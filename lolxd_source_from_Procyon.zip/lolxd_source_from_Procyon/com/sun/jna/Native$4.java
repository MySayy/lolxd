// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna;

import java.lang.reflect.Method;
import java.security.PrivilegedAction;

final class Native$4 implements PrivilegedAction<Method>
{
    private static final String a;
    
    @Override
    public Method run() {
        try {
            final Method declaredMethod = ClassLoader.class.getDeclaredMethod(Native$4.a, String.class);
            declaredMethod.setAccessible(true);
            return declaredMethod;
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 57);
        final char[] charArray = "7@|l|\u000bE#H`q".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 104;
                            break;
                        }
                        case 1: {
                            n5 = 16;
                            break;
                        }
                        case 2: {
                            n5 = 43;
                            break;
                        }
                        case 3: {
                            n5 = 49;
                            break;
                        }
                        case 4: {
                            n5 = 9;
                            break;
                        }
                        case 5: {
                            n5 = 91;
                            break;
                        }
                        default: {
                            n5 = 30;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
