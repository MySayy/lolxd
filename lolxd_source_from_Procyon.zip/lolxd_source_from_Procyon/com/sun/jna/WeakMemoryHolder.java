// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna;

import java.lang.ref.WeakReference;
import java.lang.ref.Reference;
import java.util.IdentityHashMap;
import java.lang.ref.ReferenceQueue;

public class WeakMemoryHolder
{
    ReferenceQueue<Object> referenceQueue;
    IdentityHashMap<Reference<Object>, Memory> backingMap;
    
    public WeakMemoryHolder() {
        this.referenceQueue = new ReferenceQueue<Object>();
        this.backingMap = new IdentityHashMap<Reference<Object>, Memory>();
    }
    
    public synchronized void put(final Object referent, final Memory value) {
        this.clean();
        this.backingMap.put(new WeakReference<Object>(referent, this.referenceQueue), value);
    }
    
    public synchronized void clean() {
        final int[] b = PointerType.b();
        Reference<?> key = this.referenceQueue.poll();
        final int[] array = b;
        while (key != null) {
            this.backingMap.remove(key);
            key = this.referenceQueue.poll();
            if (array == null) {
                break;
            }
        }
    }
}
