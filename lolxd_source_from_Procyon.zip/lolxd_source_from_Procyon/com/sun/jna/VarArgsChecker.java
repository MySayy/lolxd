// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna;

import java.lang.reflect.Method;

abstract class VarArgsChecker
{
    private static final String a;
    
    private VarArgsChecker() {
    }
    
    static VarArgsChecker create() {
        try {
            if (Method.class.getMethod(VarArgsChecker.a, (Class<?>[])new Class[0]) != null) {
                return new VarArgsChecker$RealVarArgsChecker(null);
            }
            return new VarArgsChecker$NoVarArgsChecker(null);
        }
        catch (NoSuchMethodException ex) {
            return new VarArgsChecker$NoVarArgsChecker(null);
        }
        catch (SecurityException ex2) {
            return new VarArgsChecker$NoVarArgsChecker(null);
        }
    }
    
    abstract boolean isVarArgs(final Method p0);
    
    abstract int fixedArgs(final Method p0);
    
    VarArgsChecker(final VarArgsChecker$1 varArgsChecker$1) {
        this();
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 24);
        final char[] charArray = "}\u0019\u000fEPK\u0002s\u0019".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 12;
                            break;
                        }
                        case 1: {
                            n5 = 114;
                            break;
                        }
                        case 2: {
                            n5 = 65;
                            break;
                        }
                        case 3: {
                            n5 = 60;
                            break;
                        }
                        case 4: {
                            n5 = 58;
                            break;
                        }
                        case 5: {
                            n5 = 18;
                            break;
                        }
                        default: {
                            n5 = 104;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
