// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna;

class Structure$AutoAllocated extends Memory
{
    private static final String e;
    
    public Structure$AutoAllocated(final int n) {
        super(n);
        super.clear();
    }
    
    @Override
    public String toString() {
        return Structure$AutoAllocated.e + super.toString();
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 90);
        final char[] charArray = "\"k\"Af".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 25;
                            break;
                        }
                        case 1: {
                            n5 = 68;
                            break;
                        }
                        case 2: {
                            n5 = 12;
                            break;
                        }
                        case 3: {
                            n5 = 116;
                            break;
                        }
                        case 4: {
                            n5 = 17;
                            break;
                        }
                        case 5: {
                            n5 = 86;
                            break;
                        }
                        default: {
                            n5 = 103;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                e = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
