// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna;

public interface Library
{
    public static final String OPTION_TYPE_MAPPER = array2[2];
    public static final String OPTION_FUNCTION_MAPPER = array2[3];
    public static final String OPTION_INVOCATION_MAPPER = array2[6];
    public static final String OPTION_STRUCTURE_ALIGNMENT = array2[4];
    public static final String OPTION_STRING_ENCODING = array2[0];
    public static final String OPTION_ALLOW_OBJECTS = array2[1];
    public static final String OPTION_CALLING_CONVENTION = array2[8];
    public static final String OPTION_OPEN_FLAGS = array2[5];
    public static final String OPTION_CLASSLOADER = array2[7];
    
    default static {
        final String[] array = new String[9];
        int n = 0;
        String s;
        int n2 = (s = "\u0015quu=\"\u001b\u0003kds7,X\u0001\r\u0007iks$hY\u0004ob\u007f'6\u000b\u0012|wy~(W\u0016ubn\u000f\u0000pi\u007f',Y\b(j}#5S\u0014\u0013\u0015qui01C\u0014`*}?,Q\bhbr'\n\tubr~#Z\u0007bt\u0011\u000fkqs0$B\u000fji1>$F\u0016`u").length();
        int n3 = 15;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 126));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0312: {
                            if (length > 1) {
                                break Label_0312;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 24;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 123;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 121;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 98;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 45;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 59;
                                        break;
                                    }
                                    default: {
                                        n11 = 72;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "\bdkb-$T\nloc\u0012\bif}7&\\Fke\u007f(-U\u001fae\u007f").length();
                            n3 = 11;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 115)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
    }
}
