// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna;

import java.lang.reflect.Method;

final class VarArgsChecker$NoVarArgsChecker extends VarArgsChecker
{
    private VarArgsChecker$NoVarArgsChecker() {
        super(null);
    }
    
    @Override
    boolean isVarArgs(final Method method) {
        return false;
    }
    
    @Override
    int fixedArgs(final Method method) {
        return 0;
    }
    
    VarArgsChecker$NoVarArgsChecker(final VarArgsChecker$1 varArgsChecker$1) {
        this();
    }
}
