// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.Graphics;
import java.awt.Window;
import java.awt.event.AWTEventListener;
import java.awt.Toolkit;
import java.awt.event.WindowListener;
import java.awt.event.ComponentListener;
import java.awt.Component;
import javax.swing.SwingUtilities;
import java.awt.Rectangle;
import javax.swing.JComponent;

public class WindowUtils$RepaintTrigger extends JComponent
{
    private static final long serialVersionUID = 1L;
    private final WindowUtils$RepaintTrigger$Listener listener;
    private final JComponent content;
    private Rectangle dirty;
    
    public WindowUtils$RepaintTrigger(final JComponent content) {
        this.listener = this.createListener();
        this.content = content;
    }
    
    @Override
    public void addNotify() {
        super.addNotify();
        final Window windowAncestor = SwingUtilities.getWindowAncestor(this);
        this.setSize(this.getParent().getSize());
        windowAncestor.addComponentListener(this.listener);
        windowAncestor.addWindowListener(this.listener);
        Toolkit.getDefaultToolkit().addAWTEventListener(this.listener, 48L);
    }
    
    @Override
    public void removeNotify() {
        Toolkit.getDefaultToolkit().removeAWTEventListener(this.listener);
        final Window windowAncestor = SwingUtilities.getWindowAncestor(this);
        windowAncestor.removeComponentListener(this.listener);
        windowAncestor.removeWindowListener(this.listener);
        super.removeNotify();
    }
    
    @Override
    protected void paintComponent(final Graphics p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_1        
        //     4: invokevirtual   java/awt/Graphics.getClipBounds:()Ljava/awt/Rectangle;
        //     7: astore_3       
        //     8: astore_2       
        //     9: aload_0        
        //    10: getfield        com/sun/jna/platform/WindowUtils$RepaintTrigger.dirty:Ljava/awt/Rectangle;
        //    13: aload_2        
        //    14: ifnonnull       68
        //    17: ifnull          56
        //    20: goto            27
        //    23: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    26: athrow         
        //    27: aload_0        
        //    28: aload_2        
        //    29: ifnonnull       130
        //    32: goto            39
        //    35: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    38: athrow         
        //    39: getfield        com/sun/jna/platform/WindowUtils$RepaintTrigger.dirty:Ljava/awt/Rectangle;
        //    42: goto            49
        //    45: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    48: athrow         
        //    49: aload_3        
        //    50: invokevirtual   java/awt/Rectangle.contains:(Ljava/awt/Rectangle;)Z
        //    53: ifne            118
        //    56: aload_0        
        //    57: aload_2        
        //    58: ifnonnull       88
        //    61: getfield        com/sun/jna/platform/WindowUtils$RepaintTrigger.dirty:Ljava/awt/Rectangle;
        //    64: aload_2        
        //    65: ifnonnull       49
        //    68: ifnonnull       87
        //    71: aload_0        
        //    72: aload_3        
        //    73: goto            80
        //    76: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    79: athrow         
        //    80: putfield        com/sun/jna/platform/WindowUtils$RepaintTrigger.dirty:Ljava/awt/Rectangle;
        //    83: aload_2        
        //    84: ifnull          103
        //    87: aload_0        
        //    88: aload_0        
        //    89: getfield        com/sun/jna/platform/WindowUtils$RepaintTrigger.dirty:Ljava/awt/Rectangle;
        //    92: aload_3        
        //    93: invokevirtual   java/awt/Rectangle.union:(Ljava/awt/Rectangle;)Ljava/awt/Rectangle;
        //    96: aload_2        
        //    97: ifnonnull       80
        //   100: putfield        com/sun/jna/platform/WindowUtils$RepaintTrigger.dirty:Ljava/awt/Rectangle;
        //   103: aload_0        
        //   104: getfield        com/sun/jna/platform/WindowUtils$RepaintTrigger.content:Ljavax/swing/JComponent;
        //   107: aload_0        
        //   108: getfield        com/sun/jna/platform/WindowUtils$RepaintTrigger.dirty:Ljava/awt/Rectangle;
        //   111: invokevirtual   javax/swing/JComponent.repaint:(Ljava/awt/Rectangle;)V
        //   114: aload_2        
        //   115: ifnull          134
        //   118: aload_0        
        //   119: aload_2        
        //   120: ifnonnull       57
        //   123: goto            130
        //   126: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   129: athrow         
        //   130: aconst_null    
        //   131: putfield        com/sun/jna/platform/WindowUtils$RepaintTrigger.dirty:Ljava/awt/Rectangle;
        //   134: return         
        //    StackMapTable: 00 12 FF 00 17 00 04 07 00 1C 07 00 4F 07 00 87 07 00 33 00 01 07 00 82 03 47 07 00 82 43 07 00 1C 45 07 00 82 43 07 00 33 06 40 07 00 1C 4A 07 00 33 47 07 00 82 FF 00 03 00 04 07 00 1C 07 00 4F 07 00 87 07 00 33 00 02 07 00 1C 07 00 33 06 40 07 00 1C 0E 0E 47 07 00 82 43 07 00 1C 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  9      20     23     27     Ljava/lang/RuntimeException;
        //  17     32     35     39     Ljava/lang/RuntimeException;
        //  27     42     45     49     Ljava/lang/RuntimeException;
        //  68     73     76     80     Ljava/lang/RuntimeException;
        //  103    123    126    130    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0027:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    protected WindowUtils$RepaintTrigger$Listener createListener() {
        return new WindowUtils$RepaintTrigger$Listener(this);
    }
    
    static JComponent access$000(final WindowUtils$RepaintTrigger windowUtils$RepaintTrigger) {
        return windowUtils$RepaintTrigger.content;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
