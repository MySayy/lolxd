// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.Rectangle;
import java.util.Set;
import java.awt.image.Raster;
import java.util.Comparator;

public class RasterRangesUtils
{
    private static final int[] subColMasks;
    private static final Comparator<Object> COMPARATOR;
    
    public static boolean outputOccupiedRanges(final Raster p0, final RasterRangesUtils$RangesOutput p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokevirtual   java/awt/image/Raster.getBounds:()Ljava/awt/Rectangle;
        //     4: astore_3       
        //     5: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils.b:()[I
        //     8: aload_0        
        //     9: invokevirtual   java/awt/image/Raster.getSampleModel:()Ljava/awt/image/SampleModel;
        //    12: astore          4
        //    14: astore_2       
        //    15: aload           4
        //    17: invokevirtual   java/awt/image/SampleModel.getNumBands:()I
        //    20: aload_2        
        //    21: ifnonnull       54
        //    24: aload_2        
        //    25: ifnonnull       54
        //    28: goto            35
        //    31: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    34: athrow         
        //    35: iconst_4       
        //    36: if_icmpne       57
        //    39: goto            46
        //    42: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    45: athrow         
        //    46: iconst_1       
        //    47: goto            54
        //    50: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    53: athrow         
        //    54: goto            58
        //    57: iconst_0       
        //    58: istore          5
        //    60: aload_0        
        //    61: invokevirtual   java/awt/image/Raster.getParent:()Ljava/awt/image/Raster;
        //    64: aload_2        
        //    65: ifnonnull       371
        //    68: ifnonnull       366
        //    71: goto            78
        //    74: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    77: athrow         
        //    78: aload_3        
        //    79: getfield        java/awt/Rectangle.x:I
        //    82: aload_2        
        //    83: ifnonnull       125
        //    86: goto            93
        //    89: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    92: athrow         
        //    93: aload_2        
        //    94: ifnonnull       125
        //    97: goto            104
        //   100: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   103: athrow         
        //   104: ifne            366
        //   107: goto            114
        //   110: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   113: athrow         
        //   114: aload_3        
        //   115: getfield        java/awt/Rectangle.y:I
        //   118: goto            125
        //   121: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   124: athrow         
        //   125: ifne            366
        //   128: aload_0        
        //   129: aload_2        
        //   130: ifnonnull       371
        //   133: invokevirtual   java/awt/image/Raster.getDataBuffer:()Ljava/awt/image/DataBuffer;
        //   136: astore          6
        //   138: aload           6
        //   140: invokevirtual   java/awt/image/DataBuffer.getNumBanks:()I
        //   143: aload_2        
        //   144: ifnonnull       170
        //   147: iconst_1       
        //   148: if_icmpne       366
        //   151: goto            158
        //   154: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   157: athrow         
        //   158: aload           4
        //   160: instanceof      Ljava/awt/image/MultiPixelPackedSampleModel;
        //   163: goto            170
        //   166: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   169: athrow         
        //   170: aload_2        
        //   171: ifnonnull       267
        //   174: ifeq            247
        //   177: goto            184
        //   180: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   183: athrow         
        //   184: aload           4
        //   186: checkcast       Ljava/awt/image/MultiPixelPackedSampleModel;
        //   189: astore          7
        //   191: aload           7
        //   193: invokevirtual   java/awt/image/MultiPixelPackedSampleModel.getPixelBitStride:()I
        //   196: aload_2        
        //   197: ifnonnull       242
        //   200: aload_2        
        //   201: ifnonnull       242
        //   204: iconst_1       
        //   205: if_icmpne       243
        //   208: goto            215
        //   211: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   214: athrow         
        //   215: aload           6
        //   217: checkcast       Ljava/awt/image/DataBufferByte;
        //   220: invokevirtual   java/awt/image/DataBufferByte.getData:()[B
        //   223: aload_3        
        //   224: getfield        java/awt/Rectangle.width:I
        //   227: aload_3        
        //   228: getfield        java/awt/Rectangle.height:I
        //   231: aload_1        
        //   232: invokestatic    com/sun/jna/platform/RasterRangesUtils.outputOccupiedRangesOfBinaryPixels:([BIILcom/sun/jna/platform/RasterRangesUtils$RangesOutput;)Z
        //   235: goto            242
        //   238: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   241: athrow         
        //   242: ireturn        
        //   243: aload_2        
        //   244: ifnull          366
        //   247: aload           4
        //   249: aload_2        
        //   250: ifnonnull       186
        //   253: goto            260
        //   256: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   259: athrow         
        //   260: instanceof      Ljava/awt/image/SinglePixelPackedSampleModel;
        //   263: aload_2        
        //   264: ifnonnull       300
        //   267: aload_2        
        //   268: ifnonnull       300
        //   271: goto            278
        //   274: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   277: athrow         
        //   278: ifeq            366
        //   281: goto            288
        //   284: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   287: athrow         
        //   288: aload           4
        //   290: invokevirtual   java/awt/image/SampleModel.getDataType:()I
        //   293: goto            300
        //   296: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   299: athrow         
        //   300: iconst_3       
        //   301: if_icmpne       366
        //   304: aload           6
        //   306: checkcast       Ljava/awt/image/DataBufferInt;
        //   309: invokevirtual   java/awt/image/DataBufferInt.getData:()[I
        //   312: aload_3        
        //   313: getfield        java/awt/Rectangle.width:I
        //   316: aload_3        
        //   317: getfield        java/awt/Rectangle.height:I
        //   320: iload           5
        //   322: aload_2        
        //   323: ifnonnull       356
        //   326: goto            333
        //   329: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   332: athrow         
        //   333: aload_2        
        //   334: ifnonnull       356
        //   337: goto            344
        //   340: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   343: athrow         
        //   344: ifeq            359
        //   347: goto            354
        //   350: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   353: athrow         
        //   354: ldc             -16777216
        //   356: goto            361
        //   359: ldc             16777215
        //   361: aload_1        
        //   362: invokestatic    com/sun/jna/platform/RasterRangesUtils.outputOccupiedRanges:([IIIILcom/sun/jna/platform/RasterRangesUtils$RangesOutput;)Z
        //   365: ireturn        
        //   366: aload_0        
        //   367: aload_2        
        //   368: ifnonnull       129
        //   371: iconst_0       
        //   372: iconst_0       
        //   373: aload_3        
        //   374: getfield        java/awt/Rectangle.width:I
        //   377: aload_3        
        //   378: getfield        java/awt/Rectangle.height:I
        //   381: aconst_null    
        //   382: checkcast       [I
        //   385: invokevirtual   java/awt/image/Raster.getPixels:(IIII[I)[I
        //   388: astore          6
        //   390: aload           6
        //   392: aload_3        
        //   393: getfield        java/awt/Rectangle.width:I
        //   396: aload_3        
        //   397: getfield        java/awt/Rectangle.height:I
        //   400: iload           5
        //   402: aload_2        
        //   403: ifnonnull       429
        //   406: aload_2        
        //   407: ifnonnull       429
        //   410: goto            417
        //   413: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   416: athrow         
        //   417: ifeq            432
        //   420: goto            427
        //   423: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   426: athrow         
        //   427: ldc             -16777216
        //   429: goto            434
        //   432: ldc             16777215
        //   434: aload_1        
        //   435: invokestatic    com/sun/jna/platform/RasterRangesUtils.outputOccupiedRanges:([IIIILcom/sun/jna/platform/RasterRangesUtils$RangesOutput;)Z
        //   438: ireturn        
        //    StackMapTable: 00 3B FF 00 1F 00 05 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 00 01 07 00 BB 43 01 46 07 00 BB 03 43 07 00 BB 43 01 02 40 01 FF 00 0F 00 06 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 01 00 01 07 00 BB 03 4A 07 00 BB 43 01 46 07 00 BB 43 01 45 07 00 BB 03 46 07 00 BB 43 01 43 07 00 45 FF 00 18 00 07 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 01 07 00 15 00 01 07 00 BB 03 47 07 00 BB 43 01 49 07 00 BB 03 41 07 00 44 FF 00 18 00 08 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 01 07 00 15 07 00 0C 00 01 07 00 BB 03 56 07 00 BB 43 01 00 FA 00 03 48 07 00 BB 43 07 00 44 46 01 46 07 00 BB 43 01 45 07 00 BB 03 47 07 00 BB 43 01 5C 07 00 BB FF 00 03 00 07 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 01 07 00 15 00 04 07 00 19 01 01 01 46 07 00 BB FF 00 03 00 07 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 01 07 00 15 00 04 07 00 19 01 01 01 45 07 00 BB FF 00 03 00 07 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 01 07 00 15 00 03 07 00 19 01 01 FF 00 01 00 07 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 01 07 00 15 00 04 07 00 19 01 01 01 FF 00 02 00 07 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 01 07 00 15 00 03 07 00 19 01 01 FF 00 01 00 07 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 01 07 00 15 00 04 07 00 19 01 01 01 FA 00 04 44 07 00 45 FF 00 29 00 07 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 01 07 00 19 00 01 07 00 BB FF 00 03 00 07 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 01 07 00 19 00 04 07 00 19 01 01 01 45 07 00 BB FF 00 03 00 07 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 01 07 00 19 00 03 07 00 19 01 01 FF 00 01 00 07 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 01 07 00 19 00 04 07 00 19 01 01 01 FF 00 02 00 07 07 00 45 07 00 35 07 00 19 07 00 21 07 00 44 01 07 00 19 00 03 07 00 19 01 01 FF 00 01 00 02 00 07 00 35 00 04 07 00 19 01 01 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  15     28     31     35     Ljava/lang/RuntimeException;
        //  24     39     42     46     Ljava/lang/RuntimeException;
        //  35     47     50     54     Ljava/lang/RuntimeException;
        //  60     71     74     78     Ljava/lang/RuntimeException;
        //  68     86     89     93     Ljava/lang/RuntimeException;
        //  78     97     100    104    Ljava/lang/RuntimeException;
        //  93     107    110    114    Ljava/lang/RuntimeException;
        //  104    118    121    125    Ljava/lang/RuntimeException;
        //  138    151    154    158    Ljava/lang/RuntimeException;
        //  147    163    166    170    Ljava/lang/RuntimeException;
        //  170    177    180    184    Ljava/lang/RuntimeException;
        //  200    208    211    215    Ljava/lang/RuntimeException;
        //  204    235    238    242    Ljava/lang/RuntimeException;
        //  243    253    256    260    Ljava/lang/RuntimeException;
        //  260    271    274    278    Ljava/lang/RuntimeException;
        //  267    281    284    288    Ljava/lang/RuntimeException;
        //  278    293    296    300    Ljava/lang/RuntimeException;
        //  300    326    329    333    Ljava/lang/RuntimeException;
        //  304    337    340    344    Ljava/lang/RuntimeException;
        //  333    347    350    354    Ljava/lang/RuntimeException;
        //  390    410    413    417    Ljava/lang/RuntimeException;
        //  406    420    423    427    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0035:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static boolean outputOccupiedRangesOfBinaryPixels(final byte[] p0, final int p1, final int p2, final RasterRangesUtils$RangesOutput p3) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: invokespecial   java/util/HashSet.<init>:()V
        //     7: astore          5
        //     9: invokestatic    java/util/Collections.emptySet:()Ljava/util/Set;
        //    12: astore          6
        //    14: aload_0        
        //    15: arraylength    
        //    16: iload_2        
        //    17: idiv           
        //    18: istore          7
        //    20: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils.b:()[I
        //    23: iconst_0       
        //    24: istore          8
        //    26: astore          4
        //    28: iload           8
        //    30: iload_2        
        //    31: if_icmpge       470
        //    34: new             Ljava/util/TreeSet;
        //    37: dup            
        //    38: getstatic       com/sun/jna/platform/RasterRangesUtils.COMPARATOR:Ljava/util/Comparator;
        //    41: invokespecial   java/util/TreeSet.<init>:(Ljava/util/Comparator;)V
        //    44: astore          9
        //    46: iload           8
        //    48: iload           7
        //    50: imul           
        //    51: istore          10
        //    53: iconst_m1      
        //    54: istore          11
        //    56: iconst_0       
        //    57: aload           4
        //    59: ifnonnull       479
        //    62: istore          12
        //    64: iload           12
        //    66: iload           7
        //    68: if_icmpge       379
        //    71: iload           12
        //    73: iconst_3       
        //    74: ishl           
        //    75: istore          13
        //    77: aload_0        
        //    78: iload           10
        //    80: iload           12
        //    82: iadd           
        //    83: baload         
        //    84: istore          14
        //    86: iload           14
        //    88: aload           4
        //    90: ifnonnull       381
        //    93: aload           4
        //    95: ifnonnull       172
        //    98: goto            105
        //   101: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   104: athrow         
        //   105: ifne            165
        //   108: goto            115
        //   111: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   114: athrow         
        //   115: iload           11
        //   117: aload           4
        //   119: ifnonnull       158
        //   122: iflt            361
        //   125: aload           9
        //   127: new             Ljava/awt/Rectangle;
        //   130: dup            
        //   131: iload           11
        //   133: iload           8
        //   135: iload           13
        //   137: iload           11
        //   139: isub           
        //   140: iconst_1       
        //   141: invokespecial   java/awt/Rectangle.<init>:(IIII)V
        //   144: invokeinterface java/util/Set.add:(Ljava/lang/Object;)Z
        //   149: pop            
        //   150: iconst_m1      
        //   151: goto            158
        //   154: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   157: athrow         
        //   158: istore          11
        //   160: aload           4
        //   162: ifnull          361
        //   165: iload           14
        //   167: aload           4
        //   169: ifnonnull       117
        //   172: aload           4
        //   174: ifnonnull       222
        //   177: sipush          255
        //   180: if_icmpne       216
        //   183: goto            190
        //   186: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   189: athrow         
        //   190: iload           11
        //   192: goto            199
        //   195: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   198: athrow         
        //   199: aload           4
        //   201: ifnonnull       209
        //   204: ifge            361
        //   207: iload           13
        //   209: istore          11
        //   211: aload           4
        //   213: ifnull          361
        //   216: iconst_0       
        //   217: aload           4
        //   219: ifnonnull       199
        //   222: istore          15
        //   224: iload           15
        //   226: bipush          8
        //   228: if_icmpge       361
        //   231: iload           13
        //   233: iload           15
        //   235: ior            
        //   236: istore          16
        //   238: iload           14
        //   240: getstatic       com/sun/jna/platform/RasterRangesUtils.subColMasks:[I
        //   243: iload           15
        //   245: iaload         
        //   246: iand           
        //   247: aload           4
        //   249: ifnonnull       66
        //   252: aload           4
        //   254: ifnonnull       293
        //   257: ifeq            286
        //   260: goto            267
        //   263: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   266: athrow         
        //   267: iload           11
        //   269: aload           4
        //   271: ifnonnull       279
        //   274: ifge            343
        //   277: iload           16
        //   279: istore          11
        //   281: aload           4
        //   283: ifnull          343
        //   286: iload           11
        //   288: aload           4
        //   290: ifnonnull       269
        //   293: aload           4
        //   295: ifnonnull       341
        //   298: iflt            343
        //   301: goto            308
        //   304: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   307: athrow         
        //   308: aload           9
        //   310: new             Ljava/awt/Rectangle;
        //   313: dup            
        //   314: iload           11
        //   316: iload           8
        //   318: iload           16
        //   320: iload           11
        //   322: isub           
        //   323: iconst_1       
        //   324: invokespecial   java/awt/Rectangle.<init>:(IIII)V
        //   327: invokeinterface java/util/Set.add:(Ljava/lang/Object;)Z
        //   332: pop            
        //   333: goto            340
        //   336: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   339: athrow         
        //   340: iconst_m1      
        //   341: istore          11
        //   343: iinc            15, 1
        //   346: aload           4
        //   348: ifnonnull       281
        //   351: aload           4
        //   353: ifnonnull       340
        //   356: aload           4
        //   358: ifnull          224
        //   361: iinc            12, 1
        //   364: aload           4
        //   366: ifnonnull       160
        //   369: aload           4
        //   371: ifnonnull       211
        //   374: aload           4
        //   376: ifnull          64
        //   379: iload           11
        //   381: aload           4
        //   383: ifnonnull       438
        //   386: aload           4
        //   388: ifnonnull       438
        //   391: goto            398
        //   394: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   397: athrow         
        //   398: iflt            439
        //   401: goto            408
        //   404: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   407: athrow         
        //   408: aload           9
        //   410: new             Ljava/awt/Rectangle;
        //   413: dup            
        //   414: iload           11
        //   416: iload           8
        //   418: iload_1        
        //   419: iload           11
        //   421: isub           
        //   422: iconst_1       
        //   423: invokespecial   java/awt/Rectangle.<init>:(IIII)V
        //   426: invokeinterface java/util/Set.add:(Ljava/lang/Object;)Z
        //   431: goto            438
        //   434: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   437: athrow         
        //   438: pop            
        //   439: aload           6
        //   441: aload           9
        //   443: invokestatic    com/sun/jna/platform/RasterRangesUtils.mergeRects:(Ljava/util/Set;Ljava/util/Set;)Ljava/util/Set;
        //   446: astore          12
        //   448: aload           5
        //   450: aload           12
        //   452: invokeinterface java/util/Set.addAll:(Ljava/util/Collection;)Z
        //   457: pop            
        //   458: aload           9
        //   460: astore          6
        //   462: iinc            8, 1
        //   465: aload           4
        //   467: ifnull          28
        //   470: aload           5
        //   472: aload           6
        //   474: invokeinterface java/util/Set.addAll:(Ljava/util/Collection;)Z
        //   479: pop            
        //   480: aload           5
        //   482: invokeinterface java/util/Set.iterator:()Ljava/util/Iterator;
        //   487: astore          8
        //   489: aload           8
        //   491: invokeinterface java/util/Iterator.hasNext:()Z
        //   496: ifeq            583
        //   499: aload           8
        //   501: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   506: checkcast       Ljava/awt/Rectangle;
        //   509: astore          9
        //   511: aload_3        
        //   512: aload           9
        //   514: getfield        java/awt/Rectangle.x:I
        //   517: aload           9
        //   519: getfield        java/awt/Rectangle.y:I
        //   522: aload           9
        //   524: getfield        java/awt/Rectangle.width:I
        //   527: aload           9
        //   529: getfield        java/awt/Rectangle.height:I
        //   532: invokeinterface com/sun/jna/platform/RasterRangesUtils$RangesOutput.outputRange:(IIII)Z
        //   537: aload           4
        //   539: ifnonnull       584
        //   542: aload           4
        //   544: ifnonnull       577
        //   547: goto            554
        //   550: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   553: athrow         
        //   554: aload           4
        //   556: ifnonnull       577
        //   559: goto            566
        //   562: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   565: athrow         
        //   566: ifne            578
        //   569: goto            576
        //   572: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   575: athrow         
        //   576: iconst_0       
        //   577: ireturn        
        //   578: aload           4
        //   580: ifnull          489
        //   583: iconst_1       
        //   584: ireturn        
        //    StackMapTable: 00 3A FF 00 1C 00 09 07 00 4A 01 01 07 00 35 07 00 19 07 00 1B 07 00 4B 01 01 00 00 FF 00 23 00 0D 07 00 4A 01 01 07 00 35 07 00 19 07 00 1B 07 00 4B 01 01 07 00 1E 01 01 01 00 00 41 01 FF 00 22 00 0F 07 00 4A 01 01 07 00 35 07 00 19 07 00 1B 07 00 4B 01 01 07 00 1E 01 01 01 01 01 00 01 07 00 BB 43 01 45 07 00 BB 03 41 01 64 07 00 BB 43 01 01 04 46 01 4D 07 00 BB 03 44 07 00 BB 43 01 49 01 01 04 45 01 FC 00 01 01 FF 00 26 00 11 07 00 4A 01 01 07 00 35 07 00 19 07 00 1B 07 00 4B 01 01 07 00 1E 01 01 01 01 01 01 01 00 01 07 00 BB 03 41 01 49 01 01 04 46 01 4A 07 00 BB 03 5B 07 00 BB 03 40 01 01 F9 00 11 F9 00 11 41 01 4C 07 00 BB 43 01 45 07 00 BB 03 59 07 00 BB 43 01 00 FF 00 1E 00 09 07 00 4A 01 01 07 00 35 07 00 19 07 00 1B 07 00 4B 01 01 00 00 48 01 FF 00 09 00 09 07 00 4A 01 01 07 00 35 07 00 19 07 00 1B 07 00 4B 01 07 00 4C 00 00 FF 00 3C 00 0A 07 00 4A 01 01 07 00 35 07 00 19 07 00 1B 07 00 4B 01 07 00 4C 07 00 21 00 01 07 00 BB 43 01 47 07 00 BB 43 01 45 07 00 BB 03 40 01 00 FA 00 04 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  86     98     101    105    Ljava/lang/RuntimeException;
        //  93     108    111    115    Ljava/lang/RuntimeException;
        //  122    151    154    158    Ljava/lang/RuntimeException;
        //  172    183    186    190    Ljava/lang/RuntimeException;
        //  177    192    195    199    Ljava/lang/RuntimeException;
        //  252    260    263    267    Ljava/lang/RuntimeException;
        //  293    301    304    308    Ljava/lang/RuntimeException;
        //  298    333    336    340    Ljava/lang/RuntimeException;
        //  381    391    394    398    Ljava/lang/RuntimeException;
        //  386    401    404    408    Ljava/lang/RuntimeException;
        //  398    431    434    438    Ljava/lang/RuntimeException;
        //  511    547    550    554    Ljava/lang/RuntimeException;
        //  542    559    562    566    Ljava/lang/RuntimeException;
        //  554    569    572    576    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0398:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static boolean outputOccupiedRanges(final int[] p0, final int p1, final int p2, final int p3, final RasterRangesUtils$RangesOutput p4) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: new             Ljava/util/HashSet;
        //     6: dup            
        //     7: invokespecial   java/util/HashSet.<init>:()V
        //    10: astore          6
        //    12: invokestatic    java/util/Collections.emptySet:()Ljava/util/Set;
        //    15: astore          7
        //    17: iconst_0       
        //    18: istore          8
        //    20: astore          5
        //    22: iload           8
        //    24: iload_2        
        //    25: if_icmpge       284
        //    28: new             Ljava/util/TreeSet;
        //    31: dup            
        //    32: getstatic       com/sun/jna/platform/RasterRangesUtils.COMPARATOR:Ljava/util/Comparator;
        //    35: invokespecial   java/util/TreeSet.<init>:(Ljava/util/Comparator;)V
        //    38: astore          9
        //    40: iload           8
        //    42: iload_1        
        //    43: imul           
        //    44: istore          10
        //    46: iconst_m1      
        //    47: istore          11
        //    49: iconst_0       
        //    50: aload           5
        //    52: ifnonnull       293
        //    55: istore          12
        //    57: iload           12
        //    59: iload_1        
        //    60: if_icmpge       193
        //    63: aload_0        
        //    64: iload           10
        //    66: iload           12
        //    68: iadd           
        //    69: iaload         
        //    70: iload_3        
        //    71: iand           
        //    72: aload           5
        //    74: ifnonnull       195
        //    77: aload           5
        //    79: ifnonnull       125
        //    82: goto            89
        //    85: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    88: athrow         
        //    89: ifeq            118
        //    92: goto            99
        //    95: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    98: athrow         
        //    99: iload           11
        //   101: aload           5
        //   103: ifnonnull       111
        //   106: ifge            175
        //   109: iload           12
        //   111: istore          11
        //   113: aload           5
        //   115: ifnull          175
        //   118: iload           11
        //   120: aload           5
        //   122: ifnonnull       101
        //   125: aload           5
        //   127: ifnonnull       173
        //   130: iflt            175
        //   133: goto            140
        //   136: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   139: athrow         
        //   140: aload           9
        //   142: new             Ljava/awt/Rectangle;
        //   145: dup            
        //   146: iload           11
        //   148: iload           8
        //   150: iload           12
        //   152: iload           11
        //   154: isub           
        //   155: iconst_1       
        //   156: invokespecial   java/awt/Rectangle.<init>:(IIII)V
        //   159: invokeinterface java/util/Set.add:(Ljava/lang/Object;)Z
        //   164: pop            
        //   165: goto            172
        //   168: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   171: athrow         
        //   172: iconst_m1      
        //   173: istore          11
        //   175: iinc            12, 1
        //   178: aload           5
        //   180: ifnonnull       113
        //   183: aload           5
        //   185: ifnonnull       172
        //   188: aload           5
        //   190: ifnull          57
        //   193: iload           11
        //   195: aload           5
        //   197: ifnonnull       252
        //   200: aload           5
        //   202: ifnonnull       252
        //   205: goto            212
        //   208: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   211: athrow         
        //   212: iflt            253
        //   215: goto            222
        //   218: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   221: athrow         
        //   222: aload           9
        //   224: new             Ljava/awt/Rectangle;
        //   227: dup            
        //   228: iload           11
        //   230: iload           8
        //   232: iload_1        
        //   233: iload           11
        //   235: isub           
        //   236: iconst_1       
        //   237: invokespecial   java/awt/Rectangle.<init>:(IIII)V
        //   240: invokeinterface java/util/Set.add:(Ljava/lang/Object;)Z
        //   245: goto            252
        //   248: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   251: athrow         
        //   252: pop            
        //   253: aload           7
        //   255: aload           9
        //   257: invokestatic    com/sun/jna/platform/RasterRangesUtils.mergeRects:(Ljava/util/Set;Ljava/util/Set;)Ljava/util/Set;
        //   260: astore          12
        //   262: aload           6
        //   264: aload           12
        //   266: invokeinterface java/util/Set.addAll:(Ljava/util/Collection;)Z
        //   271: pop            
        //   272: aload           9
        //   274: astore          7
        //   276: iinc            8, 1
        //   279: aload           5
        //   281: ifnull          22
        //   284: aload           6
        //   286: aload           7
        //   288: invokeinterface java/util/Set.addAll:(Ljava/util/Collection;)Z
        //   293: pop            
        //   294: aload           6
        //   296: invokeinterface java/util/Set.iterator:()Ljava/util/Iterator;
        //   301: astore          8
        //   303: aload           8
        //   305: invokeinterface java/util/Iterator.hasNext:()Z
        //   310: ifeq            398
        //   313: aload           8
        //   315: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   320: checkcast       Ljava/awt/Rectangle;
        //   323: astore          9
        //   325: aload           4
        //   327: aload           9
        //   329: getfield        java/awt/Rectangle.x:I
        //   332: aload           9
        //   334: getfield        java/awt/Rectangle.y:I
        //   337: aload           9
        //   339: getfield        java/awt/Rectangle.width:I
        //   342: aload           9
        //   344: getfield        java/awt/Rectangle.height:I
        //   347: invokeinterface com/sun/jna/platform/RasterRangesUtils$RangesOutput.outputRange:(IIII)Z
        //   352: aload           5
        //   354: ifnonnull       399
        //   357: aload           5
        //   359: ifnonnull       392
        //   362: goto            369
        //   365: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   368: athrow         
        //   369: aload           5
        //   371: ifnonnull       392
        //   374: goto            381
        //   377: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   380: athrow         
        //   381: ifne            393
        //   384: goto            391
        //   387: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   390: athrow         
        //   391: iconst_0       
        //   392: ireturn        
        //   393: aload           5
        //   395: ifnull          303
        //   398: iconst_1       
        //   399: ireturn        
        //    StackMapTable: 00 27 FF 00 16 00 09 07 00 19 01 01 01 07 00 35 07 00 19 07 00 1B 07 00 4B 01 00 00 FF 00 22 00 0D 07 00 19 01 01 01 07 00 35 07 00 19 07 00 1B 07 00 4B 01 07 00 1E 01 01 01 00 00 5B 07 00 BB 43 01 45 07 00 BB 03 41 01 49 01 01 04 46 01 4A 07 00 BB 03 5B 07 00 BB 03 40 01 01 11 41 01 4C 07 00 BB 43 01 45 07 00 BB 03 59 07 00 BB 43 01 00 FF 00 1E 00 09 07 00 19 01 01 01 07 00 35 07 00 19 07 00 1B 07 00 4B 01 00 00 48 01 FF 00 09 00 09 07 00 19 01 01 01 07 00 35 07 00 19 07 00 1B 07 00 4B 07 00 4C 00 00 FF 00 3D 00 0A 07 00 19 01 01 01 07 00 35 07 00 19 07 00 1B 07 00 4B 07 00 4C 07 00 21 00 01 07 00 BB 43 01 47 07 00 BB 43 01 45 07 00 BB 03 40 01 00 FA 00 04 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  63     82     85     89     Ljava/lang/RuntimeException;
        //  77     92     95     99     Ljava/lang/RuntimeException;
        //  125    133    136    140    Ljava/lang/RuntimeException;
        //  130    165    168    172    Ljava/lang/RuntimeException;
        //  195    205    208    212    Ljava/lang/RuntimeException;
        //  200    215    218    222    Ljava/lang/RuntimeException;
        //  212    245    248    252    Ljava/lang/RuntimeException;
        //  325    362    365    369    Ljava/lang/RuntimeException;
        //  357    374    377    381    Ljava/lang/RuntimeException;
        //  369    384    387    391    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0212:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static Set<Rectangle> mergeRects(final Set<Rectangle> p0, final Set<Rectangle> p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: aload_0        
        //     5: invokespecial   java/util/HashSet.<init>:(Ljava/util/Collection;)V
        //     8: astore_3       
        //     9: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils.b:()[I
        //    12: astore_2       
        //    13: aload_0        
        //    14: invokeinterface java/util/Set.isEmpty:()Z
        //    19: aload_2        
        //    20: ifnonnull       43
        //    23: ifne            322
        //    26: goto            33
        //    29: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    32: athrow         
        //    33: aload_1        
        //    34: aload_2        
        //    35: ifnonnull       47
        //    38: invokeinterface java/util/Set.isEmpty:()Z
        //    43: ifne            322
        //    46: aload_0        
        //    47: aload_0        
        //    48: invokeinterface java/util/Set.size:()I
        //    53: anewarray       Ljava/awt/Rectangle;
        //    56: invokeinterface java/util/Set.toArray:([Ljava/lang/Object;)[Ljava/lang/Object;
        //    61: checkcast       [Ljava/awt/Rectangle;
        //    64: astore          4
        //    66: aload_1        
        //    67: aload_1        
        //    68: invokeinterface java/util/Set.size:()I
        //    73: anewarray       Ljava/awt/Rectangle;
        //    76: invokeinterface java/util/Set.toArray:([Ljava/lang/Object;)[Ljava/lang/Object;
        //    81: checkcast       [Ljava/awt/Rectangle;
        //    84: astore          5
        //    86: iconst_0       
        //    87: istore          6
        //    89: iconst_0       
        //    90: istore          7
        //    92: iload           6
        //    94: aload           4
        //    96: arraylength    
        //    97: if_icmpge       322
        //   100: iload           7
        //   102: aload           5
        //   104: arraylength    
        //   105: aload_2        
        //   106: ifnonnull       153
        //   109: aload_2        
        //   110: ifnonnull       153
        //   113: goto            120
        //   116: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   119: athrow         
        //   120: if_icmpge       322
        //   123: goto            130
        //   126: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   129: athrow         
        //   130: aload           5
        //   132: iload           7
        //   134: aaload         
        //   135: getfield        java/awt/Rectangle.x:I
        //   138: aload           4
        //   140: iload           6
        //   142: aaload         
        //   143: getfield        java/awt/Rectangle.x:I
        //   146: goto            153
        //   149: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   152: athrow         
        //   153: if_icmpge       173
        //   156: iinc            7, 1
        //   159: iload           7
        //   161: aload           5
        //   163: arraylength    
        //   164: if_icmpne       130
        //   167: aload_2        
        //   168: ifnonnull       159
        //   171: aload_3        
        //   172: areturn        
        //   173: aload           5
        //   175: iload           7
        //   177: aaload         
        //   178: getfield        java/awt/Rectangle.x:I
        //   181: aload           4
        //   183: iload           6
        //   185: aaload         
        //   186: getfield        java/awt/Rectangle.x:I
        //   189: aload_2        
        //   190: ifnonnull       248
        //   193: aload_2        
        //   194: ifnonnull       248
        //   197: goto            204
        //   200: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   203: athrow         
        //   204: if_icmpne       311
        //   207: goto            214
        //   210: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   213: athrow         
        //   214: aload           5
        //   216: iload           7
        //   218: aaload         
        //   219: getfield        java/awt/Rectangle.width:I
        //   222: aload_2        
        //   223: ifnonnull       269
        //   226: goto            233
        //   229: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   232: athrow         
        //   233: aload           4
        //   235: iload           6
        //   237: aaload         
        //   238: getfield        java/awt/Rectangle.width:I
        //   241: goto            248
        //   244: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   247: athrow         
        //   248: if_icmpne       311
        //   251: aload_3        
        //   252: aload           4
        //   254: iload           6
        //   256: aaload         
        //   257: invokeinterface java/util/Set.remove:(Ljava/lang/Object;)Z
        //   262: goto            269
        //   265: invokestatic    com/sun/jna/platform/RasterRangesUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   268: athrow         
        //   269: pop            
        //   270: aload           5
        //   272: iload           7
        //   274: aaload         
        //   275: aload           4
        //   277: iload           6
        //   279: aaload         
        //   280: getfield        java/awt/Rectangle.y:I
        //   283: putfield        java/awt/Rectangle.y:I
        //   286: aload           5
        //   288: iload           7
        //   290: aaload         
        //   291: aload           4
        //   293: iload           6
        //   295: aaload         
        //   296: getfield        java/awt/Rectangle.height:I
        //   299: iconst_1       
        //   300: iadd           
        //   301: putfield        java/awt/Rectangle.height:I
        //   304: iinc            7, 1
        //   307: aload_2        
        //   308: ifnull          92
        //   311: iinc            6, 1
        //   314: aload_2        
        //   315: ifnonnull       307
        //   318: aload_2        
        //   319: ifnull          92
        //   322: aload_3        
        //   323: aload_2        
        //   324: ifnonnull       34
        //   327: aload_2        
        //   328: ifnonnull       47
        //   331: areturn        
        //    Signature:
        //  (Ljava/util/Set<Ljava/awt/Rectangle;>;Ljava/util/Set<Ljava/awt/Rectangle;>;)Ljava/util/Set<Ljava/awt/Rectangle;>;
        //    StackMapTable: 00 1B FF 00 1D 00 04 07 00 4B 07 00 4B 07 00 19 07 00 1B 00 01 07 00 BB 03 40 07 00 4B 48 01 43 07 00 4B FF 00 2C 00 08 07 00 4B 07 00 4B 07 00 19 07 00 1B 07 00 2F 07 00 2F 01 01 00 00 57 07 00 BB FF 00 03 00 08 07 00 4B 07 00 4B 07 00 19 07 00 1B 07 00 2F 07 00 2F 01 01 00 02 01 01 45 07 00 BB 03 52 07 00 BB FF 00 03 00 08 07 00 4B 07 00 4B 07 00 19 07 00 1B 07 00 2F 07 00 2F 01 01 00 02 01 01 05 0D 5A 07 00 BB FF 00 03 00 08 07 00 4B 07 00 4B 07 00 19 07 00 1B 07 00 2F 07 00 2F 01 01 00 02 01 01 45 07 00 BB 03 4E 07 00 BB 43 01 4A 07 00 BB FF 00 03 00 08 07 00 4B 07 00 4B 07 00 19 07 00 1B 07 00 2F 07 00 2F 01 01 00 02 01 01 50 07 00 BB 43 01 25 03 FF 00 0A 00 04 07 00 4B 07 00 4B 07 00 19 07 00 1B 00 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  13     26     29     33     Ljava/lang/RuntimeException;
        //  100    113    116    120    Ljava/lang/RuntimeException;
        //  109    123    126    130    Ljava/lang/RuntimeException;
        //  120    146    149    153    Ljava/lang/RuntimeException;
        //  173    197    200    204    Ljava/lang/RuntimeException;
        //  193    207    210    214    Ljava/lang/RuntimeException;
        //  204    226    229    233    Ljava/lang/RuntimeException;
        //  214    241    244    248    Ljava/lang/RuntimeException;
        //  248    262    265    269    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0120:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        subColMasks = new int[] { 128, 64, 32, 16, 8, 4, 2, 1 };
        COMPARATOR = new RasterRangesUtils$1();
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
