// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.peer.ComponentPeer;
import java.awt.Window;

class WindowUtils$MacWindowUtils$1 implements Runnable
{
    final Window val$w;
    final float val$alpha;
    final WindowUtils$MacWindowUtils this$0;
    private static final String a;
    
    WindowUtils$MacWindowUtils$1(final WindowUtils$MacWindowUtils this$0, final Window val$w, final float val$alpha) {
        this.this$0 = this$0;
        this.val$w = val$w;
        this.val$alpha = val$alpha;
    }
    
    @Override
    public void run() {
        final ComponentPeer peer = this.val$w.getPeer();
        try {
            peer.getClass().getMethod(WindowUtils$MacWindowUtils$1.a, Float.TYPE).invoke(peer, this.val$alpha);
        }
        catch (Exception ex) {}
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 25);
        final char[] charArray = "3b:\u0017I\u0015\u0000!".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 89;
                            break;
                        }
                        case 1: {
                            n5 = 30;
                            break;
                        }
                        case 2: {
                            n5 = 87;
                            break;
                        }
                        case 3: {
                            n5 = 79;
                            break;
                        }
                        case 4: {
                            n5 = 60;
                            break;
                        }
                        case 5: {
                            n5 = 124;
                            break;
                        }
                        default: {
                            n5 = 113;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
