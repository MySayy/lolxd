// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import javax.swing.JRootPane;
import com.sun.jna.platform.win32.WinDef$HWND;
import com.sun.jna.Structure;
import javax.swing.JLayeredPane;
import javax.swing.JComponent;
import java.awt.Container;
import javax.swing.RootPaneContainer;
import java.awt.Component;
import com.sun.jna.platform.win32.User32;
import java.awt.Window;

class WindowUtils$W32WindowUtils$2 implements Runnable
{
    final Window val$w;
    final boolean val$transparent;
    final WindowUtils$W32WindowUtils this$0;
    
    WindowUtils$W32WindowUtils$2(final WindowUtils$W32WindowUtils this$0, final Window val$w, final boolean val$transparent) {
        this.this$0 = this$0;
        this.val$w = val$w;
        this.val$transparent = val$transparent;
    }
    
    @Override
    public void run() {
        final int[] b = WindowUtils$NativeWindowUtils.b();
        final User32 instance = User32.INSTANCE;
        final int[] array = b;
        final WinDef$HWND access$400 = WindowUtils$W32WindowUtils.access$400(this.this$0, this.val$w);
        int getWindowLong = instance.GetWindowLong(access$400, -20);
        final JRootPane rootPane = ((RootPaneContainer)this.val$w).getRootPane();
        final JLayeredPane layeredPane = rootPane.getLayeredPane();
        final Container contentPane = rootPane.getContentPane();
        Label_0385: {
            WindowUtils$W32WindowUtils windowUtils$W32WindowUtils = null;
            Window window = null;
            boolean val$transparent3 = false;
            Label_0384: {
                Label_0370: {
                    Label_0351: {
                    Label_0293_Outer:
                        while (true) {
                            WindowUtils$W32WindowUtils$2 windowUtils$W32WindowUtils$2 = null;
                            Label_0340: {
                                while (true) {
                                    Label_0305: {
                                        WindowUtils$W32WindowUtils windowUtils$W32WindowUtils2 = null;
                                        Window window2 = null;
                                        Label_0258: {
                                            boolean val$transparent2 = false;
                                            while (true) {
                                                Label_0235: {
                                                    boolean b4 = false;
                                                    Label_0187: {
                                                        boolean val$transparent = false;
                                                        Label_0173: {
                                                            Label_0169: {
                                                                Label_0116: {
                                                                    boolean b2 = false;
                                                                    Label_0105: {
                                                                        Label_0079: {
                                                                            WindowUtils$W32WindowUtils$W32TransparentContentPane windowUtils$W32WindowUtils$W32TransparentContentPane;
                                                                            try {
                                                                                final Container container;
                                                                                windowUtils$W32WindowUtils$W32TransparentContentPane = (WindowUtils$W32WindowUtils$W32TransparentContentPane)(container = contentPane);
                                                                                if (array != null) {
                                                                                    break Label_0105;
                                                                                }
                                                                                final boolean b3;
                                                                                b2 = (b3 = (val$transparent = (val$transparent2 = (windowUtils$W32WindowUtils$W32TransparentContentPane instanceof WindowUtils$W32WindowUtils$W32TransparentContentPane))));
                                                                                final int[] array2 = array;
                                                                                if (array2 == null) {
                                                                                    break Label_0079;
                                                                                }
                                                                                break Label_0116;
                                                                            }
                                                                            catch (RuntimeException ex) {
                                                                                throw b(ex);
                                                                            }
                                                                            try {
                                                                                final boolean b3;
                                                                                b2 = (b3 = (val$transparent = (val$transparent2 = (windowUtils$W32WindowUtils$W32TransparentContentPane instanceof WindowUtils$W32WindowUtils$W32TransparentContentPane))));
                                                                                final int[] array2 = array;
                                                                                if (array2 != null) {
                                                                                    break Label_0116;
                                                                                }
                                                                                if (!b3) {
                                                                                    break Label_0105;
                                                                                }
                                                                            }
                                                                            catch (RuntimeException ex2) {
                                                                                throw b(ex2);
                                                                            }
                                                                        }
                                                                        Container container = contentPane;
                                                                        try {
                                                                            ((WindowUtils$W32WindowUtils$W32TransparentContentPane)container).setTransparent(this.val$transparent);
                                                                            if (array == null) {
                                                                                break Label_0169;
                                                                            }
                                                                            val$transparent = (b2 = (val$transparent2 = this.val$transparent));
                                                                        }
                                                                        catch (RuntimeException ex3) {
                                                                            throw b(ex3);
                                                                        }
                                                                    }
                                                                    try {
                                                                        if (array != null) {
                                                                            break Label_0173;
                                                                        }
                                                                        if (!b2) {
                                                                            break Label_0169;
                                                                        }
                                                                    }
                                                                    catch (RuntimeException ex4) {
                                                                        throw b(ex4);
                                                                    }
                                                                }
                                                                final WindowUtils$W32WindowUtils$W32TransparentContentPane contentPane2 = new WindowUtils$W32WindowUtils$W32TransparentContentPane(this.this$0, contentPane);
                                                                rootPane.setContentPane(contentPane2);
                                                                layeredPane.add(new WindowUtils$RepaintTrigger(contentPane2), JLayeredPane.DRAG_LAYER);
                                                            }
                                                            val$transparent2 = (val$transparent = this.val$transparent);
                                                            try {
                                                                if (array != null) {
                                                                    break Label_0258;
                                                                }
                                                                if (val$transparent) {
                                                                    break Label_0187;
                                                                }
                                                                break Label_0235;
                                                            }
                                                            catch (RuntimeException ex5) {
                                                                throw b(ex5);
                                                            }
                                                        }
                                                        try {
                                                            if (!val$transparent) {
                                                                break Label_0235;
                                                            }
                                                            val$transparent2 = (b4 = WindowUtils$W32WindowUtils.access$500(this.this$0, this.val$w));
                                                        }
                                                        catch (RuntimeException ex6) {
                                                            throw b(ex6);
                                                        }
                                                    }
                                                    while (true) {
                                                        if (array != null) {
                                                            break Label_0258;
                                                        }
                                                        if (b4) {
                                                            break Label_0235;
                                                        }
                                                        getWindowLong |= 0x80000;
                                                        instance.SetWindowLong(access$400, -20, getWindowLong);
                                                        if (array == null) {
                                                            break Label_0305;
                                                        }
                                                        try {
                                                            windowUtils$W32WindowUtils$2 = this;
                                                            if (array != null) {
                                                                break Label_0340;
                                                            }
                                                            val$transparent2 = (b4 = this.val$transparent);
                                                            if (array != null) {
                                                                continue Label_0293_Outer;
                                                            }
                                                        }
                                                        catch (RuntimeException ex7) {
                                                            throw b(ex7);
                                                        }
                                                        break;
                                                    }
                                                }
                                                if (array != null) {
                                                    continue Label_0293_Outer;
                                                }
                                                break;
                                            }
                                            try {
                                                if (val$transparent2) {
                                                    break Label_0305;
                                                }
                                                windowUtils$W32WindowUtils = (windowUtils$W32WindowUtils2 = this.this$0);
                                                window = (window2 = this.val$w);
                                            }
                                            catch (RuntimeException ex8) {
                                                throw b(ex8);
                                            }
                                        }
                                        if (array != null) {
                                            break Label_0351;
                                        }
                                        if (!WindowUtils$W32WindowUtils.access$500(windowUtils$W32WindowUtils2, window2)) {
                                            break Label_0305;
                                        }
                                        getWindowLong &= 0xFFF7FFFF;
                                        instance.SetWindowLong(access$400, -20, getWindowLong);
                                    }
                                    this.this$0.setLayersTransparent(this.val$w, this.val$transparent);
                                    this.this$0.setForceHeavyweightPopups(this.val$w, this.val$transparent);
                                    if (array != null) {
                                        continue;
                                    }
                                    break;
                                }
                                windowUtils$W32WindowUtils$2 = this;
                            }
                            WindowUtils$W32WindowUtils windowUtils$W32WindowUtils2;
                            windowUtils$W32WindowUtils = (windowUtils$W32WindowUtils2 = windowUtils$W32WindowUtils$2.this$0);
                            Window window2;
                            window = (window2 = this.val$w);
                            if (array != null) {
                                continue;
                            }
                            break;
                        }
                        try {
                            val$transparent3 = this.val$transparent;
                            if (array != null) {
                                break Label_0370;
                            }
                            final int[] array3 = array;
                            if (array3 == null) {
                                break Label_0370;
                            }
                            break Label_0370;
                        }
                        catch (RuntimeException ex9) {
                            throw b(ex9);
                        }
                    }
                    try {
                        final int[] array3 = array;
                        if (array3 != null) {
                            break Label_0370;
                        }
                        if (val$transparent3) {
                            break Label_0384;
                        }
                    }
                    catch (RuntimeException ex10) {
                        throw b(ex10);
                    }
                }
                break Label_0385;
            }
            try {
                windowUtils$W32WindowUtils.setDoubleBuffered(window, val$transparent3);
                if (Structure.a() == 0) {
                    WindowUtils$NativeWindowUtils.b(new int[3]);
                }
            }
            catch (RuntimeException ex11) {
                throw b(ex11);
            }
        }
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
