// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import com.sun.jna.platform.unix.X11$XImage;
import java.awt.image.Raster;
import com.sun.jna.platform.unix.X11$GC;
import com.sun.jna.platform.unix.X11$Window;
import com.sun.jna.platform.unix.X11$Display;
import java.awt.Window;
import com.sun.jna.Pointer;
import com.sun.jna.platform.unix.X11$XWindowAttributes;
import com.sun.jna.Structure;
import com.sun.jna.platform.unix.X11$XGCValues;
import com.sun.jna.platform.unix.X11$Drawable;
import com.sun.jna.NativeLong;
import java.awt.Point;
import com.sun.jna.platform.unix.X11;
import java.awt.Component;
import javax.swing.SwingUtilities;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.Container;
import com.sun.jna.Memory;

class WindowUtils$X11WindowUtils$X11TransparentContentPane extends WindowUtils$NativeWindowUtils$TransparentContentPane
{
    private static final long serialVersionUID = 1L;
    private Memory buffer;
    private int[] pixels;
    private final int[] pixel;
    final WindowUtils$X11WindowUtils this$0;
    
    public WindowUtils$X11WindowUtils$X11TransparentContentPane(final WindowUtils$X11WindowUtils this$0, final Container container) {
        super(this.this$0 = this$0, container);
        this.pixel = new int[4];
    }
    
    @Override
    protected void paintDirect(final BufferedImage bufferedImage, final Rectangle rectangle) {
        final Window windowAncestor = SwingUtilities.getWindowAncestor(this);
        final int[] b = WindowUtils$NativeWindowUtils.b();
        final X11 instance = X11.INSTANCE;
        final X11$Display xOpenDisplay = instance.XOpenDisplay(null);
        final int[] array = b;
        final X11$Window access$800 = WindowUtils$X11WindowUtils.access$800(windowAncestor);
        final Point point = new Point();
        final X11$Window access$801 = WindowUtils$X11WindowUtils.access$900(windowAncestor, xOpenDisplay, access$800, point);
        final X11$GC xCreateGC = instance.XCreateGC(xOpenDisplay, access$801, new NativeLong(0L), null);
        final Raster data = bufferedImage.getData();
        final int width = rectangle.width;
        final int height = rectangle.height;
        long n2 = 0L;
        Label_0195: {
            Label_0194: {
                WindowUtils$X11WindowUtils$X11TransparentContentPane windowUtils$X11WindowUtils$X11TransparentContentPane = null;
                Label_0153: {
                    WindowUtils$X11WindowUtils$X11TransparentContentPane windowUtils$X11WindowUtils$X11TransparentContentPane2 = null;
                    Label_0112: {
                        try {
                            windowUtils$X11WindowUtils$X11TransparentContentPane = this;
                            if (array != null) {
                                break Label_0153;
                            }
                            final Memory memory = this.buffer;
                            if (memory != null) {
                                break Label_0112;
                            }
                            break Label_0153;
                        }
                        catch (RuntimeException ex) {
                            throw c(ex);
                        }
                        try {
                            final Memory memory = this.buffer;
                            if (memory == null) {
                                break Label_0153;
                            }
                            windowUtils$X11WindowUtils$X11TransparentContentPane = this;
                            windowUtils$X11WindowUtils$X11TransparentContentPane2 = this;
                        }
                        catch (RuntimeException ex2) {
                            throw c(ex2);
                        }
                    }
                    while (true) {
                        if (array != null) {
                            break Label_0153;
                        }
                        long n;
                        try {
                            n = (n2 = lcmp(windowUtils$X11WindowUtils$X11TransparentContentPane2.buffer.size(), (long)(width * height * 4)));
                            if (array != null) {
                                break Label_0195;
                            }
                            if (n != 0) {
                                break Label_0153;
                            }
                            break Label_0194;
                        }
                        catch (RuntimeException ex3) {
                            throw c(ex3);
                        }
                        try {
                            if (n == 0) {
                                break Label_0194;
                            }
                            this.buffer = new Memory(width * height * 4);
                            windowUtils$X11WindowUtils$X11TransparentContentPane = this;
                            windowUtils$X11WindowUtils$X11TransparentContentPane2 = this;
                            if (array != null) {
                                continue;
                            }
                        }
                        catch (RuntimeException ex4) {
                            throw c(ex4);
                        }
                        break;
                    }
                }
                windowUtils$X11WindowUtils$X11TransparentContentPane.pixels = new int[width * height];
            }
            n2 = 0;
        }
        long y = n2;
    Label_0343_Outer:
        while (y < height) {
            int i = 0;
        Label_0343:
            while (true) {
                while (i < width) {
                    data.getPixel(i, (int)y, this.pixel);
                    final int n3 = this.pixel[3] & 0xFF;
                    final int n4 = this.pixel[2] & 0xFF;
                    final int n5 = this.pixel[1] & 0xFF;
                    final int n6 = this.pixel[0] & 0xFF;
                    try {
                        this.pixels[y * width + i] = (n3 << 24 | n6 << 16 | n5 << 8 | n4);
                        ++i;
                        if (array != null) {
                            break Label_0343;
                        }
                        if (array == null) {
                            continue Label_0343_Outer;
                        }
                    }
                    catch (RuntimeException ex5) {
                        throw c(ex5);
                    }
                    int b2 = Structure.b();
                    Structure.b(++b2);
                    break;
                    if (array != null) {
                        break Label_0343_Outer;
                    }
                    continue Label_0343_Outer;
                }
                ++y;
                continue Label_0343;
            }
        }
        final X11$XWindowAttributes x11$XWindowAttributes = new X11$XWindowAttributes();
        instance.XGetWindowAttributes(xOpenDisplay, access$801, x11$XWindowAttributes);
        final X11$XImage xCreateImage = instance.XCreateImage(xOpenDisplay, x11$XWindowAttributes.visual, 32, 2, 0, this.buffer, width, height, 32, width * 4);
        this.buffer.write(0L, this.pixels, 0, this.pixels.length);
        final Point point2 = point;
        point2.x += rectangle.x;
        final Point point3 = point;
        point3.y += rectangle.y;
        instance.XPutImage(xOpenDisplay, access$801, xCreateGC, xCreateImage, 0, 0, point.x, point.y, width, height);
        instance.XFree(xCreateImage.getPointer());
        instance.XFreeGC(xOpenDisplay, xCreateGC);
        instance.XCloseDisplay(xOpenDisplay);
    }
    
    private static RuntimeException c(final RuntimeException ex) {
        return ex;
    }
}
