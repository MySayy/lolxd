// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.util.Collection;
import java.util.Iterator;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.io.File;
import java.util.Map;

public abstract class FileMonitor
{
    public static final int FILE_CREATED = 1;
    public static final int FILE_DELETED = 2;
    public static final int FILE_MODIFIED = 4;
    public static final int FILE_ACCESSED = 8;
    public static final int FILE_NAME_CHANGED_OLD = 16;
    public static final int FILE_NAME_CHANGED_NEW = 32;
    public static final int FILE_RENAMED = 48;
    public static final int FILE_SIZE_CHANGED = 64;
    public static final int FILE_ATTRIBUTES_CHANGED = 128;
    public static final int FILE_SECURITY_CHANGED = 256;
    public static final int FILE_ANY = 511;
    private final Map<File, Integer> watched;
    private List<FileMonitor$FileListener> listeners;
    
    public FileMonitor() {
        this.watched = new HashMap<File, Integer>();
        this.listeners = new ArrayList<FileMonitor$FileListener>();
    }
    
    protected abstract void watch(final File p0, final int p1, final boolean p2) throws IOException;
    
    protected abstract void unwatch(final File p0);
    
    public abstract void dispose();
    
    public void addWatch(final File file) throws IOException {
        this.addWatch(file, 511);
    }
    
    public void addWatch(final File file, final int n) throws IOException {
        this.addWatch(file, n, file.isDirectory());
    }
    
    public void addWatch(final File file, final int i, final boolean b) throws IOException {
        this.watched.put(file, i);
        this.watch(file, i, b);
    }
    
    public void removeWatch(final File p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_0        
        //     5: aload_2        
        //     6: ifnonnull       47
        //     9: aload_2        
        //    10: ifnonnull       47
        //    13: goto            20
        //    16: invokestatic    com/sun/jna/platform/FileMonitor.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    19: athrow         
        //    20: getfield        com/sun/jna/platform/FileMonitor.watched:Ljava/util/Map;
        //    23: aload_1        
        //    24: invokeinterface java/util/Map.remove:(Ljava/lang/Object;)Ljava/lang/Object;
        //    29: ifnull          51
        //    32: goto            39
        //    35: invokestatic    com/sun/jna/platform/FileMonitor.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    38: athrow         
        //    39: aload_0        
        //    40: goto            47
        //    43: invokestatic    com/sun/jna/platform/FileMonitor.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    46: athrow         
        //    47: aload_1        
        //    48: invokevirtual   com/sun/jna/platform/FileMonitor.unwatch:(Ljava/io/File;)V
        //    51: return         
        //    StackMapTable: 00 07 FF 00 10 00 03 07 00 01 07 00 1B 07 00 A2 00 01 07 00 9D 43 07 00 01 4E 07 00 9D 03 43 07 00 9D 43 07 00 01 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      13     16     20     Ljava/lang/RuntimeException;
        //  9      32     35     39     Ljava/lang/RuntimeException;
        //  20     40     43     47     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    protected void notify(final FileMonitor$FileEvent fileMonitor$FileEvent) {
        final int[] b = WindowUtils$NativeWindowUtils.b();
        final Iterator<FileMonitor$FileListener> iterator = this.listeners.iterator();
        final int[] array = b;
        while (iterator.hasNext()) {
            iterator.next().fileChanged(fileMonitor$FileEvent);
            if (array != null) {
                break;
            }
        }
    }
    
    public synchronized void addFileListener(final FileMonitor$FileListener fileMonitor$FileListener) {
        final ArrayList<FileMonitor$FileListener> listeners = new ArrayList<FileMonitor$FileListener>(this.listeners);
        listeners.add(fileMonitor$FileListener);
        this.listeners = listeners;
    }
    
    public synchronized void removeFileListener(final FileMonitor$FileListener fileMonitor$FileListener) {
        final ArrayList<FileMonitor$FileListener> listeners = new ArrayList<FileMonitor$FileListener>(this.listeners);
        listeners.remove(fileMonitor$FileListener);
        this.listeners = listeners;
    }
    
    @Override
    protected void finalize() {
        final int[] b = WindowUtils$NativeWindowUtils.b();
        final Iterator<File> iterator = this.watched.keySet().iterator();
        final int[] array = b;
        while (iterator.hasNext()) {
            final File file = iterator.next();
            try {
                this.removeWatch(file);
                if (array != null) {
                    return;
                }
                if (array == null) {
                    continue;
                }
            }
            catch (RuntimeException ex) {
                throw b(ex);
            }
            break;
        }
        this.dispose();
    }
    
    public static FileMonitor getInstance() {
        return FileMonitor$Holder.INSTANCE;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
