// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

abstract class KeyboardUtils$NativeKeyboardUtils
{
    private KeyboardUtils$NativeKeyboardUtils() {
    }
    
    public abstract boolean isPressed(final int p0, final int p1);
    
    public boolean isPressed(final int n) {
        return this.isPressed(n, 0);
    }
    
    KeyboardUtils$NativeKeyboardUtils(final KeyboardUtils$1 keyboardUtils$1) {
        this();
    }
}
