// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

class KeyboardUtils$X11KeyboardUtils extends KeyboardUtils$NativeKeyboardUtils
{
    private static final String a;
    
    private KeyboardUtils$X11KeyboardUtils() {
        super(null);
    }
    
    private int toKeySym(final int n, final int n2) {
        final int[] b = WindowUtils$NativeWindowUtils.b();
        int n34;
        while (true) {
            Label_0335: {
                int n36 = 0;
                int n35 = 0;
                Label_0298: {
                    int n3 = 0;
                    int n13 = 0;
                    Label_0279: {
                        int n30 = 0;
                        int n31 = 0;
                        Label_0245: {
                            int n4 = 0;
                            int n12 = 0;
                            Label_0231: {
                                while (true) {
                                    Label_0224: {
                                        int n26 = 0;
                                        int n27 = 0;
                                        Label_0190: {
                                            int n5 = 0;
                                            int n11 = 0;
                                            Label_0176: {
                                                while (true) {
                                                    Label_0169: {
                                                        int n22 = 0;
                                                        int n23 = 0;
                                                        Label_0135: {
                                                            int n6 = 0;
                                                            int n10 = 0;
                                                            Label_0121: {
                                                                int n20;
                                                                int n21;
                                                                while (true) {
                                                                    Label_0110: {
                                                                        int n18 = 0;
                                                                        int n19 = 0;
                                                                        Label_0078: {
                                                                            int n7 = 0;
                                                                            int n9 = 0;
                                                                            Label_0064: {
                                                                                int n16;
                                                                                int n17;
                                                                                while (true) {
                                                                                    Label_0053: {
                                                                                        int n14 = 0;
                                                                                        int n15 = 0;
                                                                                        Label_0021: {
                                                                                            int n8;
                                                                                            try {
                                                                                                n3 = n;
                                                                                                n4 = n;
                                                                                                n5 = n;
                                                                                                n6 = n;
                                                                                                n7 = n;
                                                                                                n8 = (n9 = (n10 = (n11 = (n12 = (n13 = 65)))));
                                                                                                if (b != null) {
                                                                                                    break Label_0064;
                                                                                                }
                                                                                                if (n >= n8) {
                                                                                                    break Label_0021;
                                                                                                }
                                                                                                break Label_0053;
                                                                                            }
                                                                                            catch (RuntimeException ex) {
                                                                                                throw b(ex);
                                                                                            }
                                                                                            try {
                                                                                                if (n < n8) {
                                                                                                    break Label_0053;
                                                                                                }
                                                                                                n3 = n;
                                                                                                n4 = n;
                                                                                                n5 = n;
                                                                                                n6 = n;
                                                                                                n7 = n;
                                                                                                n14 = n;
                                                                                                n9 = (n15 = (n10 = (n11 = (n12 = (n13 = 90)))));
                                                                                            }
                                                                                            catch (RuntimeException ex2) {
                                                                                                throw b(ex2);
                                                                                            }
                                                                                        }
                                                                                        if (b != null) {
                                                                                            break Label_0064;
                                                                                        }
                                                                                        try {
                                                                                            if (n14 > n15) {
                                                                                                break Label_0053;
                                                                                            }
                                                                                            n16 = 97;
                                                                                            n17 = n - 65;
                                                                                        }
                                                                                        catch (RuntimeException ex3) {
                                                                                            throw b(ex3);
                                                                                        }
                                                                                        return n16 + n17;
                                                                                    }
                                                                                    n3 = n;
                                                                                    n4 = n;
                                                                                    n5 = n;
                                                                                    n6 = n;
                                                                                    n7 = n;
                                                                                    n16 = n;
                                                                                    int n14 = n;
                                                                                    int n15;
                                                                                    n17 = (n15 = (n9 = (n10 = (n11 = (n12 = (n13 = 48))))));
                                                                                    if (b != null) {
                                                                                        continue;
                                                                                    }
                                                                                    break;
                                                                                }
                                                                                if (b != null) {
                                                                                    return n16 + n17;
                                                                                }
                                                                                try {
                                                                                    if (b != null) {
                                                                                        break Label_0121;
                                                                                    }
                                                                                    if (n7 >= n9) {
                                                                                        break Label_0078;
                                                                                    }
                                                                                    break Label_0110;
                                                                                }
                                                                                catch (RuntimeException ex4) {
                                                                                    throw b(ex4);
                                                                                }
                                                                            }
                                                                            try {
                                                                                if (n7 < n9) {
                                                                                    break Label_0110;
                                                                                }
                                                                                n3 = n;
                                                                                n4 = n;
                                                                                n5 = n;
                                                                                n6 = n;
                                                                                n18 = n;
                                                                                n10 = (n19 = (n11 = (n12 = (n13 = 57))));
                                                                            }
                                                                            catch (RuntimeException ex5) {
                                                                                throw b(ex5);
                                                                            }
                                                                        }
                                                                        if (b != null) {
                                                                            break Label_0121;
                                                                        }
                                                                        try {
                                                                            if (n18 > n19) {
                                                                                break Label_0110;
                                                                            }
                                                                            n20 = 48;
                                                                            n21 = n - 48;
                                                                        }
                                                                        catch (RuntimeException ex6) {
                                                                            throw b(ex6);
                                                                        }
                                                                        return n20 + n21;
                                                                    }
                                                                    n3 = n;
                                                                    n4 = n;
                                                                    n5 = n;
                                                                    n6 = n;
                                                                    n20 = n;
                                                                    int n18 = n;
                                                                    int n19;
                                                                    n21 = (n19 = (n10 = (n11 = (n12 = (n13 = 16)))));
                                                                    if (b != null) {
                                                                        continue;
                                                                    }
                                                                    break;
                                                                }
                                                                if (b != null) {
                                                                    return n20 + n21;
                                                                }
                                                                try {
                                                                    if (b != null) {
                                                                        break Label_0176;
                                                                    }
                                                                    if (n6 == n10) {
                                                                        break Label_0135;
                                                                    }
                                                                    break Label_0169;
                                                                }
                                                                catch (RuntimeException ex7) {
                                                                    throw b(ex7);
                                                                }
                                                            }
                                                            try {
                                                                if (n6 != n10) {
                                                                    break Label_0169;
                                                                }
                                                                n22 = n2;
                                                                n23 = 3;
                                                            }
                                                            catch (RuntimeException ex8) {
                                                                throw b(ex8);
                                                            }
                                                        }
                                                        int n24 = 0;
                                                        Label_0162: {
                                                            try {
                                                                n24 = (n22 & n23);
                                                                if (b != null) {
                                                                    return n24;
                                                                }
                                                                if (n24 == 0) {
                                                                    break Label_0162;
                                                                }
                                                            }
                                                            catch (RuntimeException ex9) {
                                                                throw b(ex9);
                                                            }
                                                            return 65505;
                                                        }
                                                        final int n25 = 65505;
                                                        if (b != null) {
                                                            return n25;
                                                        }
                                                        return n24;
                                                    }
                                                    n3 = n;
                                                    n4 = n;
                                                    n5 = n;
                                                    int n22 = n;
                                                    int n23;
                                                    n11 = (n23 = (n12 = (n13 = 17)));
                                                    if (b != null) {
                                                        continue;
                                                    }
                                                    break;
                                                }
                                                try {
                                                    if (b != null) {
                                                        break Label_0231;
                                                    }
                                                    if (n5 == n11) {
                                                        break Label_0190;
                                                    }
                                                    break Label_0224;
                                                }
                                                catch (RuntimeException ex10) {
                                                    throw b(ex10);
                                                }
                                            }
                                            try {
                                                if (n5 != n11) {
                                                    break Label_0224;
                                                }
                                                n26 = n2;
                                                n27 = 3;
                                            }
                                            catch (RuntimeException ex11) {
                                                throw b(ex11);
                                            }
                                        }
                                        int n28 = 0;
                                        Label_0217: {
                                            try {
                                                n28 = (n26 & n27);
                                                if (b != null) {
                                                    return n28;
                                                }
                                                if (n28 == 0) {
                                                    break Label_0217;
                                                }
                                            }
                                            catch (RuntimeException ex12) {
                                                throw b(ex12);
                                            }
                                            return 65508;
                                        }
                                        final int n29 = 65507;
                                        if (b != null) {
                                            return n29;
                                        }
                                        return n28;
                                    }
                                    n3 = n;
                                    n4 = n;
                                    int n26 = n;
                                    int n27;
                                    n12 = (n27 = (n13 = 18));
                                    if (b != null) {
                                        continue;
                                    }
                                    break;
                                }
                                try {
                                    if (b != null) {
                                        break Label_0298;
                                    }
                                    if (n4 == n12) {
                                        break Label_0245;
                                    }
                                    break Label_0279;
                                }
                                catch (RuntimeException ex13) {
                                    throw b(ex13);
                                }
                            }
                            try {
                                if (n4 != n12) {
                                    break Label_0279;
                                }
                                n30 = n2;
                                n31 = 3;
                            }
                            catch (RuntimeException ex14) {
                                throw b(ex14);
                            }
                        }
                        while (true) {
                            int n32 = 0;
                            Label_0272: {
                                try {
                                    n32 = (n30 & n31);
                                    if (b != null) {
                                        return n32;
                                    }
                                    if (n32 == 0) {
                                        break Label_0272;
                                    }
                                }
                                catch (RuntimeException ex15) {
                                    throw b(ex15);
                                }
                                return 65514;
                            }
                            final int n33 = 65513;
                            if (b != null) {
                                return n33;
                            }
                            return n32;
                            try {
                                n34 = n;
                                n3 = n;
                                n30 = n;
                                if (b != null) {
                                    return n34;
                                }
                                n13 = (n31 = 157);
                                if (b != null) {
                                    continue;
                                }
                            }
                            catch (RuntimeException ex16) {
                                throw b(ex16);
                            }
                            break;
                        }
                    }
                    try {
                        if (n3 != n13) {
                            break Label_0335;
                        }
                        n35 = (n36 = (n2 & 0x3));
                    }
                    catch (RuntimeException ex17) {
                        throw b(ex17);
                    }
                }
                Label_0328: {
                    try {
                        if (b != null) {
                            return n35;
                        }
                        if (n36 == 0) {
                            break Label_0328;
                        }
                    }
                    catch (RuntimeException ex18) {
                        throw b(ex18);
                    }
                    return 65512;
                }
                int n37;
                n35 = (n37 = 65511);
                if (b != null) {
                    return n37;
                }
                return n35;
            }
            int n36;
            int n35 = n36 = (n34 = 0);
            if (b != null) {
                continue;
            }
            break;
        }
        return n34;
    }
    
    @Override
    public boolean isPressed(final int p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: getstatic       com/sun/jna/platform/unix/X11.INSTANCE:Lcom/sun/jna/platform/unix/X11;
        //     6: astore          4
        //     8: aload           4
        //    10: aconst_null    
        //    11: invokeinterface com/sun/jna/platform/unix/X11.XOpenDisplay:(Ljava/lang/String;)Lcom/sun/jna/platform/unix/X11$Display;
        //    16: astore          5
        //    18: astore_3       
        //    19: aload           5
        //    21: ifnonnull       39
        //    24: new             Ljava/lang/Error;
        //    27: dup            
        //    28: getstatic       com/sun/jna/platform/KeyboardUtils$X11KeyboardUtils.a:Ljava/lang/String;
        //    31: invokespecial   java/lang/Error.<init>:(Ljava/lang/String;)V
        //    34: athrow         
        //    35: invokestatic    com/sun/jna/platform/KeyboardUtils$X11KeyboardUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    38: athrow         
        //    39: bipush          32
        //    41: newarray        B
        //    43: astore          6
        //    45: aload           4
        //    47: aload           5
        //    49: aload           6
        //    51: invokeinterface com/sun/jna/platform/unix/X11.XQueryKeymap:(Lcom/sun/jna/platform/unix/X11$Display;[B)I
        //    56: pop            
        //    57: aload_0        
        //    58: iload_1        
        //    59: iload_2        
        //    60: invokespecial   com/sun/jna/platform/KeyboardUtils$X11KeyboardUtils.toKeySym:(II)I
        //    63: istore          7
        //    65: iconst_5       
        //    66: istore          8
        //    68: iload           8
        //    70: sipush          256
        //    73: if_icmpge       220
        //    76: iload           8
        //    78: bipush          8
        //    80: idiv           
        //    81: istore          9
        //    83: iload           8
        //    85: bipush          8
        //    87: irem           
        //    88: istore          10
        //    90: aload_3        
        //    91: ifnonnull       216
        //    94: aload           6
        //    96: iload           9
        //    98: baload         
        //    99: iconst_1       
        //   100: iload           10
        //   102: ishl           
        //   103: iand           
        //   104: aload_3        
        //   105: ifnonnull       229
        //   108: goto            115
        //   111: invokestatic    com/sun/jna/platform/KeyboardUtils$X11KeyboardUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   114: athrow         
        //   115: aload_3        
        //   116: ifnonnull       159
        //   119: goto            126
        //   122: invokestatic    com/sun/jna/platform/KeyboardUtils$X11KeyboardUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   125: athrow         
        //   126: ifeq            213
        //   129: goto            136
        //   132: invokestatic    com/sun/jna/platform/KeyboardUtils$X11KeyboardUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   135: athrow         
        //   136: aload           4
        //   138: aload           5
        //   140: iload           8
        //   142: i2b            
        //   143: iconst_0       
        //   144: invokeinterface com/sun/jna/platform/unix/X11.XKeycodeToKeysym:(Lcom/sun/jna/platform/unix/X11$Display;BI)Lcom/sun/jna/platform/unix/X11$KeySym;
        //   149: invokevirtual   com/sun/jna/platform/unix/X11$KeySym.intValue:()I
        //   152: goto            159
        //   155: invokestatic    com/sun/jna/platform/KeyboardUtils$X11KeyboardUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   158: athrow         
        //   159: istore          11
        //   161: aload_3        
        //   162: ifnonnull       216
        //   165: iload           11
        //   167: aload_3        
        //   168: ifnonnull       198
        //   171: goto            178
        //   174: invokestatic    com/sun/jna/platform/KeyboardUtils$X11KeyboardUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   177: athrow         
        //   178: iload           7
        //   180: if_icmpne       213
        //   183: goto            190
        //   186: invokestatic    com/sun/jna/platform/KeyboardUtils$X11KeyboardUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   189: athrow         
        //   190: iconst_1       
        //   191: goto            198
        //   194: invokestatic    com/sun/jna/platform/KeyboardUtils$X11KeyboardUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   197: athrow         
        //   198: istore          12
        //   200: aload           4
        //   202: aload           5
        //   204: invokeinterface com/sun/jna/platform/unix/X11.XCloseDisplay:(Lcom/sun/jna/platform/unix/X11$Display;)I
        //   209: pop            
        //   210: iload           12
        //   212: ireturn        
        //   213: iinc            8, 1
        //   216: aload_3        
        //   217: ifnull          68
        //   220: aload           4
        //   222: aload           5
        //   224: invokeinterface com/sun/jna/platform/unix/X11.XCloseDisplay:(Lcom/sun/jna/platform/unix/X11$Display;)I
        //   229: pop            
        //   230: goto            248
        //   233: astore          13
        //   235: aload           4
        //   237: aload           5
        //   239: invokeinterface com/sun/jna/platform/unix/X11.XCloseDisplay:(Lcom/sun/jna/platform/unix/X11$Display;)I
        //   244: pop            
        //   245: aload           13
        //   247: athrow         
        //   248: iconst_0       
        //   249: ireturn        
        //    StackMapTable: 00 17 FF 00 23 00 06 07 00 16 01 01 07 00 65 07 00 0C 07 00 23 00 01 07 00 4E 03 FE 00 1C 07 00 24 01 01 FF 00 2A 00 0B 07 00 16 01 01 07 00 65 07 00 0C 07 00 23 07 00 24 01 01 01 01 00 01 07 00 4E 43 01 46 07 00 4E 43 01 45 07 00 4E 03 52 07 00 4E 43 01 FF 00 0E 00 0C 07 00 16 01 01 07 00 65 07 00 0C 07 00 23 07 00 24 01 01 01 01 01 00 01 07 00 4E 43 01 47 07 00 4E 03 43 07 00 4E 43 01 FA 00 0E 02 F9 00 03 48 01 FF 00 03 00 06 07 00 16 01 01 07 00 65 07 00 0C 07 00 23 00 01 07 00 25 0E
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  178    191    194    198    Ljava/lang/RuntimeException;
        //  165    183    186    190    Ljava/lang/RuntimeException;
        //  161    171    174    178    Ljava/lang/RuntimeException;
        //  126    152    155    159    Ljava/lang/RuntimeException;
        //  115    129    132    136    Ljava/lang/RuntimeException;
        //  94     119    122    126    Ljava/lang/RuntimeException;
        //  90     108    111    115    Ljava/lang/RuntimeException;
        //  19     35     35     39     Ljava/lang/RuntimeException;
        //  39     200    233    248    Any
        //  213    220    233    248    Any
        //  233    235    233    248    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0115:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    KeyboardUtils$X11KeyboardUtils(final KeyboardUtils$1 keyboardUtils$1) {
        this();
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 17);
        final char[] charArray = "\u007f_ !\u0014x/L[ &8x\u0004UM>j\u0001!".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 45;
                            break;
                        }
                        case 1: {
                            n5 = 47;
                            break;
                        }
                        case 2: {
                            n5 = 95;
                            break;
                        }
                        case 3: {
                            n5 = 23;
                            break;
                        }
                        case 4: {
                            n5 = 113;
                            break;
                        }
                        case 5: {
                            n5 = 73;
                            break;
                        }
                        default: {
                            n5 = 81;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
