// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.Window;
import com.sun.jna.platform.win32.WinDef$HWND;
import com.sun.jna.platform.win32.WinNT$HANDLE;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.GDI32;
import com.sun.jna.platform.win32.WinDef$HRGN;
import java.awt.Component;

class WindowUtils$W32WindowUtils$3 implements Runnable
{
    final Component val$w;
    final WinDef$HRGN val$hrgn;
    final WindowUtils$W32WindowUtils this$0;
    
    WindowUtils$W32WindowUtils$3(final WindowUtils$W32WindowUtils this$0, final Component val$w, final WinDef$HRGN val$hrgn) {
        this.this$0 = this$0;
        this.val$w = val$w;
        this.val$hrgn = val$hrgn;
    }
    
    @Override
    public void run() {
        final GDI32 instance = GDI32.INSTANCE;
        final User32 instance2 = User32.INSTANCE;
        final WinDef$HWND access$400 = WindowUtils$W32WindowUtils.access$400(this.this$0, this.val$w);
        try {
            WindowUtils$W32WindowUtils this$0 = null;
            Window window = null;
            boolean b = false;
            Label_0064: {
                try {
                    instance2.SetWindowRgn(access$400, this.val$hrgn, true);
                    this$0 = this.this$0;
                    window = this.this$0.getWindow(this.val$w);
                    if (this.val$hrgn != null) {
                        b = true;
                        break Label_0064;
                    }
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                b = false;
            }
            this$0.setForceHeavyweightPopups(window, b);
        }
        finally {
            instance.DeleteObject(this.val$hrgn);
        }
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
