// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.Composite;
import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Shape;
import javax.swing.JPanel;

class WindowUtils$MacWindowUtils$OSXMaskingContentPane extends JPanel
{
    private static final long serialVersionUID = 1L;
    private Shape shape;
    private static final String a;
    
    public WindowUtils$MacWindowUtils$OSXMaskingContentPane(final Component comp) {
        super(new BorderLayout());
        if (comp != null) {
            this.add(comp, WindowUtils$MacWindowUtils$OSXMaskingContentPane.a);
        }
    }
    
    public void setMask(final Shape shape) {
        this.shape = shape;
        this.repaint();
    }
    
    @Override
    public void paint(final Graphics g) {
        final int[] b = WindowUtils$NativeWindowUtils.b();
        Graphics2D g2 = (Graphics2D)g.create();
        final int[] array = b;
        WindowUtils$MacWindowUtils$OSXMaskingContentPane windowUtils$MacWindowUtils$OSXMaskingContentPane = null;
        Label_0089: {
            while (true) {
                Label_0084: {
                    try {
                        g2.setComposite(AlphaComposite.Clear);
                        g2.fillRect(0, 0, this.getWidth(), this.getHeight());
                        g2.dispose();
                        windowUtils$MacWindowUtils$OSXMaskingContentPane = this;
                        if (array != null) {
                            break Label_0089;
                        }
                        if (this.shape == null) {
                            break Label_0084;
                        }
                    }
                    catch (RuntimeException ex) {
                        throw b(ex);
                    }
                    g2 = (Graphics2D)g.create();
                    g2.setClip(this.shape);
                    final WindowUtils$MacWindowUtils$OSXMaskingContentPane windowUtils$MacWindowUtils$OSXMaskingContentPane2 = this;
                    windowUtils$MacWindowUtils$OSXMaskingContentPane2.paint(g2);
                    g2.dispose();
                    if (array == null) {
                        return;
                    }
                }
                windowUtils$MacWindowUtils$OSXMaskingContentPane = this;
                final WindowUtils$MacWindowUtils$OSXMaskingContentPane windowUtils$MacWindowUtils$OSXMaskingContentPane2 = this;
                if (array != null) {
                    continue;
                }
                break;
            }
        }
        windowUtils$MacWindowUtils$OSXMaskingContentPane.paint(g);
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 73);
        final char[] charArray = "b\u0004E\\a.".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 104;
                            break;
                        }
                        case 1: {
                            n5 = 40;
                            break;
                        }
                        case 2: {
                            n5 = 98;
                            break;
                        }
                        case 3: {
                            n5 = 97;
                            break;
                        }
                        case 4: {
                            n5 = 77;
                            break;
                        }
                        case 5: {
                            n5 = 21;
                            break;
                        }
                        default: {
                            n5 = 86;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
