// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.mac;

import com.sun.jna.Native;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.Library;

public interface MacFileUtils$FileManager extends Library
{
    public static final MacFileUtils$FileManager INSTANCE = Native.loadLibrary(new String(charArray).intern(), MacFileUtils$FileManager.class);
    public static final int kFSFileOperationDefaultOptions = 0;
    public static final int kFSFileOperationsOverwrite = 1;
    public static final int kFSFileOperationsSkipSourcePermissionErrors = 2;
    public static final int kFSFileOperationsDoNotMoveAcrossVolumes = 4;
    public static final int kFSFileOperationsSkipPreflight = 8;
    public static final int kFSPathDefaultOptions = 0;
    public static final int kFSPathMakeRefDoNotFollowLeafSymlink = 1;
    
    int FSRefMakePath(final MacFileUtils$FileManager$FSRef p0, final byte[] p1, final int p2);
    
    int FSPathMakeRef(final String p0, final int p1, final ByteByReference p2);
    
    int FSPathMakeRefWithOptions(final String p0, final int p1, final MacFileUtils$FileManager$FSRef p2, final ByteByReference p3);
    
    int FSPathMoveObjectToTrashSync(final String p0, final PointerByReference p1, final int p2);
    
    int FSMoveObjectToTrashSync(final MacFileUtils$FileManager$FSRef p0, final MacFileUtils$FileManager$FSRef p1, final int p2);
    
    default static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 26);
        final char[] charArray = "*A?ia?p\u001fG.iA".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 115;
                            break;
                        }
                        case 1: {
                            n5 = 52;
                            break;
                        }
                        case 2: {
                            n5 = 87;
                            break;
                        }
                        case 3: {
                            n5 = 22;
                            break;
                        }
                        case 4: {
                            n5 = 40;
                            break;
                        }
                        case 5: {
                            n5 = 64;
                            break;
                        }
                        default: {
                            n5 = 24;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                return;
            }
            continue;
        }
    }
}
