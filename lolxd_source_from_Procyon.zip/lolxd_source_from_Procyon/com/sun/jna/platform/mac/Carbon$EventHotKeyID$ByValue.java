// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.mac;

import com.sun.jna.Structure$ByValue;

public class Carbon$EventHotKeyID$ByValue extends Carbon$EventHotKeyID implements Structure$ByValue
{
}
