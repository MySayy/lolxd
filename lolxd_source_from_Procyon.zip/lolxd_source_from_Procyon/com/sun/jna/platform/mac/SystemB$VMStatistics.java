// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.mac;

import java.util.List;
import com.sun.jna.Structure;

public class SystemB$VMStatistics extends Structure
{
    public static final List<String> FIELDS;
    public int free_count;
    public int active_count;
    public int inactive_count;
    public int wire_count;
    public int zero_fill_count;
    public int reactivations;
    public int pageins;
    public int pageouts;
    public int faults;
    public int cow_faults;
    public int lookups;
    public int hits;
    public int purgeable_count;
    public int purges;
    public int speculative_count;
    
    @Override
    protected List<String> getFieldOrder() {
        return SystemB$VMStatistics.FIELDS;
    }
    
    static {
        final String[] array = new String[15];
        int n = 0;
        String s;
        int n2 = (s = "iO\u000f\u0013w(R\nzA\u001f)x'TuZ\u001b\u0004qG\u001c\u0005\u000ep@\t\u0015j/W|q\u000b\u0019k(U\n\u007f\\\r\u0013A%Nl@\u001c\rkK\t\u0015j/WxZ\u0001\u0019p5\nnG\u001a\u0013A%Nl@\u001c\u000fcK\u001a\u0019A HuB7\u0015q3Om\u0006i[\u001a\u0011{5\u000fi[\u001a\u0011{'CuK7\u0015q3Om\biO\u000f\u0013q3Uj\u0007uA\u0007\u001dk6R\u0006\u007fO\u001d\u001aj5").length();
        int n3 = 7;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 88));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0252: {
                            if (length > 1) {
                                break Label_0252;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 65;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 118;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 48;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 46;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 70;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 30;
                                        break;
                                    }
                                    default: {
                                        n11 = 121;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "bV\u0005\u001dc\"HeO\u0016\u001bI-FdH\u0014\fpE\u0014\u0017`+vrI\u0015\u0010b").length();
                            n3 = 17;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 80)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[4], array2[14], array2[3], array2[6], array2[7], array2[5], array2[0], array2[10], array2[12], array2[1], array2[11], array2[2], array2[9], array2[8], array2[13]);
    }
}
