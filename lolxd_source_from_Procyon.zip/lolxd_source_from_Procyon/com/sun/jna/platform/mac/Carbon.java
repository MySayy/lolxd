// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.mac;

import com.sun.jna.Native;
import java.nio.IntBuffer;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.Pointer;
import com.sun.jna.Library;

public interface Carbon extends Library
{
    public static final Carbon INSTANCE = Native.loadLibrary(new String(charArray).intern(), Carbon.class);
    public static final int cmdKey = 256;
    public static final int shiftKey = 512;
    public static final int optionKey = 2048;
    public static final int controlKey = 4096;
    
    Pointer GetEventDispatcherTarget();
    
    int InstallEventHandler(final Pointer p0, final Carbon$EventHandlerProcPtr p1, final int p2, final Carbon$EventTypeSpec[] p3, final Pointer p4, final PointerByReference p5);
    
    int RegisterEventHotKey(final int p0, final int p1, final Carbon$EventHotKeyID$ByValue p2, final Pointer p3, final int p4, final PointerByReference p5);
    
    int GetEventParameter(final Pointer p0, final int p1, final int p2, final Pointer p3, final int p4, final IntBuffer p5, final Carbon$EventHotKeyID p6);
    
    int RemoveEventHandler(final Pointer p0);
    
    int UnregisterEventHotKey(final Pointer p0);
    
    default static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 63);
        final char[] charArray = "*\u001a\u0010\"[\u0013".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 86;
                            break;
                        }
                        case 1: {
                            n5 = 68;
                            break;
                        }
                        case 2: {
                            n5 = 93;
                            break;
                        }
                        case 3: {
                            n5 = 127;
                            break;
                        }
                        case 4: {
                            n5 = 11;
                            break;
                        }
                        case 5: {
                            n5 = 66;
                            break;
                        }
                        default: {
                            n5 = 93;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                return;
            }
            continue;
        }
    }
}
