// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.mac;

import com.sun.jna.Pointer;
import com.sun.jna.Callback;

public interface Carbon$EventHandlerProcPtr extends Callback
{
    int callback(final Pointer p0, final Pointer p1, final Pointer p2);
}
