// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.mac;

import java.io.IOException;
import java.io.File;
import com.sun.jna.platform.FileUtils;

public class MacFileUtils extends FileUtils
{
    private static final String[] a;
    private static final String[] b;
    
    @Override
    public boolean hasTrash() {
        return true;
    }
    
    @Override
    public void moveToTrash(final File[] p0) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: sipush          -9232
        //     7: sipush          9562
        //    10: invokestatic    com/sun/jna/platform/mac/MacFileUtils.a:(II)Ljava/lang/String;
        //    13: invokestatic    java/lang/System.getProperty:(Ljava/lang/String;)Ljava/lang/String;
        //    16: invokespecial   java/io/File.<init>:(Ljava/lang/String;)V
        //    19: astore          4
        //    21: invokestatic    com/sun/jna/platform/mac/Carbon$EventHotKeyID.c:()[I
        //    24: new             Ljava/io/File;
        //    27: dup            
        //    28: aload           4
        //    30: sipush          -9228
        //    33: sipush          11653
        //    36: invokestatic    com/sun/jna/platform/mac/MacFileUtils.a:(II)Ljava/lang/String;
        //    39: invokespecial   java/io/File.<init>:(Ljava/io/File;Ljava/lang/String;)V
        //    42: astore          5
        //    44: astore_2       
        //    45: aload           5
        //    47: invokevirtual   java/io/File.exists:()Z
        //    50: ifne            97
        //    53: new             Ljava/io/IOException;
        //    56: dup            
        //    57: new             Ljava/lang/StringBuilder;
        //    60: dup            
        //    61: invokespecial   java/lang/StringBuilder.<init>:()V
        //    64: sipush          -9227
        //    67: sipush          24266
        //    70: invokestatic    com/sun/jna/platform/mac/MacFileUtils.a:(II)Ljava/lang/String;
        //    73: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    76: aload           5
        //    78: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //    81: ldc             ")"
        //    83: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    86: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    89: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //    92: athrow         
        //    93: invokestatic    com/sun/jna/platform/mac/MacFileUtils.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    96: athrow         
        //    97: new             Ljava/util/ArrayList;
        //   100: dup            
        //   101: invokespecial   java/util/ArrayList.<init>:()V
        //   104: astore          6
        //   106: iconst_0       
        //   107: istore          7
        //   109: iload           7
        //   111: aload_1        
        //   112: arraylength    
        //   113: if_icmpge       348
        //   116: aload_1        
        //   117: iload           7
        //   119: aaload         
        //   120: astore          8
        //   122: new             Lcom/sun/jna/platform/mac/MacFileUtils$FileManager$FSRef;
        //   125: dup            
        //   126: invokespecial   com/sun/jna/platform/mac/MacFileUtils$FileManager$FSRef.<init>:()V
        //   129: astore          9
        //   131: getstatic       com/sun/jna/platform/mac/MacFileUtils$FileManager.INSTANCE:Lcom/sun/jna/platform/mac/MacFileUtils$FileManager;
        //   134: aload           8
        //   136: invokevirtual   java/io/File.getAbsolutePath:()Ljava/lang/String;
        //   139: iconst_1       
        //   140: aload           9
        //   142: aconst_null    
        //   143: invokeinterface com/sun/jna/platform/mac/MacFileUtils$FileManager.FSPathMakeRefWithOptions:(Ljava/lang/String;ILcom/sun/jna/platform/mac/MacFileUtils$FileManager$FSRef;Lcom/sun/jna/ptr/ByteByReference;)I
        //   148: istore          10
        //   150: iload           10
        //   152: aload_2        
        //   153: ifnull          355
        //   156: aload_2        
        //   157: ifnull          279
        //   160: goto            167
        //   163: invokestatic    com/sun/jna/platform/mac/MacFileUtils.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   166: athrow         
        //   167: ifeq            244
        //   170: goto            177
        //   173: invokestatic    com/sun/jna/platform/mac/MacFileUtils.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   176: athrow         
        //   177: aload           6
        //   179: new             Ljava/lang/StringBuilder;
        //   182: dup            
        //   183: invokespecial   java/lang/StringBuilder.<init>:()V
        //   186: aload           8
        //   188: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   191: sipush          -9230
        //   194: sipush          13532
        //   197: invokestatic    com/sun/jna/platform/mac/MacFileUtils.a:(II)Ljava/lang/String;
        //   200: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   203: iload           10
        //   205: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //   208: ldc             ")"
        //   210: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   213: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   216: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   221: goto            228
        //   224: invokestatic    com/sun/jna/platform/mac/MacFileUtils.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   227: athrow         
        //   228: pop            
        //   229: aload_2        
        //   230: ifnonnull       341
        //   233: invokestatic    com/sun/jna/Structure.a:()I
        //   236: istore_3       
        //   237: iinc            3, 1
        //   240: iload_3        
        //   241: invokestatic    com/sun/jna/Structure.b:(I)V
        //   244: getstatic       com/sun/jna/platform/mac/MacFileUtils$FileManager.INSTANCE:Lcom/sun/jna/platform/mac/MacFileUtils$FileManager;
        //   247: aload           9
        //   249: aconst_null    
        //   250: iconst_0       
        //   251: invokeinterface com/sun/jna/platform/mac/MacFileUtils$FileManager.FSMoveObjectToTrashSync:(Lcom/sun/jna/platform/mac/MacFileUtils$FileManager$FSRef;Lcom/sun/jna/platform/mac/MacFileUtils$FileManager$FSRef;I)I
        //   256: istore          10
        //   258: aload_2        
        //   259: ifnull          344
        //   262: iload           10
        //   264: aload_2        
        //   265: ifnull          228
        //   268: goto            275
        //   271: invokestatic    com/sun/jna/platform/mac/MacFileUtils.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   274: athrow         
        //   275: aload_2        
        //   276: ifnull          340
        //   279: ifeq            341
        //   282: goto            289
        //   285: invokestatic    com/sun/jna/platform/mac/MacFileUtils.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   288: athrow         
        //   289: aload           6
        //   291: new             Ljava/lang/StringBuilder;
        //   294: dup            
        //   295: invokespecial   java/lang/StringBuilder.<init>:()V
        //   298: aload           8
        //   300: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   303: sipush          -9229
        //   306: sipush          762
        //   309: invokestatic    com/sun/jna/platform/mac/MacFileUtils.a:(II)Ljava/lang/String;
        //   312: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   315: iload           10
        //   317: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //   320: ldc             ")"
        //   322: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   325: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   328: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   333: goto            340
        //   336: invokestatic    com/sun/jna/platform/mac/MacFileUtils.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   339: athrow         
        //   340: pop            
        //   341: iinc            7, 1
        //   344: aload_2        
        //   345: ifnonnull       109
        //   348: aload           6
        //   350: invokeinterface java/util/List.size:()I
        //   355: ifle            397
        //   358: new             Ljava/io/IOException;
        //   361: dup            
        //   362: new             Ljava/lang/StringBuilder;
        //   365: dup            
        //   366: invokespecial   java/lang/StringBuilder.<init>:()V
        //   369: sipush          -9231
        //   372: sipush          10393
        //   375: invokestatic    com/sun/jna/platform/mac/MacFileUtils.a:(II)Ljava/lang/String;
        //   378: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   381: aload           6
        //   383: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   386: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   389: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   392: athrow         
        //   393: invokestatic    com/sun/jna/platform/mac/MacFileUtils.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   396: athrow         
        //   397: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 17 FF 00 5D 00 06 07 00 1E 07 00 92 07 00 94 00 07 00 06 07 00 06 00 01 07 00 0B 03 FD 00 0B 07 00 12 01 FF 00 35 00 0B 07 00 1E 07 00 92 07 00 94 00 07 00 06 07 00 06 07 00 12 01 07 00 06 07 00 14 01 00 01 07 00 0B 43 01 45 07 00 0B 03 6E 07 00 0B 43 01 0F 5A 07 00 0B 43 01 43 01 45 07 00 0B 03 6E 07 00 0B 43 01 00 02 F8 00 03 46 01 65 07 00 0B 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  45     93     93     97     Ljava/io/IOException;
        //  150    160    163    167    Ljava/io/IOException;
        //  156    170    173    177    Ljava/io/IOException;
        //  167    221    224    228    Ljava/io/IOException;
        //  258    268    271    275    Ljava/io/IOException;
        //  275    282    285    289    Ljava/io/IOException;
        //  279    333    336    340    Ljava/io/IOException;
        //  355    393    393    397    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0167:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static IOException b(final IOException ex) {
        return ex;
    }
    
    static {
        final String[] a2 = new String[6];
        int n = 0;
        String s;
        int n2 = (s = "®f\u00c5\u00058\u0093\u0088\u0001C\u001d\u000f{º¥'%\u0089\t\u008c°¦\u00c0r]}EQª`+?¨\u00c6\u00d0\u00c7\u001ck\r\u0099\u008f¸p\t \u0018\u0011\u00e0\u00ea0\u0090\u0093)\u0002+H\t´·_\u0004\u0018¤4\u00fa\u00d0").length();
        int n3 = 42;
        int n4 = -1;
    Label_0023:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 101));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0260: {
                            if (length > 1) {
                                break Label_0260;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 123;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 24;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 13;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 70;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 71;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 121;
                                        break;
                                    }
                                    default: {
                                        n11 = 104;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            a2[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0023;
                            }
                            n2 = (s = " \u0013±\u000e!Jw>²\u00f4mQ\u009a«\u0018G\u00dacM\u00fa\u009a\u008b\u0095\u00fc\u001a_\u00fa\u00cd7\u00f72¯\u0090\u0091\u00ec\u0017Y\u0086\u009c³\u00ca\u00d1\u00e3 \t\u0019>\u00d4\u0089)\u0006!\u0090³\u0084³h").length();
                            n3 = 50;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            a2[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0023;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 96)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        a = a2;
        b = new String[6];
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0xFFFFDBF1) & 0xFFFF;
        if (MacFileUtils.b[n3] == null) {
            final char[] charArray = MacFileUtils.a[n3].toCharArray();
            int n4 = 0;
            switch (charArray[0] & '\u00ff') {
                case 0: {
                    n4 = 205;
                    break;
                }
                case 1: {
                    n4 = 26;
                    break;
                }
                case 2: {
                    n4 = 176;
                    break;
                }
                case 3: {
                    n4 = 74;
                    break;
                }
                case 4: {
                    n4 = 192;
                    break;
                }
                case 5: {
                    n4 = 232;
                    break;
                }
                case 6: {
                    n4 = 77;
                    break;
                }
                case 7: {
                    n4 = 253;
                    break;
                }
                case 8: {
                    n4 = 55;
                    break;
                }
                case 9: {
                    n4 = 188;
                    break;
                }
                case 10: {
                    n4 = 60;
                    break;
                }
                case 11: {
                    n4 = 70;
                    break;
                }
                case 12: {
                    n4 = 219;
                    break;
                }
                case 13: {
                    n4 = 46;
                    break;
                }
                case 14: {
                    n4 = 193;
                    break;
                }
                case 15: {
                    n4 = 221;
                    break;
                }
                case 16: {
                    n4 = 29;
                    break;
                }
                case 17: {
                    n4 = 138;
                    break;
                }
                case 18: {
                    n4 = 206;
                    break;
                }
                case 19: {
                    n4 = 43;
                    break;
                }
                case 20: {
                    n4 = 214;
                    break;
                }
                case 21: {
                    n4 = 141;
                    break;
                }
                case 22: {
                    n4 = 118;
                    break;
                }
                case 23: {
                    n4 = 167;
                    break;
                }
                case 24: {
                    n4 = 21;
                    break;
                }
                case 25: {
                    n4 = 66;
                    break;
                }
                case 26: {
                    n4 = 213;
                    break;
                }
                case 27: {
                    n4 = 49;
                    break;
                }
                case 28: {
                    n4 = 31;
                    break;
                }
                case 29: {
                    n4 = 72;
                    break;
                }
                case 30: {
                    n4 = 183;
                    break;
                }
                case 31: {
                    n4 = 10;
                    break;
                }
                case 32: {
                    n4 = 208;
                    break;
                }
                case 33: {
                    n4 = 135;
                    break;
                }
                case 34: {
                    n4 = 220;
                    break;
                }
                case 35: {
                    n4 = 87;
                    break;
                }
                case 36: {
                    n4 = 67;
                    break;
                }
                case 37: {
                    n4 = 237;
                    break;
                }
                case 38: {
                    n4 = 19;
                    break;
                }
                case 39: {
                    n4 = 166;
                    break;
                }
                case 40: {
                    n4 = 125;
                    break;
                }
                case 41: {
                    n4 = 32;
                    break;
                }
                case 42: {
                    n4 = 120;
                    break;
                }
                case 43: {
                    n4 = 242;
                    break;
                }
                case 44: {
                    n4 = 143;
                    break;
                }
                case 45: {
                    n4 = 119;
                    break;
                }
                case 46: {
                    n4 = 34;
                    break;
                }
                case 47: {
                    n4 = 63;
                    break;
                }
                case 48: {
                    n4 = 22;
                    break;
                }
                case 49: {
                    n4 = 37;
                    break;
                }
                case 50: {
                    n4 = 154;
                    break;
                }
                case 51: {
                    n4 = 187;
                    break;
                }
                case 52: {
                    n4 = 159;
                    break;
                }
                case 53: {
                    n4 = 229;
                    break;
                }
                case 54: {
                    n4 = 174;
                    break;
                }
                case 55: {
                    n4 = 225;
                    break;
                }
                case 56: {
                    n4 = 131;
                    break;
                }
                case 57: {
                    n4 = 137;
                    break;
                }
                case 58: {
                    n4 = 113;
                    break;
                }
                case 59: {
                    n4 = 91;
                    break;
                }
                case 60: {
                    n4 = 58;
                    break;
                }
                case 61: {
                    n4 = 158;
                    break;
                }
                case 62: {
                    n4 = 15;
                    break;
                }
                case 63: {
                    n4 = 185;
                    break;
                }
                case 64: {
                    n4 = 23;
                    break;
                }
                case 65: {
                    n4 = 110;
                    break;
                }
                case 66: {
                    n4 = 145;
                    break;
                }
                case 67: {
                    n4 = 132;
                    break;
                }
                case 68: {
                    n4 = 117;
                    break;
                }
                case 69: {
                    n4 = 123;
                    break;
                }
                case 70: {
                    n4 = 116;
                    break;
                }
                case 71: {
                    n4 = 211;
                    break;
                }
                case 72: {
                    n4 = 98;
                    break;
                }
                case 73: {
                    n4 = 39;
                    break;
                }
                case 74: {
                    n4 = 24;
                    break;
                }
                case 75: {
                    n4 = 41;
                    break;
                }
                case 76: {
                    n4 = 170;
                    break;
                }
                case 77: {
                    n4 = 73;
                    break;
                }
                case 78: {
                    n4 = 53;
                    break;
                }
                case 79: {
                    n4 = 189;
                    break;
                }
                case 80: {
                    n4 = 164;
                    break;
                }
                case 81: {
                    n4 = 148;
                    break;
                }
                case 82: {
                    n4 = 51;
                    break;
                }
                case 83: {
                    n4 = 217;
                    break;
                }
                case 84: {
                    n4 = 171;
                    break;
                }
                case 85: {
                    n4 = 20;
                    break;
                }
                case 86: {
                    n4 = 13;
                    break;
                }
                case 87: {
                    n4 = 146;
                    break;
                }
                case 88: {
                    n4 = 71;
                    break;
                }
                case 89: {
                    n4 = 18;
                    break;
                }
                case 90: {
                    n4 = 249;
                    break;
                }
                case 91: {
                    n4 = 241;
                    break;
                }
                case 92: {
                    n4 = 191;
                    break;
                }
                case 93: {
                    n4 = 250;
                    break;
                }
                case 94: {
                    n4 = 173;
                    break;
                }
                case 95: {
                    n4 = 122;
                    break;
                }
                case 96: {
                    n4 = 180;
                    break;
                }
                case 97: {
                    n4 = 190;
                    break;
                }
                case 98: {
                    n4 = 199;
                    break;
                }
                case 99: {
                    n4 = 62;
                    break;
                }
                case 100: {
                    n4 = 230;
                    break;
                }
                case 101: {
                    n4 = 238;
                    break;
                }
                case 102: {
                    n4 = 97;
                    break;
                }
                case 103: {
                    n4 = 35;
                    break;
                }
                case 104: {
                    n4 = 5;
                    break;
                }
                case 105: {
                    n4 = 28;
                    break;
                }
                case 106: {
                    n4 = 163;
                    break;
                }
                case 107: {
                    n4 = 42;
                    break;
                }
                case 108: {
                    n4 = 8;
                    break;
                }
                case 109: {
                    n4 = 201;
                    break;
                }
                case 110: {
                    n4 = 223;
                    break;
                }
                case 111: {
                    n4 = 231;
                    break;
                }
                case 112: {
                    n4 = 101;
                    break;
                }
                case 113: {
                    n4 = 88;
                    break;
                }
                case 114: {
                    n4 = 195;
                    break;
                }
                case 115: {
                    n4 = 184;
                    break;
                }
                case 116: {
                    n4 = 61;
                    break;
                }
                case 117: {
                    n4 = 147;
                    break;
                }
                case 118: {
                    n4 = 57;
                    break;
                }
                case 119: {
                    n4 = 38;
                    break;
                }
                case 120: {
                    n4 = 215;
                    break;
                }
                case 121: {
                    n4 = 114;
                    break;
                }
                case 122: {
                    n4 = 107;
                    break;
                }
                case 123: {
                    n4 = 212;
                    break;
                }
                case 124: {
                    n4 = 33;
                    break;
                }
                case 125: {
                    n4 = 227;
                    break;
                }
                case 126: {
                    n4 = 1;
                    break;
                }
                case 127: {
                    n4 = 65;
                    break;
                }
                case 128: {
                    n4 = 78;
                    break;
                }
                case 129: {
                    n4 = 222;
                    break;
                }
                case 130: {
                    n4 = 155;
                    break;
                }
                case 131: {
                    n4 = 224;
                    break;
                }
                case 132: {
                    n4 = 248;
                    break;
                }
                case 133: {
                    n4 = 228;
                    break;
                }
                case 134: {
                    n4 = 244;
                    break;
                }
                case 135: {
                    n4 = 14;
                    break;
                }
                case 136: {
                    n4 = 157;
                    break;
                }
                case 137: {
                    n4 = 165;
                    break;
                }
                case 138: {
                    n4 = 130;
                    break;
                }
                case 139: {
                    n4 = 93;
                    break;
                }
                case 140: {
                    n4 = 79;
                    break;
                }
                case 141: {
                    n4 = 239;
                    break;
                }
                case 142: {
                    n4 = 136;
                    break;
                }
                case 143: {
                    n4 = 207;
                    break;
                }
                case 144: {
                    n4 = 99;
                    break;
                }
                case 145: {
                    n4 = 254;
                    break;
                }
                case 146: {
                    n4 = 17;
                    break;
                }
                case 147: {
                    n4 = 197;
                    break;
                }
                case 148: {
                    n4 = 115;
                    break;
                }
                case 149: {
                    n4 = 255;
                    break;
                }
                case 150: {
                    n4 = 252;
                    break;
                }
                case 151: {
                    n4 = 80;
                    break;
                }
                case 152: {
                    n4 = 179;
                    break;
                }
                case 153: {
                    n4 = 156;
                    break;
                }
                case 154: {
                    n4 = 105;
                    break;
                }
                case 155: {
                    n4 = 126;
                    break;
                }
                case 156: {
                    n4 = 109;
                    break;
                }
                case 157: {
                    n4 = 247;
                    break;
                }
                case 158: {
                    n4 = 121;
                    break;
                }
                case 159: {
                    n4 = 75;
                    break;
                }
                case 160: {
                    n4 = 7;
                    break;
                }
                case 161: {
                    n4 = 104;
                    break;
                }
                case 162: {
                    n4 = 200;
                    break;
                }
                case 163: {
                    n4 = 203;
                    break;
                }
                case 164: {
                    n4 = 162;
                    break;
                }
                case 165: {
                    n4 = 240;
                    break;
                }
                case 166: {
                    n4 = 245;
                    break;
                }
                case 167: {
                    n4 = 178;
                    break;
                }
                case 168: {
                    n4 = 161;
                    break;
                }
                case 169: {
                    n4 = 54;
                    break;
                }
                case 170: {
                    n4 = 82;
                    break;
                }
                case 171: {
                    n4 = 48;
                    break;
                }
                case 172: {
                    n4 = 76;
                    break;
                }
                case 173: {
                    n4 = 134;
                    break;
                }
                case 174: {
                    n4 = 106;
                    break;
                }
                case 175: {
                    n4 = 90;
                    break;
                }
                case 176: {
                    n4 = 181;
                    break;
                }
                case 177: {
                    n4 = 84;
                    break;
                }
                case 178: {
                    n4 = 68;
                    break;
                }
                case 179: {
                    n4 = 194;
                    break;
                }
                case 180: {
                    n4 = 100;
                    break;
                }
                case 181: {
                    n4 = 85;
                    break;
                }
                case 182: {
                    n4 = 95;
                    break;
                }
                case 183: {
                    n4 = 45;
                    break;
                }
                case 184: {
                    n4 = 47;
                    break;
                }
                case 185: {
                    n4 = 152;
                    break;
                }
                case 186: {
                    n4 = 30;
                    break;
                }
                case 187: {
                    n4 = 235;
                    break;
                }
                case 188: {
                    n4 = 153;
                    break;
                }
                case 189: {
                    n4 = 36;
                    break;
                }
                case 190: {
                    n4 = 16;
                    break;
                }
                case 191: {
                    n4 = 89;
                    break;
                }
                case 192: {
                    n4 = 3;
                    break;
                }
                case 193: {
                    n4 = 172;
                    break;
                }
                case 194: {
                    n4 = 27;
                    break;
                }
                case 195: {
                    n4 = 204;
                    break;
                }
                case 196: {
                    n4 = 69;
                    break;
                }
                case 197: {
                    n4 = 9;
                    break;
                }
                case 198: {
                    n4 = 175;
                    break;
                }
                case 199: {
                    n4 = 50;
                    break;
                }
                case 200: {
                    n4 = 81;
                    break;
                }
                case 201: {
                    n4 = 226;
                    break;
                }
                case 202: {
                    n4 = 124;
                    break;
                }
                case 203: {
                    n4 = 202;
                    break;
                }
                case 204: {
                    n4 = 218;
                    break;
                }
                case 205: {
                    n4 = 44;
                    break;
                }
                case 206: {
                    n4 = 129;
                    break;
                }
                case 207: {
                    n4 = 210;
                    break;
                }
                case 208: {
                    n4 = 139;
                    break;
                }
                case 209: {
                    n4 = 246;
                    break;
                }
                case 210: {
                    n4 = 151;
                    break;
                }
                case 211: {
                    n4 = 209;
                    break;
                }
                case 212: {
                    n4 = 6;
                    break;
                }
                case 213: {
                    n4 = 11;
                    break;
                }
                case 214: {
                    n4 = 59;
                    break;
                }
                case 215: {
                    n4 = 160;
                    break;
                }
                case 216: {
                    n4 = 25;
                    break;
                }
                case 217: {
                    n4 = 94;
                    break;
                }
                case 218: {
                    n4 = 198;
                    break;
                }
                case 219: {
                    n4 = 168;
                    break;
                }
                case 220: {
                    n4 = 96;
                    break;
                }
                case 221: {
                    n4 = 177;
                    break;
                }
                case 222: {
                    n4 = 64;
                    break;
                }
                case 223: {
                    n4 = 128;
                    break;
                }
                case 224: {
                    n4 = 0;
                    break;
                }
                case 225: {
                    n4 = 196;
                    break;
                }
                case 226: {
                    n4 = 186;
                    break;
                }
                case 227: {
                    n4 = 234;
                    break;
                }
                case 228: {
                    n4 = 108;
                    break;
                }
                case 229: {
                    n4 = 133;
                    break;
                }
                case 230: {
                    n4 = 102;
                    break;
                }
                case 231: {
                    n4 = 92;
                    break;
                }
                case 232: {
                    n4 = 112;
                    break;
                }
                case 233: {
                    n4 = 142;
                    break;
                }
                case 234: {
                    n4 = 56;
                    break;
                }
                case 235: {
                    n4 = 243;
                    break;
                }
                case 236: {
                    n4 = 182;
                    break;
                }
                case 237: {
                    n4 = 233;
                    break;
                }
                case 238: {
                    n4 = 4;
                    break;
                }
                case 239: {
                    n4 = 83;
                    break;
                }
                case 240: {
                    n4 = 140;
                    break;
                }
                case 241: {
                    n4 = 251;
                    break;
                }
                case 242: {
                    n4 = 52;
                    break;
                }
                case 243: {
                    n4 = 216;
                    break;
                }
                case 244: {
                    n4 = 144;
                    break;
                }
                case 245: {
                    n4 = 111;
                    break;
                }
                case 246: {
                    n4 = 127;
                    break;
                }
                case 247: {
                    n4 = 12;
                    break;
                }
                case 248: {
                    n4 = 2;
                    break;
                }
                case 249: {
                    n4 = 236;
                    break;
                }
                case 250: {
                    n4 = 40;
                    break;
                }
                case 251: {
                    n4 = 86;
                    break;
                }
                case 252: {
                    n4 = 150;
                    break;
                }
                case 253: {
                    n4 = 149;
                    break;
                }
                case 254: {
                    n4 = 169;
                    break;
                }
                default: {
                    n4 = 103;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < charArray.length; ++i) {
                final int n8 = i % 2;
                final char[] array = charArray;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ charArray[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ charArray[i]) & 0xFF);
                }
            }
            MacFileUtils.b[n3] = new String(charArray).intern();
        }
        return MacFileUtils.b[n3];
    }
}
