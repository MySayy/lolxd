// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.mac;

import java.util.List;
import com.sun.jna.Structure;

public class SystemB$VMStatistics64 extends Structure
{
    public static final List<String> FIELDS;
    public int free_count;
    public int active_count;
    public int inactive_count;
    public int wire_count;
    public long zero_fill_count;
    public long reactivations;
    public long pageins;
    public long pageouts;
    public long faults;
    public long cow_faults;
    public long lookups;
    public long hits;
    public long purges;
    public int purgeable_count;
    public int speculative_count;
    public long decompressions;
    public long compressions;
    public long swapins;
    public long swapouts;
    public int compressor_page_count;
    public int throttled_count;
    public int external_page_count;
    public int internal_page_count;
    public long total_uncompressed_pages_in_compressor;
    
    @Override
    protected List<String> getFieldOrder() {
        return SystemB$VMStatistics64.FIELDS;
    }
    
    static {
        final String[] array = new String[24];
        int n = 0;
        String s;
        int n2 = (s = "Rx\u0005wN'<R\u000f[j\u0016h~4!Mc;dN'&U\u0007M`\u000blT\";\nG}\u0001b~1'Ta\u0010\u0007Qn\u0003bH<;\u0007Rx\u0005wH<;\f@l\u0010nW7\u0017B`\u0011iU\u000eEj\u0007hL\":D|\u0017nN<;\rSj\u0005dU;>@{\rhO!\u0006Qz\u0016`D!\u000eHa\u0005dU;>DP\u0007hT<<\nB`\u0013XG3=M{\u0017&U`\u0010fM\r=Ol\u000bjQ -R|\u0001c~\")Fj\u0017XH<\u0017B`\twS7;R`\u0016\u0015B`\twS7;R`\u0016XQ3/DP\u0007hT<<\u0011R\u007f\u0001dT>)Uf\u0012b~1'Ta\u0010\u0013Dw\u0010bS<)MP\u0014fF7\u0017B`\u0011iU\u0004If\u0010t\u000fUg\u0016hU&$Dk;dN'&U\bQn\u0003bN'<R\u0013Ha\u0010bS<)MP\u0014fF7\u0017B`\u0011iU\fB`\twS7;Rf\u000biR\u000fQz\u0016`D3*Mj;dN'&U").length();
        int n3 = 8;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 6));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0251: {
                            if (length > 1) {
                                break Label_0251;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 39;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 9;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 98;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 1;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 39;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 84;
                                        break;
                                    }
                                    default: {
                                        n11 = 78;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "&\u0016f\u0012\u000eAW$\u0011`\u00067\u001ea\u001b%Q").length();
                            n3 = 10;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 118)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[3], array2[6], array2[10], array2[22], array2[1], array2[8], array2[4], array2[18], array2[23], array2[11], array2[2], array2[16], array2[9], array2[21], array2[14], array2[7], array2[20], array2[5], array2[0], array2[13], array2[17], array2[15], array2[19], array2[12]);
    }
}
