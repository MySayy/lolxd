// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.mac;

import com.sun.jna.Native;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.Structure;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.Library;

public interface SystemB extends Library
{
    public static final SystemB INSTANCE = Native.loadLibrary(new String(charArray).intern(), SystemB.class);
    public static final int HOST_LOAD_INFO = 1;
    public static final int HOST_VM_INFO = 2;
    public static final int HOST_CPU_LOAD_INFO = 3;
    public static final int HOST_VM_INFO64 = 4;
    public static final int CPU_STATE_MAX = 4;
    public static final int CPU_STATE_USER = 0;
    public static final int CPU_STATE_SYSTEM = 1;
    public static final int CPU_STATE_IDLE = 2;
    public static final int CPU_STATE_NICE = 3;
    public static final int PROCESSOR_BASIC_INFO = 1;
    public static final int PROCESSOR_CPU_LOAD_INFO = 2;
    public static final int UINT64_SIZE = Native.getNativeSize(Long.TYPE);
    public static final int INT_SIZE = Native.getNativeSize(Integer.TYPE);
    
    int mach_host_self();
    
    int mach_task_self();
    
    int host_page_size(final int p0, final LongByReference p1);
    
    int host_statistics(final int p0, final int p1, final Structure p2, final IntByReference p3);
    
    int host_statistics64(final int p0, final int p1, final Structure p2, final IntByReference p3);
    
    int sysctl(final int[] p0, final int p1, final Pointer p2, final IntByReference p3, final Pointer p4, final int p5);
    
    int sysctlbyname(final String p0, final Pointer p1, final IntByReference p2, final Pointer p3, final int p4);
    
    int sysctlnametomib(final String p0, final Pointer p1, final IntByReference p2);
    
    int host_processor_info(final int p0, final int p1, final IntByReference p2, final PointerByReference p3, final IntByReference p4);
    
    int getloadavg(final double[] p0, final int p1);
    
    default static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 24);
        final char[] charArray = "iVw\n\u0012q".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0127: {
                if (length > 1) {
                    break Label_0127;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 34;
                            break;
                        }
                        case 1: {
                            n5 = 55;
                            break;
                        }
                        case 2: {
                            n5 = 28;
                            break;
                        }
                        case 3: {
                            n5 = 102;
                            break;
                        }
                        case 4: {
                            n5 = 111;
                            break;
                        }
                        case 5: {
                            n5 = 4;
                            break;
                        }
                        default: {
                            n5 = 80;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                return;
            }
            continue;
        }
    }
}
