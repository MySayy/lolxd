// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.mac;

import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.Library;

interface XAttr extends Library
{
    public static final XAttr INSTANCE = Native.loadLibrary(null, XAttr.class);
    public static final int XATTR_NOFOLLOW = 1;
    public static final int XATTR_CREATE = 2;
    public static final int XATTR_REPLACE = 4;
    public static final int XATTR_NOSECURITY = 8;
    public static final int XATTR_NODEFAULT = 16;
    public static final int XATTR_SHOWCOMPRESSION = 32;
    public static final int XATTR_MAXNAMELEN = 127;
    public static final String XATTR_FINDERINFO_NAME = array2[1];
    public static final String XATTR_RESOURCEFORK_NAME = array2[0];
    
    long getxattr(final String p0, final String p1, final Pointer p2, final long p3, final int p4, final int p5);
    
    int setxattr(final String p0, final String p1, final Pointer p2, final long p3, final int p4, final int p5);
    
    int removexattr(final String p0, final String p1, final int p2);
    
    long listxattr(final String p0, final Pointer p1, final long p2, final int p3);
    
    default static {
        final String[] array = new String[2];
        int n = 0;
        final String s;
        final int length = (s = "_\u001f_\u001c\u0014\f\u0016P\u0015\u001c`\u0010\u000f\tI\u0002QW3\u0013\u0014W\u0014_\u001f_\u001c\u0014\f\u0016P\u0015\u001ct\u001c\u0012\u0002Y\u0002{\\\u0013\u0013").length();
        int char1 = 22;
        int index = -1;
        Label_0023: {
            break Label_0023;
            do {
                char1 = s.charAt(index);
                int n4;
                int n3;
                final int n2 = n3 = (n4 = 35);
                ++index;
                final String s2 = s;
                final int beginIndex = index;
                final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
                final int length2 = charArray.length;
                int n5 = 0;
                while (true) {
                    Label_0208: {
                        if (length2 > 1) {
                            break Label_0208;
                        }
                        n4 = (n3 = n5);
                        do {
                            final char c = charArray[n3];
                            int n6 = 0;
                            switch (n5 % 7) {
                                case 0: {
                                    n6 = 31;
                                    break;
                                }
                                case 1: {
                                    n6 = 83;
                                    break;
                                }
                                case 2: {
                                    n6 = 17;
                                    break;
                                }
                                case 3: {
                                    n6 = 17;
                                    break;
                                }
                                case 4: {
                                    n6 = 86;
                                    break;
                                }
                                case 5: {
                                    n6 = 95;
                                    break;
                                }
                                default: {
                                    n6 = 69;
                                    break;
                                }
                            }
                            charArray[n4] = (char)(c ^ (n2 ^ n6));
                            ++n5;
                        } while (n2 == 0);
                    }
                    if (length2 > n5) {
                        continue;
                    }
                    break;
                }
                array[n++] = new String(charArray).intern();
            } while ((index += char1) < length);
        }
        final String[] array2 = array;
    }
}
