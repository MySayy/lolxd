// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.mac;

import java.util.List;
import com.sun.jna.Structure;

public class Carbon$EventHotKeyID extends Structure
{
    public static final List<String> FIELDS;
    public int signature;
    public int id;
    private static int[] a;
    
    @Override
    protected List<String> getFieldOrder() {
        return Carbon$EventHotKeyID.FIELDS;
    }
    
    static {
        final String[] array = new String[2];
        final int[] array2 = new int[5];
        int n = 0;
        final String s;
        final int length = (s = "\r\t\t\u0017\u0004NB}bm\u0016\b").length();
        b(array2);
        int char1 = 2;
        int index = -1;
        Label_0028: {
            break Label_0028;
            do {
                char1 = s.charAt(index);
                int n4;
                int n3;
                final int n2 = n3 = (n4 = 65);
                ++index;
                final String s2 = s;
                final int beginIndex = index;
                final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
                final int length2 = charArray.length;
                int n5 = 0;
                while (true) {
                    Label_0196: {
                        if (length2 > 1) {
                            break Label_0196;
                        }
                        n4 = (n3 = n5);
                        do {
                            final char c = charArray[n3];
                            int n6 = 0;
                            switch (n5 % 7) {
                                case 0: {
                                    n6 = 37;
                                    break;
                                }
                                case 1: {
                                    n6 = 44;
                                    break;
                                }
                                case 2: {
                                    n6 = 104;
                                    break;
                                }
                                case 3: {
                                    n6 = 109;
                                    break;
                                }
                                case 4: {
                                    n6 = 93;
                                    break;
                                }
                                case 5: {
                                    n6 = 87;
                                    break;
                                }
                                default: {
                                    n6 = 89;
                                    break;
                                }
                            }
                            charArray[n4] = (char)(c ^ (n2 ^ n6));
                            ++n5;
                        } while (n2 == 0);
                    }
                    if (length2 > n5) {
                        continue;
                    }
                    break;
                }
                array[n++] = new String(charArray).intern();
            } while ((index += char1) < length);
        }
        final String[] array3 = array;
        FIELDS = Structure.createFieldsOrder(array3[1], array3[0]);
    }
    
    public static void b(final int[] a) {
        Carbon$EventHotKeyID.a = a;
    }
    
    public static int[] c() {
        return Carbon$EventHotKeyID.a;
    }
}
