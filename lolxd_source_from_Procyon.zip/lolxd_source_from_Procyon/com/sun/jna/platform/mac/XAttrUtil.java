// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.mac;

import java.nio.ByteBuffer;
import com.sun.jna.Structure;
import java.nio.charset.Charset;
import com.sun.jna.Memory;
import java.util.ArrayList;
import com.sun.jna.Pointer;
import java.util.List;

public class XAttrUtil
{
    private static final String a;
    
    public static List<String> listXAttr(final String s) {
        final int[] c = Carbon$EventHotKeyID.c();
        final long listxattr = XAttr.INSTANCE.listxattr(s, null, 0L, 0);
        final int[] array = c;
        Label_0043: {
            Label_0034: {
                long n;
                try {
                    final long n2;
                    n = (n2 = lcmp(listxattr, 0L));
                    if (array == null) {
                        break Label_0043;
                    }
                    if (n < 0) {
                        break Label_0034;
                    }
                    break Label_0034;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    if (n < 0) {
                        return null;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            long n2 = lcmp(listxattr, 0L);
            try {
                if (n2 == 0) {
                    return new ArrayList<String>(0);
                }
            }
            catch (RuntimeException ex3) {
                throw b(ex3);
            }
        }
        final Memory memory = new Memory(listxattr);
        final long listxattr2 = XAttr.INSTANCE.listxattr(s, memory, listxattr, 0);
        try {
            if (listxattr2 < 0L) {
                return null;
            }
        }
        catch (RuntimeException ex4) {
            throw b(ex4);
        }
        return decodeStringSequence(memory.getByteBuffer(0L, listxattr2));
    }
    
    public static String getXAttr(final String s, final String s2) {
        final long getxattr = XAttr.INSTANCE.getxattr(s, s2, null, 0L, 0, 0);
        try {
            if (getxattr < 0L) {
                return null;
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
        final Memory memory = new Memory(getxattr);
        final long getxattr2 = XAttr.INSTANCE.getxattr(s, s2, memory, getxattr, 0, 0);
        try {
            if (getxattr2 < 0L) {
                return null;
            }
        }
        catch (RuntimeException ex2) {
            throw b(ex2);
        }
        return decodeString(memory.getByteBuffer(0L, getxattr2 - 1L));
    }
    
    public static int setXAttr(final String s, final String s2, final String s3) {
        final Memory encodeString = encodeString(s3);
        return XAttr.INSTANCE.setxattr(s, s2, encodeString, encodeString.size(), 0, 0);
    }
    
    public static int removeXAttr(final String s, final String s2) {
        return XAttr.INSTANCE.removexattr(s, s2, 0);
    }
    
    protected static Memory encodeString(final String s) {
        final byte[] bytes = s.getBytes(Charset.forName(XAttrUtil.a));
        Carbon$EventHotKeyID.c();
        final Memory memory = new Memory(bytes.length + 1);
        Memory memory2;
        try {
            memory.write(0L, bytes, 0, bytes.length);
            memory.setByte(memory.size() - 1L, (byte)0);
            memory2 = memory;
            if (Structure.b() != 0) {
                Carbon$EventHotKeyID.b(new int[2]);
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
        return memory2;
    }
    
    protected static String decodeString(final ByteBuffer bb) {
        return Charset.forName(XAttrUtil.a).decode(bb).toString();
    }
    
    protected static List<String> decodeStringSequence(final ByteBuffer byteBuffer) {
        final int[] c = Carbon$EventHotKeyID.c();
        final ArrayList<String> list = new ArrayList<String>();
        byteBuffer.mark();
        final int[] array = c;
    Label_0017:
        while (true) {
            boolean b = byteBuffer.hasRemaining();
            while (b) {
                ByteBuffer byteBuffer2 = null;
                Label_0061: {
                    try {
                        byteBuffer2 = byteBuffer;
                        if (array == null) {
                            break Label_0061;
                        }
                        if (byteBuffer.get() != 0) {
                            continue Label_0017;
                        }
                    }
                    catch (RuntimeException ex) {
                        throw b(ex);
                    }
                    byteBuffer2 = (ByteBuffer)byteBuffer.duplicate().limit(byteBuffer.position() - 1).reset();
                }
                final ByteBuffer byteBuffer3 = byteBuffer2;
                Label_0117: {
                    boolean b2;
                    try {
                        final ByteBuffer byteBuffer4 = byteBuffer3;
                        if (array == null) {
                            break Label_0117;
                        }
                        b2 = (b = byteBuffer4.hasRemaining());
                        if (array == null) {
                            continue;
                        }
                    }
                    catch (RuntimeException ex2) {
                        throw b(ex2);
                    }
                    Label_0095: {
                        try {
                            if (array == null) {
                                break Label_0095;
                            }
                            if (b2) {
                                break Label_0095;
                            }
                            break Label_0095;
                        }
                        catch (RuntimeException ex3) {
                            throw b(ex3);
                        }
                        try {
                            if (b2) {
                                list.add(decodeString(byteBuffer3));
                            }
                        }
                        catch (RuntimeException ex4) {
                            throw b(ex4);
                        }
                    }
                    byteBuffer.mark();
                }
                if (array == null) {
                    break;
                }
                continue Label_0017;
            }
            break;
        }
        return list;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 64);
        final char[] charArray = "RW,\u0016|".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0127: {
                if (length > 1) {
                    break Label_0127;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 71;
                            break;
                        }
                        case 1: {
                            n5 = 67;
                            break;
                        }
                        case 2: {
                            n5 = 42;
                            break;
                        }
                        case 3: {
                            n5 = 123;
                            break;
                        }
                        case 4: {
                            n5 = 4;
                            break;
                        }
                        case 5: {
                            n5 = 110;
                            break;
                        }
                        default: {
                            n5 = 66;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
