// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.mac;

import java.util.List;
import com.sun.jna.Structure;

public class MacFileUtils$FileManager$FSRef extends Structure
{
    public static final List<String> FIELDS;
    public byte[] hidden;
    
    public MacFileUtils$FileManager$FSRef() {
        this.hidden = new byte[80];
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return MacFileUtils$FileManager$FSRef.FIELDS;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 13);
        final char[] charArray = "\u0003VyN$p".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 102;
                            break;
                        }
                        case 1: {
                            n5 = 50;
                            break;
                        }
                        case 2: {
                            n5 = 16;
                            break;
                        }
                        case 3: {
                            n5 = 39;
                            break;
                        }
                        case 4: {
                            n5 = 76;
                            break;
                        }
                        case 5: {
                            n5 = 19;
                            break;
                        }
                        default: {
                            n5 = 45;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                FIELDS = Structure.createFieldsOrder(new String(charArray).intern());
                return;
            }
            continue;
        }
    }
}
