// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.Rectangle;
import java.util.List;
import java.awt.Dimension;
import com.sun.jna.platform.win32.WinDef$HICON;
import java.awt.image.BufferedImage;
import com.sun.jna.platform.win32.WinDef$HWND;
import java.awt.GraphicsConfiguration;
import javax.swing.Icon;
import java.awt.Component;
import java.awt.Window;
import java.awt.Shape;

public class WindowUtils
{
    private static final String TRANSPARENT_OLD_BG;
    private static final String TRANSPARENT_OLD_OPAQUE;
    private static final String TRANSPARENT_ALPHA;
    public static final Shape MASK_NONE;
    
    private static WindowUtils$NativeWindowUtils getInstance() {
        return WindowUtils$Holder.INSTANCE;
    }
    
    public static void setWindowMask(final Window window, final Shape shape) {
        getInstance().setWindowMask(window, shape);
    }
    
    public static void setComponentMask(final Component component, final Shape shape) {
        getInstance().setWindowMask(component, shape);
    }
    
    public static void setWindowMask(final Window window, final Icon icon) {
        getInstance().setWindowMask(window, icon);
    }
    
    public static boolean isWindowAlphaSupported() {
        return getInstance().isWindowAlphaSupported();
    }
    
    public static GraphicsConfiguration getAlphaCompatibleGraphicsConfiguration() {
        return getInstance().getAlphaCompatibleGraphicsConfiguration();
    }
    
    public static void setWindowAlpha(final Window window, final float a) {
        getInstance().setWindowAlpha(window, Math.max(0.0f, Math.min(a, 1.0f)));
    }
    
    public static void setWindowTransparent(final Window window, final boolean b) {
        getInstance().setWindowTransparent(window, b);
    }
    
    public static BufferedImage getWindowIcon(final WinDef$HWND winDef$HWND) {
        return getInstance().getWindowIcon(winDef$HWND);
    }
    
    public static Dimension getIconSize(final WinDef$HICON winDef$HICON) {
        return getInstance().getIconSize(winDef$HICON);
    }
    
    public static List<DesktopWindow> getAllWindows(final boolean b) {
        return getInstance().getAllWindows(b);
    }
    
    public static String getWindowTitle(final WinDef$HWND winDef$HWND) {
        return getInstance().getWindowTitle(winDef$HWND);
    }
    
    public static String getProcessFilePath(final WinDef$HWND winDef$HWND) {
        return getInstance().getProcessFilePath(winDef$HWND);
    }
    
    public static Rectangle getWindowLocationAndSize(final WinDef$HWND winDef$HWND) {
        return getInstance().getWindowLocationAndSize(winDef$HWND);
    }
    
    static {
        final String[] array = new String[3];
        int n = 0;
        final String s;
        final int length = (s = "fhdWT\u0006G`\u007fkM\n\u0017Jbrd\u0016fhdWT\u0006G`\u007fkM\n\u0019Jv7jIF\u0007Sw\u0012fhdWT\u0006G`\u007fkM\n\u0019Jv7g^").length();
        int char1 = 17;
        int index = -1;
        Label_0023: {
            break Label_0023;
            do {
                char1 = s.charAt(index);
                int n4;
                int n3;
                final int n2 = n3 = (n4 = 112);
                ++index;
                final String s2 = s;
                final int beginIndex = index;
                final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
                final int length2 = charArray.length;
                int n5 = 0;
                while (true) {
                    Label_0212: {
                        if (length2 > 1) {
                            break Label_0212;
                        }
                        n4 = (n3 = n5);
                        do {
                            final char c = charArray[n3];
                            int n6 = 0;
                            switch (n5 % 7) {
                                case 0: {
                                    n6 = 98;
                                    break;
                                }
                                case 1: {
                                    n6 = 106;
                                    break;
                                }
                                case 2: {
                                    n6 = 117;
                                    break;
                                }
                                case 3: {
                                    n6 = 73;
                                    break;
                                }
                                case 4: {
                                    n6 = 87;
                                    break;
                                }
                                case 5: {
                                    n6 = 6;
                                    break;
                                }
                                default: {
                                    n6 = 86;
                                    break;
                                }
                            }
                            charArray[n4] = (char)(c ^ (n2 ^ n6));
                            ++n5;
                        } while (n2 == 0);
                    }
                    if (length2 > n5) {
                        continue;
                    }
                    break;
                }
                array[n++] = new String(charArray).intern();
            } while ((index += char1) < length);
        }
        final String[] array2 = array;
        TRANSPARENT_OLD_OPAQUE = array2[1];
        TRANSPARENT_ALPHA = array2[0];
        TRANSPARENT_OLD_BG = array2[2];
        MASK_NONE = null;
    }
}
