// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.Container;
import java.awt.Dimension;
import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.WinDef$HBITMAP;
import com.sun.jna.platform.win32.WinDef$HDC;

class WindowUtils$W32WindowUtils$W32TransparentContentPane extends WindowUtils$NativeWindowUtils$TransparentContentPane
{
    private static final long serialVersionUID = 1L;
    private WinDef$HDC memDC;
    private WinDef$HBITMAP hBitmap;
    private Pointer pbits;
    private Dimension bitmapSize;
    final WindowUtils$W32WindowUtils this$0;
    
    public WindowUtils$W32WindowUtils$W32TransparentContentPane(final WindowUtils$W32WindowUtils this$0, final Container container) {
        super(this.this$0 = this$0, container);
    }
    
    private void disposeBackingStore() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: getstatic       com/sun/jna/platform/win32/GDI32.INSTANCE:Lcom/sun/jna/platform/win32/GDI32;
        //     6: astore_2       
        //     7: astore_1       
        //     8: aload_0        
        //     9: aload_1        
        //    10: ifnonnull       58
        //    13: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.hBitmap:Lcom/sun/jna/platform/win32/WinDef$HBITMAP;
        //    16: ifnull          49
        //    19: goto            26
        //    22: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    25: athrow         
        //    26: aload_2        
        //    27: aload_0        
        //    28: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.hBitmap:Lcom/sun/jna/platform/win32/WinDef$HBITMAP;
        //    31: invokeinterface com/sun/jna/platform/win32/GDI32.DeleteObject:(Lcom/sun/jna/platform/win32/WinNT$HANDLE;)Z
        //    36: pop            
        //    37: aload_0        
        //    38: goto            45
        //    41: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    44: athrow         
        //    45: aconst_null    
        //    46: putfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.hBitmap:Lcom/sun/jna/platform/win32/WinDef$HBITMAP;
        //    49: aload_0        
        //    50: aload_1        
        //    51: ifnonnull       45
        //    54: aload_1        
        //    55: ifnonnull       101
        //    58: aload_1        
        //    59: ifnonnull       101
        //    62: goto            69
        //    65: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    68: athrow         
        //    69: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.memDC:Lcom/sun/jna/platform/win32/WinDef$HDC;
        //    72: ifnull          105
        //    75: goto            82
        //    78: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    81: athrow         
        //    82: aload_2        
        //    83: aload_0        
        //    84: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.memDC:Lcom/sun/jna/platform/win32/WinDef$HDC;
        //    87: invokeinterface com/sun/jna/platform/win32/GDI32.DeleteDC:(Lcom/sun/jna/platform/win32/WinDef$HDC;)Z
        //    92: pop            
        //    93: aload_0        
        //    94: goto            101
        //    97: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   100: athrow         
        //   101: aconst_null    
        //   102: putfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.memDC:Lcom/sun/jna/platform/win32/WinDef$HDC;
        //   105: return         
        //    StackMapTable: 00 0D FF 00 16 00 03 07 00 4A 07 00 7A 07 00 66 00 01 07 01 15 03 4E 07 01 15 43 07 00 4A 03 48 07 00 4A 46 07 01 15 43 07 00 4A 48 07 01 15 03 4E 07 01 15 43 07 00 4A 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  8      19     22     26     Ljava/lang/RuntimeException;
        //  13     38     41     45     Ljava/lang/RuntimeException;
        //  54     62     65     69     Ljava/lang/RuntimeException;
        //  58     75     78     82     Ljava/lang/RuntimeException;
        //  69     94     97     101    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0058:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void removeNotify() {
        super.removeNotify();
        this.disposeBackingStore();
    }
    
    @Override
    public void setTransparent(final boolean p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_0        
        //     5: aload_2        
        //     6: ifnonnull       43
        //     9: aload_2        
        //    10: ifnonnull       43
        //    13: goto            20
        //    16: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    19: athrow         
        //    20: iload_1        
        //    21: invokespecial   com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.setTransparent:(Z)V
        //    24: iload_1        
        //    25: ifne            46
        //    28: goto            35
        //    31: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    34: athrow         
        //    35: aload_0        
        //    36: goto            43
        //    39: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    42: athrow         
        //    43: invokespecial   com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.disposeBackingStore:()V
        //    46: return         
        //    StackMapTable: 00 07 FF 00 10 00 03 07 00 4A 01 07 00 7A 00 01 07 01 15 43 07 00 4A 4A 07 01 15 03 43 07 01 15 43 07 00 4A 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      13     16     20     Ljava/lang/RuntimeException;
        //  9      28     31     35     Ljava/lang/RuntimeException;
        //  20     36     39     43     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    protected void paintDirect(final BufferedImage p0, final Rectangle p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokestatic    javax/swing/SwingUtilities.getWindowAncestor:(Ljava/awt/Component;)Ljava/awt/Window;
        //     4: astore          4
        //     6: getstatic       com/sun/jna/platform/win32/GDI32.INSTANCE:Lcom/sun/jna/platform/win32/GDI32;
        //     9: astore          5
        //    11: getstatic       com/sun/jna/platform/win32/User32.INSTANCE:Lcom/sun/jna/platform/win32/User32;
        //    14: astore          6
        //    16: aload_2        
        //    17: getfield        java/awt/Rectangle.x:I
        //    20: istore          7
        //    22: aload_2        
        //    23: getfield        java/awt/Rectangle.y:I
        //    26: istore          8
        //    28: aload_0        
        //    29: iload           7
        //    31: iload           8
        //    33: aload           4
        //    35: invokestatic    javax/swing/SwingUtilities.convertPoint:(Ljava/awt/Component;IILjava/awt/Component;)Ljava/awt/Point;
        //    38: astore          9
        //    40: aload_2        
        //    41: getfield        java/awt/Rectangle.width:I
        //    44: istore          10
        //    46: aload_2        
        //    47: getfield        java/awt/Rectangle.height:I
        //    50: istore          11
        //    52: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils.b:()[I
        //    55: astore_3       
        //    56: aload           4
        //    58: invokevirtual   java/awt/Window.getWidth:()I
        //    61: istore          12
        //    63: aload           4
        //    65: invokevirtual   java/awt/Window.getHeight:()I
        //    68: istore          13
        //    70: aload           6
        //    72: aconst_null    
        //    73: invokeinterface com/sun/jna/platform/win32/User32.GetDC:(Lcom/sun/jna/platform/win32/WinDef$HWND;)Lcom/sun/jna/platform/win32/WinDef$HDC;
        //    78: astore          14
        //    80: aconst_null    
        //    81: astore          15
        //    83: aload_0        
        //    84: aload_3        
        //    85: ifnonnull       126
        //    88: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.memDC:Lcom/sun/jna/platform/win32/WinDef$HDC;
        //    91: ifnonnull       121
        //    94: goto            101
        //    97: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   100: athrow         
        //   101: aload_0        
        //   102: goto            109
        //   105: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   108: athrow         
        //   109: aload           5
        //   111: aload           14
        //   113: invokeinterface com/sun/jna/platform/win32/GDI32.CreateCompatibleDC:(Lcom/sun/jna/platform/win32/WinDef$HDC;)Lcom/sun/jna/platform/win32/WinDef$HDC;
        //   118: putfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.memDC:Lcom/sun/jna/platform/win32/WinDef$HDC;
        //   121: aload_0        
        //   122: aload_3        
        //   123: ifnonnull       109
        //   126: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.hBitmap:Lcom/sun/jna/platform/win32/WinDef$HBITMAP;
        //   129: aload_3        
        //   130: ifnonnull       187
        //   133: ifnull          165
        //   136: goto            143
        //   139: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   142: athrow         
        //   143: aload           4
        //   145: invokevirtual   java/awt/Window.getSize:()Ljava/awt/Dimension;
        //   148: aload_0        
        //   149: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.bitmapSize:Ljava/awt/Dimension;
        //   152: invokevirtual   java/awt/Dimension.equals:(Ljava/lang/Object;)Z
        //   155: ifne            345
        //   158: goto            165
        //   161: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   164: athrow         
        //   165: aload_0        
        //   166: aload_3        
        //   167: ifnonnull       210
        //   170: goto            177
        //   173: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   176: athrow         
        //   177: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.hBitmap:Lcom/sun/jna/platform/win32/WinDef$HBITMAP;
        //   180: goto            187
        //   183: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   186: athrow         
        //   187: ifnull          214
        //   190: aload           5
        //   192: aload_0        
        //   193: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.hBitmap:Lcom/sun/jna/platform/win32/WinDef$HBITMAP;
        //   196: invokeinterface com/sun/jna/platform/win32/GDI32.DeleteObject:(Lcom/sun/jna/platform/win32/WinNT$HANDLE;)Z
        //   201: pop            
        //   202: aload_0        
        //   203: goto            210
        //   206: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   209: athrow         
        //   210: aconst_null    
        //   211: putfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.hBitmap:Lcom/sun/jna/platform/win32/WinDef$HBITMAP;
        //   214: new             Lcom/sun/jna/platform/win32/WinGDI$BITMAPINFO;
        //   217: dup            
        //   218: invokespecial   com/sun/jna/platform/win32/WinGDI$BITMAPINFO.<init>:()V
        //   221: astore          16
        //   223: aload           16
        //   225: getfield        com/sun/jna/platform/win32/WinGDI$BITMAPINFO.bmiHeader:Lcom/sun/jna/platform/win32/WinGDI$BITMAPINFOHEADER;
        //   228: iload           12
        //   230: putfield        com/sun/jna/platform/win32/WinGDI$BITMAPINFOHEADER.biWidth:I
        //   233: aload           16
        //   235: getfield        com/sun/jna/platform/win32/WinGDI$BITMAPINFO.bmiHeader:Lcom/sun/jna/platform/win32/WinGDI$BITMAPINFOHEADER;
        //   238: iload           13
        //   240: putfield        com/sun/jna/platform/win32/WinGDI$BITMAPINFOHEADER.biHeight:I
        //   243: aload           16
        //   245: getfield        com/sun/jna/platform/win32/WinGDI$BITMAPINFO.bmiHeader:Lcom/sun/jna/platform/win32/WinGDI$BITMAPINFOHEADER;
        //   248: iconst_1       
        //   249: putfield        com/sun/jna/platform/win32/WinGDI$BITMAPINFOHEADER.biPlanes:S
        //   252: aload           16
        //   254: getfield        com/sun/jna/platform/win32/WinGDI$BITMAPINFO.bmiHeader:Lcom/sun/jna/platform/win32/WinGDI$BITMAPINFOHEADER;
        //   257: bipush          32
        //   259: putfield        com/sun/jna/platform/win32/WinGDI$BITMAPINFOHEADER.biBitCount:S
        //   262: aload           16
        //   264: getfield        com/sun/jna/platform/win32/WinGDI$BITMAPINFO.bmiHeader:Lcom/sun/jna/platform/win32/WinGDI$BITMAPINFOHEADER;
        //   267: iconst_0       
        //   268: putfield        com/sun/jna/platform/win32/WinGDI$BITMAPINFOHEADER.biCompression:I
        //   271: aload           16
        //   273: getfield        com/sun/jna/platform/win32/WinGDI$BITMAPINFO.bmiHeader:Lcom/sun/jna/platform/win32/WinGDI$BITMAPINFOHEADER;
        //   276: iload           12
        //   278: iload           13
        //   280: imul           
        //   281: iconst_4       
        //   282: imul           
        //   283: putfield        com/sun/jna/platform/win32/WinGDI$BITMAPINFOHEADER.biSizeImage:I
        //   286: new             Lcom/sun/jna/ptr/PointerByReference;
        //   289: dup            
        //   290: invokespecial   com/sun/jna/ptr/PointerByReference.<init>:()V
        //   293: astore          17
        //   295: aload_0        
        //   296: aload           5
        //   298: aload_0        
        //   299: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.memDC:Lcom/sun/jna/platform/win32/WinDef$HDC;
        //   302: aload           16
        //   304: iconst_0       
        //   305: aload           17
        //   307: aconst_null    
        //   308: iconst_0       
        //   309: invokeinterface com/sun/jna/platform/win32/GDI32.CreateDIBSection:(Lcom/sun/jna/platform/win32/WinDef$HDC;Lcom/sun/jna/platform/win32/WinGDI$BITMAPINFO;ILcom/sun/jna/ptr/PointerByReference;Lcom/sun/jna/Pointer;I)Lcom/sun/jna/platform/win32/WinDef$HBITMAP;
        //   314: putfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.hBitmap:Lcom/sun/jna/platform/win32/WinDef$HBITMAP;
        //   317: aload_0        
        //   318: aload           17
        //   320: invokevirtual   com/sun/jna/ptr/PointerByReference.getValue:()Lcom/sun/jna/Pointer;
        //   323: putfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.pbits:Lcom/sun/jna/Pointer;
        //   326: aload_0        
        //   327: aload_3        
        //   328: ifnonnull       210
        //   331: new             Ljava/awt/Dimension;
        //   334: dup            
        //   335: iload           12
        //   337: iload           13
        //   339: invokespecial   java/awt/Dimension.<init>:(II)V
        //   342: putfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.bitmapSize:Ljava/awt/Dimension;
        //   345: aload           5
        //   347: aload_0        
        //   348: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.memDC:Lcom/sun/jna/platform/win32/WinDef$HDC;
        //   351: aload_0        
        //   352: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.hBitmap:Lcom/sun/jna/platform/win32/WinDef$HBITMAP;
        //   355: invokeinterface com/sun/jna/platform/win32/GDI32.SelectObject:(Lcom/sun/jna/platform/win32/WinDef$HDC;Lcom/sun/jna/platform/win32/WinNT$HANDLE;)Lcom/sun/jna/platform/win32/WinNT$HANDLE;
        //   360: astore          15
        //   362: aload_1        
        //   363: invokevirtual   java/awt/image/BufferedImage.getData:()Ljava/awt/image/Raster;
        //   366: astore          16
        //   368: iconst_4       
        //   369: newarray        I
        //   371: astore          17
        //   373: iload           10
        //   375: newarray        I
        //   377: astore          18
        //   379: iconst_0       
        //   380: istore          19
        //   382: iload           19
        //   384: iload           11
        //   386: if_icmpge       543
        //   389: iconst_0       
        //   390: istore          20
        //   392: iload           20
        //   394: iload           10
        //   396: if_icmpge       494
        //   399: aload           16
        //   401: iload           20
        //   403: iload           19
        //   405: aload           17
        //   407: invokevirtual   java/awt/image/Raster.getPixel:(II[I)[I
        //   410: pop            
        //   411: aload           17
        //   413: iconst_3       
        //   414: iaload         
        //   415: sipush          255
        //   418: iand           
        //   419: bipush          24
        //   421: ishl           
        //   422: istore          21
        //   424: aload           17
        //   426: iconst_2       
        //   427: iaload         
        //   428: sipush          255
        //   431: iand           
        //   432: istore          22
        //   434: aload           17
        //   436: iconst_1       
        //   437: iaload         
        //   438: sipush          255
        //   441: iand           
        //   442: bipush          8
        //   444: ishl           
        //   445: istore          23
        //   447: aload           17
        //   449: iconst_0       
        //   450: iaload         
        //   451: sipush          255
        //   454: iand           
        //   455: bipush          16
        //   457: ishl           
        //   458: istore          24
        //   460: aload           18
        //   462: iload           20
        //   464: iload           21
        //   466: iload           22
        //   468: ior            
        //   469: iload           23
        //   471: ior            
        //   472: iload           24
        //   474: ior            
        //   475: iastore        
        //   476: iinc            20, 1
        //   479: aload_3        
        //   480: ifnonnull       539
        //   483: aload_3        
        //   484: ifnull          392
        //   487: goto            494
        //   490: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   493: athrow         
        //   494: iload           13
        //   496: aload           9
        //   498: getfield        java/awt/Point.y:I
        //   501: iload           19
        //   503: iadd           
        //   504: isub           
        //   505: iconst_1       
        //   506: isub           
        //   507: istore          20
        //   509: aload_0        
        //   510: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.pbits:Lcom/sun/jna/Pointer;
        //   513: iload           20
        //   515: iload           12
        //   517: imul           
        //   518: aload           9
        //   520: getfield        java/awt/Point.x:I
        //   523: iadd           
        //   524: iconst_4       
        //   525: imul           
        //   526: i2l            
        //   527: aload           18
        //   529: iconst_0       
        //   530: aload           18
        //   532: arraylength    
        //   533: invokevirtual   com/sun/jna/Pointer.write:(J[III)V
        //   536: iinc            19, 1
        //   539: aload_3        
        //   540: ifnull          382
        //   543: new             Lcom/sun/jna/platform/win32/WinUser$SIZE;
        //   546: dup            
        //   547: invokespecial   com/sun/jna/platform/win32/WinUser$SIZE.<init>:()V
        //   550: astore          19
        //   552: aload           19
        //   554: aload           4
        //   556: invokevirtual   java/awt/Window.getWidth:()I
        //   559: putfield        com/sun/jna/platform/win32/WinUser$SIZE.cx:I
        //   562: aload           19
        //   564: aload           4
        //   566: invokevirtual   java/awt/Window.getHeight:()I
        //   569: putfield        com/sun/jna/platform/win32/WinUser$SIZE.cy:I
        //   572: new             Lcom/sun/jna/platform/win32/WinDef$POINT;
        //   575: dup            
        //   576: invokespecial   com/sun/jna/platform/win32/WinDef$POINT.<init>:()V
        //   579: astore          20
        //   581: aload           20
        //   583: aload           4
        //   585: invokevirtual   java/awt/Window.getX:()I
        //   588: putfield        com/sun/jna/platform/win32/WinDef$POINT.x:I
        //   591: aload           20
        //   593: aload           4
        //   595: invokevirtual   java/awt/Window.getY:()I
        //   598: putfield        com/sun/jna/platform/win32/WinDef$POINT.y:I
        //   601: new             Lcom/sun/jna/platform/win32/WinDef$POINT;
        //   604: dup            
        //   605: invokespecial   com/sun/jna/platform/win32/WinDef$POINT.<init>:()V
        //   608: astore          21
        //   610: new             Lcom/sun/jna/platform/win32/WinUser$BLENDFUNCTION;
        //   613: dup            
        //   614: invokespecial   com/sun/jna/platform/win32/WinUser$BLENDFUNCTION.<init>:()V
        //   617: astore          22
        //   619: aload_0        
        //   620: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.this$0:Lcom/sun/jna/platform/WindowUtils$W32WindowUtils;
        //   623: aload           4
        //   625: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils.access$400:(Lcom/sun/jna/platform/WindowUtils$W32WindowUtils;Ljava/awt/Component;)Lcom/sun/jna/platform/win32/WinDef$HWND;
        //   628: astore          23
        //   630: new             Lcom/sun/jna/ptr/ByteByReference;
        //   633: dup            
        //   634: invokespecial   com/sun/jna/ptr/ByteByReference.<init>:()V
        //   637: astore          24
        //   639: new             Lcom/sun/jna/ptr/IntByReference;
        //   642: dup            
        //   643: invokespecial   com/sun/jna/ptr/IntByReference.<init>:()V
        //   646: astore          25
        //   648: aload_0        
        //   649: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.this$0:Lcom/sun/jna/platform/WindowUtils$W32WindowUtils;
        //   652: aload           4
        //   654: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils.access$700:(Lcom/sun/jna/platform/WindowUtils$W32WindowUtils;Ljava/awt/Window;)B
        //   657: istore          26
        //   659: aload           6
        //   661: aload           23
        //   663: aconst_null    
        //   664: aload           24
        //   666: aload           25
        //   668: invokeinterface com/sun/jna/platform/win32/User32.GetLayeredWindowAttributes:(Lcom/sun/jna/platform/win32/WinDef$HWND;Lcom/sun/jna/ptr/IntByReference;Lcom/sun/jna/ptr/ByteByReference;Lcom/sun/jna/ptr/IntByReference;)Z
        //   673: aload_3        
        //   674: ifnonnull       712
        //   677: aload_3        
        //   678: ifnonnull       716
        //   681: goto            688
        //   684: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   687: athrow         
        //   688: ifeq            751
        //   691: goto            698
        //   694: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   697: athrow         
        //   698: aload           25
        //   700: invokevirtual   com/sun/jna/ptr/IntByReference.getValue:()I
        //   703: iconst_2       
        //   704: iand           
        //   705: goto            712
        //   708: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   711: athrow         
        //   712: aload_3        
        //   713: ifnonnull       749
        //   716: aload_3        
        //   717: ifnonnull       749
        //   720: goto            727
        //   723: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   726: athrow         
        //   727: ifeq            751
        //   730: goto            737
        //   733: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   736: athrow         
        //   737: aload           24
        //   739: invokevirtual   com/sun/jna/ptr/ByteByReference.getValue:()B
        //   742: goto            749
        //   745: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   748: athrow         
        //   749: istore          26
        //   751: goto            756
        //   754: astore          27
        //   756: aload           22
        //   758: iload           26
        //   760: putfield        com/sun/jna/platform/win32/WinUser$BLENDFUNCTION.SourceConstantAlpha:B
        //   763: aload           22
        //   765: iconst_1       
        //   766: putfield        com/sun/jna/platform/win32/WinUser$BLENDFUNCTION.AlphaFormat:B
        //   769: aload           6
        //   771: aload           23
        //   773: aload           14
        //   775: aload           20
        //   777: aload           19
        //   779: aload_0        
        //   780: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.memDC:Lcom/sun/jna/platform/win32/WinDef$HDC;
        //   783: aload           21
        //   785: iconst_0       
        //   786: aload           22
        //   788: iconst_2       
        //   789: invokeinterface com/sun/jna/platform/win32/User32.UpdateLayeredWindow:(Lcom/sun/jna/platform/win32/WinDef$HWND;Lcom/sun/jna/platform/win32/WinDef$HDC;Lcom/sun/jna/platform/win32/WinDef$POINT;Lcom/sun/jna/platform/win32/WinUser$SIZE;Lcom/sun/jna/platform/win32/WinDef$HDC;Lcom/sun/jna/platform/win32/WinDef$POINT;ILcom/sun/jna/platform/win32/WinUser$BLENDFUNCTION;I)Z
        //   794: pop            
        //   795: aload           6
        //   797: aconst_null    
        //   798: aload           14
        //   800: invokeinterface com/sun/jna/platform/win32/User32.ReleaseDC:(Lcom/sun/jna/platform/win32/WinDef$HWND;Lcom/sun/jna/platform/win32/WinDef$HDC;)I
        //   805: pop            
        //   806: aload_0        
        //   807: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.memDC:Lcom/sun/jna/platform/win32/WinDef$HDC;
        //   810: aload_3        
        //   811: ifnonnull       830
        //   814: aload_3        
        //   815: ifnonnull       834
        //   818: ifnull          972
        //   821: goto            828
        //   824: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   827: athrow         
        //   828: aload           15
        //   830: aload_3        
        //   831: ifnonnull       875
        //   834: aload_3        
        //   835: ifnonnull       875
        //   838: goto            845
        //   841: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   844: athrow         
        //   845: ifnull          972
        //   848: goto            855
        //   851: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   854: athrow         
        //   855: aload           5
        //   857: aload_0        
        //   858: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.memDC:Lcom/sun/jna/platform/win32/WinDef$HDC;
        //   861: aload           15
        //   863: invokeinterface com/sun/jna/platform/win32/GDI32.SelectObject:(Lcom/sun/jna/platform/win32/WinDef$HDC;Lcom/sun/jna/platform/win32/WinNT$HANDLE;)Lcom/sun/jna/platform/win32/WinNT$HANDLE;
        //   868: goto            875
        //   871: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   874: athrow         
        //   875: pop            
        //   876: goto            972
        //   879: astore          28
        //   881: aload           6
        //   883: aconst_null    
        //   884: aload           14
        //   886: invokeinterface com/sun/jna/platform/win32/User32.ReleaseDC:(Lcom/sun/jna/platform/win32/WinDef$HWND;Lcom/sun/jna/platform/win32/WinDef$HDC;)I
        //   891: pop            
        //   892: aload_0        
        //   893: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.memDC:Lcom/sun/jna/platform/win32/WinDef$HDC;
        //   896: aload_3        
        //   897: ifnonnull       923
        //   900: aload_3        
        //   901: ifnonnull       927
        //   904: goto            911
        //   907: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   910: athrow         
        //   911: ifnull          969
        //   914: goto            921
        //   917: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   920: athrow         
        //   921: aload           15
        //   923: aload_3        
        //   924: ifnonnull       968
        //   927: aload_3        
        //   928: ifnonnull       968
        //   931: goto            938
        //   934: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   937: athrow         
        //   938: ifnull          969
        //   941: goto            948
        //   944: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   947: athrow         
        //   948: aload           5
        //   950: aload_0        
        //   951: getfield        com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.memDC:Lcom/sun/jna/platform/win32/WinDef$HDC;
        //   954: aload           15
        //   956: invokeinterface com/sun/jna/platform/win32/GDI32.SelectObject:(Lcom/sun/jna/platform/win32/WinDef$HDC;Lcom/sun/jna/platform/win32/WinNT$HANDLE;)Lcom/sun/jna/platform/win32/WinNT$HANDLE;
        //   961: goto            968
        //   964: invokestatic    com/sun/jna/platform/WindowUtils$W32WindowUtils$W32TransparentContentPane.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   967: athrow         
        //   968: pop            
        //   969: aload           28
        //   971: athrow         
        //   972: return         
        //    StackMapTable: 00 41 FF 00 61 00 10 07 00 4A 07 00 74 07 00 75 07 00 7A 07 00 76 07 00 66 07 00 77 01 01 07 00 78 01 01 01 01 07 00 52 05 00 01 07 00 45 03 43 07 00 45 43 07 00 4A 0B 44 07 00 4A 4C 07 00 45 03 51 07 00 45 03 47 07 00 45 43 07 00 4A 45 07 00 45 43 07 00 55 52 07 00 45 43 07 00 4A 03 FB 00 82 FF 00 24 00 14 07 00 4A 07 00 74 07 00 75 07 00 7A 07 00 76 07 00 66 07 00 77 01 01 07 00 78 01 01 01 01 07 00 52 07 00 73 07 00 79 07 00 7A 07 00 7A 01 00 00 FC 00 09 01 FF 00 61 00 19 07 00 4A 07 00 74 07 00 75 07 00 7A 07 00 76 07 00 66 07 00 77 01 01 07 00 78 01 01 01 01 07 00 52 07 00 73 07 00 79 07 00 7A 07 00 7A 01 01 01 01 01 01 00 01 07 00 45 FF 00 03 00 15 07 00 4A 07 00 74 07 00 75 07 00 7A 07 00 76 07 00 66 07 00 77 01 01 07 00 78 01 01 01 01 07 00 52 07 00 73 07 00 79 07 00 7A 07 00 7A 01 01 00 00 2C FA 00 03 FF 00 8C 00 1B 07 00 4A 07 00 74 07 00 75 07 00 7A 07 00 76 07 00 66 07 00 77 01 01 07 00 78 01 01 01 01 07 00 52 07 00 73 07 00 79 07 00 7A 07 00 7A 07 00 30 07 00 34 07 00 34 07 00 3A 07 00 6E 07 00 3D 07 00 3F 01 00 01 07 00 45 43 01 45 07 00 45 03 49 07 00 45 43 01 43 01 46 07 00 45 43 01 45 07 00 45 03 47 07 00 45 43 01 01 42 07 00 45 01 F7 00 43 07 00 45 03 41 07 00 73 43 07 00 73 46 07 00 45 43 07 00 73 45 07 00 45 03 4F 07 00 45 43 07 00 73 FF 00 03 00 10 07 00 4A 07 00 74 07 00 75 07 00 7A 07 00 76 07 00 66 07 00 77 01 01 07 00 78 01 01 01 01 07 00 52 07 00 73 00 01 07 00 7B FF 00 1B 00 1D 07 00 4A 07 00 74 07 00 75 07 00 7A 07 00 76 07 00 66 07 00 77 01 01 07 00 78 01 01 01 01 07 00 52 07 00 73 00 00 00 00 00 00 00 00 00 00 00 00 07 00 7B 00 01 07 00 45 43 07 00 52 45 07 00 45 03 41 07 00 73 43 07 00 73 46 07 00 45 43 07 00 73 45 07 00 45 03 4F 07 00 45 43 07 00 73 00 FF 00 02 00 01 07 00 4A 00 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  727    742    745    749    Ljava/lang/UnsatisfiedLinkError;
        //  716    730    733    737    Ljava/lang/UnsatisfiedLinkError;
        //  712    720    723    727    Ljava/lang/UnsatisfiedLinkError;
        //  688    705    708    712    Ljava/lang/UnsatisfiedLinkError;
        //  677    691    694    698    Ljava/lang/UnsatisfiedLinkError;
        //  659    681    684    688    Ljava/lang/UnsatisfiedLinkError;
        //  460    487    490    494    Ljava/lang/UnsatisfiedLinkError;
        //  187    203    206    210    Ljava/lang/UnsatisfiedLinkError;
        //  165    180    183    187    Ljava/lang/UnsatisfiedLinkError;
        //  143    170    173    177    Ljava/lang/UnsatisfiedLinkError;
        //  133    158    161    165    Ljava/lang/UnsatisfiedLinkError;
        //  126    136    139    143    Ljava/lang/UnsatisfiedLinkError;
        //  88     102    105    109    Ljava/lang/UnsatisfiedLinkError;
        //  83     94     97     101    Ljava/lang/UnsatisfiedLinkError;
        //  659    751    754    756    Ljava/lang/UnsatisfiedLinkError;
        //  83     795    879    972    Any
        //  845    868    871    875    Ljava/lang/UnsatisfiedLinkError;
        //  834    848    851    855    Ljava/lang/UnsatisfiedLinkError;
        //  830    838    841    845    Ljava/lang/UnsatisfiedLinkError;
        //  814    821    824    828    Ljava/lang/UnsatisfiedLinkError;
        //  879    881    879    972    Any
        //  881    904    907    911    Ljava/lang/UnsatisfiedLinkError;
        //  900    914    917    921    Ljava/lang/UnsatisfiedLinkError;
        //  923    931    934    938    Ljava/lang/UnsatisfiedLinkError;
        //  927    941    944    948    Ljava/lang/UnsatisfiedLinkError;
        //  938    961    964    968    Ljava/lang/UnsatisfiedLinkError;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0143:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static Throwable b(final Throwable t) {
        return t;
    }
}
