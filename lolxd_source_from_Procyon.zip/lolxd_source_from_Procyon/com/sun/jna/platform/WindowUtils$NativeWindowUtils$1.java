// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;

class WindowUtils$NativeWindowUtils$1 extends WindowAdapter
{
    final Runnable val$action;
    final WindowUtils$NativeWindowUtils this$0;
    
    WindowUtils$NativeWindowUtils$1(final WindowUtils$NativeWindowUtils this$0, final Runnable val$action) {
        this.this$0 = this$0;
        this.val$action = val$action;
    }
    
    @Override
    public void windowOpened(final WindowEvent windowEvent) {
        windowEvent.getWindow().removeWindowListener(this);
        this.val$action.run();
    }
    
    @Override
    public void windowClosed(final WindowEvent windowEvent) {
        windowEvent.getWindow().removeWindowListener(this);
    }
}
