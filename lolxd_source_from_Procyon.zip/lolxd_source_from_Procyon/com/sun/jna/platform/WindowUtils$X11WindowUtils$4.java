// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import com.sun.jna.platform.unix.X11$Window;
import com.sun.jna.platform.unix.X11$Display;
import com.sun.jna.platform.unix.X11$Pixmap;
import com.sun.jna.platform.unix.X11$Xext;
import java.awt.Component;
import com.sun.jna.platform.unix.X11;
import java.awt.Window;

class WindowUtils$X11WindowUtils$4 implements Runnable
{
    final Window val$w;
    final WindowUtils$X11WindowUtils$PixmapSource val$src;
    final WindowUtils$X11WindowUtils this$0;
    
    WindowUtils$X11WindowUtils$4(final WindowUtils$X11WindowUtils this$0, final Window val$w, final WindowUtils$X11WindowUtils$PixmapSource val$src) {
        this.this$0 = this$0;
        this.val$w = val$w;
        this.val$src = val$src;
    }
    
    @Override
    public void run() {
        final X11 instance = X11.INSTANCE;
        final int[] b = WindowUtils$NativeWindowUtils.b();
        final X11$Display xOpenDisplay = instance.XOpenDisplay(null);
        final int[] array = b;
        try {
            if (xOpenDisplay == null) {
                return;
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
        X11$Pixmap pixmap = null;
        try {
            final X11$Window access$800 = WindowUtils$X11WindowUtils.access$800(this.val$w);
            pixmap = this.val$src.getPixmap(xOpenDisplay, access$800);
            final X11$Xext instance2 = X11$Xext.INSTANCE;
            X11$Xext x11$Xext = null;
            X11$Display x11$Display = null;
            X11$Window x11$Window = null;
            int n = 0;
            int n2 = 0;
            int n3 = 0;
            X11$Pixmap x11$Pixmap = null;
            Label_0097: {
                Label_0094: {
                    Label_0081: {
                        try {
                            x11$Xext = instance2;
                            x11$Display = xOpenDisplay;
                            x11$Window = access$800;
                            n = 0;
                            n2 = 0;
                            n3 = 0;
                            x11$Pixmap = pixmap;
                            if (array != null) {
                                break Label_0094;
                            }
                            final int[] array2 = array;
                            if (array2 == null) {
                                break Label_0081;
                            }
                            break Label_0094;
                        }
                        catch (RuntimeException ex2) {
                            throw b(ex2);
                        }
                        try {
                            final int[] array2 = array;
                            if (array2 != null) {
                                break Label_0094;
                            }
                            if (x11$Pixmap != null) {
                                break Label_0097;
                            }
                        }
                        catch (RuntimeException ex3) {
                            throw b(ex3);
                        }
                    }
                    final X11$Pixmap none = X11$Pixmap.None;
                }
                break Label_0097;
            }
            x11$Xext.XShapeCombineMask(x11$Display, x11$Window, n, n2, n3, x11$Pixmap, 0);
            if (array == null) {
                try {
                    if (pixmap != null) {
                        instance.XFreePixmap(xOpenDisplay, pixmap);
                    }
                }
                catch (RuntimeException ex4) {
                    throw b(ex4);
                }
                while (true) {
                    instance.XCloseDisplay(xOpenDisplay);
                    if (array != null) {
                        continue;
                    }
                    break;
                }
            }
        }
        finally {
            Label_0193: {
                while (true) {
                    Label_0164: {
                        try {
                            if (array != null) {
                                break Label_0193;
                            }
                            final X11$Pixmap x11$Pixmap2 = pixmap;
                            if (x11$Pixmap2 != null) {
                                break Label_0164;
                            }
                            break Label_0180;
                        }
                        catch (RuntimeException ex5) {
                            throw b(ex5);
                        }
                        try {
                            final X11$Pixmap x11$Pixmap2 = pixmap;
                            if (x11$Pixmap2 != null) {
                                instance.XFreePixmap(xOpenDisplay, pixmap);
                            }
                        }
                        catch (RuntimeException ex6) {
                            throw b(ex6);
                        }
                    }
                    instance.XCloseDisplay(xOpenDisplay);
                    if (array != null) {
                        continue;
                    }
                    break;
                }
            }
        }
        WindowUtils$X11WindowUtils this$0 = null;
        Window window = null;
        boolean b2 = false;
        Label_0225: {
            try {
                this$0 = this.this$0;
                window = this.this$0.getWindow(this.val$w);
                if (pixmap != null) {
                    b2 = true;
                    break Label_0225;
                }
            }
            catch (RuntimeException ex7) {
                throw b(ex7);
            }
            b2 = false;
        }
        this$0.setForceHeavyweightPopups(window, b2);
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
