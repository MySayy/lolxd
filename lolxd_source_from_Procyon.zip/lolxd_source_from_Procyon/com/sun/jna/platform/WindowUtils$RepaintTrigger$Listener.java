// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.AWTEvent;
import java.awt.event.HierarchyEvent;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowEvent;
import java.awt.event.AWTEventListener;
import java.awt.event.HierarchyListener;
import java.awt.event.ComponentListener;
import java.awt.event.WindowAdapter;

public class WindowUtils$RepaintTrigger$Listener extends WindowAdapter implements ComponentListener, HierarchyListener, AWTEventListener
{
    final WindowUtils$RepaintTrigger this$0;
    
    protected WindowUtils$RepaintTrigger$Listener(final WindowUtils$RepaintTrigger this$0) {
        this.this$0 = this$0;
    }
    
    @Override
    public void windowOpened(final WindowEvent windowEvent) {
        this.this$0.repaint();
    }
    
    @Override
    public void componentHidden(final ComponentEvent componentEvent) {
    }
    
    @Override
    public void componentMoved(final ComponentEvent componentEvent) {
    }
    
    @Override
    public void componentResized(final ComponentEvent componentEvent) {
        this.this$0.setSize(this.this$0.getParent().getSize());
        this.this$0.repaint();
    }
    
    @Override
    public void componentShown(final ComponentEvent componentEvent) {
        this.this$0.repaint();
    }
    
    @Override
    public void hierarchyChanged(final HierarchyEvent hierarchyEvent) {
        this.this$0.repaint();
    }
    
    @Override
    public void eventDispatched(final AWTEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_1        
        //     5: aload_2        
        //     6: ifnonnull       41
        //     9: aload_2        
        //    10: ifnonnull       41
        //    13: goto            20
        //    16: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger$Listener.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    19: athrow         
        //    20: instanceof      Ljava/awt/event/MouseEvent;
        //    23: ifeq            180
        //    26: goto            33
        //    29: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger$Listener.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    32: athrow         
        //    33: aload_1        
        //    34: goto            41
        //    37: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger$Listener.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    40: athrow         
        //    41: checkcast       Ljava/awt/event/MouseEvent;
        //    44: invokevirtual   java/awt/event/MouseEvent.getComponent:()Ljava/awt/Component;
        //    47: astore_3       
        //    48: aload_3        
        //    49: aload_2        
        //    50: ifnonnull       75
        //    53: aload_2        
        //    54: ifnonnull       79
        //    57: goto            64
        //    60: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger$Listener.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    63: athrow         
        //    64: ifnull          180
        //    67: goto            74
        //    70: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger$Listener.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    73: athrow         
        //    74: aload_3        
        //    75: aload_2        
        //    76: ifnonnull       118
        //    79: aload_2        
        //    80: ifnonnull       118
        //    83: goto            90
        //    86: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger$Listener.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    89: athrow         
        //    90: aload_0        
        //    91: getfield        com/sun/jna/platform/WindowUtils$RepaintTrigger$Listener.this$0:Lcom/sun/jna/platform/WindowUtils$RepaintTrigger;
        //    94: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger.access$000:(Lcom/sun/jna/platform/WindowUtils$RepaintTrigger;)Ljavax/swing/JComponent;
        //    97: invokestatic    javax/swing/SwingUtilities.isDescendingFrom:(Ljava/awt/Component;Ljava/awt/Component;)Z
        //   100: ifeq            180
        //   103: goto            110
        //   106: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger$Listener.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   109: athrow         
        //   110: aload_3        
        //   111: goto            118
        //   114: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger$Listener.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   117: athrow         
        //   118: aload_1        
        //   119: checkcast       Ljava/awt/event/MouseEvent;
        //   122: aload_0        
        //   123: getfield        com/sun/jna/platform/WindowUtils$RepaintTrigger$Listener.this$0:Lcom/sun/jna/platform/WindowUtils$RepaintTrigger;
        //   126: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger.access$000:(Lcom/sun/jna/platform/WindowUtils$RepaintTrigger;)Ljavax/swing/JComponent;
        //   129: invokestatic    javax/swing/SwingUtilities.convertMouseEvent:(Ljava/awt/Component;Ljava/awt/event/MouseEvent;Ljava/awt/Component;)Ljava/awt/event/MouseEvent;
        //   132: astore          4
        //   134: aload_0        
        //   135: getfield        com/sun/jna/platform/WindowUtils$RepaintTrigger$Listener.this$0:Lcom/sun/jna/platform/WindowUtils$RepaintTrigger;
        //   138: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger.access$000:(Lcom/sun/jna/platform/WindowUtils$RepaintTrigger;)Ljavax/swing/JComponent;
        //   141: aload           4
        //   143: invokevirtual   java/awt/event/MouseEvent.getX:()I
        //   146: aload           4
        //   148: invokevirtual   java/awt/event/MouseEvent.getY:()I
        //   151: invokestatic    javax/swing/SwingUtilities.getDeepestComponentAt:(Ljava/awt/Component;II)Ljava/awt/Component;
        //   154: astore          5
        //   156: aload           5
        //   158: ifnull          180
        //   161: aload_0        
        //   162: getfield        com/sun/jna/platform/WindowUtils$RepaintTrigger$Listener.this$0:Lcom/sun/jna/platform/WindowUtils$RepaintTrigger;
        //   165: aload           5
        //   167: invokevirtual   java/awt/Component.getCursor:()Ljava/awt/Cursor;
        //   170: invokevirtual   com/sun/jna/platform/WindowUtils$RepaintTrigger.setCursor:(Ljava/awt/Cursor;)V
        //   173: goto            180
        //   176: invokestatic    com/sun/jna/platform/WindowUtils$RepaintTrigger$Listener.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   179: athrow         
        //   180: return         
        //    StackMapTable: 00 14 FF 00 10 00 03 07 00 11 07 00 6C 07 00 6E 00 01 07 00 67 43 07 00 6C 48 07 00 67 03 43 07 00 67 43 07 00 6C FF 00 12 00 04 07 00 11 07 00 6C 07 00 6E 07 00 3C 00 01 07 00 67 43 07 00 3C 45 07 00 67 03 40 07 00 3C 43 07 00 3C 46 07 00 67 43 07 00 3C 4F 07 00 67 03 43 07 00 67 43 07 00 3C FF 00 39 00 06 07 00 11 07 00 6C 07 00 6E 07 00 3C 07 00 07 07 00 3C 00 01 07 00 67 F8 00 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      13     16     20     Ljava/lang/RuntimeException;
        //  9      26     29     33     Ljava/lang/RuntimeException;
        //  20     34     37     41     Ljava/lang/RuntimeException;
        //  48     57     60     64     Ljava/lang/RuntimeException;
        //  53     67     70     74     Ljava/lang/RuntimeException;
        //  75     83     86     90     Ljava/lang/RuntimeException;
        //  79     103    106    110    Ljava/lang/RuntimeException;
        //  90     111    114    118    Ljava/lang/RuntimeException;
        //  156    173    176    180    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
