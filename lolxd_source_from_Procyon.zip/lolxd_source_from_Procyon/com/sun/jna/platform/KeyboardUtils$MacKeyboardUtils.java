// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

class KeyboardUtils$MacKeyboardUtils extends KeyboardUtils$NativeKeyboardUtils
{
    private KeyboardUtils$MacKeyboardUtils() {
        super(null);
    }
    
    @Override
    public boolean isPressed(final int n, final int n2) {
        return false;
    }
    
    KeyboardUtils$MacKeyboardUtils(final KeyboardUtils$1 keyboardUtils$1) {
        this();
    }
}
