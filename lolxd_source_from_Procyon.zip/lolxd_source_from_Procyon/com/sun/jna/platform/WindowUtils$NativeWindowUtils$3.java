// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.Shape;
import java.awt.Rectangle;
import java.awt.geom.Area;

class WindowUtils$NativeWindowUtils$3 implements RasterRangesUtils$RangesOutput
{
    final Area val$area;
    final WindowUtils$NativeWindowUtils this$0;
    
    WindowUtils$NativeWindowUtils$3(final WindowUtils$NativeWindowUtils this$0, final Area val$area) {
        this.this$0 = this$0;
        this.val$area = val$area;
    }
    
    @Override
    public boolean outputRange(final int x, final int y, final int width, final int height) {
        this.val$area.add(new Area(new Rectangle(x, y, width, height)));
        return true;
    }
}
