// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.io.IOException;
import java.io.File;

public abstract class FileUtils
{
    public boolean hasTrash() {
        return false;
    }
    
    public abstract void moveToTrash(final File[] p0) throws IOException;
    
    public static FileUtils getInstance() {
        return FileUtils$Holder.INSTANCE;
    }
}
