// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import com.sun.jna.platform.unix.X11$Pixmap;
import com.sun.jna.platform.unix.X11$Window;
import com.sun.jna.platform.unix.X11$Display;
import java.awt.image.Raster;

class WindowUtils$X11WindowUtils$5 implements WindowUtils$X11WindowUtils$PixmapSource
{
    final Raster val$raster;
    final WindowUtils$X11WindowUtils this$0;
    
    WindowUtils$X11WindowUtils$5(final WindowUtils$X11WindowUtils this$0, final Raster val$raster) {
        this.this$0 = this$0;
        this.val$raster = val$raster;
    }
    
    @Override
    public X11$Pixmap getPixmap(final X11$Display x11$Display, final X11$Window x11$Window) {
        try {
            if (this.val$raster != null) {
                return WindowUtils$X11WindowUtils.access$1000(x11$Display, x11$Window, this.val$raster);
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
        return null;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
