// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;

class WindowUtils$NativeWindowUtils$2 implements HierarchyListener
{
    final Runnable val$action;
    final WindowUtils$NativeWindowUtils this$0;
    
    WindowUtils$NativeWindowUtils$2(final WindowUtils$NativeWindowUtils this$0, final Runnable val$action) {
        this.this$0 = this$0;
        this.val$action = val$action;
    }
    
    @Override
    public void hierarchyChanged(final HierarchyEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_1        
        //     5: invokevirtual   java/awt/event/HierarchyEvent.getChangeFlags:()J
        //     8: ldc2_w          2
        //    11: land           
        //    12: lconst_0       
        //    13: lcmp           
        //    14: aload_2        
        //    15: ifnonnull       75
        //    18: aload_2        
        //    19: ifnonnull       75
        //    22: goto            29
        //    25: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$2.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    28: athrow         
        //    29: ifeq            102
        //    32: goto            39
        //    35: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$2.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    38: athrow         
        //    39: aload_1        
        //    40: invokevirtual   java/awt/event/HierarchyEvent.getComponent:()Ljava/awt/Component;
        //    43: aload_2        
        //    44: ifnonnull       89
        //    47: goto            54
        //    50: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$2.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    53: athrow         
        //    54: aload_2        
        //    55: ifnonnull       89
        //    58: goto            65
        //    61: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$2.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    64: athrow         
        //    65: invokevirtual   java/awt/Component.isDisplayable:()Z
        //    68: goto            75
        //    71: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$2.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    74: athrow         
        //    75: ifeq            102
        //    78: aload_1        
        //    79: invokevirtual   java/awt/event/HierarchyEvent.getComponent:()Ljava/awt/Component;
        //    82: goto            89
        //    85: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$2.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    88: athrow         
        //    89: aload_0        
        //    90: invokevirtual   java/awt/Component.removeHierarchyListener:(Ljava/awt/event/HierarchyListener;)V
        //    93: aload_0        
        //    94: getfield        com/sun/jna/platform/WindowUtils$NativeWindowUtils$2.val$action:Ljava/lang/Runnable;
        //    97: invokeinterface java/lang/Runnable.run:()V
        //   102: return         
        //    StackMapTable: 00 0D FF 00 19 00 03 07 00 0C 07 00 05 07 00 42 00 01 07 00 3D 43 01 45 07 00 3D 03 4A 07 00 3D 43 07 00 24 46 07 00 3D 43 07 00 24 45 07 00 3D 43 01 49 07 00 3D 43 07 00 24 0C
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      22     25     29     Ljava/lang/RuntimeException;
        //  18     32     35     39     Ljava/lang/RuntimeException;
        //  29     47     50     54     Ljava/lang/RuntimeException;
        //  39     58     61     65     Ljava/lang/RuntimeException;
        //  54     68     71     75     Ljava/lang/RuntimeException;
        //  75     82     85     89     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0029:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
