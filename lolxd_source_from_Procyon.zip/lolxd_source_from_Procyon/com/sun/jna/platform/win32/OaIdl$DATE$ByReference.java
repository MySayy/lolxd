// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Structure$ByReference;

public class OaIdl$DATE$ByReference extends OaIdl$DATE implements Structure$ByReference
{
}
