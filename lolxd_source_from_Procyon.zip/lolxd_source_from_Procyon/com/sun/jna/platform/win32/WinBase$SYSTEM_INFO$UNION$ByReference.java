// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Structure$ByReference;

public class WinBase$SYSTEM_INFO$UNION$ByReference extends WinBase$SYSTEM_INFO$UNION implements Structure$ByReference
{
}
