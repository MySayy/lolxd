// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public interface DBT
{
    public static final int DBT_NO_DISK_SPACE = 71;
    public static final int DBT_LOW_DISK_SPACE = 72;
    public static final int DBT_CONFIGMGPRIVATE = 32767;
    public static final int DBT_DEVICEARRIVAL = 32768;
    public static final int DBT_DEVICEQUERYREMOVE = 32769;
    public static final int DBT_DEVICEQUERYREMOVEFAILED = 32770;
    public static final int DBT_DEVICEREMOVEPENDING = 32771;
    public static final int DBT_DEVICEREMOVECOMPLETE = 32772;
    public static final int DBT_DEVNODES_CHANGED = 7;
    public static final int DBT_DEVICETYPESPECIFIC = 32773;
    public static final int DBT_CUSTOMEVENT = 32774;
    public static final Guid$GUID GUID_DEVINTERFACE_USB_DEVICE = new Guid$GUID(array2[1]);
    public static final Guid$GUID GUID_DEVINTERFACE_HID = new Guid$GUID(array2[4]);
    public static final Guid$GUID GUID_DEVINTERFACE_VOLUME = new Guid$GUID(array2[2]);
    public static final Guid$GUID GUID_DEVINTERFACE_KEYBOARD = new Guid$GUID(array2[0]);
    public static final Guid$GUID GUID_DEVINTERFACE_MOUSE = new Guid$GUID(array2[3]);
    public static final int DBT_DEVTYP_OEM = 0;
    public static final int DBT_DEVTYP_DEVNODE = 1;
    public static final int DBT_DEVTYP_VOLUME = 2;
    public static final int DBT_DEVTYP_PORT = 3;
    public static final int DBT_DEVTYP_NET = 4;
    public static final int DBT_DEVTYP_DEVICEINTERFACE = 5;
    public static final int DBT_DEVTYP_HANDLE = 6;
    public static final int DBTF_MEDIA = 1;
    public static final int DBTF_NET = 2;
    
    default static {
        final String[] array = new String[5];
        int n = 0;
        String s;
        int n2 = (s = "wHwI\u0018d/oCbHL8\u007f!A~\u0019Kp{oH,PJmx<\u0013vLNm,h\u00142&w1z99\u001f_=@bKOn)!A~9Hp <A\tPJmZ<D\t?Ch(I42&wE|;Ok*<4b?L\u001f_!A~9Jp 86}PJmX<3vL?\u001b[422").length();
        int n3 = 38;
        int n4 = -1;
    Label_0023:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 42));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0252: {
                            if (length > 1) {
                                break Label_0252;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 38;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 90;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 101;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 87;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 80;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 119;
                                        break;
                                    }
                                    default: {
                                        n11 = 51;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0023;
                            }
                            n2 = (s = "ZnUh\u00135\u0000\u0015\u001eOea5r\flS\u0014f]vbe!}g@u\u0011\u001e[ac@\u0001e\u0019\u001f&Zi&a\u0012E\u0001coO\u0016fFr\flS\u0013\u0011]\f\u0019\u001e }g@\u0005\u0010lS`g@\u0004\u0012m\u001f").length();
                            n3 = 38;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0023;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 7)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
    }
}
