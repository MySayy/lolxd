// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.ptr.ByReference;

public class OaIdl$MEMBERIDByReference extends ByReference
{
    public OaIdl$MEMBERIDByReference() {
        this(new OaIdl$MEMBERID(0));
    }
    
    public OaIdl$MEMBERIDByReference(final OaIdl$MEMBERID value) {
        super(OaIdl$MEMBERID.SIZE);
        this.setValue(value);
    }
    
    public void setValue(final OaIdl$MEMBERID oaIdl$MEMBERID) {
        this.getPointer().setInt(0L, oaIdl$MEMBERID.intValue());
    }
    
    public OaIdl$MEMBERID getValue() {
        return new OaIdl$MEMBERID(this.getPointer().getInt(0L));
    }
}
