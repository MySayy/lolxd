// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public interface LMCons
{
    public static final int NETBIOS_NAME_LEN = 16;
    public static final int MAX_PREFERRED_LENGTH = -1;
}
