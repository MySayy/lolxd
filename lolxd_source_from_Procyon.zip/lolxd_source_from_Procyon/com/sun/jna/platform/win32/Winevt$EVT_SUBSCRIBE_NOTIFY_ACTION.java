// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public interface Winevt$EVT_SUBSCRIBE_NOTIFY_ACTION
{
    public static final int EvtSubscribeActionError = 0;
    public static final int EvtSubscribeActionDeliver = 1;
}
