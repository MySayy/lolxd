// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public class Netapi32Util$DomainTrust
{
    public String NetbiosDomainName;
    public String DnsDomainName;
    public WinNT$PSID DomainSid;
    public String DomainSidString;
    public Guid$GUID DomainGuid;
    public String DomainGuidString;
    private int flags;
    
    public boolean isInForest() {
        final boolean c = WinNT$HANDLE.c();
        int n = 0;
        Label_0039: {
            Label_0025: {
                try {
                    n = (this.flags & 0x1);
                    if (!c) {
                        return n != 0;
                    }
                    final boolean b = c;
                    if (b) {
                        break Label_0025;
                    }
                    return n != 0;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final boolean b = c;
                    if (!b) {
                        return n != 0;
                    }
                    if (n == 0) {
                        break Label_0039;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            return n != 0;
        }
        return n != 0;
    }
    
    public boolean isOutbound() {
        final boolean c = WinNT$HANDLE.c();
        int n = 0;
        Label_0039: {
            Label_0025: {
                try {
                    n = (this.flags & 0x2);
                    if (!c) {
                        return n != 0;
                    }
                    final boolean b = c;
                    if (b) {
                        break Label_0025;
                    }
                    return n != 0;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final boolean b = c;
                    if (!b) {
                        return n != 0;
                    }
                    if (n == 0) {
                        break Label_0039;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            return n != 0;
        }
        return n != 0;
    }
    
    public boolean isRoot() {
        final boolean c = WinNT$HANDLE.c();
        int n = 0;
        Label_0039: {
            Label_0025: {
                try {
                    n = (this.flags & 0x4);
                    if (!c) {
                        return n != 0;
                    }
                    final boolean b = c;
                    if (b) {
                        break Label_0025;
                    }
                    return n != 0;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final boolean b = c;
                    if (!b) {
                        return n != 0;
                    }
                    if (n == 0) {
                        break Label_0039;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            return n != 0;
        }
        return n != 0;
    }
    
    public boolean isPrimary() {
        final boolean c = WinNT$HANDLE.c();
        int n = 0;
        Label_0040: {
            Label_0026: {
                try {
                    n = (this.flags & 0x8);
                    if (!c) {
                        return n != 0;
                    }
                    final boolean b = c;
                    if (b) {
                        break Label_0026;
                    }
                    return n != 0;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final boolean b = c;
                    if (!b) {
                        return n != 0;
                    }
                    if (n == 0) {
                        break Label_0040;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            return n != 0;
        }
        return n != 0;
    }
    
    public boolean isNativeMode() {
        final boolean c = WinNT$HANDLE.c();
        int n = 0;
        Label_0040: {
            Label_0026: {
                try {
                    n = (this.flags & 0x10);
                    if (!c) {
                        return n != 0;
                    }
                    final boolean b = c;
                    if (b) {
                        break Label_0026;
                    }
                    return n != 0;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final boolean b = c;
                    if (!b) {
                        return n != 0;
                    }
                    if (n == 0) {
                        break Label_0040;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            return n != 0;
        }
        return n != 0;
    }
    
    public boolean isInbound() {
        final boolean c = WinNT$HANDLE.c();
        int n = 0;
        Label_0040: {
            Label_0026: {
                try {
                    n = (this.flags & 0x20);
                    if (!c) {
                        return n != 0;
                    }
                    final boolean b = c;
                    if (b) {
                        break Label_0026;
                    }
                    return n != 0;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final boolean b = c;
                    if (!b) {
                        return n != 0;
                    }
                    if (n == 0) {
                        break Label_0040;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            return n != 0;
        }
        return n != 0;
    }
    
    static int access$002(final Netapi32Util$DomainTrust netapi32Util$DomainTrust, final int flags) {
        return netapi32Util$DomainTrust.flags = flags;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
