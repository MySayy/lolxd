// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Structure$ByReference;

public class OaIdl$IDLDESC$ByReference extends OaIdl$IDLDESC implements Structure$ByReference
{
    public OaIdl$IDLDESC$ByReference() {
    }
    
    public OaIdl$IDLDESC$ByReference(final OaIdl$IDLDESC oaIdl$IDLDESC) {
        super(oaIdl$IDLDESC.dwReserved, oaIdl$IDLDESC.wIDLFlags);
    }
}
