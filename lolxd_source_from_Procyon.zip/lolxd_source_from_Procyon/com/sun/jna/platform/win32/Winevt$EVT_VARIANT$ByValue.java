// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import com.sun.jna.Structure$ByValue;

public class Winevt$EVT_VARIANT$ByValue extends Winevt$EVT_VARIANT implements Structure$ByValue
{
    public Winevt$EVT_VARIANT$ByValue(final Pointer pointer) {
        super(pointer);
    }
    
    public Winevt$EVT_VARIANT$ByValue() {
    }
}
