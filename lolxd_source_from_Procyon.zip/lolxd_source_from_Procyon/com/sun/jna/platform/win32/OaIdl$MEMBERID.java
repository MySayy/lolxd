// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public class OaIdl$MEMBERID extends OaIdl$DISPID
{
    private static final long serialVersionUID = 1L;
    
    public OaIdl$MEMBERID() {
        this(0);
    }
    
    public OaIdl$MEMBERID(final int n) {
        super(n);
    }
}
