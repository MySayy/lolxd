// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.IntegerType;

public class WinDef$USHORT extends IntegerType implements Comparable<WinDef$USHORT>
{
    public static final int SIZE = 2;
    
    public WinDef$USHORT() {
        this(0L);
    }
    
    public WinDef$USHORT(final long n) {
        super(2, n, true);
    }
    
    @Override
    public int compareTo(final WinDef$USHORT winDef$USHORT) {
        return IntegerType.compare(this, winDef$USHORT);
    }
}
