// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Union;

public class WinNT$LARGE_INTEGER$UNION extends Union
{
    public WinNT$LARGE_INTEGER$LowHigh lh;
    public long value;
    
    public WinNT$LARGE_INTEGER$UNION() {
    }
    
    public WinNT$LARGE_INTEGER$UNION(final long value) {
        this.value = value;
        this.lh = new WinNT$LARGE_INTEGER$LowHigh(value);
    }
    
    public long longValue() {
        return this.value;
    }
    
    @Override
    public String toString() {
        return Long.toString(this.longValue());
    }
}
