// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import com.sun.jna.win32.W32APITypeMapper;
import java.util.List;
import com.sun.jna.Structure;

public class Winnetwk$NETRESOURCE extends Structure
{
    public static final List<String> FIELDS;
    public int dwScope;
    public int dwType;
    public int dwDisplayType;
    public int dwUsage;
    public String lpLocalName;
    public String lpRemoteName;
    public String lpComment;
    public String lpProvider;
    
    public Winnetwk$NETRESOURCE() {
        super(W32APITypeMapper.DEFAULT);
    }
    
    public Winnetwk$NETRESOURCE(final Pointer pointer) {
        super(pointer, 0, W32APITypeMapper.DEFAULT);
        this.read();
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return Winnetwk$NETRESOURCE.FIELDS;
    }
    
    static {
        final String[] array = new String[8];
        int n = 0;
        String s;
        int n2 = (s = "D@%90\u0014kfQ\u00043\nD@9$<\u0003nLU\u001b\u0007LG<%2\u0012b\u0006LG=/#\u0010\u0007LG:5<\u0005b\fD@;3>\u001asM~\b;6").length();
        int n3 = 11;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 30));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0252: {
                            if (length > 1) {
                                break Label_0252;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 54;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 46;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 119;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 72;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 77;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 107;
                                        break;
                                    }
                                    default: {
                                        n11 = 25;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "\u0004\u0000jy~X\"\u0006\u0004\r\f\u0007m\u007f`E+\t\t}ocP").length();
                            n3 = 9;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 94)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[4], array2[3], array2[7], array2[2], array2[0], array2[5], array2[6], array2[1]);
    }
}
