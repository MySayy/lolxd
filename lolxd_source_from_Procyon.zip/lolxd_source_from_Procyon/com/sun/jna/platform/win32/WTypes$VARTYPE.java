// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public class WTypes$VARTYPE extends WinDef$USHORT
{
    private static final long serialVersionUID = 1L;
    
    public WTypes$VARTYPE() {
        this(0);
    }
    
    public WTypes$VARTYPE(final int n) {
        super((long)n);
    }
}
