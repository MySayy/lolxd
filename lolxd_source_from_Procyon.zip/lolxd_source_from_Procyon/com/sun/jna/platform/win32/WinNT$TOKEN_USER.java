// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Memory;
import com.sun.jna.Pointer;
import java.util.List;
import com.sun.jna.Structure;

public class WinNT$TOKEN_USER extends Structure
{
    public static final List<String> FIELDS;
    public WinNT$SID_AND_ATTRIBUTES User;
    
    public WinNT$TOKEN_USER() {
    }
    
    public WinNT$TOKEN_USER(final Pointer pointer) {
        super(pointer);
        this.read();
    }
    
    public WinNT$TOKEN_USER(final int n) {
        super(new Memory(n));
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return WinNT$TOKEN_USER.FIELDS;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 105);
        final char[] charArray = "\t?\u0016I".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 53;
                            break;
                        }
                        case 1: {
                            n5 = 37;
                            break;
                        }
                        case 2: {
                            n5 = 26;
                            break;
                        }
                        case 3: {
                            n5 = 82;
                            break;
                        }
                        case 4: {
                            n5 = 92;
                            break;
                        }
                        case 5: {
                            n5 = 10;
                            break;
                        }
                        default: {
                            n5 = 58;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                FIELDS = Structure.createFieldsOrder(new String(charArray).intern());
                return;
            }
            continue;
        }
    }
}
