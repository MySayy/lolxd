// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.ptr.ByReference;

public class WinDef$DWORDByReference extends ByReference
{
    public WinDef$DWORDByReference() {
        this(new WinDef$DWORD(0L));
    }
    
    public WinDef$DWORDByReference(final WinDef$DWORD value) {
        super(4);
        this.setValue(value);
    }
    
    public void setValue(final WinDef$DWORD winDef$DWORD) {
        this.getPointer().setInt(0L, winDef$DWORD.intValue());
    }
    
    public WinDef$DWORD getValue() {
        return new WinDef$DWORD((long)this.getPointer().getInt(0L));
    }
}
