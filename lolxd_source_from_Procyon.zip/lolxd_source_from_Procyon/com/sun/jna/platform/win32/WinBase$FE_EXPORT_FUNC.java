// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import com.sun.jna.win32.StdCallLibrary$StdCallCallback;

public interface WinBase$FE_EXPORT_FUNC extends StdCallLibrary$StdCallCallback
{
    WinDef$DWORD callback(final Pointer p0, final Pointer p1, final WinDef$ULONG p2);
}
