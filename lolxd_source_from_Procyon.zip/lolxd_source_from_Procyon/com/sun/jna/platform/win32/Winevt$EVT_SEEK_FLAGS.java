// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public interface Winevt$EVT_SEEK_FLAGS
{
    public static final int EvtSeekRelativeToFirst = 1;
    public static final int EvtSeekRelativeToLast = 2;
    public static final int EvtSeekRelativeToCurrent = 3;
    public static final int EvtSeekRelativeToBookmark = 4;
    public static final int EvtSeekOriginMask = 7;
    public static final int EvtSeekStrict = 65536;
}
