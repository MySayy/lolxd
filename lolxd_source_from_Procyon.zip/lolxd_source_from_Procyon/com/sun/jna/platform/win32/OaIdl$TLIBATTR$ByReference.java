// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import com.sun.jna.Structure$ByReference;

public class OaIdl$TLIBATTR$ByReference extends OaIdl$TLIBATTR implements Structure$ByReference
{
    public OaIdl$TLIBATTR$ByReference() {
    }
    
    public OaIdl$TLIBATTR$ByReference(final Pointer pointer) {
        super(pointer);
        this.read();
    }
}
