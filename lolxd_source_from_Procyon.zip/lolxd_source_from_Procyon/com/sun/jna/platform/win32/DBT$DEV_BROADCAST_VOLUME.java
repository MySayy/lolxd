// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import java.util.List;
import com.sun.jna.Structure;

public class DBT$DEV_BROADCAST_VOLUME extends Structure
{
    public static final List<String> FIELDS;
    public int dbcv_size;
    public int dbcv_devicetype;
    public int dbcv_reserved;
    public int dbcv_unitmask;
    public short dbcv_flags;
    
    public DBT$DEV_BROADCAST_VOLUME() {
        this.dbcv_size = this.size();
    }
    
    public DBT$DEV_BROADCAST_VOLUME(final Pointer pointer) {
        super(pointer);
        this.dbcv_size = this.size();
        this.read();
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return DBT$DEV_BROADCAST_VOLUME.FIELDS;
    }
    
    static {
        final String[] array = new String[5];
        int n = 0;
        String s;
        int n2 = (s = "I\n=$w\t#L\u000f-\rI\n=$w\u001d*^\r,$M\u000b\tI\n=$w\u001c&W\r").length();
        int n3 = 10;
        int n4 = -1;
    Label_0023:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 108));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0250: {
                            if (length > 1) {
                                break Label_0250;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 65;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 4;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 50;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 62;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 68;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 3;
                                        break;
                                    }
                                    default: {
                                        n11 = 35;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0023;
                            }
                            n2 = (s = "\u0003@wn=Pk\u000eVyy\u0011N\u000f\u0003@wn=A`\u0011Kw}\u0016\\u\u0002").length();
                            n3 = 13;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0023;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 38)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[2], array2[4], array2[1], array2[3], array2[0]);
    }
}
