// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public interface DdemlUtil$RequestHandler
{
    Ddeml$HDDEDATA onRequest(final int p0, final int p1, final Ddeml$HCONV p2, final Ddeml$HSZ p3, final Ddeml$HSZ p4);
}
