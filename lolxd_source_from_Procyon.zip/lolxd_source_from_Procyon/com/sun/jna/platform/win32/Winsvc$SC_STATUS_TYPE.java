// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public abstract class Winsvc$SC_STATUS_TYPE
{
    public static final int SC_STATUS_PROCESS_INFO = 0;
}
