// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Structure$ByReference;

public class WTypes$LPSTR$ByReference extends WTypes$BSTR implements Structure$ByReference
{
}
