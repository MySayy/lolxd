// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public abstract class AccCtrl$SE_OBJECT_TYPE
{
    public static final int SE_UNKNOWN_OBJECT_TYPE = 0;
    public static final int SE_FILE_OBJECT = 1;
    public static final int SE_SERVICE = 2;
    public static final int SE_PRINTER = 3;
    public static final int SE_REGISTRY_KEY = 4;
    public static final int SE_LMSHARE = 5;
    public static final int SE_KERNEL_OBJECT = 6;
    public static final int SE_WINDOW_OBJECT = 7;
    public static final int SE_DS_OBJECT = 8;
    public static final int SE_DS_OBJECT_ALL = 9;
    public static final int SE_PROVIDER_DEFINED_OBJECT = 10;
    public static final int SE_WMIGUID_OBJECT = 11;
    public static final int SE_REGISTRY_WOW64_32KEY = 12;
    final AccCtrl this$0;
    
    public AccCtrl$SE_OBJECT_TYPE(final AccCtrl this$0) {
        this.this$0 = this$0;
    }
}
