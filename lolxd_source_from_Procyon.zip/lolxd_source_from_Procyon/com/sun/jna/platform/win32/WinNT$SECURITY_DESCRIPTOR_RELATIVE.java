// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import com.sun.jna.Memory;
import java.util.List;
import com.sun.jna.Structure;

public class WinNT$SECURITY_DESCRIPTOR_RELATIVE extends Structure
{
    public static final List<String> FIELDS;
    public byte Revision;
    public byte Sbz1;
    public short Control;
    public int Owner;
    public int Group;
    public int Sacl;
    public int Dacl;
    private WinNT$PSID OWNER;
    private WinNT$PSID GROUP;
    private WinNT$ACL SACL;
    private WinNT$ACL DACL;
    
    public WinNT$SECURITY_DESCRIPTOR_RELATIVE() {
    }
    
    public WinNT$SECURITY_DESCRIPTOR_RELATIVE(final byte[] array) {
        super(new Memory(array.length));
        this.getPointer().write(0L, array, 0, array.length);
        this.setMembers();
    }
    
    public WinNT$SECURITY_DESCRIPTOR_RELATIVE(final int n) {
        super(new Memory(n));
    }
    
    public WinNT$SECURITY_DESCRIPTOR_RELATIVE(final Pointer pointer) {
        super(pointer);
        this.setMembers();
    }
    
    public WinNT$PSID getOwner() {
        return this.OWNER;
    }
    
    public WinNT$PSID getGroup() {
        return this.GROUP;
    }
    
    public WinNT$ACL getDiscretionaryACL() {
        return this.DACL;
    }
    
    public WinNT$ACL getSystemACL() {
        return this.SACL;
    }
    
    private final void setMembers() {
        final boolean a = WinNT$HANDLE.a();
        this.read();
        final boolean b = a;
        WinNT$SECURITY_DESCRIPTOR_RELATIVE winNT$SECURITY_DESCRIPTOR_RELATIVE4 = null;
        Label_0173: {
            int n2 = 0;
            Label_0169: {
                while (true) {
                    Label_0139: {
                        Label_0102: {
                            while (true) {
                                Label_0094: {
                                    Label_0057: {
                                        int n = 0;
                                        while (true) {
                                            Label_0049: {
                                                try {
                                                    final int group;
                                                    n = (group = (n2 = this.Dacl));
                                                    if (b) {
                                                        break Label_0057;
                                                    }
                                                    if (n == 0) {
                                                        break Label_0049;
                                                    }
                                                }
                                                catch (RuntimeException ex) {
                                                    throw b(ex);
                                                }
                                                final WinNT$SECURITY_DESCRIPTOR_RELATIVE winNT$SECURITY_DESCRIPTOR_RELATIVE = this;
                                                winNT$SECURITY_DESCRIPTOR_RELATIVE.DACL = new WinNT$ACL(this.getPointer().share(this.Dacl));
                                            }
                                            final WinNT$SECURITY_DESCRIPTOR_RELATIVE winNT$SECURITY_DESCRIPTOR_RELATIVE = this;
                                            if (b) {
                                                continue;
                                            }
                                            break;
                                        }
                                        final int n3;
                                        int group = n3 = (n2 = this.Sacl);
                                        try {
                                            if (b) {
                                                break Label_0102;
                                            }
                                            if (n == 0) {
                                                break Label_0094;
                                            }
                                        }
                                        catch (RuntimeException ex2) {
                                            throw b(ex2);
                                        }
                                    }
                                    final WinNT$SECURITY_DESCRIPTOR_RELATIVE winNT$SECURITY_DESCRIPTOR_RELATIVE2 = this;
                                    winNT$SECURITY_DESCRIPTOR_RELATIVE2.SACL = new WinNT$ACL(this.getPointer().share(this.Sacl));
                                }
                                final WinNT$SECURITY_DESCRIPTOR_RELATIVE winNT$SECURITY_DESCRIPTOR_RELATIVE2 = this;
                                if (b) {
                                    continue;
                                }
                                break;
                            }
                            int group;
                            n2 = (group = this.Group);
                            try {
                                if (b) {
                                    break Label_0169;
                                }
                                if (group == 0) {
                                    break Label_0139;
                                }
                            }
                            catch (RuntimeException ex3) {
                                throw b(ex3);
                            }
                        }
                        final WinNT$SECURITY_DESCRIPTOR_RELATIVE winNT$SECURITY_DESCRIPTOR_RELATIVE3 = this;
                        winNT$SECURITY_DESCRIPTOR_RELATIVE3.GROUP = new WinNT$PSID(this.getPointer().share(this.Group));
                    }
                    winNT$SECURITY_DESCRIPTOR_RELATIVE4 = this;
                    final WinNT$SECURITY_DESCRIPTOR_RELATIVE winNT$SECURITY_DESCRIPTOR_RELATIVE3 = this;
                    if (b) {
                        continue;
                    }
                    break;
                }
                Label_0159: {
                    try {
                        if (b) {
                            break Label_0173;
                        }
                        final boolean b2 = b;
                        if (!b2) {
                            break Label_0159;
                        }
                        break Label_0173;
                    }
                    catch (RuntimeException ex4) {
                        throw b(ex4);
                    }
                    try {
                        final boolean b2 = b;
                        if (b2) {
                            break Label_0173;
                        }
                        n2 = this.Owner;
                    }
                    catch (RuntimeException ex5) {
                        throw b(ex5);
                    }
                }
            }
            if (n2 == 0) {
                return;
            }
            winNT$SECURITY_DESCRIPTOR_RELATIVE4 = this;
        }
        winNT$SECURITY_DESCRIPTOR_RELATIVE4.OWNER = new WinNT$PSID(this.getPointer().share(this.Owner));
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return WinNT$SECURITY_DESCRIPTOR_RELATIVE.FIELDS;
    }
    
    static {
        final String[] array = new String[7];
        int n = 0;
        String s;
        int n2 = (s = "5-!SVyM\u00042#,K\u000595!BV\u0004% 5\u0016\u0004%#,K").length();
        int n3 = 7;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 126));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0252: {
                            if (length > 1) {
                                break Label_0252;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 8;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 60;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 49;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 89;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 90;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 104;
                                        break;
                                    }
                                    default: {
                                        n11 = 95;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "_^N<:\bJIW 9\u0011 v").length();
                            n3 = 5;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 16)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[6], array2[3], array2[0], array2[2], array2[5], array2[4], array2[1]);
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
