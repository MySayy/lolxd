// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public interface Winevt$EVT_CHANNEL_CONFIG_PROPERTY_ID
{
    public static final int EvtChannelConfigEnabled = 0;
    public static final int EvtChannelConfigIsolation = 1;
    public static final int EvtChannelConfigType = 2;
    public static final int EvtChannelConfigOwningPublisher = 3;
    public static final int EvtChannelConfigClassicEventlog = 4;
    public static final int EvtChannelConfigAccess = 5;
    public static final int EvtChannelLoggingConfigRetention = 6;
    public static final int EvtChannelLoggingConfigAutoBackup = 7;
    public static final int EvtChannelLoggingConfigMaxSize = 8;
    public static final int EvtChannelLoggingConfigLogFilePath = 9;
    public static final int EvtChannelPublishingConfigLevel = 10;
    public static final int EvtChannelPublishingConfigKeywords = 11;
    public static final int EvtChannelPublishingConfigControlGuid = 12;
    public static final int EvtChannelPublishingConfigBufferSize = 13;
    public static final int EvtChannelPublishingConfigMinBuffers = 14;
    public static final int EvtChannelPublishingConfigMaxBuffers = 15;
    public static final int EvtChannelPublishingConfigLatency = 16;
    public static final int EvtChannelPublishingConfigClockType = 17;
    public static final int EvtChannelPublishingConfigSidType = 18;
    public static final int EvtChannelPublisherList = 19;
    public static final int EvtChannelPublishingConfigFileMax = 20;
    public static final int EvtChannelConfigPropertyIdEND = 21;
}
