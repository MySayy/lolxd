// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public abstract class WinNT$SECURITY_IMPERSONATION_LEVEL
{
    public static final int SecurityAnonymous = 0;
    public static final int SecurityIdentification = 1;
    public static final int SecurityImpersonation = 2;
    public static final int SecurityDelegation = 3;
}
