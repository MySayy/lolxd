// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Structure$ByReference;

public class WinNT$PSID$ByReference extends WinNT$PSID implements Structure$ByReference
{
}
