// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.ptr.ByReference;

public class WinDef$LONGByReference extends ByReference
{
    public WinDef$LONGByReference() {
        this(new WinDef$LONG(0L));
    }
    
    public WinDef$LONGByReference(final WinDef$LONG value) {
        super(WinDef$LONG.SIZE);
        this.setValue(value);
    }
    
    public void setValue(final WinDef$LONG winDef$LONG) {
        this.getPointer().setInt(0L, winDef$LONG.intValue());
    }
    
    public WinDef$LONG getValue() {
        return new WinDef$LONG((long)this.getPointer().getInt(0L));
    }
}
