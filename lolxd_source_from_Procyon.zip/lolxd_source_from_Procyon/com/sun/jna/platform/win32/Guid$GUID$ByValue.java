// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import com.sun.jna.Structure$ByValue;

public class Guid$GUID$ByValue extends Guid$GUID implements Structure$ByValue
{
    public Guid$GUID$ByValue() {
    }
    
    public Guid$GUID$ByValue(final Guid$GUID guid$GUID) {
        super(guid$GUID.getPointer());
        this.Data1 = guid$GUID.Data1;
        this.Data2 = guid$GUID.Data2;
        this.Data3 = guid$GUID.Data3;
        this.Data4 = guid$GUID.Data4;
    }
    
    public Guid$GUID$ByValue(final Pointer pointer) {
        super(pointer);
    }
}
