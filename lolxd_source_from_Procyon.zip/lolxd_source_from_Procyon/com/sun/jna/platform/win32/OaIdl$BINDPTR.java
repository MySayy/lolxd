// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.platform.win32.COM.TypeComp;
import com.sun.jna.Union;

public class OaIdl$BINDPTR extends Union
{
    public OaIdl$FUNCDESC lpfuncdesc;
    public OaIdl$VARDESC lpvardesc;
    public TypeComp lptcomp;
    
    public OaIdl$BINDPTR() {
    }
    
    public OaIdl$BINDPTR(final OaIdl$VARDESC lpvardesc) {
        this.lpvardesc = lpvardesc;
        this.setType(OaIdl$VARDESC.class);
    }
    
    public OaIdl$BINDPTR(final TypeComp lptcomp) {
        this.lptcomp = lptcomp;
        this.setType(TypeComp.class);
    }
    
    public OaIdl$BINDPTR(final OaIdl$FUNCDESC lpfuncdesc) {
        this.lpfuncdesc = lpfuncdesc;
        this.setType(OaIdl$FUNCDESC.class);
    }
}
