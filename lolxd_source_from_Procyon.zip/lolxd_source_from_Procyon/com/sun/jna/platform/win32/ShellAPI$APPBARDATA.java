// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import java.util.List;
import com.sun.jna.Structure;

public class ShellAPI$APPBARDATA extends Structure
{
    public static final List<String> FIELDS;
    public WinDef$DWORD cbSize;
    public WinDef$HWND hWnd;
    public WinDef$UINT uCallbackMessage;
    public WinDef$UINT uEdge;
    public WinDef$RECT rc;
    public WinDef$LPARAM lParam;
    
    public ShellAPI$APPBARDATA() {
    }
    
    public ShellAPI$APPBARDATA(final Pointer pointer) {
        super(pointer);
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return ShellAPI$APPBARDATA.FIELDS;
    }
    
    static {
        final String[] array = new String[6];
        int n = 0;
        String s;
        int n2 = (s = "\f AKZ\u0005.\u001a\bmBE\u0014.\u001e\u0006\u0004\u00114NC\u0006\u00153AUW\n\u0006\u001a\u0001sNL\u0002").length();
        int n3 = 16;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 8));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0252: {
                            if (length > 1) {
                                break Label_0252;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 113;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 107;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 40;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 47;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 62;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 111;
                                        break;
                                    }
                                    default: {
                                        n11 = 71;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "\u001a\u0011\u0005\u001d7UQB").length();
                            n3 = 2;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 25)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[3], array2[1], array2[0], array2[5], array2[4], array2[2]);
    }
}
