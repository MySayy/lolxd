// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public class Netapi32Util$DomainController
{
    public String name;
    public String address;
    public int addressType;
    public Guid$GUID domainGuid;
    public String domainName;
    public String dnsForestName;
    public int flags;
    public String clientSiteName;
}
