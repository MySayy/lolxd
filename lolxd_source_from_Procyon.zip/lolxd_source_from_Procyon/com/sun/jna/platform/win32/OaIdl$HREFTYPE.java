// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public class OaIdl$HREFTYPE extends WinDef$DWORD
{
    private static final long serialVersionUID = 1L;
    
    public OaIdl$HREFTYPE() {
    }
    
    public OaIdl$HREFTYPE(final long n) {
        super(n);
    }
}
