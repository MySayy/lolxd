// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import com.sun.jna.Structure$ByReference;

public class Guid$GUID$ByReference extends Guid$GUID implements Structure$ByReference
{
    public Guid$GUID$ByReference() {
    }
    
    public Guid$GUID$ByReference(final Guid$GUID guid$GUID) {
        super(guid$GUID.getPointer());
        this.Data1 = guid$GUID.Data1;
        this.Data2 = guid$GUID.Data2;
        this.Data3 = guid$GUID.Data3;
        this.Data4 = guid$GUID.Data4;
    }
    
    public Guid$GUID$ByReference(final Pointer pointer) {
        super(pointer);
    }
}
