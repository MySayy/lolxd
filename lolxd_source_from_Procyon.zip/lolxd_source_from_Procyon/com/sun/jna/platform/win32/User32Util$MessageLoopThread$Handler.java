// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.Callable;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationHandler;

public class User32Util$MessageLoopThread$Handler implements InvocationHandler
{
    private final Object delegate;
    final User32Util$MessageLoopThread this$0;
    
    public User32Util$MessageLoopThread$Handler(final User32Util$MessageLoopThread this$0, final Object delegate) {
        this.this$0 = this$0;
        this.delegate = delegate;
    }
    
    @Override
    public Object invoke(final Object o, final Method method, final Object[] array) throws Throwable {
        final boolean a = WinNT$HANDLE.a();
        try {
            return this.this$0.runOnThread((Callable<Object>)new User32Util$MessageLoopThread$Handler$1(this, method, array));
        }
        catch (InvocationTargetException ex) {
            final Throwable cause = ex.getCause();
            while (true) {
                Label_0130: {
                    Throwable t2 = null;
                    Label_0052: {
                        Throwable t;
                        try {
                            t = (t2 = cause);
                            if (a) {
                                break Label_0061;
                            }
                            final boolean b = t instanceof Exception;
                            if (b) {
                                break Label_0052;
                            }
                            break Label_0130;
                        }
                        catch (InvocationTargetException ex2) {
                            throw b(ex2);
                        }
                        try {
                            final boolean b = t instanceof Exception;
                            if (!b) {
                                break Label_0130;
                            }
                            t2 = cause;
                        }
                        catch (InvocationTargetException ex3) {
                            throw b(ex3);
                        }
                    }
                    final StackTraceElement[] stackTrace = t2.getStackTrace();
                    cause.fillInStackTrace();
                    final StackTraceElement[] stackTrace2 = cause.getStackTrace();
                    final StackTraceElement[] stackTrace3 = new StackTraceElement[stackTrace2.length + stackTrace.length];
                    System.arraycopy(stackTrace, 0, stackTrace3, 0, stackTrace.length);
                    System.arraycopy(stackTrace2, 0, stackTrace3, stackTrace.length, stackTrace2.length);
                    cause.setStackTrace(stackTrace3);
                    throw (Exception)cause;
                }
                Throwable t2;
                final InvocationTargetException ex4 = (InvocationTargetException)(t2 = ex);
                if (!a) {
                    throw ex4;
                }
                continue;
            }
        }
    }
    
    static Object access$000(final User32Util$MessageLoopThread$Handler user32Util$MessageLoopThread$Handler) {
        return user32Util$MessageLoopThread$Handler.delegate;
    }
    
    private static InvocationTargetException b(final InvocationTargetException ex) {
        return ex;
    }
}
