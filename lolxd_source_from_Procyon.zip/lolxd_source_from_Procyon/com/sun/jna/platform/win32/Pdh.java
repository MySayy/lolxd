// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import java.util.Map;
import com.sun.jna.Native;
import com.sun.jna.win32.W32APIOptions;
import com.sun.jna.win32.StdCallLibrary;

public interface Pdh extends StdCallLibrary
{
    public static final Pdh INSTANCE = Native.loadLibrary(new String(charArray).intern(), Pdh.class, W32APIOptions.DEFAULT_OPTIONS);
    public static final int PDH_MAX_COUNTER_NAME = 1024;
    public static final int PDH_MAX_INSTANCE_NAME = 1024;
    public static final int PDH_MAX_COUNTER_PATH = 2048;
    public static final int PDH_MAX_DATASOURCE_PATH = 1024;
    public static final int PDH_CVERSION_WIN40 = 1024;
    public static final int PDH_CVERSION_WIN50 = 1280;
    public static final int PDH_VERSION = 1283;
    public static final int PDH_PATH_WBEM_RESULT = 1;
    public static final int PDH_PATH_WBEM_INPUT = 2;
    public static final int PDH_FMT_RAW = 16;
    public static final int PDH_FMT_ANSI = 32;
    public static final int PDH_FMT_UNICODE = 64;
    public static final int PDH_FMT_LONG = 256;
    public static final int PDH_FMT_DOUBLE = 512;
    public static final int PDH_FMT_LARGE = 1024;
    public static final int PDH_FMT_NOSCALE = 4096;
    public static final int PDH_FMT_1000 = 8192;
    public static final int PDH_FMT_NODATA = 16384;
    public static final int PDH_FMT_NOCAP100 = 32768;
    public static final int PERF_DETAIL_COSTLY = 65536;
    public static final int PERF_DETAIL_STANDARD = 65535;
    
    int PdhConnectMachine(final String p0);
    
    int PdhGetDllVersion(final WinDef$DWORDByReference p0);
    
    int PdhOpenQuery(final String p0, final BaseTSD$DWORD_PTR p1, final WinNT$HANDLEByReference p2);
    
    int PdhCloseQuery(final WinNT$HANDLE p0);
    
    int PdhMakeCounterPath(final Pdh$PDH_COUNTER_PATH_ELEMENTS p0, final char[] p1, final WinDef$DWORDByReference p2, final int p3);
    
    int PdhAddCounter(final WinNT$HANDLE p0, final String p1, final BaseTSD$DWORD_PTR p2, final WinNT$HANDLEByReference p3);
    
    int PdhAddEnglishCounter(final WinNT$HANDLE p0, final String p1, final BaseTSD$DWORD_PTR p2, final WinNT$HANDLEByReference p3);
    
    int PdhRemoveCounter(final WinNT$HANDLE p0);
    
    int PdhGetRawCounterValue(final WinNT$HANDLE p0, final WinDef$DWORDByReference p1, final Pdh$PDH_RAW_COUNTER p2);
    
    int PdhValidatePath(final String p0);
    
    int PdhCollectQueryData(final WinNT$HANDLE p0);
    
    int PdhCollectQueryDataEx(final WinNT$HANDLE p0, final int p1, final WinNT$HANDLE p2);
    
    int PdhCollectQueryDataWithTime(final WinNT$HANDLE p0, final WinDef$LONGLONGByReference p1);
    
    int PdhSetQueryTimeRange(final WinNT$HANDLE p0, final Pdh$PDH_TIME_INFO p1);
    
    default static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 88);
        final char[] charArray = "Ql\b".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 89;
                            break;
                        }
                        case 1: {
                            n5 = 80;
                            break;
                        }
                        case 2: {
                            n5 = 56;
                            break;
                        }
                        case 3: {
                            n5 = 14;
                            break;
                        }
                        case 4: {
                            n5 = 77;
                            break;
                        }
                        case 5: {
                            n5 = 82;
                            break;
                        }
                        default: {
                            n5 = 85;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                return;
            }
            continue;
        }
    }
}
