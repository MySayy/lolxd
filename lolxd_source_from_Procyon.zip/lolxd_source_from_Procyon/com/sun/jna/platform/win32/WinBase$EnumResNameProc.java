// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import com.sun.jna.Callback;

public interface WinBase$EnumResNameProc extends Callback
{
    boolean invoke(final WinDef$HMODULE p0, final Pointer p1, final Pointer p2, final Pointer p3);
}
