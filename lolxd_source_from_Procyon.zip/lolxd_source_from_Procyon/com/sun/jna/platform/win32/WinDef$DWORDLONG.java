// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.IntegerType;

public class WinDef$DWORDLONG extends IntegerType implements Comparable<WinDef$DWORDLONG>
{
    public static final int SIZE = 8;
    
    public WinDef$DWORDLONG() {
        this(0L);
    }
    
    public WinDef$DWORDLONG(final long n) {
        super(8, n, true);
    }
    
    @Override
    public int compareTo(final WinDef$DWORDLONG winDef$DWORDLONG) {
        return IntegerType.compare(this, winDef$DWORDLONG);
    }
}
