// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public interface DdemlUtil$ErrorHandler
{
    void onError(final int p0, final Ddeml$HCONV p1, final int p2);
}
