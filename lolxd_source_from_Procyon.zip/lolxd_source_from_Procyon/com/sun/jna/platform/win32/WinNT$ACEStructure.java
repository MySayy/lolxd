// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import java.util.List;
import com.sun.jna.Structure;

public abstract class WinNT$ACEStructure extends Structure
{
    public static final List<String> FIELDS;
    public byte AceType;
    public byte AceFlags;
    public short AceSize;
    WinNT$PSID psid;
    
    public WinNT$ACEStructure() {
    }
    
    public WinNT$ACEStructure(final Pointer pointer) {
        super(pointer);
    }
    
    public WinNT$ACEStructure(final byte aceType, final byte aceFlags, final short aceSize, final WinNT$PSID psid) {
        this.AceType = aceType;
        this.AceFlags = aceFlags;
        this.AceSize = aceSize;
        this.psid = psid;
        this.write();
    }
    
    public String getSidString() {
        return Advapi32Util.convertSidToStringSid(this.psid);
    }
    
    public WinNT$PSID getSID() {
        return this.psid;
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return WinNT$ACEStructure.FIELDS;
    }
    
    static {
        final String[] array = new String[3];
        int n = 0;
        final String s;
        final int length = (s = "*\f%R9w+\b*\f%@,f)\u0018\u0007*\f%U)}+").length();
        int char1 = 7;
        int index = -1;
        Label_0023: {
            break Label_0023;
            do {
                char1 = s.charAt(index);
                int n4;
                int n3;
                final int n2 = n3 = (n4 = 103);
                ++index;
                final String s2 = s;
                final int beginIndex = index;
                final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
                final int length2 = charArray.length;
                int n5 = 0;
                while (true) {
                    Label_0192: {
                        if (length2 > 1) {
                            break Label_0192;
                        }
                        n4 = (n3 = n5);
                        do {
                            final char c = charArray[n3];
                            int n6 = 0;
                            switch (n5 % 7) {
                                case 0: {
                                    n6 = 12;
                                    break;
                                }
                                case 1: {
                                    n6 = 8;
                                    break;
                                }
                                case 2: {
                                    n6 = 39;
                                    break;
                                }
                                case 3: {
                                    n6 = 97;
                                    break;
                                }
                                case 4: {
                                    n6 = 39;
                                    break;
                                }
                                case 5: {
                                    n6 = 96;
                                    break;
                                }
                                default: {
                                    n6 = 41;
                                    break;
                                }
                            }
                            charArray[n4] = (char)(c ^ (n2 ^ n6));
                            ++n5;
                        } while (n2 == 0);
                    }
                    if (length2 > n5) {
                        continue;
                    }
                    break;
                }
                array[n++] = new String(charArray).intern();
            } while ((index += char1) < length);
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[0], array2[1], array2[2]);
    }
}
