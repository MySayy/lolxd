// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.IntegerType;

public class WinDef$WORD extends IntegerType implements Comparable<WinDef$WORD>
{
    public static final int SIZE = 2;
    
    public WinDef$WORD() {
        this(0L);
    }
    
    public WinDef$WORD(final long n) {
        super(2, n, true);
    }
    
    @Override
    public int compareTo(final WinDef$WORD winDef$WORD) {
        return IntegerType.compare(this, winDef$WORD);
    }
}
