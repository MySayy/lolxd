// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import java.util.Arrays;
import java.util.List;
import com.sun.jna.Native;
import com.sun.jna.Structure;

public class Ntifs$GenericReparseBuffer extends Structure
{
    public byte[] DataBuffer;
    private static final String d;
    
    public static int sizeOf() {
        return Native.getNativeSize(Ntifs$GenericReparseBuffer.class, null);
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return Arrays.asList(Ntifs$GenericReparseBuffer.d);
    }
    
    public Ntifs$GenericReparseBuffer() {
        this.DataBuffer = new byte[16384];
    }
    
    public Ntifs$GenericReparseBuffer(final Pointer pointer) {
        super(pointer);
        this.DataBuffer = new byte[16384];
        this.read();
    }
    
    public Ntifs$GenericReparseBuffer(final String s) {
        this.DataBuffer = new byte[16384];
        this.DataBuffer = s.getBytes();
        this.write();
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 19);
        final char[] charArray = "tL/4]ZkVH)".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 35;
                            break;
                        }
                        case 1: {
                            n5 = 62;
                            break;
                        }
                        case 2: {
                            n5 = 72;
                            break;
                        }
                        case 3: {
                            n5 = 70;
                            break;
                        }
                        case 4: {
                            n5 = 12;
                            break;
                        }
                        case 5: {
                            n5 = 60;
                            break;
                        }
                        default: {
                            n5 = 30;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                d = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
