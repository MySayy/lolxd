// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public enum HighLevelMonitorConfigurationAPI$MC_SIZE_TYPE
{
    MC_WIDTH, 
    MC_HEIGHT;
    
    private static final HighLevelMonitorConfigurationAPI$MC_SIZE_TYPE[] $VALUES;
    
    static {
        final String[] array = new String[2];
        int n = 0;
        final String s;
        final int length = (s = "{i\u0011\u0000c\u0014.~~\b{i\u0011\u001fo\u0019=~").length();
        int char1 = 9;
        int index = -1;
        Label_0023: {
            break Label_0023;
            do {
                char1 = s.charAt(index);
                int n4;
                int n3;
                final int n2 = n3 = (n4 = 13);
                ++index;
                final String s2 = s;
                final int beginIndex = index;
                final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
                final int length2 = charArray.length;
                int n5 = 0;
                while (true) {
                    Label_0192: {
                        if (length2 > 1) {
                            break Label_0192;
                        }
                        n4 = (n3 = n5);
                        do {
                            final char c = charArray[n3];
                            int n6 = 0;
                            switch (n5 % 7) {
                                case 0: {
                                    n6 = 59;
                                    break;
                                }
                                case 1: {
                                    n6 = 39;
                                    break;
                                }
                                case 2: {
                                    n6 = 67;
                                    break;
                                }
                                case 3: {
                                    n6 = 69;
                                    break;
                                }
                                case 4: {
                                    n6 = 43;
                                    break;
                                }
                                case 5: {
                                    n6 = 80;
                                    break;
                                }
                                default: {
                                    n6 = 100;
                                    break;
                                }
                            }
                            charArray[n4] = (char)(c ^ (n2 ^ n6));
                            ++n5;
                        } while (n2 == 0);
                    }
                    if (length2 > n5) {
                        continue;
                    }
                    break;
                }
                array[n++] = new String(charArray).intern();
            } while ((index += char1) < length);
        }
        final String[] array2 = array;
        $VALUES = new HighLevelMonitorConfigurationAPI$MC_SIZE_TYPE[] { HighLevelMonitorConfigurationAPI$MC_SIZE_TYPE.MC_WIDTH, HighLevelMonitorConfigurationAPI$MC_SIZE_TYPE.MC_HEIGHT };
    }
}
