// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import java.util.Arrays;
import java.util.List;
import com.sun.jna.Structure;

public class WinBase$FILE_ID_INFO$FILE_ID_128 extends Structure
{
    public WinDef$BYTE[] Identifier;
    private static final String d;
    
    @Override
    protected List<String> getFieldOrder() {
        return Arrays.asList(WinBase$FILE_ID_INFO$FILE_ID_128.d);
    }
    
    public WinBase$FILE_ID_INFO$FILE_ID_128() {
        this.Identifier = new WinDef$BYTE[16];
    }
    
    public WinBase$FILE_ID_INFO$FILE_ID_128(final Pointer pointer) {
        super(pointer);
        this.Identifier = new WinDef$BYTE[16];
        this.read();
    }
    
    public WinBase$FILE_ID_INFO$FILE_ID_128(final WinDef$BYTE[] identifier) {
        this.Identifier = new WinDef$BYTE[16];
        this.Identifier = identifier;
        this.write();
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 37);
        final char[] charArray = "e>\u0002B!\u0007\u0012E?\u0015".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 9;
                            break;
                        }
                        case 1: {
                            n5 = 127;
                            break;
                        }
                        case 2: {
                            n5 = 66;
                            break;
                        }
                        case 3: {
                            n5 = 9;
                            break;
                        }
                        case 4: {
                            n5 = 112;
                            break;
                        }
                        case 5: {
                            n5 = 75;
                            break;
                        }
                        default: {
                            n5 = 81;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                d = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
