// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public class Guid$CLSID extends Guid$GUID
{
    public Guid$CLSID() {
    }
    
    public Guid$CLSID(final String s) {
        super(s);
    }
    
    public Guid$CLSID(final Guid$GUID guid$GUID) {
        super(guid$GUID);
    }
}
