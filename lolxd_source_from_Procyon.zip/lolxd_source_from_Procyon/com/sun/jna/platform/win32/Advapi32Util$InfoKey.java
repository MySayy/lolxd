// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.ptr.IntByReference;

public class Advapi32Util$InfoKey
{
    public WinReg$HKEY hKey;
    public char[] lpClass;
    public IntByReference lpcClass;
    public IntByReference lpcSubKeys;
    public IntByReference lpcMaxSubKeyLen;
    public IntByReference lpcMaxClassLen;
    public IntByReference lpcValues;
    public IntByReference lpcMaxValueNameLen;
    public IntByReference lpcMaxValueLen;
    public IntByReference lpcbSecurityDescriptor;
    public WinBase$FILETIME lpftLastWriteTime;
    
    public Advapi32Util$InfoKey() {
        this.lpClass = new char[260];
        this.lpcClass = new IntByReference(260);
        this.lpcSubKeys = new IntByReference();
        this.lpcMaxSubKeyLen = new IntByReference();
        this.lpcMaxClassLen = new IntByReference();
        this.lpcValues = new IntByReference();
        this.lpcMaxValueNameLen = new IntByReference();
        this.lpcMaxValueLen = new IntByReference();
        this.lpcbSecurityDescriptor = new IntByReference();
        this.lpftLastWriteTime = new WinBase$FILETIME();
    }
    
    public Advapi32Util$InfoKey(final WinReg$HKEY hKey, final int n) {
        this.lpClass = new char[260];
        this.lpcClass = new IntByReference(260);
        this.lpcSubKeys = new IntByReference();
        this.lpcMaxSubKeyLen = new IntByReference();
        this.lpcMaxClassLen = new IntByReference();
        this.lpcValues = new IntByReference();
        this.lpcMaxValueNameLen = new IntByReference();
        this.lpcMaxValueLen = new IntByReference();
        this.lpcbSecurityDescriptor = new IntByReference();
        this.lpftLastWriteTime = new WinBase$FILETIME();
        this.hKey = hKey;
        this.lpcbSecurityDescriptor = new IntByReference(n);
    }
}
