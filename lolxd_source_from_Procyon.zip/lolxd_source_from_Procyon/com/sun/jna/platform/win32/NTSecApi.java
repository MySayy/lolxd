// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public interface NTSecApi
{
    public static final int ForestTrustTopLevelName = 0;
    public static final int ForestTrustTopLevelNameEx = 1;
    public static final int ForestTrustDomainInfo = 2;
}
