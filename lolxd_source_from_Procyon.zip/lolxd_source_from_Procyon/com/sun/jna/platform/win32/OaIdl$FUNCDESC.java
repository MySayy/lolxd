// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import java.util.List;
import com.sun.jna.Structure;

public class OaIdl$FUNCDESC extends Structure
{
    public static final List<String> FIELDS;
    public OaIdl$MEMBERID memid;
    public OaIdl$ScodeArg$ByReference lprgscode;
    public OaIdl$ElemDescArg$ByReference lprgelemdescParam;
    public OaIdl$FUNCKIND funckind;
    public OaIdl$INVOKEKIND invkind;
    public OaIdl$CALLCONV callconv;
    public WinDef$SHORT cParams;
    public WinDef$SHORT cParamsOpt;
    public WinDef$SHORT oVft;
    public WinDef$SHORT cScodes;
    public OaIdl$ELEMDESC elemdescFunc;
    public WinDef$WORD wFuncFlags;
    
    public OaIdl$FUNCDESC() {
    }
    
    public OaIdl$FUNCDESC(final Pointer p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: aload_1        
        //     5: invokespecial   com/sun/jna/Structure.<init>:(Lcom/sun/jna/Pointer;)V
        //     8: istore_2       
        //     9: aload_0        
        //    10: invokevirtual   com/sun/jna/platform/win32/OaIdl$FUNCDESC.read:()V
        //    13: aload_0        
        //    14: iload_2        
        //    15: ifeq            71
        //    18: iload_2        
        //    19: ifeq            71
        //    22: goto            29
        //    25: invokestatic    com/sun/jna/platform/win32/OaIdl$FUNCDESC.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    28: athrow         
        //    29: getfield        com/sun/jna/platform/win32/OaIdl$FUNCDESC.cParams:Lcom/sun/jna/platform/win32/WinDef$SHORT;
        //    32: invokevirtual   com/sun/jna/platform/win32/WinDef$SHORT.shortValue:()S
        //    35: iconst_1       
        //    36: if_icmple       77
        //    39: goto            46
        //    42: invokestatic    com/sun/jna/platform/win32/OaIdl$FUNCDESC.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    45: athrow         
        //    46: aload_0        
        //    47: getfield        com/sun/jna/platform/win32/OaIdl$FUNCDESC.lprgelemdescParam:Lcom/sun/jna/platform/win32/OaIdl$ElemDescArg$ByReference;
        //    50: aload_0        
        //    51: getfield        com/sun/jna/platform/win32/OaIdl$FUNCDESC.cParams:Lcom/sun/jna/platform/win32/WinDef$SHORT;
        //    54: invokevirtual   com/sun/jna/platform/win32/WinDef$SHORT.shortValue:()S
        //    57: anewarray       Lcom/sun/jna/platform/win32/OaIdl$ELEMDESC;
        //    60: putfield        com/sun/jna/platform/win32/OaIdl$ElemDescArg$ByReference.elemDescArg:[Lcom/sun/jna/platform/win32/OaIdl$ELEMDESC;
        //    63: aload_0        
        //    64: goto            71
        //    67: invokestatic    com/sun/jna/platform/win32/OaIdl$FUNCDESC.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    70: athrow         
        //    71: getfield        com/sun/jna/platform/win32/OaIdl$FUNCDESC.lprgelemdescParam:Lcom/sun/jna/platform/win32/OaIdl$ElemDescArg$ByReference;
        //    74: invokevirtual   com/sun/jna/platform/win32/OaIdl$ElemDescArg$ByReference.read:()V
        //    77: return         
        //    StackMapTable: 00 07 FF 00 19 00 01 07 00 0F 00 01 07 00 55 43 07 00 0F 4C 07 00 55 03 54 07 00 55 43 07 00 0F 05
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  9      22     25     29     Ljava/lang/RuntimeException;
        //  18     39     42     46     Ljava/lang/RuntimeException;
        //  29     64     67     71     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0029:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return OaIdl$FUNCDESC.FIELDS;
    }
    
    static {
        final String[] array = new String[12];
        int n = 0;
        String s;
        int n2 = (s = "D\"\t\u0019N\u0002gB\b\u0019\u001aI\bG;\u0002\u0017A\u000ezE\u0007B\u001d\u000f\u001bN\u0002g\u0007H \u001a\u001fC\tp\nB\u001e\r\u0006K\ngn>\u0018\u0005L+\u0001\u001dN\u0004N\u0018\n\u0000\u0011M>\u001e\u0013O\u000bqL*\t\u0007I7uS/\u0001\bB/\u0000\u0018I\bzW\tM>\u001e\u0013Y\u0004{E+").length();
        int n3 = 12;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 29));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0252: {
                            if (length > 1) {
                                break Label_0252;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 60;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 83;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 113;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 105;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 55;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 122;
                                        break;
                                    }
                                    default: {
                                        n11 = 9;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "9gvu&N\u0017/Fp\u0007-qbi$e\b").length();
                            n3 = 10;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 114)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[5], array2[9], array2[7], array2[1], array2[3], array2[8], array2[11], array2[4], array2[6], array2[2], array2[0], array2[10]);
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
