// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Structure$ByReference;

public class WinNT$GENERIC_MAPPING$ByReference extends WinNT$GENERIC_MAPPING implements Structure$ByReference
{
}
