// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import java.util.List;
import com.sun.jna.Structure;

public class WinNT$EVENTLOGRECORD extends Structure
{
    public static final List<String> FIELDS;
    public WinDef$DWORD Length;
    public WinDef$DWORD Reserved;
    public WinDef$DWORD RecordNumber;
    public WinDef$DWORD TimeGenerated;
    public WinDef$DWORD TimeWritten;
    public WinDef$DWORD EventID;
    public WinDef$WORD EventType;
    public WinDef$WORD NumStrings;
    public WinDef$WORD EventCategory;
    public WinDef$WORD ReservedFlags;
    public WinDef$DWORD ClosingRecordNumber;
    public WinDef$DWORD StringOffset;
    public WinDef$DWORD UserSidLength;
    public WinDef$DWORD UserSidOffset;
    public WinDef$DWORD DataLength;
    public WinDef$DWORD DataOffset;
    
    public WinNT$EVENTLOGRECORD() {
    }
    
    public WinNT$EVENTLOGRECORD(final Pointer pointer) {
        super(pointer);
        this.read();
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return WinNT$EVENTLOGRECORD.FIELDS;
    }
    
    static {
        final String[] array = new String[16];
        int n = 0;
        String s;
        int n2 = (s = "n<\u0000 \u0012\u0015Y[/\r~9\u0000<5(Dg/\u000b)\u0012)\no+\u0011/)'FX/\u0011\ne?\b\u001d\u00123IE-\u0016\ry/\u0016+\u00147EO\f\t/\u00012\r~9\u0000<5(Dd,\u0003=\u00035\u0007n<\u0000 \u0012\bd\r\u007f#\b+!$NN8\u0004:\u0003%\u0013h&\n=\u000f/Gy/\u0006!\u0014%n^'\u0007+\u0014\u0006g/\u000b)\u0012)\u000b\u007f#\b+13I_>\u0000 \by/\u0016+\u00147EO\fy/\u0006!\u0014%n^'\u0007+\u0014\fx>\u0017'\b&oM,\u0016+\u0012").length();
        int n3 = 9;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 6));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0252: {
                            if (length > 1) {
                                break Label_0252;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 45;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 76;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 99;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 72;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 96;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 71;
                                        break;
                                    }
                                    default: {
                                        n11 = 38;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "/}AaSC\u0000\u001enC`Uy\n.jPnke\u000f\r\u007fL").length();
                            n3 = 13;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 71)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[9], array2[11], array2[12], array2[7], array2[10], array2[6], array2[0], array2[3], array2[14], array2[4], array2[8], array2[13], array2[1], array2[5], array2[15], array2[2]);
    }
}
