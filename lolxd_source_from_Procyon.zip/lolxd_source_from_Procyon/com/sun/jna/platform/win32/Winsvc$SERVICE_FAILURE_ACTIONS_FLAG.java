// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Structure;
import com.sun.jna.Pointer;
import java.util.List;

public class Winsvc$SERVICE_FAILURE_ACTIONS_FLAG extends Winsvc$ChangeServiceConfig2Info
{
    public int fFailureActionsOnNonCrashFailures;
    public static final List<String> FIELDS;
    
    @Override
    protected List getFieldOrder() {
        return Winsvc$SERVICE_FAILURE_ACTIONS_FLAG.FIELDS;
    }
    
    public Winsvc$SERVICE_FAILURE_ACTIONS_FLAG() {
    }
    
    public Winsvc$SERVICE_FAILURE_ACTIONS_FLAG(final Pointer pointer) {
        super(pointer);
        this.read();
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 114);
        final char[] charArray = "y!\u001fck\u0010Qz&\u001d~n\nMl(\u0010Dh\u000b`m\u0006\rbA\u0004Js\u0012\fot".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 109;
                            break;
                        }
                        case 1: {
                            n5 = 21;
                            break;
                        }
                        case 2: {
                            n5 = 12;
                            break;
                        }
                        case 3: {
                            n5 = 120;
                            break;
                        }
                        case 4: {
                            n5 = 117;
                            break;
                        }
                        case 5: {
                            n5 = 23;
                            break;
                        }
                        default: {
                            n5 = 81;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                FIELDS = Structure.createFieldsOrder(new String(charArray).intern());
                return;
            }
            continue;
        }
    }
}
