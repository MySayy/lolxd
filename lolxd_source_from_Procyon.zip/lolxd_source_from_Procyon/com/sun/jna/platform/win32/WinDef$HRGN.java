// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;

public class WinDef$HRGN extends WinNT$HANDLE
{
    public WinDef$HRGN() {
    }
    
    public WinDef$HRGN(final Pointer pointer) {
        super(pointer);
    }
}
