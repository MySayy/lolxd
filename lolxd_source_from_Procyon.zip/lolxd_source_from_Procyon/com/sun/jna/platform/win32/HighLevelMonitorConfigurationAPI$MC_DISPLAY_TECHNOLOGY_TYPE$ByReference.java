// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.platform.EnumUtils;
import com.sun.jna.ptr.ByReference;

public class HighLevelMonitorConfigurationAPI$MC_DISPLAY_TECHNOLOGY_TYPE$ByReference extends ByReference
{
    public HighLevelMonitorConfigurationAPI$MC_DISPLAY_TECHNOLOGY_TYPE$ByReference() {
        super(4);
        this.getPointer().setInt(0L, -1);
    }
    
    public HighLevelMonitorConfigurationAPI$MC_DISPLAY_TECHNOLOGY_TYPE$ByReference(final HighLevelMonitorConfigurationAPI$MC_DISPLAY_TECHNOLOGY_TYPE value) {
        super(4);
        this.setValue(value);
    }
    
    public void setValue(final HighLevelMonitorConfigurationAPI$MC_DISPLAY_TECHNOLOGY_TYPE highLevelMonitorConfigurationAPI$MC_DISPLAY_TECHNOLOGY_TYPE) {
        this.getPointer().setInt(0L, EnumUtils.toInteger(highLevelMonitorConfigurationAPI$MC_DISPLAY_TECHNOLOGY_TYPE));
    }
    
    public HighLevelMonitorConfigurationAPI$MC_DISPLAY_TECHNOLOGY_TYPE getValue() {
        return EnumUtils.fromInteger(this.getPointer().getInt(0L), HighLevelMonitorConfigurationAPI$MC_DISPLAY_TECHNOLOGY_TYPE.class);
    }
}
