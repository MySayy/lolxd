// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import java.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.List;
import java.util.logging.Logger;

public class DdemlUtil$DdeAdapter implements Ddeml$DdeCallback
{
    private static final Logger LOG;
    private int idInst;
    private final List<DdemlUtil$AdvstartHandler> advstartHandler;
    private final List<DdemlUtil$AdvstopHandler> advstopHandler;
    private final List<DdemlUtil$ConnectHandler> connectHandler;
    private final List<DdemlUtil$AdvreqHandler> advReqHandler;
    private final List<DdemlUtil$RequestHandler> requestHandler;
    private final List<DdemlUtil$WildconnectHandler> wildconnectHandler;
    private final List<DdemlUtil$AdvdataHandler> advdataHandler;
    private final List<DdemlUtil$ExecuteHandler> executeHandler;
    private final List<DdemlUtil$PokeHandler> pokeHandler;
    private final List<DdemlUtil$ConnectConfirmHandler> connectConfirmHandler;
    private final List<DdemlUtil$DisconnectHandler> disconnectHandler;
    private final List<DdemlUtil$ErrorHandler> errorHandler;
    private final List<DdemlUtil$RegisterHandler> registerHandler;
    private final List<DdemlUtil$XactCompleteHandler> xactCompleteHandler;
    private final List<DdemlUtil$UnregisterHandler> unregisterHandler;
    private final List<DdemlUtil$MonitorHandler> monitorHandler;
    private static final String[] a;
    private static final String[] b;
    
    public DdemlUtil$DdeAdapter() {
        this.advstartHandler = new CopyOnWriteArrayList<DdemlUtil$AdvstartHandler>();
        this.advstopHandler = new CopyOnWriteArrayList<DdemlUtil$AdvstopHandler>();
        this.connectHandler = new CopyOnWriteArrayList<DdemlUtil$ConnectHandler>();
        this.advReqHandler = new CopyOnWriteArrayList<DdemlUtil$AdvreqHandler>();
        this.requestHandler = new CopyOnWriteArrayList<DdemlUtil$RequestHandler>();
        this.wildconnectHandler = new CopyOnWriteArrayList<DdemlUtil$WildconnectHandler>();
        this.advdataHandler = new CopyOnWriteArrayList<DdemlUtil$AdvdataHandler>();
        this.executeHandler = new CopyOnWriteArrayList<DdemlUtil$ExecuteHandler>();
        this.pokeHandler = new CopyOnWriteArrayList<DdemlUtil$PokeHandler>();
        this.connectConfirmHandler = new CopyOnWriteArrayList<DdemlUtil$ConnectConfirmHandler>();
        this.disconnectHandler = new CopyOnWriteArrayList<DdemlUtil$DisconnectHandler>();
        this.errorHandler = new CopyOnWriteArrayList<DdemlUtil$ErrorHandler>();
        this.registerHandler = new CopyOnWriteArrayList<DdemlUtil$RegisterHandler>();
        this.xactCompleteHandler = new CopyOnWriteArrayList<DdemlUtil$XactCompleteHandler>();
        this.unregisterHandler = new CopyOnWriteArrayList<DdemlUtil$UnregisterHandler>();
        this.monitorHandler = new CopyOnWriteArrayList<DdemlUtil$MonitorHandler>();
    }
    
    public void setInstanceIdentifier(final int idInst) {
        this.idInst = idInst;
    }
    
    @Override
    public WinDef$PVOID ddeCallback(final int p0, final int p1, final Ddeml$HCONV p2, final Ddeml$HSZ p3, final Ddeml$HSZ p4, final Ddeml$HDDEDATA p5, final BaseTSD$ULONG_PTR p6, final BaseTSD$ULONG_PTR p7) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aconst_null    
        //     4: astore          14
        //     6: istore          9
        //     8: iload_1        
        //     9: iload           9
        //    11: ifne            186
        //    14: iload           9
        //    16: ifne            186
        //    19: goto            26
        //    22: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    25: athrow         
        //    26: lookupswitch {
        //             4144: 168
        //             4194: 211
        //             8226: 345
        //             8368: 420
        //             8418: 483
        //            16400: 741
        //            16464: 769
        //            16528: 805
        //            32770: 1021
        //            32832: 833
        //            32882: 849
        //            32896: 1070
        //            32930: 1049
        //            32962: 937
        //            32978: 1099
        //            33010: 1120
        //          default: 1144
        //        }
        //   164: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   167: athrow         
        //   168: aload_0        
        //   169: iload_1        
        //   170: iload_2        
        //   171: aload_3        
        //   172: aload           4
        //   174: aload           5
        //   176: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onAdvstart:(IILcom/sun/jna/platform/win32/Ddeml$HCONV;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;)Z
        //   179: goto            186
        //   182: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   185: athrow         
        //   186: istore          10
        //   188: new             Lcom/sun/jna/platform/win32/WinDef$PVOID;
        //   191: dup            
        //   192: new             Lcom/sun/jna/platform/win32/WinDef$BOOL;
        //   195: dup            
        //   196: iload           10
        //   198: invokespecial   com/sun/jna/platform/win32/WinDef$BOOL.<init>:(Z)V
        //   201: invokevirtual   com/sun/jna/platform/win32/WinDef$BOOL.intValue:()I
        //   204: invokestatic    com/sun/jna/Pointer.createConstant:(I)Lcom/sun/jna/Pointer;
        //   207: invokespecial   com/sun/jna/platform/win32/WinDef$PVOID.<init>:(Lcom/sun/jna/Pointer;)V
        //   210: areturn        
        //   211: aconst_null    
        //   212: astore          12
        //   214: aload           7
        //   216: invokevirtual   com/sun/jna/platform/win32/BaseTSD$ULONG_PTR.toPointer:()Lcom/sun/jna/Pointer;
        //   219: ifnull          243
        //   222: new             Lcom/sun/jna/platform/win32/Ddeml$CONVCONTEXT;
        //   225: dup            
        //   226: new             Lcom/sun/jna/Pointer;
        //   229: dup            
        //   230: aload           7
        //   232: invokevirtual   com/sun/jna/platform/win32/BaseTSD$ULONG_PTR.longValue:()J
        //   235: invokespecial   com/sun/jna/Pointer.<init>:(J)V
        //   238: invokespecial   com/sun/jna/platform/win32/Ddeml$CONVCONTEXT.<init>:(Lcom/sun/jna/Pointer;)V
        //   241: astore          12
        //   243: aload_0        
        //   244: iload_1        
        //   245: aload           4
        //   247: aload           5
        //   249: aload           12
        //   251: aload           8
        //   253: iload           9
        //   255: ifne            282
        //   258: iload           9
        //   260: ifne            282
        //   263: goto            270
        //   266: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   269: athrow         
        //   270: ifnull          316
        //   273: goto            280
        //   276: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   279: athrow         
        //   280: aload           8
        //   282: invokevirtual   com/sun/jna/platform/win32/BaseTSD$ULONG_PTR.intValue:()I
        //   285: iload           9
        //   287: ifne            313
        //   290: iload           9
        //   292: ifne            313
        //   295: goto            302
        //   298: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   301: athrow         
        //   302: ifeq            316
        //   305: goto            312
        //   308: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   311: athrow         
        //   312: iconst_1       
        //   313: goto            317
        //   316: iconst_0       
        //   317: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onConnect:(ILcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$CONVCONTEXT;Z)Z
        //   320: istore          10
        //   322: new             Lcom/sun/jna/platform/win32/WinDef$PVOID;
        //   325: dup            
        //   326: new             Lcom/sun/jna/platform/win32/WinDef$BOOL;
        //   329: dup            
        //   330: iload           10
        //   332: invokespecial   com/sun/jna/platform/win32/WinDef$BOOL.<init>:(Z)V
        //   335: invokevirtual   com/sun/jna/platform/win32/WinDef$BOOL.intValue:()I
        //   338: invokestatic    com/sun/jna/Pointer.createConstant:(I)Lcom/sun/jna/Pointer;
        //   341: invokespecial   com/sun/jna/platform/win32/WinDef$PVOID.<init>:(Lcom/sun/jna/Pointer;)V
        //   344: areturn        
        //   345: aload           7
        //   347: invokevirtual   com/sun/jna/platform/win32/BaseTSD$ULONG_PTR.intValue:()I
        //   350: ldc             65535
        //   352: iand           
        //   353: istore          15
        //   355: aload_0        
        //   356: iload_1        
        //   357: iload_2        
        //   358: aload_3        
        //   359: aload           4
        //   361: aload           5
        //   363: iload           15
        //   365: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onAdvreq:(IILcom/sun/jna/platform/win32/Ddeml$HCONV;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;I)Lcom/sun/jna/platform/win32/Ddeml$HDDEDATA;
        //   368: astore          11
        //   370: aload           11
        //   372: iload           9
        //   374: ifne            419
        //   377: ifnonnull       402
        //   380: goto            387
        //   383: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   386: athrow         
        //   387: new             Lcom/sun/jna/platform/win32/WinDef$PVOID;
        //   390: dup            
        //   391: invokespecial   com/sun/jna/platform/win32/WinDef$PVOID.<init>:()V
        //   394: goto            401
        //   397: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   400: athrow         
        //   401: areturn        
        //   402: new             Lcom/sun/jna/platform/win32/WinDef$PVOID;
        //   405: dup            
        //   406: aload           11
        //   408: invokevirtual   com/sun/jna/platform/win32/Ddeml$HDDEDATA.getPointer:()Lcom/sun/jna/Pointer;
        //   411: invokespecial   com/sun/jna/platform/win32/WinDef$PVOID.<init>:(Lcom/sun/jna/Pointer;)V
        //   414: iload           9
        //   416: ifne            401
        //   419: areturn        
        //   420: aload_0        
        //   421: iload_1        
        //   422: iload_2        
        //   423: aload_3        
        //   424: aload           4
        //   426: aload           5
        //   428: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onRequest:(IILcom/sun/jna/platform/win32/Ddeml$HCONV;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;)Lcom/sun/jna/platform/win32/Ddeml$HDDEDATA;
        //   431: astore          11
        //   433: aload           11
        //   435: iload           9
        //   437: ifne            482
        //   440: ifnonnull       465
        //   443: goto            450
        //   446: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   449: athrow         
        //   450: new             Lcom/sun/jna/platform/win32/WinDef$PVOID;
        //   453: dup            
        //   454: invokespecial   com/sun/jna/platform/win32/WinDef$PVOID.<init>:()V
        //   457: goto            464
        //   460: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   463: athrow         
        //   464: areturn        
        //   465: new             Lcom/sun/jna/platform/win32/WinDef$PVOID;
        //   468: dup            
        //   469: aload           11
        //   471: invokevirtual   com/sun/jna/platform/win32/Ddeml$HDDEDATA.getPointer:()Lcom/sun/jna/Pointer;
        //   474: invokespecial   com/sun/jna/platform/win32/WinDef$PVOID.<init>:(Lcom/sun/jna/Pointer;)V
        //   477: iload           9
        //   479: ifne            464
        //   482: areturn        
        //   483: aconst_null    
        //   484: astore          12
        //   486: aload           7
        //   488: invokevirtual   com/sun/jna/platform/win32/BaseTSD$ULONG_PTR.toPointer:()Lcom/sun/jna/Pointer;
        //   491: ifnull          515
        //   494: new             Lcom/sun/jna/platform/win32/Ddeml$CONVCONTEXT;
        //   497: dup            
        //   498: new             Lcom/sun/jna/Pointer;
        //   501: dup            
        //   502: aload           7
        //   504: invokevirtual   com/sun/jna/platform/win32/BaseTSD$ULONG_PTR.longValue:()J
        //   507: invokespecial   com/sun/jna/Pointer.<init>:(J)V
        //   510: invokespecial   com/sun/jna/platform/win32/Ddeml$CONVCONTEXT.<init>:(Lcom/sun/jna/Pointer;)V
        //   513: astore          12
        //   515: aload_0        
        //   516: iload_1        
        //   517: aload           4
        //   519: aload           5
        //   521: aload           12
        //   523: aload           8
        //   525: iload           9
        //   527: ifne            554
        //   530: iload           9
        //   532: ifne            554
        //   535: goto            542
        //   538: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   541: athrow         
        //   542: ifnull          588
        //   545: goto            552
        //   548: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   551: athrow         
        //   552: aload           8
        //   554: invokevirtual   com/sun/jna/platform/win32/BaseTSD$ULONG_PTR.intValue:()I
        //   557: iload           9
        //   559: ifne            585
        //   562: iload           9
        //   564: ifne            585
        //   567: goto            574
        //   570: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   573: athrow         
        //   574: ifeq            588
        //   577: goto            584
        //   580: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   583: athrow         
        //   584: iconst_1       
        //   585: goto            589
        //   588: iconst_0       
        //   589: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onWildconnect:(ILcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$CONVCONTEXT;Z)[Lcom/sun/jna/platform/win32/Ddeml$HSZPAIR;
        //   592: astore          16
        //   594: aload           16
        //   596: iload           9
        //   598: ifne            625
        //   601: iload           9
        //   603: ifne            625
        //   606: goto            613
        //   609: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   612: athrow         
        //   613: ifnull          641
        //   616: goto            623
        //   619: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   622: athrow         
        //   623: aload           16
        //   625: arraylength    
        //   626: iload           9
        //   628: ifne            650
        //   631: ifne            649
        //   634: goto            641
        //   637: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   640: athrow         
        //   641: new             Lcom/sun/jna/platform/win32/WinDef$PVOID;
        //   644: dup            
        //   645: invokespecial   com/sun/jna/platform/win32/WinDef$PVOID.<init>:()V
        //   648: areturn        
        //   649: iconst_0       
        //   650: istore          17
        //   652: aload           16
        //   654: astore          18
        //   656: aload           18
        //   658: arraylength    
        //   659: istore          19
        //   661: iconst_0       
        //   662: istore          20
        //   664: iload           20
        //   666: iload           19
        //   668: if_icmpge       701
        //   671: aload           18
        //   673: iload           20
        //   675: aaload         
        //   676: astore          21
        //   678: aload           21
        //   680: invokevirtual   com/sun/jna/platform/win32/Ddeml$HSZPAIR.write:()V
        //   683: iload           17
        //   685: aload           21
        //   687: invokevirtual   com/sun/jna/platform/win32/Ddeml$HSZPAIR.size:()I
        //   690: iadd           
        //   691: istore          17
        //   693: iinc            20, 1
        //   696: iload           9
        //   698: ifeq            664
        //   701: getstatic       com/sun/jna/platform/win32/Ddeml.INSTANCE:Lcom/sun/jna/platform/win32/Ddeml;
        //   704: aload_0        
        //   705: getfield        com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.idInst:I
        //   708: aload           16
        //   710: iconst_0       
        //   711: aaload         
        //   712: invokevirtual   com/sun/jna/platform/win32/Ddeml$HSZPAIR.getPointer:()Lcom/sun/jna/Pointer;
        //   715: iload           17
        //   717: iconst_0       
        //   718: aconst_null    
        //   719: iload_2        
        //   720: iconst_0       
        //   721: invokeinterface com/sun/jna/platform/win32/Ddeml.DdeCreateDataHandle:(ILcom/sun/jna/Pointer;IILcom/sun/jna/platform/win32/Ddeml$HSZ;II)Lcom/sun/jna/platform/win32/Ddeml$HDDEDATA;
        //   726: astore          11
        //   728: new             Lcom/sun/jna/platform/win32/WinDef$PVOID;
        //   731: dup            
        //   732: aload           11
        //   734: invokevirtual   com/sun/jna/platform/win32/Ddeml$HDDEDATA.getPointer:()Lcom/sun/jna/Pointer;
        //   737: invokespecial   com/sun/jna/platform/win32/WinDef$PVOID.<init>:(Lcom/sun/jna/Pointer;)V
        //   740: areturn        
        //   741: aload_0        
        //   742: iload_1        
        //   743: iload_2        
        //   744: aload_3        
        //   745: aload           4
        //   747: aload           5
        //   749: aload           6
        //   751: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onAdvdata:(IILcom/sun/jna/platform/win32/Ddeml$HCONV;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HDDEDATA;)I
        //   754: istore          13
        //   756: new             Lcom/sun/jna/platform/win32/WinDef$PVOID;
        //   759: dup            
        //   760: iload           13
        //   762: invokestatic    com/sun/jna/Pointer.createConstant:(I)Lcom/sun/jna/Pointer;
        //   765: invokespecial   com/sun/jna/platform/win32/WinDef$PVOID.<init>:(Lcom/sun/jna/Pointer;)V
        //   768: areturn        
        //   769: aload_0        
        //   770: iload_1        
        //   771: aload_3        
        //   772: aload           4
        //   774: aload           6
        //   776: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onExecute:(ILcom/sun/jna/platform/win32/Ddeml$HCONV;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HDDEDATA;)I
        //   779: istore          13
        //   781: getstatic       com/sun/jna/platform/win32/Ddeml.INSTANCE:Lcom/sun/jna/platform/win32/Ddeml;
        //   784: aload           6
        //   786: invokeinterface com/sun/jna/platform/win32/Ddeml.DdeFreeDataHandle:(Lcom/sun/jna/platform/win32/Ddeml$HDDEDATA;)Z
        //   791: pop            
        //   792: new             Lcom/sun/jna/platform/win32/WinDef$PVOID;
        //   795: dup            
        //   796: iload           13
        //   798: invokestatic    com/sun/jna/Pointer.createConstant:(I)Lcom/sun/jna/Pointer;
        //   801: invokespecial   com/sun/jna/platform/win32/WinDef$PVOID.<init>:(Lcom/sun/jna/Pointer;)V
        //   804: areturn        
        //   805: aload_0        
        //   806: iload_1        
        //   807: iload_2        
        //   808: aload_3        
        //   809: aload           4
        //   811: aload           5
        //   813: aload           6
        //   815: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onPoke:(IILcom/sun/jna/platform/win32/Ddeml$HCONV;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HDDEDATA;)I
        //   818: istore          13
        //   820: new             Lcom/sun/jna/platform/win32/WinDef$PVOID;
        //   823: dup            
        //   824: iload           13
        //   826: invokestatic    com/sun/jna/Pointer.createConstant:(I)Lcom/sun/jna/Pointer;
        //   829: invokespecial   com/sun/jna/platform/win32/WinDef$PVOID.<init>:(Lcom/sun/jna/Pointer;)V
        //   832: areturn        
        //   833: aload_0        
        //   834: iload_1        
        //   835: iload_2        
        //   836: aload_3        
        //   837: aload           4
        //   839: aload           5
        //   841: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onAdvstop:(IILcom/sun/jna/platform/win32/Ddeml$HCONV;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;)V
        //   844: iload           9
        //   846: ifeq            1188
        //   849: aload_0        
        //   850: iload_1        
        //   851: aload_3        
        //   852: aload           4
        //   854: aload           5
        //   856: aload           8
        //   858: iload           9
        //   860: ifne            894
        //   863: goto            870
        //   866: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   869: athrow         
        //   870: iload           9
        //   872: ifne            894
        //   875: goto            882
        //   878: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   881: athrow         
        //   882: ifnull          928
        //   885: goto            892
        //   888: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   891: athrow         
        //   892: aload           8
        //   894: invokevirtual   com/sun/jna/platform/win32/BaseTSD$ULONG_PTR.intValue:()I
        //   897: iload           9
        //   899: ifne            925
        //   902: iload           9
        //   904: ifne            925
        //   907: goto            914
        //   910: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   913: athrow         
        //   914: ifeq            928
        //   917: goto            924
        //   920: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   923: athrow         
        //   924: iconst_1       
        //   925: goto            929
        //   928: iconst_0       
        //   929: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onConnectConfirm:(ILcom/sun/jna/platform/win32/Ddeml$HCONV;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Z)V
        //   932: iload           9
        //   934: ifeq            1188
        //   937: aload_0        
        //   938: iload_1        
        //   939: aload_3        
        //   940: aload           8
        //   942: iload           9
        //   944: ifne            978
        //   947: goto            954
        //   950: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   953: athrow         
        //   954: iload           9
        //   956: ifne            978
        //   959: goto            966
        //   962: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   965: athrow         
        //   966: ifnull          1012
        //   969: goto            976
        //   972: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   975: athrow         
        //   976: aload           8
        //   978: invokevirtual   com/sun/jna/platform/win32/BaseTSD$ULONG_PTR.intValue:()I
        //   981: iload           9
        //   983: ifne            1009
        //   986: iload           9
        //   988: ifne            1009
        //   991: goto            998
        //   994: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //   997: athrow         
        //   998: ifeq            1012
        //  1001: goto            1008
        //  1004: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  1007: athrow         
        //  1008: iconst_1       
        //  1009: goto            1013
        //  1012: iconst_0       
        //  1013: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onDisconnect:(ILcom/sun/jna/platform/win32/Ddeml$HCONV;Z)V
        //  1016: iload           9
        //  1018: ifeq            1188
        //  1021: aload_0        
        //  1022: iload_1        
        //  1023: aload_3        
        //  1024: aload           8
        //  1026: invokevirtual   com/sun/jna/platform/win32/BaseTSD$ULONG_PTR.longValue:()J
        //  1029: ldc2_w          65535
        //  1032: land           
        //  1033: l2i            
        //  1034: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onError:(ILcom/sun/jna/platform/win32/Ddeml$HCONV;I)V
        //  1037: iload           9
        //  1039: ifeq            1188
        //  1042: goto            1049
        //  1045: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  1048: athrow         
        //  1049: aload_0        
        //  1050: iload_1        
        //  1051: aload           4
        //  1053: aload           5
        //  1055: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onRegister:(ILcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;)V
        //  1058: iload           9
        //  1060: ifeq            1188
        //  1063: goto            1070
        //  1066: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  1069: athrow         
        //  1070: aload_0        
        //  1071: iload_1        
        //  1072: iload_2        
        //  1073: aload_3        
        //  1074: aload           4
        //  1076: aload           5
        //  1078: aload           6
        //  1080: aload           7
        //  1082: aload           8
        //  1084: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onXactComplete:(IILcom/sun/jna/platform/win32/Ddeml$HCONV;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HDDEDATA;Lcom/sun/jna/platform/win32/BaseTSD$ULONG_PTR;Lcom/sun/jna/platform/win32/BaseTSD$ULONG_PTR;)V
        //  1087: iload           9
        //  1089: ifeq            1188
        //  1092: goto            1099
        //  1095: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  1098: athrow         
        //  1099: aload_0        
        //  1100: iload_1        
        //  1101: aload           4
        //  1103: aload           5
        //  1105: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onUnregister:(ILcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;)V
        //  1108: iload           9
        //  1110: ifeq            1188
        //  1113: goto            1120
        //  1116: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  1119: athrow         
        //  1120: aload_0        
        //  1121: iload_1        
        //  1122: aload           6
        //  1124: aload           8
        //  1126: invokevirtual   com/sun/jna/platform/win32/BaseTSD$ULONG_PTR.intValue:()I
        //  1129: invokespecial   com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.onMonitor:(ILcom/sun/jna/platform/win32/Ddeml$HDDEDATA;I)V
        //  1132: iload           9
        //  1134: ifeq            1188
        //  1137: goto            1144
        //  1140: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  1143: athrow         
        //  1144: getstatic       com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.LOG:Ljava/util/logging/Logger;
        //  1147: getstatic       java/util/logging/Level.FINE:Ljava/util/logging/Level;
        //  1150: sipush          10243
        //  1153: sipush          -319
        //  1156: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.a:(II)Ljava/lang/String;
        //  1159: iconst_2       
        //  1160: anewarray       Ljava/lang/Object;
        //  1163: dup            
        //  1164: iconst_0       
        //  1165: iload_1        
        //  1166: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //  1169: aastore        
        //  1170: dup            
        //  1171: iconst_1       
        //  1172: aload           14
        //  1174: aastore        
        //  1175: invokestatic    java/lang/String.format:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //  1178: invokevirtual   java/util/logging/Logger.log:(Ljava/util/logging/Level;Ljava/lang/String;)V
        //  1181: goto            1188
        //  1184: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  1187: athrow         
        //  1188: goto            1227
        //  1191: astore          15
        //  1193: new             Lcom/sun/jna/platform/win32/WinDef$PVOID;
        //  1196: dup            
        //  1197: iconst_m1      
        //  1198: invokestatic    com/sun/jna/Pointer.createConstant:(I)Lcom/sun/jna/Pointer;
        //  1201: invokespecial   com/sun/jna/platform/win32/WinDef$PVOID.<init>:(Lcom/sun/jna/Pointer;)V
        //  1204: areturn        
        //  1205: astore          15
        //  1207: getstatic       com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.LOG:Ljava/util/logging/Logger;
        //  1210: getstatic       java/util/logging/Level.WARNING:Ljava/util/logging/Level;
        //  1213: sipush          10242
        //  1216: sipush          -30197
        //  1219: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.a:(II)Ljava/lang/String;
        //  1222: aload           15
        //  1224: invokevirtual   java/util/logging/Logger.log:(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V
        //  1227: new             Lcom/sun/jna/platform/win32/WinDef$PVOID;
        //  1230: dup            
        //  1231: invokespecial   com/sun/jna/platform/win32/WinDef$PVOID.<init>:()V
        //  1234: areturn        
        //    StackMapTable: 00 6D FF 00 16 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 01 07 00 45 43 01 F7 00 89 07 00 45 03 4D 07 00 45 43 01 18 FF 00 1F 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 00 56 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 06 07 00 02 01 07 00 A8 07 00 A8 07 00 20 07 00 AA 45 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 05 07 00 02 01 07 00 A8 07 00 A8 07 00 20 FF 00 01 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 06 07 00 02 01 07 00 A8 07 00 A8 07 00 20 07 00 AA 4F 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 06 07 00 02 01 07 00 A8 07 00 A8 07 00 20 01 45 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 05 07 00 02 01 07 00 A8 07 00 A8 07 00 20 FF 00 00 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 06 07 00 02 01 07 00 A8 07 00 A8 07 00 20 01 FF 00 02 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 05 07 00 02 01 07 00 A8 07 00 A8 07 00 20 FF 00 00 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 06 07 00 02 01 07 00 A8 07 00 A8 07 00 20 01 FF 00 1B 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 00 FF 00 25 00 10 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 07 00 A9 00 00 05 01 00 01 07 00 45 03 49 07 00 45 43 07 00 19 00 50 07 00 19 FF 00 00 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 00 FF 00 19 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 07 00 A9 00 00 05 00 01 07 00 45 03 49 07 00 45 43 07 00 19 00 50 07 00 19 FF 00 00 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 00 FF 00 1F 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 00 56 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 06 07 00 02 01 07 00 A8 07 00 A8 07 00 20 07 00 AA 45 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 05 07 00 02 01 07 00 A8 07 00 A8 07 00 20 FF 00 01 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 06 07 00 02 01 07 00 A8 07 00 A8 07 00 20 07 00 AA 4F 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 06 07 00 02 01 07 00 A8 07 00 A8 07 00 20 01 45 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 05 07 00 02 01 07 00 A8 07 00 A8 07 00 20 FF 00 00 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 06 07 00 02 01 07 00 A8 07 00 A8 07 00 20 01 FF 00 02 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 05 07 00 02 01 07 00 A8 07 00 A8 07 00 20 FF 00 00 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 06 07 00 02 01 07 00 A8 07 00 A8 07 00 20 01 FF 00 13 00 11 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 07 00 60 00 01 07 00 45 43 07 00 60 45 07 00 45 03 41 07 00 60 4B 07 00 45 03 07 40 01 FF 00 0D 00 15 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 07 00 20 00 05 00 07 00 60 01 07 00 60 01 01 00 00 24 FF 00 27 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 00 1B 23 1B 0F 50 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 06 07 00 02 01 07 00 A7 07 00 A8 07 00 A8 07 00 AA 47 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 06 07 00 02 01 07 00 A7 07 00 A8 07 00 A8 07 00 AA 45 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 05 07 00 02 01 07 00 A7 07 00 A8 07 00 A8 FF 00 01 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 06 07 00 02 01 07 00 A7 07 00 A8 07 00 A8 07 00 AA 4F 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 06 07 00 02 01 07 00 A7 07 00 A8 07 00 A8 01 45 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 05 07 00 02 01 07 00 A7 07 00 A8 07 00 A8 FF 00 00 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 06 07 00 02 01 07 00 A7 07 00 A8 07 00 A8 01 FF 00 02 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 05 07 00 02 01 07 00 A7 07 00 A8 07 00 A8 FF 00 00 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 06 07 00 02 01 07 00 A7 07 00 A8 07 00 A8 01 07 4C 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 04 07 00 02 01 07 00 A7 07 00 AA 47 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 04 07 00 02 01 07 00 A7 07 00 AA 45 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 03 07 00 02 01 07 00 A7 FF 00 01 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 04 07 00 02 01 07 00 A7 07 00 AA 4F 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 04 07 00 02 01 07 00 A7 01 45 07 00 45 FF 00 03 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 03 07 00 02 01 07 00 A7 FF 00 00 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 04 07 00 02 01 07 00 A7 01 FF 00 02 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 03 07 00 02 01 07 00 A7 FF 00 00 00 0F 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 07 00 AA 07 00 AA 01 00 00 00 00 05 00 04 07 00 02 01 07 00 A7 01 07 57 07 00 45 03 50 07 00 45 03 58 07 00 45 03 50 07 00 45 03 53 07 00 45 03 67 07 00 45 03 42 07 00 45 4D 07 00 46 15
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                                            
        //  -----  -----  -----  -----  ----------------------------------------------------------------
        //  26     179    182    186    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  14     164    164    168    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  8      19     22     26     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  8      210    1191   1205   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  290    305    308    312    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  282    295    298    302    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  258    273    276    280    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  243    263    266    270    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  211    344    1191   1205   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  377    394    397    401    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  370    380    383    387    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  345    401    1191   1205   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  402    414    1191   1205   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  440    457    460    464    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  433    443    446    450    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  420    464    1191   1205   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  465    477    1191   1205   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  625    634    637    641    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  601    616    619    623    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  594    606    609    613    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  562    577    580    584    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  554    567    570    574    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  530    545    548    552    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  515    535    538    542    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  483    648    1191   1205   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  649    740    1191   1205   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  741    768    1191   1205   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  769    804    1191   1205   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  805    832    1191   1205   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  1120   1181   1184   1188   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  1099   1137   1140   1144   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  1070   1113   1116   1120   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  1049   1092   1095   1099   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  1021   1063   1066   1070   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  1013   1042   1045   1049   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  986    1001   1004   1008   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  978    991    994    998    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  954    969    972    976    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  937    959    962    966    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  929    947    950    954    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  902    917    920    924    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  894    907    910    914    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  870    885    888    892    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  849    875    878    882    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  833    863    866    870    Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  833    1188   1191   1205   Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  8      210    1205   1227   Ljava/lang/Throwable;
        //  211    344    1205   1227   Ljava/lang/Throwable;
        //  345    401    1205   1227   Ljava/lang/Throwable;
        //  402    414    1205   1227   Ljava/lang/Throwable;
        //  420    464    1205   1227   Ljava/lang/Throwable;
        //  465    477    1205   1227   Ljava/lang/Throwable;
        //  483    648    1205   1227   Ljava/lang/Throwable;
        //  649    740    1205   1227   Ljava/lang/Throwable;
        //  741    768    1205   1227   Ljava/lang/Throwable;
        //  769    804    1205   1227   Ljava/lang/Throwable;
        //  805    832    1205   1227   Ljava/lang/Throwable;
        //  833    1188   1205   1227   Ljava/lang/Throwable;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0026:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void registerAdvstartHandler(final DdemlUtil$AdvstartHandler ddemlUtil$AdvstartHandler) {
        this.advstartHandler.add(ddemlUtil$AdvstartHandler);
    }
    
    public void unregisterAdvstartHandler(final DdemlUtil$AdvstartHandler ddemlUtil$AdvstartHandler) {
        this.advstartHandler.remove(ddemlUtil$AdvstartHandler);
    }
    
    private boolean onAdvstart(final int p0, final int p1, final Ddeml$HCONV p2, final Ddeml$HSZ p3, final Ddeml$HSZ p4) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: istore          7
        //     3: invokestatic    com/sun/jna/platform/win32/WinNT$HANDLE.c:()Z
        //     6: aload_0        
        //     7: getfield        com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.advstartHandler:Ljava/util/List;
        //    10: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //    15: astore          8
        //    17: istore          6
        //    19: aload           8
        //    21: invokeinterface java/util/Iterator.hasNext:()Z
        //    26: ifeq            102
        //    29: aload           8
        //    31: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //    36: checkcast       Lcom/sun/jna/platform/win32/DdemlUtil$AdvstartHandler;
        //    39: astore          9
        //    41: aload           9
        //    43: iload_1        
        //    44: iload_2        
        //    45: aload_3        
        //    46: aload           4
        //    48: aload           5
        //    50: invokeinterface com/sun/jna/platform/win32/DdemlUtil$AdvstartHandler.onAdvstart:(IILcom/sun/jna/platform/win32/Ddeml$HCONV;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;)Z
        //    55: iload           6
        //    57: ifeq            104
        //    60: iload           6
        //    62: ifeq            95
        //    65: goto            72
        //    68: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    71: athrow         
        //    72: iload           6
        //    74: ifeq            95
        //    77: goto            84
        //    80: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    83: athrow         
        //    84: ifeq            97
        //    87: goto            94
        //    90: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    93: athrow         
        //    94: iconst_1       
        //    95: istore          7
        //    97: iload           6
        //    99: ifne            19
        //   102: iload           7
        //   104: ireturn        
        //    StackMapTable: 00 0B FE 00 13 01 01 07 00 B5 FF 00 30 00 0A 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 01 01 07 00 B5 07 00 4E 00 01 07 00 45 43 01 47 07 00 45 43 01 45 07 00 45 03 40 01 01 FA 00 04 41 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                                            
        //  -----  -----  -----  -----  ----------------------------------------------------------------
        //  41     65     68     72     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  60     77     80     84     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  72     87     90     94     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0072:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void registerAdvstopHandler(final DdemlUtil$AdvstopHandler ddemlUtil$AdvstopHandler) {
        this.advstopHandler.add(ddemlUtil$AdvstopHandler);
    }
    
    public void unregisterAdvstopHandler(final DdemlUtil$AdvstopHandler ddemlUtil$AdvstopHandler) {
        this.advstopHandler.remove(ddemlUtil$AdvstopHandler);
    }
    
    private void onAdvstop(final int n, final int n2, final Ddeml$HCONV ddeml$HCONV, final Ddeml$HSZ ddeml$HSZ, final Ddeml$HSZ ddeml$HSZ2) {
        final boolean c = WinNT$HANDLE.c();
        final Iterator<DdemlUtil$AdvstopHandler> iterator = this.advstopHandler.iterator();
        final boolean b = c;
        while (iterator.hasNext()) {
            iterator.next().onAdvstop(n, n2, ddeml$HCONV, ddeml$HSZ, ddeml$HSZ2);
            if (!b) {
                break;
            }
        }
    }
    
    public void registerConnectHandler(final DdemlUtil$ConnectHandler ddemlUtil$ConnectHandler) {
        this.connectHandler.add(ddemlUtil$ConnectHandler);
    }
    
    public void unregisterConnectHandler(final DdemlUtil$ConnectHandler ddemlUtil$ConnectHandler) {
        this.connectHandler.remove(ddemlUtil$ConnectHandler);
    }
    
    private boolean onConnect(final int p0, final Ddeml$HSZ p1, final Ddeml$HSZ p2, final Ddeml$CONVCONTEXT p3, final boolean p4) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: iconst_0       
        //     4: istore          7
        //     6: istore          6
        //     8: aload_0        
        //     9: getfield        com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.connectHandler:Ljava/util/List;
        //    12: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //    17: astore          8
        //    19: aload           8
        //    21: invokeinterface java/util/Iterator.hasNext:()Z
        //    26: ifeq            102
        //    29: aload           8
        //    31: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //    36: checkcast       Lcom/sun/jna/platform/win32/DdemlUtil$ConnectHandler;
        //    39: astore          9
        //    41: aload           9
        //    43: iload_1        
        //    44: aload_2        
        //    45: aload_3        
        //    46: aload           4
        //    48: iload           5
        //    50: invokeinterface com/sun/jna/platform/win32/DdemlUtil$ConnectHandler.onConnect:(ILcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$CONVCONTEXT;Z)Z
        //    55: iload           6
        //    57: ifne            104
        //    60: iload           6
        //    62: ifne            95
        //    65: goto            72
        //    68: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    71: athrow         
        //    72: iload           6
        //    74: ifne            95
        //    77: goto            84
        //    80: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    83: athrow         
        //    84: ifeq            97
        //    87: goto            94
        //    90: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    93: athrow         
        //    94: iconst_1       
        //    95: istore          7
        //    97: iload           6
        //    99: ifeq            19
        //   102: iload           7
        //   104: ireturn        
        //    StackMapTable: 00 0B FE 00 13 01 01 07 00 B5 FF 00 30 00 0A 07 00 02 01 07 00 A8 07 00 A8 07 00 20 01 01 01 07 00 B5 07 00 52 00 01 07 00 45 43 01 47 07 00 45 43 01 45 07 00 45 03 40 01 01 FA 00 04 41 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                                            
        //  -----  -----  -----  -----  ----------------------------------------------------------------
        //  41     65     68     72     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  60     77     80     84     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  72     87     90     94     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0072:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void registerAdvReqHandler(final DdemlUtil$AdvreqHandler ddemlUtil$AdvreqHandler) {
        this.advReqHandler.add(ddemlUtil$AdvreqHandler);
    }
    
    public void unregisterAdvReqHandler(final DdemlUtil$AdvreqHandler ddemlUtil$AdvreqHandler) {
        this.advReqHandler.remove(ddemlUtil$AdvreqHandler);
    }
    
    private Ddeml$HDDEDATA onAdvreq(final int n, final int n2, final Ddeml$HCONV ddeml$HCONV, final Ddeml$HSZ ddeml$HSZ, final Ddeml$HSZ ddeml$HSZ2, final int n3) {
        final boolean a = WinNT$HANDLE.a();
        final Iterator<DdemlUtil$AdvreqHandler> iterator = this.advReqHandler.iterator();
        final boolean b = a;
        while (iterator.hasNext()) {
            final Ddeml$HDDEDATA onAdvreq = iterator.next().onAdvreq(n, n2, ddeml$HCONV, ddeml$HSZ, ddeml$HSZ2, n3);
            Ddeml$HDDEDATA ddeml$HDDEDATA = null;
            Label_0085: {
                Label_0088: {
                    Label_0075: {
                        try {
                            ddeml$HDDEDATA = onAdvreq;
                            if (b) {
                                return ddeml$HDDEDATA;
                            }
                            final boolean b2 = b;
                            if (!b2) {
                                break Label_0075;
                            }
                            return ddeml$HDDEDATA;
                        }
                        catch (DdemlUtil$DdeAdapter$BlockException ex) {
                            throw b(ex);
                        }
                        try {
                            final boolean b2 = b;
                            if (b2) {
                                return ddeml$HDDEDATA;
                            }
                            if (ddeml$HDDEDATA == null) {
                                break Label_0088;
                            }
                        }
                        catch (DdemlUtil$DdeAdapter$BlockException ex2) {
                            throw b(ex2);
                        }
                    }
                    break Label_0085;
                }
                if (b) {
                    break;
                }
                continue;
            }
            return ddeml$HDDEDATA;
        }
        return null;
    }
    
    public void registerRequestHandler(final DdemlUtil$RequestHandler ddemlUtil$RequestHandler) {
        this.requestHandler.add(ddemlUtil$RequestHandler);
    }
    
    public void unregisterRequestHandler(final DdemlUtil$RequestHandler ddemlUtil$RequestHandler) {
        this.requestHandler.remove(ddemlUtil$RequestHandler);
    }
    
    private Ddeml$HDDEDATA onRequest(final int n, final int n2, final Ddeml$HCONV ddeml$HCONV, final Ddeml$HSZ ddeml$HSZ, final Ddeml$HSZ ddeml$HSZ2) {
        final boolean c = WinNT$HANDLE.c();
        final Iterator<DdemlUtil$RequestHandler> iterator = this.requestHandler.iterator();
        final boolean b = c;
        while (iterator.hasNext()) {
            final Ddeml$HDDEDATA onRequest = iterator.next().onRequest(n, n2, ddeml$HCONV, ddeml$HSZ, ddeml$HSZ2);
            Ddeml$HDDEDATA ddeml$HDDEDATA = null;
            Label_0083: {
                Label_0086: {
                    Label_0073: {
                        try {
                            ddeml$HDDEDATA = onRequest;
                            if (!b) {
                                return ddeml$HDDEDATA;
                            }
                            final boolean b2 = b;
                            if (b2) {
                                break Label_0073;
                            }
                            return ddeml$HDDEDATA;
                        }
                        catch (DdemlUtil$DdeAdapter$BlockException ex) {
                            throw b(ex);
                        }
                        try {
                            final boolean b2 = b;
                            if (!b2) {
                                return ddeml$HDDEDATA;
                            }
                            if (ddeml$HDDEDATA == null) {
                                break Label_0086;
                            }
                        }
                        catch (DdemlUtil$DdeAdapter$BlockException ex2) {
                            throw b(ex2);
                        }
                    }
                    break Label_0083;
                }
                if (!b) {
                    break;
                }
                continue;
            }
            return ddeml$HDDEDATA;
        }
        return null;
    }
    
    public void registerWildconnectHandler(final DdemlUtil$WildconnectHandler ddemlUtil$WildconnectHandler) {
        this.wildconnectHandler.add(ddemlUtil$WildconnectHandler);
    }
    
    public void unregisterWildconnectHandler(final DdemlUtil$WildconnectHandler ddemlUtil$WildconnectHandler) {
        this.wildconnectHandler.remove(ddemlUtil$WildconnectHandler);
    }
    
    private Ddeml$HSZPAIR[] onWildconnect(final int n, final Ddeml$HSZ ddeml$HSZ, final Ddeml$HSZ ddeml$HSZ2, final Ddeml$CONVCONTEXT ddeml$CONVCONTEXT, final boolean b) {
        final boolean a = WinNT$HANDLE.a();
        final ArrayList list = new ArrayList(1);
        final boolean b2 = a;
        ArrayList list2 = null;
        for (final DdemlUtil$WildconnectHandler ddemlUtil$WildconnectHandler : this.wildconnectHandler) {
            try {
                list2 = list;
                if (b2) {
                    return (Ddeml$HSZPAIR[])list2.toArray(new Ddeml$HSZPAIR[list.size()]);
                }
                list2.addAll(ddemlUtil$WildconnectHandler.onWildconnect(n, ddeml$HSZ, ddeml$HSZ2, ddeml$CONVCONTEXT, b));
                if (!b2) {
                    continue;
                }
            }
            catch (DdemlUtil$DdeAdapter$BlockException ex) {
                throw b(ex);
            }
            break;
        }
        return (Ddeml$HSZPAIR[])list2.toArray(new Ddeml$HSZPAIR[list.size()]);
    }
    
    public void registerAdvdataHandler(final DdemlUtil$AdvdataHandler ddemlUtil$AdvdataHandler) {
        this.advdataHandler.add(ddemlUtil$AdvdataHandler);
    }
    
    public void unregisterAdvdataHandler(final DdemlUtil$AdvdataHandler ddemlUtil$AdvdataHandler) {
        this.advdataHandler.remove(ddemlUtil$AdvdataHandler);
    }
    
    private int onAdvdata(final int p0, final int p1, final Ddeml$HCONV p2, final Ddeml$HSZ p3, final Ddeml$HSZ p4, final Ddeml$HDDEDATA p5) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: getfield        com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.advdataHandler:Ljava/util/List;
        //     7: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //    12: astore          8
        //    14: istore          7
        //    16: aload           8
        //    18: invokeinterface java/util/Iterator.hasNext:()Z
        //    23: ifeq            105
        //    26: aload           8
        //    28: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //    33: checkcast       Lcom/sun/jna/platform/win32/DdemlUtil$AdvdataHandler;
        //    36: astore          9
        //    38: aload           9
        //    40: iload_1        
        //    41: iload_2        
        //    42: aload_3        
        //    43: aload           4
        //    45: aload           5
        //    47: aload           6
        //    49: invokeinterface com/sun/jna/platform/win32/DdemlUtil$AdvdataHandler.onAdvdata:(IILcom/sun/jna/platform/win32/Ddeml$HCONV;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HDDEDATA;)I
        //    54: istore          10
        //    56: iload           10
        //    58: iload           7
        //    60: ifeq            106
        //    63: iload           7
        //    65: ifeq            99
        //    68: goto            75
        //    71: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    74: athrow         
        //    75: iload           7
        //    77: ifeq            99
        //    80: goto            87
        //    83: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    86: athrow         
        //    87: ifeq            100
        //    90: goto            97
        //    93: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    96: athrow         
        //    97: iload           10
        //    99: ireturn        
        //   100: iload           7
        //   102: ifne            16
        //   105: iconst_0       
        //   106: ireturn        
        //    StackMapTable: 00 0B FD 00 10 01 07 00 B5 FF 00 36 00 0B 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 01 07 00 B5 07 00 61 01 00 01 07 00 45 43 01 47 07 00 45 43 01 45 07 00 45 03 41 01 00 F9 00 04 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                                            
        //  -----  -----  -----  -----  ----------------------------------------------------------------
        //  56     68     71     75     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  63     80     83     87     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  75     90     93     97     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0075:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void registerExecuteHandler(final DdemlUtil$ExecuteHandler ddemlUtil$ExecuteHandler) {
        this.executeHandler.add(ddemlUtil$ExecuteHandler);
    }
    
    public void unregisterExecuteHandler(final DdemlUtil$ExecuteHandler ddemlUtil$ExecuteHandler) {
        this.executeHandler.remove(ddemlUtil$ExecuteHandler);
    }
    
    private int onExecute(final int p0, final Ddeml$HCONV p1, final Ddeml$HSZ p2, final Ddeml$HDDEDATA p3) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: getfield        com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.executeHandler:Ljava/util/List;
        //     7: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //    12: astore          6
        //    14: istore          5
        //    16: aload           6
        //    18: invokeinterface java/util/Iterator.hasNext:()Z
        //    23: ifeq            101
        //    26: aload           6
        //    28: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //    33: checkcast       Lcom/sun/jna/platform/win32/DdemlUtil$ExecuteHandler;
        //    36: astore          7
        //    38: aload           7
        //    40: iload_1        
        //    41: aload_2        
        //    42: aload_3        
        //    43: aload           4
        //    45: invokeinterface com/sun/jna/platform/win32/DdemlUtil$ExecuteHandler.onExecute:(ILcom/sun/jna/platform/win32/Ddeml$HCONV;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HDDEDATA;)I
        //    50: istore          8
        //    52: iload           8
        //    54: iload           5
        //    56: ifne            102
        //    59: iload           5
        //    61: ifne            95
        //    64: goto            71
        //    67: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    70: athrow         
        //    71: iload           5
        //    73: ifne            95
        //    76: goto            83
        //    79: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    82: athrow         
        //    83: ifeq            96
        //    86: goto            93
        //    89: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    92: athrow         
        //    93: iload           8
        //    95: ireturn        
        //    96: iload           5
        //    98: ifeq            16
        //   101: iconst_0       
        //   102: ireturn        
        //    StackMapTable: 00 0B FD 00 10 01 07 00 B5 FF 00 32 00 09 07 00 02 01 07 00 A7 07 00 A8 07 00 A9 01 07 00 B5 07 00 64 01 00 01 07 00 45 43 01 47 07 00 45 43 01 45 07 00 45 03 41 01 00 F9 00 04 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                                            
        //  -----  -----  -----  -----  ----------------------------------------------------------------
        //  52     64     67     71     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  59     76     79     83     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  71     86     89     93     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0071:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void registerPokeHandler(final DdemlUtil$PokeHandler ddemlUtil$PokeHandler) {
        this.pokeHandler.add(ddemlUtil$PokeHandler);
    }
    
    public void unregisterPokeHandler(final DdemlUtil$PokeHandler ddemlUtil$PokeHandler) {
        this.pokeHandler.remove(ddemlUtil$PokeHandler);
    }
    
    private int onPoke(final int p0, final int p1, final Ddeml$HCONV p2, final Ddeml$HSZ p3, final Ddeml$HSZ p4, final Ddeml$HDDEDATA p5) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: getfield        com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.pokeHandler:Ljava/util/List;
        //     7: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //    12: astore          8
        //    14: istore          7
        //    16: aload           8
        //    18: invokeinterface java/util/Iterator.hasNext:()Z
        //    23: ifeq            105
        //    26: aload           8
        //    28: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //    33: checkcast       Lcom/sun/jna/platform/win32/DdemlUtil$PokeHandler;
        //    36: astore          9
        //    38: aload           9
        //    40: iload_1        
        //    41: iload_2        
        //    42: aload_3        
        //    43: aload           4
        //    45: aload           5
        //    47: aload           6
        //    49: invokeinterface com/sun/jna/platform/win32/DdemlUtil$PokeHandler.onPoke:(IILcom/sun/jna/platform/win32/Ddeml$HCONV;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HSZ;Lcom/sun/jna/platform/win32/Ddeml$HDDEDATA;)I
        //    54: istore          10
        //    56: iload           10
        //    58: iload           7
        //    60: ifeq            106
        //    63: iload           7
        //    65: ifeq            99
        //    68: goto            75
        //    71: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    74: athrow         
        //    75: iload           7
        //    77: ifeq            99
        //    80: goto            87
        //    83: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    86: athrow         
        //    87: ifeq            100
        //    90: goto            97
        //    93: invokestatic    com/sun/jna/platform/win32/DdemlUtil$DdeAdapter.b:(Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;)Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //    96: athrow         
        //    97: iload           10
        //    99: ireturn        
        //   100: iload           7
        //   102: ifne            16
        //   105: iconst_0       
        //   106: ireturn        
        //    StackMapTable: 00 0B FD 00 10 01 07 00 B5 FF 00 36 00 0B 07 00 02 01 01 07 00 A7 07 00 A8 07 00 A8 07 00 A9 01 07 00 B5 07 00 66 01 00 01 07 00 45 43 01 47 07 00 45 43 01 45 07 00 45 03 41 01 00 F9 00 04 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                                            
        //  -----  -----  -----  -----  ----------------------------------------------------------------
        //  56     68     71     75     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  63     80     83     87     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        //  75     90     93     97     Lcom/sun/jna/platform/win32/DdemlUtil$DdeAdapter$BlockException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0075:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void registerConnectConfirmHandler(final DdemlUtil$ConnectConfirmHandler ddemlUtil$ConnectConfirmHandler) {
        this.connectConfirmHandler.add(ddemlUtil$ConnectConfirmHandler);
    }
    
    public void unregisterConnectConfirmHandler(final DdemlUtil$ConnectConfirmHandler ddemlUtil$ConnectConfirmHandler) {
        this.connectConfirmHandler.remove(ddemlUtil$ConnectConfirmHandler);
    }
    
    private void onConnectConfirm(final int n, final Ddeml$HCONV ddeml$HCONV, final Ddeml$HSZ ddeml$HSZ, final Ddeml$HSZ ddeml$HSZ2, final boolean b) {
        final boolean a = WinNT$HANDLE.a();
        final Iterator<DdemlUtil$ConnectConfirmHandler> iterator = this.connectConfirmHandler.iterator();
        final boolean b2 = a;
        while (iterator.hasNext()) {
            iterator.next().onConnectConfirm(n, ddeml$HCONV, ddeml$HSZ, ddeml$HSZ2, b);
            if (b2) {
                break;
            }
        }
    }
    
    public void registerDisconnectHandler(final DdemlUtil$DisconnectHandler ddemlUtil$DisconnectHandler) {
        this.disconnectHandler.add(ddemlUtil$DisconnectHandler);
    }
    
    public void unregisterDisconnectHandler(final DdemlUtil$DisconnectHandler ddemlUtil$DisconnectHandler) {
        this.disconnectHandler.remove(ddemlUtil$DisconnectHandler);
    }
    
    private void onDisconnect(final int n, final Ddeml$HCONV ddeml$HCONV, final boolean b) {
        final boolean c = WinNT$HANDLE.c();
        final Iterator<DdemlUtil$DisconnectHandler> iterator = this.disconnectHandler.iterator();
        final boolean b2 = c;
        while (iterator.hasNext()) {
            iterator.next().onDisconnect(n, ddeml$HCONV, b);
            if (!b2) {
                break;
            }
        }
    }
    
    public void registerErrorHandler(final DdemlUtil$ErrorHandler ddemlUtil$ErrorHandler) {
        this.errorHandler.add(ddemlUtil$ErrorHandler);
    }
    
    public void unregisterErrorHandler(final DdemlUtil$ErrorHandler ddemlUtil$ErrorHandler) {
        this.errorHandler.remove(ddemlUtil$ErrorHandler);
    }
    
    private void onError(final int n, final Ddeml$HCONV ddeml$HCONV, final int n2) {
        final boolean c = WinNT$HANDLE.c();
        final Iterator<DdemlUtil$ErrorHandler> iterator = this.errorHandler.iterator();
        final boolean b = c;
        while (iterator.hasNext()) {
            iterator.next().onError(n, ddeml$HCONV, n2);
            if (!b) {
                break;
            }
        }
    }
    
    public void registerRegisterHandler(final DdemlUtil$RegisterHandler ddemlUtil$RegisterHandler) {
        this.registerHandler.add(ddemlUtil$RegisterHandler);
    }
    
    public void unregisterRegisterHandler(final DdemlUtil$RegisterHandler ddemlUtil$RegisterHandler) {
        this.registerHandler.remove(ddemlUtil$RegisterHandler);
    }
    
    private void onRegister(final int n, final Ddeml$HSZ ddeml$HSZ, final Ddeml$HSZ ddeml$HSZ2) {
        final boolean c = WinNT$HANDLE.c();
        final Iterator<DdemlUtil$RegisterHandler> iterator = this.registerHandler.iterator();
        final boolean b = c;
        while (iterator.hasNext()) {
            iterator.next().onRegister(n, ddeml$HSZ, ddeml$HSZ2);
            if (!b) {
                break;
            }
        }
    }
    
    public void registerXactCompleteHandler(final DdemlUtil$XactCompleteHandler ddemlUtil$XactCompleteHandler) {
        this.xactCompleteHandler.add(ddemlUtil$XactCompleteHandler);
    }
    
    public void xactCompleteXactCompleteHandler(final DdemlUtil$XactCompleteHandler ddemlUtil$XactCompleteHandler) {
        this.xactCompleteHandler.remove(ddemlUtil$XactCompleteHandler);
    }
    
    private void onXactComplete(final int n, final int n2, final Ddeml$HCONV ddeml$HCONV, final Ddeml$HSZ ddeml$HSZ, final Ddeml$HSZ ddeml$HSZ2, final Ddeml$HDDEDATA ddeml$HDDEDATA, final BaseTSD$ULONG_PTR baseTSD$ULONG_PTR, final BaseTSD$ULONG_PTR baseTSD$ULONG_PTR2) {
        final boolean c = WinNT$HANDLE.c();
        final Iterator<DdemlUtil$XactCompleteHandler> iterator = this.xactCompleteHandler.iterator();
        final boolean b = c;
        while (iterator.hasNext()) {
            iterator.next().onXactComplete(n, n2, ddeml$HCONV, ddeml$HSZ, ddeml$HSZ2, ddeml$HDDEDATA, baseTSD$ULONG_PTR, baseTSD$ULONG_PTR2);
            if (!b) {
                break;
            }
        }
    }
    
    public void registerUnregisterHandler(final DdemlUtil$UnregisterHandler ddemlUtil$UnregisterHandler) {
        this.unregisterHandler.add(ddemlUtil$UnregisterHandler);
    }
    
    public void unregisterUnregisterHandler(final DdemlUtil$UnregisterHandler ddemlUtil$UnregisterHandler) {
        this.unregisterHandler.remove(ddemlUtil$UnregisterHandler);
    }
    
    private void onUnregister(final int n, final Ddeml$HSZ ddeml$HSZ, final Ddeml$HSZ ddeml$HSZ2) {
        final boolean c = WinNT$HANDLE.c();
        final Iterator<DdemlUtil$UnregisterHandler> iterator = this.unregisterHandler.iterator();
        final boolean b = c;
        while (iterator.hasNext()) {
            iterator.next().onUnregister(n, ddeml$HSZ, ddeml$HSZ2);
            if (!b) {
                break;
            }
        }
    }
    
    public void registerMonitorHandler(final DdemlUtil$MonitorHandler ddemlUtil$MonitorHandler) {
        this.monitorHandler.add(ddemlUtil$MonitorHandler);
    }
    
    public void unregisterMonitorHandler(final DdemlUtil$MonitorHandler ddemlUtil$MonitorHandler) {
        this.monitorHandler.remove(ddemlUtil$MonitorHandler);
    }
    
    private void onMonitor(final int n, final Ddeml$HDDEDATA ddeml$HDDEDATA, final int n2) {
        final boolean c = WinNT$HANDLE.c();
        final Iterator<DdemlUtil$MonitorHandler> iterator = this.monitorHandler.iterator();
        final boolean b = c;
        while (iterator.hasNext()) {
            iterator.next().onMonitor(n, ddeml$HDDEDATA, n2);
            if (!b) {
                break;
            }
        }
    }
    
    static {
        final String[] a2 = new String[2];
        int n = 0;
        final String s;
        final int length = (s = "\u00ea*\u00deO\u001b\u00f3&\u00d8\u0084´Bc\u008b\u00d9\"\u00d8\u00c6\u008f w\u00d5]\u009d\u00807+µ\u009b\f_o\u008dr\u00c0\u00cf¬\u00e8\u008f\u0089\\²!\u001aX\u00e8\u00f1fpT<\u0097®¤:¨\u00f5_?\u008e\u00cb\u00dbu\u00e3\u009ca\u00e3#\u00c5=\u00f1V\u00cc1\u00d8:\u00d01\u0003\u00c7o").length();
        int char1 = 24;
        int index = -1;
        Label_0022: {
            break Label_0022;
            do {
                char1 = s.charAt(index);
                int n4;
                int n3;
                final int n2 = n3 = (n4 = 63);
                ++index;
                final String s2 = s;
                final int beginIndex = index;
                final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
                final int length2 = charArray.length;
                int n5 = 0;
                while (true) {
                    Label_0200: {
                        if (length2 > 1) {
                            break Label_0200;
                        }
                        n4 = (n3 = n5);
                        do {
                            final char c = charArray[n3];
                            int n6 = 0;
                            switch (n5 % 7) {
                                case 0: {
                                    n6 = 44;
                                    break;
                                }
                                case 1: {
                                    n6 = 86;
                                    break;
                                }
                                case 2: {
                                    n6 = 80;
                                    break;
                                }
                                case 3: {
                                    n6 = 10;
                                    break;
                                }
                                case 4: {
                                    n6 = 109;
                                    break;
                                }
                                case 5: {
                                    n6 = 62;
                                    break;
                                }
                                default: {
                                    n6 = 39;
                                    break;
                                }
                            }
                            charArray[n4] = (char)(c ^ (n2 ^ n6));
                            ++n5;
                        } while (n2 == 0);
                    }
                    if (length2 > n5) {
                        continue;
                    }
                    break;
                }
                a2[n++] = new String(charArray).intern();
            } while ((index += char1) < length);
        }
        a = a2;
        b = new String[2];
        LOG = Logger.getLogger(DdemlUtil$DdeAdapter.class.getName());
    }
    
    private static DdemlUtil$DdeAdapter$BlockException b(final DdemlUtil$DdeAdapter$BlockException ex) {
        return ex;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0x2802) & 0xFFFF;
        if (DdemlUtil$DdeAdapter.b[n3] == null) {
            final char[] charArray = DdemlUtil$DdeAdapter.a[n3].toCharArray();
            int n4 = 0;
            switch (charArray[0] & '\u00ff') {
                case 0: {
                    n4 = 176;
                    break;
                }
                case 1: {
                    n4 = 91;
                    break;
                }
                case 2: {
                    n4 = 204;
                    break;
                }
                case 3: {
                    n4 = 181;
                    break;
                }
                case 4: {
                    n4 = 131;
                    break;
                }
                case 5: {
                    n4 = 215;
                    break;
                }
                case 6: {
                    n4 = 135;
                    break;
                }
                case 7: {
                    n4 = 72;
                    break;
                }
                case 8: {
                    n4 = 245;
                    break;
                }
                case 9: {
                    n4 = 60;
                    break;
                }
                case 10: {
                    n4 = 78;
                    break;
                }
                case 11: {
                    n4 = 222;
                    break;
                }
                case 12: {
                    n4 = 150;
                    break;
                }
                case 13: {
                    n4 = 248;
                    break;
                }
                case 14: {
                    n4 = 14;
                    break;
                }
                case 15: {
                    n4 = 56;
                    break;
                }
                case 16: {
                    n4 = 36;
                    break;
                }
                case 17: {
                    n4 = 154;
                    break;
                }
                case 18: {
                    n4 = 244;
                    break;
                }
                case 19: {
                    n4 = 48;
                    break;
                }
                case 20: {
                    n4 = 208;
                    break;
                }
                case 21: {
                    n4 = 157;
                    break;
                }
                case 22: {
                    n4 = 93;
                    break;
                }
                case 23: {
                    n4 = 177;
                    break;
                }
                case 24: {
                    n4 = 89;
                    break;
                }
                case 25: {
                    n4 = 191;
                    break;
                }
                case 26: {
                    n4 = 242;
                    break;
                }
                case 27: {
                    n4 = 210;
                    break;
                }
                case 28: {
                    n4 = 141;
                    break;
                }
                case 29: {
                    n4 = 227;
                    break;
                }
                case 30: {
                    n4 = 119;
                    break;
                }
                case 31: {
                    n4 = 28;
                    break;
                }
                case 32: {
                    n4 = 115;
                    break;
                }
                case 33: {
                    n4 = 110;
                    break;
                }
                case 34: {
                    n4 = 163;
                    break;
                }
                case 35: {
                    n4 = 239;
                    break;
                }
                case 36: {
                    n4 = 1;
                    break;
                }
                case 37: {
                    n4 = 96;
                    break;
                }
                case 38: {
                    n4 = 249;
                    break;
                }
                case 39: {
                    n4 = 127;
                    break;
                }
                case 40: {
                    n4 = 105;
                    break;
                }
                case 41: {
                    n4 = 139;
                    break;
                }
                case 42: {
                    n4 = 151;
                    break;
                }
                case 43: {
                    n4 = 17;
                    break;
                }
                case 44: {
                    n4 = 193;
                    break;
                }
                case 45: {
                    n4 = 189;
                    break;
                }
                case 46: {
                    n4 = 253;
                    break;
                }
                case 47: {
                    n4 = 23;
                    break;
                }
                case 48: {
                    n4 = 238;
                    break;
                }
                case 49: {
                    n4 = 104;
                    break;
                }
                case 50: {
                    n4 = 126;
                    break;
                }
                case 51: {
                    n4 = 27;
                    break;
                }
                case 52: {
                    n4 = 197;
                    break;
                }
                case 53: {
                    n4 = 207;
                    break;
                }
                case 54: {
                    n4 = 112;
                    break;
                }
                case 55: {
                    n4 = 233;
                    break;
                }
                case 56: {
                    n4 = 75;
                    break;
                }
                case 57: {
                    n4 = 22;
                    break;
                }
                case 58: {
                    n4 = 97;
                    break;
                }
                case 59: {
                    n4 = 0;
                    break;
                }
                case 60: {
                    n4 = 86;
                    break;
                }
                case 61: {
                    n4 = 138;
                    break;
                }
                case 62: {
                    n4 = 7;
                    break;
                }
                case 63: {
                    n4 = 90;
                    break;
                }
                case 64: {
                    n4 = 148;
                    break;
                }
                case 65: {
                    n4 = 202;
                    break;
                }
                case 66: {
                    n4 = 68;
                    break;
                }
                case 67: {
                    n4 = 182;
                    break;
                }
                case 68: {
                    n4 = 129;
                    break;
                }
                case 69: {
                    n4 = 155;
                    break;
                }
                case 70: {
                    n4 = 98;
                    break;
                }
                case 71: {
                    n4 = 134;
                    break;
                }
                case 72: {
                    n4 = 216;
                    break;
                }
                case 73: {
                    n4 = 113;
                    break;
                }
                case 74: {
                    n4 = 226;
                    break;
                }
                case 75: {
                    n4 = 69;
                    break;
                }
                case 76: {
                    n4 = 223;
                    break;
                }
                case 77: {
                    n4 = 217;
                    break;
                }
                case 78: {
                    n4 = 121;
                    break;
                }
                case 79: {
                    n4 = 137;
                    break;
                }
                case 80: {
                    n4 = 186;
                    break;
                }
                case 81: {
                    n4 = 231;
                    break;
                }
                case 82: {
                    n4 = 132;
                    break;
                }
                case 83: {
                    n4 = 70;
                    break;
                }
                case 84: {
                    n4 = 15;
                    break;
                }
                case 85: {
                    n4 = 59;
                    break;
                }
                case 86: {
                    n4 = 57;
                    break;
                }
                case 87: {
                    n4 = 21;
                    break;
                }
                case 88: {
                    n4 = 200;
                    break;
                }
                case 89: {
                    n4 = 195;
                    break;
                }
                case 90: {
                    n4 = 185;
                    break;
                }
                case 91: {
                    n4 = 201;
                    break;
                }
                case 92: {
                    n4 = 196;
                    break;
                }
                case 93: {
                    n4 = 42;
                    break;
                }
                case 94: {
                    n4 = 18;
                    break;
                }
                case 95: {
                    n4 = 255;
                    break;
                }
                case 96: {
                    n4 = 225;
                    break;
                }
                case 97: {
                    n4 = 81;
                    break;
                }
                case 98: {
                    n4 = 82;
                    break;
                }
                case 99: {
                    n4 = 5;
                    break;
                }
                case 100: {
                    n4 = 71;
                    break;
                }
                case 101: {
                    n4 = 30;
                    break;
                }
                case 102: {
                    n4 = 229;
                    break;
                }
                case 103: {
                    n4 = 122;
                    break;
                }
                case 104: {
                    n4 = 47;
                    break;
                }
                case 105: {
                    n4 = 117;
                    break;
                }
                case 106: {
                    n4 = 54;
                    break;
                }
                case 107: {
                    n4 = 24;
                    break;
                }
                case 108: {
                    n4 = 77;
                    break;
                }
                case 109: {
                    n4 = 66;
                    break;
                }
                case 110: {
                    n4 = 114;
                    break;
                }
                case 111: {
                    n4 = 35;
                    break;
                }
                case 112: {
                    n4 = 20;
                    break;
                }
                case 113: {
                    n4 = 99;
                    break;
                }
                case 114: {
                    n4 = 147;
                    break;
                }
                case 115: {
                    n4 = 159;
                    break;
                }
                case 116: {
                    n4 = 111;
                    break;
                }
                case 117: {
                    n4 = 205;
                    break;
                }
                case 118: {
                    n4 = 67;
                    break;
                }
                case 119: {
                    n4 = 38;
                    break;
                }
                case 120: {
                    n4 = 174;
                    break;
                }
                case 121: {
                    n4 = 85;
                    break;
                }
                case 122: {
                    n4 = 83;
                    break;
                }
                case 123: {
                    n4 = 74;
                    break;
                }
                case 124: {
                    n4 = 173;
                    break;
                }
                case 125: {
                    n4 = 221;
                    break;
                }
                case 126: {
                    n4 = 125;
                    break;
                }
                case 127: {
                    n4 = 241;
                    break;
                }
                case 128: {
                    n4 = 169;
                    break;
                }
                case 129: {
                    n4 = 218;
                    break;
                }
                case 130: {
                    n4 = 145;
                    break;
                }
                case 131: {
                    n4 = 43;
                    break;
                }
                case 132: {
                    n4 = 92;
                    break;
                }
                case 133: {
                    n4 = 149;
                    break;
                }
                case 134: {
                    n4 = 10;
                    break;
                }
                case 135: {
                    n4 = 162;
                    break;
                }
                case 136: {
                    n4 = 254;
                    break;
                }
                case 137: {
                    n4 = 12;
                    break;
                }
                case 138: {
                    n4 = 199;
                    break;
                }
                case 139: {
                    n4 = 31;
                    break;
                }
                case 140: {
                    n4 = 49;
                    break;
                }
                case 141: {
                    n4 = 53;
                    break;
                }
                case 142: {
                    n4 = 172;
                    break;
                }
                case 143: {
                    n4 = 198;
                    break;
                }
                case 144: {
                    n4 = 100;
                    break;
                }
                case 145: {
                    n4 = 3;
                    break;
                }
                case 146: {
                    n4 = 33;
                    break;
                }
                case 147: {
                    n4 = 188;
                    break;
                }
                case 148: {
                    n4 = 109;
                    break;
                }
                case 149: {
                    n4 = 237;
                    break;
                }
                case 150: {
                    n4 = 34;
                    break;
                }
                case 151: {
                    n4 = 235;
                    break;
                }
                case 152: {
                    n4 = 44;
                    break;
                }
                case 153: {
                    n4 = 87;
                    break;
                }
                case 154: {
                    n4 = 136;
                    break;
                }
                case 155: {
                    n4 = 40;
                    break;
                }
                case 156: {
                    n4 = 13;
                    break;
                }
                case 157: {
                    n4 = 234;
                    break;
                }
                case 158: {
                    n4 = 187;
                    break;
                }
                case 159: {
                    n4 = 171;
                    break;
                }
                case 160: {
                    n4 = 19;
                    break;
                }
                case 161: {
                    n4 = 228;
                    break;
                }
                case 162: {
                    n4 = 84;
                    break;
                }
                case 163: {
                    n4 = 143;
                    break;
                }
                case 164: {
                    n4 = 124;
                    break;
                }
                case 165: {
                    n4 = 214;
                    break;
                }
                case 166: {
                    n4 = 168;
                    break;
                }
                case 167: {
                    n4 = 9;
                    break;
                }
                case 168: {
                    n4 = 128;
                    break;
                }
                case 169: {
                    n4 = 123;
                    break;
                }
                case 170: {
                    n4 = 133;
                    break;
                }
                case 171: {
                    n4 = 246;
                    break;
                }
                case 172: {
                    n4 = 183;
                    break;
                }
                case 173: {
                    n4 = 25;
                    break;
                }
                case 174: {
                    n4 = 39;
                    break;
                }
                case 175: {
                    n4 = 158;
                    break;
                }
                case 176: {
                    n4 = 175;
                    break;
                }
                case 177: {
                    n4 = 206;
                    break;
                }
                case 178: {
                    n4 = 16;
                    break;
                }
                case 179: {
                    n4 = 164;
                    break;
                }
                case 180: {
                    n4 = 4;
                    break;
                }
                case 181: {
                    n4 = 2;
                    break;
                }
                case 182: {
                    n4 = 63;
                    break;
                }
                case 183: {
                    n4 = 184;
                    break;
                }
                case 184: {
                    n4 = 144;
                    break;
                }
                case 185: {
                    n4 = 219;
                    break;
                }
                case 186: {
                    n4 = 236;
                    break;
                }
                case 187: {
                    n4 = 52;
                    break;
                }
                case 188: {
                    n4 = 153;
                    break;
                }
                case 189: {
                    n4 = 32;
                    break;
                }
                case 190: {
                    n4 = 224;
                    break;
                }
                case 191: {
                    n4 = 108;
                    break;
                }
                case 192: {
                    n4 = 46;
                    break;
                }
                case 193: {
                    n4 = 161;
                    break;
                }
                case 194: {
                    n4 = 203;
                    break;
                }
                case 195: {
                    n4 = 180;
                    break;
                }
                case 196: {
                    n4 = 103;
                    break;
                }
                case 197: {
                    n4 = 209;
                    break;
                }
                case 198: {
                    n4 = 107;
                    break;
                }
                case 199: {
                    n4 = 232;
                    break;
                }
                case 200: {
                    n4 = 140;
                    break;
                }
                case 201: {
                    n4 = 94;
                    break;
                }
                case 202: {
                    n4 = 64;
                    break;
                }
                case 203: {
                    n4 = 102;
                    break;
                }
                case 204: {
                    n4 = 166;
                    break;
                }
                case 205: {
                    n4 = 252;
                    break;
                }
                case 206: {
                    n4 = 88;
                    break;
                }
                case 207: {
                    n4 = 8;
                    break;
                }
                case 208: {
                    n4 = 61;
                    break;
                }
                case 209: {
                    n4 = 11;
                    break;
                }
                case 210: {
                    n4 = 230;
                    break;
                }
                case 211: {
                    n4 = 51;
                    break;
                }
                case 212: {
                    n4 = 62;
                    break;
                }
                case 213: {
                    n4 = 142;
                    break;
                }
                case 214: {
                    n4 = 50;
                    break;
                }
                case 215: {
                    n4 = 65;
                    break;
                }
                case 216: {
                    n4 = 152;
                    break;
                }
                case 217: {
                    n4 = 73;
                    break;
                }
                case 218: {
                    n4 = 220;
                    break;
                }
                case 219: {
                    n4 = 130;
                    break;
                }
                case 220: {
                    n4 = 156;
                    break;
                }
                case 221: {
                    n4 = 95;
                    break;
                }
                case 222: {
                    n4 = 170;
                    break;
                }
                case 223: {
                    n4 = 101;
                    break;
                }
                case 224: {
                    n4 = 211;
                    break;
                }
                case 225: {
                    n4 = 251;
                    break;
                }
                case 226: {
                    n4 = 179;
                    break;
                }
                case 227: {
                    n4 = 243;
                    break;
                }
                case 228: {
                    n4 = 29;
                    break;
                }
                case 229: {
                    n4 = 45;
                    break;
                }
                case 230: {
                    n4 = 192;
                    break;
                }
                case 231: {
                    n4 = 41;
                    break;
                }
                case 232: {
                    n4 = 250;
                    break;
                }
                case 233: {
                    n4 = 120;
                    break;
                }
                case 234: {
                    n4 = 146;
                    break;
                }
                case 235: {
                    n4 = 118;
                    break;
                }
                case 236: {
                    n4 = 178;
                    break;
                }
                case 237: {
                    n4 = 165;
                    break;
                }
                case 238: {
                    n4 = 213;
                    break;
                }
                case 239: {
                    n4 = 6;
                    break;
                }
                case 240: {
                    n4 = 37;
                    break;
                }
                case 241: {
                    n4 = 58;
                    break;
                }
                case 242: {
                    n4 = 190;
                    break;
                }
                case 243: {
                    n4 = 106;
                    break;
                }
                case 244: {
                    n4 = 212;
                    break;
                }
                case 245: {
                    n4 = 240;
                    break;
                }
                case 246: {
                    n4 = 167;
                    break;
                }
                case 247: {
                    n4 = 76;
                    break;
                }
                case 248: {
                    n4 = 80;
                    break;
                }
                case 249: {
                    n4 = 79;
                    break;
                }
                case 250: {
                    n4 = 55;
                    break;
                }
                case 251: {
                    n4 = 26;
                    break;
                }
                case 252: {
                    n4 = 247;
                    break;
                }
                case 253: {
                    n4 = 194;
                    break;
                }
                case 254: {
                    n4 = 116;
                    break;
                }
                default: {
                    n4 = 160;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < charArray.length; ++i) {
                final int n8 = i % 2;
                final char[] array = charArray;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ charArray[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ charArray[i]) & 0xFF);
                }
            }
            DdemlUtil$DdeAdapter.b[n3] = new String(charArray).intern();
        }
        return DdemlUtil$DdeAdapter.b[n3];
    }
}
