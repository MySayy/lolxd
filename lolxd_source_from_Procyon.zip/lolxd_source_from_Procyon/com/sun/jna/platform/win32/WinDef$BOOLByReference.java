// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.ptr.ByReference;

public class WinDef$BOOLByReference extends ByReference
{
    public WinDef$BOOLByReference() {
        this(new WinDef$BOOL(0L));
    }
    
    public WinDef$BOOLByReference(final WinDef$BOOL value) {
        super(4);
        this.setValue(value);
    }
    
    public void setValue(final WinDef$BOOL winDef$BOOL) {
        this.getPointer().setInt(0L, winDef$BOOL.intValue());
    }
    
    public WinDef$BOOL getValue() {
        return new WinDef$BOOL((long)this.getPointer().getInt(0L));
    }
}
