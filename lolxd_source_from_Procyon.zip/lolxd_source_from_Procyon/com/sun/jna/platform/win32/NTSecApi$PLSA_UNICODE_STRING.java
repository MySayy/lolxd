// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public class NTSecApi$PLSA_UNICODE_STRING
{
    public NTSecApi$LSA_UNICODE_STRING$ByReference s;
}
