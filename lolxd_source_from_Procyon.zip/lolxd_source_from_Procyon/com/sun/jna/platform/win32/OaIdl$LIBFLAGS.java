// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import java.util.List;
import com.sun.jna.Structure;

public class OaIdl$LIBFLAGS extends Structure
{
    public static final List<String> FIELDS;
    public int value;
    public static final int LIBFLAG_FRESTRICTED = 1;
    public static final int LIBFLAG_FCONTROL = 2;
    public static final int LIBFLAG_FHIDDEN = 4;
    public static final int LIBFLAG_FHASDISKIMAGE = 8;
    
    public OaIdl$LIBFLAGS() {
    }
    
    public OaIdl$LIBFLAGS(final int value) {
        this.value = value;
    }
    
    public OaIdl$LIBFLAGS(final Pointer pointer) {
        super(pointer);
        this.read();
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return OaIdl$LIBFLAGS.FIELDS;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 77);
        final char[] charArray = "\u0013\u0017vFy".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 40;
                            break;
                        }
                        case 1: {
                            n5 = 59;
                            break;
                        }
                        case 2: {
                            n5 = 87;
                            break;
                        }
                        case 3: {
                            n5 = 126;
                            break;
                        }
                        case 4: {
                            n5 = 81;
                            break;
                        }
                        case 5: {
                            n5 = 35;
                            break;
                        }
                        default: {
                            n5 = 40;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                FIELDS = Structure.createFieldsOrder(new String(charArray).intern());
                return;
            }
            continue;
        }
    }
}
