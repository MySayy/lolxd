// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.ptr.ByReference;

public class WinDef$ULONGLONGByReference extends ByReference
{
    public WinDef$ULONGLONGByReference() {
        this(new WinDef$ULONGLONG(0L));
    }
    
    public WinDef$ULONGLONGByReference(final WinDef$ULONGLONG value) {
        super(WinDef$ULONGLONG.SIZE);
        this.setValue(value);
    }
    
    public void setValue(final WinDef$ULONGLONG winDef$ULONGLONG) {
        this.getPointer().setLong(0L, winDef$ULONGLONG.longValue());
    }
    
    public WinDef$ULONGLONG getValue() {
        return new WinDef$ULONGLONG(this.getPointer().getLong(0L));
    }
}
