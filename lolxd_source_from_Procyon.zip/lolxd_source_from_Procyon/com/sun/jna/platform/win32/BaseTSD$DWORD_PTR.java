// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import com.sun.jna.IntegerType;

public class BaseTSD$DWORD_PTR extends IntegerType
{
    public BaseTSD$DWORD_PTR() {
        this(0L);
    }
    
    public BaseTSD$DWORD_PTR(final long n) {
        super(Pointer.SIZE, n);
    }
}
