// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import java.util.List;
import com.sun.jna.Structure;

public class OaIdl$INVOKEKIND extends Structure
{
    public static final List<String> FIELDS;
    public static final OaIdl$INVOKEKIND INVOKE_FUNC;
    public static final OaIdl$INVOKEKIND INVOKE_PROPERTYGET;
    public static final OaIdl$INVOKEKIND INVOKE_PROPERTYPUT;
    public static final OaIdl$INVOKEKIND INVOKE_PROPERTYPUTREF;
    public int value;
    
    public OaIdl$INVOKEKIND() {
    }
    
    public OaIdl$INVOKEKIND(final int value) {
        this.value = value;
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return OaIdl$INVOKEKIND.FIELDS;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 54);
        final char[] charArray = "z/K\u0004z".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 58;
                            break;
                        }
                        case 1: {
                            n5 = 120;
                            break;
                        }
                        case 2: {
                            n5 = 17;
                            break;
                        }
                        case 3: {
                            n5 = 71;
                            break;
                        }
                        case 4: {
                            n5 = 41;
                            break;
                        }
                        case 5: {
                            n5 = 126;
                            break;
                        }
                        default: {
                            n5 = 67;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                FIELDS = Structure.createFieldsOrder(new String(charArray).intern());
                INVOKE_FUNC = new OaIdl$INVOKEKIND(1);
                INVOKE_PROPERTYGET = new OaIdl$INVOKEKIND(2);
                INVOKE_PROPERTYPUT = new OaIdl$INVOKEKIND(4);
                INVOKE_PROPERTYPUTREF = new OaIdl$INVOKEKIND(8);
                return;
            }
            continue;
        }
    }
}
