// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import com.sun.jna.IntegerType;

public class WinDef$INT_PTR extends IntegerType
{
    public WinDef$INT_PTR() {
        super(Pointer.SIZE);
    }
    
    public WinDef$INT_PTR(final long n) {
        super(Pointer.SIZE, n);
    }
    
    public Pointer toPointer() {
        return Pointer.createConstant(this.longValue());
    }
}
