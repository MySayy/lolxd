// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Structure$ByReference;

public class NTSecApi$PLSA_FOREST_TRUST_RECORD$ByReference extends NTSecApi$PLSA_FOREST_TRUST_RECORD implements Structure$ByReference
{
}
