// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import com.sun.jna.ptr.ByReference;

public class WinNT$PACLByReference extends ByReference
{
    public WinNT$PACLByReference() {
        this((WinNT$ACL)null);
    }
    
    public WinNT$PACLByReference(final WinNT$ACL value) {
        super(Pointer.SIZE);
        this.setValue(value);
    }
    
    public void setValue(final WinNT$ACL winNT$ACL) {
        final boolean a = WinNT$HANDLE.a();
        Pointer pointer = null;
        long n = 0L;
        Pointer pointer2 = null;
        Label_0043: {
            Label_0042: {
                WinNT$ACL winNT$ACL2 = null;
                Label_0036: {
                    Label_0025: {
                        try {
                            pointer = this.getPointer();
                            n = 0L;
                            winNT$ACL2 = winNT$ACL;
                            if (a) {
                                break Label_0036;
                            }
                            final boolean b = a;
                            if (!b) {
                                break Label_0025;
                            }
                            break Label_0036;
                        }
                        catch (RuntimeException ex) {
                            throw b(ex);
                        }
                        try {
                            final boolean b = a;
                            if (b) {
                                break Label_0036;
                            }
                            if (winNT$ACL == null) {
                                break Label_0042;
                            }
                        }
                        catch (RuntimeException ex2) {
                            throw b(ex2);
                        }
                    }
                    winNT$ACL2 = winNT$ACL;
                }
                pointer2 = winNT$ACL2.getPointer();
                break Label_0043;
            }
            pointer2 = null;
        }
        pointer.setPointer(n, pointer2);
    }
    
    public WinNT$ACL getValue() {
        final Pointer pointer = this.getPointer().getPointer(0L);
        try {
            if (pointer == null) {
                return null;
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
        return new WinNT$ACL(pointer);
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
