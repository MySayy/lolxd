// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.win32.W32APITypeMapper;
import java.util.List;
import com.sun.jna.Structure;

public class Sspi$SecPkgInfo extends Structure
{
    public static final List<String> FIELDS;
    public int fCapabilities;
    public short wVersion;
    public short wRPCID;
    public int cbMaxToken;
    public String Name;
    public String Comment;
    
    public Sspi$SecPkgInfo() {
        super(W32APITypeMapper.DEFAULT);
        this.wVersion = 1;
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return Sspi$SecPkgInfo.FIELDS;
    }
    
    static {
        final String[] array = new String[6];
        int n = 0;
        String s;
        int n2 = (s = "\u000e,Wag \r\u001f=fRO\u0006+\u0015\u0017sKK\u0017\n\u001a\u001cJCV0-\u0012\u001bi\u0007:\u0011jOK\n6").length();
        int n3 = 6;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 101));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0251: {
                            if (length > 1) {
                                break Label_0251;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 28;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 27;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 98;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 71;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 75;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 1;
                                        break;
                                    }
                                    default: {
                                        n11 = 39;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "/\tCq|,\f6\u0004\u0016>Kf").length();
                            n3 = 8;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 68)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[1], array2[4], array2[0], array2[2], array2[5], array2[3]);
    }
}
