// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.ptr.ByReference;

public class WinDef$SCODEByReference extends ByReference
{
    public WinDef$SCODEByReference() {
        this(new WinDef$SCODE(0L));
    }
    
    public WinDef$SCODEByReference(final WinDef$SCODE value) {
        super(WinDef$SCODE.SIZE);
        this.setValue(value);
    }
    
    public void setValue(final WinDef$SCODE winDef$SCODE) {
        this.getPointer().setInt(0L, winDef$SCODE.intValue());
    }
    
    public WinDef$SCODE getValue() {
        return new WinDef$SCODE((long)this.getPointer().getInt(0L));
    }
}
