// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import java.util.List;
import com.sun.jna.Structure;

public class OaIdl$DESCKIND extends Structure
{
    public static final List<String> FIELDS;
    public int value;
    public static final int DESCKIND_NONE = 0;
    public static final int DESCKIND_FUNCDESC = 1;
    public static final int DESCKIND_VARDESC = 2;
    public static final int DESCKIND_TYPECOMP = 3;
    public static final int DESCKIND_IMPLICITAPPOBJ = 4;
    public static final int DESCKIND_MAX = 5;
    
    public OaIdl$DESCKIND() {
    }
    
    public OaIdl$DESCKIND(final int value) {
        this.value = value;
    }
    
    public OaIdl$DESCKIND(final Pointer pointer) {
        super(pointer);
        this.read();
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return OaIdl$DESCKIND.FIELDS;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 85);
        final char[] charArray = "a\u0007]R\u0014".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 66;
                            break;
                        }
                        case 1: {
                            n5 = 51;
                            break;
                        }
                        case 2: {
                            n5 = 100;
                            break;
                        }
                        case 3: {
                            n5 = 114;
                            break;
                        }
                        case 4: {
                            n5 = 36;
                            break;
                        }
                        case 5: {
                            n5 = 105;
                            break;
                        }
                        default: {
                            n5 = 100;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                FIELDS = Structure.createFieldsOrder(new String(charArray).intern());
                return;
            }
            continue;
        }
    }
}
