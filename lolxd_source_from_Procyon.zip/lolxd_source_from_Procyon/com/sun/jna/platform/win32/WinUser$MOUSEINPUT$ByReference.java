// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import com.sun.jna.Structure$ByReference;

public class WinUser$MOUSEINPUT$ByReference extends WinUser$MOUSEINPUT implements Structure$ByReference
{
    public WinUser$MOUSEINPUT$ByReference() {
    }
    
    public WinUser$MOUSEINPUT$ByReference(final Pointer pointer) {
        super(pointer);
    }
}
