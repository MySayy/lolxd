// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public interface Winevt$EVT_LOGIN_CLASS
{
    public static final int EvtRpcLogin = 1;
}
