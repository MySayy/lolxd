// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.ptr.ByReference;

public class WinDef$UINTByReference extends ByReference
{
    public WinDef$UINTByReference() {
        this(new WinDef$UINT(0L));
    }
    
    public WinDef$UINTByReference(final WinDef$UINT value) {
        super(4);
        this.setValue(value);
    }
    
    public void setValue(final WinDef$UINT winDef$UINT) {
        this.getPointer().setInt(0L, winDef$UINT.intValue());
    }
    
    public WinDef$UINT getValue() {
        return new WinDef$UINT((long)this.getPointer().getInt(0L));
    }
}
