// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public class OaIdl$HREFTYPEByReference extends WinDef$DWORDByReference
{
    public OaIdl$HREFTYPEByReference() {
        this(new OaIdl$HREFTYPE(0L));
    }
    
    public OaIdl$HREFTYPEByReference(final WinDef$DWORD winDef$DWORD) {
        super(winDef$DWORD);
    }
    
    public void setValue(final OaIdl$HREFTYPE oaIdl$HREFTYPE) {
        this.getPointer().setInt(0L, oaIdl$HREFTYPE.intValue());
    }
    
    @Override
    public OaIdl$HREFTYPE getValue() {
        return new OaIdl$HREFTYPE((long)this.getPointer().getInt(0L));
    }
}
