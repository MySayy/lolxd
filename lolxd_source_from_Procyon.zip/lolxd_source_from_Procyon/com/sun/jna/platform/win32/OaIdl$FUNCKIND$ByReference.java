// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Structure$ByReference;

public class OaIdl$FUNCKIND$ByReference extends OaIdl$FUNCKIND implements Structure$ByReference
{
}
