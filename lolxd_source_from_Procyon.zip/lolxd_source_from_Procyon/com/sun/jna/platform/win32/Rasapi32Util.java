// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import java.util.HashMap;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.IntByReference;
import java.util.Map;

public abstract class Rasapi32Util
{
    private static final int RASP_PppIp = 32801;
    private static Object phoneBookMutex;
    public static final Map CONNECTION_STATE_TEXT;
    private static final String[] a;
    private static final String[] b;
    
    public static String getRasErrorString(final int i) {
        final boolean a = WinNT$HANDLE.a();
        final char[] value = new char[1024];
        final boolean b = a;
        final int rasGetErrorString = Rasapi32.INSTANCE.RasGetErrorString(i, value, value.length);
        int n2 = 0;
        Label_0070: {
            Label_0038: {
                int n;
                try {
                    n = (n2 = rasGetErrorString);
                    if (b) {
                        break Label_0070;
                    }
                    if (n != 0) {
                        break Label_0038;
                    }
                    break Label_0038;
                }
                catch (Rasapi32Util$Ras32Exception ex) {
                    throw b(ex);
                }
                try {
                    if (n != 0) {
                        return a(30832, 2746) + i;
                    }
                }
                catch (Rasapi32Util$Ras32Exception ex2) {
                    throw b(ex2);
                }
            }
            n2 = 0;
        }
        int j = n2;
        while (j < value.length) {
            try {
                if (value[j] == '\0') {
                    break;
                }
            }
            catch (Rasapi32Util$Ras32Exception ex3) {
                throw b(ex3);
            }
            ++j;
            if (b) {
                break;
            }
        }
        return new String(value, 0, j);
    }
    
    public static String getRasConnectionStatusText(final int i) {
        final boolean c = WinNT$HANDLE.c();
        Map map2 = null;
        Integer n2 = null;
        Label_0049: {
            Label_0042: {
                Label_0030: {
                    Map map;
                    Integer n;
                    try {
                        map = (map2 = Rasapi32Util.CONNECTION_STATE_TEXT);
                        n = (n2 = i);
                        if (!c) {
                            break Label_0049;
                        }
                        final boolean b = map.containsKey(n);
                        if (!b) {
                            break Label_0030;
                        }
                        break Label_0042;
                    }
                    catch (Rasapi32Util$Ras32Exception ex) {
                        throw b(ex);
                    }
                    try {
                        final boolean b = map.containsKey(n);
                        if (b) {
                            break Label_0042;
                        }
                        Integer.toString(i);
                    }
                    catch (Rasapi32Util$Ras32Exception ex2) {
                        throw b(ex2);
                    }
                }
                return;
            }
            map2 = Rasapi32Util.CONNECTION_STATE_TEXT;
            n2 = i;
        }
        final String s = map2.get(n2);
        if (c) {
            return s;
        }
        return s;
    }
    
    public static WinNT$HANDLE getRasConnection(final String anObject) throws Rasapi32Util$Ras32Exception {
        final boolean c = WinNT$HANDLE.c();
        final IntByReference intByReference = new IntByReference(0);
        final boolean b = c;
        final IntByReference intByReference2 = new IntByReference();
        int n = Rasapi32.INSTANCE.RasEnumConnections(null, intByReference, intByReference2);
        int n4 = 0;
        Label_0108: {
            Label_0098: {
                int n3 = 0;
                Label_0084: {
                    while (true) {
                        Label_0076: {
                            try {
                                final int n2 = n3 = (n4 = n);
                                if (!b) {
                                    break Label_0084;
                                }
                                if (n2 == 0) {
                                    break Label_0076;
                                }
                            }
                            catch (Rasapi32Util$Ras32Exception ex) {
                                throw b(ex);
                            }
                            final int n5;
                            n3 = (n5 = (n4 = n));
                            if (!b) {
                                break Label_0084;
                            }
                            try {
                                if (n5 != 603) {
                                    throw new Rasapi32Util$Ras32Exception(n);
                                }
                            }
                            catch (Rasapi32Util$Ras32Exception ex2) {
                                throw b(ex2);
                            }
                        }
                        int n5;
                        n3 = (n5 = (n4 = intByReference.getValue()));
                        if (!b) {
                            continue;
                        }
                        break;
                    }
                    try {
                        if (!b) {
                            break Label_0108;
                        }
                        if (n3 == 0) {
                            break Label_0098;
                        }
                        break Label_0098;
                    }
                    catch (Rasapi32Util$Ras32Exception ex3) {
                        throw b(ex3);
                    }
                }
                try {
                    if (n3 == 0) {
                        return null;
                    }
                }
                catch (Rasapi32Util$Ras32Exception ex4) {
                    throw b(ex4);
                }
            }
            n4 = intByReference2.getValue();
        }
        final WinRas$RASCONN[] array = new WinRas$RASCONN[n4];
        int i = 0;
        while (true) {
            while (i < intByReference2.getValue()) {
                int n7 = 0;
                Label_0220: {
                    Label_0205: {
                        int n6 = 0;
                        Label_0189: {
                            try {
                                array[i] = new WinRas$RASCONN();
                                ++i;
                                if (!b) {
                                    break Label_0189;
                                }
                                if (b) {
                                    continue;
                                }
                            }
                            catch (Rasapi32Util$Ras32Exception ex5) {
                                throw b(ex5);
                            }
                            break;
                            try {
                                n6 = (n7 = n);
                                if (!b) {
                                    break Label_0220;
                                }
                                if (n6 != 0) {
                                    break Label_0205;
                                }
                                break Label_0205;
                            }
                            catch (Rasapi32Util$Ras32Exception ex6) {
                                throw b(ex6);
                            }
                        }
                        try {
                            if (n6 != 0) {
                                throw new Rasapi32Util$Ras32Exception(n);
                            }
                        }
                        catch (Rasapi32Util$Ras32Exception ex7) {
                            throw b(ex7);
                        }
                    }
                    n7 = 0;
                }
                int j = n7;
                while (j < intByReference2.getValue()) {
                    try {
                        if (new String(array[j].szEntryName).equals(anObject)) {
                            return array[j].hrasconn;
                        }
                    }
                    catch (Rasapi32Util$Ras32Exception ex8) {
                        throw b(ex8);
                    }
                    ++j;
                    if (!b) {
                        break;
                    }
                }
                return null;
            }
            n = Rasapi32.INSTANCE.RasEnumConnections(array, new IntByReference(array[0].dwSize * intByReference2.getValue()), intByReference2);
            continue;
        }
    }
    
    public static void hangupRasConnection(final String s) throws Rasapi32Util$Ras32Exception {
        final WinNT$HANDLE rasConnection = getRasConnection(s);
        try {
            if (rasConnection == null) {
                return;
            }
        }
        catch (Rasapi32Util$Ras32Exception ex) {
            throw b(ex);
        }
        final int rasHangUp = Rasapi32.INSTANCE.RasHangUp(rasConnection);
        try {
            if (rasHangUp != 0) {
                throw new Rasapi32Util$Ras32Exception(rasHangUp);
            }
        }
        catch (Rasapi32Util$Ras32Exception ex2) {
            throw b(ex2);
        }
    }
    
    public static void hangupRasConnection(final WinNT$HANDLE winNT$HANDLE) throws Rasapi32Util$Ras32Exception {
        try {
            if (winNT$HANDLE == null) {
                return;
            }
        }
        catch (Rasapi32Util$Ras32Exception ex) {
            throw b(ex);
        }
        final int rasHangUp = Rasapi32.INSTANCE.RasHangUp(winNT$HANDLE);
        try {
            if (rasHangUp != 0) {
                throw new Rasapi32Util$Ras32Exception(rasHangUp);
            }
        }
        catch (Rasapi32Util$Ras32Exception ex2) {
            throw b(ex2);
        }
    }
    
    public static WinRas$RASPPPIP getIPProjection(final WinNT$HANDLE winNT$HANDLE) throws Rasapi32Util$Ras32Exception {
        final WinRas$RASPPPIP winRas$RASPPPIP = new WinRas$RASPPPIP();
        final boolean a = WinNT$HANDLE.a();
        final IntByReference intByReference = new IntByReference(winRas$RASPPPIP.size());
        final boolean b = a;
        winRas$RASPPPIP.write();
        final int rasGetProjectionInfo = Rasapi32.INSTANCE.RasGetProjectionInfo(winNT$HANDLE, 32801, winRas$RASPPPIP.getPointer(), intByReference);
        Label_0062: {
            try {
                if (b) {
                    return winRas$RASPPPIP;
                }
                final int n = rasGetProjectionInfo;
                if (n != 0) {
                    break Label_0062;
                }
                break Label_0062;
            }
            catch (Rasapi32Util$Ras32Exception ex) {
                throw b(ex);
            }
            try {
                final int n = rasGetProjectionInfo;
                if (n != 0) {
                    throw new Rasapi32Util$Ras32Exception(rasGetProjectionInfo);
                }
            }
            catch (Rasapi32Util$Ras32Exception ex2) {
                throw b(ex2);
            }
        }
        winRas$RASPPPIP.read();
        return winRas$RASPPPIP;
    }
    
    public static WinRas$RASENTRY$ByReference getPhoneBookEntry(final String s) throws Rasapi32Util$Ras32Exception {
        synchronized (Rasapi32Util.phoneBookMutex) {
            final WinRas$RASENTRY$ByReference winRas$RASENTRY$ByReference = new WinRas$RASENTRY$ByReference();
            final int rasGetEntryProperties = Rasapi32.INSTANCE.RasGetEntryProperties(null, s, winRas$RASENTRY$ByReference, new IntByReference(winRas$RASENTRY$ByReference.size()), null, null);
            try {
                if (rasGetEntryProperties != 0) {
                    throw new Rasapi32Util$Ras32Exception(rasGetEntryProperties);
                }
            }
            catch (Rasapi32Util$Ras32Exception ex) {
                throw b(ex);
            }
            return winRas$RASENTRY$ByReference;
        }
    }
    
    public static void setPhoneBookEntry(final String s, final WinRas$RASENTRY$ByReference winRas$RASENTRY$ByReference) throws Rasapi32Util$Ras32Exception {
        final boolean a = WinNT$HANDLE.a();
        // monitorenter(phoneBookMutex = Rasapi32Util.phoneBookMutex)
        final boolean b = a;
        try {
            final int rasSetEntryProperties = Rasapi32.INSTANCE.RasSetEntryProperties(null, s, winRas$RASENTRY$ByReference, winRas$RASENTRY$ByReference.size(), null, 0);
            Label_0045: {
                try {
                    if (b) {
                        return;
                    }
                    final int n = rasSetEntryProperties;
                    if (n != 0) {
                        break Label_0045;
                    }
                    return;
                }
                catch (Rasapi32Util$Ras32Exception ex) {
                    throw b(ex);
                }
                try {
                    final int n = rasSetEntryProperties;
                    if (n != 0) {
                        throw new Rasapi32Util$Ras32Exception(rasSetEntryProperties);
                    }
                }
                catch (Rasapi32Util$Ras32Exception ex2) {
                    throw b(ex2);
                }
            }
        }
        finally {
        }
        // monitorexit(phoneBookMutex)
    }
    
    public static WinRas$RASDIALPARAMS getPhoneBookDialingParams(final String s) throws Rasapi32Util$Ras32Exception {
        synchronized (Rasapi32Util.phoneBookMutex) {
            final WinRas$RASDIALPARAMS$ByReference winRas$RASDIALPARAMS$ByReference = new WinRas$RASDIALPARAMS$ByReference();
            System.arraycopy(winRas$RASDIALPARAMS$ByReference.szEntryName, 0, s.toCharArray(), 0, s.length());
            final int rasGetEntryDialParams = Rasapi32.INSTANCE.RasGetEntryDialParams(null, winRas$RASDIALPARAMS$ByReference, new WinDef$BOOLByReference());
            try {
                if (rasGetEntryDialParams != 0) {
                    throw new Rasapi32Util$Ras32Exception(rasGetEntryDialParams);
                }
            }
            catch (Rasapi32Util$Ras32Exception ex) {
                throw b(ex);
            }
            return winRas$RASDIALPARAMS$ByReference;
        }
    }
    
    public static WinNT$HANDLE dialEntry(final String s) throws Rasapi32Util$Ras32Exception {
        final boolean a = WinNT$HANDLE.a();
        final WinRas$RASCREDENTIALS$ByReference winRas$RASCREDENTIALS$ByReference = new WinRas$RASCREDENTIALS$ByReference();
        final boolean b = a;
        synchronized (Rasapi32Util.phoneBookMutex) {
            winRas$RASCREDENTIALS$ByReference.dwMask = 7;
            final int rasGetCredentials = Rasapi32.INSTANCE.RasGetCredentials(null, s, winRas$RASCREDENTIALS$ByReference);
            Label_0053: {
                try {
                    if (b) {
                        break Label_0053;
                    }
                    final int n = rasGetCredentials;
                    if (n != 0) {
                        break Label_0053;
                    }
                    break Label_0053;
                }
                catch (Rasapi32Util$Ras32Exception ex) {
                    throw b(ex);
                }
                try {
                    final int n = rasGetCredentials;
                    if (n != 0) {
                        throw new Rasapi32Util$Ras32Exception(rasGetCredentials);
                    }
                }
                catch (Rasapi32Util$Ras32Exception ex2) {
                    throw b(ex2);
                }
            }
        }
        final WinRas$RASDIALPARAMS$ByReference winRas$RASDIALPARAMS$ByReference = new WinRas$RASDIALPARAMS$ByReference();
        System.arraycopy(s.toCharArray(), 0, winRas$RASDIALPARAMS$ByReference.szEntryName, 0, s.length());
        System.arraycopy(winRas$RASCREDENTIALS$ByReference.szUserName, 0, winRas$RASDIALPARAMS$ByReference.szUserName, 0, winRas$RASCREDENTIALS$ByReference.szUserName.length);
        System.arraycopy(winRas$RASCREDENTIALS$ByReference.szPassword, 0, winRas$RASDIALPARAMS$ByReference.szPassword, 0, winRas$RASCREDENTIALS$ByReference.szPassword.length);
        System.arraycopy(winRas$RASCREDENTIALS$ByReference.szDomain, 0, winRas$RASDIALPARAMS$ByReference.szDomain, 0, winRas$RASCREDENTIALS$ByReference.szDomain.length);
        final WinNT$HANDLEByReference winNT$HANDLEByReference = new WinNT$HANDLEByReference();
        final int rasDial = Rasapi32.INSTANCE.RasDial(null, null, winRas$RASDIALPARAMS$ByReference, 0, null, winNT$HANDLEByReference);
        while (true) {
            Label_0235: {
                try {
                    if (rasDial == 0) {
                        break Label_0235;
                    }
                    winNT$HANDLEByReference.getValue();
                }
                catch (Rasapi32Util$Ras32Exception ex3) {
                    throw b(ex3);
                }
                try {
                    final WinNT$HANDLE value;
                    if (value != null) {
                        Rasapi32.INSTANCE.RasHangUp(winNT$HANDLEByReference.getValue());
                    }
                }
                catch (Rasapi32Util$Ras32Exception ex4) {
                    throw b(ex4);
                }
                throw new Rasapi32Util$Ras32Exception(rasDial);
            }
            final WinNT$HANDLE value = winNT$HANDLEByReference.getValue();
            if (!b) {
                return value;
            }
            continue;
        }
    }
    
    public static WinNT$HANDLE dialEntry(final String s, final WinRas$RasDialFunc2 winRas$RasDialFunc2) throws Rasapi32Util$Ras32Exception {
        final WinRas$RASCREDENTIALS$ByReference winRas$RASCREDENTIALS$ByReference = new WinRas$RASCREDENTIALS$ByReference();
        final boolean c = WinNT$HANDLE.c();
        // monitorenter(phoneBookMutex = Rasapi32Util.phoneBookMutex)
        final boolean b = c;
        try {
            winRas$RASCREDENTIALS$ByReference.dwMask = 7;
            final int rasGetCredentials = Rasapi32.INSTANCE.RasGetCredentials(null, s, winRas$RASCREDENTIALS$ByReference);
            Label_0054: {
                try {
                    if (!b) {
                        break Label_0054;
                    }
                    final int n = rasGetCredentials;
                    if (n != 0) {
                        break Label_0054;
                    }
                    break Label_0054;
                }
                catch (Rasapi32Util$Ras32Exception ex) {
                    throw b(ex);
                }
                try {
                    final int n = rasGetCredentials;
                    if (n != 0) {
                        throw new Rasapi32Util$Ras32Exception(rasGetCredentials);
                    }
                }
                catch (Rasapi32Util$Ras32Exception ex2) {
                    throw b(ex2);
                }
            }
        }
        finally {
        }
        // monitorexit(phoneBookMutex)
        final WinRas$RASDIALPARAMS$ByReference winRas$RASDIALPARAMS$ByReference = new WinRas$RASDIALPARAMS$ByReference();
        System.arraycopy(s.toCharArray(), 0, winRas$RASDIALPARAMS$ByReference.szEntryName, 0, s.length());
        System.arraycopy(winRas$RASCREDENTIALS$ByReference.szUserName, 0, winRas$RASDIALPARAMS$ByReference.szUserName, 0, winRas$RASCREDENTIALS$ByReference.szUserName.length);
        System.arraycopy(winRas$RASCREDENTIALS$ByReference.szPassword, 0, winRas$RASDIALPARAMS$ByReference.szPassword, 0, winRas$RASCREDENTIALS$ByReference.szPassword.length);
        System.arraycopy(winRas$RASCREDENTIALS$ByReference.szDomain, 0, winRas$RASDIALPARAMS$ByReference.szDomain, 0, winRas$RASCREDENTIALS$ByReference.szDomain.length);
        final WinNT$HANDLEByReference winNT$HANDLEByReference = new WinNT$HANDLEByReference();
        final int rasDial = Rasapi32.INSTANCE.RasDial(null, null, winRas$RASDIALPARAMS$ByReference, 2, winRas$RasDialFunc2, winNT$HANDLEByReference);
        while (true) {
            Label_0244: {
                try {
                    if (rasDial == 0) {
                        break Label_0244;
                    }
                    winNT$HANDLEByReference.getValue();
                }
                catch (Rasapi32Util$Ras32Exception ex3) {
                    throw b(ex3);
                }
                try {
                    final WinNT$HANDLE value;
                    if (value != null) {
                        Rasapi32.INSTANCE.RasHangUp(winNT$HANDLEByReference.getValue());
                    }
                }
                catch (Rasapi32Util$Ras32Exception ex4) {
                    throw b(ex4);
                }
                throw new Rasapi32Util$Ras32Exception(rasDial);
            }
            final WinNT$HANDLE value = winNT$HANDLEByReference.getValue();
            if (b) {
                return value;
            }
            continue;
        }
    }
    
    static {
        final String[] a2 = new String[32];
        int n = 0;
        String s;
        int n2 = (s = "\u00cd\u00d5\u0018\f\u00f6«\u0000S\u0082\t\u0090\u00ee¢M-5D(¶<e:\u0012\u0080\u00d7<\u0002\u00054\u001d\u0099`³\u001e\u00c3+\u0001l\u008e\u00d1?¥9\u00ed£5 ¦±>\u000b\u00dc\u0011\u0083\u009f\rAsJz5R\u008a\u0013\u0091}\u00d0ª\u00d4(\u001c\u00e1\u0014\u007fz\u00e9.s\u009ag\u0087|¿\u009b¾\u0086c\u00f4\u00e4Pµ\u0094\u00dc\u0002\u0093+s\u00c8\u00d1?¨\u001dBw5ª\u00c8\u00c6\u0004C·\u009fk\u00f5)\u008a\u00d1°x§e\u00e5°\u0015h\u00013\u0083\u001e\u0082M/\u00f5µ\"ou\u008a\u0018\u00c2\u00da\u00c5H\u00e6\u00ca¿\u00e7: \u00c6\u00ca\u00f3\u00d3\\,\u00920\u00ebg\u0002\u009c\u00f6«GS\u00e9Rx¼\u0083N\t\u0091\u008f\u0019\u0011S8/\u00f9\u0081)\u0007\u00ca\u00de0\u00c6\u00adJ£\u00eaH\u00c6(¦G9\u0003\u001a\u001c®\u001e\u001d\u00f7 '\u00e4+\u00ec\u00f2\u00c7`w\u00f94\u00e3a«\b·\u00df\u00e3h³vRF\u0094\u00e3\u0018^U\u00dc\u00d7U\u00c0'\t\u0004e\u00c9[»\u00e9\u0094BD\u00e0\u00ff\u00e3I?\u0098\u00ea\u0012~T,5\u00fc\u009e2&x;\u00d0\u00d1\u0000\u0097¿\u00cc&A\u00d9\u00d05\u0006^\u00ddb\u00ed¯¿\u00e2\u00d76\u00ffz+\u00d1 \u0000\u00c7Bºi\u00f3°T³\u00c7\u00dbl\u0082r²\u00f7\u00d3\u00e8ps\u0097+\u00f2\u000b\u0014º\u00e6\u0099\u0096$6\u00e3\u009ec\u00df\u0015G\u0016&\u00e6\u0013@¢\"\u001a\u00cf°\u008c»\u00e9J®01\u00df\u007f\u0088§\u00ebT\u00ed\u00ffQ\u00e5p&\u0004´\u000e¨\u00f0ª²j\u00c9Ym\u0016\u0016\u00e60\u00e6x\u00c6\u007f\u00e0\u001d>\u008dl#\u008a\u00cb\u001d^\u008d\u0082p·\u0098\u0002;\u009c\u009d)?\u0087\u0095ª\u00ad+\u00ca\u00dc2\u00dbm\u009b\u00ddi\u00fe\u00d3»l@b6%\u00db\u000f\u00e9\u00f7\u009e\u00c2Hywm\u0003F]´F\u000b\u0000U\u0083<\u0097(\u00c2¿AH\u00846\u000f\u00d2\u00e6/V\u009d1 _\u00e02O5\u00e8B\u00f3\u0012\u00cd\u0016\u00c73°p\tY\u009a\n\u00e4\u009d\u0013\u0099\u0080uHM\u00f7\u00e7\u00ed¦\u00f4~\u00c0¾f\u00cd¼\u0081e\u0012\u0082\u00e9\u00cc\u001b³ \u0006\u0083\u009aN\u00dc0K\u0010\u0091a\u0087\u00c4\u0099\u0090\u0099,\u0002:\u00ecx\u0002\u001b\u001a\u0018x0\u00f2\u00c3\"\u00c1\u0089\u00ff°\u00ffYw\u009a\u00eb\u00884ªWJ3\u0004\u00d9\u00ff\u0018\u0081\u009e\u00f6r³+\u008d^\u00c5\u00f7\u0083#\u00c1\u0011;1}\u00d3\u0085¦\u00d3\u0015\u00e1TO\u00935U½\u00f6pxX\u0080\u00ec\u00caA«\u00fe©:@\u009c*\u0001\u0093\u009b\u0094\u00c8S\t\u008d\u0099\u00da+f\u00e3©>6®M\u00fe³g@\u009d\u00da[\u00c0+\u000e_\u0089\u00fc\u00efW\u0007°|6¸Z\u0082\u0098T\u00c9\u0080\u0085\u00d7z\u00ca\tB^*®\u00e8\u0013\u00cd\u0003\u00ce[\u00d6\u00faFF\u00dfN)\u001a1\u00d8\u0007®\bº\u0004-WP\u00fd¤k\b\u00fa%\u00869\u00c3;¼\u001f\u00ca^!b3Q\u00ebª\u0011\"«m?\u00970«\u00dd&«\u0016\u001e\u00f2\u00fa\u0085[¥ w\u00f2l\u00d6i\u00f6\u00de\u0012\u00df2i\u0012\u0082V%i\u00c7\u008b\u000f\u00db\u0091Z\u0006\u00e0z#^\u008a}\rWi\u00cagc75\u00f7ºX(]Nx` `¿\u009e\u00ec{\r¾¤ªTZ-Y\u00dd%s\u0010\u0012»\u008f°p\u0016AJ\u0099L\u00e8\u00c0¦\u00c9\u00cb\u00e0#°\u00fa_¦]=rO\u0011\u0004!T%k\u00f3\u0006¹c5\u0096\r\\\u009f½E\u00e3³\u0012\u00feº\u00d1\u00ec\u001eo\u00e9\u00898\u0015\u0093\u00ecW¢·\u00e9\u00dd[H\u00c1\u0006oI\u00dd\u00cc\u001cªY\u0089\u00d9\u00fc\u00fc\u001e\u009f\u008c{ j\u00df\u0004@Q\u0017\u00fd/\u00855>\u0098\u00fe b¤\u0086\u00d4S~\u008fP\u0087\u00c5\u0080 ¢~\u0005\u00eaqL\u00c0?D\u0006[\u009bH ¨Zp°$s\u0083z·(\u00fdb\u0007\u0092¹\u0013h\u0007\u00fb\u008bCByT\u0094\u00f3v§\u0089\u008d¢\u0003s\u00cf7.\u008c`\u00dd\u00cb\u001e4n\u00124½d\u000e\t\u00d7+\u0094\u00f2b\u0087\u00f9\u00fbo³1R\u00ff\u00d7\u00ec\u00e6Y¤v.\u0016\u0092\nr\u001ae£\u00da\u007f\u0091?$\u0011\f\u00f6\u00daT\u0007d\u007fR¶\u00ce^\u00c8\u00c9\u001c ¤\u0093\n\fZ\u0090W²\u0095\u008f\u00f9D\u00d7\u00e1\u00f2\u0096`\u00e9³\u00d8W\u00ca4\u00cb\b¯\u00f6'G\u00163\u0019 \u00e0\u00e5»\u00db\u00c1\u00ff\u00e8\u009ej\u00f0^\u0095\u00df\u00c7W\u008f»\u009d¢`\u0082\u00db\u00e1|=·\u00e2\u0000\u00d0\u00d9cm\u009f\u0013\u001c\u0097Ex\u00e7\u00e2\u001d\u00f6\u0018¢\u0015¬\u00d4:\u0091k\u00e9S\u00fb<\u0018\u0090\u00e7r\\\u001fµ\u00eb\u00e9/\u00dd15\u0018\u0090µF\u00ad¦=,©>\u00115\t\u00d2\u0017z&\u00d5\u00e6\u0086wB\u00ee\u00fd5\u00c1®c¥\u00da\u008c\u00c2³P\u00dc4¾=\u00e8\u00063\u0087\u00f6\u008a+q®.\u00f8¾¥XM\u00da¶\u0082\u009b\u00ef\u000e\u00de\u00f4A$'0\u00f4U\u0002pf&\u0016cw\u008a\u0011}\u00da-;\u0016\u00f2\u00d6\u0000\u00c5\u00df\u00c1«\u001e&fª\t\u0089b\u00d2P\u0002\u0001~ª\\\u0018U\f8\u0013\\\u00d1\"\u0082r\u0004\u00d9\u00da\u0005\u00d4U@)z \u00d6\u00db\u0013+u5\u0087\u0001\u00db\u00c0\u000b\u0002$¾\u00e0\u00c1+\u00d7[\u0093v\u00d9\\-(\u0099\u009e\u0012\u00ad\u0000X\u00eb6\u0001+½\u00ad\u00836").length();
        int n3 = 14;
        int n4 = -1;
    Label_0023:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 20));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0259: {
                            if (length > 1) {
                                break Label_0259;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 12;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 127;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 34;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 2;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 78;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 40;
                                        break;
                                    }
                                    default: {
                                        n11 = 109;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            a2[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0023;
                            }
                            n2 = (s = "\u00dbIU½?\u00d3l\u00e1\u00dcO\u00ddJTf\u00f9\u00e2\u00f2\u00ca\u00eai\u00d6k\u00ca&7ki\u008cb\u00c8\u000f\u001dE\\\u0004\u00fd1\u0086\u00ea\u001b\b)?°k\u0005\u00de\u00ec\u00d3\u00c6\u0014\u0002A]¦\u00f4\u0016\\\u00cen\u00da\u00ee\u0089x§©\u00c4").length();
                            n3 = 39;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            a2[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0023;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 6)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        a = a2;
        b = new String[32];
        Rasapi32Util.phoneBookMutex = new Object();
        (CONNECTION_STATE_TEXT = new HashMap()).put(0, a(30820, -26180));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(1, a(30847, -31368));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(2, a(30843, -17409));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(3, a(30840, -11163));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(4, a(30842, 28430));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(5, a(30824, -23146));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(6, a(30817, -2292));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(7, a(30845, -28677));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(8, a(30830, -19745));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(9, a(30826, 21169));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(10, a(30839, 3777));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(11, a(30819, -26838));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(12, a(30844, -12364));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(13, a(30821, -3510));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(14, a(30818, -17272));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(15, a(30833, 4676));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(16, a(30846, -26327));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(17, a(30835, -15443));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(18, a(30827, 387));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(19, a(30816, 15703));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(20, a(30838, -26930));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(21, a(30823, 6637));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(22, a(30831, 11352));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(23, a(30828, -23913));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(4096, a(30829, -26721));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(4097, a(30834, 25591));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(4098, a(30841, -30368));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(4099, a(30836, -9690));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(4100, a(30825, -30965));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(8192, a(30837, -30953));
        Rasapi32Util.CONNECTION_STATE_TEXT.put(8193, a(30822, 12547));
    }
    
    private static Rasapi32Util$Ras32Exception b(final Rasapi32Util$Ras32Exception ex) {
        return ex;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0x7870) & 0xFFFF;
        if (Rasapi32Util.b[n3] == null) {
            final char[] charArray = Rasapi32Util.a[n3].toCharArray();
            int n4 = 0;
            switch (charArray[0] & '\u00ff') {
                case 0: {
                    n4 = 84;
                    break;
                }
                case 1: {
                    n4 = 214;
                    break;
                }
                case 2: {
                    n4 = 7;
                    break;
                }
                case 3: {
                    n4 = 160;
                    break;
                }
                case 4: {
                    n4 = 59;
                    break;
                }
                case 5: {
                    n4 = 171;
                    break;
                }
                case 6: {
                    n4 = 156;
                    break;
                }
                case 7: {
                    n4 = 189;
                    break;
                }
                case 8: {
                    n4 = 198;
                    break;
                }
                case 9: {
                    n4 = 209;
                    break;
                }
                case 10: {
                    n4 = 61;
                    break;
                }
                case 11: {
                    n4 = 24;
                    break;
                }
                case 12: {
                    n4 = 62;
                    break;
                }
                case 13: {
                    n4 = 38;
                    break;
                }
                case 14: {
                    n4 = 116;
                    break;
                }
                case 15: {
                    n4 = 104;
                    break;
                }
                case 16: {
                    n4 = 236;
                    break;
                }
                case 17: {
                    n4 = 248;
                    break;
                }
                case 18: {
                    n4 = 0;
                    break;
                }
                case 19: {
                    n4 = 211;
                    break;
                }
                case 20: {
                    n4 = 184;
                    break;
                }
                case 21: {
                    n4 = 44;
                    break;
                }
                case 22: {
                    n4 = 229;
                    break;
                }
                case 23: {
                    n4 = 98;
                    break;
                }
                case 24: {
                    n4 = 165;
                    break;
                }
                case 25: {
                    n4 = 10;
                    break;
                }
                case 26: {
                    n4 = 234;
                    break;
                }
                case 27: {
                    n4 = 197;
                    break;
                }
                case 28: {
                    n4 = 29;
                    break;
                }
                case 29: {
                    n4 = 86;
                    break;
                }
                case 30: {
                    n4 = 212;
                    break;
                }
                case 31: {
                    n4 = 96;
                    break;
                }
                case 32: {
                    n4 = 246;
                    break;
                }
                case 33: {
                    n4 = 35;
                    break;
                }
                case 34: {
                    n4 = 245;
                    break;
                }
                case 35: {
                    n4 = 136;
                    break;
                }
                case 36: {
                    n4 = 218;
                    break;
                }
                case 37: {
                    n4 = 40;
                    break;
                }
                case 38: {
                    n4 = 30;
                    break;
                }
                case 39: {
                    n4 = 252;
                    break;
                }
                case 40: {
                    n4 = 100;
                    break;
                }
                case 41: {
                    n4 = 195;
                    break;
                }
                case 42: {
                    n4 = 112;
                    break;
                }
                case 43: {
                    n4 = 163;
                    break;
                }
                case 44: {
                    n4 = 253;
                    break;
                }
                case 45: {
                    n4 = 203;
                    break;
                }
                case 46: {
                    n4 = 106;
                    break;
                }
                case 47: {
                    n4 = 66;
                    break;
                }
                case 48: {
                    n4 = 41;
                    break;
                }
                case 49: {
                    n4 = 28;
                    break;
                }
                case 50: {
                    n4 = 191;
                    break;
                }
                case 51: {
                    n4 = 162;
                    break;
                }
                case 52: {
                    n4 = 67;
                    break;
                }
                case 53: {
                    n4 = 130;
                    break;
                }
                case 54: {
                    n4 = 91;
                    break;
                }
                case 55: {
                    n4 = 137;
                    break;
                }
                case 56: {
                    n4 = 121;
                    break;
                }
                case 57: {
                    n4 = 82;
                    break;
                }
                case 58: {
                    n4 = 249;
                    break;
                }
                case 59: {
                    n4 = 230;
                    break;
                }
                case 60: {
                    n4 = 129;
                    break;
                }
                case 61: {
                    n4 = 194;
                    break;
                }
                case 62: {
                    n4 = 42;
                    break;
                }
                case 63: {
                    n4 = 79;
                    break;
                }
                case 64: {
                    n4 = 83;
                    break;
                }
                case 65: {
                    n4 = 123;
                    break;
                }
                case 66: {
                    n4 = 190;
                    break;
                }
                case 67: {
                    n4 = 113;
                    break;
                }
                case 68: {
                    n4 = 207;
                    break;
                }
                case 69: {
                    n4 = 152;
                    break;
                }
                case 70: {
                    n4 = 213;
                    break;
                }
                case 71: {
                    n4 = 254;
                    break;
                }
                case 72: {
                    n4 = 148;
                    break;
                }
                case 73: {
                    n4 = 176;
                    break;
                }
                case 74: {
                    n4 = 223;
                    break;
                }
                case 75: {
                    n4 = 210;
                    break;
                }
                case 76: {
                    n4 = 153;
                    break;
                }
                case 77: {
                    n4 = 220;
                    break;
                }
                case 78: {
                    n4 = 3;
                    break;
                }
                case 79: {
                    n4 = 154;
                    break;
                }
                case 80: {
                    n4 = 65;
                    break;
                }
                case 81: {
                    n4 = 34;
                    break;
                }
                case 82: {
                    n4 = 159;
                    break;
                }
                case 83: {
                    n4 = 178;
                    break;
                }
                case 84: {
                    n4 = 158;
                    break;
                }
                case 85: {
                    n4 = 244;
                    break;
                }
                case 86: {
                    n4 = 25;
                    break;
                }
                case 87: {
                    n4 = 109;
                    break;
                }
                case 88: {
                    n4 = 239;
                    break;
                }
                case 89: {
                    n4 = 111;
                    break;
                }
                case 90: {
                    n4 = 237;
                    break;
                }
                case 91: {
                    n4 = 216;
                    break;
                }
                case 92: {
                    n4 = 175;
                    break;
                }
                case 93: {
                    n4 = 139;
                    break;
                }
                case 94: {
                    n4 = 5;
                    break;
                }
                case 95: {
                    n4 = 141;
                    break;
                }
                case 96: {
                    n4 = 71;
                    break;
                }
                case 97: {
                    n4 = 108;
                    break;
                }
                case 98: {
                    n4 = 105;
                    break;
                }
                case 99: {
                    n4 = 133;
                    break;
                }
                case 100: {
                    n4 = 221;
                    break;
                }
                case 101: {
                    n4 = 16;
                    break;
                }
                case 102: {
                    n4 = 164;
                    break;
                }
                case 103: {
                    n4 = 48;
                    break;
                }
                case 104: {
                    n4 = 46;
                    break;
                }
                case 105: {
                    n4 = 74;
                    break;
                }
                case 106: {
                    n4 = 114;
                    break;
                }
                case 107: {
                    n4 = 226;
                    break;
                }
                case 108: {
                    n4 = 140;
                    break;
                }
                case 109: {
                    n4 = 241;
                    break;
                }
                case 110: {
                    n4 = 22;
                    break;
                }
                case 111: {
                    n4 = 52;
                    break;
                }
                case 112: {
                    n4 = 125;
                    break;
                }
                case 113: {
                    n4 = 51;
                    break;
                }
                case 114: {
                    n4 = 149;
                    break;
                }
                case 115: {
                    n4 = 119;
                    break;
                }
                case 116: {
                    n4 = 17;
                    break;
                }
                case 117: {
                    n4 = 8;
                    break;
                }
                case 118: {
                    n4 = 57;
                    break;
                }
                case 119: {
                    n4 = 90;
                    break;
                }
                case 120: {
                    n4 = 1;
                    break;
                }
                case 121: {
                    n4 = 228;
                    break;
                }
                case 122: {
                    n4 = 78;
                    break;
                }
                case 123: {
                    n4 = 75;
                    break;
                }
                case 124: {
                    n4 = 183;
                    break;
                }
                case 125: {
                    n4 = 180;
                    break;
                }
                case 126: {
                    n4 = 21;
                    break;
                }
                case 127: {
                    n4 = 222;
                    break;
                }
                case 128: {
                    n4 = 99;
                    break;
                }
                case 129: {
                    n4 = 168;
                    break;
                }
                case 130: {
                    n4 = 33;
                    break;
                }
                case 131: {
                    n4 = 196;
                    break;
                }
                case 132: {
                    n4 = 13;
                    break;
                }
                case 133: {
                    n4 = 233;
                    break;
                }
                case 134: {
                    n4 = 26;
                    break;
                }
                case 135: {
                    n4 = 117;
                    break;
                }
                case 136: {
                    n4 = 242;
                    break;
                }
                case 137: {
                    n4 = 19;
                    break;
                }
                case 138: {
                    n4 = 49;
                    break;
                }
                case 139: {
                    n4 = 255;
                    break;
                }
                case 140: {
                    n4 = 169;
                    break;
                }
                case 141: {
                    n4 = 36;
                    break;
                }
                case 142: {
                    n4 = 174;
                    break;
                }
                case 143: {
                    n4 = 64;
                    break;
                }
                case 144: {
                    n4 = 127;
                    break;
                }
                case 145: {
                    n4 = 87;
                    break;
                }
                case 146: {
                    n4 = 232;
                    break;
                }
                case 147: {
                    n4 = 204;
                    break;
                }
                case 148: {
                    n4 = 132;
                    break;
                }
                case 149: {
                    n4 = 101;
                    break;
                }
                case 150: {
                    n4 = 146;
                    break;
                }
                case 151: {
                    n4 = 39;
                    break;
                }
                case 152: {
                    n4 = 173;
                    break;
                }
                case 153: {
                    n4 = 185;
                    break;
                }
                case 154: {
                    n4 = 92;
                    break;
                }
                case 155: {
                    n4 = 235;
                    break;
                }
                case 156: {
                    n4 = 128;
                    break;
                }
                case 157: {
                    n4 = 97;
                    break;
                }
                case 158: {
                    n4 = 131;
                    break;
                }
                case 159: {
                    n4 = 206;
                    break;
                }
                case 160: {
                    n4 = 69;
                    break;
                }
                case 161: {
                    n4 = 215;
                    break;
                }
                case 162: {
                    n4 = 227;
                    break;
                }
                case 163: {
                    n4 = 110;
                    break;
                }
                case 164: {
                    n4 = 161;
                    break;
                }
                case 165: {
                    n4 = 85;
                    break;
                }
                case 166: {
                    n4 = 122;
                    break;
                }
                case 167: {
                    n4 = 126;
                    break;
                }
                case 168: {
                    n4 = 138;
                    break;
                }
                case 169: {
                    n4 = 193;
                    break;
                }
                case 170: {
                    n4 = 144;
                    break;
                }
                case 171: {
                    n4 = 23;
                    break;
                }
                case 172: {
                    n4 = 150;
                    break;
                }
                case 173: {
                    n4 = 224;
                    break;
                }
                case 174: {
                    n4 = 170;
                    break;
                }
                case 175: {
                    n4 = 2;
                    break;
                }
                case 176: {
                    n4 = 15;
                    break;
                }
                case 177: {
                    n4 = 250;
                    break;
                }
                case 178: {
                    n4 = 31;
                    break;
                }
                case 179: {
                    n4 = 12;
                    break;
                }
                case 180: {
                    n4 = 124;
                    break;
                }
                case 181: {
                    n4 = 55;
                    break;
                }
                case 182: {
                    n4 = 73;
                    break;
                }
                case 183: {
                    n4 = 6;
                    break;
                }
                case 184: {
                    n4 = 4;
                    break;
                }
                case 185: {
                    n4 = 115;
                    break;
                }
                case 186: {
                    n4 = 102;
                    break;
                }
                case 187: {
                    n4 = 251;
                    break;
                }
                case 188: {
                    n4 = 63;
                    break;
                }
                case 189: {
                    n4 = 37;
                    break;
                }
                case 190: {
                    n4 = 143;
                    break;
                }
                case 191: {
                    n4 = 217;
                    break;
                }
                case 192: {
                    n4 = 225;
                    break;
                }
                case 193: {
                    n4 = 147;
                    break;
                }
                case 194: {
                    n4 = 243;
                    break;
                }
                case 195: {
                    n4 = 81;
                    break;
                }
                case 196: {
                    n4 = 77;
                    break;
                }
                case 197: {
                    n4 = 32;
                    break;
                }
                case 198: {
                    n4 = 145;
                    break;
                }
                case 199: {
                    n4 = 142;
                    break;
                }
                case 200: {
                    n4 = 68;
                    break;
                }
                case 201: {
                    n4 = 120;
                    break;
                }
                case 202: {
                    n4 = 14;
                    break;
                }
                case 203: {
                    n4 = 177;
                    break;
                }
                case 204: {
                    n4 = 53;
                    break;
                }
                case 205: {
                    n4 = 187;
                    break;
                }
                case 206: {
                    n4 = 103;
                    break;
                }
                case 207: {
                    n4 = 151;
                    break;
                }
                case 208: {
                    n4 = 240;
                    break;
                }
                case 209: {
                    n4 = 93;
                    break;
                }
                case 210: {
                    n4 = 72;
                    break;
                }
                case 211: {
                    n4 = 167;
                    break;
                }
                case 212: {
                    n4 = 192;
                    break;
                }
                case 213: {
                    n4 = 58;
                    break;
                }
                case 214: {
                    n4 = 181;
                    break;
                }
                case 215: {
                    n4 = 155;
                    break;
                }
                case 216: {
                    n4 = 157;
                    break;
                }
                case 217: {
                    n4 = 54;
                    break;
                }
                case 218: {
                    n4 = 172;
                    break;
                }
                case 219: {
                    n4 = 134;
                    break;
                }
                case 220: {
                    n4 = 60;
                    break;
                }
                case 221: {
                    n4 = 94;
                    break;
                }
                case 222: {
                    n4 = 70;
                    break;
                }
                case 223: {
                    n4 = 188;
                    break;
                }
                case 224: {
                    n4 = 186;
                    break;
                }
                case 225: {
                    n4 = 76;
                    break;
                }
                case 226: {
                    n4 = 47;
                    break;
                }
                case 227: {
                    n4 = 95;
                    break;
                }
                case 228: {
                    n4 = 219;
                    break;
                }
                case 229: {
                    n4 = 166;
                    break;
                }
                case 230: {
                    n4 = 199;
                    break;
                }
                case 231: {
                    n4 = 50;
                    break;
                }
                case 232: {
                    n4 = 11;
                    break;
                }
                case 233: {
                    n4 = 45;
                    break;
                }
                case 234: {
                    n4 = 9;
                    break;
                }
                case 235: {
                    n4 = 247;
                    break;
                }
                case 236: {
                    n4 = 238;
                    break;
                }
                case 237: {
                    n4 = 200;
                    break;
                }
                case 238: {
                    n4 = 89;
                    break;
                }
                case 239: {
                    n4 = 107;
                    break;
                }
                case 240: {
                    n4 = 27;
                    break;
                }
                case 241: {
                    n4 = 18;
                    break;
                }
                case 242: {
                    n4 = 20;
                    break;
                }
                case 243: {
                    n4 = 118;
                    break;
                }
                case 244: {
                    n4 = 80;
                    break;
                }
                case 245: {
                    n4 = 182;
                    break;
                }
                case 246: {
                    n4 = 43;
                    break;
                }
                case 247: {
                    n4 = 56;
                    break;
                }
                case 248: {
                    n4 = 135;
                    break;
                }
                case 249: {
                    n4 = 179;
                    break;
                }
                case 250: {
                    n4 = 202;
                    break;
                }
                case 251: {
                    n4 = 208;
                    break;
                }
                case 252: {
                    n4 = 88;
                    break;
                }
                case 253: {
                    n4 = 201;
                    break;
                }
                case 254: {
                    n4 = 231;
                    break;
                }
                default: {
                    n4 = 205;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < charArray.length; ++i) {
                final int n8 = i % 2;
                final char[] array = charArray;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ charArray[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ charArray[i]) & 0xFF);
                }
            }
            Rasapi32Util.b[n3] = new String(charArray).intern();
        }
        return Rasapi32Util.b[n3];
    }
}
