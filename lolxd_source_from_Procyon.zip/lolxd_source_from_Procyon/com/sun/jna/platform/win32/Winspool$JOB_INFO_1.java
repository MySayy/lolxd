// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

import com.sun.jna.Pointer;
import com.sun.jna.Memory;
import java.util.List;
import com.sun.jna.Structure;

public class Winspool$JOB_INFO_1 extends Structure
{
    public static final List<String> FIELDS;
    public int JobId;
    public String pPrinterName;
    public String pMachineName;
    public String pUserName;
    public String pDocument;
    public String pDatatype;
    public String pStatus;
    public int Status;
    public int Priority;
    public int Position;
    public int TotalPages;
    public int PagesPrinted;
    public WinBase$SYSTEMTIME Submitted;
    
    public Winspool$JOB_INFO_1() {
    }
    
    public Winspool$JOB_INFO_1(final int n) {
        super(new Memory(n));
    }
    
    @Override
    protected List<String> getFieldOrder() {
        return Winspool$JOB_INFO_1.FIELDS;
    }
    
    static {
        final String[] array = new String[13];
        int n = 0;
        String s;
        int n2 = (s = "gN\u001c\u0001s+qy~\tgN\u0012\u0016g2mgo\u0005]e\u0011+b\nCe\u0007\u0003j\u0016upo\u0000\u0007gY\u0007\u0003r3g\fgG\u0012\u0001n/zrD\u0012\u000fc\fGk\u0014\u0007u\u0016f~d\u0007\u0007b\tg_\u0000\u0007t\buzo\tD\u007f\u0011\u000fo2`rn\u0006D~\u0012\u0016s5\fgZ\u0001\u000bh2qeD\u0012\u000fc").length();
        int n3 = 9;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 117));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0252: {
                            if (length > 1) {
                                break Label_0252;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 98;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 127;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 6;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 23;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 115;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 51;
                                        break;
                                    }
                                    default: {
                                        n11 = 97;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "pR7<E\u0018LN\bpO-:C\u0018WY").length();
                            n3 = 8;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 66)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[2], array2[10], array2[5], array2[7], array2[0], array2[1], array2[4], array2[9], array2[12], array2[11], array2[3], array2[6], array2[8]);
    }
}
