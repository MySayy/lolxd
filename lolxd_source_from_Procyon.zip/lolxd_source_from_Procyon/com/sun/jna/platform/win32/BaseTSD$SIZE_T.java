// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.win32;

public class BaseTSD$SIZE_T extends BaseTSD$ULONG_PTR
{
    public BaseTSD$SIZE_T() {
        this(0L);
    }
    
    public BaseTSD$SIZE_T(final long n) {
        super(n);
    }
}
