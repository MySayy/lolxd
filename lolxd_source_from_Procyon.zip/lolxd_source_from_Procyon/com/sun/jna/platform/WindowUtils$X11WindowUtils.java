// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import com.sun.jna.Native;
import java.awt.Component;
import java.awt.Point;
import java.awt.Window;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.GraphicsConfiguration;
import com.sun.jna.Pointer;
import com.sun.jna.platform.unix.X11$GC;
import java.awt.Rectangle;
import com.sun.jna.platform.unix.X11$XRectangle;
import java.util.List;
import java.util.ArrayList;
import com.sun.jna.platform.unix.X11$XGCValues;
import com.sun.jna.NativeLong;
import com.sun.jna.platform.unix.X11$Drawable;
import com.sun.jna.platform.unix.X11;
import com.sun.jna.platform.unix.X11$Pixmap;
import java.awt.image.Raster;
import com.sun.jna.platform.unix.X11$Window;
import com.sun.jna.platform.unix.X11$Display;

class WindowUtils$X11WindowUtils extends WindowUtils$NativeWindowUtils
{
    private boolean didCheck;
    private long[] alphaVisualIDs;
    private static final long OPAQUE = 4294967295L;
    private static final String OPACITY;
    private static final String[] d;
    private static final String[] e;
    
    private WindowUtils$X11WindowUtils() {
        this.alphaVisualIDs = new long[0];
    }
    
    private static X11$Pixmap createBitmap(final X11$Display x11$Display, final X11$Window x11$Window, final Raster raster) {
        final X11 instance = X11.INSTANCE;
        final Rectangle bounds = raster.getBounds();
        final int[] b = WindowUtils$NativeWindowUtils.b();
        final int n = bounds.x + bounds.width;
        final int[] array = b;
        final int n2 = bounds.y + bounds.height;
        final X11$Pixmap xCreatePixmap = instance.XCreatePixmap(x11$Display, x11$Window, n, n2, 1);
        final X11$GC xCreateGC = instance.XCreateGC(x11$Display, xCreatePixmap, new NativeLong(0L), null);
        Label_0138: {
            Label_0094: {
                try {
                    if (array != null) {
                        break Label_0138;
                    }
                    final X11$GC x11$GC = xCreateGC;
                    if (x11$GC == null) {
                        break Label_0094;
                    }
                    break Label_0094;
                }
                catch (UnsupportedOperationException ex) {
                    throw c(ex);
                }
                try {
                    final X11$GC x11$GC = xCreateGC;
                    if (x11$GC == null) {
                        return null;
                    }
                }
                catch (UnsupportedOperationException ex2) {
                    throw c(ex2);
                }
            }
            instance.XSetForeground(x11$Display, xCreateGC, new NativeLong(0L));
            instance.XFillRectangle(x11$Display, xCreatePixmap, xCreateGC, 0, 0, n, n2);
        }
        final ArrayList<Object> list = new ArrayList<Object>();
        try {
            RasterRangesUtils.outputOccupiedRanges(raster, new WindowUtils$X11WindowUtils$1(list));
            final X11$XRectangle[] array2 = (X11$XRectangle[])new X11$XRectangle().toArray(list.size());
            int i = 0;
            while (i < array2.length) {
                final Rectangle rectangle = list.get(i);
                array2[i].x = (short)rectangle.x;
                array2[i].y = (short)rectangle.y;
                array2[i].width = (short)rectangle.width;
                array2[i].height = (short)rectangle.height;
                final Pointer pointer = array2[i].getPointer();
                try {
                    pointer.setShort(0L, (short)rectangle.x);
                    pointer.setShort(2L, (short)rectangle.y);
                    pointer.setShort(4L, (short)rectangle.width);
                    pointer.setShort(6L, (short)rectangle.height);
                    array2[i].setAutoSynch(false);
                    ++i;
                    if (array != null) {
                        return xCreatePixmap;
                    }
                    if (array == null) {
                        continue;
                    }
                }
                catch (UnsupportedOperationException ex3) {
                    throw c(ex3);
                }
                break;
            }
            instance.XSetForeground(x11$Display, xCreateGC, new NativeLong(1L));
            instance.XFillRectangles(x11$Display, xCreatePixmap, xCreateGC, array2, array2.length);
            return xCreatePixmap;
        }
        finally {
            instance.XFreeGC(x11$Display, xCreateGC);
        }
        return xCreatePixmap;
    }
    
    @Override
    public boolean isWindowAlphaSupported() {
        final int[] b = WindowUtils$NativeWindowUtils.b();
        Label_0024: {
            int length;
            int n;
            try {
                n = (length = this.getAlphaVisualIDs().length);
                if (b != null) {
                    return length != 0;
                }
                final int[] array = b;
                if (array == null) {
                    break Label_0024;
                }
                return length != 0;
            }
            catch (UnsupportedOperationException ex) {
                throw c(ex);
            }
            try {
                final int[] array = b;
                if (array != null) {
                    return length != 0;
                }
                if (n <= 0) {
                    return false;
                }
            }
            catch (UnsupportedOperationException ex2) {
                throw c(ex2);
            }
        }
        int length = true ? 1 : 0;
        return length != 0;
        length = (false ? 1 : 0);
        return length != 0;
    }
    
    private static long getVisualID(final GraphicsConfiguration obj) {
        try {
            return ((Number)obj.getClass().getMethod(b(28383, 14288), (Class<?>[])null).invoke(obj, (Object[])null)).longValue();
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return -1L;
        }
    }
    
    @Override
    public GraphicsConfiguration getAlphaCompatibleGraphicsConfiguration() {
        final int[] b = WindowUtils$NativeWindowUtils.b();
        Label_0138: {
            try {
                final WindowUtils$X11WindowUtils windowUtils$X11WindowUtils = this;
                if (b != null) {
                    return windowUtils$X11WindowUtils.getAlphaCompatibleGraphicsConfiguration();
                }
                if (!this.isWindowAlphaSupported()) {
                    break Label_0138;
                }
            }
            catch (UnsupportedOperationException ex) {
                throw c(ex);
            }
            final GraphicsDevice[] screenDevices = GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices();
            int n = 0;
            do {
                int i = 0;
            Label_0036:
                while (i < screenDevices.length) {
                    final GraphicsConfiguration[] configurations = screenDevices[n].getConfigurations();
                    int n2 = 0;
                    do {
                        long n3 = 0L;
                        Label_0053: {
                            n3 = n2;
                        }
                        Label_0055:
                        while (n3 < configurations.length) {
                            final long visualID = getVisualID(configurations[n2]);
                            final long[] alphaVisualIDs = this.getAlphaVisualIDs();
                            i = 0;
                            if (b == null) {
                                int j = i;
                                while (j < alphaVisualIDs.length) {
                                    final long n4 = n3 = lcmp(visualID, alphaVisualIDs[j]);
                                    if (b != null) {
                                        continue Label_0055;
                                    }
                                    try {
                                        if (n4 == 0) {
                                            return configurations[n2];
                                        }
                                    }
                                    catch (UnsupportedOperationException ex2) {
                                        throw c(ex2);
                                    }
                                    ++j;
                                    if (b != null) {
                                        break;
                                    }
                                }
                                ++n2;
                                continue Label_0053;
                            }
                            continue Label_0036;
                        }
                        break;
                    } while (b == null);
                    ++n;
                }
                break;
            } while (b == null);
        }
        final WindowUtils$X11WindowUtils windowUtils$X11WindowUtils = this;
        return windowUtils$X11WindowUtils.getAlphaCompatibleGraphicsConfiguration();
    }
    
    private synchronized long[] getAlphaVisualIDs() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: aload_0        
        //     5: aload_1        
        //     6: ifnonnull       39
        //     9: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils.didCheck:Z
        //    12: ifeq            34
        //    15: goto            22
        //    18: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //    21: athrow         
        //    22: aload_0        
        //    23: goto            30
        //    26: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //    29: athrow         
        //    30: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils.alphaVisualIDs:[J
        //    33: areturn        
        //    34: aload_0        
        //    35: aload_1        
        //    36: ifnonnull       30
        //    39: iconst_1       
        //    40: putfield        com/sun/jna/platform/WindowUtils$X11WindowUtils.didCheck:Z
        //    43: getstatic       com/sun/jna/platform/unix/X11.INSTANCE:Lcom/sun/jna/platform/unix/X11;
        //    46: astore_2       
        //    47: aload_2        
        //    48: aconst_null    
        //    49: invokeinterface com/sun/jna/platform/unix/X11.XOpenDisplay:(Ljava/lang/String;)Lcom/sun/jna/platform/unix/X11$Display;
        //    54: astore_3       
        //    55: aload_3        
        //    56: ifnonnull       68
        //    59: aload_0        
        //    60: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils.alphaVisualIDs:[J
        //    63: areturn        
        //    64: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //    67: athrow         
        //    68: aconst_null    
        //    69: astore          4
        //    71: aload_2        
        //    72: aload_3        
        //    73: invokeinterface com/sun/jna/platform/unix/X11.XDefaultScreen:(Lcom/sun/jna/platform/unix/X11$Display;)I
        //    78: istore          5
        //    80: new             Lcom/sun/jna/platform/unix/X11$XVisualInfo;
        //    83: dup            
        //    84: invokespecial   com/sun/jna/platform/unix/X11$XVisualInfo.<init>:()V
        //    87: astore          6
        //    89: aload           6
        //    91: iload           5
        //    93: putfield        com/sun/jna/platform/unix/X11$XVisualInfo.screen:I
        //    96: aload           6
        //    98: bipush          32
        //   100: putfield        com/sun/jna/platform/unix/X11$XVisualInfo.depth:I
        //   103: aload           6
        //   105: iconst_4       
        //   106: putfield        com/sun/jna/platform/unix/X11$XVisualInfo.c_class:I
        //   109: new             Lcom/sun/jna/NativeLong;
        //   112: dup            
        //   113: ldc2_w          14
        //   116: invokespecial   com/sun/jna/NativeLong.<init>:(J)V
        //   119: astore          7
        //   121: new             Lcom/sun/jna/ptr/IntByReference;
        //   124: dup            
        //   125: invokespecial   com/sun/jna/ptr/IntByReference.<init>:()V
        //   128: astore          8
        //   130: aload_2        
        //   131: aload_3        
        //   132: aload           7
        //   134: aload           6
        //   136: aload           8
        //   138: invokeinterface com/sun/jna/platform/unix/X11.XGetVisualInfo:(Lcom/sun/jna/platform/unix/X11$Display;Lcom/sun/jna/NativeLong;Lcom/sun/jna/platform/unix/X11$XVisualInfo;Lcom/sun/jna/ptr/IntByReference;)Lcom/sun/jna/platform/unix/X11$XVisualInfo;
        //   143: astore          4
        //   145: aload           4
        //   147: aload_1        
        //   148: ifnonnull       461
        //   151: ifnull          459
        //   154: goto            161
        //   157: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   160: athrow         
        //   161: new             Ljava/util/ArrayList;
        //   164: dup            
        //   165: invokespecial   java/util/ArrayList.<init>:()V
        //   168: astore          9
        //   170: aload           4
        //   172: aload           8
        //   174: invokevirtual   com/sun/jna/ptr/IntByReference.getValue:()I
        //   177: invokevirtual   com/sun/jna/platform/unix/X11$XVisualInfo.toArray:(I)[Lcom/sun/jna/Structure;
        //   180: checkcast       [Lcom/sun/jna/platform/unix/X11$XVisualInfo;
        //   183: checkcast       [Lcom/sun/jna/platform/unix/X11$XVisualInfo;
        //   186: astore          10
        //   188: iconst_0       
        //   189: istore          11
        //   191: iload           11
        //   193: aload           10
        //   195: arraylength    
        //   196: if_icmpge       330
        //   199: getstatic       com/sun/jna/platform/unix/X11$Xrender.INSTANCE:Lcom/sun/jna/platform/unix/X11$Xrender;
        //   202: aload_3        
        //   203: aload           10
        //   205: iload           11
        //   207: aaload         
        //   208: getfield        com/sun/jna/platform/unix/X11$XVisualInfo.visual:Lcom/sun/jna/platform/unix/X11$Visual;
        //   211: invokeinterface com/sun/jna/platform/unix/X11$Xrender.XRenderFindVisualFormat:(Lcom/sun/jna/platform/unix/X11$Display;Lcom/sun/jna/platform/unix/X11$Visual;)Lcom/sun/jna/platform/unix/X11$Xrender$XRenderPictFormat;
        //   216: astore          12
        //   218: aload_1        
        //   219: ifnonnull       326
        //   222: aload           12
        //   224: getfield        com/sun/jna/platform/unix/X11$Xrender$XRenderPictFormat.type:I
        //   227: aload_1        
        //   228: ifnonnull       275
        //   231: goto            238
        //   234: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   237: athrow         
        //   238: iconst_1       
        //   239: aload_1        
        //   240: ifnonnull       353
        //   243: goto            250
        //   246: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   249: athrow         
        //   250: if_icmpne       323
        //   253: goto            260
        //   256: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   259: athrow         
        //   260: aload           12
        //   262: getfield        com/sun/jna/platform/unix/X11$Xrender$XRenderPictFormat.direct:Lcom/sun/jna/platform/unix/X11$Xrender$XRenderDirectFormat;
        //   265: getfield        com/sun/jna/platform/unix/X11$Xrender$XRenderDirectFormat.alphaMask:S
        //   268: goto            275
        //   271: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   274: athrow         
        //   275: aload_1        
        //   276: ifnonnull       322
        //   279: aload_1        
        //   280: ifnonnull       322
        //   283: goto            290
        //   286: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   289: athrow         
        //   290: ifeq            323
        //   293: goto            300
        //   296: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   299: athrow         
        //   300: aload           9
        //   302: aload           10
        //   304: iload           11
        //   306: aaload         
        //   307: getfield        com/sun/jna/platform/unix/X11$XVisualInfo.visualid:Lcom/sun/jna/platform/unix/X11$VisualID;
        //   310: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   315: goto            322
        //   318: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   321: athrow         
        //   322: pop            
        //   323: iinc            11, 1
        //   326: aload_1        
        //   327: ifnull          191
        //   330: aload_0        
        //   331: aload           9
        //   333: invokeinterface java/util/List.size:()I
        //   338: newarray        J
        //   340: putfield        com/sun/jna/platform/WindowUtils$X11WindowUtils.alphaVisualIDs:[J
        //   343: iconst_0       
        //   344: istore          11
        //   346: iload           11
        //   348: aload_0        
        //   349: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils.alphaVisualIDs:[J
        //   352: arraylength    
        //   353: if_icmpge       403
        //   356: aload_0        
        //   357: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils.alphaVisualIDs:[J
        //   360: aload_1        
        //   361: ifnonnull       407
        //   364: goto            371
        //   367: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   370: athrow         
        //   371: iload           11
        //   373: aload           9
        //   375: iload           11
        //   377: invokeinterface java/util/List.get:(I)Ljava/lang/Object;
        //   382: checkcast       Ljava/lang/Number;
        //   385: invokevirtual   java/lang/Number.longValue:()J
        //   388: lastore        
        //   389: iinc            11, 1
        //   392: aload_1        
        //   393: ifnull          346
        //   396: goto            403
        //   399: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   402: athrow         
        //   403: aload_0        
        //   404: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils.alphaVisualIDs:[J
        //   407: astore          11
        //   409: aload_1        
        //   410: ifnonnull       456
        //   413: aload           4
        //   415: ifnull          444
        //   418: goto            425
        //   421: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   424: athrow         
        //   425: aload_2        
        //   426: aload           4
        //   428: invokevirtual   com/sun/jna/platform/unix/X11$XVisualInfo.getPointer:()Lcom/sun/jna/Pointer;
        //   431: invokeinterface com/sun/jna/platform/unix/X11.XFree:(Lcom/sun/jna/Pointer;)I
        //   436: goto            443
        //   439: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   442: athrow         
        //   443: pop            
        //   444: aload_2        
        //   445: aload_3        
        //   446: invokeinterface com/sun/jna/platform/unix/X11.XCloseDisplay:(Lcom/sun/jna/platform/unix/X11$Display;)I
        //   451: aload_1        
        //   452: ifnonnull       443
        //   455: pop            
        //   456: aload           11
        //   458: areturn        
        //   459: aload           4
        //   461: ifnull          483
        //   464: aload_2        
        //   465: aload           4
        //   467: invokevirtual   com/sun/jna/platform/unix/X11$XVisualInfo.getPointer:()Lcom/sun/jna/Pointer;
        //   470: invokeinterface com/sun/jna/platform/unix/X11.XFree:(Lcom/sun/jna/Pointer;)I
        //   475: goto            482
        //   478: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   481: athrow         
        //   482: pop            
        //   483: aload_2        
        //   484: aload_3        
        //   485: invokeinterface com/sun/jna/platform/unix/X11.XCloseDisplay:(Lcom/sun/jna/platform/unix/X11$Display;)I
        //   490: aload_1        
        //   491: ifnonnull       482
        //   494: pop            
        //   495: goto            550
        //   498: astore          13
        //   500: aload_1        
        //   501: ifnonnull       547
        //   504: aload           4
        //   506: ifnull          535
        //   509: goto            516
        //   512: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   515: athrow         
        //   516: aload_2        
        //   517: aload           4
        //   519: invokevirtual   com/sun/jna/platform/unix/X11$XVisualInfo.getPointer:()Lcom/sun/jna/Pointer;
        //   522: invokeinterface com/sun/jna/platform/unix/X11.XFree:(Lcom/sun/jna/Pointer;)I
        //   527: goto            534
        //   530: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   533: athrow         
        //   534: pop            
        //   535: aload_2        
        //   536: aload_3        
        //   537: invokeinterface com/sun/jna/platform/unix/X11.XCloseDisplay:(Lcom/sun/jna/platform/unix/X11$Display;)I
        //   542: aload_1        
        //   543: ifnonnull       534
        //   546: pop            
        //   547: aload           13
        //   549: athrow         
        //   550: aload_0        
        //   551: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils.alphaVisualIDs:[J
        //   554: areturn        
        //    StackMapTable: 00 36 FF 00 12 00 02 07 00 8F 07 00 C6 00 01 07 00 75 03 43 07 00 75 43 07 00 8F 03 44 07 00 8F FF 00 18 00 04 07 00 8F 07 00 C6 07 00 4A 07 00 A2 00 01 07 00 75 03 FF 00 58 00 09 07 00 8F 07 00 C6 07 00 4A 07 00 A2 07 00 46 01 07 00 46 07 00 11 07 00 4E 00 01 07 00 75 03 FE 00 1D 07 00 16 07 00 53 01 FF 00 2A 00 0D 07 00 8F 07 00 C6 07 00 4A 07 00 A2 07 00 46 01 07 00 46 07 00 11 07 00 4E 07 00 16 07 00 53 01 07 00 BD 00 01 07 00 75 43 01 47 07 00 75 FF 00 03 00 0D 07 00 8F 07 00 C6 07 00 4A 07 00 A2 07 00 46 01 07 00 46 07 00 11 07 00 4E 07 00 16 07 00 53 01 07 00 BD 00 02 01 01 45 07 00 75 03 4A 07 00 75 43 01 4A 07 00 75 43 01 45 07 00 75 03 51 07 00 75 43 01 00 02 FA 00 03 0F FF 00 06 00 0C 07 00 8F 07 00 C6 07 00 4A 07 00 A2 07 00 46 01 07 00 46 07 00 11 07 00 4E 07 00 16 07 00 53 01 00 02 01 01 4D 07 00 75 43 07 00 BA 5B 07 00 75 03 43 07 00 BA FF 00 0D 00 0C 07 00 8F 07 00 C6 07 00 4A 07 00 A2 07 00 46 01 07 00 46 07 00 11 07 00 4E 07 00 16 07 00 53 07 00 BA 00 01 07 00 75 03 4D 07 00 75 43 01 00 0B F8 00 02 41 07 00 46 50 07 00 75 43 01 00 FF 00 0E 00 05 07 00 8F 07 00 C6 07 00 4A 07 00 A2 07 00 46 00 01 07 00 AE FF 00 0D 00 0E 07 00 8F 07 00 C6 07 00 4A 07 00 A2 07 00 46 00 00 00 00 00 00 00 00 07 00 AE 00 01 07 00 75 03 4D 07 00 75 43 01 00 0B FF 00 02 00 01 07 00 8F 00 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                     
        //  -----  -----  -----  -----  -----------------------------------------
        //  356    396    399    403    Ljava/lang/UnsupportedOperationException;
        //  353    364    367    371    Ljava/lang/UnsupportedOperationException;
        //  290    315    318    322    Ljava/lang/UnsupportedOperationException;
        //  279    293    296    300    Ljava/lang/UnsupportedOperationException;
        //  275    283    286    290    Ljava/lang/UnsupportedOperationException;
        //  250    268    271    275    Ljava/lang/UnsupportedOperationException;
        //  238    253    256    260    Ljava/lang/UnsupportedOperationException;
        //  222    243    246    250    Ljava/lang/UnsupportedOperationException;
        //  218    231    234    238    Ljava/lang/UnsupportedOperationException;
        //  145    154    157    161    Ljava/lang/UnsupportedOperationException;
        //  55     64     64     68     Ljava/lang/UnsupportedOperationException;
        //  9      23     26     30     Ljava/lang/UnsupportedOperationException;
        //  4      15     18     22     Ljava/lang/UnsupportedOperationException;
        //  71     409    498    550    Any
        //  461    475    478    482    Ljava/lang/UnsupportedOperationException;
        //  413    436    439    443    Ljava/lang/UnsupportedOperationException;
        //  409    418    421    425    Ljava/lang/UnsupportedOperationException;
        //  498    500    498    550    Any
        //  500    509    512    516    Ljava/lang/UnsupportedOperationException;
        //  504    527    530    534    Ljava/lang/UnsupportedOperationException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0238:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static X11$Window getContentWindow(final Window p0, final X11$Display p1, final X11$Window p2, final Point p3) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore          4
        //     5: aload_0        
        //     6: instanceof      Ljava/awt/Frame;
        //     9: aload           4
        //    11: ifnonnull       67
        //    14: ifeq            46
        //    17: goto            24
        //    20: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //    23: athrow         
        //    24: aload_0        
        //    25: checkcast       Ljava/awt/Frame;
        //    28: invokevirtual   java/awt/Frame.isUndecorated:()Z
        //    31: goto            38
        //    34: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //    37: athrow         
        //    38: aload           4
        //    40: ifnonnull       67
        //    43: ifeq            99
        //    46: aload_0        
        //    47: instanceof      Ljava/awt/Dialog;
        //    50: aload           4
        //    52: ifnonnull       38
        //    55: goto            62
        //    58: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //    61: athrow         
        //    62: aload           4
        //    64: ifnonnull       96
        //    67: aload           4
        //    69: ifnonnull       96
        //    72: ifeq            322
        //    75: goto            82
        //    78: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //    81: athrow         
        //    82: aload_0        
        //    83: checkcast       Ljava/awt/Dialog;
        //    86: invokevirtual   java/awt/Dialog.isUndecorated:()Z
        //    89: goto            96
        //    92: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //    95: athrow         
        //    96: ifne            322
        //    99: getstatic       com/sun/jna/platform/unix/X11.INSTANCE:Lcom/sun/jna/platform/unix/X11;
        //   102: astore          5
        //   104: new             Lcom/sun/jna/platform/unix/X11$WindowByReference;
        //   107: dup            
        //   108: invokespecial   com/sun/jna/platform/unix/X11$WindowByReference.<init>:()V
        //   111: astore          6
        //   113: new             Lcom/sun/jna/platform/unix/X11$WindowByReference;
        //   116: dup            
        //   117: invokespecial   com/sun/jna/platform/unix/X11$WindowByReference.<init>:()V
        //   120: astore          7
        //   122: new             Lcom/sun/jna/ptr/PointerByReference;
        //   125: dup            
        //   126: invokespecial   com/sun/jna/ptr/PointerByReference.<init>:()V
        //   129: astore          8
        //   131: new             Lcom/sun/jna/ptr/IntByReference;
        //   134: dup            
        //   135: invokespecial   com/sun/jna/ptr/IntByReference.<init>:()V
        //   138: astore          9
        //   140: aload           5
        //   142: aload_1        
        //   143: aload_2        
        //   144: aload           6
        //   146: aload           7
        //   148: aload           8
        //   150: aload           9
        //   152: invokeinterface com/sun/jna/platform/unix/X11.XQueryTree:(Lcom/sun/jna/platform/unix/X11$Display;Lcom/sun/jna/platform/unix/X11$Window;Lcom/sun/jna/platform/unix/X11$WindowByReference;Lcom/sun/jna/platform/unix/X11$WindowByReference;Lcom/sun/jna/ptr/PointerByReference;Lcom/sun/jna/ptr/IntByReference;)I
        //   157: pop            
        //   158: aload           8
        //   160: invokevirtual   com/sun/jna/ptr/PointerByReference.getValue:()Lcom/sun/jna/Pointer;
        //   163: astore          10
        //   165: aload           10
        //   167: lconst_0       
        //   168: aload           9
        //   170: invokevirtual   com/sun/jna/ptr/IntByReference.getValue:()I
        //   173: invokevirtual   com/sun/jna/Pointer.getIntArray:(JI)[I
        //   176: astore          11
        //   178: aload           11
        //   180: astore          12
        //   182: aload           12
        //   184: arraylength    
        //   185: istore          13
        //   187: iconst_0       
        //   188: istore          14
        //   190: iload           14
        //   192: aload           4
        //   194: ifnonnull       62
        //   197: aload           4
        //   199: ifnonnull       238
        //   202: aload           4
        //   204: ifnonnull       238
        //   207: goto            214
        //   210: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   213: athrow         
        //   214: iload           13
        //   216: if_icmpge       300
        //   219: goto            226
        //   222: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   225: athrow         
        //   226: aload           12
        //   228: iload           14
        //   230: iaload         
        //   231: goto            238
        //   234: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   237: athrow         
        //   238: istore          15
        //   240: new             Lcom/sun/jna/platform/unix/X11$Window;
        //   243: dup            
        //   244: iload           15
        //   246: i2l            
        //   247: invokespecial   com/sun/jna/platform/unix/X11$Window.<init>:(J)V
        //   250: astore          16
        //   252: new             Lcom/sun/jna/platform/unix/X11$XWindowAttributes;
        //   255: dup            
        //   256: invokespecial   com/sun/jna/platform/unix/X11$XWindowAttributes.<init>:()V
        //   259: astore          17
        //   261: aload           5
        //   263: aload_1        
        //   264: aload           16
        //   266: aload           17
        //   268: invokeinterface com/sun/jna/platform/unix/X11.XGetWindowAttributes:(Lcom/sun/jna/platform/unix/X11$Display;Lcom/sun/jna/platform/unix/X11$Window;Lcom/sun/jna/platform/unix/X11$XWindowAttributes;)I
        //   273: pop            
        //   274: aload_3        
        //   275: aload           17
        //   277: getfield        com/sun/jna/platform/unix/X11$XWindowAttributes.x:I
        //   280: ineg           
        //   281: putfield        java/awt/Point.x:I
        //   284: aload_3        
        //   285: aload           17
        //   287: getfield        com/sun/jna/platform/unix/X11$XWindowAttributes.y:I
        //   290: ineg           
        //   291: putfield        java/awt/Point.y:I
        //   294: aload           16
        //   296: astore_2       
        //   297: goto            300
        //   300: aload           10
        //   302: ifnull          322
        //   305: aload           5
        //   307: aload           10
        //   309: invokeinterface com/sun/jna/platform/unix/X11.XFree:(Lcom/sun/jna/Pointer;)I
        //   314: pop            
        //   315: goto            322
        //   318: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   321: athrow         
        //   322: aload_2        
        //   323: areturn        
        //    StackMapTable: 00 16 FF 00 14 00 05 07 00 C3 07 00 A2 07 00 6B 07 00 C4 07 00 C6 00 01 07 00 75 03 49 07 00 75 43 01 07 4B 07 00 75 43 01 44 01 4A 07 00 75 03 49 07 00 75 43 01 02 FF 00 6E 00 0F 07 00 C3 07 00 A2 07 00 6B 07 00 C4 07 00 C6 07 00 4A 07 00 64 07 00 64 07 00 66 07 00 4E 07 00 C5 07 00 C6 07 00 C6 01 01 00 01 07 00 75 43 01 47 07 00 75 03 47 07 00 75 43 01 3D 51 07 00 75 FF 00 03 00 03 00 00 07 00 6B 00 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                     
        //  -----  -----  -----  -----  -----------------------------------------
        //  5      17     20     24     Ljava/lang/UnsupportedOperationException;
        //  14     31     34     38     Ljava/lang/UnsupportedOperationException;
        //  43     55     58     62     Ljava/lang/UnsupportedOperationException;
        //  67     75     78     82     Ljava/lang/UnsupportedOperationException;
        //  72     89     92     96     Ljava/lang/UnsupportedOperationException;
        //  197    207    210    214    Ljava/lang/UnsupportedOperationException;
        //  202    219    222    226    Ljava/lang/UnsupportedOperationException;
        //  214    231    234    238    Ljava/lang/UnsupportedOperationException;
        //  300    315    318    322    Ljava/lang/UnsupportedOperationException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0214:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static X11$Window getDrawable(final Component component) {
        final int n = (int)Native.getComponentID(component);
        try {
            if (n == 0) {
                return null;
            }
        }
        catch (UnsupportedOperationException ex) {
            throw c(ex);
        }
        return new X11$Window((long)n);
    }
    
    @Override
    public void setWindowAlpha(final Window window, final float n) {
        try {
            if (!this.isWindowAlphaSupported()) {
                throw new UnsupportedOperationException(b(28378, -15382));
            }
        }
        catch (UnsupportedOperationException ex) {
            throw c(ex);
        }
        this.whenDisplayable(window, new WindowUtils$X11WindowUtils$2(this, window, n));
    }
    
    @Override
    public void setWindowTransparent(final Window p0, final boolean p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_3       
        //     4: aload_1        
        //     5: instanceof      Ljavax/swing/RootPaneContainer;
        //     8: aload_3        
        //     9: ifnonnull       47
        //    12: ifne            43
        //    15: goto            22
        //    18: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //    21: athrow         
        //    22: new             Ljava/lang/IllegalArgumentException;
        //    25: dup            
        //    26: sipush          28377
        //    29: sipush          22672
        //    32: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.b:(II)Ljava/lang/String;
        //    35: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //    38: athrow         
        //    39: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //    42: athrow         
        //    43: aload_0        
        //    44: invokevirtual   com/sun/jna/platform/WindowUtils$X11WindowUtils.isWindowAlphaSupported:()Z
        //    47: aload_3        
        //    48: ifnonnull       104
        //    51: ifne            82
        //    54: goto            61
        //    57: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //    60: athrow         
        //    61: new             Ljava/lang/UnsupportedOperationException;
        //    64: dup            
        //    65: sipush          28378
        //    68: sipush          -15382
        //    71: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.b:(II)Ljava/lang/String;
        //    74: invokespecial   java/lang/UnsupportedOperationException.<init>:(Ljava/lang/String;)V
        //    77: athrow         
        //    78: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //    81: athrow         
        //    82: aload_1        
        //    83: aload_3        
        //    84: ifnonnull       161
        //    87: invokevirtual   java/awt/Window.getGraphicsConfiguration:()Ljava/awt/GraphicsConfiguration;
        //    90: aload_0        
        //    91: invokevirtual   com/sun/jna/platform/WindowUtils$X11WindowUtils.getAlphaCompatibleGraphicsConfiguration:()Ljava/awt/GraphicsConfiguration;
        //    94: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //    97: goto            104
        //   100: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   103: athrow         
        //   104: ifne            160
        //   107: new             Ljava/lang/IllegalArgumentException;
        //   110: dup            
        //   111: new             Ljava/lang/StringBuilder;
        //   114: dup            
        //   115: invokespecial   java/lang/StringBuilder.<init>:()V
        //   118: sipush          28376
        //   121: sipush          13487
        //   124: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.b:(II)Ljava/lang/String;
        //   127: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   130: aload_1        
        //   131: invokevirtual   java/awt/Window.getGraphicsConfiguration:()Ljava/awt/GraphicsConfiguration;
        //   134: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   137: sipush          28382
        //   140: sipush          21689
        //   143: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.b:(II)Ljava/lang/String;
        //   146: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   149: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   152: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //   155: athrow         
        //   156: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   159: athrow         
        //   160: aload_1        
        //   161: invokevirtual   java/awt/Window.getBackground:()Ljava/awt/Color;
        //   164: aload_3        
        //   165: ifnonnull       200
        //   168: aload_3        
        //   169: ifnonnull       200
        //   172: goto            179
        //   175: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   178: athrow         
        //   179: ifnull          232
        //   182: goto            189
        //   185: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   188: athrow         
        //   189: aload_1        
        //   190: invokevirtual   java/awt/Window.getBackground:()Ljava/awt/Color;
        //   193: goto            200
        //   196: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   199: athrow         
        //   200: invokevirtual   java/awt/Color.getAlpha:()I
        //   203: aload_3        
        //   204: ifnonnull       229
        //   207: aload_3        
        //   208: ifnonnull       229
        //   211: goto            218
        //   214: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   217: athrow         
        //   218: ifne            232
        //   221: goto            228
        //   224: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   227: athrow         
        //   228: iconst_1       
        //   229: goto            233
        //   232: iconst_0       
        //   233: istore          4
        //   235: aload_3        
        //   236: ifnonnull       272
        //   239: iload_2        
        //   240: iload           4
        //   242: if_icmpne       257
        //   245: goto            252
        //   248: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   251: athrow         
        //   252: return         
        //   253: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils.c:(Ljava/lang/UnsupportedOperationException;)Ljava/lang/UnsupportedOperationException;
        //   256: athrow         
        //   257: aload_0        
        //   258: aload_1        
        //   259: new             Lcom/sun/jna/platform/WindowUtils$X11WindowUtils$3;
        //   262: dup            
        //   263: aload_0        
        //   264: aload_1        
        //   265: iload_2        
        //   266: invokespecial   com/sun/jna/platform/WindowUtils$X11WindowUtils$3.<init>:(Lcom/sun/jna/platform/WindowUtils$X11WindowUtils;Ljava/awt/Window;Z)V
        //   269: invokevirtual   com/sun/jna/platform/WindowUtils$X11WindowUtils.whenDisplayable:(Ljava/awt/Component;Ljava/lang/Runnable;)V
        //   272: return         
        //    StackMapTable: 00 20 FF 00 12 00 04 07 00 8F 07 00 C3 01 07 00 C6 00 01 07 00 75 03 50 07 00 75 03 43 01 49 07 00 75 03 50 07 00 75 03 51 07 00 75 43 01 73 07 00 75 03 40 07 00 C3 4D 07 00 75 43 07 01 41 45 07 00 75 03 46 07 00 75 43 07 01 41 4D 07 00 75 43 01 45 07 00 75 03 40 01 02 40 01 FF 00 0E 00 05 07 00 8F 07 00 C3 01 07 00 C6 01 00 01 07 00 75 03 40 07 00 75 03 0E
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                     
        //  -----  -----  -----  -----  -----------------------------------------
        //  4      15     18     22     Ljava/lang/UnsupportedOperationException;
        //  12     39     39     43     Ljava/lang/UnsupportedOperationException;
        //  47     54     57     61     Ljava/lang/UnsupportedOperationException;
        //  51     78     78     82     Ljava/lang/UnsupportedOperationException;
        //  82     97     100    104    Ljava/lang/UnsupportedOperationException;
        //  104    156    156    160    Ljava/lang/UnsupportedOperationException;
        //  161    172    175    179    Ljava/lang/UnsupportedOperationException;
        //  168    182    185    189    Ljava/lang/UnsupportedOperationException;
        //  179    193    196    200    Ljava/lang/UnsupportedOperationException;
        //  200    211    214    218    Ljava/lang/UnsupportedOperationException;
        //  207    221    224    228    Ljava/lang/UnsupportedOperationException;
        //  235    245    248    252    Ljava/lang/UnsupportedOperationException;
        //  239    253    253    257    Ljava/lang/UnsupportedOperationException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0179:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void setWindowShape(final Window window, final WindowUtils$X11WindowUtils$PixmapSource windowUtils$X11WindowUtils$PixmapSource) {
        this.whenDisplayable(window, new WindowUtils$X11WindowUtils$4(this, window, windowUtils$X11WindowUtils$PixmapSource));
    }
    
    @Override
    protected void setMask(final Component component, final Raster raster) {
        this.setWindowShape(this.getWindow(component), new WindowUtils$X11WindowUtils$5(this, raster));
    }
    
    WindowUtils$X11WindowUtils(final WindowUtils$1 windowUtils$1) {
        this();
    }
    
    static X11$Window access$800(final Component component) {
        return getDrawable(component);
    }
    
    static X11$Window access$900(final Window window, final X11$Display x11$Display, final X11$Window x11$Window, final Point point) {
        return getContentWindow(window, x11$Display, x11$Window, point);
    }
    
    static X11$Pixmap access$1000(final X11$Display x11$Display, final X11$Window x11$Window, final Raster raster) {
        return createBitmap(x11$Display, x11$Window, raster);
    }
    
    private static UnsupportedOperationException c(final UnsupportedOperationException ex) {
        return ex;
    }
    
    static {
        final String[] d2 = new String[6];
        int n = 0;
        String s;
        int n2 = (s = "\u00d4\u00c6)D`\u0097Ra\u0089\u0093\u008d¡\u00ef\bu\u0083\b\u00d8\u00ef\u00ad%\u00fd1\u00fbG\u008a±\u00c2\u00e5\u00ea¯\u001a\u00c4A\u00f4\u008aH?\u00e1\u00c8A¥3\u00e2\u00fe_\u00d6s\u008fr\u0000.:l\u00d4[\u00c4d\u00ed\u0082\u00e9g\u00dc\u009bff0\u00c3\u0082¾º\u00c7\"\u00df²j9v.\u00cb@X\u00f9\u00eb\u00f5sX\u0011\u00d3d*0¤W7\u0001\u0090G\u0005\u00d8B\u009c\u00faB3\u009e!\u001e\u00fc.\u000eª\u00fa\\Z$m\b®\u00d3T\u00db\u00ccG©\u00e2&\u0000®@\\\u00f0\u008c\u00cd\u00924\u0081r").length();
        int n3 = 22;
        int n4 = -1;
    Label_0023:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 125));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0272: {
                            if (length > 1) {
                                break Label_0272;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 79;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 36;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 121;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 25;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 10;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 103;
                                        break;
                                    }
                                    default: {
                                        n11 = 52;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            d2[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0023;
                            }
                            n2 = (s = "\u00c42\u00e5V\u0018sU£\u00ad\u001f\n\u0019d\u00e76[H©\u00f2`s²i\\7*h<&_\u00f5\u00c1\\\u0084\u00d7\u00db 4\u00f7\u009c¦").length();
                            n3 = 9;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            d2[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0023;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 16)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        d = d2;
        e = new String[6];
        OPACITY = b(28379, 10513);
    }
    
    private static String b(final int n, final int n2) {
        final int n3 = (n ^ 0x6EDB) & 0xFFFF;
        if (WindowUtils$X11WindowUtils.e[n3] == null) {
            final char[] charArray = WindowUtils$X11WindowUtils.d[n3].toCharArray();
            int n4 = 0;
            switch (charArray[0] & '\u00ff') {
                case 0: {
                    n4 = 200;
                    break;
                }
                case 1: {
                    n4 = 213;
                    break;
                }
                case 2: {
                    n4 = 135;
                    break;
                }
                case 3: {
                    n4 = 79;
                    break;
                }
                case 4: {
                    n4 = 65;
                    break;
                }
                case 5: {
                    n4 = 87;
                    break;
                }
                case 6: {
                    n4 = 80;
                    break;
                }
                case 7: {
                    n4 = 199;
                    break;
                }
                case 8: {
                    n4 = 181;
                    break;
                }
                case 9: {
                    n4 = 58;
                    break;
                }
                case 10: {
                    n4 = 142;
                    break;
                }
                case 11: {
                    n4 = 185;
                    break;
                }
                case 12: {
                    n4 = 191;
                    break;
                }
                case 13: {
                    n4 = 146;
                    break;
                }
                case 14: {
                    n4 = 13;
                    break;
                }
                case 15: {
                    n4 = 145;
                    break;
                }
                case 16: {
                    n4 = 5;
                    break;
                }
                case 17: {
                    n4 = 163;
                    break;
                }
                case 18: {
                    n4 = 165;
                    break;
                }
                case 19: {
                    n4 = 251;
                    break;
                }
                case 20: {
                    n4 = 85;
                    break;
                }
                case 21: {
                    n4 = 131;
                    break;
                }
                case 22: {
                    n4 = 224;
                    break;
                }
                case 23: {
                    n4 = 172;
                    break;
                }
                case 24: {
                    n4 = 56;
                    break;
                }
                case 25: {
                    n4 = 66;
                    break;
                }
                case 26: {
                    n4 = 148;
                    break;
                }
                case 27: {
                    n4 = 57;
                    break;
                }
                case 28: {
                    n4 = 53;
                    break;
                }
                case 29: {
                    n4 = 175;
                    break;
                }
                case 30: {
                    n4 = 95;
                    break;
                }
                case 31: {
                    n4 = 9;
                    break;
                }
                case 32: {
                    n4 = 237;
                    break;
                }
                case 33: {
                    n4 = 227;
                    break;
                }
                case 34: {
                    n4 = 243;
                    break;
                }
                case 35: {
                    n4 = 141;
                    break;
                }
                case 36: {
                    n4 = 122;
                    break;
                }
                case 37: {
                    n4 = 238;
                    break;
                }
                case 38: {
                    n4 = 230;
                    break;
                }
                case 39: {
                    n4 = 149;
                    break;
                }
                case 40: {
                    n4 = 93;
                    break;
                }
                case 41: {
                    n4 = 245;
                    break;
                }
                case 42: {
                    n4 = 123;
                    break;
                }
                case 43: {
                    n4 = 107;
                    break;
                }
                case 44: {
                    n4 = 202;
                    break;
                }
                case 45: {
                    n4 = 105;
                    break;
                }
                case 46: {
                    n4 = 114;
                    break;
                }
                case 47: {
                    n4 = 154;
                    break;
                }
                case 48: {
                    n4 = 18;
                    break;
                }
                case 49: {
                    n4 = 52;
                    break;
                }
                case 50: {
                    n4 = 73;
                    break;
                }
                case 51: {
                    n4 = 60;
                    break;
                }
                case 52: {
                    n4 = 184;
                    break;
                }
                case 53: {
                    n4 = 34;
                    break;
                }
                case 54: {
                    n4 = 178;
                    break;
                }
                case 55: {
                    n4 = 69;
                    break;
                }
                case 56: {
                    n4 = 189;
                    break;
                }
                case 57: {
                    n4 = 39;
                    break;
                }
                case 58: {
                    n4 = 225;
                    break;
                }
                case 59: {
                    n4 = 17;
                    break;
                }
                case 60: {
                    n4 = 63;
                    break;
                }
                case 61: {
                    n4 = 109;
                    break;
                }
                case 62: {
                    n4 = 244;
                    break;
                }
                case 63: {
                    n4 = 115;
                    break;
                }
                case 64: {
                    n4 = 117;
                    break;
                }
                case 65: {
                    n4 = 32;
                    break;
                }
                case 66: {
                    n4 = 209;
                    break;
                }
                case 67: {
                    n4 = 234;
                    break;
                }
                case 68: {
                    n4 = 157;
                    break;
                }
                case 69: {
                    n4 = 0;
                    break;
                }
                case 70: {
                    n4 = 99;
                    break;
                }
                case 71: {
                    n4 = 51;
                    break;
                }
                case 72: {
                    n4 = 72;
                    break;
                }
                case 73: {
                    n4 = 29;
                    break;
                }
                case 74: {
                    n4 = 106;
                    break;
                }
                case 75: {
                    n4 = 128;
                    break;
                }
                case 76: {
                    n4 = 3;
                    break;
                }
                case 77: {
                    n4 = 170;
                    break;
                }
                case 78: {
                    n4 = 132;
                    break;
                }
                case 79: {
                    n4 = 126;
                    break;
                }
                case 80: {
                    n4 = 151;
                    break;
                }
                case 81: {
                    n4 = 246;
                    break;
                }
                case 82: {
                    n4 = 97;
                    break;
                }
                case 83: {
                    n4 = 43;
                    break;
                }
                case 84: {
                    n4 = 101;
                    break;
                }
                case 85: {
                    n4 = 71;
                    break;
                }
                case 86: {
                    n4 = 23;
                    break;
                }
                case 87: {
                    n4 = 241;
                    break;
                }
                case 88: {
                    n4 = 220;
                    break;
                }
                case 89: {
                    n4 = 188;
                    break;
                }
                case 90: {
                    n4 = 192;
                    break;
                }
                case 91: {
                    n4 = 28;
                    break;
                }
                case 92: {
                    n4 = 130;
                    break;
                }
                case 93: {
                    n4 = 59;
                    break;
                }
                case 94: {
                    n4 = 253;
                    break;
                }
                case 95: {
                    n4 = 236;
                    break;
                }
                case 96: {
                    n4 = 210;
                    break;
                }
                case 97: {
                    n4 = 19;
                    break;
                }
                case 98: {
                    n4 = 92;
                    break;
                }
                case 99: {
                    n4 = 37;
                    break;
                }
                case 100: {
                    n4 = 174;
                    break;
                }
                case 101: {
                    n4 = 14;
                    break;
                }
                case 102: {
                    n4 = 229;
                    break;
                }
                case 103: {
                    n4 = 111;
                    break;
                }
                case 104: {
                    n4 = 75;
                    break;
                }
                case 105: {
                    n4 = 147;
                    break;
                }
                case 106: {
                    n4 = 48;
                    break;
                }
                case 107: {
                    n4 = 167;
                    break;
                }
                case 108: {
                    n4 = 207;
                    break;
                }
                case 109: {
                    n4 = 36;
                    break;
                }
                case 110: {
                    n4 = 240;
                    break;
                }
                case 111: {
                    n4 = 160;
                    break;
                }
                case 112: {
                    n4 = 83;
                    break;
                }
                case 113: {
                    n4 = 124;
                    break;
                }
                case 114: {
                    n4 = 180;
                    break;
                }
                case 115: {
                    n4 = 1;
                    break;
                }
                case 116: {
                    n4 = 50;
                    break;
                }
                case 117: {
                    n4 = 108;
                    break;
                }
                case 118: {
                    n4 = 218;
                    break;
                }
                case 119: {
                    n4 = 217;
                    break;
                }
                case 120: {
                    n4 = 249;
                    break;
                }
                case 121: {
                    n4 = 155;
                    break;
                }
                case 122: {
                    n4 = 159;
                    break;
                }
                case 123: {
                    n4 = 247;
                    break;
                }
                case 124: {
                    n4 = 42;
                    break;
                }
                case 125: {
                    n4 = 90;
                    break;
                }
                case 126: {
                    n4 = 67;
                    break;
                }
                case 127: {
                    n4 = 156;
                    break;
                }
                case 128: {
                    n4 = 55;
                    break;
                }
                case 129: {
                    n4 = 16;
                    break;
                }
                case 130: {
                    n4 = 158;
                    break;
                }
                case 131: {
                    n4 = 68;
                    break;
                }
                case 132: {
                    n4 = 190;
                    break;
                }
                case 133: {
                    n4 = 10;
                    break;
                }
                case 134: {
                    n4 = 233;
                    break;
                }
                case 135: {
                    n4 = 216;
                    break;
                }
                case 136: {
                    n4 = 46;
                    break;
                }
                case 137: {
                    n4 = 136;
                    break;
                }
                case 138: {
                    n4 = 74;
                    break;
                }
                case 139: {
                    n4 = 194;
                    break;
                }
                case 140: {
                    n4 = 25;
                    break;
                }
                case 141: {
                    n4 = 113;
                    break;
                }
                case 142: {
                    n4 = 226;
                    break;
                }
                case 143: {
                    n4 = 152;
                    break;
                }
                case 144: {
                    n4 = 78;
                    break;
                }
                case 145: {
                    n4 = 103;
                    break;
                }
                case 146: {
                    n4 = 150;
                    break;
                }
                case 147: {
                    n4 = 179;
                    break;
                }
                case 148: {
                    n4 = 102;
                    break;
                }
                case 149: {
                    n4 = 137;
                    break;
                }
                case 150: {
                    n4 = 21;
                    break;
                }
                case 151: {
                    n4 = 252;
                    break;
                }
                case 152: {
                    n4 = 187;
                    break;
                }
                case 153: {
                    n4 = 239;
                    break;
                }
                case 154: {
                    n4 = 206;
                    break;
                }
                case 155: {
                    n4 = 212;
                    break;
                }
                case 156: {
                    n4 = 232;
                    break;
                }
                case 157: {
                    n4 = 169;
                    break;
                }
                case 158: {
                    n4 = 54;
                    break;
                }
                case 159: {
                    n4 = 76;
                    break;
                }
                case 160: {
                    n4 = 27;
                    break;
                }
                case 161: {
                    n4 = 31;
                    break;
                }
                case 162: {
                    n4 = 91;
                    break;
                }
                case 163: {
                    n4 = 47;
                    break;
                }
                case 164: {
                    n4 = 89;
                    break;
                }
                case 165: {
                    n4 = 186;
                    break;
                }
                case 166: {
                    n4 = 221;
                    break;
                }
                case 167: {
                    n4 = 173;
                    break;
                }
                case 168: {
                    n4 = 20;
                    break;
                }
                case 169: {
                    n4 = 2;
                    break;
                }
                case 170: {
                    n4 = 235;
                    break;
                }
                case 171: {
                    n4 = 162;
                    break;
                }
                case 172: {
                    n4 = 81;
                    break;
                }
                case 173: {
                    n4 = 6;
                    break;
                }
                case 174: {
                    n4 = 12;
                    break;
                }
                case 175: {
                    n4 = 143;
                    break;
                }
                case 176: {
                    n4 = 30;
                    break;
                }
                case 177: {
                    n4 = 116;
                    break;
                }
                case 178: {
                    n4 = 139;
                    break;
                }
                case 179: {
                    n4 = 177;
                    break;
                }
                case 180: {
                    n4 = 215;
                    break;
                }
                case 181: {
                    n4 = 96;
                    break;
                }
                case 182: {
                    n4 = 196;
                    break;
                }
                case 183: {
                    n4 = 171;
                    break;
                }
                case 184: {
                    n4 = 166;
                    break;
                }
                case 185: {
                    n4 = 24;
                    break;
                }
                case 186: {
                    n4 = 70;
                    break;
                }
                case 187: {
                    n4 = 203;
                    break;
                }
                case 188: {
                    n4 = 38;
                    break;
                }
                case 189: {
                    n4 = 201;
                    break;
                }
                case 190: {
                    n4 = 242;
                    break;
                }
                case 191: {
                    n4 = 7;
                    break;
                }
                case 192: {
                    n4 = 44;
                    break;
                }
                case 193: {
                    n4 = 41;
                    break;
                }
                case 194: {
                    n4 = 127;
                    break;
                }
                case 195: {
                    n4 = 61;
                    break;
                }
                case 196: {
                    n4 = 26;
                    break;
                }
                case 197: {
                    n4 = 164;
                    break;
                }
                case 198: {
                    n4 = 8;
                    break;
                }
                case 199: {
                    n4 = 129;
                    break;
                }
                case 200: {
                    n4 = 33;
                    break;
                }
                case 201: {
                    n4 = 77;
                    break;
                }
                case 202: {
                    n4 = 183;
                    break;
                }
                case 203: {
                    n4 = 140;
                    break;
                }
                case 204: {
                    n4 = 15;
                    break;
                }
                case 205: {
                    n4 = 223;
                    break;
                }
                case 206: {
                    n4 = 22;
                    break;
                }
                case 207: {
                    n4 = 219;
                    break;
                }
                case 208: {
                    n4 = 144;
                    break;
                }
                case 209: {
                    n4 = 98;
                    break;
                }
                case 210: {
                    n4 = 118;
                    break;
                }
                case 211: {
                    n4 = 11;
                    break;
                }
                case 212: {
                    n4 = 197;
                    break;
                }
                case 213: {
                    n4 = 208;
                    break;
                }
                case 214: {
                    n4 = 104;
                    break;
                }
                case 215: {
                    n4 = 153;
                    break;
                }
                case 216: {
                    n4 = 120;
                    break;
                }
                case 217: {
                    n4 = 100;
                    break;
                }
                case 218: {
                    n4 = 255;
                    break;
                }
                case 219: {
                    n4 = 35;
                    break;
                }
                case 220: {
                    n4 = 176;
                    break;
                }
                case 221: {
                    n4 = 133;
                    break;
                }
                case 222: {
                    n4 = 161;
                    break;
                }
                case 223: {
                    n4 = 231;
                    break;
                }
                case 224: {
                    n4 = 168;
                    break;
                }
                case 225: {
                    n4 = 222;
                    break;
                }
                case 226: {
                    n4 = 125;
                    break;
                }
                case 227: {
                    n4 = 182;
                    break;
                }
                case 228: {
                    n4 = 86;
                    break;
                }
                case 229: {
                    n4 = 62;
                    break;
                }
                case 230: {
                    n4 = 88;
                    break;
                }
                case 231: {
                    n4 = 228;
                    break;
                }
                case 232: {
                    n4 = 134;
                    break;
                }
                case 233: {
                    n4 = 204;
                    break;
                }
                case 234: {
                    n4 = 45;
                    break;
                }
                case 235: {
                    n4 = 119;
                    break;
                }
                case 236: {
                    n4 = 250;
                    break;
                }
                case 237: {
                    n4 = 214;
                    break;
                }
                case 238: {
                    n4 = 248;
                    break;
                }
                case 239: {
                    n4 = 82;
                    break;
                }
                case 240: {
                    n4 = 49;
                    break;
                }
                case 241: {
                    n4 = 211;
                    break;
                }
                case 242: {
                    n4 = 110;
                    break;
                }
                case 243: {
                    n4 = 138;
                    break;
                }
                case 244: {
                    n4 = 84;
                    break;
                }
                case 245: {
                    n4 = 4;
                    break;
                }
                case 246: {
                    n4 = 198;
                    break;
                }
                case 247: {
                    n4 = 205;
                    break;
                }
                case 248: {
                    n4 = 121;
                    break;
                }
                case 249: {
                    n4 = 195;
                    break;
                }
                case 250: {
                    n4 = 254;
                    break;
                }
                case 251: {
                    n4 = 94;
                    break;
                }
                case 252: {
                    n4 = 64;
                    break;
                }
                case 253: {
                    n4 = 40;
                    break;
                }
                case 254: {
                    n4 = 193;
                    break;
                }
                default: {
                    n4 = 112;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < charArray.length; ++i) {
                final int n8 = i % 2;
                final char[] array = charArray;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ charArray[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ charArray[i]) & 0xFF);
                }
            }
            WindowUtils$X11WindowUtils.e[n3] = new String(charArray).intern();
        }
        return WindowUtils$X11WindowUtils.e[n3];
    }
}
