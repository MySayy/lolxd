// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import com.sun.jna.platform.unix.X11$Pixmap;
import com.sun.jna.platform.unix.X11$Window;
import com.sun.jna.platform.unix.X11$Display;

interface WindowUtils$X11WindowUtils$PixmapSource
{
    X11$Pixmap getPixmap(final X11$Display p0, final X11$Window p1);
}
