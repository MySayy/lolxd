// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.Window;

class WindowUtils$X11WindowUtils$3 implements Runnable
{
    final Window val$w;
    final boolean val$transparent;
    final WindowUtils$X11WindowUtils this$0;
    
    WindowUtils$X11WindowUtils$3(final WindowUtils$X11WindowUtils this$0, final Window val$w, final boolean val$transparent) {
        this.this$0 = this$0;
        this.val$w = val$w;
        this.val$transparent = val$transparent;
    }
    
    @Override
    public void run() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils$3.val$w:Ljava/awt/Window;
        //     4: checkcast       Ljavax/swing/RootPaneContainer;
        //     7: invokeinterface javax/swing/RootPaneContainer.getRootPane:()Ljavax/swing/JRootPane;
        //    12: astore_2       
        //    13: aload_2        
        //    14: invokevirtual   javax/swing/JRootPane.getLayeredPane:()Ljavax/swing/JLayeredPane;
        //    17: astore_3       
        //    18: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils.b:()[I
        //    21: aload_2        
        //    22: invokevirtual   javax/swing/JRootPane.getContentPane:()Ljava/awt/Container;
        //    25: astore          4
        //    27: astore_1       
        //    28: aload           4
        //    30: aload_1        
        //    31: ifnonnull       60
        //    34: instanceof      Lcom/sun/jna/platform/WindowUtils$X11WindowUtils$X11TransparentContentPane;
        //    37: aload_1        
        //    38: ifnonnull       96
        //    41: goto            48
        //    44: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils$3.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    47: athrow         
        //    48: ifeq            74
        //    51: goto            58
        //    54: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils$3.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    57: athrow         
        //    58: aload           4
        //    60: checkcast       Lcom/sun/jna/platform/WindowUtils$X11WindowUtils$X11TransparentContentPane;
        //    63: aload_0        
        //    64: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils$3.val$transparent:Z
        //    67: invokevirtual   com/sun/jna/platform/WindowUtils$X11WindowUtils$X11TransparentContentPane.setTransparent:(Z)V
        //    70: aload_1        
        //    71: ifnull          136
        //    74: aload_0        
        //    75: aload_1        
        //    76: ifnonnull       167
        //    79: goto            86
        //    82: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils$3.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    85: athrow         
        //    86: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils$3.val$transparent:Z
        //    89: goto            96
        //    92: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils$3.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    95: athrow         
        //    96: ifeq            136
        //    99: new             Lcom/sun/jna/platform/WindowUtils$X11WindowUtils$X11TransparentContentPane;
        //   102: dup            
        //   103: aload_0        
        //   104: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils$3.this$0:Lcom/sun/jna/platform/WindowUtils$X11WindowUtils;
        //   107: aload           4
        //   109: invokespecial   com/sun/jna/platform/WindowUtils$X11WindowUtils$X11TransparentContentPane.<init>:(Lcom/sun/jna/platform/WindowUtils$X11WindowUtils;Ljava/awt/Container;)V
        //   112: astore          5
        //   114: aload_2        
        //   115: aload           5
        //   117: invokevirtual   javax/swing/JRootPane.setContentPane:(Ljava/awt/Container;)V
        //   120: aload_3        
        //   121: new             Lcom/sun/jna/platform/WindowUtils$RepaintTrigger;
        //   124: dup            
        //   125: aload           5
        //   127: invokespecial   com/sun/jna/platform/WindowUtils$RepaintTrigger.<init>:(Ljavax/swing/JComponent;)V
        //   130: getstatic       javax/swing/JLayeredPane.DRAG_LAYER:Ljava/lang/Integer;
        //   133: invokevirtual   javax/swing/JLayeredPane.add:(Ljava/awt/Component;Ljava/lang/Object;)V
        //   136: aload_0        
        //   137: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils$3.this$0:Lcom/sun/jna/platform/WindowUtils$X11WindowUtils;
        //   140: aload_0        
        //   141: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils$3.val$w:Ljava/awt/Window;
        //   144: aload_0        
        //   145: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils$3.val$transparent:Z
        //   148: invokevirtual   com/sun/jna/platform/WindowUtils$X11WindowUtils.setLayersTransparent:(Ljava/awt/Window;Z)V
        //   151: aload_0        
        //   152: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils$3.this$0:Lcom/sun/jna/platform/WindowUtils$X11WindowUtils;
        //   155: aload_0        
        //   156: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils$3.val$w:Ljava/awt/Window;
        //   159: aload_0        
        //   160: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils$3.val$transparent:Z
        //   163: invokevirtual   com/sun/jna/platform/WindowUtils$X11WindowUtils.setForceHeavyweightPopups:(Ljava/awt/Window;Z)V
        //   166: aload_0        
        //   167: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils$3.this$0:Lcom/sun/jna/platform/WindowUtils$X11WindowUtils;
        //   170: aload_0        
        //   171: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils$3.val$w:Ljava/awt/Window;
        //   174: aload_0        
        //   175: getfield        com/sun/jna/platform/WindowUtils$X11WindowUtils$3.val$transparent:Z
        //   178: aload_1        
        //   179: ifnonnull       204
        //   182: aload_1        
        //   183: ifnonnull       204
        //   186: goto            193
        //   189: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils$3.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   192: athrow         
        //   193: ifne            207
        //   196: goto            203
        //   199: invokestatic    com/sun/jna/platform/WindowUtils$X11WindowUtils$3.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   202: athrow         
        //   203: iconst_1       
        //   204: goto            208
        //   207: iconst_0       
        //   208: invokevirtual   com/sun/jna/platform/WindowUtils$X11WindowUtils.setDoubleBuffered:(Ljava/awt/Component;Z)V
        //   211: return         
        //    StackMapTable: 00 13 FF 00 2C 00 05 07 00 14 07 00 67 07 00 26 07 00 27 07 00 28 00 01 07 00 62 43 01 45 07 00 62 03 41 07 00 28 0D 47 07 00 62 43 07 00 14 45 07 00 62 43 01 27 5E 07 00 14 55 07 00 62 FF 00 03 00 05 07 00 14 07 00 67 07 00 26 07 00 27 07 00 28 00 03 07 00 1C 07 00 29 01 45 07 00 62 FF 00 03 00 05 07 00 14 07 00 67 07 00 26 07 00 27 07 00 28 00 02 07 00 1C 07 00 29 FF 00 00 00 05 07 00 14 07 00 67 07 00 26 07 00 27 07 00 28 00 03 07 00 1C 07 00 29 01 FF 00 02 00 05 07 00 14 07 00 67 07 00 26 07 00 27 07 00 28 00 02 07 00 1C 07 00 29 FF 00 00 00 01 07 00 14 00 03 07 00 1C 07 00 29 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  28     41     44     48     Ljava/lang/RuntimeException;
        //  34     51     54     58     Ljava/lang/RuntimeException;
        //  60     79     82     86     Ljava/lang/RuntimeException;
        //  74     89     92     96     Ljava/lang/RuntimeException;
        //  167    186    189    193    Ljava/lang/RuntimeException;
        //  182    196    199    203    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0074:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
