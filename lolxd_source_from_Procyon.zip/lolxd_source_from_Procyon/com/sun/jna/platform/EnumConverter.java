// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import com.sun.jna.ToNativeContext;
import com.sun.jna.FromNativeContext;
import com.sun.jna.TypeConverter;

public class EnumConverter<T extends Enum<T>> implements TypeConverter
{
    private final Class<T> clazz;
    
    public EnumConverter(final Class<T> clazz) {
        this.clazz = clazz;
    }
    
    @Override
    public T fromNative(final Object o, final FromNativeContext fromNativeContext) {
        return this.clazz.getEnumConstants()[(int)o];
    }
    
    @Override
    public Integer toNative(final Object obj, final ToNativeContext toNativeContext) {
        return this.clazz.cast(obj).ordinal();
    }
    
    @Override
    public Class<Integer> nativeType() {
        return Integer.class;
    }
}
