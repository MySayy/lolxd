// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.Graphics;
import java.awt.AWTEvent;
import java.awt.Toolkit;
import java.awt.Container;
import java.awt.event.AWTEventListener;
import javax.swing.JPanel;

public abstract class WindowUtils$NativeWindowUtils$TransparentContentPane extends JPanel implements AWTEventListener
{
    private static final long serialVersionUID = 1L;
    private boolean transparent;
    final WindowUtils$NativeWindowUtils this$0;
    private static final String a;
    
    public WindowUtils$NativeWindowUtils$TransparentContentPane(final WindowUtils$NativeWindowUtils p0, final Container p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: aload_1        
        //     2: putfield        com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.this$0:Lcom/sun/jna/platform/WindowUtils$NativeWindowUtils;
        //     5: aload_0        
        //     6: new             Ljava/awt/BorderLayout;
        //     9: dup            
        //    10: invokespecial   java/awt/BorderLayout.<init>:()V
        //    13: invokespecial   javax/swing/JPanel.<init>:(Ljava/awt/LayoutManager;)V
        //    16: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils.b:()[I
        //    19: aload_0        
        //    20: aload_2        
        //    21: getstatic       com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.a:Ljava/lang/String;
        //    24: invokevirtual   com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.add:(Ljava/awt/Component;Ljava/lang/Object;)V
        //    27: astore_3       
        //    28: aload_0        
        //    29: iconst_1       
        //    30: invokevirtual   com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.setTransparent:(Z)V
        //    33: aload_2        
        //    34: aload_3        
        //    35: ifnonnull       70
        //    38: aload_3        
        //    39: ifnonnull       70
        //    42: goto            49
        //    45: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    48: athrow         
        //    49: instanceof      Ljavax/swing/JPanel;
        //    52: ifeq            77
        //    55: goto            62
        //    58: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    61: athrow         
        //    62: aload_2        
        //    63: goto            70
        //    66: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    69: athrow         
        //    70: checkcast       Ljavax/swing/JComponent;
        //    73: iconst_0       
        //    74: invokevirtual   javax/swing/JComponent.setOpaque:(Z)V
        //    77: return         
        //    StackMapTable: 00 07 FF 00 2D 00 04 07 00 2D 07 00 37 07 00 3F 07 00 C9 00 01 07 00 B2 43 07 00 3F 48 07 00 B2 03 43 07 00 B2 43 07 00 3F 06
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  28     42     45     49     Ljava/lang/RuntimeException;
        //  38     55     58     62     Ljava/lang/RuntimeException;
        //  49     63     66     70     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0049:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void addNotify() {
        super.addNotify();
        Toolkit.getDefaultToolkit().addAWTEventListener(this, 2L);
    }
    
    @Override
    public void removeNotify() {
        Toolkit.getDefaultToolkit().removeAWTEventListener(this);
        super.removeNotify();
    }
    
    public void setTransparent(final boolean transparent) {
        final int[] b = WindowUtils$NativeWindowUtils.b();
        this.transparent = transparent;
        final int[] array = b;
        boolean doubleBuffered = false;
        Label_0076: {
            Label_0075: {
                Label_0072: {
                    Label_0061: {
                        Label_0041: {
                            Label_0040: {
                                Label_0037: {
                                    Label_0026: {
                                        try {
                                            final boolean opaque = transparent;
                                            if (array != null) {
                                                break Label_0037;
                                            }
                                            final int[] array2 = array;
                                            if (array2 == null) {
                                                break Label_0026;
                                            }
                                            break Label_0037;
                                        }
                                        catch (RuntimeException ex) {
                                            throw b(ex);
                                        }
                                        try {
                                            final int[] array2 = array;
                                            if (array2 != null) {
                                                break Label_0037;
                                            }
                                            if (transparent) {
                                                break Label_0040;
                                            }
                                        }
                                        catch (RuntimeException ex2) {
                                            throw b(ex2);
                                        }
                                    }
                                    final boolean opaque = true;
                                }
                                break Label_0041;
                            }
                            final boolean opaque = false;
                            try {
                                this.setOpaque(opaque);
                                doubleBuffered = transparent;
                                if (array != null) {
                                    break Label_0072;
                                }
                                final int[] array3 = array;
                                if (array3 == null) {
                                    break Label_0061;
                                }
                                break Label_0072;
                            }
                            catch (RuntimeException ex3) {
                                throw b(ex3);
                            }
                        }
                        try {
                            final int[] array3 = array;
                            if (array3 != null) {
                                break Label_0072;
                            }
                            if (transparent) {
                                break Label_0075;
                            }
                        }
                        catch (RuntimeException ex4) {
                            throw b(ex4);
                        }
                    }
                    doubleBuffered = true;
                }
                break Label_0076;
            }
            doubleBuffered = false;
        }
        this.setDoubleBuffered(doubleBuffered);
        this.repaint();
    }
    
    @Override
    public void eventDispatched(final AWTEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_1        
        //     5: invokevirtual   java/awt/AWTEvent.getID:()I
        //     8: aload_2        
        //     9: ifnonnull       76
        //    12: aload_2        
        //    13: ifnonnull       76
        //    16: goto            23
        //    19: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    22: athrow         
        //    23: sipush          300
        //    26: if_icmpne       103
        //    29: goto            36
        //    32: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    35: athrow         
        //    36: aload_1        
        //    37: checkcast       Ljava/awt/event/ContainerEvent;
        //    40: invokevirtual   java/awt/event/ContainerEvent.getChild:()Ljava/awt/Component;
        //    43: aload_2        
        //    44: ifnonnull       93
        //    47: goto            54
        //    50: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    53: athrow         
        //    54: aload_2        
        //    55: ifnonnull       93
        //    58: goto            65
        //    61: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    64: athrow         
        //    65: aload_0        
        //    66: invokestatic    javax/swing/SwingUtilities.isDescendingFrom:(Ljava/awt/Component;Ljava/awt/Component;)Z
        //    69: goto            76
        //    72: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    75: athrow         
        //    76: ifeq            103
        //    79: aload_1        
        //    80: checkcast       Ljava/awt/event/ContainerEvent;
        //    83: invokevirtual   java/awt/event/ContainerEvent.getChild:()Ljava/awt/Component;
        //    86: goto            93
        //    89: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    92: athrow         
        //    93: astore_3       
        //    94: aload_0        
        //    95: getfield        com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.this$0:Lcom/sun/jna/platform/WindowUtils$NativeWindowUtils;
        //    98: aload_3        
        //    99: iconst_0       
        //   100: invokevirtual   com/sun/jna/platform/WindowUtils$NativeWindowUtils.setDoubleBuffered:(Ljava/awt/Component;Z)V
        //   103: return         
        //    StackMapTable: 00 0D FF 00 13 00 03 07 00 2D 07 00 0D 07 00 C9 00 01 07 00 B2 43 01 48 07 00 B2 03 4D 07 00 B2 43 07 00 CB 46 07 00 B2 43 07 00 CB 46 07 00 B2 43 01 4C 07 00 B2 43 07 00 CB 09
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      16     19     23     Ljava/lang/RuntimeException;
        //  12     29     32     36     Ljava/lang/RuntimeException;
        //  23     47     50     54     Ljava/lang/RuntimeException;
        //  36     58     61     65     Ljava/lang/RuntimeException;
        //  54     69     72     76     Ljava/lang/RuntimeException;
        //  76     86     89     93     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0023:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void paint(final Graphics p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_0        
        //     5: aload_2        
        //     6: ifnonnull       179
        //     9: getfield        com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.transparent:Z
        //    12: ifeq            171
        //    15: goto            22
        //    18: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    21: athrow         
        //    22: aload_1        
        //    23: invokevirtual   java/awt/Graphics.getClipBounds:()Ljava/awt/Rectangle;
        //    26: astore_3       
        //    27: aload_3        
        //    28: getfield        java/awt/Rectangle.width:I
        //    31: istore          4
        //    33: aload_3        
        //    34: getfield        java/awt/Rectangle.height:I
        //    37: istore          5
        //    39: aload_0        
        //    40: invokevirtual   com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.getWidth:()I
        //    43: aload_2        
        //    44: ifnonnull       79
        //    47: aload_2        
        //    48: ifnonnull       79
        //    51: goto            58
        //    54: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    57: athrow         
        //    58: ifle            167
        //    61: goto            68
        //    64: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    67: athrow         
        //    68: aload_0        
        //    69: invokevirtual   com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.getHeight:()I
        //    72: goto            79
        //    75: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    78: athrow         
        //    79: ifle            167
        //    82: new             Ljava/awt/image/BufferedImage;
        //    85: dup            
        //    86: iload           4
        //    88: iload           5
        //    90: iconst_3       
        //    91: invokespecial   java/awt/image/BufferedImage.<init>:(III)V
        //    94: astore          6
        //    96: aload           6
        //    98: invokevirtual   java/awt/image/BufferedImage.createGraphics:()Ljava/awt/Graphics2D;
        //   101: astore          7
        //   103: aload           7
        //   105: getstatic       java/awt/AlphaComposite.Clear:Ljava/awt/AlphaComposite;
        //   108: invokevirtual   java/awt/Graphics2D.setComposite:(Ljava/awt/Composite;)V
        //   111: aload           7
        //   113: iconst_0       
        //   114: iconst_0       
        //   115: iload           4
        //   117: iload           5
        //   119: invokevirtual   java/awt/Graphics2D.fillRect:(IIII)V
        //   122: aload           7
        //   124: invokevirtual   java/awt/Graphics2D.dispose:()V
        //   127: aload           6
        //   129: invokevirtual   java/awt/image/BufferedImage.createGraphics:()Ljava/awt/Graphics2D;
        //   132: astore          7
        //   134: aload           7
        //   136: aload_3        
        //   137: getfield        java/awt/Rectangle.x:I
        //   140: ineg           
        //   141: aload_3        
        //   142: getfield        java/awt/Rectangle.y:I
        //   145: ineg           
        //   146: invokevirtual   java/awt/Graphics2D.translate:(II)V
        //   149: aload_0        
        //   150: aload           7
        //   152: invokespecial   javax/swing/JPanel.paint:(Ljava/awt/Graphics;)V
        //   155: aload           7
        //   157: invokevirtual   java/awt/Graphics2D.dispose:()V
        //   160: aload_0        
        //   161: aload           6
        //   163: aload_3        
        //   164: invokevirtual   com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.paintDirect:(Ljava/awt/image/BufferedImage;Ljava/awt/Rectangle;)V
        //   167: aload_2        
        //   168: ifnull          183
        //   171: aload_0        
        //   172: goto            179
        //   175: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils$TransparentContentPane.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   178: athrow         
        //   179: aload_1        
        //   180: invokespecial   javax/swing/JPanel.paint:(Ljava/awt/Graphics;)V
        //   183: return         
        //    StackMapTable: 00 0D FF 00 12 00 03 07 00 2D 07 00 68 07 00 C9 00 01 07 00 B2 03 FF 00 1F 00 06 07 00 2D 07 00 68 07 00 C9 07 00 6A 01 01 00 01 07 00 B2 43 01 45 07 00 B2 03 46 07 00 B2 43 01 FB 00 57 F8 00 03 43 07 00 B2 43 07 00 2D 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      15     18     22     Ljava/lang/RuntimeException;
        //  39     51     54     58     Ljava/lang/RuntimeException;
        //  47     61     64     68     Ljava/lang/RuntimeException;
        //  58     72     75     79     Ljava/lang/RuntimeException;
        //  167    172    175    179    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0058:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    protected abstract void paintDirect(final BufferedImage p0, final Rectangle p1);
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 3);
        final char[] charArray = "RjzhZ7".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 18;
                            break;
                        }
                        case 1: {
                            n5 = 12;
                            break;
                        }
                        case 2: {
                            n5 = 23;
                            break;
                        }
                        case 3: {
                            n5 = 31;
                            break;
                        }
                        case 4: {
                            n5 = 60;
                            break;
                        }
                        case 5: {
                            n5 = 70;
                            break;
                        }
                        default: {
                            n5 = 71;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
