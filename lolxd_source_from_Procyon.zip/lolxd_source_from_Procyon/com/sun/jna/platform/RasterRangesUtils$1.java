// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.Rectangle;
import java.util.Comparator;

final class RasterRangesUtils$1 implements Comparator<Object>
{
    @Override
    public int compare(final Object o, final Object o2) {
        return ((Rectangle)o).x - ((Rectangle)o2).x;
    }
}
