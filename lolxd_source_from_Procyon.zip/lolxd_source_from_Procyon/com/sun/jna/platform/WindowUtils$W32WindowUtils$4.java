// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import com.sun.jna.platform.win32.GDI32;
import com.sun.jna.platform.win32.WinDef$HRGN;

class WindowUtils$W32WindowUtils$4 implements RasterRangesUtils$RangesOutput
{
    final WinDef$HRGN val$tempRgn;
    final WinDef$HRGN val$region;
    final WindowUtils$W32WindowUtils this$0;
    
    WindowUtils$W32WindowUtils$4(final WindowUtils$W32WindowUtils this$0, final WinDef$HRGN val$tempRgn, final WinDef$HRGN val$region) {
        this.this$0 = this$0;
        this.val$tempRgn = val$tempRgn;
        this.val$region = val$region;
    }
    
    @Override
    public boolean outputRange(final int n, final int n2, final int n3, final int n4) {
        final GDI32 instance = GDI32.INSTANCE;
        final int[] b = WindowUtils$NativeWindowUtils.b();
        instance.SetRectRgn(this.val$tempRgn, n, n2, n + n3, n2 + n4);
        final int[] array = b;
        int combineRgn = 0;
        Label_0082: {
            Label_0068: {
                try {
                    combineRgn = instance.CombineRgn(this.val$region, this.val$region, this.val$tempRgn, 2);
                    if (array != null) {
                        return combineRgn != 0;
                    }
                    final int[] array2 = array;
                    if (array2 == null) {
                        break Label_0068;
                    }
                    return combineRgn != 0;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final int[] array2 = array;
                    if (array2 != null) {
                        return combineRgn != 0;
                    }
                    if (combineRgn == 0) {
                        break Label_0082;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            return combineRgn != 0;
        }
        return combineRgn != 0;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
