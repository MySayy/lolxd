// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.io.File;
import java.util.EventObject;

public class FileMonitor$FileEvent extends EventObject
{
    private final File file;
    private final int type;
    final FileMonitor this$0;
    private static final String a;
    
    public FileMonitor$FileEvent(final FileMonitor this$0, final File file, final int type) {
        super(this.this$0 = this$0);
        this.file = file;
        this.type = type;
    }
    
    public File getFile() {
        return this.file;
    }
    
    public int getType() {
        return this.type;
    }
    
    @Override
    public String toString() {
        return FileMonitor$FileEvent.a + this.file + ":" + this.type;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 15);
        final char[] charArray = ">C\f+\u0014\u0001\u0003\u0016^Zn".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 119;
                            break;
                        }
                        case 1: {
                            n5 = 37;
                            break;
                        }
                        case 2: {
                            n5 = 111;
                            break;
                        }
                        case 3: {
                            n5 = 65;
                            break;
                        }
                        case 4: {
                            n5 = 94;
                            break;
                        }
                        case 5: {
                            n5 = 120;
                            break;
                        }
                        default: {
                            n5 = 105;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
