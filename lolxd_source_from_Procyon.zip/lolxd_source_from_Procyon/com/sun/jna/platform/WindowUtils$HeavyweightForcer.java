// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.Rectangle;
import java.awt.Window;

class WindowUtils$HeavyweightForcer extends Window
{
    private static final long serialVersionUID = 1L;
    private final boolean packed;
    
    public WindowUtils$HeavyweightForcer(final Window owner) {
        super(owner);
        this.pack();
        this.packed = true;
    }
    
    @Override
    public boolean isVisible() {
        return this.packed;
    }
    
    @Override
    public Rectangle getBounds() {
        return this.getOwner().getBounds();
    }
}
