// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import com.sun.jna.platform.win32.WinDef$HWND;
import com.sun.jna.platform.win32.WinUser$SIZE;
import com.sun.jna.platform.win32.WinDef$POINT;
import com.sun.jna.platform.win32.WinDef$HDC;
import com.sun.jna.platform.win32.WinUser$BLENDFUNCTION;
import com.sun.jna.platform.win32.User32;
import java.awt.Component;
import java.awt.Window;

class WindowUtils$W32WindowUtils$1 implements Runnable
{
    final Window val$w;
    final float val$alpha;
    final WindowUtils$W32WindowUtils this$0;
    
    WindowUtils$W32WindowUtils$1(final WindowUtils$W32WindowUtils this$0, final Window val$w, final float val$alpha) {
        this.this$0 = this$0;
        this.val$w = val$w;
        this.val$alpha = val$alpha;
    }
    
    @Override
    public void run() {
        final WinDef$HWND access$400 = WindowUtils$W32WindowUtils.access$400(this.this$0, this.val$w);
        final User32 instance = User32.INSTANCE;
        final int[] b = WindowUtils$NativeWindowUtils.b();
        int getWindowLong = instance.GetWindowLong(access$400, -20);
        final int[] array = b;
        final byte sourceConstantAlpha = (byte)((int)(255.0f * this.val$alpha) & 0xFF);
        WindowUtils$W32WindowUtils this$0 = null;
        Window val$w = null;
        float n = 0.0f;
        Label_0242: {
            Label_0228: {
                Label_0199: {
                    Label_0198: {
                        while (true) {
                            Label_0164: {
                                Label_0127: {
                                    float access$401 = 0.0f;
                                    Label_0114: {
                                        try {
                                            final boolean b2 = (access$401 = (WindowUtils$W32WindowUtils.access$500(this.this$0, this.val$w) ? 1 : 0)) != 0.0f;
                                            if (array != null) {
                                                break Label_0127;
                                            }
                                            if (!b2) {
                                                break Label_0114;
                                            }
                                        }
                                        catch (RuntimeException ex) {
                                            throw b(ex);
                                        }
                                        final WinUser$BLENDFUNCTION winUser$BLENDFUNCTION = new WinUser$BLENDFUNCTION();
                                        try {
                                            winUser$BLENDFUNCTION.SourceConstantAlpha = sourceConstantAlpha;
                                            winUser$BLENDFUNCTION.AlphaFormat = 1;
                                            instance.UpdateLayeredWindow(access$400, null, null, null, null, null, 0, winUser$BLENDFUNCTION, 2);
                                            if (array == null) {
                                                break Label_0199;
                                            }
                                            access$401 = fcmpl(this.val$alpha, 1.0f);
                                        }
                                        catch (RuntimeException ex2) {
                                            throw b(ex2);
                                        }
                                    }
                                    try {
                                        if (array != null) {
                                            break Label_0198;
                                        }
                                        if (access$401 != 0) {
                                            break Label_0164;
                                        }
                                    }
                                    catch (RuntimeException ex3) {
                                        throw b(ex3);
                                    }
                                }
                                getWindowLong &= 0xFFF7FFFF;
                                instance.SetWindowLong(access$400, -20, getWindowLong);
                                if (array == null) {
                                    break Label_0199;
                                }
                            }
                            getWindowLong |= 0x80000;
                            instance.SetWindowLong(access$400, -20, getWindowLong);
                            instance.SetLayeredWindowAttributes(access$400, 0, sourceConstantAlpha, 2);
                            if (array != null) {
                                continue;
                            }
                            break;
                        }
                    }
                    try {
                        this$0 = this.this$0;
                        val$w = this.val$w;
                        n = fcmpl(this.val$alpha, 1.0f);
                        if (array != null) {
                            break Label_0228;
                        }
                        final int[] array2 = array;
                        if (array2 == null) {
                            break Label_0228;
                        }
                        break Label_0228;
                    }
                    catch (RuntimeException ex4) {
                        throw b(ex4);
                    }
                }
                try {
                    final int[] array2 = array;
                    if (array2 != null) {
                        break Label_0228;
                    }
                    if (n == 0) {
                        break Label_0242;
                    }
                }
                catch (RuntimeException ex5) {
                    throw b(ex5);
                }
            }
            break Label_0242;
        }
        this$0.setForceHeavyweightPopups(val$w, (boolean)(n != 0.0f));
        WindowUtils$W32WindowUtils.access$600(this.this$0, this.val$w, sourceConstantAlpha);
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
