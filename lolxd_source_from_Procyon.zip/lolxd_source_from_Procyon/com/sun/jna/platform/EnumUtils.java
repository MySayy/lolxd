// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.util.Iterator;
import java.util.Set;
import com.sun.jna.platform.win32.FlagEnum;

public class EnumUtils
{
    public static final int UNINITIALIZED = -1;
    
    public static <E extends Enum<E>> int toInteger(final E e) {
        final int[] b = WindowUtils$NativeWindowUtils.b();
        final Enum[] array = (Enum[])e.getClass().getEnumConstants();
        final int[] array2 = b;
        int i = 0;
        while (i < array.length) {
            try {
                if (array[i] == e) {
                    return i;
                }
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            ++i;
            if (array2 != null) {
                break;
            }
        }
        throw new IllegalArgumentException();
    }
    
    public static <E extends Enum<E>> E fromInteger(final int n, final Class<E> clazz) {
        try {
            if (n == -1) {
                return null;
            }
        }
        catch (IllegalArgumentException ex) {
            throw b(ex);
        }
        return clazz.getEnumConstants()[n];
    }
    
    public static <T extends FlagEnum> Set<T> setFromInteger(final int p0, final Class<T> p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokevirtual   java/lang/Class.getEnumConstants:()[Ljava/lang/Object;
        //     4: checkcast       [Lcom/sun/jna/platform/win32/FlagEnum;
        //     7: astore_3       
        //     8: invokestatic    com/sun/jna/platform/WindowUtils$NativeWindowUtils.b:()[I
        //    11: new             Ljava/util/HashSet;
        //    14: dup            
        //    15: invokespecial   java/util/HashSet.<init>:()V
        //    18: astore          4
        //    20: astore_2       
        //    21: aload_3        
        //    22: astore          5
        //    24: aload           5
        //    26: arraylength    
        //    27: istore          6
        //    29: iconst_0       
        //    30: istore          7
        //    32: iload           7
        //    34: iload           6
        //    36: if_icmpge       104
        //    39: aload           5
        //    41: iload           7
        //    43: aaload         
        //    44: astore          8
        //    46: aload_2        
        //    47: ifnonnull       100
        //    50: iload_0        
        //    51: aload           8
        //    53: invokeinterface com/sun/jna/platform/win32/FlagEnum.getFlag:()I
        //    58: iand           
        //    59: aload_2        
        //    60: ifnonnull       96
        //    63: goto            70
        //    66: invokestatic    com/sun/jna/platform/EnumUtils.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    69: athrow         
        //    70: ifeq            97
        //    73: goto            80
        //    76: invokestatic    com/sun/jna/platform/EnumUtils.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    79: athrow         
        //    80: aload           4
        //    82: aload           8
        //    84: invokeinterface java/util/Set.add:(Ljava/lang/Object;)Z
        //    89: goto            96
        //    92: invokestatic    com/sun/jna/platform/EnumUtils.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    95: athrow         
        //    96: pop            
        //    97: iinc            7, 1
        //   100: aload_2        
        //   101: ifnull          32
        //   104: aload           4
        //   106: areturn        
        //    Signature:
        //  <T::Lcom/sun/jna/platform/win32/FlagEnum;>(ILjava/lang/Class<TT;>;)Ljava/util/Set<TT;>;
        //    StackMapTable: 00 0A FF 00 20 00 08 01 07 00 27 07 00 57 07 00 08 07 00 09 07 00 08 01 01 00 00 FF 00 21 00 09 01 07 00 27 07 00 57 07 00 08 07 00 09 07 00 08 01 01 07 00 10 00 01 07 00 05 43 01 45 07 00 05 03 4B 07 00 05 43 01 00 02 FA 00 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  46     63     66     70     Ljava/lang/IllegalArgumentException;
        //  50     73     76     80     Ljava/lang/IllegalArgumentException;
        //  70     89     92     96     Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0070:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static <T extends FlagEnum> int setToInteger(final Set<T> set) {
        int n = 0;
        final int[] b = WindowUtils$NativeWindowUtils.b();
        final Iterator<T> iterator = set.iterator();
        final int[] array = b;
        int n2 = 0;
        while (iterator.hasNext()) {
            n2 = (n | iterator.next().getFlag());
            if (array != null) {
                return n2;
            }
            n = n2;
            if (array != null) {
                break;
            }
        }
        return n2;
    }
    
    private static IllegalArgumentException b(final IllegalArgumentException ex) {
        return ex;
    }
}
