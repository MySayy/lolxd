// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.Rectangle;
import java.util.List;

final class WindowUtils$X11WindowUtils$1 implements RasterRangesUtils$RangesOutput
{
    final List val$rlist;
    
    WindowUtils$X11WindowUtils$1(final List val$rlist) {
        this.val$rlist = val$rlist;
    }
    
    @Override
    public boolean outputRange(final int x, final int y, final int width, final int height) {
        this.val$rlist.add(new Rectangle(x, y, width, height));
        return true;
    }
}
