// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import com.sun.jna.platform.win32.User32;
import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.WinDef$HWND;
import java.util.List;
import com.sun.jna.platform.win32.WinUser$WNDENUMPROC;

class WindowUtils$W32WindowUtils$5 implements WinUser$WNDENUMPROC
{
    final boolean val$onlyVisibleWindows;
    final List val$result;
    final WindowUtils$W32WindowUtils this$0;
    
    WindowUtils$W32WindowUtils$5(final WindowUtils$W32WindowUtils this$0, final boolean val$onlyVisibleWindows, final List val$result) {
        this.this$0 = this$0;
        this.val$onlyVisibleWindows = val$onlyVisibleWindows;
        this.val$result = val$result;
    }
    
    @Override
    public boolean callback(final WinDef$HWND winDef$HWND, final Pointer pointer) {
        final int[] b = WindowUtils$NativeWindowUtils.b();
        try {
            boolean val$onlyVisibleWindows = false;
            Label_0068: {
                Label_0071: {
                    Label_0056: {
                        boolean isWindowVisible = false;
                        Label_0022: {
                            boolean b2;
                            try {
                                b2 = (val$onlyVisibleWindows = this.val$onlyVisibleWindows);
                                if (b != null) {
                                    break Label_0068;
                                }
                                if (b2) {
                                    break Label_0022;
                                }
                                break Label_0056;
                            }
                            catch (Exception ex) {
                                throw b(ex);
                            }
                            try {
                                if (!b2) {
                                    break Label_0056;
                                }
                                val$onlyVisibleWindows = (isWindowVisible = User32.INSTANCE.IsWindowVisible(winDef$HWND));
                            }
                            catch (Exception ex2) {
                                throw b(ex2);
                            }
                        }
                        while (true) {
                            if (b != null) {
                                break Label_0068;
                            }
                            try {
                                if (b != null) {
                                    break Label_0068;
                                }
                                if (isWindowVisible) {
                                    break Label_0056;
                                }
                                break Label_0071;
                            }
                            catch (Exception ex3) {
                                throw b(ex3);
                            }
                            try {
                                if (!isWindowVisible) {
                                    break Label_0071;
                                }
                                val$onlyVisibleWindows = (isWindowVisible = true);
                                if (b != null) {
                                    continue;
                                }
                            }
                            catch (Exception ex4) {
                                throw b(ex4);
                            }
                            break;
                        }
                    }
                    break Label_0068;
                }
                val$onlyVisibleWindows = false;
            }
            if (val$onlyVisibleWindows) {
                this.val$result.add(new DesktopWindow(winDef$HWND, this.this$0.getWindowTitle(winDef$HWND), this.this$0.getProcessFilePath(winDef$HWND), this.this$0.getWindowLocationAndSize(winDef$HWND)));
            }
        }
        catch (Exception ex5) {
            ex5.printStackTrace();
        }
        return true;
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
}
