// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.FromNativeContext;
import com.sun.jna.NativeLong;

public class X11$VisualID extends NativeLong
{
    private static final long serialVersionUID = 1L;
    public static final X11$VisualID None;
    
    public X11$VisualID() {
        this(0L);
    }
    
    public X11$VisualID(final long n) {
        super(n, true);
    }
    
    protected boolean isNone(final Object p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_1        
        //     5: aload_2        
        //     6: ifnull          20
        //     9: ifnull          82
        //    12: goto            19
        //    15: invokestatic    com/sun/jna/platform/unix/X11$VisualID.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    18: athrow         
        //    19: aload_1        
        //    20: instanceof      Ljava/lang/Number;
        //    23: aload_2        
        //    24: ifnull          57
        //    27: aload_2        
        //    28: ifnull          61
        //    31: ifeq            97
        //    34: goto            41
        //    37: invokestatic    com/sun/jna/platform/unix/X11$VisualID.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    40: athrow         
        //    41: aload_1        
        //    42: checkcast       Ljava/lang/Number;
        //    45: invokevirtual   java/lang/Number.longValue:()J
        //    48: lconst_0       
        //    49: lcmp           
        //    50: goto            57
        //    53: invokestatic    com/sun/jna/platform/unix/X11$VisualID.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    56: athrow         
        //    57: aload_2        
        //    58: ifnull          94
        //    61: aload_2        
        //    62: ifnull          94
        //    65: goto            72
        //    68: invokestatic    com/sun/jna/platform/unix/X11$VisualID.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    71: athrow         
        //    72: ifne            97
        //    75: goto            82
        //    78: invokestatic    com/sun/jna/platform/unix/X11$VisualID.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    81: athrow         
        //    82: iconst_1       
        //    83: aload_2        
        //    84: ifnull          23
        //    87: goto            94
        //    90: invokestatic    com/sun/jna/platform/unix/X11$VisualID.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    93: athrow         
        //    94: goto            98
        //    97: iconst_0       
        //    98: ireturn        
        //    StackMapTable: 00 11 FF 00 0F 00 03 07 00 08 07 00 34 07 00 36 00 01 07 00 2F 03 40 07 00 34 42 01 4D 07 00 2F 03 4B 07 00 2F 43 01 43 01 46 07 00 2F 43 01 45 07 00 2F 03 47 07 00 2F 43 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      12     15     19     Ljava/lang/RuntimeException;
        //  27     34     37     41     Ljava/lang/RuntimeException;
        //  31     50     53     57     Ljava/lang/RuntimeException;
        //  57     65     68     72     Ljava/lang/RuntimeException;
        //  61     75     78     82     Ljava/lang/RuntimeException;
        //  72     87     90     94     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0061:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public Object fromNative(final Object o, final FromNativeContext fromNativeContext) {
        final String b = X11$XID.b();
        Label_0034: {
            X11$VisualID none = null;
            Label_0023: {
                try {
                    final X11$VisualID x11$VisualID = this;
                    if (b == null) {
                        return x11$VisualID;
                    }
                    final Object o2 = o;
                    final boolean b2 = this.isNone(o2);
                    if (b2) {
                        break Label_0023;
                    }
                    break Label_0034;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final Object o2 = o;
                    final boolean b2 = this.isNone(o2);
                    if (!b2) {
                        break Label_0034;
                    }
                    none = X11$VisualID.None;
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            return none;
        }
        X11$VisualID none;
        final X11$VisualID x11$VisualID = none = new X11$VisualID(((Number)o).longValue());
        if (b == null) {
            return none;
        }
        return x11$VisualID;
    }
    
    static {
        None = null;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
