// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import java.util.List;
import com.sun.jna.Structure;

public class X11$Xrender$XRenderPictFormat extends Structure
{
    public static final List<String> FIELDS;
    public X11$Xrender$PictFormat id;
    public int type;
    public int depth;
    public X11$Xrender$XRenderDirectFormat direct;
    public X11$Colormap colormap;
    
    @Override
    protected List<String> getFieldOrder() {
        return X11$Xrender$XRenderPictFormat.FIELDS;
    }
    
    static {
        final String[] array = new String[5];
        int n = 0;
        String s;
        int n2 = (s = "'1\u0004:,}\u0016\b-:a\u001c\u0011j%>").length();
        int n3 = 2;
        int n4 = -1;
    Label_0022:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 72));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0252: {
                            if (length > 1) {
                                break Label_0252;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 6;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 29;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 69;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 59;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 43;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 79;
                                        break;
                                    }
                                    default: {
                                        n11 = 12;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0022;
                            }
                            n2 = (s = "XB\u000fuy\u0006XN\rdr\u0001").length();
                            n3 = 5;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0022;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 58)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[0], array2[1], array2[3], array2[4], array2[2]);
    }
}
