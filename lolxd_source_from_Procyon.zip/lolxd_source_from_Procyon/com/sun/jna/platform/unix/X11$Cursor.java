// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.FromNativeContext;

public class X11$Cursor extends X11$XID
{
    private static final long serialVersionUID = 1L;
    public static final X11$Cursor None;
    
    public X11$Cursor() {
    }
    
    public X11$Cursor(final long n) {
        super(n);
    }
    
    @Override
    public Object fromNative(final Object o, final FromNativeContext fromNativeContext) {
        final String b = X11$XID.b();
        Label_0034: {
            X11$Cursor none = null;
            Label_0023: {
                try {
                    final X11$Cursor x11$Cursor = this;
                    if (b == null) {
                        return x11$Cursor;
                    }
                    final Object o2 = o;
                    final boolean b2 = this.isNone(o2);
                    if (b2) {
                        break Label_0023;
                    }
                    break Label_0034;
                }
                catch (RuntimeException ex) {
                    throw c(ex);
                }
                try {
                    final Object o2 = o;
                    final boolean b2 = this.isNone(o2);
                    if (!b2) {
                        break Label_0034;
                    }
                    none = X11$Cursor.None;
                }
                catch (RuntimeException ex2) {
                    throw c(ex2);
                }
            }
            return none;
        }
        X11$Cursor none;
        final X11$Cursor x11$Cursor = none = new X11$Cursor(((Number)o).longValue());
        if (b == null) {
            return none;
        }
        return x11$Cursor;
    }
    
    static {
        None = null;
    }
    
    private static RuntimeException c(final RuntimeException ex) {
        return ex;
    }
}
