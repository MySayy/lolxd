// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.FromNativeContext;

public class X11$Window extends X11$Drawable
{
    private static final long serialVersionUID = 1L;
    public static final X11$Window None;
    
    public X11$Window() {
    }
    
    public X11$Window(final long n) {
        super(n);
    }
    
    @Override
    public Object fromNative(final Object o, final FromNativeContext fromNativeContext) {
        final String b = X11$XID.b();
        Label_0034: {
            X11$Window none = null;
            Label_0023: {
                try {
                    final X11$Window x11$Window = this;
                    if (b == null) {
                        return x11$Window;
                    }
                    final Object o2 = o;
                    final boolean b2 = this.isNone(o2);
                    if (b2) {
                        break Label_0023;
                    }
                    break Label_0034;
                }
                catch (RuntimeException ex) {
                    throw d(ex);
                }
                try {
                    final Object o2 = o;
                    final boolean b2 = this.isNone(o2);
                    if (!b2) {
                        break Label_0034;
                    }
                    none = X11$Window.None;
                }
                catch (RuntimeException ex2) {
                    throw d(ex2);
                }
            }
            return none;
        }
        X11$Window none;
        final X11$Window x11$Window = none = new X11$Window(((Number)o).longValue());
        if (b == null) {
            return none;
        }
        return x11$Window;
    }
    
    static {
        None = null;
    }
    
    private static RuntimeException d(final RuntimeException ex) {
        return ex;
    }
}
