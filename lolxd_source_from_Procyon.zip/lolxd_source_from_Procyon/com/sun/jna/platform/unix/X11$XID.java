// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.FromNativeContext;
import com.sun.jna.NativeLong;

public class X11$XID extends NativeLong
{
    private static final long serialVersionUID = 1L;
    public static final X11$XID None;
    private static String b;
    private static final String c;
    
    public X11$XID() {
        this(0L);
    }
    
    public X11$XID(final long n) {
        super(n, true);
    }
    
    protected boolean isNone(final Object p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_1        
        //     5: aload_2        
        //     6: ifnull          20
        //     9: ifnull          82
        //    12: goto            19
        //    15: invokestatic    com/sun/jna/platform/unix/X11$XID.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    18: athrow         
        //    19: aload_1        
        //    20: instanceof      Ljava/lang/Number;
        //    23: aload_2        
        //    24: ifnull          57
        //    27: aload_2        
        //    28: ifnull          61
        //    31: ifeq            97
        //    34: goto            41
        //    37: invokestatic    com/sun/jna/platform/unix/X11$XID.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    40: athrow         
        //    41: aload_1        
        //    42: checkcast       Ljava/lang/Number;
        //    45: invokevirtual   java/lang/Number.longValue:()J
        //    48: lconst_0       
        //    49: lcmp           
        //    50: goto            57
        //    53: invokestatic    com/sun/jna/platform/unix/X11$XID.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    56: athrow         
        //    57: aload_2        
        //    58: ifnull          94
        //    61: aload_2        
        //    62: ifnull          94
        //    65: goto            72
        //    68: invokestatic    com/sun/jna/platform/unix/X11$XID.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    71: athrow         
        //    72: ifne            97
        //    75: goto            82
        //    78: invokestatic    com/sun/jna/platform/unix/X11$XID.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    81: athrow         
        //    82: iconst_1       
        //    83: aload_2        
        //    84: ifnull          23
        //    87: goto            94
        //    90: invokestatic    com/sun/jna/platform/unix/X11$XID.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    93: athrow         
        //    94: goto            98
        //    97: iconst_0       
        //    98: ireturn        
        //    StackMapTable: 00 11 FF 00 0F 00 03 07 00 0A 07 00 5D 07 00 4E 00 01 07 00 46 03 40 07 00 5D 42 01 4D 07 00 46 03 4B 07 00 46 43 01 43 01 46 07 00 46 43 01 45 07 00 46 03 47 07 00 46 43 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      12     15     19     Ljava/lang/RuntimeException;
        //  27     34     37     41     Ljava/lang/RuntimeException;
        //  31     50     53     57     Ljava/lang/RuntimeException;
        //  57     65     68     72     Ljava/lang/RuntimeException;
        //  61     75     78     82     Ljava/lang/RuntimeException;
        //  72     87     90     94     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0061:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public Object fromNative(final Object o, final FromNativeContext fromNativeContext) {
        final String b = b();
        Label_0034: {
            X11$XID none = null;
            Label_0023: {
                try {
                    final X11$XID x11$XID = this;
                    if (b == null) {
                        return x11$XID;
                    }
                    final Object o2 = o;
                    final boolean b2 = this.isNone(o2);
                    if (b2) {
                        break Label_0023;
                    }
                    break Label_0034;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final Object o2 = o;
                    final boolean b2 = this.isNone(o2);
                    if (!b2) {
                        break Label_0034;
                    }
                    none = X11$XID.None;
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            return none;
        }
        X11$XID none;
        final X11$XID x11$XID = none = new X11$XID(((Number)o).longValue());
        if (b == null) {
            return none;
        }
        return x11$XID;
    }
    
    @Override
    public String toString() {
        return X11$XID.c + Long.toHexString(this.longValue());
    }
    
    static {
        b("CBqYe");
        int n3;
        int n2;
        final int n = n2 = (n3 = 6);
        final char[] charArray = "s\u007f".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0131: {
                if (length > 1) {
                    break Label_0131;
                }
                n3 = (n2 = n4);
                do {
                    final char c2 = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 69;
                            break;
                        }
                        case 1: {
                            n5 = 1;
                            break;
                        }
                        case 2: {
                            n5 = 113;
                            break;
                        }
                        case 3: {
                            n5 = 16;
                            break;
                        }
                        case 4: {
                            n5 = 55;
                            break;
                        }
                        case 5: {
                            n5 = 35;
                            break;
                        }
                        default: {
                            n5 = 87;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c2 ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                c = new String(charArray).intern();
                None = null;
                return;
            }
            continue;
        }
    }
    
    public static void b(final String b) {
        X11$XID.b = b;
    }
    
    public static String b() {
        return X11$XID.b;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
