// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.FromNativeContext;

public class X11$Pixmap extends X11$Drawable
{
    private static final long serialVersionUID = 1L;
    public static final X11$Pixmap None;
    
    public X11$Pixmap() {
    }
    
    public X11$Pixmap(final long n) {
        super(n);
    }
    
    @Override
    public Object fromNative(final Object o, final FromNativeContext fromNativeContext) {
        final String b = X11$XID.b();
        Label_0034: {
            X11$Pixmap none = null;
            Label_0023: {
                try {
                    final X11$Pixmap x11$Pixmap = this;
                    if (b == null) {
                        return x11$Pixmap;
                    }
                    final Object o2 = o;
                    final boolean b2 = this.isNone(o2);
                    if (b2) {
                        break Label_0023;
                    }
                    break Label_0034;
                }
                catch (RuntimeException ex) {
                    throw d(ex);
                }
                try {
                    final Object o2 = o;
                    final boolean b2 = this.isNone(o2);
                    if (!b2) {
                        break Label_0034;
                    }
                    none = X11$Pixmap.None;
                }
                catch (RuntimeException ex2) {
                    throw d(ex2);
                }
            }
            return none;
        }
        X11$Pixmap none;
        final X11$Pixmap x11$Pixmap = none = new X11$Pixmap(((Number)o).longValue());
        if (b == null) {
            return none;
        }
        return x11$Pixmap;
    }
    
    static {
        None = null;
    }
    
    private static RuntimeException d(final RuntimeException ex) {
        return ex;
    }
}
