// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.FromNativeContext;

public class X11$Colormap extends X11$XID
{
    private static final long serialVersionUID = 1L;
    public static final X11$Colormap None;
    
    public X11$Colormap() {
    }
    
    public X11$Colormap(final long n) {
        super(n);
    }
    
    @Override
    public Object fromNative(final Object o, final FromNativeContext fromNativeContext) {
        final String b = X11$XID.b();
        Label_0034: {
            X11$Colormap none = null;
            Label_0023: {
                try {
                    final X11$Colormap x11$Colormap = this;
                    if (b == null) {
                        return x11$Colormap;
                    }
                    final Object o2 = o;
                    final boolean b2 = this.isNone(o2);
                    if (b2) {
                        break Label_0023;
                    }
                    break Label_0034;
                }
                catch (RuntimeException ex) {
                    throw c(ex);
                }
                try {
                    final Object o2 = o;
                    final boolean b2 = this.isNone(o2);
                    if (!b2) {
                        break Label_0034;
                    }
                    none = X11$Colormap.None;
                }
                catch (RuntimeException ex2) {
                    throw c(ex2);
                }
            }
            return none;
        }
        X11$Colormap none;
        final X11$Colormap x11$Colormap = none = new X11$Colormap(((Number)o).longValue());
        if (b == null) {
            return none;
        }
        return x11$Colormap;
    }
    
    static {
        None = null;
    }
    
    private static RuntimeException c(final RuntimeException ex) {
        return ex;
    }
}
