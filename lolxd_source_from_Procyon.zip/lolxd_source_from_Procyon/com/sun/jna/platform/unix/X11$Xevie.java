// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.Native;
import com.sun.jna.NativeLong;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.Library;

public interface X11$Xevie extends Library
{
    public static final X11$Xevie INSTANCE = Native.loadLibrary(new String(charArray).intern(), X11$Xevie.class);
    public static final int XEVIE_UNMODIFIED = 0;
    public static final int XEVIE_MODIFIED = 1;
    
    boolean XevieQueryVersion(final X11$Display p0, final IntByReference p1, final IntByReference p2);
    
    int XevieStart(final X11$Display p0);
    
    int XevieEnd(final X11$Display p0);
    
    int XevieSendEvent(final X11$Display p0, final X11$XEvent p1, final int p2);
    
    int XevieSelectInput(final X11$Display p0, final NativeLong p1);
    
    default static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 32);
        final char[] charArray = ")[r\u001e*".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0127: {
                if (length > 1) {
                    break Label_0127;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 81;
                            break;
                        }
                        case 1: {
                            n5 = 30;
                            break;
                        }
                        case 2: {
                            n5 = 36;
                            break;
                        }
                        case 3: {
                            n5 = 87;
                            break;
                        }
                        case 4: {
                            n5 = 111;
                            break;
                        }
                        case 5: {
                            n5 = 3;
                            break;
                        }
                        default: {
                            n5 = 14;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                return;
            }
            continue;
        }
    }
}
