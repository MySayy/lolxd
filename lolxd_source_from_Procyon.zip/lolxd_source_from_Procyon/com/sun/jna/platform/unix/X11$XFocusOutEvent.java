// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

public class X11$XFocusOutEvent extends X11$XFocusChangeEvent
{
}
