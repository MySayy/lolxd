// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.Native;
import com.sun.jna.Library;

public interface X11$Xrender extends Library
{
    public static final X11$Xrender INSTANCE = Native.loadLibrary(new String(charArray).intern(), X11$Xrender.class);
    public static final int PictTypeIndexed = 0;
    public static final int PictTypeDirect = 1;
    
    X11$Xrender$XRenderPictFormat XRenderFindVisualFormat(final X11$Display p0, final X11$Visual p1);
    
    default static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 49);
        final char[] charArray = "f{D\u0013E\u0011p".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 15;
                            break;
                        }
                        case 1: {
                            n5 = 56;
                            break;
                        }
                        case 2: {
                            n5 = 16;
                            break;
                        }
                        case 3: {
                            n5 = 76;
                            break;
                        }
                        case 4: {
                            n5 = 16;
                            break;
                        }
                        case 5: {
                            n5 = 69;
                            break;
                        }
                        default: {
                            n5 = 51;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                return;
            }
            continue;
        }
    }
}
