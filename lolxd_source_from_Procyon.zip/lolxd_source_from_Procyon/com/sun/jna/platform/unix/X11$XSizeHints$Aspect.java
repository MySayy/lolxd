// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import java.util.List;
import com.sun.jna.Structure;

public class X11$XSizeHints$Aspect extends Structure
{
    public static final List<String> FIELDS;
    public int x;
    public int y;
    
    @Override
    protected List<String> getFieldOrder() {
        return X11$XSizeHints$Aspect.FIELDS;
    }
    
    static {
        FIELDS = Structure.createFieldsOrder("x", "y");
    }
}
