// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.NativeLong;
import com.sun.jna.Union;

public class X11$XEvent extends Union
{
    public int type;
    public X11$XAnyEvent xany;
    public X11$XKeyEvent xkey;
    public X11$XButtonEvent xbutton;
    public X11$XMotionEvent xmotion;
    public X11$XCrossingEvent xcrossing;
    public X11$XFocusChangeEvent xfocus;
    public X11$XExposeEvent xexpose;
    public X11$XGraphicsExposeEvent xgraphicsexpose;
    public X11$XNoExposeEvent xnoexpose;
    public X11$XVisibilityEvent xvisibility;
    public X11$XCreateWindowEvent xcreatewindow;
    public X11$XDestroyWindowEvent xdestroywindow;
    public X11$XUnmapEvent xunmap;
    public X11$XMapEvent xmap;
    public X11$XMapRequestEvent xmaprequest;
    public X11$XReparentEvent xreparent;
    public X11$XConfigureEvent xconfigure;
    public X11$XGravityEvent xgravity;
    public X11$XResizeRequestEvent xresizerequest;
    public X11$XConfigureRequestEvent xconfigurerequest;
    public X11$XCirculateEvent xcirculate;
    public X11$XCirculateRequestEvent xcirculaterequest;
    public X11$XPropertyEvent xproperty;
    public X11$XSelectionClearEvent xselectionclear;
    public X11$XSelectionRequestEvent xselectionrequest;
    public X11$XSelectionEvent xselection;
    public X11$XColormapEvent xcolormap;
    public X11$XClientMessageEvent xclient;
    public X11$XMappingEvent xmapping;
    public X11$XErrorEvent xerror;
    public X11$XKeymapEvent xkeymap;
    public NativeLong[] pad;
    
    public X11$XEvent() {
        this.pad = new NativeLong[24];
    }
}
