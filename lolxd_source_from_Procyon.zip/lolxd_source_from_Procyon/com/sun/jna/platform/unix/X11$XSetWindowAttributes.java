// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.NativeLong;
import java.util.List;
import com.sun.jna.Structure;

public class X11$XSetWindowAttributes extends Structure
{
    public static final List<String> FIELDS;
    public X11$Pixmap background_pixmap;
    public NativeLong background_pixel;
    public X11$Pixmap border_pixmap;
    public NativeLong border_pixel;
    public int bit_gravity;
    public int win_gravity;
    public int backing_store;
    public NativeLong backing_planes;
    public NativeLong backing_pixel;
    public boolean save_under;
    public NativeLong event_mask;
    public NativeLong do_not_propagate_mask;
    public boolean override_redirect;
    public X11$Colormap colormap;
    public X11$Cursor cursor;
    
    @Override
    protected List<String> getFieldOrder() {
        return X11$XSetWindowAttributes.FIELDS;
    }
    
    static {
        final String[] array = new String[15];
        int n = 0;
        String s;
        int n2 = (s = "^8Of\r\u0000\u000b_$IJ\u0005\u0000fK$Il\u0015Y\"b{\r\u0006XM?Re\u0003\u0015fI(bx\u0003\u0001l\u0011_,^~\u0005\u0000hH#YJ\u0012\u001b\u007fP,M\u000bJ$SJ\u0005\u0000fK$Il\u0011R;Xg\u0010\u001bcX\u0012Op\u0006\u001buX.I\u000e_,^~\u000b\u001c`b=Qt\f\u0017t\b^\"Qz\u0010\u001ffM\f_\"Oq\u0007\u0000XM$Ep\u000e\u0010_,^~\u0005\u0000hH#YJ\u0012\u001b\u007fX!\r_\"Oq\u0007\u0000XM$Ex\u0003\u0002\r_,^~\u000b\u001c`b>Iz\u0010\u0017\nN,Kp=\u0007iY(O").length();
        int n3 = 6;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 5));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0251: {
                            if (length > 1) {
                                break Label_0251;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 56;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 72;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 56;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 16;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 103;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 119;
                                        break;
                                    }
                                    default: {
                                        n11 = 2;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = ")J)\ng\\\u001b-O'\r.]/\u000fzm\u0011\u0013L%\u001cvo").length();
                            n3 = 10;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 116)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[3], array2[9], array2[10], array2[8], array2[1], array2[4], array2[11], array2[6], array2[14], array2[12], array2[13], array2[2], array2[5], array2[7], array2[0]);
    }
}
