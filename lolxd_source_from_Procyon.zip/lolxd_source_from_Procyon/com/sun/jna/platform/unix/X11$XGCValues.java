// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.NativeLong;
import java.util.List;
import com.sun.jna.Structure;

public class X11$XGCValues extends Structure
{
    public static final List<String> FIELDS;
    public int function;
    public NativeLong plane_mask;
    public NativeLong foreground;
    public NativeLong background;
    public int line_width;
    public int line_style;
    public int cap_style;
    public int join_style;
    public int fill_style;
    public int fill_rule;
    public int arc_mode;
    public X11$Pixmap tile;
    public X11$Pixmap stipple;
    public int ts_x_origin;
    public int ts_y_origin;
    public X11$Font font;
    public int subwindow_mode;
    public boolean graphics_exposures;
    public int clip_x_origin;
    public int clip_y_origin;
    public X11$Pixmap clip_mask;
    public int dash_offset;
    public byte dashes;
    
    @Override
    protected List<String> getFieldOrder() {
        return X11$XGCValues.FIELDS;
    }
    
    static {
        final String[] array = new String[23];
        int n = 0;
        String s;
        int n2 = (s = ",Fa\fY1}0D\\\u0016_;|\n9\\q\u001eW-v*]g\b>A`$]0}:\r<_j\u000bo'F0Aj\u001cY1\u00128Ab\u000bX6z,lf\u0003@0j*Af\b\n=R`\u0010W-v*]g\u000b+@\\\u0002o0k6Tj\u0015\t<_j\u000bo2x,X\u000b+@\\\u0003o0k6Tj\u0015\n5\\j\u0015o,m&_f\t9Zo\u0017o-l3V\b9Fm\u0018D6v1\n3Zm\u001eo(p;Gk\u000b;Rp\u0013o0\u007f9@f\u000f\u00049\\m\u000f\n3Zm\u001eo,m&_f\n9Zo\u0017o,m&_f\t<Rs$C+`3V\n/_b\u0015U\u0000t>@h\u0006;Rp\u0013U,\u0007,Gj\u000b@3|").length();
        int n3 = 14;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 90));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0250: {
                            if (length > 1) {
                                break Label_0250;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 5;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 105;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 89;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 33;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 106;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 5;
                                        break;
                                    }
                                    default: {
                                        n11 = 67;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "|\r8I\rk\b=\\8q\u0011g\u0016=K\u000ef").length();
                            n3 = 4;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 13)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[11], array2[18], array2[1], array2[5], array2[12], array2[15], array2[17], array2[9], array2[16], array2[10], array2[2], array2[21], array2[20], array2[8], array2[6], array2[14], array2[0], array2[4], array2[3], array2[22], array2[7], array2[13], array2[19]);
    }
}
