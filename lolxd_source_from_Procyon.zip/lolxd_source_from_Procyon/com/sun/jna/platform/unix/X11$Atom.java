// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.FromNativeContext;

public class X11$Atom extends X11$XID
{
    private static final long serialVersionUID = 1L;
    public static final X11$Atom None;
    
    public X11$Atom() {
    }
    
    public X11$Atom(final long n) {
        super(n);
    }
    
    @Override
    public Object fromNative(final Object p0, final FromNativeContext p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_1        
        //     4: checkcast       Ljava/lang/Number;
        //     7: invokevirtual   java/lang/Number.longValue:()J
        //    10: lstore          4
        //    12: astore_3       
        //    13: lload           4
        //    15: ldc2_w          2147483647
        //    18: lcmp           
        //    19: aload_3        
        //    20: ifnull          54
        //    23: aload_3        
        //    24: ifnull          54
        //    27: goto            34
        //    30: invokestatic    com/sun/jna/platform/unix/X11$Atom.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    33: athrow         
        //    34: ifgt            620
        //    37: goto            44
        //    40: invokestatic    com/sun/jna/platform/unix/X11$Atom.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    43: athrow         
        //    44: lload           4
        //    46: l2i            
        //    47: goto            54
        //    50: invokestatic    com/sun/jna/platform/unix/X11$Atom.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    53: athrow         
        //    54: tableswitch {
        //                0: 344
        //                1: 348
        //                2: 352
        //                3: 356
        //                4: 360
        //                5: 364
        //                6: 368
        //                7: 372
        //                8: 376
        //                9: 380
        //               10: 384
        //               11: 388
        //               12: 392
        //               13: 396
        //               14: 400
        //               15: 404
        //               16: 408
        //               17: 412
        //               18: 416
        //               19: 420
        //               20: 424
        //               21: 428
        //               22: 432
        //               23: 436
        //               24: 440
        //               25: 444
        //               26: 448
        //               27: 452
        //               28: 456
        //               29: 460
        //               30: 464
        //               31: 468
        //               32: 472
        //               33: 476
        //               34: 480
        //               35: 484
        //               36: 488
        //               37: 492
        //               38: 496
        //               39: 500
        //               40: 504
        //               41: 508
        //               42: 512
        //               43: 516
        //               44: 520
        //               45: 524
        //               46: 528
        //               47: 532
        //               48: 536
        //               49: 540
        //               50: 544
        //               51: 548
        //               52: 552
        //               53: 556
        //               54: 560
        //               55: 564
        //               56: 568
        //               57: 572
        //               58: 576
        //               59: 580
        //               60: 584
        //               61: 588
        //               62: 592
        //               63: 596
        //               64: 600
        //               65: 604
        //               66: 608
        //               67: 612
        //               68: 616
        //          default: 620
        //        }
        //   344: getstatic       com/sun/jna/platform/unix/X11$Atom.None:Lcom/sun/jna/platform/unix/X11$Atom;
        //   347: areturn        
        //   348: getstatic       com/sun/jna/platform/unix/X11.XA_PRIMARY:Lcom/sun/jna/platform/unix/X11$Atom;
        //   351: areturn        
        //   352: getstatic       com/sun/jna/platform/unix/X11.XA_SECONDARY:Lcom/sun/jna/platform/unix/X11$Atom;
        //   355: areturn        
        //   356: getstatic       com/sun/jna/platform/unix/X11.XA_ARC:Lcom/sun/jna/platform/unix/X11$Atom;
        //   359: areturn        
        //   360: getstatic       com/sun/jna/platform/unix/X11.XA_ATOM:Lcom/sun/jna/platform/unix/X11$Atom;
        //   363: areturn        
        //   364: getstatic       com/sun/jna/platform/unix/X11.XA_BITMAP:Lcom/sun/jna/platform/unix/X11$Atom;
        //   367: areturn        
        //   368: getstatic       com/sun/jna/platform/unix/X11.XA_CARDINAL:Lcom/sun/jna/platform/unix/X11$Atom;
        //   371: areturn        
        //   372: getstatic       com/sun/jna/platform/unix/X11.XA_COLORMAP:Lcom/sun/jna/platform/unix/X11$Atom;
        //   375: areturn        
        //   376: getstatic       com/sun/jna/platform/unix/X11.XA_CURSOR:Lcom/sun/jna/platform/unix/X11$Atom;
        //   379: areturn        
        //   380: getstatic       com/sun/jna/platform/unix/X11.XA_CUT_BUFFER0:Lcom/sun/jna/platform/unix/X11$Atom;
        //   383: areturn        
        //   384: getstatic       com/sun/jna/platform/unix/X11.XA_CUT_BUFFER1:Lcom/sun/jna/platform/unix/X11$Atom;
        //   387: areturn        
        //   388: getstatic       com/sun/jna/platform/unix/X11.XA_CUT_BUFFER2:Lcom/sun/jna/platform/unix/X11$Atom;
        //   391: areturn        
        //   392: getstatic       com/sun/jna/platform/unix/X11.XA_CUT_BUFFER3:Lcom/sun/jna/platform/unix/X11$Atom;
        //   395: areturn        
        //   396: getstatic       com/sun/jna/platform/unix/X11.XA_CUT_BUFFER4:Lcom/sun/jna/platform/unix/X11$Atom;
        //   399: areturn        
        //   400: getstatic       com/sun/jna/platform/unix/X11.XA_CUT_BUFFER5:Lcom/sun/jna/platform/unix/X11$Atom;
        //   403: areturn        
        //   404: getstatic       com/sun/jna/platform/unix/X11.XA_CUT_BUFFER6:Lcom/sun/jna/platform/unix/X11$Atom;
        //   407: areturn        
        //   408: getstatic       com/sun/jna/platform/unix/X11.XA_CUT_BUFFER7:Lcom/sun/jna/platform/unix/X11$Atom;
        //   411: areturn        
        //   412: getstatic       com/sun/jna/platform/unix/X11.XA_DRAWABLE:Lcom/sun/jna/platform/unix/X11$Atom;
        //   415: areturn        
        //   416: getstatic       com/sun/jna/platform/unix/X11.XA_FONT:Lcom/sun/jna/platform/unix/X11$Atom;
        //   419: areturn        
        //   420: getstatic       com/sun/jna/platform/unix/X11.XA_INTEGER:Lcom/sun/jna/platform/unix/X11$Atom;
        //   423: areturn        
        //   424: getstatic       com/sun/jna/platform/unix/X11.XA_PIXMAP:Lcom/sun/jna/platform/unix/X11$Atom;
        //   427: areturn        
        //   428: getstatic       com/sun/jna/platform/unix/X11.XA_POINT:Lcom/sun/jna/platform/unix/X11$Atom;
        //   431: areturn        
        //   432: getstatic       com/sun/jna/platform/unix/X11.XA_RECTANGLE:Lcom/sun/jna/platform/unix/X11$Atom;
        //   435: areturn        
        //   436: getstatic       com/sun/jna/platform/unix/X11.XA_RESOURCE_MANAGER:Lcom/sun/jna/platform/unix/X11$Atom;
        //   439: areturn        
        //   440: getstatic       com/sun/jna/platform/unix/X11.XA_RGB_COLOR_MAP:Lcom/sun/jna/platform/unix/X11$Atom;
        //   443: areturn        
        //   444: getstatic       com/sun/jna/platform/unix/X11.XA_RGB_BEST_MAP:Lcom/sun/jna/platform/unix/X11$Atom;
        //   447: areturn        
        //   448: getstatic       com/sun/jna/platform/unix/X11.XA_RGB_BLUE_MAP:Lcom/sun/jna/platform/unix/X11$Atom;
        //   451: areturn        
        //   452: getstatic       com/sun/jna/platform/unix/X11.XA_RGB_DEFAULT_MAP:Lcom/sun/jna/platform/unix/X11$Atom;
        //   455: areturn        
        //   456: getstatic       com/sun/jna/platform/unix/X11.XA_RGB_GRAY_MAP:Lcom/sun/jna/platform/unix/X11$Atom;
        //   459: areturn        
        //   460: getstatic       com/sun/jna/platform/unix/X11.XA_RGB_GREEN_MAP:Lcom/sun/jna/platform/unix/X11$Atom;
        //   463: areturn        
        //   464: getstatic       com/sun/jna/platform/unix/X11.XA_RGB_RED_MAP:Lcom/sun/jna/platform/unix/X11$Atom;
        //   467: areturn        
        //   468: getstatic       com/sun/jna/platform/unix/X11.XA_STRING:Lcom/sun/jna/platform/unix/X11$Atom;
        //   471: areturn        
        //   472: getstatic       com/sun/jna/platform/unix/X11.XA_VISUALID:Lcom/sun/jna/platform/unix/X11$Atom;
        //   475: areturn        
        //   476: getstatic       com/sun/jna/platform/unix/X11.XA_WINDOW:Lcom/sun/jna/platform/unix/X11$Atom;
        //   479: areturn        
        //   480: getstatic       com/sun/jna/platform/unix/X11.XA_WM_COMMAND:Lcom/sun/jna/platform/unix/X11$Atom;
        //   483: areturn        
        //   484: getstatic       com/sun/jna/platform/unix/X11.XA_WM_HINTS:Lcom/sun/jna/platform/unix/X11$Atom;
        //   487: areturn        
        //   488: getstatic       com/sun/jna/platform/unix/X11.XA_WM_CLIENT_MACHINE:Lcom/sun/jna/platform/unix/X11$Atom;
        //   491: areturn        
        //   492: getstatic       com/sun/jna/platform/unix/X11.XA_WM_ICON_NAME:Lcom/sun/jna/platform/unix/X11$Atom;
        //   495: areturn        
        //   496: getstatic       com/sun/jna/platform/unix/X11.XA_WM_ICON_SIZE:Lcom/sun/jna/platform/unix/X11$Atom;
        //   499: areturn        
        //   500: getstatic       com/sun/jna/platform/unix/X11.XA_WM_NAME:Lcom/sun/jna/platform/unix/X11$Atom;
        //   503: areturn        
        //   504: getstatic       com/sun/jna/platform/unix/X11.XA_WM_NORMAL_HINTS:Lcom/sun/jna/platform/unix/X11$Atom;
        //   507: areturn        
        //   508: getstatic       com/sun/jna/platform/unix/X11.XA_WM_SIZE_HINTS:Lcom/sun/jna/platform/unix/X11$Atom;
        //   511: areturn        
        //   512: getstatic       com/sun/jna/platform/unix/X11.XA_WM_ZOOM_HINTS:Lcom/sun/jna/platform/unix/X11$Atom;
        //   515: areturn        
        //   516: getstatic       com/sun/jna/platform/unix/X11.XA_MIN_SPACE:Lcom/sun/jna/platform/unix/X11$Atom;
        //   519: areturn        
        //   520: getstatic       com/sun/jna/platform/unix/X11.XA_NORM_SPACE:Lcom/sun/jna/platform/unix/X11$Atom;
        //   523: areturn        
        //   524: getstatic       com/sun/jna/platform/unix/X11.XA_MAX_SPACE:Lcom/sun/jna/platform/unix/X11$Atom;
        //   527: areturn        
        //   528: getstatic       com/sun/jna/platform/unix/X11.XA_END_SPACE:Lcom/sun/jna/platform/unix/X11$Atom;
        //   531: areturn        
        //   532: getstatic       com/sun/jna/platform/unix/X11.XA_SUPERSCRIPT_X:Lcom/sun/jna/platform/unix/X11$Atom;
        //   535: areturn        
        //   536: getstatic       com/sun/jna/platform/unix/X11.XA_SUPERSCRIPT_Y:Lcom/sun/jna/platform/unix/X11$Atom;
        //   539: areturn        
        //   540: getstatic       com/sun/jna/platform/unix/X11.XA_SUBSCRIPT_X:Lcom/sun/jna/platform/unix/X11$Atom;
        //   543: areturn        
        //   544: getstatic       com/sun/jna/platform/unix/X11.XA_SUBSCRIPT_Y:Lcom/sun/jna/platform/unix/X11$Atom;
        //   547: areturn        
        //   548: getstatic       com/sun/jna/platform/unix/X11.XA_UNDERLINE_POSITION:Lcom/sun/jna/platform/unix/X11$Atom;
        //   551: areturn        
        //   552: getstatic       com/sun/jna/platform/unix/X11.XA_UNDERLINE_THICKNESS:Lcom/sun/jna/platform/unix/X11$Atom;
        //   555: areturn        
        //   556: getstatic       com/sun/jna/platform/unix/X11.XA_STRIKEOUT_ASCENT:Lcom/sun/jna/platform/unix/X11$Atom;
        //   559: areturn        
        //   560: getstatic       com/sun/jna/platform/unix/X11.XA_STRIKEOUT_DESCENT:Lcom/sun/jna/platform/unix/X11$Atom;
        //   563: areturn        
        //   564: getstatic       com/sun/jna/platform/unix/X11.XA_ITALIC_ANGLE:Lcom/sun/jna/platform/unix/X11$Atom;
        //   567: areturn        
        //   568: getstatic       com/sun/jna/platform/unix/X11.XA_X_HEIGHT:Lcom/sun/jna/platform/unix/X11$Atom;
        //   571: areturn        
        //   572: getstatic       com/sun/jna/platform/unix/X11.XA_QUAD_WIDTH:Lcom/sun/jna/platform/unix/X11$Atom;
        //   575: areturn        
        //   576: getstatic       com/sun/jna/platform/unix/X11.XA_WEIGHT:Lcom/sun/jna/platform/unix/X11$Atom;
        //   579: areturn        
        //   580: getstatic       com/sun/jna/platform/unix/X11.XA_POINT_SIZE:Lcom/sun/jna/platform/unix/X11$Atom;
        //   583: areturn        
        //   584: getstatic       com/sun/jna/platform/unix/X11.XA_RESOLUTION:Lcom/sun/jna/platform/unix/X11$Atom;
        //   587: areturn        
        //   588: getstatic       com/sun/jna/platform/unix/X11.XA_COPYRIGHT:Lcom/sun/jna/platform/unix/X11$Atom;
        //   591: areturn        
        //   592: getstatic       com/sun/jna/platform/unix/X11.XA_NOTICE:Lcom/sun/jna/platform/unix/X11$Atom;
        //   595: areturn        
        //   596: getstatic       com/sun/jna/platform/unix/X11.XA_FONT_NAME:Lcom/sun/jna/platform/unix/X11$Atom;
        //   599: areturn        
        //   600: getstatic       com/sun/jna/platform/unix/X11.XA_FAMILY_NAME:Lcom/sun/jna/platform/unix/X11$Atom;
        //   603: areturn        
        //   604: getstatic       com/sun/jna/platform/unix/X11.XA_FULL_NAME:Lcom/sun/jna/platform/unix/X11$Atom;
        //   607: areturn        
        //   608: getstatic       com/sun/jna/platform/unix/X11.XA_CAP_HEIGHT:Lcom/sun/jna/platform/unix/X11$Atom;
        //   611: areturn        
        //   612: getstatic       com/sun/jna/platform/unix/X11.XA_WM_CLASS:Lcom/sun/jna/platform/unix/X11$Atom;
        //   615: areturn        
        //   616: getstatic       com/sun/jna/platform/unix/X11.XA_WM_TRANSIENT_FOR:Lcom/sun/jna/platform/unix/X11$Atom;
        //   619: areturn        
        //   620: new             Lcom/sun/jna/platform/unix/X11$Atom;
        //   623: dup            
        //   624: lload           4
        //   626: invokespecial   com/sun/jna/platform/unix/X11$Atom.<init>:(J)V
        //   629: aload_3        
        //   630: ifnull          347
        //   633: areturn        
        //    StackMapTable: 00 4D FF 00 1E 00 05 07 00 4D 07 00 FF 07 01 01 07 01 03 04 00 01 07 00 F9 43 01 45 07 00 F9 03 45 07 00 F9 43 01 FB 01 21 42 07 00 4D 00 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  13     27     30     34     Ljava/lang/RuntimeException;
        //  23     37     40     44     Ljava/lang/RuntimeException;
        //  34     47     50     54     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0034:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        None = null;
    }
    
    private static RuntimeException c(final RuntimeException ex) {
        return ex;
    }
}
