// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.NativeLong;
import java.util.List;
import com.sun.jna.Structure;

public class X11$XWindowAttributes extends Structure
{
    public static final List<String> FIELDS;
    public int x;
    public int y;
    public int width;
    public int height;
    public int border_width;
    public int depth;
    public X11$Visual visual;
    public X11$Window root;
    public int c_class;
    public int bit_gravity;
    public int win_gravity;
    public int backing_store;
    public NativeLong backing_planes;
    public NativeLong backing_pixel;
    public boolean save_under;
    public X11$Colormap colormap;
    public boolean map_installed;
    public int map_state;
    public NativeLong all_event_masks;
    public NativeLong your_event_mask;
    public NativeLong do_not_propagate_mask;
    public boolean override_redirect;
    public X11$Screen screen;
    
    @Override
    protected List<String> getFieldOrder() {
        return X11$XWindowAttributes.FIELDS;
    }
    
    static {
        final String[] array = new String[21];
        int n = 0;
        String s;
        int n2 = (s = "$I_d\u0011!\u0002=ICW\u001d+\u0015-GpU\u0017;.9Z@K\u0019(\u0010=MpV\u0019<\u001a\u0006!MF\\\u0010;\u0006:K]^\u001d!\r+ILP\u0011!\u0016\u0016[[T\n*\u000f0GZI'*\u0007,F[d\u0015.\u0002\"\u0005-M_O\u0010\u000b+A[d\u001f=\u0010?A[B\u000e+ILP\u0011!\u0016\u0016XCZ\u0016*\u0002\u0007*wLW\u0019<\u0002\u0005>AKO\u0010\u0006?A\\N\u0019#\b*GCT\n\"\u00109\r+ILP\u0011!\u0016\u0016XFC\u001d#\u000b>AAd\u001f=\u0010?A[B\u0011&^JI\n&\u0015,w]^\u001c&\u0003,K[\u000f(DCd\u001d9\u0014'\\pV\u0019<\u001a:\f+G]_\u001d=.>AKO\u0010\n:IY^':\u001f-M]").length();
        int n3 = 13;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 55));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0252: {
                            if (length > 1) {
                                break Label_0252;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 126;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 31;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 24;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 12;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 79;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 120;
                                        break;
                                    }
                                    default: {
                                        n11 = 70;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "\u0015xnU:\n!\f|\u0004\nvq~").length();
                            n3 = 9;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 6)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder("x", "y", array2[10], array2[2], array2[17], array2[6], array2[11], array2[20], array2[9], array2[7], array2[14], array2[4], array2[8], array2[13], array2[18], array2[12], array2[0], array2[19], array2[16], array2[5], array2[1], array2[15], array2[3]);
    }
}
