// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.FromNativeContext;

public class X11$KeySym extends X11$XID
{
    private static final long serialVersionUID = 1L;
    public static final X11$KeySym None;
    
    public X11$KeySym() {
    }
    
    public X11$KeySym(final long n) {
        super(n);
    }
    
    @Override
    public Object fromNative(final Object o, final FromNativeContext fromNativeContext) {
        final String b = X11$XID.b();
        Label_0034: {
            X11$KeySym none = null;
            Label_0023: {
                try {
                    final X11$KeySym x11$KeySym = this;
                    if (b == null) {
                        return x11$KeySym;
                    }
                    final Object o2 = o;
                    final boolean b2 = this.isNone(o2);
                    if (b2) {
                        break Label_0023;
                    }
                    break Label_0034;
                }
                catch (RuntimeException ex) {
                    throw c(ex);
                }
                try {
                    final Object o2 = o;
                    final boolean b2 = this.isNone(o2);
                    if (!b2) {
                        break Label_0034;
                    }
                    none = X11$KeySym.None;
                }
                catch (RuntimeException ex2) {
                    throw c(ex2);
                }
            }
            return none;
        }
        X11$KeySym none;
        final X11$KeySym x11$KeySym = none = new X11$KeySym(((Number)o).longValue());
        if (b == null) {
            return none;
        }
        return x11$KeySym;
    }
    
    static {
        None = null;
    }
    
    private static RuntimeException c(final RuntimeException ex) {
        return ex;
    }
}
