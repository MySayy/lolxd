// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.Native;
import com.sun.jna.Library;

public interface X11$Xext extends Library
{
    public static final X11$Xext INSTANCE = Native.loadLibrary(new String(charArray).intern(), X11$Xext.class);
    public static final int ShapeBounding = 0;
    public static final int ShapeClip = 1;
    public static final int ShapeInput = 2;
    public static final int ShapeSet = 0;
    public static final int ShapeUnion = 1;
    public static final int ShapeIntersect = 2;
    public static final int ShapeSubtract = 3;
    public static final int ShapeInvert = 4;
    
    void XShapeCombineMask(final X11$Display p0, final X11$Window p1, final int p2, final int p3, final int p4, final X11$Pixmap p5, final int p6);
    
    default static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 117);
        final char[] charArray = "04+f".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 29;
                            break;
                        }
                        case 1: {
                            n5 = 36;
                            break;
                        }
                        case 2: {
                            n5 = 38;
                            break;
                        }
                        case 3: {
                            n5 = 103;
                            break;
                        }
                        case 4: {
                            n5 = 21;
                            break;
                        }
                        case 5: {
                            n5 = 88;
                            break;
                        }
                        default: {
                            n5 = 20;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                return;
            }
            continue;
        }
    }
}
