// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.NativeLong;
import java.util.List;
import com.sun.jna.Structure;

public class X11$XWMHints extends Structure
{
    public static final List<String> FIELDS;
    public NativeLong flags;
    public boolean input;
    public int initial_state;
    public X11$Pixmap icon_pixmap;
    public X11$Window icon_window;
    public int icon_x;
    public int icon_y;
    public X11$Pixmap icon_mask;
    public X11$XID window_group;
    
    @Override
    protected List<String> getFieldOrder() {
        return X11$XWMHints.FIELDS;
    }
    
    static {
        final String[] array = new String[9];
        int n = 0;
        String s;
        int n2 = (s = "-&\"p~\u0005M7.\u0005-+=kU\u0006-&\"p~\u0010\r-+$jH\t@\u001b69\u007fU\r\u000b-&\"p~\u0018E<(,n\u000b-&\"p~\u001fE*!\"i\f3,#zN\u001fs#7\"kQ").length();
        int n3 = 9;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 74));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0252: {
                            if (length > 1) {
                                break Label_0252;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 14;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 15;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 7;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 84;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 107;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 34;
                                        break;
                                    }
                                    default: {
                                        n11 = 102;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "\u0013\u0018\u001dHc\u0006\u001c\u0017\u0013AO ").length();
                            n3 = 5;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 123)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[7], array2[1], array2[3], array2[4], array2[5], array2[2], array2[8], array2[0], array2[6]);
    }
}
