// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import java.util.List;
import com.sun.jna.Structure;

public class X11$XRectangle extends Structure
{
    public static final List<String> FIELDS;
    public short x;
    public short y;
    public short width;
    public short height;
    
    @Override
    protected List<String> getFieldOrder() {
        return X11$XRectangle.FIELDS;
    }
    
    public X11$XRectangle() {
        this((short)0, (short)0, (short)0, (short)0);
    }
    
    public X11$XRectangle(final short x, final short y, final short width, final short height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    
    static {
        final String[] array = new String[2];
        int n = 0;
        final String s;
        final int length = (s = "nO\b\u0003\u000f\u007f\u0005qC\u0005\u0010\u000f").length();
        int char1 = 6;
        int index = -1;
        Label_0023: {
            break Label_0023;
            do {
                char1 = s.charAt(index);
                int n4;
                int n3;
                final int n2 = n3 = (n4 = 39);
                ++index;
                final String s2 = s;
                final int beginIndex = index;
                final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
                final int length2 = charArray.length;
                int n5 = 0;
                while (true) {
                    Label_0192: {
                        if (length2 > 1) {
                            break Label_0192;
                        }
                        n4 = (n3 = n5);
                        do {
                            final char c = charArray[n3];
                            int n6 = 0;
                            switch (n5 % 7) {
                                case 0: {
                                    n6 = 33;
                                    break;
                                }
                                case 1: {
                                    n6 = 13;
                                    break;
                                }
                                case 2: {
                                    n6 = 70;
                                    break;
                                }
                                case 3: {
                                    n6 = 67;
                                    break;
                                }
                                case 4: {
                                    n6 = 64;
                                    break;
                                }
                                case 5: {
                                    n6 = 44;
                                    break;
                                }
                                default: {
                                    n6 = 40;
                                    break;
                                }
                            }
                            charArray[n4] = (char)(c ^ (n2 ^ n6));
                            ++n5;
                        } while (n2 == 0);
                    }
                    if (length2 > n5) {
                        continue;
                    }
                    break;
                }
                array[n++] = new String(charArray).intern();
            } while ((index += char1) < length);
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder("x", "y", array2[1], array2[0]);
    }
}
