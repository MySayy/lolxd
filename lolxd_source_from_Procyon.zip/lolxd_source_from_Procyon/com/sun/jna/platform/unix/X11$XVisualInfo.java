// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.NativeLong;
import java.util.List;
import com.sun.jna.Structure;

public class X11$XVisualInfo extends Structure
{
    public static final List<String> FIELDS;
    public X11$Visual visual;
    public X11$VisualID visualid;
    public int screen;
    public int depth;
    public int c_class;
    public NativeLong red_mask;
    public NativeLong green_mask;
    public NativeLong blue_mask;
    public int colormap_size;
    public int bits_per_rgb;
    
    @Override
    protected List<String> getFieldOrder() {
        return X11$XVisualInfo.FIELDS;
    }
    
    static {
        final String[] array = new String[10];
        int n = 0;
        String s;
        int n2 = (s = "\u000f$G\u0003cy5\r\u000f\u0014H\u0000pg'\u001c$W\u0006xo\u0006\u001f\u0018V\ngd\b\u001e\u001e@0ok5\u0007\u0005\b\u001eT\u001bj\n\u000b\tA\nlU+\r\bO\f\u000e\u0012P\u001c]z#\u001e$V\b`\t\u000e\u0017Q\n]g'\u001f\u0010").length();
        int n3 = 7;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 117));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0252: {
                            if (length > 1) {
                                break Label_0252;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 25;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 14;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 81;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 26;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 119;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 127;
                                        break;
                                    }
                                    default: {
                                        n11 = 51;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "\"*o\"[^\u00170\u0006\"*o\"[^").length();
                            n3 = 8;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 77)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[9], array2[8], array2[2], array2[4], array2[0], array2[3], array2[5], array2[7], array2[1], array2[6]);
    }
}
