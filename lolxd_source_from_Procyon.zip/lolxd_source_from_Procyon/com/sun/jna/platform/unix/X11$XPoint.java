// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import java.util.List;
import com.sun.jna.Structure;

public class X11$XPoint extends Structure
{
    public static final List<String> FIELDS;
    public short x;
    public short y;
    
    @Override
    protected List<String> getFieldOrder() {
        return X11$XPoint.FIELDS;
    }
    
    public X11$XPoint() {
        this((short)0, (short)0);
    }
    
    public X11$XPoint(final short x, final short y) {
        this.x = x;
        this.y = y;
    }
    
    static {
        FIELDS = Structure.createFieldsOrder("x", "y");
    }
}
