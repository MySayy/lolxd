// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import java.util.List;
import com.sun.jna.Structure;

public class X11$Xrender$XRenderDirectFormat extends Structure
{
    public static final List<String> FIELDS;
    public short red;
    public short redMask;
    public short green;
    public short greenMask;
    public short blue;
    public short blueMask;
    public short alpha;
    public short alphaMask;
    
    @Override
    protected List<String> getFieldOrder() {
        return X11$Xrender$XRenderDirectFormat.FIELDS;
    }
    
    static {
        final String[] array = new String[8];
        int n = 0;
        String s;
        int n2 = (s = "\u0000:40\u007f\u0003\u00133 \u0007\u00133 \u0015\u007f-E\u0005\u0006$!=p\t\u0000:40\u007f\u0013O\u0012=\b\u0003:1=S?]\n").length();
        int n3 = 5;
        int n4 = -1;
    Label_0023:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 32));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0252: {
                            if (length > 1) {
                                break Label_0252;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 65;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 118;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 100;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 120;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 62;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 126;
                                        break;
                                    }
                                    default: {
                                        n11 = 14;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0023;
                            }
                            n2 = (s = "lNKW\u001ay%xW\u0004iP[W").length();
                            n3 = 9;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0023;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 74)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[1], array2[2], array2[3], array2[6], array2[7], array2[5], array2[0], array2[4]);
    }
}
