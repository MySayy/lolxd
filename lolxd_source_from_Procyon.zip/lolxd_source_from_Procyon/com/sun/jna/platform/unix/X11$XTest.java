// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.Native;
import com.sun.jna.NativeLong;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.Library;

public interface X11$XTest extends Library
{
    public static final X11$XTest INSTANCE = Native.loadLibrary(new String(charArray).intern(), X11$XTest.class);
    
    boolean XTestQueryExtension(final X11$Display p0, final IntByReference p1, final IntByReference p2, final IntByReference p3, final IntByReference p4);
    
    boolean XTestCompareCursorWithWindow(final X11$Display p0, final X11$Window p1, final X11$Cursor p2);
    
    boolean XTestCompareCurrentCursorWithWindow(final X11$Display p0, final X11$Window p1);
    
    int XTestFakeKeyEvent(final X11$Display p0, final int p1, final boolean p2, final NativeLong p3);
    
    int XTestFakeButtonEvent(final X11$Display p0, final int p1, final boolean p2, final NativeLong p3);
    
    int XTestFakeMotionEvent(final X11$Display p0, final int p1, final int p2, final int p3, final NativeLong p4);
    
    int XTestFakeRelativeMotionEvent(final X11$Display p0, final int p1, final int p2, final NativeLong p3);
    
    int XTestFakeDeviceKeyEvent(final X11$Display p0, final X11$XDeviceByReference p1, final int p2, final boolean p3, final IntByReference p4, final int p5, final NativeLong p6);
    
    int XTestFakeDeviceButtonEvent(final X11$Display p0, final X11$XDeviceByReference p1, final int p2, final boolean p3, final IntByReference p4, final int p5, final NativeLong p6);
    
    int XTestFakeProximityEvent(final X11$Display p0, final X11$XDeviceByReference p1, final boolean p2, final IntByReference p3, final int p4, final NativeLong p5);
    
    int XTestFakeDeviceMotionEvent(final X11$Display p0, final X11$XDeviceByReference p1, final boolean p2, final int p3, final IntByReference p4, final int p5, final NativeLong p6);
    
    int XTestGrabControl(final X11$Display p0, final boolean p1);
    
    void XTestSetVisualIDOfVisual(final X11$Visual p0, final X11$VisualID p1);
    
    int XTestDiscard(final X11$Display p0);
    
    default static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 110);
        final char[] charArray = "A`tJ".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 119;
                            break;
                        }
                        case 1: {
                            n5 = 122;
                            break;
                        }
                        case 2: {
                            n5 = 105;
                            break;
                        }
                        case 3: {
                            n5 = 80;
                            break;
                        }
                        case 4: {
                            n5 = 52;
                            break;
                        }
                        case 5: {
                            n5 = 18;
                            break;
                        }
                        default: {
                            n5 = 51;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                return;
            }
            continue;
        }
    }
}
