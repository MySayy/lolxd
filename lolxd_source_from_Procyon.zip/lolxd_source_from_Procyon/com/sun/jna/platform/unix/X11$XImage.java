// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.PointerType;

public class X11$XImage extends PointerType
{
}
