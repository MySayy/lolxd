// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.FromNativeContext;
import com.sun.jna.ptr.ByReference;

public class X11$AtomByReference extends ByReference
{
    public X11$AtomByReference() {
        super(X11$XID.SIZE);
    }
    
    public X11$Atom getValue() {
        return (X11$Atom)new X11$Atom().fromNative(this.getPointer().getNativeLong(0L), null);
    }
}
