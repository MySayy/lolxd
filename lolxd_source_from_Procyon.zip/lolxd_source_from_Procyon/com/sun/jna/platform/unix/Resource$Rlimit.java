// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import java.util.List;
import com.sun.jna.Structure;

public class Resource$Rlimit extends Structure
{
    public static final List<String> FIELDS;
    public long rlim_cur;
    public long rlim_max;
    
    @Override
    protected List<String> getFieldOrder() {
        return Resource$Rlimit.FIELDS;
    }
    
    static {
        final String[] array = new String[2];
        int n = 0;
        final String s;
        final int length = (s = "ULs\fi\bAU\bULs\fi\u0006U_").length();
        int char1 = 8;
        int index = -1;
        Label_0023: {
            break Label_0023;
            do {
                char1 = s.charAt(index);
                int n4;
                int n3;
                final int n2 = n3 = (n4 = 101);
                ++index;
                final String s2 = s;
                final int beginIndex = index;
                final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
                final int length2 = charArray.length;
                int n5 = 0;
                while (true) {
                    Label_0191: {
                        if (length2 > 1) {
                            break Label_0191;
                        }
                        n4 = (n3 = n5);
                        do {
                            final char c = charArray[n3];
                            int n6 = 0;
                            switch (n5 % 7) {
                                case 0: {
                                    n6 = 66;
                                    break;
                                }
                                case 1: {
                                    n6 = 69;
                                    break;
                                }
                                case 2: {
                                    n6 = 127;
                                    break;
                                }
                                case 3: {
                                    n6 = 4;
                                    break;
                                }
                                case 4: {
                                    n6 = 83;
                                    break;
                                }
                                case 5: {
                                    n6 = 14;
                                    break;
                                }
                                default: {
                                    n6 = 81;
                                    break;
                                }
                            }
                            charArray[n4] = (char)(c ^ (n2 ^ n6));
                            ++n5;
                        } while (n2 == 0);
                    }
                    if (length2 > n5) {
                        continue;
                    }
                    break;
                }
                array[n++] = new String(charArray).intern();
            } while ((index += char1) < length);
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[0], array2[1]);
    }
}
