// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.Callback;

public interface X11$XErrorHandler extends Callback
{
    int apply(final X11$Display p0, final X11$XErrorEvent p1);
}
