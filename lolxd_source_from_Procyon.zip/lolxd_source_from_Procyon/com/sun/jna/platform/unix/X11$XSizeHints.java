// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.NativeLong;
import java.util.List;
import com.sun.jna.Structure;

public class X11$XSizeHints extends Structure
{
    public static final List<String> FIELDS;
    public NativeLong flags;
    public int x;
    public int y;
    public int width;
    public int height;
    public int min_width;
    public int min_height;
    public int max_width;
    public int max_height;
    public int width_inc;
    public int height_inc;
    public X11$XSizeHints$Aspect min_aspect;
    public X11$XSizeHints$Aspect max_aspect;
    public int base_width;
    public int base_height;
    public int win_gravity;
    
    @Override
    protected List<String> getFieldOrder() {
        return X11$XSizeHints.FIELDS;
    }
    
    static {
        final String[] array = new String[14];
        int n = 0;
        String s;
        int n2 = (s = "\u0000\u0019(5 u\u0017\u0006\f3\n\u000f\u00115\u000f\u0017g\u0017\u0005\u0010/\u000b\u0000\u0019(5 j\u001b\u000b\u001f3$\u0005\u0004\u0014:7\f\n\u000f\u0019#\u000f\u001eq\u000e\u0007\u001b/\t\u000f\u0019#\u000f\bk\u001a\u0016\u0010\t\u000f\u00115\u000f\bk\u001a\u0016\u0010\u000b\u0015\u00115\u000f\u0018p\u001f\u0014\u0011/)\u0006\n\u001d27\u0017v\n\n\u001d27\u0017v!\u000b\u00168\n\u000f\u0019#\u000f\u0017g\u0017\u0005\u0010/\n\u000f\u00115\u000f\u001eq\u000e\u0007\u001b/").length();
        int n3 = 10;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 42));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0252: {
                            if (length > 1) {
                                break Label_0252;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 72;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 82;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 113;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 122;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 85;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 40;
                                        break;
                                    }
                                    default: {
                                        n11 = 84;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0024;
                            }
                            n2 = (s = "\u0016\u0012<'\u0014^\u0014\u000f\u0018\u0005\u0016\u0012<'\u0014").length();
                            n3 = 9;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 41)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[3], "x", "y", array2[13], array2[8], array2[6], array2[1], array2[5], array2[10], array2[12], array2[9], array2[11], array2[4], array2[0], array2[2], array2[7]);
    }
}
