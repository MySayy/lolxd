// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.NativeLong;
import com.sun.jna.ptr.ByReference;

public class X11$WindowByReference extends ByReference
{
    public X11$WindowByReference() {
        super(X11$XID.SIZE);
    }
    
    public X11$Window getValue() {
        final NativeLong nativeLong = this.getPointer().getNativeLong(0L);
        try {
            if (nativeLong.longValue() == 0L) {
                return X11$Window.None;
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
        return new X11$Window(nativeLong.longValue());
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
