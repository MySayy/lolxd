// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.NativeLong;
import com.sun.jna.Union;

public class X11$XClientMessageEvent$Data extends Union
{
    public byte[] b;
    public short[] s;
    public NativeLong[] l;
    
    public X11$XClientMessageEvent$Data() {
        this.b = new byte[20];
        this.s = new short[10];
        this.l = new NativeLong[5];
    }
}
