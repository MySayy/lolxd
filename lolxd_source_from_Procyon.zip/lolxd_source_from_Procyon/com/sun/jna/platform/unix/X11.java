// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.Native;
import com.sun.jna.ptr.NativeLongByReference;
import com.sun.jna.NativeLong;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.PointerByReference;
import com.sun.jna.Pointer;
import com.sun.jna.Library;

public interface X11 extends Library
{
    public static final X11 INSTANCE = Native.loadLibrary(new String(charArray).intern(), X11.class);
    public static final int XK_0 = 48;
    public static final int XK_9 = 57;
    public static final int XK_A = 65;
    public static final int XK_Z = 90;
    public static final int XK_a = 97;
    public static final int XK_z = 122;
    public static final int XK_Shift_L = 65505;
    public static final int XK_Shift_R = 65505;
    public static final int XK_Control_L = 65507;
    public static final int XK_Control_R = 65508;
    public static final int XK_CapsLock = 65509;
    public static final int XK_ShiftLock = 65510;
    public static final int XK_Meta_L = 65511;
    public static final int XK_Meta_R = 65512;
    public static final int XK_Alt_L = 65513;
    public static final int XK_Alt_R = 65514;
    public static final int VisualNoMask = 0;
    public static final int VisualIDMask = 1;
    public static final int VisualScreenMask = 2;
    public static final int VisualDepthMask = 4;
    public static final int VisualClassMask = 8;
    public static final int VisualRedMaskMask = 16;
    public static final int VisualGreenMaskMask = 32;
    public static final int VisualBlueMaskMask = 64;
    public static final int VisualColormapSizeMask = 128;
    public static final int VisualBitsPerRGBMask = 256;
    public static final int VisualAllMask = 511;
    public static final X11$Atom XA_PRIMARY = new X11$Atom(1L);
    public static final X11$Atom XA_SECONDARY = new X11$Atom(2L);
    public static final X11$Atom XA_ARC = new X11$Atom(3L);
    public static final X11$Atom XA_ATOM = new X11$Atom(4L);
    public static final X11$Atom XA_BITMAP = new X11$Atom(5L);
    public static final X11$Atom XA_CARDINAL = new X11$Atom(6L);
    public static final X11$Atom XA_COLORMAP = new X11$Atom(7L);
    public static final X11$Atom XA_CURSOR = new X11$Atom(8L);
    public static final X11$Atom XA_CUT_BUFFER0 = new X11$Atom(9L);
    public static final X11$Atom XA_CUT_BUFFER1 = new X11$Atom(10L);
    public static final X11$Atom XA_CUT_BUFFER2 = new X11$Atom(11L);
    public static final X11$Atom XA_CUT_BUFFER3 = new X11$Atom(12L);
    public static final X11$Atom XA_CUT_BUFFER4 = new X11$Atom(13L);
    public static final X11$Atom XA_CUT_BUFFER5 = new X11$Atom(14L);
    public static final X11$Atom XA_CUT_BUFFER6 = new X11$Atom(15L);
    public static final X11$Atom XA_CUT_BUFFER7 = new X11$Atom(16L);
    public static final X11$Atom XA_DRAWABLE = new X11$Atom(17L);
    public static final X11$Atom XA_FONT = new X11$Atom(18L);
    public static final X11$Atom XA_INTEGER = new X11$Atom(19L);
    public static final X11$Atom XA_PIXMAP = new X11$Atom(20L);
    public static final X11$Atom XA_POINT = new X11$Atom(21L);
    public static final X11$Atom XA_RECTANGLE = new X11$Atom(22L);
    public static final X11$Atom XA_RESOURCE_MANAGER = new X11$Atom(23L);
    public static final X11$Atom XA_RGB_COLOR_MAP = new X11$Atom(24L);
    public static final X11$Atom XA_RGB_BEST_MAP = new X11$Atom(25L);
    public static final X11$Atom XA_RGB_BLUE_MAP = new X11$Atom(26L);
    public static final X11$Atom XA_RGB_DEFAULT_MAP = new X11$Atom(27L);
    public static final X11$Atom XA_RGB_GRAY_MAP = new X11$Atom(28L);
    public static final X11$Atom XA_RGB_GREEN_MAP = new X11$Atom(29L);
    public static final X11$Atom XA_RGB_RED_MAP = new X11$Atom(30L);
    public static final X11$Atom XA_STRING = new X11$Atom(31L);
    public static final X11$Atom XA_VISUALID = new X11$Atom(32L);
    public static final X11$Atom XA_WINDOW = new X11$Atom(33L);
    public static final X11$Atom XA_WM_COMMAND = new X11$Atom(34L);
    public static final X11$Atom XA_WM_HINTS = new X11$Atom(35L);
    public static final X11$Atom XA_WM_CLIENT_MACHINE = new X11$Atom(36L);
    public static final X11$Atom XA_WM_ICON_NAME = new X11$Atom(37L);
    public static final X11$Atom XA_WM_ICON_SIZE = new X11$Atom(38L);
    public static final X11$Atom XA_WM_NAME = new X11$Atom(39L);
    public static final X11$Atom XA_WM_NORMAL_HINTS = new X11$Atom(40L);
    public static final X11$Atom XA_WM_SIZE_HINTS = new X11$Atom(41L);
    public static final X11$Atom XA_WM_ZOOM_HINTS = new X11$Atom(42L);
    public static final X11$Atom XA_MIN_SPACE = new X11$Atom(43L);
    public static final X11$Atom XA_NORM_SPACE = new X11$Atom(44L);
    public static final X11$Atom XA_MAX_SPACE = new X11$Atom(45L);
    public static final X11$Atom XA_END_SPACE = new X11$Atom(46L);
    public static final X11$Atom XA_SUPERSCRIPT_X = new X11$Atom(47L);
    public static final X11$Atom XA_SUPERSCRIPT_Y = new X11$Atom(48L);
    public static final X11$Atom XA_SUBSCRIPT_X = new X11$Atom(49L);
    public static final X11$Atom XA_SUBSCRIPT_Y = new X11$Atom(50L);
    public static final X11$Atom XA_UNDERLINE_POSITION = new X11$Atom(51L);
    public static final X11$Atom XA_UNDERLINE_THICKNESS = new X11$Atom(52L);
    public static final X11$Atom XA_STRIKEOUT_ASCENT = new X11$Atom(53L);
    public static final X11$Atom XA_STRIKEOUT_DESCENT = new X11$Atom(54L);
    public static final X11$Atom XA_ITALIC_ANGLE = new X11$Atom(55L);
    public static final X11$Atom XA_X_HEIGHT = new X11$Atom(56L);
    public static final X11$Atom XA_QUAD_WIDTH = new X11$Atom(57L);
    public static final X11$Atom XA_WEIGHT = new X11$Atom(58L);
    public static final X11$Atom XA_POINT_SIZE = new X11$Atom(59L);
    public static final X11$Atom XA_RESOLUTION = new X11$Atom(60L);
    public static final X11$Atom XA_COPYRIGHT = new X11$Atom(61L);
    public static final X11$Atom XA_NOTICE = new X11$Atom(62L);
    public static final X11$Atom XA_FONT_NAME = new X11$Atom(63L);
    public static final X11$Atom XA_FAMILY_NAME = new X11$Atom(64L);
    public static final X11$Atom XA_FULL_NAME = new X11$Atom(65L);
    public static final X11$Atom XA_CAP_HEIGHT = new X11$Atom(66L);
    public static final X11$Atom XA_WM_CLASS = new X11$Atom(67L);
    public static final X11$Atom XA_WM_TRANSIENT_FOR = new X11$Atom(68L);
    public static final X11$Atom XA_LAST_PREDEFINED = X11.XA_WM_TRANSIENT_FOR;
    public static final int None = 0;
    public static final int ParentRelative = 1;
    public static final int CopyFromParent = 0;
    public static final int PointerWindow = 0;
    public static final int InputFocus = 1;
    public static final int PointerRoot = 1;
    public static final int AnyPropertyType = 0;
    public static final int AnyKey = 0;
    public static final int AnyButton = 0;
    public static final int AllTemporary = 0;
    public static final int CurrentTime = 0;
    public static final int NoSymbol = 0;
    public static final int NoEventMask = 0;
    public static final int KeyPressMask = 1;
    public static final int KeyReleaseMask = 2;
    public static final int ButtonPressMask = 4;
    public static final int ButtonReleaseMask = 8;
    public static final int EnterWindowMask = 16;
    public static final int LeaveWindowMask = 32;
    public static final int PointerMotionMask = 64;
    public static final int PointerMotionHintMask = 128;
    public static final int Button1MotionMask = 256;
    public static final int Button2MotionMask = 512;
    public static final int Button3MotionMask = 1024;
    public static final int Button4MotionMask = 2048;
    public static final int Button5MotionMask = 4096;
    public static final int ButtonMotionMask = 8192;
    public static final int KeymapStateMask = 16384;
    public static final int ExposureMask = 32768;
    public static final int VisibilityChangeMask = 65536;
    public static final int StructureNotifyMask = 131072;
    public static final int ResizeRedirectMask = 262144;
    public static final int SubstructureNotifyMask = 524288;
    public static final int SubstructureRedirectMask = 1048576;
    public static final int FocusChangeMask = 2097152;
    public static final int PropertyChangeMask = 4194304;
    public static final int ColormapChangeMask = 8388608;
    public static final int OwnerGrabButtonMask = 16777216;
    public static final int KeyPress = 2;
    public static final int KeyRelease = 3;
    public static final int ButtonPress = 4;
    public static final int ButtonRelease = 5;
    public static final int MotionNotify = 6;
    public static final int EnterNotify = 7;
    public static final int LeaveNotify = 8;
    public static final int FocusIn = 9;
    public static final int FocusOut = 10;
    public static final int KeymapNotify = 11;
    public static final int Expose = 12;
    public static final int GraphicsExpose = 13;
    public static final int NoExpose = 14;
    public static final int VisibilityNotify = 15;
    public static final int CreateNotify = 16;
    public static final int DestroyNotify = 17;
    public static final int UnmapNotify = 18;
    public static final int MapNotify = 19;
    public static final int MapRequest = 20;
    public static final int ReparentNotify = 21;
    public static final int ConfigureNotify = 22;
    public static final int ConfigureRequest = 23;
    public static final int GravityNotify = 24;
    public static final int ResizeRequest = 25;
    public static final int CirculateNotify = 26;
    public static final int CirculateRequest = 27;
    public static final int PropertyNotify = 28;
    public static final int SelectionClear = 29;
    public static final int SelectionRequest = 30;
    public static final int SelectionNotify = 31;
    public static final int ColormapNotify = 32;
    public static final int ClientMessage = 33;
    public static final int MappingNotify = 34;
    public static final int LASTEvent = 35;
    public static final int ShiftMask = 1;
    public static final int LockMask = 2;
    public static final int ControlMask = 4;
    public static final int Mod1Mask = 8;
    public static final int Mod2Mask = 16;
    public static final int Mod3Mask = 32;
    public static final int Mod4Mask = 64;
    public static final int Mod5Mask = 128;
    public static final int ShiftMapIndex = 0;
    public static final int LockMapIndex = 1;
    public static final int ControlMapIndex = 2;
    public static final int Mod1MapIndex = 3;
    public static final int Mod2MapIndex = 4;
    public static final int Mod3MapIndex = 5;
    public static final int Mod4MapIndex = 6;
    public static final int Mod5MapIndex = 7;
    public static final int Button1Mask = 256;
    public static final int Button2Mask = 512;
    public static final int Button3Mask = 1024;
    public static final int Button4Mask = 2048;
    public static final int Button5Mask = 4096;
    public static final int AnyModifier = 32768;
    public static final int Button1 = 1;
    public static final int Button2 = 2;
    public static final int Button3 = 3;
    public static final int Button4 = 4;
    public static final int Button5 = 5;
    public static final int NotifyNormal = 0;
    public static final int NotifyGrab = 1;
    public static final int NotifyUngrab = 2;
    public static final int NotifyWhileGrabbed = 3;
    public static final int NotifyHint = 1;
    public static final int NotifyAncestor = 0;
    public static final int NotifyVirtual = 1;
    public static final int NotifyInferior = 2;
    public static final int NotifyNonlinear = 3;
    public static final int NotifyNonlinearVirtual = 4;
    public static final int NotifyPointer = 5;
    public static final int NotifyPointerRoot = 6;
    public static final int NotifyDetailNone = 7;
    public static final int VisibilityUnobscured = 0;
    public static final int VisibilityPartiallyObscured = 1;
    public static final int VisibilityFullyObscured = 2;
    public static final int PlaceOnTop = 0;
    public static final int PlaceOnBottom = 1;
    public static final int FamilyInternet = 0;
    public static final int FamilyDECnet = 1;
    public static final int FamilyChaos = 2;
    public static final int FamilyInternet6 = 6;
    public static final int FamilyServerInterpreted = 5;
    public static final int PropertyNewValue = 0;
    public static final int PropertyDelete = 1;
    public static final int ColormapUninstalled = 0;
    public static final int ColormapInstalled = 1;
    public static final int GrabModeSync = 0;
    public static final int GrabModeAsync = 1;
    public static final int GrabSuccess = 0;
    public static final int AlreadyGrabbed = 1;
    public static final int GrabInvalidTime = 2;
    public static final int GrabNotViewable = 3;
    public static final int GrabFrozen = 4;
    public static final int AsyncPointer = 0;
    public static final int SyncPointer = 1;
    public static final int ReplayPointer = 2;
    public static final int AsyncKeyboard = 3;
    public static final int SyncKeyboard = 4;
    public static final int ReplayKeyboard = 5;
    public static final int AsyncBoth = 6;
    public static final int SyncBoth = 7;
    public static final int RevertToNone = 0;
    public static final int RevertToPointerRoot = 1;
    public static final int RevertToParent = 2;
    public static final int Success = 0;
    public static final int BadRequest = 1;
    public static final int BadValue = 2;
    public static final int BadWindow = 3;
    public static final int BadPixmap = 4;
    public static final int BadAtom = 5;
    public static final int BadCursor = 6;
    public static final int BadFont = 7;
    public static final int BadMatch = 8;
    public static final int BadDrawable = 9;
    public static final int BadAccess = 10;
    public static final int BadAlloc = 11;
    public static final int BadColor = 12;
    public static final int BadGC = 13;
    public static final int BadIDChoice = 14;
    public static final int BadName = 15;
    public static final int BadLength = 16;
    public static final int BadImplementation = 17;
    public static final int FirstExtensionError = 128;
    public static final int LastExtensionError = 255;
    public static final int InputOutput = 1;
    public static final int InputOnly = 2;
    public static final int CWBackPixmap = 1;
    public static final int CWBackPixel = 2;
    public static final int CWBorderPixmap = 4;
    public static final int CWBorderPixel = 8;
    public static final int CWBitGravity = 16;
    public static final int CWWinGravity = 32;
    public static final int CWBackingStore = 64;
    public static final int CWBackingPlanes = 128;
    public static final int CWBackingPixel = 256;
    public static final int CWOverrideRedirect = 512;
    public static final int CWSaveUnder = 1024;
    public static final int CWEventMask = 2048;
    public static final int CWDontPropagate = 4096;
    public static final int CWColormap = 8192;
    public static final int CWCursor = 16384;
    public static final int CWX = 1;
    public static final int CWY = 2;
    public static final int CWWidth = 4;
    public static final int CWHeight = 8;
    public static final int CWBorderWidth = 16;
    public static final int CWSibling = 32;
    public static final int CWStackMode = 64;
    public static final int ForgetGravity = 0;
    public static final int NorthWestGravity = 1;
    public static final int NorthGravity = 2;
    public static final int NorthEastGravity = 3;
    public static final int WestGravity = 4;
    public static final int CenterGravity = 5;
    public static final int EastGravity = 6;
    public static final int SouthWestGravity = 7;
    public static final int SouthGravity = 8;
    public static final int SouthEastGravity = 9;
    public static final int StaticGravity = 10;
    public static final int UnmapGravity = 0;
    public static final int NotUseful = 0;
    public static final int WhenMapped = 1;
    public static final int Always = 2;
    public static final int IsUnmapped = 0;
    public static final int IsUnviewable = 1;
    public static final int IsViewable = 2;
    public static final int SetModeInsert = 0;
    public static final int SetModeDelete = 1;
    public static final int DestroyAll = 0;
    public static final int RetainPermanent = 1;
    public static final int RetainTemporary = 2;
    public static final int Above = 0;
    public static final int Below = 1;
    public static final int TopIf = 2;
    public static final int BottomIf = 3;
    public static final int Opposite = 4;
    public static final int RaiseLowest = 0;
    public static final int LowerHighest = 1;
    public static final int PropModeReplace = 0;
    public static final int PropModePrepend = 1;
    public static final int PropModeAppend = 2;
    public static final int GXclear = 0;
    public static final int GXand = 1;
    public static final int GXandReverse = 2;
    public static final int GXcopy = 3;
    public static final int GXandInverted = 4;
    public static final int GXnoop = 5;
    public static final int GXxor = 6;
    public static final int GXor = 7;
    public static final int GXnor = 8;
    public static final int GXequiv = 9;
    public static final int GXinvert = 10;
    public static final int GXorReverse = 11;
    public static final int GXcopyInverted = 12;
    public static final int GXorInverted = 13;
    public static final int GXnand = 14;
    public static final int GXset = 15;
    public static final int LineSolid = 0;
    public static final int LineOnOffDash = 1;
    public static final int LineDoubleDash = 2;
    public static final int CapNotLast = 0;
    public static final int CapButt = 1;
    public static final int CapRound = 2;
    public static final int CapProjecting = 3;
    public static final int JoinMiter = 0;
    public static final int JoinRound = 1;
    public static final int JoinBevel = 2;
    public static final int FillSolid = 0;
    public static final int FillTiled = 1;
    public static final int FillStippled = 2;
    public static final int FillOpaqueStippled = 3;
    public static final int EvenOddRule = 0;
    public static final int WindingRule = 1;
    public static final int ClipByChildren = 0;
    public static final int IncludeInferiors = 1;
    public static final int Unsorted = 0;
    public static final int YSorted = 1;
    public static final int YXSorted = 2;
    public static final int YXBanded = 3;
    public static final int CoordModeOrigin = 0;
    public static final int CoordModePrevious = 1;
    public static final int Complex = 0;
    public static final int Nonconvex = 1;
    public static final int Convex = 2;
    public static final int ArcChord = 0;
    public static final int ArcPieSlice = 1;
    public static final int GCFunction = 1;
    public static final int GCPlaneMask = 2;
    public static final int GCForeground = 4;
    public static final int GCBackground = 8;
    public static final int GCLineWidth = 16;
    public static final int GCLineStyle = 32;
    public static final int GCCapStyle = 64;
    public static final int GCJoinStyle = 128;
    public static final int GCFillStyle = 256;
    public static final int GCFillRule = 512;
    public static final int GCTile = 1024;
    public static final int GCStipple = 2048;
    public static final int GCTileStipXOrigin = 4096;
    public static final int GCTileStipYOrigin = 8192;
    public static final int GCFont = 16384;
    public static final int GCSubwindowMode = 32768;
    public static final int GCGraphicsExposures = 65536;
    public static final int GCClipXOrigin = 131072;
    public static final int GCClipYOrigin = 262144;
    public static final int GCClipMask = 524288;
    public static final int GCDashOffset = 1048576;
    public static final int GCDashList = 2097152;
    public static final int GCArcMode = 4194304;
    public static final int GCLastBit = 22;
    public static final int FontLeftToRight = 0;
    public static final int FontRightToLeft = 1;
    public static final int FontChange = 255;
    public static final int XYBitmap = 0;
    public static final int XYPixmap = 1;
    public static final int ZPixmap = 2;
    public static final int AllocNone = 0;
    public static final int AllocAll = 1;
    public static final int DoRed = 1;
    public static final int DoGreen = 2;
    public static final int DoBlue = 4;
    public static final int CursorShape = 0;
    public static final int TileShape = 1;
    public static final int StippleShape = 2;
    public static final int AutoRepeatModeOff = 0;
    public static final int AutoRepeatModeOn = 1;
    public static final int AutoRepeatModeDefault = 2;
    public static final int LedModeOff = 0;
    public static final int LedModeOn = 1;
    public static final int KBKeyClickPercent = 1;
    public static final int KBBellPercent = 2;
    public static final int KBBellPitch = 4;
    public static final int KBBellDuration = 8;
    public static final int KBLed = 16;
    public static final int KBLedMode = 32;
    public static final int KBKey = 64;
    public static final int KBAutoRepeatMode = 128;
    public static final int MappingSuccess = 0;
    public static final int MappingBusy = 1;
    public static final int MappingFailed = 2;
    public static final int MappingModifier = 0;
    public static final int MappingKeyboard = 1;
    public static final int MappingPointer = 2;
    public static final int DontPreferBlanking = 0;
    public static final int PreferBlanking = 1;
    public static final int DefaultBlanking = 2;
    public static final int DisableScreenSaver = 0;
    public static final int DisableScreenInterval = 0;
    public static final int DontAllowExposures = 0;
    public static final int AllowExposures = 1;
    public static final int DefaultExposures = 2;
    public static final int ScreenSaverReset = 0;
    public static final int ScreenSaverActive = 1;
    public static final int HostInsert = 0;
    public static final int HostDelete = 1;
    public static final int EnableAccess = 1;
    public static final int DisableAccess = 0;
    public static final int StaticGray = 0;
    public static final int GrayScale = 1;
    public static final int StaticColor = 2;
    public static final int PseudoColor = 3;
    public static final int TrueColor = 4;
    public static final int DirectColor = 5;
    public static final int LSBFirst = 0;
    public static final int MSBFirst = 1;
    
    X11$Display XOpenDisplay(final String p0);
    
    int XGetErrorText(final X11$Display p0, final int p1, final byte[] p2, final int p3);
    
    int XDefaultScreen(final X11$Display p0);
    
    X11$Screen DefaultScreenOfDisplay(final X11$Display p0);
    
    X11$Visual XDefaultVisual(final X11$Display p0, final int p1);
    
    X11$Colormap XDefaultColormap(final X11$Display p0, final int p1);
    
    int XDisplayWidth(final X11$Display p0, final int p1);
    
    int XDisplayHeight(final X11$Display p0, final int p1);
    
    X11$Window XDefaultRootWindow(final X11$Display p0);
    
    X11$Window XRootWindow(final X11$Display p0, final int p1);
    
    int XAllocNamedColor(final X11$Display p0, final int p1, final String p2, final Pointer p3, final Pointer p4);
    
    X11$XSizeHints XAllocSizeHints();
    
    void XSetWMProperties(final X11$Display p0, final X11$Window p1, final String p2, final String p3, final String[] p4, final int p5, final X11$XSizeHints p6, final Pointer p7, final Pointer p8);
    
    int XSetWMProtocols(final X11$Display p0, final X11$Window p1, final X11$Atom[] p2, final int p3);
    
    int XGetWMProtocols(final X11$Display p0, final X11$Window p1, final PointerByReference p2, final IntByReference p3);
    
    int XFree(final Pointer p0);
    
    X11$Window XCreateSimpleWindow(final X11$Display p0, final X11$Window p1, final int p2, final int p3, final int p4, final int p5, final int p6, final int p7, final int p8);
    
    X11$Pixmap XCreateBitmapFromData(final X11$Display p0, final X11$Window p1, final Pointer p2, final int p3, final int p4);
    
    int XMapWindow(final X11$Display p0, final X11$Window p1);
    
    int XMapRaised(final X11$Display p0, final X11$Window p1);
    
    int XMapSubwindows(final X11$Display p0, final X11$Window p1);
    
    int XFlush(final X11$Display p0);
    
    int XSync(final X11$Display p0, final boolean p1);
    
    int XEventsQueued(final X11$Display p0, final int p1);
    
    int XPending(final X11$Display p0);
    
    int XUnmapWindow(final X11$Display p0, final X11$Window p1);
    
    int XDestroyWindow(final X11$Display p0, final X11$Window p1);
    
    int XCloseDisplay(final X11$Display p0);
    
    int XClearWindow(final X11$Display p0, final X11$Window p1);
    
    int XClearArea(final X11$Display p0, final X11$Window p1, final int p2, final int p3, final int p4, final int p5, final int p6);
    
    X11$Pixmap XCreatePixmap(final X11$Display p0, final X11$Drawable p1, final int p2, final int p3, final int p4);
    
    int XFreePixmap(final X11$Display p0, final X11$Pixmap p1);
    
    X11$GC XCreateGC(final X11$Display p0, final X11$Drawable p1, final NativeLong p2, final X11$XGCValues p3);
    
    int XSetFillRule(final X11$Display p0, final X11$GC p1, final int p2);
    
    int XFreeGC(final X11$Display p0, final X11$GC p1);
    
    int XDrawPoint(final X11$Display p0, final X11$Drawable p1, final X11$GC p2, final int p3, final int p4);
    
    int XDrawPoints(final X11$Display p0, final X11$Drawable p1, final X11$GC p2, final X11$XPoint[] p3, final int p4, final int p5);
    
    int XFillRectangle(final X11$Display p0, final X11$Drawable p1, final X11$GC p2, final int p3, final int p4, final int p5, final int p6);
    
    int XFillRectangles(final X11$Display p0, final X11$Drawable p1, final X11$GC p2, final X11$XRectangle[] p3, final int p4);
    
    int XSetForeground(final X11$Display p0, final X11$GC p1, final NativeLong p2);
    
    int XSetBackground(final X11$Display p0, final X11$GC p1, final NativeLong p2);
    
    int XFillArc(final X11$Display p0, final X11$Drawable p1, final X11$GC p2, final int p3, final int p4, final int p5, final int p6, final int p7, final int p8);
    
    int XFillPolygon(final X11$Display p0, final X11$Drawable p1, final X11$GC p2, final X11$XPoint[] p3, final int p4, final int p5, final int p6);
    
    int XQueryTree(final X11$Display p0, final X11$Window p1, final X11$WindowByReference p2, final X11$WindowByReference p3, final PointerByReference p4, final IntByReference p5);
    
    boolean XQueryPointer(final X11$Display p0, final X11$Window p1, final X11$WindowByReference p2, final X11$WindowByReference p3, final IntByReference p4, final IntByReference p5, final IntByReference p6, final IntByReference p7, final IntByReference p8);
    
    int XGetWindowAttributes(final X11$Display p0, final X11$Window p1, final X11$XWindowAttributes p2);
    
    int XChangeWindowAttributes(final X11$Display p0, final X11$Window p1, final NativeLong p2, final X11$XSetWindowAttributes p3);
    
    int XGetGeometry(final X11$Display p0, final X11$Drawable p1, final X11$WindowByReference p2, final IntByReference p3, final IntByReference p4, final IntByReference p5, final IntByReference p6, final IntByReference p7, final IntByReference p8);
    
    boolean XTranslateCoordinates(final X11$Display p0, final X11$Window p1, final X11$Window p2, final int p3, final int p4, final IntByReference p5, final IntByReference p6, final X11$WindowByReference p7);
    
    int XSelectInput(final X11$Display p0, final X11$Window p1, final NativeLong p2);
    
    int XSendEvent(final X11$Display p0, final X11$Window p1, final int p2, final NativeLong p3, final X11$XEvent p4);
    
    int XNextEvent(final X11$Display p0, final X11$XEvent p1);
    
    int XPeekEvent(final X11$Display p0, final X11$XEvent p1);
    
    int XWindowEvent(final X11$Display p0, final X11$Window p1, final NativeLong p2, final X11$XEvent p3);
    
    boolean XCheckWindowEvent(final X11$Display p0, final X11$Window p1, final NativeLong p2, final X11$XEvent p3);
    
    int XMaskEvent(final X11$Display p0, final NativeLong p1, final X11$XEvent p2);
    
    boolean XCheckMaskEvent(final X11$Display p0, final NativeLong p1, final X11$XEvent p2);
    
    boolean XCheckTypedEvent(final X11$Display p0, final int p1, final X11$XEvent p2);
    
    boolean XCheckTypedWindowEvent(final X11$Display p0, final X11$Window p1, final int p2, final X11$XEvent p3);
    
    X11$XWMHints XGetWMHints(final X11$Display p0, final X11$Window p1);
    
    int XGetWMName(final X11$Display p0, final X11$Window p1, final X11$XTextProperty p2);
    
    X11$XVisualInfo XGetVisualInfo(final X11$Display p0, final NativeLong p1, final X11$XVisualInfo p2, final IntByReference p3);
    
    X11$Colormap XCreateColormap(final X11$Display p0, final X11$Window p1, final X11$Visual p2, final int p3);
    
    int XGetWindowProperty(final X11$Display p0, final X11$Window p1, final X11$Atom p2, final NativeLong p3, final NativeLong p4, final boolean p5, final X11$Atom p6, final X11$AtomByReference p7, final IntByReference p8, final NativeLongByReference p9, final NativeLongByReference p10, final PointerByReference p11);
    
    int XChangeProperty(final X11$Display p0, final X11$Window p1, final X11$Atom p2, final X11$Atom p3, final int p4, final int p5, final Pointer p6, final int p7);
    
    int XDeleteProperty(final X11$Display p0, final X11$Window p1, final X11$Atom p2);
    
    X11$Atom XInternAtom(final X11$Display p0, final String p1, final boolean p2);
    
    String XGetAtomName(final X11$Display p0, final X11$Atom p1);
    
    int XCopyArea(final X11$Display p0, final X11$Drawable p1, final X11$Drawable p2, final X11$GC p3, final int p4, final int p5, final int p6, final int p7, final int p8, final int p9);
    
    X11$XImage XCreateImage(final X11$Display p0, final X11$Visual p1, final int p2, final int p3, final int p4, final Pointer p5, final int p6, final int p7, final int p8, final int p9);
    
    int XPutImage(final X11$Display p0, final X11$Drawable p1, final X11$GC p2, final X11$XImage p3, final int p4, final int p5, final int p6, final int p7, final int p8, final int p9);
    
    int XDestroyImage(final X11$XImage p0);
    
    X11$XErrorHandler XSetErrorHandler(final X11$XErrorHandler p0);
    
    String XKeysymToString(final X11$KeySym p0);
    
    X11$KeySym XStringToKeysym(final String p0);
    
    byte XKeysymToKeycode(final X11$Display p0, final X11$KeySym p1);
    
    X11$KeySym XKeycodeToKeysym(final X11$Display p0, final byte p1, final int p2);
    
    int XGrabKey(final X11$Display p0, final int p1, final int p2, final X11$Window p3, final int p4, final int p5, final int p6);
    
    int XUngrabKey(final X11$Display p0, final int p1, final int p2, final X11$Window p3);
    
    int XGrabKeyboard(final X11$Display p0, final X11$Window p1, final int p2, final int p3, final int p4, final NativeLong p5);
    
    int XUngrabKeyboard(final X11$Display p0, final NativeLong p1);
    
    int XFetchName(final X11$Display p0, final X11$Window p1, final PointerByReference p2);
    
    int XChangeKeyboardMapping(final X11$Display p0, final int p1, final int p2, final X11$KeySym[] p3, final int p4);
    
    X11$KeySym XGetKeyboardMapping(final X11$Display p0, final byte p1, final int p2, final IntByReference p3);
    
    int XDisplayKeycodes(final X11$Display p0, final IntByReference p1, final IntByReference p2);
    
    int XSetModifierMapping(final X11$Display p0, final X11$XModifierKeymapRef p1);
    
    X11$XModifierKeymapRef XGetModifierMapping(final X11$Display p0);
    
    X11$XModifierKeymapRef XNewModifiermap(final int p0);
    
    X11$XModifierKeymapRef XInsertModifiermapEntry(final X11$XModifierKeymapRef p0, final byte p1, final int p2);
    
    X11$XModifierKeymapRef XDeleteModifiermapEntry(final X11$XModifierKeymapRef p0, final byte p1, final int p2);
    
    int XFreeModifiermap(final X11$XModifierKeymapRef p0);
    
    int XChangeKeyboardControl(final X11$Display p0, final NativeLong p1, final X11$XKeyboardControlRef p2);
    
    int XGetKeyboardControl(final X11$Display p0, final X11$XKeyboardStateRef p1);
    
    int XAutoRepeatOn(final X11$Display p0);
    
    int XAutoRepeatOff(final X11$Display p0);
    
    int XBell(final X11$Display p0, final int p1);
    
    int XQueryKeymap(final X11$Display p0, final byte[] p1);
    
    default static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 36);
        final char[] charArray = "b\u0006e".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 30;
                            break;
                        }
                        case 1: {
                            n5 = 19;
                            break;
                        }
                        case 2: {
                            n5 = 112;
                            break;
                        }
                        case 3: {
                            n5 = 108;
                            break;
                        }
                        case 4: {
                            n5 = 19;
                            break;
                        }
                        case 5: {
                            n5 = 111;
                            break;
                        }
                        default: {
                            n5 = 26;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                return;
            }
            continue;
        }
    }
}
