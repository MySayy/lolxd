// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform.unix;

import com.sun.jna.NativeLong;
import java.util.List;
import com.sun.jna.Structure;

public class X11$XTextProperty extends Structure
{
    public static final List<String> FIELDS;
    public String value;
    public X11$Atom encoding;
    public int format;
    public NativeLong nitems;
    
    @Override
    protected List<String> getFieldOrder() {
        return X11$XTextProperty.FIELDS;
    }
    
    static {
        final String[] array = new String[4];
        int n = 0;
        String s;
        int n2 = (s = "dqna)l\u0006lwhi%k").length();
        int n3 = 6;
        int n4 = -1;
    Label_0023:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 77));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0251: {
                            if (length > 1) {
                                break Label_0251;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 79;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 83;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 81;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 65;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 5;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 85;
                                        break;
                                    }
                                    default: {
                                        n11 = 124;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0023;
                            }
                            n2 = (s = "\u0013\u0018\u0017\u001eJ\b\u0000\u0017\u0018\u0004K\u00168\u0002").length();
                            n3 = 5;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0023;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 42)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        FIELDS = Structure.createFieldsOrder(array2[2], array2[3], array2[0], array2[1]);
    }
}
