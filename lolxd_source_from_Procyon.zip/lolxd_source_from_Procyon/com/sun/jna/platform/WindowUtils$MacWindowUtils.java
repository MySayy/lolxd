// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna.platform;

import java.awt.Shape;
import java.awt.Rectangle;
import java.awt.image.Raster;
import java.awt.Container;
import java.awt.Component;
import javax.swing.RootPaneContainer;
import java.awt.Window;

class WindowUtils$MacWindowUtils extends WindowUtils$NativeWindowUtils
{
    private static final String WDRAG;
    private static final String[] d;
    private static final String[] e;
    
    private WindowUtils$MacWindowUtils() {
    }
    
    @Override
    public boolean isWindowAlphaSupported() {
        return true;
    }
    
    private WindowUtils$MacWindowUtils$OSXMaskingContentPane installMaskingPane(final Window window) {
        final int[] b = WindowUtils$NativeWindowUtils.b();
        Component component = null;
        Label_0144: {
            Label_0147: {
                Label_0129: {
                    int n = 0;
                    Label_0092: {
                        try {
                            n = ((window instanceof RootPaneContainer) ? 1 : 0);
                            if (b != null) {
                                break Label_0129;
                            }
                            if (n == 0) {
                                break Label_0092;
                            }
                        }
                        catch (RuntimeException ex) {
                            throw b(ex);
                        }
                        Window window2 = window;
                    Label_0062_Outer:
                        while (true) {
                            final RootPaneContainer rootPaneContainer = (RootPaneContainer)window2;
                            final Container contentPane = rootPaneContainer.getContentPane();
                            Container container;
                            final WindowUtils$MacWindowUtils$OSXMaskingContentPane windowUtils$MacWindowUtils$OSXMaskingContentPane = (WindowUtils$MacWindowUtils$OSXMaskingContentPane)(container = contentPane);
                            Label_0088: {
                                WindowUtils$MacWindowUtils$OSXMaskingContentPane windowUtils$MacWindowUtils$OSXMaskingContentPane2;
                                while (true) {
                                    Label_0066: {
                                        if (b == null) {
                                            try {
                                                if (!(windowUtils$MacWindowUtils$OSXMaskingContentPane instanceof WindowUtils$MacWindowUtils$OSXMaskingContentPane)) {
                                                    break Label_0066;
                                                }
                                                container = contentPane;
                                            }
                                            catch (RuntimeException ex2) {
                                                throw b(ex2);
                                            }
                                        }
                                        windowUtils$MacWindowUtils$OSXMaskingContentPane2 = (WindowUtils$MacWindowUtils$OSXMaskingContentPane)container;
                                        if (b == null) {
                                            break Label_0088;
                                        }
                                    }
                                    windowUtils$MacWindowUtils$OSXMaskingContentPane2 = new WindowUtils$MacWindowUtils$OSXMaskingContentPane(contentPane);
                                    if (b != null) {
                                        continue;
                                    }
                                    break;
                                }
                                rootPaneContainer.setContentPane(windowUtils$MacWindowUtils$OSXMaskingContentPane2);
                                try {
                                    if (b == null) {
                                        return windowUtils$MacWindowUtils$OSXMaskingContentPane2;
                                    }
                                    component = window;
                                    window2 = window;
                                    if (b != null) {
                                        continue Label_0062_Outer;
                                    }
                                }
                                catch (RuntimeException ex3) {
                                    throw b(ex3);
                                }
                            }
                            break;
                        }
                    }
                    Label_0119: {
                        try {
                            if (b != null) {
                                break Label_0144;
                            }
                            final int[] array = b;
                            if (array == null) {
                                break Label_0119;
                            }
                            break Label_0144;
                        }
                        catch (RuntimeException ex4) {
                            throw b(ex4);
                        }
                        try {
                            final int[] array = b;
                            if (array != null) {
                                break Label_0144;
                            }
                            window.getComponentCount();
                        }
                        catch (RuntimeException ex5) {
                            throw b(ex5);
                        }
                    }
                    try {
                        if (n <= 0) {
                            break Label_0147;
                        }
                        component = window.getComponent(0);
                    }
                    catch (RuntimeException ex6) {
                        throw b(ex6);
                    }
                }
                break Label_0144;
            }
            component = null;
        }
        final Component component2 = component;
        WindowUtils$MacWindowUtils$OSXMaskingContentPane windowUtils$MacWindowUtils$OSXMaskingContentPane2;
        while (true) {
            Label_0186: {
                Component add = null;
                Label_0169: {
                    WindowUtils$MacWindowUtils$OSXMaskingContentPane windowUtils$MacWindowUtils$OSXMaskingContentPane3;
                    try {
                        windowUtils$MacWindowUtils$OSXMaskingContentPane3 = (WindowUtils$MacWindowUtils$OSXMaskingContentPane)(add = component2);
                        if (b != null) {
                            break Label_0178;
                        }
                        final boolean b2 = windowUtils$MacWindowUtils$OSXMaskingContentPane3 instanceof WindowUtils$MacWindowUtils$OSXMaskingContentPane;
                        if (b2) {
                            break Label_0169;
                        }
                        break Label_0186;
                    }
                    catch (RuntimeException ex7) {
                        throw b(ex7);
                    }
                    try {
                        final boolean b2 = windowUtils$MacWindowUtils$OSXMaskingContentPane3 instanceof WindowUtils$MacWindowUtils$OSXMaskingContentPane;
                        if (!b2) {
                            break Label_0186;
                        }
                        add = component2;
                    }
                    catch (RuntimeException ex8) {
                        throw b(ex8);
                    }
                }
                windowUtils$MacWindowUtils$OSXMaskingContentPane2 = (WindowUtils$MacWindowUtils$OSXMaskingContentPane)add;
                if (b == null) {
                    return windowUtils$MacWindowUtils$OSXMaskingContentPane2;
                }
            }
            windowUtils$MacWindowUtils$OSXMaskingContentPane2 = new WindowUtils$MacWindowUtils$OSXMaskingContentPane(component2);
            Component add = window.add(windowUtils$MacWindowUtils$OSXMaskingContentPane2);
            if (b != null) {
                continue;
            }
            break;
        }
        return windowUtils$MacWindowUtils$OSXMaskingContentPane2;
    }
    
    @Override
    public void setWindowTransparent(final Window p0, final boolean p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_3       
        //     4: aload_1        
        //     5: invokevirtual   java/awt/Window.getBackground:()Ljava/awt/Color;
        //     8: aload_3        
        //     9: ifnonnull       44
        //    12: aload_3        
        //    13: ifnonnull       44
        //    16: goto            23
        //    19: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    22: athrow         
        //    23: ifnull          76
        //    26: goto            33
        //    29: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    32: athrow         
        //    33: aload_1        
        //    34: invokevirtual   java/awt/Window.getBackground:()Ljava/awt/Color;
        //    37: goto            44
        //    40: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    43: athrow         
        //    44: invokevirtual   java/awt/Color.getAlpha:()I
        //    47: aload_3        
        //    48: ifnonnull       73
        //    51: aload_3        
        //    52: ifnonnull       73
        //    55: goto            62
        //    58: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    61: athrow         
        //    62: ifne            76
        //    65: goto            72
        //    68: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    71: athrow         
        //    72: iconst_1       
        //    73: goto            77
        //    76: iconst_0       
        //    77: istore          4
        //    79: iload_2        
        //    80: iload           4
        //    82: if_icmpeq       107
        //    85: aload_0        
        //    86: aload_1        
        //    87: iload_2        
        //    88: sipush          18164
        //    91: sipush          -13246
        //    94: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //    97: invokespecial   com/sun/jna/platform/WindowUtils$MacWindowUtils.setBackgroundTransparent:(Ljava/awt/Window;ZLjava/lang/String;)V
        //   100: goto            107
        //   103: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   106: athrow         
        //   107: return         
        //    StackMapTable: 00 0F FF 00 13 00 04 07 00 13 07 00 2A 01 07 00 EB 00 01 07 00 C1 43 07 00 2E 45 07 00 C1 03 46 07 00 C1 43 07 00 2E 4D 07 00 C1 43 01 45 07 00 C1 03 40 01 02 40 01 FF 00 19 00 05 07 00 13 07 00 2A 01 07 00 EB 01 00 01 07 00 C1 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      16     19     23     Ljava/lang/RuntimeException;
        //  12     26     29     33     Ljava/lang/RuntimeException;
        //  23     37     40     44     Ljava/lang/RuntimeException;
        //  44     55     58     62     Ljava/lang/RuntimeException;
        //  51     65     68     72     Ljava/lang/RuntimeException;
        //  79     100    103    107    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0023:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void fixWindowDragging(final Window p0, final String p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_3       
        //     4: aload_1        
        //     5: aload_3        
        //     6: ifnonnull       41
        //     9: aload_3        
        //    10: ifnonnull       41
        //    13: goto            20
        //    16: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    19: athrow         
        //    20: instanceof      Ljavax/swing/RootPaneContainer;
        //    23: ifeq            247
        //    26: goto            33
        //    29: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    32: athrow         
        //    33: aload_1        
        //    34: goto            41
        //    37: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    40: athrow         
        //    41: checkcast       Ljavax/swing/RootPaneContainer;
        //    44: invokeinterface javax/swing/RootPaneContainer.getRootPane:()Ljavax/swing/JRootPane;
        //    49: astore          4
        //    51: aload           4
        //    53: sipush          18172
        //    56: sipush          13844
        //    59: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //    62: invokevirtual   javax/swing/JRootPane.getClientProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //    65: checkcast       Ljava/lang/Boolean;
        //    68: astore          5
        //    70: aload_3        
        //    71: ifnonnull       121
        //    74: aload_3        
        //    75: ifnonnull       121
        //    78: goto            85
        //    81: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    84: athrow         
        //    85: aload           5
        //    87: ifnonnull       247
        //    90: goto            97
        //    93: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    96: athrow         
        //    97: aload           4
        //    99: sipush          18172
        //   102: sipush          13844
        //   105: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //   108: getstatic       java/lang/Boolean.FALSE:Ljava/lang/Boolean;
        //   111: invokevirtual   javax/swing/JRootPane.putClientProperty:(Ljava/lang/Object;Ljava/lang/Object;)V
        //   114: goto            121
        //   117: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   120: athrow         
        //   121: aload_1        
        //   122: invokevirtual   java/awt/Window.isDisplayable:()Z
        //   125: ifeq            247
        //   128: getstatic       java/lang/System.err:Ljava/io/PrintStream;
        //   131: new             Ljava/lang/StringBuilder;
        //   134: dup            
        //   135: invokespecial   java/lang/StringBuilder.<init>:()V
        //   138: aload_2        
        //   139: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   142: sipush          18167
        //   145: sipush          -3603
        //   148: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //   151: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   154: aload_2        
        //   155: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   158: sipush          18166
        //   161: sipush          11183
        //   164: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //   167: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   170: sipush          18172
        //   173: sipush          13844
        //   176: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //   179: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   182: sipush          18161
        //   185: sipush          -16450
        //   188: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //   191: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   194: sipush          18172
        //   197: sipush          13844
        //   200: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //   203: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   206: sipush          18165
        //   209: sipush          -7467
        //   212: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //   215: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   218: aload_2        
        //   219: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   222: sipush          18174
        //   225: sipush          -16918
        //   228: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //   231: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   234: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   237: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   240: goto            247
        //   243: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   246: athrow         
        //   247: return         
        //    StackMapTable: 00 0E FF 00 10 00 04 07 00 13 07 00 2A 07 00 CE 07 00 EB 00 01 07 00 C1 43 07 00 2A 48 07 00 C1 03 43 07 00 C1 43 07 00 2A FF 00 27 00 06 07 00 13 07 00 2A 07 00 CE 07 00 EB 07 00 4F 07 00 15 00 01 07 00 C1 03 47 07 00 C1 03 53 07 00 C1 03 F7 00 79 07 00 C1 F9 00 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      13     16     20     Ljava/lang/RuntimeException;
        //  9      26     29     33     Ljava/lang/RuntimeException;
        //  20     34     37     41     Ljava/lang/RuntimeException;
        //  70     78     81     85     Ljava/lang/RuntimeException;
        //  74     90     93     97     Ljava/lang/RuntimeException;
        //  85     114    117    121    Ljava/lang/RuntimeException;
        //  121    240    243    247    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void setWindowAlpha(final Window p0, final float p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_3       
        //     4: aload_3        
        //     5: ifnonnull       98
        //     8: aload_1        
        //     9: aload_3        
        //    10: ifnonnull       41
        //    13: goto            20
        //    16: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    19: athrow         
        //    20: instanceof      Ljavax/swing/RootPaneContainer;
        //    23: ifeq            83
        //    26: goto            33
        //    29: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    32: athrow         
        //    33: aload_1        
        //    34: goto            41
        //    37: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    40: athrow         
        //    41: checkcast       Ljavax/swing/RootPaneContainer;
        //    44: invokeinterface javax/swing/RootPaneContainer.getRootPane:()Ljavax/swing/JRootPane;
        //    49: astore          4
        //    51: aload           4
        //    53: sipush          18173
        //    56: sipush          -21047
        //    59: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //    62: fload_2        
        //    63: invokestatic    java/lang/Float.valueOf:(F)Ljava/lang/Float;
        //    66: invokevirtual   javax/swing/JRootPane.putClientProperty:(Ljava/lang/Object;Ljava/lang/Object;)V
        //    69: aload_0        
        //    70: aload_1        
        //    71: sipush          18160
        //    74: sipush          -11617
        //    77: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //    80: invokespecial   com/sun/jna/platform/WindowUtils$MacWindowUtils.fixWindowDragging:(Ljava/awt/Window;Ljava/lang/String;)V
        //    83: aload_0        
        //    84: aload_1        
        //    85: new             Lcom/sun/jna/platform/WindowUtils$MacWindowUtils$1;
        //    88: dup            
        //    89: aload_0        
        //    90: aload_1        
        //    91: fload_2        
        //    92: invokespecial   com/sun/jna/platform/WindowUtils$MacWindowUtils$1.<init>:(Lcom/sun/jna/platform/WindowUtils$MacWindowUtils;Ljava/awt/Window;F)V
        //    95: invokevirtual   com/sun/jna/platform/WindowUtils$MacWindowUtils.whenDisplayable:(Ljava/awt/Component;Ljava/lang/Runnable;)V
        //    98: return         
        //    StackMapTable: 00 08 FF 00 10 00 04 07 00 13 07 00 2A 02 07 00 EB 00 01 07 00 C1 43 07 00 2A 48 07 00 C1 03 43 07 00 C1 43 07 00 2A 29 0E
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      13     16     20     Ljava/lang/RuntimeException;
        //  8      26     29     33     Ljava/lang/RuntimeException;
        //  20     34     37     41     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    protected void setWindowMask(final Component component, final Raster raster) {
        final int[] b = WindowUtils$NativeWindowUtils.b();
        Rectangle rectangle = null;
        Label_0040: {
            WindowUtils$MacWindowUtils windowUtils$MacWindowUtils = null;
            Component component2 = null;
            Shape shape = null;
            Label_0019: {
                try {
                    if (b != null) {
                        break Label_0040;
                    }
                    final Raster raster2 = raster;
                    if (raster2 != null) {
                        break Label_0019;
                    }
                    break Label_0040;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final Raster raster2 = raster;
                    if (raster2 == null) {
                        break Label_0040;
                    }
                    windowUtils$MacWindowUtils = this;
                    component2 = component;
                    shape = this.toShape(raster);
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            while (true) {
                windowUtils$MacWindowUtils.setWindowMask(component2, shape);
                try {
                    if (b == null) {
                        return;
                    }
                    windowUtils$MacWindowUtils = this;
                    component2 = component;
                    rectangle = (Rectangle)(shape = new Rectangle(0, 0, component.getWidth(), component.getHeight()));
                    if (b != null) {
                        continue;
                    }
                }
                catch (RuntimeException ex3) {
                    throw b(ex3);
                }
                break;
            }
        }
        this.setWindowMask(component, rectangle);
    }
    
    @Override
    public void setWindowMask(final Component p0, final Shape p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_3       
        //     4: aload_1        
        //     5: aload_3        
        //     6: ifnonnull       41
        //     9: aload_3        
        //    10: ifnonnull       41
        //    13: goto            20
        //    16: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    19: athrow         
        //    20: instanceof      Ljava/awt/Window;
        //    23: ifeq            91
        //    26: goto            33
        //    29: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    32: athrow         
        //    33: aload_1        
        //    34: goto            41
        //    37: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    40: athrow         
        //    41: checkcast       Ljava/awt/Window;
        //    44: astore          4
        //    46: aload_0        
        //    47: aload           4
        //    49: invokespecial   com/sun/jna/platform/WindowUtils$MacWindowUtils.installMaskingPane:(Ljava/awt/Window;)Lcom/sun/jna/platform/WindowUtils$MacWindowUtils$OSXMaskingContentPane;
        //    52: astore          5
        //    54: aload           5
        //    56: aload_2        
        //    57: invokevirtual   com/sun/jna/platform/WindowUtils$MacWindowUtils$OSXMaskingContentPane.setMask:(Ljava/awt/Shape;)V
        //    60: aload_0        
        //    61: aload           4
        //    63: aload_2        
        //    64: getstatic       com/sun/jna/platform/WindowUtils.MASK_NONE:Ljava/awt/Shape;
        //    67: if_acmpeq       78
        //    70: iconst_1       
        //    71: goto            79
        //    74: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    77: athrow         
        //    78: iconst_0       
        //    79: sipush          18163
        //    82: sipush          1095
        //    85: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //    88: invokespecial   com/sun/jna/platform/WindowUtils$MacWindowUtils.setBackgroundTransparent:(Ljava/awt/Window;ZLjava/lang/String;)V
        //    91: return         
        //    StackMapTable: 00 0A FF 00 10 00 01 07 00 13 00 01 07 00 C1 FF 00 03 00 03 07 00 13 07 00 42 07 00 4C 00 01 07 00 42 FF 00 08 00 01 07 00 13 00 01 07 00 C1 FD 00 03 07 00 42 07 00 4C FF 00 03 00 01 07 00 13 00 01 07 00 C1 FF 00 03 00 03 07 00 13 00 07 00 4C 00 01 07 00 42 FF 00 20 00 01 07 00 13 00 01 07 00 C1 FF 00 03 00 01 07 00 13 00 02 07 00 13 07 00 2A FF 00 00 00 01 07 00 13 00 03 07 00 13 07 00 2A 01 0B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      13     16     20     Ljava/lang/RuntimeException;
        //  9      26     29     33     Ljava/lang/RuntimeException;
        //  20     34     37     41     Ljava/lang/RuntimeException;
        //  54     74     74     78     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void setBackgroundTransparent(final Window p0, final boolean p1, final String p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore          4
        //     5: aload_1        
        //     6: aload           4
        //     8: ifnonnull       44
        //    11: aload           4
        //    13: ifnonnull       44
        //    16: goto            23
        //    19: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    22: athrow         
        //    23: instanceof      Ljavax/swing/RootPaneContainer;
        //    26: ifeq            55
        //    29: goto            36
        //    32: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    35: athrow         
        //    36: aload_1        
        //    37: goto            44
        //    40: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    43: athrow         
        //    44: checkcast       Ljavax/swing/RootPaneContainer;
        //    47: invokeinterface javax/swing/RootPaneContainer.getRootPane:()Ljavax/swing/JRootPane;
        //    52: goto            56
        //    55: aconst_null    
        //    56: astore          5
        //    58: iload_2        
        //    59: ifeq            129
        //    62: aload           5
        //    64: goto            71
        //    67: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    70: athrow         
        //    71: aload           4
        //    73: ifnonnull       93
        //    76: aload           4
        //    78: ifnonnull       93
        //    81: ifnull          109
        //    84: goto            91
        //    87: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    90: athrow         
        //    91: aload           5
        //    93: sipush          18175
        //    96: sipush          -22446
        //    99: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //   102: aload_1        
        //   103: invokevirtual   java/awt/Window.getBackground:()Ljava/awt/Color;
        //   106: invokevirtual   javax/swing/JRootPane.putClientProperty:(Ljava/lang/Object;Ljava/lang/Object;)V
        //   109: aload_1        
        //   110: new             Ljava/awt/Color;
        //   113: dup            
        //   114: iconst_0       
        //   115: iconst_0       
        //   116: iconst_0       
        //   117: iconst_0       
        //   118: invokespecial   java/awt/Color.<init>:(IIII)V
        //   121: invokevirtual   java/awt/Window.setBackground:(Ljava/awt/Color;)V
        //   124: aload           4
        //   126: ifnull          292
        //   129: aload           5
        //   131: aload           4
        //   133: ifnonnull       71
        //   136: goto            143
        //   139: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   142: athrow         
        //   143: aload           4
        //   145: ifnonnull       179
        //   148: ifnull          275
        //   151: goto            158
        //   154: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   157: athrow         
        //   158: aload           5
        //   160: sipush          18175
        //   163: sipush          -22446
        //   166: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //   169: invokevirtual   javax/swing/JRootPane.getClientProperty:(Ljava/lang/Object;)Ljava/lang/Object;
        //   172: goto            179
        //   175: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   178: athrow         
        //   179: checkcast       Ljava/awt/Color;
        //   182: astore          6
        //   184: aload           4
        //   186: ifnonnull       270
        //   189: aload           6
        //   191: aload           4
        //   193: ifnonnull       247
        //   196: goto            203
        //   199: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   202: athrow         
        //   203: ifnull          249
        //   206: goto            213
        //   209: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   212: athrow         
        //   213: new             Ljava/awt/Color;
        //   216: dup            
        //   217: aload           6
        //   219: invokevirtual   java/awt/Color.getRed:()I
        //   222: aload           6
        //   224: invokevirtual   java/awt/Color.getGreen:()I
        //   227: aload           6
        //   229: invokevirtual   java/awt/Color.getBlue:()I
        //   232: aload           6
        //   234: invokevirtual   java/awt/Color.getAlpha:()I
        //   237: invokespecial   java/awt/Color.<init>:(IIII)V
        //   240: goto            247
        //   243: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   246: athrow         
        //   247: astore          6
        //   249: aload_1        
        //   250: aload           6
        //   252: invokevirtual   java/awt/Window.setBackground:(Ljava/awt/Color;)V
        //   255: aload           5
        //   257: sipush          18175
        //   260: sipush          -22446
        //   263: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(II)Ljava/lang/String;
        //   266: aconst_null    
        //   267: invokevirtual   javax/swing/JRootPane.putClientProperty:(Ljava/lang/Object;Ljava/lang/Object;)V
        //   270: aload           4
        //   272: ifnull          292
        //   275: aload_1        
        //   276: aload           4
        //   278: ifnonnull       179
        //   281: goto            288
        //   284: invokestatic    com/sun/jna/platform/WindowUtils$MacWindowUtils.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   287: athrow         
        //   288: aconst_null    
        //   289: invokevirtual   java/awt/Window.setBackground:(Ljava/awt/Color;)V
        //   292: aload_0        
        //   293: aload_1        
        //   294: aload_3        
        //   295: invokespecial   com/sun/jna/platform/WindowUtils$MacWindowUtils.fixWindowDragging:(Ljava/awt/Window;Ljava/lang/String;)V
        //   298: return         
        //    StackMapTable: 00 21 FF 00 13 00 05 07 00 13 07 00 2A 01 07 00 CE 07 00 EB 00 01 07 00 C1 43 07 00 2A 48 07 00 C1 03 43 07 00 C1 43 07 00 2A 0A 40 07 00 4F FF 00 0A 00 06 07 00 13 07 00 2A 01 07 00 CE 07 00 EB 07 00 4F 00 01 07 00 C1 43 07 00 4F 4F 07 00 C1 03 41 07 00 4F 0F 13 49 07 00 C1 43 07 00 4F 4A 07 00 C1 03 50 07 00 C1 43 07 00 EF FF 00 13 00 07 07 00 13 07 00 2A 01 07 00 CE 07 00 EB 07 00 4F 07 00 2E 00 01 07 00 C1 43 07 00 2E 45 07 00 C1 03 5D 07 00 C1 43 07 00 2E 01 14 FA 00 04 48 07 00 C1 43 07 00 2A 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  5      16     19     23     Ljava/lang/RuntimeException;
        //  11     29     32     36     Ljava/lang/RuntimeException;
        //  23     37     40     44     Ljava/lang/RuntimeException;
        //  58     64     67     71     Ljava/lang/RuntimeException;
        //  76     84     87     91     Ljava/lang/RuntimeException;
        //  109    136    139    143    Ljava/lang/RuntimeException;
        //  143    151    154    158    Ljava/lang/RuntimeException;
        //  148    172    175    179    Ljava/lang/RuntimeException;
        //  184    196    199    203    Ljava/lang/RuntimeException;
        //  189    206    209    213    Ljava/lang/RuntimeException;
        //  203    240    243    247    Ljava/lang/RuntimeException;
        //  270    281    284    288    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0023:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    WindowUtils$MacWindowUtils(final WindowUtils$1 windowUtils$1) {
        this();
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
    
    static {
        final String[] d2 = new String[12];
        int n = 0;
        String s;
        int n2 = (s = "\u0092_%¬%\u0015\u008bj\u00d6v\u00f2´(u\u00d1\u0015\u00c5m\u00e2\u00df\u0094¨u\u0088\u0094|\u00ed\u0090\r\u0093\u0096£\"\u008b[&¤\u00e9\u00d6\u0082¨\u008dEªIR¨\u009c] \u00c2\u00cc\u001fU\b\u00c7\u000b\u0001\u0019^5¦\u00fe#\u00e936\u00d8\u0098\u0097\u00f3¶\u00f0\u00d5u\u00d3]\u0007Q1O\u00f0Y\u00cf\u0014\u0003\u00dbs\u00c3-\u0098\u0005*\u0000\u00e9\u00cdR\u00d8\u00f4=\u00dd\u00d1µ¸8:\u00c8\u00fa)\u00db\"\u0004[0\u00ea1\u008c\u00d6n\u00c5\u009dm*\u00e4\u00de\u00fc\u00ad\u00c8\u0000&6<vºp²´;#º\u0003\"\u00f8]\u00ce\u00c2a\u0085\u0006\u0000\u00fbn\t&F-]\u009a\u00ee¢f[\u001a\u00d7#O\u00cc®\u00ad\u001eI\u00eb@{\u00c5\u00d7\u00f1@\u00e5\u00d7ii*¶\u00c0\u00f6>\u00c1q\u0081>\u00fb.¬\u0092\u009b\u0090\u00ea\u00cdb\r\u0096\u0083\u00c1\u00c8{\u00f9\u00cf\u0006Yu\u00f5\u00e9«\u000e\u00f5\u00f0\u00ad¦\u00f64~¿oN>\u0000}\u009fg¹³\u001c\u00e3\u00fcr\u0087\u00fa\u00c1\u009f_J1G\u0098\r©\u00cc\u0080Dw\u00fdv¦\r®Po\u007f\u00cb\u001a\u001e\u00dbV#\u00d8G\u00dc\u0082\u00d4&¤|\\\u00d5a\u00f5½\u00ce\u0015\u0082·7{p\u00cb`g'-\u00fc]r\u001c1*K¶\u00f8\u00ff«\u009dª´\u001dd\u0002<\u0088\u00c4´\u00d1\u00ee\u00db\u00de\u00825\u00cb\u00f5\u00d4h\u00e6i\u008c\u00e9¤-\u009b\u00fb\u0096D\u009d±\u0018i\u001dZ\u00fd\u00d0Vpr0\u0015\u00e8\u00cfb\u00ea¯\u0006\u00ff§\u009c}o \u00fa\u00db\u0012\u0007\u0097\u0001\u0086\u00ce0%\u00ff³\u00d7\u00ed¤\u001b\u00f0p\u00ed\u00fet").length();
        int n3 = 52;
        int n4 = -1;
    Label_0023:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 127));
                ++n4;
                final String s2 = s;
                final int beginIndex = n4;
                String s3 = s2.substring(beginIndex, beginIndex + n3);
                int n9 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n10 = 0;
                    while (true) {
                        Label_0272: {
                            if (length > 1) {
                                break Label_0272;
                            }
                            n7 = (n6 = n10);
                            do {
                                final char c = charArray[n6];
                                int n11 = 0;
                                switch (n10 % 7) {
                                    case 0: {
                                        n11 = 77;
                                        break;
                                    }
                                    case 1: {
                                        n11 = 13;
                                        break;
                                    }
                                    case 2: {
                                        n11 = 67;
                                        break;
                                    }
                                    case 3: {
                                        n11 = 23;
                                        break;
                                    }
                                    case 4: {
                                        n11 = 40;
                                        break;
                                    }
                                    case 5: {
                                        n11 = 65;
                                        break;
                                    }
                                    default: {
                                        n11 = 21;
                                        break;
                                    }
                                }
                                charArray[n7] = (char)(c ^ (n5 ^ n11));
                                ++n10;
                            } while (n8 == 0);
                        }
                        if (length > n10) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n9) {
                        default: {
                            d2[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                continue Label_0023;
                            }
                            n2 = (s = "o\u00d86³\u0091\u0016\u00867J·m#\u008b#2-I>.\u00deya¬\u0006°LA\u00fcgT~\u00d4\u00ca\u00d9\u00fa\f\u0007U\u00d50:6\u00f7W\u00da1hu").length();
                            n3 = 35;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            d2[n++] = intern;
                            if ((n4 += n3) < n2) {
                                n3 = s.charAt(n4);
                                break;
                            }
                            break Label_0023;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 41)));
                    ++n4;
                    final String s4 = s;
                    final int beginIndex2 = n4;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n3);
                    n9 = 0;
                }
            }
            break;
        }
        d = d2;
        e = new String[12];
        WDRAG = b(18162, -693);
    }
    
    private static String b(final int n, final int n2) {
        final int n3 = (n ^ 0x46F6) & 0xFFFF;
        if (WindowUtils$MacWindowUtils.e[n3] == null) {
            final char[] charArray = WindowUtils$MacWindowUtils.d[n3].toCharArray();
            int n4 = 0;
            switch (charArray[0] & '\u00ff') {
                case 0: {
                    n4 = 132;
                    break;
                }
                case 1: {
                    n4 = 2;
                    break;
                }
                case 2: {
                    n4 = 213;
                    break;
                }
                case 3: {
                    n4 = 146;
                    break;
                }
                case 4: {
                    n4 = 83;
                    break;
                }
                case 5: {
                    n4 = 80;
                    break;
                }
                case 6: {
                    n4 = 225;
                    break;
                }
                case 7: {
                    n4 = 82;
                    break;
                }
                case 8: {
                    n4 = 122;
                    break;
                }
                case 9: {
                    n4 = 176;
                    break;
                }
                case 10: {
                    n4 = 51;
                    break;
                }
                case 11: {
                    n4 = 170;
                    break;
                }
                case 12: {
                    n4 = 217;
                    break;
                }
                case 13: {
                    n4 = 8;
                    break;
                }
                case 14: {
                    n4 = 136;
                    break;
                }
                case 15: {
                    n4 = 161;
                    break;
                }
                case 16: {
                    n4 = 87;
                    break;
                }
                case 17: {
                    n4 = 57;
                    break;
                }
                case 18: {
                    n4 = 10;
                    break;
                }
                case 19: {
                    n4 = 187;
                    break;
                }
                case 20: {
                    n4 = 192;
                    break;
                }
                case 21: {
                    n4 = 41;
                    break;
                }
                case 22: {
                    n4 = 154;
                    break;
                }
                case 23: {
                    n4 = 233;
                    break;
                }
                case 24: {
                    n4 = 68;
                    break;
                }
                case 25: {
                    n4 = 206;
                    break;
                }
                case 26: {
                    n4 = 239;
                    break;
                }
                case 27: {
                    n4 = 211;
                    break;
                }
                case 28: {
                    n4 = 23;
                    break;
                }
                case 29: {
                    n4 = 168;
                    break;
                }
                case 30: {
                    n4 = 16;
                    break;
                }
                case 31: {
                    n4 = 147;
                    break;
                }
                case 32: {
                    n4 = 247;
                    break;
                }
                case 33: {
                    n4 = 1;
                    break;
                }
                case 34: {
                    n4 = 180;
                    break;
                }
                case 35: {
                    n4 = 228;
                    break;
                }
                case 36: {
                    n4 = 246;
                    break;
                }
                case 37: {
                    n4 = 184;
                    break;
                }
                case 38: {
                    n4 = 166;
                    break;
                }
                case 39: {
                    n4 = 183;
                    break;
                }
                case 40: {
                    n4 = 9;
                    break;
                }
                case 41: {
                    n4 = 32;
                    break;
                }
                case 42: {
                    n4 = 220;
                    break;
                }
                case 43: {
                    n4 = 62;
                    break;
                }
                case 44: {
                    n4 = 78;
                    break;
                }
                case 45: {
                    n4 = 137;
                    break;
                }
                case 46: {
                    n4 = 94;
                    break;
                }
                case 47: {
                    n4 = 153;
                    break;
                }
                case 48: {
                    n4 = 92;
                    break;
                }
                case 49: {
                    n4 = 0;
                    break;
                }
                case 50: {
                    n4 = 103;
                    break;
                }
                case 51: {
                    n4 = 95;
                    break;
                }
                case 52: {
                    n4 = 204;
                    break;
                }
                case 53: {
                    n4 = 17;
                    break;
                }
                case 54: {
                    n4 = 145;
                    break;
                }
                case 55: {
                    n4 = 69;
                    break;
                }
                case 56: {
                    n4 = 181;
                    break;
                }
                case 57: {
                    n4 = 104;
                    break;
                }
                case 58: {
                    n4 = 174;
                    break;
                }
                case 59: {
                    n4 = 33;
                    break;
                }
                case 60: {
                    n4 = 165;
                    break;
                }
                case 61: {
                    n4 = 237;
                    break;
                }
                case 62: {
                    n4 = 77;
                    break;
                }
                case 63: {
                    n4 = 37;
                    break;
                }
                case 64: {
                    n4 = 105;
                    break;
                }
                case 65: {
                    n4 = 20;
                    break;
                }
                case 66: {
                    n4 = 108;
                    break;
                }
                case 67: {
                    n4 = 5;
                    break;
                }
                case 68: {
                    n4 = 249;
                    break;
                }
                case 69: {
                    n4 = 14;
                    break;
                }
                case 70: {
                    n4 = 173;
                    break;
                }
                case 71: {
                    n4 = 52;
                    break;
                }
                case 72: {
                    n4 = 22;
                    break;
                }
                case 73: {
                    n4 = 7;
                    break;
                }
                case 74: {
                    n4 = 6;
                    break;
                }
                case 75: {
                    n4 = 65;
                    break;
                }
                case 76: {
                    n4 = 55;
                    break;
                }
                case 77: {
                    n4 = 116;
                    break;
                }
                case 78: {
                    n4 = 73;
                    break;
                }
                case 79: {
                    n4 = 167;
                    break;
                }
                case 80: {
                    n4 = 3;
                    break;
                }
                case 81: {
                    n4 = 93;
                    break;
                }
                case 82: {
                    n4 = 4;
                    break;
                }
                case 83: {
                    n4 = 50;
                    break;
                }
                case 84: {
                    n4 = 202;
                    break;
                }
                case 85: {
                    n4 = 24;
                    break;
                }
                case 86: {
                    n4 = 81;
                    break;
                }
                case 87: {
                    n4 = 49;
                    break;
                }
                case 88: {
                    n4 = 227;
                    break;
                }
                case 89: {
                    n4 = 106;
                    break;
                }
                case 90: {
                    n4 = 185;
                    break;
                }
                case 91: {
                    n4 = 119;
                    break;
                }
                case 92: {
                    n4 = 21;
                    break;
                }
                case 93: {
                    n4 = 27;
                    break;
                }
                case 94: {
                    n4 = 35;
                    break;
                }
                case 95: {
                    n4 = 157;
                    break;
                }
                case 96: {
                    n4 = 111;
                    break;
                }
                case 97: {
                    n4 = 86;
                    break;
                }
                case 98: {
                    n4 = 67;
                    break;
                }
                case 99: {
                    n4 = 149;
                    break;
                }
                case 100: {
                    n4 = 133;
                    break;
                }
                case 101: {
                    n4 = 221;
                    break;
                }
                case 102: {
                    n4 = 229;
                    break;
                }
                case 103: {
                    n4 = 158;
                    break;
                }
                case 104: {
                    n4 = 196;
                    break;
                }
                case 105: {
                    n4 = 123;
                    break;
                }
                case 106: {
                    n4 = 102;
                    break;
                }
                case 107: {
                    n4 = 191;
                    break;
                }
                case 108: {
                    n4 = 99;
                    break;
                }
                case 109: {
                    n4 = 141;
                    break;
                }
                case 110: {
                    n4 = 193;
                    break;
                }
                case 111: {
                    n4 = 29;
                    break;
                }
                case 112: {
                    n4 = 177;
                    break;
                }
                case 113: {
                    n4 = 252;
                    break;
                }
                case 114: {
                    n4 = 151;
                    break;
                }
                case 115: {
                    n4 = 100;
                    break;
                }
                case 116: {
                    n4 = 139;
                    break;
                }
                case 117: {
                    n4 = 59;
                    break;
                }
                case 118: {
                    n4 = 216;
                    break;
                }
                case 119: {
                    n4 = 223;
                    break;
                }
                case 120: {
                    n4 = 222;
                    break;
                }
                case 121: {
                    n4 = 101;
                    break;
                }
                case 122: {
                    n4 = 188;
                    break;
                }
                case 123: {
                    n4 = 171;
                    break;
                }
                case 124: {
                    n4 = 212;
                    break;
                }
                case 125: {
                    n4 = 47;
                    break;
                }
                case 126: {
                    n4 = 42;
                    break;
                }
                case 127: {
                    n4 = 238;
                    break;
                }
                case 128: {
                    n4 = 54;
                    break;
                }
                case 129: {
                    n4 = 144;
                    break;
                }
                case 130: {
                    n4 = 18;
                    break;
                }
                case 131: {
                    n4 = 71;
                    break;
                }
                case 132: {
                    n4 = 53;
                    break;
                }
                case 133: {
                    n4 = 43;
                    break;
                }
                case 134: {
                    n4 = 140;
                    break;
                }
                case 135: {
                    n4 = 156;
                    break;
                }
                case 136: {
                    n4 = 72;
                    break;
                }
                case 137: {
                    n4 = 115;
                    break;
                }
                case 138: {
                    n4 = 63;
                    break;
                }
                case 139: {
                    n4 = 19;
                    break;
                }
                case 140: {
                    n4 = 113;
                    break;
                }
                case 141: {
                    n4 = 243;
                    break;
                }
                case 142: {
                    n4 = 126;
                    break;
                }
                case 143: {
                    n4 = 207;
                    break;
                }
                case 144: {
                    n4 = 107;
                    break;
                }
                case 145: {
                    n4 = 199;
                    break;
                }
                case 146: {
                    n4 = 84;
                    break;
                }
                case 147: {
                    n4 = 44;
                    break;
                }
                case 148: {
                    n4 = 201;
                    break;
                }
                case 149: {
                    n4 = 195;
                    break;
                }
                case 150: {
                    n4 = 142;
                    break;
                }
                case 151: {
                    n4 = 255;
                    break;
                }
                case 152: {
                    n4 = 150;
                    break;
                }
                case 153: {
                    n4 = 45;
                    break;
                }
                case 154: {
                    n4 = 34;
                    break;
                }
                case 155: {
                    n4 = 253;
                    break;
                }
                case 156: {
                    n4 = 12;
                    break;
                }
                case 157: {
                    n4 = 58;
                    break;
                }
                case 158: {
                    n4 = 79;
                    break;
                }
                case 159: {
                    n4 = 88;
                    break;
                }
                case 160: {
                    n4 = 39;
                    break;
                }
                case 161: {
                    n4 = 131;
                    break;
                }
                case 162: {
                    n4 = 75;
                    break;
                }
                case 163: {
                    n4 = 190;
                    break;
                }
                case 164: {
                    n4 = 112;
                    break;
                }
                case 165: {
                    n4 = 254;
                    break;
                }
                case 166: {
                    n4 = 98;
                    break;
                }
                case 167: {
                    n4 = 179;
                    break;
                }
                case 168: {
                    n4 = 26;
                    break;
                }
                case 169: {
                    n4 = 214;
                    break;
                }
                case 170: {
                    n4 = 124;
                    break;
                }
                case 171: {
                    n4 = 46;
                    break;
                }
                case 172: {
                    n4 = 121;
                    break;
                }
                case 173: {
                    n4 = 242;
                    break;
                }
                case 174: {
                    n4 = 143;
                    break;
                }
                case 175: {
                    n4 = 200;
                    break;
                }
                case 176: {
                    n4 = 236;
                    break;
                }
                case 177: {
                    n4 = 215;
                    break;
                }
                case 178: {
                    n4 = 114;
                    break;
                }
                case 179: {
                    n4 = 110;
                    break;
                }
                case 180: {
                    n4 = 138;
                    break;
                }
                case 181: {
                    n4 = 198;
                    break;
                }
                case 182: {
                    n4 = 117;
                    break;
                }
                case 183: {
                    n4 = 159;
                    break;
                }
                case 184: {
                    n4 = 209;
                    break;
                }
                case 185: {
                    n4 = 248;
                    break;
                }
                case 186: {
                    n4 = 186;
                    break;
                }
                case 187: {
                    n4 = 40;
                    break;
                }
                case 188: {
                    n4 = 245;
                    break;
                }
                case 189: {
                    n4 = 130;
                    break;
                }
                case 190: {
                    n4 = 129;
                    break;
                }
                case 191: {
                    n4 = 38;
                    break;
                }
                case 192: {
                    n4 = 232;
                    break;
                }
                case 193: {
                    n4 = 13;
                    break;
                }
                case 194: {
                    n4 = 118;
                    break;
                }
                case 195: {
                    n4 = 30;
                    break;
                }
                case 196: {
                    n4 = 60;
                    break;
                }
                case 197: {
                    n4 = 64;
                    break;
                }
                case 198: {
                    n4 = 31;
                    break;
                }
                case 199: {
                    n4 = 235;
                    break;
                }
                case 200: {
                    n4 = 205;
                    break;
                }
                case 201: {
                    n4 = 203;
                    break;
                }
                case 202: {
                    n4 = 125;
                    break;
                }
                case 203: {
                    n4 = 169;
                    break;
                }
                case 204: {
                    n4 = 234;
                    break;
                }
                case 205: {
                    n4 = 48;
                    break;
                }
                case 206: {
                    n4 = 231;
                    break;
                }
                case 207: {
                    n4 = 244;
                    break;
                }
                case 208: {
                    n4 = 97;
                    break;
                }
                case 209: {
                    n4 = 194;
                    break;
                }
                case 210: {
                    n4 = 127;
                    break;
                }
                case 211: {
                    n4 = 135;
                    break;
                }
                case 212: {
                    n4 = 66;
                    break;
                }
                case 213: {
                    n4 = 230;
                    break;
                }
                case 214: {
                    n4 = 250;
                    break;
                }
                case 215: {
                    n4 = 160;
                    break;
                }
                case 216: {
                    n4 = 241;
                    break;
                }
                case 217: {
                    n4 = 175;
                    break;
                }
                case 218: {
                    n4 = 240;
                    break;
                }
                case 219: {
                    n4 = 178;
                    break;
                }
                case 220: {
                    n4 = 208;
                    break;
                }
                case 221: {
                    n4 = 152;
                    break;
                }
                case 222: {
                    n4 = 219;
                    break;
                }
                case 223: {
                    n4 = 15;
                    break;
                }
                case 224: {
                    n4 = 85;
                    break;
                }
                case 225: {
                    n4 = 164;
                    break;
                }
                case 226: {
                    n4 = 61;
                    break;
                }
                case 227: {
                    n4 = 128;
                    break;
                }
                case 228: {
                    n4 = 28;
                    break;
                }
                case 229: {
                    n4 = 189;
                    break;
                }
                case 230: {
                    n4 = 120;
                    break;
                }
                case 231: {
                    n4 = 76;
                    break;
                }
                case 232: {
                    n4 = 56;
                    break;
                }
                case 233: {
                    n4 = 210;
                    break;
                }
                case 234: {
                    n4 = 162;
                    break;
                }
                case 235: {
                    n4 = 74;
                    break;
                }
                case 236: {
                    n4 = 148;
                    break;
                }
                case 237: {
                    n4 = 89;
                    break;
                }
                case 238: {
                    n4 = 11;
                    break;
                }
                case 239: {
                    n4 = 182;
                    break;
                }
                case 240: {
                    n4 = 172;
                    break;
                }
                case 241: {
                    n4 = 96;
                    break;
                }
                case 242: {
                    n4 = 109;
                    break;
                }
                case 243: {
                    n4 = 197;
                    break;
                }
                case 244: {
                    n4 = 155;
                    break;
                }
                case 245: {
                    n4 = 226;
                    break;
                }
                case 246: {
                    n4 = 36;
                    break;
                }
                case 247: {
                    n4 = 134;
                    break;
                }
                case 248: {
                    n4 = 91;
                    break;
                }
                case 249: {
                    n4 = 25;
                    break;
                }
                case 250: {
                    n4 = 251;
                    break;
                }
                case 251: {
                    n4 = 70;
                    break;
                }
                case 252: {
                    n4 = 218;
                    break;
                }
                case 253: {
                    n4 = 90;
                    break;
                }
                case 254: {
                    n4 = 163;
                    break;
                }
                default: {
                    n4 = 224;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < charArray.length; ++i) {
                final int n8 = i % 2;
                final char[] array = charArray;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ charArray[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ charArray[i]) & 0xFF);
                }
            }
            WindowUtils$MacWindowUtils.e[n3] = new String(charArray).intern();
        }
        return WindowUtils$MacWindowUtils.e[n3];
    }
}
