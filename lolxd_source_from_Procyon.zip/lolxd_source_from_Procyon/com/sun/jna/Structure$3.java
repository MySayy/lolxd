// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna;

final class Structure$3 extends Pointer
{
    Structure$3(final long n) {
        super(n);
    }
    
    @Override
    public Pointer share(final long n, final long n2) {
        return this;
    }
}
