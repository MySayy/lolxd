// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna;

import java.util.WeakHashMap;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.io.Serializable;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Collections;
import java.lang.reflect.Modifier;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Set;
import java.util.List;
import java.util.Map;

public abstract class Structure
{
    public static final int ALIGN_DEFAULT = 0;
    public static final int ALIGN_NONE = 1;
    public static final int ALIGN_GNUC = 2;
    public static final int ALIGN_MSVC = 3;
    protected static final int CALCULATE_SIZE = -1;
    static final Map<Class<?>, Structure$LayoutInfo> layoutInfo;
    static final Map<Class<?>, List<String>> fieldOrder;
    private Pointer memory;
    private int size;
    private int alignType;
    private String encoding;
    private int actualAlignType;
    private int structAlignment;
    private Map<String, Structure$StructField> structFields;
    private final Map<String, Object> nativeStrings;
    private TypeMapper typeMapper;
    private long typeInfo;
    private boolean autoRead;
    private boolean autoWrite;
    private Structure[] array;
    private boolean readCalled;
    private static final ThreadLocal<Map<Pointer, Structure>> reads;
    private static final ThreadLocal<Set<Structure>> busy;
    private static final Pointer PLACEHOLDER_MEMORY;
    private static int b;
    private static final String[] a;
    private static final String[] c;
    
    protected Structure() {
        this(0);
    }
    
    protected Structure(final TypeMapper typeMapper) {
        this(null, 0, typeMapper);
    }
    
    protected Structure(final int n) {
        this(null, n);
    }
    
    protected Structure(final int n, final TypeMapper typeMapper) {
        this(null, n, typeMapper);
    }
    
    protected Structure(final Pointer pointer) {
        this(pointer, 0);
    }
    
    protected Structure(final Pointer pointer, final int n) {
        this(pointer, n, null);
    }
    
    protected Structure(final Pointer pointer, final int alignType, final TypeMapper typeMapper) {
        this.size = -1;
        this.nativeStrings = new HashMap<String, Object>();
        this.autoRead = true;
        this.autoWrite = true;
        this.setAlignType(alignType);
        this.setStringEncoding(Native.getStringEncoding(this.getClass()));
        this.initializeTypeMapper(typeMapper);
        this.validateFields();
        if (pointer != null) {
            this.useMemory(pointer, 0, true);
        }
        else {
            this.allocateMemory(-1);
        }
        this.initializeFields();
    }
    
    Map<String, Structure$StructField> fields() {
        return this.structFields;
    }
    
    TypeMapper getTypeMapper() {
        return this.typeMapper;
    }
    
    private void initializeTypeMapper(TypeMapper typeMapper) {
        if (typeMapper == null) {
            typeMapper = Native.getTypeMapper(this.getClass());
        }
        this.typeMapper = typeMapper;
        this.layoutChanged();
    }
    
    private void layoutChanged() {
        Label_0030: {
            try {
                if (this.size == -1) {
                    return;
                }
                final Structure structure = this;
                final int n = -1;
                structure.size = n;
                final Structure structure2 = this;
                final Pointer pointer = structure2.memory;
                final boolean b = pointer instanceof Structure$AutoAllocated;
                if (b) {
                    break Label_0030;
                }
                break Label_0030;
            }
            catch (IndexOutOfBoundsException ex) {
                throw b(ex);
            }
            try {
                final Structure structure = this;
                final int n = -1;
                structure.size = n;
                final Structure structure2 = this;
                final Pointer pointer = structure2.memory;
                final boolean b = pointer instanceof Structure$AutoAllocated;
                if (b) {
                    this.memory = null;
                }
            }
            catch (IndexOutOfBoundsException ex2) {
                throw b(ex2);
            }
        }
        this.ensureAllocated();
    }
    
    protected void setStringEncoding(final String encoding) {
        this.encoding = encoding;
    }
    
    protected String getStringEncoding() {
        return this.encoding;
    }
    
    protected void setAlignType(int structureAlignment) {
        this.alignType = structureAlignment;
        Label_0041: {
            if (structureAlignment == 0) {
                structureAlignment = Native.getStructureAlignment(this.getClass());
                Label_0039: {
                    try {
                        if (structureAlignment != 0) {
                            break Label_0041;
                        }
                        if (!Platform.isWindows()) {
                            break Label_0039;
                        }
                    }
                    catch (IndexOutOfBoundsException ex) {
                        throw b(ex);
                    }
                    structureAlignment = 3;
                    break Label_0041;
                }
                structureAlignment = 2;
            }
        }
        this.actualAlignType = structureAlignment;
        this.layoutChanged();
    }
    
    protected Memory autoAllocate(final int n) {
        return new Structure$AutoAllocated(n);
    }
    
    protected void useMemory(final Pointer pointer) {
        this.useMemory(pointer, 0);
    }
    
    protected void useMemory(final Pointer pointer, final int n) {
        this.useMemory(pointer, n, false);
    }
    
    void useMemory(final Pointer pointer, final int n, final boolean b) {
        try {
            Label_0127: {
                Label_0063: {
                    try {
                        this.nativeStrings.clear();
                        if (!(this instanceof Structure$ByValue) || b) {
                            break Label_0063;
                        }
                    }
                    catch (IndexOutOfBoundsException ex) {
                        throw b(ex);
                    }
                    final byte[] array = new byte[this.size()];
                    pointer.read(0L, array, 0, array.length);
                    this.memory.write(0L, array, 0, array.length);
                    break Label_0127;
                    try {
                        this.memory = pointer.share(n);
                        if (this.size == -1) {
                            this.size = this.calculateSize(false);
                        }
                    }
                    catch (IndexOutOfBoundsException ex2) {
                        throw b(ex2);
                    }
                }
                try {
                    if (this.size != -1) {
                        this.memory = pointer.share(n, this.size);
                    }
                }
                catch (IndexOutOfBoundsException ex3) {
                    throw b(ex3);
                }
            }
            this.array = null;
            this.readCalled = false;
        }
        catch (IndexOutOfBoundsException cause) {
            throw new IllegalArgumentException(a(30817, -7155), cause);
        }
    }
    
    protected void ensureAllocated() {
        this.ensureAllocated(false);
    }
    
    private void ensureAllocated(final boolean p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        com/sun/jna/Structure.memory:Lcom/sun/jna/Pointer;
        //     4: ifnonnull       19
        //     7: aload_0        
        //     8: iload_1        
        //     9: invokespecial   com/sun/jna/Structure.allocateMemory:(Z)V
        //    12: goto            97
        //    15: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    18: athrow         
        //    19: aload_0        
        //    20: getfield        com/sun/jna/Structure.size:I
        //    23: iconst_m1      
        //    24: if_icmpne       97
        //    27: aload_0        
        //    28: aload_0        
        //    29: iconst_1       
        //    30: iload_1        
        //    31: invokevirtual   com/sun/jna/Structure.calculateSize:(ZZ)I
        //    34: putfield        com/sun/jna/Structure.size:I
        //    37: aload_0        
        //    38: getfield        com/sun/jna/Structure.memory:Lcom/sun/jna/Pointer;
        //    41: instanceof      Lcom/sun/jna/Structure$AutoAllocated;
        //    44: ifne            97
        //    47: goto            54
        //    50: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    53: athrow         
        //    54: aload_0        
        //    55: aload_0        
        //    56: getfield        com/sun/jna/Structure.memory:Lcom/sun/jna/Pointer;
        //    59: lconst_0       
        //    60: aload_0        
        //    61: getfield        com/sun/jna/Structure.size:I
        //    64: i2l            
        //    65: invokevirtual   com/sun/jna/Pointer.share:(JJ)Lcom/sun/jna/Pointer;
        //    68: putfield        com/sun/jna/Structure.memory:Lcom/sun/jna/Pointer;
        //    71: goto            97
        //    74: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    77: athrow         
        //    78: astore_2       
        //    79: new             Ljava/lang/IllegalArgumentException;
        //    82: dup            
        //    83: sipush          30817
        //    86: sipush          -7155
        //    89: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //    92: aload_2        
        //    93: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;Ljava/lang/Throwable;)V
        //    96: athrow         
        //    97: return         
        //    StackMapTable: 00 07 4F 07 00 4E 03 5E 07 00 4E 03 53 07 00 4F 43 07 00 4E 12
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                 
        //  -----  -----  -----  -----  -------------------------------------
        //  19     47     50     54     Ljava/lang/IndexOutOfBoundsException;
        //  0      15     15     19     Ljava/lang/IndexOutOfBoundsException;
        //  54     71     78     97     Ljava/lang/IndexOutOfBoundsException;
        //  27     74     74     78     Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0054:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    protected void allocateMemory() {
        this.allocateMemory(false);
    }
    
    private void allocateMemory(final boolean b) {
        this.allocateMemory(this.calculateSize(true, b));
    }
    
    protected void allocateMemory(final int p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: iconst_m1      
        //     2: if_icmpne       14
        //     5: aload_0        
        //     6: iconst_0       
        //     7: invokevirtual   com/sun/jna/Structure.calculateSize:(Z)I
        //    10: istore_1       
        //    11: goto            56
        //    14: iload_1        
        //    15: ifgt            56
        //    18: new             Ljava/lang/IllegalArgumentException;
        //    21: dup            
        //    22: new             Ljava/lang/StringBuilder;
        //    25: dup            
        //    26: invokespecial   java/lang/StringBuilder.<init>:()V
        //    29: sipush          30843
        //    32: sipush          3513
        //    35: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //    38: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    41: iload_1        
        //    42: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //    45: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    48: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //    51: athrow         
        //    52: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    55: athrow         
        //    56: iload_1        
        //    57: iconst_m1      
        //    58: if_icmpeq       113
        //    61: aload_0        
        //    62: getfield        com/sun/jna/Structure.memory:Lcom/sun/jna/Pointer;
        //    65: ifnull          92
        //    68: goto            75
        //    71: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    74: athrow         
        //    75: aload_0        
        //    76: getfield        com/sun/jna/Structure.memory:Lcom/sun/jna/Pointer;
        //    79: instanceof      Lcom/sun/jna/Structure$AutoAllocated;
        //    82: ifeq            108
        //    85: goto            92
        //    88: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    91: athrow         
        //    92: aload_0        
        //    93: aload_0        
        //    94: iload_1        
        //    95: invokevirtual   com/sun/jna/Structure.autoAllocate:(I)Lcom/sun/jna/Memory;
        //    98: putfield        com/sun/jna/Structure.memory:Lcom/sun/jna/Pointer;
        //   101: goto            108
        //   104: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   107: athrow         
        //   108: aload_0        
        //   109: iload_1        
        //   110: putfield        com/sun/jna/Structure.size:I
        //   113: return         
        //    StackMapTable: 00 0A 0E 65 07 00 4E 03 4E 07 00 4E 03 4C 07 00 4E 03 4B 07 00 4E 03 04
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                 
        //  -----  -----  -----  -----  -------------------------------------
        //  14     52     52     56     Ljava/lang/IndexOutOfBoundsException;
        //  56     68     71     75     Ljava/lang/IndexOutOfBoundsException;
        //  61     85     88     92     Ljava/lang/IndexOutOfBoundsException;
        //  75     101    104    108    Ljava/lang/IndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0075:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public int size() {
        this.ensureAllocated();
        return this.size;
    }
    
    public void clear() {
        this.ensureAllocated();
        this.memory.clear(this.size());
    }
    
    public Pointer getPointer() {
        this.ensureAllocated();
        return this.memory;
    }
    
    static Set<Structure> busy() {
        return Structure.busy.get();
    }
    
    static Map<Pointer, Structure> reading() {
        return Structure.reads.get();
    }
    
    void conditionalAutoRead() {
        try {
            if (!this.readCalled) {
                this.autoRead();
            }
        }
        catch (IndexOutOfBoundsException ex) {
            throw b(ex);
        }
    }
    
    public void read() {
        try {
            if (this.memory == Structure.PLACEHOLDER_MEMORY) {
                return;
            }
        }
        catch (IndexOutOfBoundsException ex) {
            throw b(ex);
        }
        try {
            this.readCalled = true;
            this.ensureAllocated();
            if (busy().contains(this)) {
                return;
            }
        }
        catch (IndexOutOfBoundsException ex2) {
            throw b(ex2);
        }
        try {
            busy().add(this);
            if (this instanceof Structure$ByReference) {
                reading().put(this.getPointer(), this);
            }
        }
        catch (IndexOutOfBoundsException ex3) {
            throw b(ex3);
        }
        try {
            final Iterator<Structure$StructField> iterator = this.fields().values().iterator();
            while (iterator.hasNext()) {
                this.readField(iterator.next());
            }
        }
        finally {
            try {
                busy().remove(this);
                if (reading().get(this.getPointer()) == this) {
                    reading().remove(this.getPointer());
                }
            }
            catch (IndexOutOfBoundsException ex4) {
                throw b(ex4);
            }
        }
    }
    
    protected int fieldOffset(final String str) {
        final int[] b = PointerType.b();
        this.ensureAllocated();
        final int[] array = b;
        final Structure$StructField structure$StructField = this.fields().get(str);
        Label_0037: {
            Structure$StructField structure$StructField2;
            try {
                final Structure$StructField structure$StructField3;
                structure$StructField2 = (structure$StructField3 = structure$StructField);
                if (array == null) {
                    return structure$StructField3.offset;
                }
                if (structure$StructField2 == null) {
                    break Label_0037;
                }
                break Label_0037;
            }
            catch (IndexOutOfBoundsException ex) {
                throw b(ex);
            }
            try {
                if (structure$StructField2 == null) {
                    throw new IllegalArgumentException(a(30788, -13122) + str);
                }
            }
            catch (IndexOutOfBoundsException ex2) {
                throw b(ex2);
            }
        }
        Structure$StructField structure$StructField3 = structure$StructField;
        return structure$StructField3.offset;
    }
    
    public Object readField(final String str) {
        this.ensureAllocated();
        final int[] b = PointerType.b();
        final Structure$StructField structure$StructField = this.fields().get(str);
        final int[] array = b;
        Label_0037: {
            Structure$StructField structure$StructField2;
            try {
                final Object field;
                structure$StructField2 = (Structure$StructField)(field = structure$StructField);
                if (array == null) {
                    return field;
                }
                if (structure$StructField2 == null) {
                    break Label_0037;
                }
                return this.readField(structure$StructField);
            }
            catch (IndexOutOfBoundsException ex) {
                throw b(ex);
            }
            try {
                if (structure$StructField2 == null) {
                    throw new IllegalArgumentException(a(30788, -13122) + str);
                }
            }
            catch (IndexOutOfBoundsException ex2) {
                throw b(ex2);
            }
        }
        return this.readField(structure$StructField);
    }
    
    Object getFieldValue(final Field field) {
        try {
            return field.get(this);
        }
        catch (Exception cause) {
            throw new Error(a(30840, 19597) + field.getName() + a(30845, -29987) + this.getClass(), cause);
        }
    }
    
    void setFieldValue(final Field field, final Object o) {
        this.setFieldValue(field, o, false);
    }
    
    private void setFieldValue(final Field field, final Object value, final boolean b) {
        try {
            field.set(this, value);
        }
        catch (IllegalAccessException ex) {
            final int modifiers = field.getModifiers();
            Label_0036: {
                try {
                    if (!Modifier.isFinal(modifiers)) {
                        throw new Error(a(30815, 31821) + field.getName() + a(30784, 26845) + this.getClass(), ex);
                    }
                    final boolean b2 = b;
                    if (b2) {
                        break Label_0036;
                    }
                    throw new UnsupportedOperationException(a(30831, -14579) + field.getName() + a(30784, 26845) + this.getClass(), ex);
                }
                catch (IllegalAccessException ex2) {
                    throw b(ex2);
                }
                try {
                    final boolean b2 = b;
                    if (b2) {
                        throw new UnsupportedOperationException(a(30833, -26091) + field.getName() + a(30784, 26845) + this.getClass() + ")", ex);
                    }
                }
                catch (IllegalAccessException ex3) {
                    throw b(ex3);
                }
            }
            throw new UnsupportedOperationException(a(30831, -14579) + field.getName() + a(30784, 26845) + this.getClass(), ex);
        }
    }
    
    static Structure updateStructureByReference(final Class<?> clazz, Structure instance, final Pointer pointer) {
        if (pointer == null) {
            instance = null;
        }
        else {
            Label_0088: {
                try {
                    if (instance != null) {
                        if (pointer.equals(instance.getPointer())) {
                            break Label_0088;
                        }
                    }
                }
                catch (IndexOutOfBoundsException ex) {
                    throw b(ex);
                }
                final Structure structure = reading().get(pointer);
                Label_0075: {
                    try {
                        if (structure == null || !clazz.equals(structure.getClass())) {
                            break Label_0075;
                        }
                    }
                    catch (IndexOutOfBoundsException ex2) {
                        throw b(ex2);
                    }
                    instance = structure;
                    instance.autoRead();
                    return instance;
                }
                instance = newInstance(clazz, pointer);
                instance.conditionalAutoRead();
                return instance;
            }
            instance.autoRead();
        }
        return instance;
    }
    
    protected Object readField(final Structure$StructField p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        com/sun/jna/Structure$StructField.offset:I
        //     4: istore_2       
        //     5: aload_1        
        //     6: getfield        com/sun/jna/Structure$StructField.type:Ljava/lang/Class;
        //     9: astore_3       
        //    10: aload_1        
        //    11: getfield        com/sun/jna/Structure$StructField.readConverter:Lcom/sun/jna/FromNativeConverter;
        //    14: astore          4
        //    16: aload           4
        //    18: ifnull          29
        //    21: aload           4
        //    23: invokeinterface com/sun/jna/FromNativeConverter.nativeType:()Ljava/lang/Class;
        //    28: astore_3       
        //    29: ldc             Lcom/sun/jna/Structure;.class
        //    31: aload_3        
        //    32: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //    35: ifne            129
        //    38: ldc             Lcom/sun/jna/Callback;.class
        //    40: aload_3        
        //    41: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //    44: ifne            129
        //    47: goto            54
        //    50: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    53: athrow         
        //    54: getstatic       com/sun/jna/Platform.HAS_BUFFERS:Z
        //    57: ifeq            83
        //    60: goto            67
        //    63: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    66: athrow         
        //    67: ldc             Ljava/nio/Buffer;.class
        //    69: aload_3        
        //    70: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //    73: ifne            129
        //    76: goto            83
        //    79: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    82: athrow         
        //    83: ldc             Lcom/sun/jna/Pointer;.class
        //    85: aload_3        
        //    86: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //    89: ifne            129
        //    92: goto            99
        //    95: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    98: athrow         
        //    99: ldc             Lcom/sun/jna/NativeMapped;.class
        //   101: aload_3        
        //   102: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //   105: ifne            129
        //   108: goto            115
        //   111: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   114: athrow         
        //   115: aload_3        
        //   116: invokevirtual   java/lang/Class.isArray:()Z
        //   119: ifeq            144
        //   122: goto            129
        //   125: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   128: athrow         
        //   129: aload_0        
        //   130: aload_1        
        //   131: getfield        com/sun/jna/Structure$StructField.field:Ljava/lang/reflect/Field;
        //   134: invokevirtual   com/sun/jna/Structure.getFieldValue:(Ljava/lang/reflect/Field;)Ljava/lang/Object;
        //   137: goto            145
        //   140: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   143: athrow         
        //   144: aconst_null    
        //   145: astore          5
        //   147: aload_3        
        //   148: ldc             Ljava/lang/String;.class
        //   150: if_acmpne       192
        //   153: aload_0        
        //   154: getfield        com/sun/jna/Structure.memory:Lcom/sun/jna/Pointer;
        //   157: iload_2        
        //   158: i2l            
        //   159: invokevirtual   com/sun/jna/Pointer.getPointer:(J)Lcom/sun/jna/Pointer;
        //   162: astore          7
        //   164: aload           7
        //   166: ifnonnull       177
        //   169: aconst_null    
        //   170: goto            187
        //   173: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   176: athrow         
        //   177: aload           7
        //   179: lconst_0       
        //   180: aload_0        
        //   181: getfield        com/sun/jna/Structure.encoding:Ljava/lang/String;
        //   184: invokevirtual   com/sun/jna/Pointer.getString:(JLjava/lang/String;)Ljava/lang/String;
        //   187: astore          6
        //   189: goto            206
        //   192: aload_0        
        //   193: getfield        com/sun/jna/Structure.memory:Lcom/sun/jna/Pointer;
        //   196: iload_2        
        //   197: i2l            
        //   198: aload_3        
        //   199: aload           5
        //   201: invokevirtual   com/sun/jna/Pointer.getValue:(JLjava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;
        //   204: astore          6
        //   206: aload           4
        //   208: ifnull          252
        //   211: aload           4
        //   213: aload           6
        //   215: aload_1        
        //   216: getfield        com/sun/jna/Structure$StructField.context:Lcom/sun/jna/FromNativeContext;
        //   219: invokeinterface com/sun/jna/FromNativeConverter.fromNative:(Ljava/lang/Object;Lcom/sun/jna/FromNativeContext;)Ljava/lang/Object;
        //   224: astore          6
        //   226: aload           5
        //   228: ifnull          252
        //   231: aload           5
        //   233: aload           6
        //   235: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   238: ifeq            252
        //   241: goto            248
        //   244: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   247: athrow         
        //   248: aload           5
        //   250: astore          6
        //   252: aload_3        
        //   253: ldc             Ljava/lang/String;.class
        //   255: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   258: ifne            277
        //   261: aload_3        
        //   262: ldc             Lcom/sun/jna/WString;.class
        //   264: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   267: ifeq            373
        //   270: goto            277
        //   273: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   276: athrow         
        //   277: aload_0        
        //   278: getfield        com/sun/jna/Structure.nativeStrings:Ljava/util/Map;
        //   281: new             Ljava/lang/StringBuilder;
        //   284: dup            
        //   285: invokespecial   java/lang/StringBuilder.<init>:()V
        //   288: aload_1        
        //   289: getfield        com/sun/jna/Structure$StructField.name:Ljava/lang/String;
        //   292: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   295: sipush          30786
        //   298: sipush          30186
        //   301: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   304: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   307: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   310: aload_0        
        //   311: getfield        com/sun/jna/Structure.memory:Lcom/sun/jna/Pointer;
        //   314: iload_2        
        //   315: i2l            
        //   316: invokevirtual   com/sun/jna/Pointer.getPointer:(J)Lcom/sun/jna/Pointer;
        //   319: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   324: pop            
        //   325: aload_0        
        //   326: getfield        com/sun/jna/Structure.nativeStrings:Ljava/util/Map;
        //   329: new             Ljava/lang/StringBuilder;
        //   332: dup            
        //   333: invokespecial   java/lang/StringBuilder.<init>:()V
        //   336: aload_1        
        //   337: getfield        com/sun/jna/Structure$StructField.name:Ljava/lang/String;
        //   340: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   343: sipush          30824
        //   346: sipush          26760
        //   349: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   352: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   355: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   358: aload           6
        //   360: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   365: pop            
        //   366: goto            373
        //   369: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   372: athrow         
        //   373: aload_0        
        //   374: aload_1        
        //   375: getfield        com/sun/jna/Structure$StructField.field:Ljava/lang/reflect/Field;
        //   378: aload           6
        //   380: iconst_1       
        //   381: invokespecial   com/sun/jna/Structure.setFieldValue:(Ljava/lang/reflect/Field;Ljava/lang/Object;Z)V
        //   384: aload           6
        //   386: areturn        
        //    StackMapTable: 00 1C FE 00 1D 01 07 01 27 07 01 B0 54 07 00 4E 03 48 07 00 4E 03 4B 07 00 4E 03 4B 07 00 4E 03 4B 07 00 4E 03 49 07 00 4E 03 4A 07 00 4E 03 40 07 01 29 FF 00 1B 00 08 07 00 01 07 00 6C 01 07 01 27 07 01 B0 07 01 29 00 07 00 06 00 01 07 00 4E 03 49 07 00 08 F9 00 04 FC 00 0D 07 01 29 65 07 00 4E 03 03 54 07 00 4E 03 F7 00 5B 07 00 4E 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                 
        //  -----  -----  -----  -----  -------------------------------------
        //  29     47     50     54     Ljava/lang/IndexOutOfBoundsException;
        //  38     60     63     67     Ljava/lang/IndexOutOfBoundsException;
        //  54     76     79     83     Ljava/lang/IndexOutOfBoundsException;
        //  67     92     95     99     Ljava/lang/IndexOutOfBoundsException;
        //  83     108    111    115    Ljava/lang/IndexOutOfBoundsException;
        //  99     122    125    129    Ljava/lang/IndexOutOfBoundsException;
        //  115    140    140    144    Ljava/lang/IndexOutOfBoundsException;
        //  164    173    173    177    Ljava/lang/IndexOutOfBoundsException;
        //  226    241    244    248    Ljava/lang/IndexOutOfBoundsException;
        //  252    270    273    277    Ljava/lang/IndexOutOfBoundsException;
        //  261    366    369    373    Ljava/lang/IndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0054:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void write() {
        try {
            if (this.memory == Structure.PLACEHOLDER_MEMORY) {
                return;
            }
        }
        catch (IndexOutOfBoundsException ex) {
            throw b(ex);
        }
        try {
            this.ensureAllocated();
            if (this instanceof Structure$ByValue) {
                this.getTypeInfo();
            }
        }
        catch (IndexOutOfBoundsException ex2) {
            throw b(ex2);
        }
        try {
            if (busy().contains(this)) {
                return;
            }
        }
        catch (IndexOutOfBoundsException ex3) {
            throw b(ex3);
        }
        busy().add(this);
        try {
            for (final Structure$StructField structure$StructField : this.fields().values()) {
                try {
                    if (structure$StructField.isVolatile) {
                        continue;
                    }
                    this.writeField(structure$StructField);
                }
                catch (IndexOutOfBoundsException ex4) {
                    throw b(ex4);
                }
            }
        }
        finally {
            busy().remove(this);
        }
    }
    
    public void writeField(final String str) {
        this.ensureAllocated();
        final Structure$StructField structure$StructField = this.fields().get(str);
        try {
            if (structure$StructField == null) {
                throw new IllegalArgumentException(a(30788, -13122) + str);
            }
        }
        catch (IndexOutOfBoundsException ex) {
            throw b(ex);
        }
        this.writeField(structure$StructField);
    }
    
    public void writeField(final String str, final Object o) {
        this.ensureAllocated();
        final Structure$StructField structure$StructField = this.fields().get(str);
        try {
            if (structure$StructField == null) {
                throw new IllegalArgumentException(a(30788, -13122) + str);
            }
        }
        catch (IndexOutOfBoundsException ex) {
            throw b(ex);
        }
        this.setFieldValue(structure$StructField.field, o);
        this.writeField(structure$StructField);
    }
    
    protected void writeField(final Structure$StructField p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        com/sun/jna/Structure$StructField.isReadOnly:Z
        //     4: ifeq            12
        //     7: return         
        //     8: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    11: athrow         
        //    12: aload_1        
        //    13: getfield        com/sun/jna/Structure$StructField.offset:I
        //    16: istore_2       
        //    17: aload_0        
        //    18: aload_1        
        //    19: getfield        com/sun/jna/Structure$StructField.field:Ljava/lang/reflect/Field;
        //    22: invokevirtual   com/sun/jna/Structure.getFieldValue:(Ljava/lang/reflect/Field;)Ljava/lang/Object;
        //    25: astore_3       
        //    26: aload_1        
        //    27: getfield        com/sun/jna/Structure$StructField.type:Ljava/lang/Class;
        //    30: astore          4
        //    32: aload_1        
        //    33: getfield        com/sun/jna/Structure$StructField.writeConverter:Lcom/sun/jna/ToNativeConverter;
        //    36: astore          5
        //    38: aload           5
        //    40: ifnull          73
        //    43: aload           5
        //    45: aload_3        
        //    46: new             Lcom/sun/jna/StructureWriteContext;
        //    49: dup            
        //    50: aload_0        
        //    51: aload_1        
        //    52: getfield        com/sun/jna/Structure$StructField.field:Ljava/lang/reflect/Field;
        //    55: invokespecial   com/sun/jna/StructureWriteContext.<init>:(Lcom/sun/jna/Structure;Ljava/lang/reflect/Field;)V
        //    58: invokeinterface com/sun/jna/ToNativeConverter.toNative:(Ljava/lang/Object;Lcom/sun/jna/ToNativeContext;)Ljava/lang/Object;
        //    63: astore_3       
        //    64: aload           5
        //    66: invokeinterface com/sun/jna/ToNativeConverter.nativeType:()Ljava/lang/Class;
        //    71: astore          4
        //    73: ldc             Ljava/lang/String;.class
        //    75: aload           4
        //    77: if_acmpeq       94
        //    80: ldc             Lcom/sun/jna/WString;.class
        //    82: aload           4
        //    84: if_acmpne       386
        //    87: goto            94
        //    90: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    93: athrow         
        //    94: aload           4
        //    96: ldc             Lcom/sun/jna/WString;.class
        //    98: if_acmpne       116
        //   101: goto            108
        //   104: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   107: athrow         
        //   108: iconst_1       
        //   109: goto            117
        //   112: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   115: athrow         
        //   116: iconst_0       
        //   117: istore          6
        //   119: aload_3        
        //   120: ifnull          294
        //   123: aload_0        
        //   124: getfield        com/sun/jna/Structure.nativeStrings:Ljava/util/Map;
        //   127: new             Ljava/lang/StringBuilder;
        //   130: dup            
        //   131: invokespecial   java/lang/StringBuilder.<init>:()V
        //   134: aload_1        
        //   135: getfield        com/sun/jna/Structure$StructField.name:Ljava/lang/String;
        //   138: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   141: sipush          30786
        //   144: sipush          30186
        //   147: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   150: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   153: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   156: invokeinterface java/util/Map.containsKey:(Ljava/lang/Object;)Z
        //   161: ifeq            228
        //   164: goto            171
        //   167: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   170: athrow         
        //   171: aload_3        
        //   172: aload_0        
        //   173: getfield        com/sun/jna/Structure.nativeStrings:Ljava/util/Map;
        //   176: new             Ljava/lang/StringBuilder;
        //   179: dup            
        //   180: invokespecial   java/lang/StringBuilder.<init>:()V
        //   183: aload_1        
        //   184: getfield        com/sun/jna/Structure$StructField.name:Ljava/lang/String;
        //   187: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   190: sipush          30824
        //   193: sipush          26760
        //   196: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   199: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   202: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   205: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   210: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   213: ifeq            228
        //   216: goto            223
        //   219: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   222: athrow         
        //   223: return         
        //   224: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   227: athrow         
        //   228: iload           6
        //   230: ifeq            252
        //   233: new             Lcom/sun/jna/NativeString;
        //   236: dup            
        //   237: aload_3        
        //   238: invokevirtual   java/lang/Object.toString:()Ljava/lang/String;
        //   241: iconst_1       
        //   242: invokespecial   com/sun/jna/NativeString.<init>:(Ljava/lang/String;Z)V
        //   245: goto            267
        //   248: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   251: athrow         
        //   252: new             Lcom/sun/jna/NativeString;
        //   255: dup            
        //   256: aload_3        
        //   257: invokevirtual   java/lang/Object.toString:()Ljava/lang/String;
        //   260: aload_0        
        //   261: getfield        com/sun/jna/Structure.encoding:Ljava/lang/String;
        //   264: invokespecial   com/sun/jna/NativeString.<init>:(Ljava/lang/String;Ljava/lang/String;)V
        //   267: astore          7
        //   269: aload_0        
        //   270: getfield        com/sun/jna/Structure.nativeStrings:Ljava/util/Map;
        //   273: aload_1        
        //   274: getfield        com/sun/jna/Structure$StructField.name:Ljava/lang/String;
        //   277: aload           7
        //   279: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   284: pop            
        //   285: aload           7
        //   287: invokevirtual   com/sun/jna/NativeString.getPointer:()Lcom/sun/jna/Pointer;
        //   290: astore_3       
        //   291: goto            308
        //   294: aload_0        
        //   295: getfield        com/sun/jna/Structure.nativeStrings:Ljava/util/Map;
        //   298: aload_1        
        //   299: getfield        com/sun/jna/Structure$StructField.name:Ljava/lang/String;
        //   302: invokeinterface java/util/Map.remove:(Ljava/lang/Object;)Ljava/lang/Object;
        //   307: pop            
        //   308: aload_0        
        //   309: getfield        com/sun/jna/Structure.nativeStrings:Ljava/util/Map;
        //   312: new             Ljava/lang/StringBuilder;
        //   315: dup            
        //   316: invokespecial   java/lang/StringBuilder.<init>:()V
        //   319: aload_1        
        //   320: getfield        com/sun/jna/Structure$StructField.name:Ljava/lang/String;
        //   323: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   326: sipush          30786
        //   329: sipush          30186
        //   332: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   335: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   338: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   341: invokeinterface java/util/Map.remove:(Ljava/lang/Object;)Ljava/lang/Object;
        //   346: pop            
        //   347: aload_0        
        //   348: getfield        com/sun/jna/Structure.nativeStrings:Ljava/util/Map;
        //   351: new             Ljava/lang/StringBuilder;
        //   354: dup            
        //   355: invokespecial   java/lang/StringBuilder.<init>:()V
        //   358: aload_1        
        //   359: getfield        com/sun/jna/Structure$StructField.name:Ljava/lang/String;
        //   362: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   365: sipush          30824
        //   368: sipush          26760
        //   371: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   374: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   377: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   380: invokeinterface java/util/Map.remove:(Ljava/lang/Object;)Ljava/lang/Object;
        //   385: pop            
        //   386: aload_0        
        //   387: getfield        com/sun/jna/Structure.memory:Lcom/sun/jna/Pointer;
        //   390: iload_2        
        //   391: i2l            
        //   392: aload_3        
        //   393: aload           4
        //   395: invokevirtual   com/sun/jna/Pointer.setValue:(JLjava/lang/Object;Ljava/lang/Class;)V
        //   398: goto            530
        //   401: astore          6
        //   403: new             Ljava/lang/StringBuilder;
        //   406: dup            
        //   407: invokespecial   java/lang/StringBuilder.<init>:()V
        //   410: sipush          30846
        //   413: sipush          -14900
        //   416: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   419: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   422: aload_1        
        //   423: getfield        com/sun/jna/Structure$StructField.name:Ljava/lang/String;
        //   426: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   429: sipush          30789
        //   432: sipush          -5770
        //   435: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   438: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   441: aload_1        
        //   442: getfield        com/sun/jna/Structure$StructField.type:Ljava/lang/Class;
        //   445: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   448: aload_1        
        //   449: getfield        com/sun/jna/Structure$StructField.type:Ljava/lang/Class;
        //   452: aload           4
        //   454: if_acmpne       466
        //   457: ldc             ""
        //   459: goto            498
        //   462: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   465: athrow         
        //   466: new             Ljava/lang/StringBuilder;
        //   469: dup            
        //   470: invokespecial   java/lang/StringBuilder.<init>:()V
        //   473: sipush          30828
        //   476: sipush          -30897
        //   479: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   482: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   485: aload           4
        //   487: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   490: ldc             ")"
        //   492: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   495: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   498: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   501: sipush          30827
        //   504: sipush          18541
        //   507: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   510: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   513: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   516: astore          7
        //   518: new             Ljava/lang/IllegalArgumentException;
        //   521: dup            
        //   522: aload           7
        //   524: aload           6
        //   526: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;Ljava/lang/Throwable;)V
        //   529: athrow         
        //   530: return         
        //    StackMapTable: 00 1B 48 07 00 4F 03 FF 00 3C 00 06 07 00 01 07 00 6C 01 07 01 29 07 01 27 07 01 B6 00 00 50 07 00 4F 03 49 07 00 4F 03 43 07 00 4F 03 40 01 FF 00 31 00 07 07 00 01 07 00 6C 01 07 01 29 07 01 27 07 01 B6 01 00 01 07 00 4F 03 6F 07 00 4F 03 40 07 00 4F 03 53 07 00 4F 03 4E 07 00 9C 1A 0D FA 00 4D 4E 07 00 4F FF 00 3C 00 07 07 00 01 07 00 6C 01 07 01 29 07 01 27 07 01 B6 07 00 4F 00 01 07 00 4F 43 07 00 53 FF 00 1F 00 07 07 00 01 07 00 6C 01 07 01 29 07 01 27 07 01 B6 07 00 4F 00 02 07 00 53 07 00 08 FA 00 1F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  228    248    248    252    Ljava/lang/IllegalArgumentException;
        //  171    224    224    228    Ljava/lang/IllegalArgumentException;
        //  123    216    219    223    Ljava/lang/IllegalArgumentException;
        //  119    164    167    171    Ljava/lang/IllegalArgumentException;
        //  94     112    112    116    Ljava/lang/IllegalArgumentException;
        //  80     101    104    108    Ljava/lang/IllegalArgumentException;
        //  73     87     90     94     Ljava/lang/IllegalArgumentException;
        //  0      8      8      12     Ljava/lang/IllegalArgumentException;
        //  386    398    401    530    Ljava/lang/IllegalArgumentException;
        //  403    462    462    466    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0094:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    protected abstract List<String> getFieldOrder();
    
    @Deprecated
    protected final void setFieldOrder(final String[] array) {
        throw new Error(a(30841, 29138));
    }
    
    protected void sortFields(final List<Field> list, final List<String> list2) {
        for (int i = 0; i < list2.size(); ++i) {
            final String s = list2.get(i);
            for (int j = 0; j < list.size(); ++j) {
                final Field field = list.get(j);
                try {
                    if (s.equals(field.getName())) {
                        Collections.swap(list, i, j);
                        break;
                    }
                }
                catch (IndexOutOfBoundsException ex) {
                    throw b(ex);
                }
            }
        }
    }
    
    protected List<Field> getFieldList() {
        final ArrayList<Field> list = new ArrayList<Field>();
        for (Serializable s = this.getClass(); !s.equals(Structure.class); s = ((Class<? extends Structure>)s).getSuperclass()) {
            final ArrayList<Field> list2 = new ArrayList<Field>();
            final Field[] declaredFields = ((Class)s).getDeclaredFields();
            for (int i = 0; i < declaredFields.length; ++i) {
                final int modifiers = declaredFields[i].getModifiers();
                Label_0080: {
                    try {
                        if (Modifier.isStatic(modifiers)) {
                            continue;
                        }
                        final int n = modifiers;
                        final boolean b = Modifier.isPublic(n);
                        if (!b) {
                            break Label_0080;
                        }
                        break Label_0080;
                    }
                    catch (IndexOutOfBoundsException ex) {
                        throw b(ex);
                    }
                    try {
                        final int n = modifiers;
                        final boolean b = Modifier.isPublic(n);
                        if (!b) {
                            continue;
                        }
                    }
                    catch (IndexOutOfBoundsException ex2) {
                        throw b(ex2);
                    }
                }
                list2.add(declaredFields[i]);
            }
            list.addAll(0, (Collection<?>)list2);
        }
        return list;
    }
    
    private List<String> fieldOrder() {
        final Class<? extends Structure> class1 = this.getClass();
        synchronized (Structure.fieldOrder) {
            List<String> fieldOrder = Structure.fieldOrder.get(class1);
            if (fieldOrder == null) {
                fieldOrder = this.getFieldOrder();
                Structure.fieldOrder.put(class1, fieldOrder);
            }
            return fieldOrder;
        }
    }
    
    public static List<String> createFieldsOrder(final List<String> list, final String... a) {
        return createFieldsOrder(list, Arrays.asList(a));
    }
    
    public static List<String> createFieldsOrder(final List<String> list, final List<String> list2) {
        final ArrayList list3 = new ArrayList(list.size() + list2.size());
        list3.addAll(list);
        list3.addAll(list2);
        return Collections.unmodifiableList((List<? extends String>)list3);
    }
    
    public static List<String> createFieldsOrder(final String o) {
        return Collections.unmodifiableList((List<? extends String>)Collections.singletonList((T)o));
    }
    
    public static List<String> createFieldsOrder(final String... a) {
        return Collections.unmodifiableList((List<? extends String>)Arrays.asList((T[])a));
    }
    
    private static <T extends Comparable<T>> List<T> sort(final Collection<? extends T> c) {
        final ArrayList<Comparable> list = new ArrayList<Comparable>(c);
        Collections.sort(list);
        return (List<T>)list;
    }
    
    protected List<Field> getFields(final boolean p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokevirtual   com/sun/jna/Structure.getFieldList:()Ljava/util/List;
        //     4: astore_2       
        //     5: new             Ljava/util/HashSet;
        //     8: dup            
        //     9: invokespecial   java/util/HashSet.<init>:()V
        //    12: astore_3       
        //    13: aload_2        
        //    14: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //    19: astore          4
        //    21: aload           4
        //    23: invokeinterface java/util/Iterator.hasNext:()Z
        //    28: ifeq            58
        //    31: aload           4
        //    33: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //    38: checkcast       Ljava/lang/reflect/Field;
        //    41: astore          5
        //    43: aload_3        
        //    44: aload           5
        //    46: invokevirtual   java/lang/reflect/Field.getName:()Ljava/lang/String;
        //    49: invokeinterface java/util/Set.add:(Ljava/lang/Object;)Z
        //    54: pop            
        //    55: goto            21
        //    58: aload_0        
        //    59: invokespecial   com/sun/jna/Structure.fieldOrder:()Ljava/util/List;
        //    62: astore          4
        //    64: aload           4
        //    66: invokeinterface java/util/List.size:()I
        //    71: aload_2        
        //    72: invokeinterface java/util/List.size:()I
        //    77: if_icmpeq       238
        //    80: aload_2        
        //    81: invokeinterface java/util/List.size:()I
        //    86: iconst_1       
        //    87: if_icmple       238
        //    90: goto            97
        //    93: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    96: athrow         
        //    97: iload_1        
        //    98: ifeq            236
        //   101: goto            108
        //   104: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   107: athrow         
        //   108: new             Ljava/lang/Error;
        //   111: dup            
        //   112: new             Ljava/lang/StringBuilder;
        //   115: dup            
        //   116: invokespecial   java/lang/StringBuilder.<init>:()V
        //   119: sipush          30798
        //   122: sipush          -1148
        //   125: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   128: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   131: aload_0        
        //   132: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //   135: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   138: sipush          30792
        //   141: sipush          -27156
        //   144: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   147: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   150: aload           4
        //   152: invokeinterface java/util/List.size:()I
        //   157: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //   160: sipush          30821
        //   163: sipush          4609
        //   166: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   169: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   172: aload           4
        //   174: invokestatic    com/sun/jna/Structure.sort:(Ljava/util/Collection;)Ljava/util/List;
        //   177: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   180: sipush          30818
        //   183: sipush          1037
        //   186: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   189: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   192: aload_2        
        //   193: invokeinterface java/util/List.size:()I
        //   198: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //   201: sipush          30821
        //   204: sipush          4609
        //   207: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   210: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   213: aload_3        
        //   214: invokestatic    com/sun/jna/Structure.sort:(Ljava/util/Collection;)Ljava/util/List;
        //   217: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   220: ldc             ")"
        //   222: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   225: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   228: invokespecial   java/lang/Error.<init>:(Ljava/lang/String;)V
        //   231: athrow         
        //   232: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   235: athrow         
        //   236: aconst_null    
        //   237: areturn        
        //   238: new             Ljava/util/HashSet;
        //   241: dup            
        //   242: aload           4
        //   244: invokespecial   java/util/HashSet.<init>:(Ljava/util/Collection;)V
        //   247: astore          5
        //   249: aload           5
        //   251: aload_3        
        //   252: invokeinterface java/util/Set.equals:(Ljava/lang/Object;)Z
        //   257: ifne            345
        //   260: new             Ljava/lang/Error;
        //   263: dup            
        //   264: new             Ljava/lang/StringBuilder;
        //   267: dup            
        //   268: invokespecial   java/lang/StringBuilder.<init>:()V
        //   271: sipush          30798
        //   274: sipush          -1148
        //   277: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   280: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   283: aload_0        
        //   284: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //   287: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   290: sipush          30832
        //   293: sipush          -23035
        //   296: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   299: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   302: aload           4
        //   304: invokestatic    com/sun/jna/Structure.sort:(Ljava/util/Collection;)Ljava/util/List;
        //   307: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   310: sipush          30823
        //   313: sipush          15813
        //   316: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   319: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   322: aload_3        
        //   323: invokestatic    com/sun/jna/Structure.sort:(Ljava/util/Collection;)Ljava/util/List;
        //   326: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   329: ldc             ")"
        //   331: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   334: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   337: invokespecial   java/lang/Error.<init>:(Ljava/lang/String;)V
        //   340: athrow         
        //   341: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   344: athrow         
        //   345: aload_0        
        //   346: aload_2        
        //   347: aload           4
        //   349: invokevirtual   com/sun/jna/Structure.sortFields:(Ljava/util/List;Ljava/util/List;)V
        //   352: aload_2        
        //   353: areturn        
        //    Signature:
        //  (Z)Ljava/util/List<Ljava/lang/reflect/Field;>;
        //    StackMapTable: 00 0B FE 00 15 07 00 B1 07 00 BC 07 01 9B 24 FF 00 22 00 05 07 00 01 01 07 00 B1 07 00 BC 07 00 B1 00 01 07 00 4E 03 46 07 00 4E 03 F7 00 7B 07 00 4E 03 01 FF 00 66 00 06 07 00 01 01 07 00 B1 07 00 BC 07 00 B1 07 00 BC 00 01 07 00 4E 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                 
        //  -----  -----  -----  -----  -------------------------------------
        //  64     90     93     97     Ljava/lang/IndexOutOfBoundsException;
        //  80     101    104    108    Ljava/lang/IndexOutOfBoundsException;
        //  97     232    232    236    Ljava/lang/IndexOutOfBoundsException;
        //  249    341    341    345    Ljava/lang/IndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0097:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    protected int calculateSize(final boolean b) {
        return this.calculateSize(b, false);
    }
    
    static int size(final Class<?> clazz) {
        return size(clazz, null);
    }
    
    static int size(final Class<?> clazz, Structure instance) {
        final Structure$LayoutInfo structure$LayoutInfo;
        synchronized (Structure.layoutInfo) {
            structure$LayoutInfo = Structure.layoutInfo.get(clazz);
        }
        int access$100 = 0;
        Label_0061: {
            Label_0049: {
                try {
                    if (structure$LayoutInfo == null) {
                        break Label_0049;
                    }
                    final Structure$LayoutInfo structure$LayoutInfo2 = structure$LayoutInfo;
                    final boolean b = Structure$LayoutInfo.access$000(structure$LayoutInfo2);
                    if (!b) {
                        break Label_0049;
                    }
                    break Label_0049;
                }
                catch (IndexOutOfBoundsException ex) {
                    throw b(ex);
                }
                try {
                    final Structure$LayoutInfo structure$LayoutInfo2 = structure$LayoutInfo;
                    final boolean b = Structure$LayoutInfo.access$000(structure$LayoutInfo2);
                    if (!b) {
                        access$100 = Structure$LayoutInfo.access$100(structure$LayoutInfo);
                        break Label_0061;
                    }
                }
                catch (IndexOutOfBoundsException ex2) {
                    throw b(ex2);
                }
            }
            access$100 = -1;
        }
        int size = access$100;
        try {
            if (size != -1) {
                return size;
            }
            if (instance != null) {
                return instance.size();
            }
        }
        catch (IndexOutOfBoundsException ex3) {
            throw b(ex3);
        }
        instance = newInstance(clazz, Structure.PLACEHOLDER_MEMORY);
        size = instance.size();
        return size;
    }
    
    int calculateSize(final boolean b, final boolean b2) {
        int access$100 = -1;
        final Class<? extends Structure> class1 = this.getClass();
        Structure$LayoutInfo deriveLayout;
        synchronized (Structure.layoutInfo) {
            deriveLayout = Structure.layoutInfo.get(class1);
        }
        Label_0095: {
            Label_0068: {
                try {
                    if (deriveLayout == null) {
                        break Label_0068;
                    }
                    final Structure structure = this;
                    final int n = structure.alignType;
                    final Structure$LayoutInfo structure$LayoutInfo = deriveLayout;
                    final int n2 = Structure$LayoutInfo.access$200(structure$LayoutInfo);
                    if (n == n2) {
                        break Label_0068;
                    }
                    break Label_0068;
                }
                catch (IndexOutOfBoundsException ex) {
                    throw b(ex);
                }
                try {
                    final Structure structure = this;
                    final int n = structure.alignType;
                    final Structure$LayoutInfo structure$LayoutInfo = deriveLayout;
                    final int n2 = Structure$LayoutInfo.access$200(structure$LayoutInfo);
                    if (n == n2) {
                        if (this.typeMapper == Structure$LayoutInfo.access$300(deriveLayout)) {
                            break Label_0095;
                        }
                    }
                }
                catch (IndexOutOfBoundsException ex2) {
                    throw b(ex2);
                }
            }
            deriveLayout = this.deriveLayout(b, b2);
            try {
                if (deriveLayout == null) {
                    return access$100;
                }
                this.structAlignment = Structure$LayoutInfo.access$400(deriveLayout);
                this.structFields = (Map<String, Structure$StructField>)Structure$LayoutInfo.access$500(deriveLayout);
                if (Structure$LayoutInfo.access$000(deriveLayout)) {
                    return Structure$LayoutInfo.access$100(deriveLayout);
                }
            }
            catch (IndexOutOfBoundsException ex3) {
                throw b(ex3);
            }
        }
        synchronized (Structure.layoutInfo) {
            Label_0174: {
                if (!Structure.layoutInfo.containsKey(class1)) {
                    break Label_0174;
                }
                try {
                    if (this.alignType != 0) {
                        break Label_0174;
                    }
                    final Structure structure2 = this;
                    final TypeMapper typeMapper = structure2.typeMapper;
                    if (typeMapper != null) {
                        break Label_0174;
                    }
                    return Structure$LayoutInfo.access$100(deriveLayout);
                }
                catch (IndexOutOfBoundsException ex4) {
                    throw b(ex4);
                }
                try {
                    final Structure structure2 = this;
                    final TypeMapper typeMapper = structure2.typeMapper;
                    if (typeMapper != null) {
                        Structure.layoutInfo.put(class1, deriveLayout);
                    }
                }
                catch (IndexOutOfBoundsException ex5) {
                    throw b(ex5);
                }
            }
        }
        access$100 = Structure$LayoutInfo.access$100(deriveLayout);
        return access$100;
    }
    
    private void validateField(final String str, final Class<?> obj) {
        if (this.typeMapper != null) {
            final ToNativeConverter toNativeConverter = this.typeMapper.getToNativeConverter(obj);
            try {
                if (toNativeConverter != null) {
                    this.validateField(str, toNativeConverter.nativeType());
                    return;
                }
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
        }
        try {
            if (obj.isArray()) {
                this.validateField(str, obj.getComponentType());
                return;
            }
        }
        catch (IllegalArgumentException ex2) {
            throw b(ex2);
        }
        try {
            this.getNativeSize(obj);
        }
        catch (IllegalArgumentException cause) {
            throw new IllegalArgumentException(a(30822, -10460) + this.getClass() + a(30844, -24842) + str + a(30835, -30486) + obj + a(30787, 11888) + cause.getMessage(), cause);
        }
    }
    
    private void validateFields() {
        for (final Field field : this.getFieldList()) {
            this.validateField(field.getName(), field.getType());
        }
    }
    
    private Structure$LayoutInfo deriveLayout(final boolean p0, final boolean p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: istore_3       
        //     2: aload_0        
        //     3: iload_1        
        //     4: invokevirtual   com/sun/jna/Structure.getFields:(Z)Ljava/util/List;
        //     7: astore          4
        //     9: aload           4
        //    11: ifnonnull       20
        //    14: aconst_null    
        //    15: areturn        
        //    16: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    19: athrow         
        //    20: new             Lcom/sun/jna/Structure$LayoutInfo;
        //    23: dup            
        //    24: aconst_null    
        //    25: invokespecial   com/sun/jna/Structure$LayoutInfo.<init>:(Lcom/sun/jna/Structure$1;)V
        //    28: astore          5
        //    30: aload           5
        //    32: aload_0        
        //    33: getfield        com/sun/jna/Structure.alignType:I
        //    36: invokestatic    com/sun/jna/Structure$LayoutInfo.access$202:(Lcom/sun/jna/Structure$LayoutInfo;I)I
        //    39: pop            
        //    40: aload           5
        //    42: aload_0        
        //    43: getfield        com/sun/jna/Structure.typeMapper:Lcom/sun/jna/TypeMapper;
        //    46: invokestatic    com/sun/jna/Structure$LayoutInfo.access$302:(Lcom/sun/jna/Structure$LayoutInfo;Lcom/sun/jna/TypeMapper;)Lcom/sun/jna/TypeMapper;
        //    49: pop            
        //    50: iconst_1       
        //    51: istore          6
        //    53: aload           4
        //    55: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //    60: astore          7
        //    62: aload           7
        //    64: invokeinterface java/util/Iterator.hasNext:()Z
        //    69: ifeq            1150
        //    72: aload           7
        //    74: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //    79: checkcast       Ljava/lang/reflect/Field;
        //    82: astore          8
        //    84: aload           8
        //    86: invokevirtual   java/lang/reflect/Field.getModifiers:()I
        //    89: istore          9
        //    91: aload           8
        //    93: invokevirtual   java/lang/reflect/Field.getType:()Ljava/lang/Class;
        //    96: astore          10
        //    98: aload           10
        //   100: invokevirtual   java/lang/Class.isArray:()Z
        //   103: ifeq            120
        //   106: aload           5
        //   108: iconst_1       
        //   109: invokestatic    com/sun/jna/Structure$LayoutInfo.access$002:(Lcom/sun/jna/Structure$LayoutInfo;Z)Z
        //   112: pop            
        //   113: goto            120
        //   116: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   119: athrow         
        //   120: new             Lcom/sun/jna/Structure$StructField;
        //   123: dup            
        //   124: invokespecial   com/sun/jna/Structure$StructField.<init>:()V
        //   127: astore          11
        //   129: aload           11
        //   131: iload           9
        //   133: invokestatic    java/lang/reflect/Modifier.isVolatile:(I)Z
        //   136: putfield        com/sun/jna/Structure$StructField.isVolatile:Z
        //   139: aload           11
        //   141: iload           9
        //   143: invokestatic    java/lang/reflect/Modifier.isFinal:(I)Z
        //   146: putfield        com/sun/jna/Structure$StructField.isReadOnly:Z
        //   149: aload           11
        //   151: getfield        com/sun/jna/Structure$StructField.isReadOnly:Z
        //   154: ifeq            242
        //   157: getstatic       com/sun/jna/Platform.RO_FIELDS:Z
        //   160: ifne            236
        //   163: goto            170
        //   166: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   169: athrow         
        //   170: new             Ljava/lang/IllegalArgumentException;
        //   173: dup            
        //   174: new             Ljava/lang/StringBuilder;
        //   177: dup            
        //   178: invokespecial   java/lang/StringBuilder.<init>:()V
        //   181: sipush          30842
        //   184: sipush          -8115
        //   187: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   190: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   193: aload           8
        //   195: invokevirtual   java/lang/reflect/Field.getName:()Ljava/lang/String;
        //   198: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   201: sipush          30784
        //   204: sipush          26845
        //   207: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   210: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   213: aload_0        
        //   214: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //   217: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   220: ldc             ")"
        //   222: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   225: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   228: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //   231: athrow         
        //   232: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   235: athrow         
        //   236: aload           8
        //   238: iconst_1       
        //   239: invokevirtual   java/lang/reflect/Field.setAccessible:(Z)V
        //   242: aload           11
        //   244: aload           8
        //   246: putfield        com/sun/jna/Structure$StructField.field:Ljava/lang/reflect/Field;
        //   249: aload           11
        //   251: aload           8
        //   253: invokevirtual   java/lang/reflect/Field.getName:()Ljava/lang/String;
        //   256: putfield        com/sun/jna/Structure$StructField.name:Ljava/lang/String;
        //   259: aload           11
        //   261: aload           10
        //   263: putfield        com/sun/jna/Structure$StructField.type:Ljava/lang/Class;
        //   266: ldc             Lcom/sun/jna/Callback;.class
        //   268: aload           10
        //   270: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //   273: ifeq            345
        //   276: aload           10
        //   278: invokevirtual   java/lang/Class.isInterface:()Z
        //   281: ifne            345
        //   284: goto            291
        //   287: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   290: athrow         
        //   291: new             Ljava/lang/IllegalArgumentException;
        //   294: dup            
        //   295: new             Ljava/lang/StringBuilder;
        //   298: dup            
        //   299: invokespecial   java/lang/StringBuilder.<init>:()V
        //   302: sipush          30814
        //   305: sipush          29441
        //   308: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   311: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   314: aload           8
        //   316: invokevirtual   java/lang/reflect/Field.getName:()Ljava/lang/String;
        //   319: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   322: sipush          30797
        //   325: sipush          16064
        //   328: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   331: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   334: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   337: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //   340: athrow         
        //   341: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   344: athrow         
        //   345: aload           10
        //   347: invokevirtual   java/lang/Class.isArray:()Z
        //   350: ifeq            394
        //   353: ldc             Lcom/sun/jna/Structure;.class
        //   355: aload           10
        //   357: invokevirtual   java/lang/Class.getComponentType:()Ljava/lang/Class;
        //   360: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   363: ifeq            394
        //   366: goto            373
        //   369: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   372: athrow         
        //   373: sipush          30790
        //   376: sipush          -2833
        //   379: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   382: astore          12
        //   384: new             Ljava/lang/IllegalArgumentException;
        //   387: dup            
        //   388: aload           12
        //   390: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //   393: athrow         
        //   394: iconst_1       
        //   395: istore          12
        //   397: aload           8
        //   399: invokevirtual   java/lang/reflect/Field.getModifiers:()I
        //   402: invokestatic    java/lang/reflect/Modifier.isPublic:(I)Z
        //   405: ifne            415
        //   408: goto            1144
        //   411: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   414: athrow         
        //   415: aload_0        
        //   416: aload           11
        //   418: getfield        com/sun/jna/Structure$StructField.field:Ljava/lang/reflect/Field;
        //   421: invokevirtual   com/sun/jna/Structure.getFieldValue:(Ljava/lang/reflect/Field;)Ljava/lang/Object;
        //   424: astore          13
        //   426: aload           13
        //   428: ifnonnull       480
        //   431: aload           10
        //   433: invokevirtual   java/lang/Class.isArray:()Z
        //   436: ifeq            480
        //   439: goto            446
        //   442: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   445: athrow         
        //   446: iload_1        
        //   447: ifeq            478
        //   450: goto            457
        //   453: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   456: athrow         
        //   457: new             Ljava/lang/IllegalStateException;
        //   460: dup            
        //   461: sipush          30820
        //   464: sipush          12673
        //   467: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   470: invokespecial   java/lang/IllegalStateException.<init>:(Ljava/lang/String;)V
        //   473: athrow         
        //   474: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   477: athrow         
        //   478: aconst_null    
        //   479: areturn        
        //   480: aload           10
        //   482: astore          14
        //   484: ldc             Lcom/sun/jna/NativeMapped;.class
        //   486: aload           10
        //   488: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //   491: ifeq            540
        //   494: aload           10
        //   496: invokestatic    com/sun/jna/NativeMappedConverter.getInstance:(Ljava/lang/Class;)Lcom/sun/jna/NativeMappedConverter;
        //   499: astore          15
        //   501: aload           15
        //   503: invokevirtual   com/sun/jna/NativeMappedConverter.nativeType:()Ljava/lang/Class;
        //   506: astore          14
        //   508: aload           11
        //   510: aload           15
        //   512: putfield        com/sun/jna/Structure$StructField.writeConverter:Lcom/sun/jna/ToNativeConverter;
        //   515: aload           11
        //   517: aload           15
        //   519: putfield        com/sun/jna/Structure$StructField.readConverter:Lcom/sun/jna/FromNativeConverter;
        //   522: aload           11
        //   524: new             Lcom/sun/jna/StructureReadContext;
        //   527: dup            
        //   528: aload_0        
        //   529: aload           8
        //   531: invokespecial   com/sun/jna/StructureReadContext.<init>:(Lcom/sun/jna/Structure;Ljava/lang/reflect/Field;)V
        //   534: putfield        com/sun/jna/Structure$StructField.context:Lcom/sun/jna/FromNativeContext;
        //   537: goto            723
        //   540: aload_0        
        //   541: getfield        com/sun/jna/Structure.typeMapper:Lcom/sun/jna/TypeMapper;
        //   544: ifnull          723
        //   547: aload_0        
        //   548: getfield        com/sun/jna/Structure.typeMapper:Lcom/sun/jna/TypeMapper;
        //   551: aload           10
        //   553: invokeinterface com/sun/jna/TypeMapper.getToNativeConverter:(Ljava/lang/Class;)Lcom/sun/jna/ToNativeConverter;
        //   558: astore          15
        //   560: aload_0        
        //   561: getfield        com/sun/jna/Structure.typeMapper:Lcom/sun/jna/TypeMapper;
        //   564: aload           10
        //   566: invokeinterface com/sun/jna/TypeMapper.getFromNativeConverter:(Ljava/lang/Class;)Lcom/sun/jna/FromNativeConverter;
        //   571: astore          16
        //   573: aload           15
        //   575: ifnull          667
        //   578: aload           16
        //   580: ifnull          667
        //   583: goto            590
        //   586: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   589: athrow         
        //   590: aload           15
        //   592: aload           13
        //   594: new             Lcom/sun/jna/StructureWriteContext;
        //   597: dup            
        //   598: aload_0        
        //   599: aload           11
        //   601: getfield        com/sun/jna/Structure$StructField.field:Ljava/lang/reflect/Field;
        //   604: invokespecial   com/sun/jna/StructureWriteContext.<init>:(Lcom/sun/jna/Structure;Ljava/lang/reflect/Field;)V
        //   607: invokeinterface com/sun/jna/ToNativeConverter.toNative:(Ljava/lang/Object;Lcom/sun/jna/ToNativeContext;)Ljava/lang/Object;
        //   612: astore          13
        //   614: aload           13
        //   616: ifnull          631
        //   619: aload           13
        //   621: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //   624: goto            633
        //   627: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   630: athrow         
        //   631: ldc             Lcom/sun/jna/Pointer;.class
        //   633: astore          14
        //   635: aload           11
        //   637: aload           15
        //   639: putfield        com/sun/jna/Structure$StructField.writeConverter:Lcom/sun/jna/ToNativeConverter;
        //   642: aload           11
        //   644: aload           16
        //   646: putfield        com/sun/jna/Structure$StructField.readConverter:Lcom/sun/jna/FromNativeConverter;
        //   649: aload           11
        //   651: new             Lcom/sun/jna/StructureReadContext;
        //   654: dup            
        //   655: aload_0        
        //   656: aload           8
        //   658: invokespecial   com/sun/jna/StructureReadContext.<init>:(Lcom/sun/jna/Structure;Ljava/lang/reflect/Field;)V
        //   661: putfield        com/sun/jna/Structure$StructField.context:Lcom/sun/jna/FromNativeContext;
        //   664: goto            723
        //   667: aload           15
        //   669: ifnonnull       684
        //   672: aload           16
        //   674: ifnull          723
        //   677: goto            684
        //   680: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   683: athrow         
        //   684: new             Ljava/lang/StringBuilder;
        //   687: dup            
        //   688: invokespecial   java/lang/StringBuilder.<init>:()V
        //   691: sipush          30811
        //   694: sipush          -8463
        //   697: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   700: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   703: aload           10
        //   705: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   708: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   711: astore          17
        //   713: new             Ljava/lang/IllegalArgumentException;
        //   716: dup            
        //   717: aload           17
        //   719: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //   722: athrow         
        //   723: aload           13
        //   725: ifnonnull       741
        //   728: aload_0        
        //   729: aload           11
        //   731: getfield        com/sun/jna/Structure$StructField.field:Ljava/lang/reflect/Field;
        //   734: aload           10
        //   736: invokespecial   com/sun/jna/Structure.initializeField:(Ljava/lang/reflect/Field;Ljava/lang/Class;)Ljava/lang/Object;
        //   739: astore          13
        //   741: aload           11
        //   743: aload_0        
        //   744: aload           14
        //   746: aload           13
        //   748: invokevirtual   com/sun/jna/Structure.getNativeSize:(Ljava/lang/Class;Ljava/lang/Object;)I
        //   751: putfield        com/sun/jna/Structure$StructField.size:I
        //   754: aload_0        
        //   755: aload           14
        //   757: aload           13
        //   759: iload           6
        //   761: invokevirtual   com/sun/jna/Structure.getNativeAlignment:(Ljava/lang/Class;Ljava/lang/Object;Z)I
        //   764: istore          12
        //   766: goto            898
        //   769: astore          15
        //   771: iload_1        
        //   772: ifne            795
        //   775: aload_0        
        //   776: getfield        com/sun/jna/Structure.typeMapper:Lcom/sun/jna/TypeMapper;
        //   779: ifnonnull       795
        //   782: goto            789
        //   785: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   788: athrow         
        //   789: aconst_null    
        //   790: areturn        
        //   791: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   794: athrow         
        //   795: new             Ljava/lang/StringBuilder;
        //   798: dup            
        //   799: invokespecial   java/lang/StringBuilder.<init>:()V
        //   802: sipush          30822
        //   805: sipush          -10460
        //   808: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   811: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   814: aload_0        
        //   815: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //   818: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   821: sipush          30844
        //   824: sipush          -24842
        //   827: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   830: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   833: aload           11
        //   835: getfield        com/sun/jna/Structure$StructField.name:Ljava/lang/String;
        //   838: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   841: sipush          30835
        //   844: sipush          -30486
        //   847: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   850: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   853: aload           11
        //   855: getfield        com/sun/jna/Structure$StructField.type:Ljava/lang/Class;
        //   858: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   861: sipush          30787
        //   864: sipush          11888
        //   867: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   870: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   873: aload           15
        //   875: invokevirtual   java/lang/IllegalArgumentException.getMessage:()Ljava/lang/String;
        //   878: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   881: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   884: astore          16
        //   886: new             Ljava/lang/IllegalArgumentException;
        //   889: dup            
        //   890: aload           16
        //   892: aload           15
        //   894: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;Ljava/lang/Throwable;)V
        //   897: athrow         
        //   898: iload           12
        //   900: ifne            964
        //   903: new             Ljava/lang/Error;
        //   906: dup            
        //   907: new             Ljava/lang/StringBuilder;
        //   910: dup            
        //   911: invokespecial   java/lang/StringBuilder.<init>:()V
        //   914: sipush          30816
        //   917: sipush          -316
        //   920: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   923: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   926: aload           11
        //   928: getfield        com/sun/jna/Structure$StructField.name:Ljava/lang/String;
        //   931: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   934: sipush          30784
        //   937: sipush          26845
        //   940: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   943: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   946: aload_0        
        //   947: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //   950: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   953: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   956: invokespecial   java/lang/Error.<init>:(Ljava/lang/String;)V
        //   959: athrow         
        //   960: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   963: athrow         
        //   964: aload           5
        //   966: aload           5
        //   968: invokestatic    com/sun/jna/Structure$LayoutInfo.access$400:(Lcom/sun/jna/Structure$LayoutInfo;)I
        //   971: iload           12
        //   973: invokestatic    java/lang/Math.max:(II)I
        //   976: invokestatic    com/sun/jna/Structure$LayoutInfo.access$402:(Lcom/sun/jna/Structure$LayoutInfo;I)I
        //   979: pop            
        //   980: iload_3        
        //   981: iload           12
        //   983: irem           
        //   984: ifeq            997
        //   987: iload_3        
        //   988: iload           12
        //   990: iload_3        
        //   991: iload           12
        //   993: irem           
        //   994: isub           
        //   995: iadd           
        //   996: istore_3       
        //   997: aload_0        
        //   998: instanceof      Lcom/sun/jna/Union;
        //  1001: ifeq            1023
        //  1004: aload           11
        //  1006: iconst_0       
        //  1007: putfield        com/sun/jna/Structure$StructField.offset:I
        //  1010: iload_3        
        //  1011: aload           11
        //  1013: getfield        com/sun/jna/Structure$StructField.size:I
        //  1016: invokestatic    java/lang/Math.max:(II)I
        //  1019: istore_3       
        //  1020: goto            1037
        //  1023: aload           11
        //  1025: iload_3        
        //  1026: putfield        com/sun/jna/Structure$StructField.offset:I
        //  1029: iload_3        
        //  1030: aload           11
        //  1032: getfield        com/sun/jna/Structure$StructField.size:I
        //  1035: iadd           
        //  1036: istore_3       
        //  1037: aload           5
        //  1039: invokestatic    com/sun/jna/Structure$LayoutInfo.access$500:(Lcom/sun/jna/Structure$LayoutInfo;)Ljava/util/Map;
        //  1042: aload           11
        //  1044: getfield        com/sun/jna/Structure$StructField.name:Ljava/lang/String;
        //  1047: aload           11
        //  1049: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //  1054: pop            
        //  1055: aload           5
        //  1057: invokestatic    com/sun/jna/Structure$LayoutInfo.access$700:(Lcom/sun/jna/Structure$LayoutInfo;)Lcom/sun/jna/Structure$StructField;
        //  1060: ifnull          1129
        //  1063: aload           5
        //  1065: invokestatic    com/sun/jna/Structure$LayoutInfo.access$700:(Lcom/sun/jna/Structure$LayoutInfo;)Lcom/sun/jna/Structure$StructField;
        //  1068: getfield        com/sun/jna/Structure$StructField.size:I
        //  1071: aload           11
        //  1073: getfield        com/sun/jna/Structure$StructField.size:I
        //  1076: if_icmplt       1129
        //  1079: goto            1086
        //  1082: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1085: athrow         
        //  1086: aload           5
        //  1088: invokestatic    com/sun/jna/Structure$LayoutInfo.access$700:(Lcom/sun/jna/Structure$LayoutInfo;)Lcom/sun/jna/Structure$StructField;
        //  1091: getfield        com/sun/jna/Structure$StructField.size:I
        //  1094: aload           11
        //  1096: getfield        com/sun/jna/Structure$StructField.size:I
        //  1099: if_icmpne       1144
        //  1102: goto            1109
        //  1105: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1108: athrow         
        //  1109: ldc             Lcom/sun/jna/Structure;.class
        //  1111: aload           11
        //  1113: getfield        com/sun/jna/Structure$StructField.type:Ljava/lang/Class;
        //  1116: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //  1119: ifeq            1144
        //  1122: goto            1129
        //  1125: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1128: athrow         
        //  1129: aload           5
        //  1131: aload           11
        //  1133: invokestatic    com/sun/jna/Structure$LayoutInfo.access$702:(Lcom/sun/jna/Structure$LayoutInfo;Lcom/sun/jna/Structure$StructField;)Lcom/sun/jna/Structure$StructField;
        //  1136: pop            
        //  1137: goto            1144
        //  1140: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1143: athrow         
        //  1144: iconst_0       
        //  1145: istore          6
        //  1147: goto            62
        //  1150: iload_3        
        //  1151: ifle            1207
        //  1154: aload_0        
        //  1155: iload_3        
        //  1156: aload           5
        //  1158: invokestatic    com/sun/jna/Structure$LayoutInfo.access$400:(Lcom/sun/jna/Structure$LayoutInfo;)I
        //  1161: invokespecial   com/sun/jna/Structure.addPadding:(II)I
        //  1164: istore          7
        //  1166: aload_0        
        //  1167: instanceof      Lcom/sun/jna/Structure$ByValue;
        //  1170: ifeq            1196
        //  1173: iload_2        
        //  1174: ifne            1196
        //  1177: goto            1184
        //  1180: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1183: athrow         
        //  1184: aload_0        
        //  1185: invokevirtual   com/sun/jna/Structure.getTypeInfo:()Lcom/sun/jna/Pointer;
        //  1188: pop            
        //  1189: goto            1196
        //  1192: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1195: athrow         
        //  1196: aload           5
        //  1198: iload           7
        //  1200: invokestatic    com/sun/jna/Structure$LayoutInfo.access$102:(Lcom/sun/jna/Structure$LayoutInfo;I)I
        //  1203: pop            
        //  1204: aload           5
        //  1206: areturn        
        //  1207: new             Ljava/lang/IllegalArgumentException;
        //  1210: dup            
        //  1211: new             Ljava/lang/StringBuilder;
        //  1214: dup            
        //  1215: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1218: sipush          30839
        //  1221: sipush          7438
        //  1224: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //  1227: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1230: aload_0        
        //  1231: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //  1234: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //  1237: sipush          30819
        //  1240: sipush          -18895
        //  1243: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //  1246: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1249: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1252: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //  1255: athrow         
        //    StackMapTable: 00 3E FF 00 10 00 05 07 00 01 01 01 01 07 00 B1 00 01 07 00 4F 03 FE 00 29 07 00 C6 01 07 01 9B FF 00 35 00 0B 07 00 01 01 01 01 07 00 B1 07 00 C6 01 07 01 9B 07 00 A5 01 07 01 27 00 01 07 00 4F 03 FF 00 2D 00 0C 07 00 01 01 01 01 07 00 B1 07 00 C6 01 07 01 9B 07 00 A5 01 07 01 27 07 00 6C 00 01 07 00 4F 03 7D 07 00 4F 03 05 6C 07 00 4F 03 71 07 00 4F 03 57 07 00 4F 03 14 FF 00 10 00 0D 07 00 01 01 01 01 07 00 B1 07 00 C6 01 07 01 9B 07 00 A5 01 07 01 27 07 00 6C 01 00 01 07 00 4F 03 FF 00 1A 00 0E 07 00 01 01 01 01 07 00 B1 07 00 C6 01 07 01 9B 07 00 A5 01 07 01 27 07 00 6C 01 07 01 29 00 01 07 00 4F 03 46 07 00 4F 03 50 07 00 4F 03 01 FC 00 3B 07 01 27 FF 00 2D 00 11 07 00 01 01 01 01 07 00 B1 07 00 C6 01 07 01 9B 07 00 A5 01 07 01 27 07 00 6C 01 07 01 29 07 01 27 07 01 B6 07 01 B0 00 01 07 00 4F 03 64 07 00 4F 03 41 07 01 27 21 4C 07 00 4F 03 F9 00 26 11 5B 07 00 4F FF 00 0F 00 10 07 00 01 01 01 01 07 00 B1 07 00 C6 01 07 01 9B 07 00 A5 01 07 01 27 07 00 6C 01 07 01 29 07 01 27 07 00 4F 00 01 07 00 4F 03 41 07 00 4F 03 FA 00 66 7D 07 00 4F 03 20 19 0D 6C 07 00 4F 03 52 07 00 4F 03 4F 07 00 4F 03 4A 07 00 4F F9 00 03 FF 00 05 00 08 07 00 01 01 01 01 07 00 B1 07 00 C6 01 07 01 9B 00 00 FF 00 1D 00 08 07 00 01 01 01 01 07 00 B1 07 00 C6 01 01 00 01 07 00 4F 03 47 07 00 4F 03 FF 00 0A 00 08 07 00 01 01 01 01 07 00 B1 07 00 C6 01 07 01 9B 00 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  667    677    680    684    Ljava/lang/IllegalArgumentException;
        //  614    627    627    631    Ljava/lang/IllegalArgumentException;
        //  573    583    586    590    Ljava/lang/IllegalArgumentException;
        //  446    474    474    478    Ljava/lang/IllegalArgumentException;
        //  431    450    453    457    Ljava/lang/IllegalArgumentException;
        //  426    439    442    446    Ljava/lang/IllegalArgumentException;
        //  397    411    411    415    Ljava/lang/IllegalArgumentException;
        //  345    366    369    373    Ljava/lang/IllegalArgumentException;
        //  276    341    341    345    Ljava/lang/IllegalArgumentException;
        //  242    284    287    291    Ljava/lang/IllegalArgumentException;
        //  157    232    232    236    Ljava/lang/IllegalArgumentException;
        //  129    163    166    170    Ljava/lang/IllegalArgumentException;
        //  98     113    116    120    Ljava/lang/IllegalArgumentException;
        //  9      16     16     20     Ljava/lang/IllegalArgumentException;
        //  741    766    769    898    Ljava/lang/IllegalArgumentException;
        //  771    782    785    789    Ljava/lang/IllegalArgumentException;
        //  775    791    791    795    Ljava/lang/IllegalArgumentException;
        //  898    960    960    964    Ljava/lang/IllegalArgumentException;
        //  1037   1079   1082   1086   Ljava/lang/IllegalArgumentException;
        //  1063   1102   1105   1109   Ljava/lang/IllegalArgumentException;
        //  1086   1122   1125   1129   Ljava/lang/IllegalArgumentException;
        //  1109   1137   1140   1144   Ljava/lang/IllegalArgumentException;
        //  1166   1177   1180   1184   Ljava/lang/IllegalArgumentException;
        //  1173   1189   1192   1196   Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0446:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void initializeFields() {
        for (final Field field : this.getFieldList()) {
            try {
                final Object value = field.get(this);
                try {
                    if (value != null) {
                        continue;
                    }
                    this.initializeField(field, field.getType());
                }
                catch (Exception ex) {
                    throw b(ex);
                }
            }
            catch (Exception cause) {
                throw new Error(a(30840, 19597) + field.getName() + a(30845, -29987) + this.getClass(), cause);
            }
        }
    }
    
    private Object initializeField(final Field field, final Class<?> clazz) {
        Object o = null;
        Label_0069: {
            try {
                if (!Structure.class.isAssignableFrom(clazz) || Structure$ByReference.class.isAssignableFrom(clazz)) {
                    break Label_0069;
                }
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            try {
                o = newInstance(clazz, Structure.PLACEHOLDER_MEMORY);
                this.setFieldValue(field, o);
                return o;
            }
            catch (IllegalArgumentException cause) {
                throw new IllegalArgumentException(a(30830, -28773), cause);
            }
        }
        if (NativeMapped.class.isAssignableFrom(clazz)) {
            o = NativeMappedConverter.getInstance(clazz).defaultValue();
            this.setFieldValue(field, o);
        }
        return o;
    }
    
    private int addPadding(final int n) {
        return this.addPadding(n, this.structAlignment);
    }
    
    private int addPadding(int n, final int n2) {
        try {
            if (this.actualAlignType == 1 || n % n2 == 0) {
                return n;
            }
        }
        catch (IndexOutOfBoundsException ex) {
            throw b(ex);
        }
        n += n2 - n % n2;
        return n;
    }
    
    protected int getStructAlignment() {
        try {
            if (this.size == -1) {
                this.calculateSize(true);
            }
        }
        catch (IndexOutOfBoundsException ex) {
            throw b(ex);
        }
        return this.structAlignment;
    }
    
    protected int getNativeAlignment(final Class<?> p0, final Object p1, final boolean p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: istore          4
        //     3: ldc             Lcom/sun/jna/NativeMapped;.class
        //     5: aload_1        
        //     6: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //     9: ifeq            38
        //    12: aload_1        
        //    13: invokestatic    com/sun/jna/NativeMappedConverter.getInstance:(Ljava/lang/Class;)Lcom/sun/jna/NativeMappedConverter;
        //    16: astore          5
        //    18: aload           5
        //    20: invokevirtual   com/sun/jna/NativeMappedConverter.nativeType:()Ljava/lang/Class;
        //    23: astore_1       
        //    24: aload           5
        //    26: aload_2        
        //    27: new             Lcom/sun/jna/ToNativeContext;
        //    30: dup            
        //    31: invokespecial   com/sun/jna/ToNativeContext.<init>:()V
        //    34: invokevirtual   com/sun/jna/NativeMappedConverter.toNative:(Ljava/lang/Object;Lcom/sun/jna/ToNativeContext;)Ljava/lang/Object;
        //    37: astore_2       
        //    38: aload_1        
        //    39: aload_2        
        //    40: invokestatic    com/sun/jna/Native.getNativeSize:(Ljava/lang/Class;Ljava/lang/Object;)I
        //    43: istore          5
        //    45: aload_1        
        //    46: invokevirtual   java/lang/Class.isPrimitive:()Z
        //    49: ifne            156
        //    52: ldc             Ljava/lang/Long;.class
        //    54: aload_1        
        //    55: if_acmpeq       156
        //    58: goto            65
        //    61: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    64: athrow         
        //    65: ldc             Ljava/lang/Integer;.class
        //    67: aload_1        
        //    68: if_acmpeq       156
        //    71: goto            78
        //    74: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    77: athrow         
        //    78: ldc             Ljava/lang/Short;.class
        //    80: aload_1        
        //    81: if_acmpeq       156
        //    84: goto            91
        //    87: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    90: athrow         
        //    91: ldc             Ljava/lang/Character;.class
        //    93: aload_1        
        //    94: if_acmpeq       156
        //    97: goto            104
        //   100: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   103: athrow         
        //   104: ldc             Ljava/lang/Byte;.class
        //   106: aload_1        
        //   107: if_acmpeq       156
        //   110: goto            117
        //   113: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   116: athrow         
        //   117: ldc             Ljava/lang/Boolean;.class
        //   119: aload_1        
        //   120: if_acmpeq       156
        //   123: goto            130
        //   126: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   129: athrow         
        //   130: ldc             Ljava/lang/Float;.class
        //   132: aload_1        
        //   133: if_acmpeq       156
        //   136: goto            143
        //   139: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   142: athrow         
        //   143: ldc             Ljava/lang/Double;.class
        //   145: aload_1        
        //   146: if_acmpne       163
        //   149: goto            156
        //   152: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   155: athrow         
        //   156: iload           5
        //   158: istore          4
        //   160: goto            392
        //   163: ldc             Lcom/sun/jna/Pointer;.class
        //   165: aload_1        
        //   166: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //   169: ifeq            188
        //   172: ldc             Lcom/sun/jna/Function;.class
        //   174: aload_1        
        //   175: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //   178: ifeq            259
        //   181: goto            188
        //   184: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   187: athrow         
        //   188: getstatic       com/sun/jna/Platform.HAS_BUFFERS:Z
        //   191: ifeq            217
        //   194: goto            201
        //   197: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   200: athrow         
        //   201: ldc             Ljava/nio/Buffer;.class
        //   203: aload_1        
        //   204: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //   207: ifne            259
        //   210: goto            217
        //   213: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   216: athrow         
        //   217: ldc             Lcom/sun/jna/Callback;.class
        //   219: aload_1        
        //   220: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //   223: ifne            259
        //   226: goto            233
        //   229: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   232: athrow         
        //   233: ldc             Lcom/sun/jna/WString;.class
        //   235: aload_1        
        //   236: if_acmpeq       259
        //   239: goto            246
        //   242: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   245: athrow         
        //   246: ldc             Ljava/lang/String;.class
        //   248: aload_1        
        //   249: if_acmpne       267
        //   252: goto            259
        //   255: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   258: athrow         
        //   259: getstatic       com/sun/jna/Pointer.SIZE:I
        //   262: istore          4
        //   264: goto            392
        //   267: ldc             Lcom/sun/jna/Structure;.class
        //   269: aload_1        
        //   270: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //   273: ifeq            324
        //   276: ldc             Lcom/sun/jna/Structure$ByReference;.class
        //   278: aload_1        
        //   279: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //   282: ifeq            300
        //   285: goto            292
        //   288: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   291: athrow         
        //   292: getstatic       com/sun/jna/Pointer.SIZE:I
        //   295: istore          4
        //   297: goto            392
        //   300: aload_2        
        //   301: ifnonnull       312
        //   304: aload_1        
        //   305: getstatic       com/sun/jna/Structure.PLACEHOLDER_MEMORY:Lcom/sun/jna/Pointer;
        //   308: invokestatic    com/sun/jna/Structure.newInstance:(Ljava/lang/Class;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Structure;
        //   311: astore_2       
        //   312: aload_2        
        //   313: checkcast       Lcom/sun/jna/Structure;
        //   316: invokevirtual   com/sun/jna/Structure.getStructAlignment:()I
        //   319: istore          4
        //   321: goto            392
        //   324: aload_1        
        //   325: invokevirtual   java/lang/Class.isArray:()Z
        //   328: ifeq            346
        //   331: aload_0        
        //   332: aload_1        
        //   333: invokevirtual   java/lang/Class.getComponentType:()Ljava/lang/Class;
        //   336: aconst_null    
        //   337: iload_3        
        //   338: invokevirtual   com/sun/jna/Structure.getNativeAlignment:(Ljava/lang/Class;Ljava/lang/Object;Z)I
        //   341: istore          4
        //   343: goto            392
        //   346: new             Ljava/lang/IllegalArgumentException;
        //   349: dup            
        //   350: new             Ljava/lang/StringBuilder;
        //   353: dup            
        //   354: invokespecial   java/lang/StringBuilder.<init>:()V
        //   357: sipush          30796
        //   360: sipush          21184
        //   363: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   366: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   369: aload_1        
        //   370: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   373: sipush          30795
        //   376: sipush          11633
        //   379: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   382: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   385: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   388: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //   391: athrow         
        //   392: aload_0        
        //   393: getfield        com/sun/jna/Structure.actualAlignType:I
        //   396: iconst_1       
        //   397: if_icmpne       406
        //   400: iconst_1       
        //   401: istore          4
        //   403: goto            528
        //   406: aload_0        
        //   407: getfield        com/sun/jna/Structure.actualAlignType:I
        //   410: iconst_3       
        //   411: if_icmpne       426
        //   414: bipush          8
        //   416: iload           4
        //   418: invokestatic    java/lang/Math.min:(II)I
        //   421: istore          4
        //   423: goto            528
        //   426: aload_0        
        //   427: getfield        com/sun/jna/Structure.actualAlignType:I
        //   430: iconst_2       
        //   431: if_icmpne       528
        //   434: iload_3        
        //   435: ifeq            471
        //   438: goto            445
        //   441: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   444: athrow         
        //   445: invokestatic    com/sun/jna/Platform.isMac:()Z
        //   448: ifeq            471
        //   451: goto            458
        //   454: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   457: athrow         
        //   458: invokestatic    com/sun/jna/Platform.isPPC:()Z
        //   461: ifne            481
        //   464: goto            471
        //   467: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   470: athrow         
        //   471: getstatic       com/sun/jna/Native.MAX_ALIGNMENT:I
        //   474: iload           4
        //   476: invokestatic    java/lang/Math.min:(II)I
        //   479: istore          4
        //   481: iload_3        
        //   482: ifne            528
        //   485: invokestatic    com/sun/jna/Platform.isAIX:()Z
        //   488: ifeq            528
        //   491: goto            498
        //   494: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   497: athrow         
        //   498: aload_1        
        //   499: getstatic       java/lang/Double.TYPE:Ljava/lang/Class;
        //   502: if_acmpeq       525
        //   505: goto            512
        //   508: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   511: athrow         
        //   512: aload_1        
        //   513: ldc             Ljava/lang/Double;.class
        //   515: if_acmpne       528
        //   518: goto            525
        //   521: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   524: athrow         
        //   525: iconst_4       
        //   526: istore          4
        //   528: iload           4
        //   530: ireturn        
        //    Signature:
        //  (Ljava/lang/Class<*>;Ljava/lang/Object;Z)I
        //    StackMapTable: 00 36 FC 00 26 01 FF 00 16 00 06 07 00 01 07 01 27 07 01 29 01 01 01 00 01 07 00 4E 03 48 07 00 4E 03 48 07 00 4E 03 48 07 00 4E 03 48 07 00 4E 03 48 07 00 4E 03 48 07 00 4E 03 48 07 00 4E 03 06 54 07 00 4E 03 48 07 00 4E 03 4B 07 00 4E 03 4B 07 00 4E 03 48 07 00 4E 03 48 07 00 4E 03 07 54 07 00 4E 03 07 0B 0B 15 2D 0D 13 4E 07 00 4E 03 48 07 00 4E 03 48 07 00 4E 03 09 4C 07 00 4E 03 49 07 00 4E 03 48 07 00 4E 03 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                 
        //  -----  -----  -----  -----  -------------------------------------
        //  45     58     61     65     Ljava/lang/IndexOutOfBoundsException;
        //  52     71     74     78     Ljava/lang/IndexOutOfBoundsException;
        //  65     84     87     91     Ljava/lang/IndexOutOfBoundsException;
        //  78     97     100    104    Ljava/lang/IndexOutOfBoundsException;
        //  91     110    113    117    Ljava/lang/IndexOutOfBoundsException;
        //  104    123    126    130    Ljava/lang/IndexOutOfBoundsException;
        //  117    136    139    143    Ljava/lang/IndexOutOfBoundsException;
        //  130    149    152    156    Ljava/lang/IndexOutOfBoundsException;
        //  163    181    184    188    Ljava/lang/IndexOutOfBoundsException;
        //  172    194    197    201    Ljava/lang/IndexOutOfBoundsException;
        //  188    210    213    217    Ljava/lang/IndexOutOfBoundsException;
        //  201    226    229    233    Ljava/lang/IndexOutOfBoundsException;
        //  217    239    242    246    Ljava/lang/IndexOutOfBoundsException;
        //  233    252    255    259    Ljava/lang/IndexOutOfBoundsException;
        //  267    285    288    292    Ljava/lang/IndexOutOfBoundsException;
        //  426    438    441    445    Ljava/lang/IndexOutOfBoundsException;
        //  434    451    454    458    Ljava/lang/IndexOutOfBoundsException;
        //  445    464    467    471    Ljava/lang/IndexOutOfBoundsException;
        //  481    491    494    498    Ljava/lang/IndexOutOfBoundsException;
        //  485    505    508    512    Ljava/lang/IndexOutOfBoundsException;
        //  498    518    521    525    Ljava/lang/IndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0065:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public String toString() {
        return this.toString(Boolean.getBoolean(a(30847, -31513)));
    }
    
    public String toString(final boolean b) {
        return this.toString(0, true, b);
    }
    
    private String format(final Class<?> clazz) {
        final String name = clazz.getName();
        return name.substring(name.lastIndexOf(".") + 1);
    }
    
    private String toString(final int p0, final boolean p1, final boolean p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokevirtual   com/sun/jna/Structure.ensureAllocated:()V
        //     4: invokestatic    com/sun/jna/PointerType.b:()[I
        //     7: sipush          30799
        //    10: sipush          11600
        //    13: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //    16: invokestatic    java/lang/System.getProperty:(Ljava/lang/String;)Ljava/lang/String;
        //    19: astore          5
        //    21: astore          4
        //    23: new             Ljava/lang/StringBuilder;
        //    26: dup            
        //    27: invokespecial   java/lang/StringBuilder.<init>:()V
        //    30: aload_0        
        //    31: aload_0        
        //    32: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //    35: invokespecial   com/sun/jna/Structure.format:(Ljava/lang/Class;)Ljava/lang/String;
        //    38: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    41: ldc             "("
        //    43: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    46: aload_0        
        //    47: invokevirtual   com/sun/jna/Structure.getPointer:()Lcom/sun/jna/Pointer;
        //    50: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //    53: ldc             ")"
        //    55: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    58: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    61: astore          6
        //    63: aload_0        
        //    64: invokevirtual   com/sun/jna/Structure.getPointer:()Lcom/sun/jna/Pointer;
        //    67: instanceof      Lcom/sun/jna/Memory;
        //    70: ifne            128
        //    73: new             Ljava/lang/StringBuilder;
        //    76: dup            
        //    77: invokespecial   java/lang/StringBuilder.<init>:()V
        //    80: aload           6
        //    82: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    85: sipush          30838
        //    88: sipush          21533
        //    91: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //    94: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    97: aload_0        
        //    98: invokevirtual   com/sun/jna/Structure.size:()I
        //   101: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //   104: sipush          30794
        //   107: sipush          23505
        //   110: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   113: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   116: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   119: goto            126
        //   122: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   125: athrow         
        //   126: astore          6
        //   128: ldc             ""
        //   130: aload           4
        //   132: ifnull          126
        //   135: astore          7
        //   137: iconst_0       
        //   138: istore          8
        //   140: iload           8
        //   142: iload_1        
        //   143: if_icmpge       188
        //   146: new             Ljava/lang/StringBuilder;
        //   149: dup            
        //   150: invokespecial   java/lang/StringBuilder.<init>:()V
        //   153: aload           7
        //   155: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   158: sipush          30837
        //   161: sipush          16537
        //   164: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   167: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   170: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   173: aload           4
        //   175: ifnull          190
        //   178: astore          7
        //   180: iinc            8, 1
        //   183: aload           4
        //   185: ifnonnull       140
        //   188: aload           5
        //   190: astore          8
        //   192: aload           4
        //   194: ifnull          231
        //   197: aload           4
        //   199: ifnull          231
        //   202: goto            209
        //   205: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   208: athrow         
        //   209: iload_2        
        //   210: ifne            236
        //   213: goto            220
        //   216: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   219: athrow         
        //   220: sipush          30836
        //   223: sipush          21194
        //   226: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   229: astore          8
        //   231: aload           4
        //   233: ifnonnull       953
        //   236: aload_0        
        //   237: invokevirtual   com/sun/jna/Structure.fields:()Ljava/util/Map;
        //   240: invokeinterface java/util/Map.values:()Ljava/util/Collection;
        //   245: invokeinterface java/util/Collection.iterator:()Ljava/util/Iterator;
        //   250: astore          9
        //   252: aload           9
        //   254: invokeinterface java/util/Iterator.hasNext:()Z
        //   259: ifeq            953
        //   262: aload           9
        //   264: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   269: checkcast       Lcom/sun/jna/Structure$StructField;
        //   272: astore          10
        //   274: aload_0        
        //   275: aload           10
        //   277: getfield        com/sun/jna/Structure$StructField.field:Ljava/lang/reflect/Field;
        //   280: invokevirtual   com/sun/jna/Structure.getFieldValue:(Ljava/lang/reflect/Field;)Ljava/lang/Object;
        //   283: astore          11
        //   285: aload_0        
        //   286: aload           10
        //   288: getfield        com/sun/jna/Structure$StructField.type:Ljava/lang/Class;
        //   291: invokespecial   com/sun/jna/Structure.format:(Ljava/lang/Class;)Ljava/lang/String;
        //   294: astore          12
        //   296: ldc             ""
        //   298: astore          13
        //   300: new             Ljava/lang/StringBuilder;
        //   303: dup            
        //   304: invokespecial   java/lang/StringBuilder.<init>:()V
        //   307: aload           8
        //   309: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   312: aload           7
        //   314: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   317: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   320: astore          8
        //   322: aload           10
        //   324: getfield        com/sun/jna/Structure$StructField.type:Ljava/lang/Class;
        //   327: invokevirtual   java/lang/Class.isArray:()Z
        //   330: aload           4
        //   332: ifnull          954
        //   335: aload           4
        //   337: ifnull          494
        //   340: goto            347
        //   343: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   346: athrow         
        //   347: ifeq            411
        //   350: goto            357
        //   353: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   356: athrow         
        //   357: aload           11
        //   359: aload           4
        //   361: ifnull          491
        //   364: ifnull          411
        //   367: aload_0        
        //   368: aload           10
        //   370: getfield        com/sun/jna/Structure$StructField.type:Ljava/lang/Class;
        //   373: invokevirtual   java/lang/Class.getComponentType:()Ljava/lang/Class;
        //   376: invokespecial   com/sun/jna/Structure.format:(Ljava/lang/Class;)Ljava/lang/String;
        //   379: astore          12
        //   381: new             Ljava/lang/StringBuilder;
        //   384: dup            
        //   385: invokespecial   java/lang/StringBuilder.<init>:()V
        //   388: ldc             "["
        //   390: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   393: aload           11
        //   395: invokestatic    java/lang/reflect/Array.getLength:(Ljava/lang/Object;)I
        //   398: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //   401: ldc             "]"
        //   403: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   406: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   409: astore          13
        //   411: new             Ljava/lang/StringBuilder;
        //   414: dup            
        //   415: invokespecial   java/lang/StringBuilder.<init>:()V
        //   418: aload           8
        //   420: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   423: sipush          30837
        //   426: sipush          16537
        //   429: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //   432: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   435: aload           12
        //   437: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   440: ldc             " "
        //   442: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   445: aload           10
        //   447: getfield        com/sun/jna/Structure$StructField.name:Ljava/lang/String;
        //   450: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   453: aload           13
        //   455: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   458: ldc             "@"
        //   460: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   463: aload           10
        //   465: getfield        com/sun/jna/Structure$StructField.offset:I
        //   468: invokestatic    java/lang/Integer.toHexString:(I)Ljava/lang/String;
        //   471: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   474: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   477: astore          8
        //   479: aload           4
        //   481: ifnull          381
        //   484: aload           11
        //   486: aload           4
        //   488: ifnull          359
        //   491: instanceof      Lcom/sun/jna/Structure;
        //   494: aload           4
        //   496: ifnull          597
        //   499: ifeq            553
        //   502: goto            509
        //   505: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   508: athrow         
        //   509: aload           11
        //   511: checkcast       Lcom/sun/jna/Structure;
        //   514: iload_1        
        //   515: iconst_1       
        //   516: iadd           
        //   517: aload           11
        //   519: instanceof      Lcom/sun/jna/Structure$ByReference;
        //   522: aload           4
        //   524: ifnull          543
        //   527: aload           4
        //   529: ifnull          543
        //   532: ifne            546
        //   535: goto            542
        //   538: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   541: athrow         
        //   542: iconst_1       
        //   543: goto            547
        //   546: iconst_0       
        //   547: iload_3        
        //   548: invokespecial   com/sun/jna/Structure.toString:(IZZ)Ljava/lang/String;
        //   551: astore          11
        //   553: new             Ljava/lang/StringBuilder;
        //   556: dup            
        //   557: invokespecial   java/lang/StringBuilder.<init>:()V
        //   560: aload           8
        //   562: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   565: ldc             "="
        //   567: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   570: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   573: astore          8
        //   575: aload           4
        //   577: ifnull          643
        //   580: aload           11
        //   582: aload           4
        //   584: ifnull          511
        //   587: goto            594
        //   590: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   593: athrow         
        //   594: instanceof      Ljava/lang/Long;
        //   597: aload           4
        //   599: ifnull          660
        //   602: ifeq            648
        //   605: goto            612
        //   608: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   611: athrow         
        //   612: new             Ljava/lang/StringBuilder;
        //   615: dup            
        //   616: invokespecial   java/lang/StringBuilder.<init>:()V
        //   619: aload           8
        //   621: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   624: aload           11
        //   626: checkcast       Ljava/lang/Long;
        //   629: invokevirtual   java/lang/Long.longValue:()J
        //   632: invokestatic    java/lang/Long.toHexString:(J)Ljava/lang/String;
        //   635: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   638: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   641: astore          8
        //   643: aload           4
        //   645: ifnonnull       865
        //   648: aload           11
        //   650: instanceof      Ljava/lang/Integer;
        //   653: goto            660
        //   656: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   659: athrow         
        //   660: aload           4
        //   662: ifnull          723
        //   665: ifeq            711
        //   668: goto            675
        //   671: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   674: athrow         
        //   675: new             Ljava/lang/StringBuilder;
        //   678: dup            
        //   679: invokespecial   java/lang/StringBuilder.<init>:()V
        //   682: aload           8
        //   684: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   687: aload           11
        //   689: checkcast       Ljava/lang/Integer;
        //   692: invokevirtual   java/lang/Integer.intValue:()I
        //   695: invokestatic    java/lang/Integer.toHexString:(I)Ljava/lang/String;
        //   698: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   701: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   704: astore          8
        //   706: aload           4
        //   708: ifnonnull       865
        //   711: aload           11
        //   713: instanceof      Ljava/lang/Short;
        //   716: goto            723
        //   719: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   722: athrow         
        //   723: aload           4
        //   725: ifnull          786
        //   728: ifeq            774
        //   731: goto            738
        //   734: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   737: athrow         
        //   738: new             Ljava/lang/StringBuilder;
        //   741: dup            
        //   742: invokespecial   java/lang/StringBuilder.<init>:()V
        //   745: aload           8
        //   747: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   750: aload           11
        //   752: checkcast       Ljava/lang/Short;
        //   755: invokevirtual   java/lang/Short.shortValue:()S
        //   758: invokestatic    java/lang/Integer.toHexString:(I)Ljava/lang/String;
        //   761: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   764: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   767: astore          8
        //   769: aload           4
        //   771: ifnonnull       865
        //   774: aload           11
        //   776: instanceof      Ljava/lang/Byte;
        //   779: goto            786
        //   782: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   785: athrow         
        //   786: ifeq            832
        //   789: new             Ljava/lang/StringBuilder;
        //   792: dup            
        //   793: invokespecial   java/lang/StringBuilder.<init>:()V
        //   796: aload           8
        //   798: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   801: aload           11
        //   803: checkcast       Ljava/lang/Byte;
        //   806: invokevirtual   java/lang/Byte.byteValue:()B
        //   809: invokestatic    java/lang/Integer.toHexString:(I)Ljava/lang/String;
        //   812: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   815: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   818: goto            825
        //   821: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   824: athrow         
        //   825: astore          8
        //   827: aload           4
        //   829: ifnonnull       865
        //   832: new             Ljava/lang/StringBuilder;
        //   835: dup            
        //   836: invokespecial   java/lang/StringBuilder.<init>:()V
        //   839: aload           8
        //   841: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   844: aload           11
        //   846: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   849: invokevirtual   java/lang/String.trim:()Ljava/lang/String;
        //   852: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   855: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   858: aload           4
        //   860: ifnull          825
        //   863: astore          8
        //   865: new             Ljava/lang/StringBuilder;
        //   868: dup            
        //   869: invokespecial   java/lang/StringBuilder.<init>:()V
        //   872: aload           8
        //   874: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   877: aload           5
        //   879: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   882: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   885: aload           4
        //   887: ifnull          946
        //   890: aload           4
        //   892: ifnull          946
        //   895: goto            902
        //   898: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   901: athrow         
        //   902: astore          8
        //   904: aload           9
        //   906: invokeinterface java/util/Iterator.hasNext:()Z
        //   911: ifne            948
        //   914: new             Ljava/lang/StringBuilder;
        //   917: dup            
        //   918: invokespecial   java/lang/StringBuilder.<init>:()V
        //   921: aload           8
        //   923: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   926: aload           7
        //   928: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   931: ldc             "}"
        //   933: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   936: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   939: goto            946
        //   942: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   945: athrow         
        //   946: astore          8
        //   948: aload           4
        //   950: ifnonnull       252
        //   953: iload_1        
        //   954: aload           4
        //   956: ifnull          982
        //   959: aload           4
        //   961: ifnull          987
        //   964: goto            971
        //   967: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   970: athrow         
        //   971: ifne            1348
        //   974: goto            981
        //   977: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   980: athrow         
        //   981: iload_3        
        //   982: aload           4
        //   984: ifnull          1010
        //   987: aload           4
        //   989: ifnull          1010
        //   992: goto            999
        //   995: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   998: athrow         
        //   999: ifeq            1348
        //  1002: goto            1009
        //  1005: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1008: athrow         
        //  1009: iconst_4       
        //  1010: istore          9
        //  1012: new             Ljava/lang/StringBuilder;
        //  1015: dup            
        //  1016: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1019: aload           8
        //  1021: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1024: aload           5
        //  1026: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1029: sipush          30793
        //  1032: sipush          27846
        //  1035: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //  1038: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1041: aload           5
        //  1043: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1046: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1049: astore          8
        //  1051: aload_0        
        //  1052: invokevirtual   com/sun/jna/Structure.getPointer:()Lcom/sun/jna/Pointer;
        //  1055: lconst_0       
        //  1056: aload_0        
        //  1057: invokevirtual   com/sun/jna/Structure.size:()I
        //  1060: invokevirtual   com/sun/jna/Pointer.getByteArray:(JI)[B
        //  1063: astore          10
        //  1065: iconst_0       
        //  1066: istore          11
        //  1068: iload           11
        //  1070: aload           10
        //  1072: arraylength    
        //  1073: if_icmpge       1326
        //  1076: aload           4
        //  1078: ifnull          1348
        //  1081: iload           11
        //  1083: iconst_4       
        //  1084: irem           
        //  1085: aload           4
        //  1087: ifnull          1134
        //  1090: goto            1097
        //  1093: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1096: athrow         
        //  1097: ifne            1129
        //  1100: goto            1107
        //  1103: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1106: athrow         
        //  1107: new             Ljava/lang/StringBuilder;
        //  1110: dup            
        //  1111: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1114: aload           8
        //  1116: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1119: ldc             "["
        //  1121: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1124: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1127: astore          8
        //  1129: aload           10
        //  1131: iload           11
        //  1133: baload         
        //  1134: aload           4
        //  1136: ifnull          1253
        //  1139: iflt            1200
        //  1142: goto            1149
        //  1145: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1148: athrow         
        //  1149: aload           10
        //  1151: iload           11
        //  1153: baload         
        //  1154: bipush          16
        //  1156: goto            1163
        //  1159: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1162: athrow         
        //  1163: aload           4
        //  1165: ifnull          1264
        //  1168: if_icmpge       1200
        //  1171: new             Ljava/lang/StringBuilder;
        //  1174: dup            
        //  1175: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1178: aload           8
        //  1180: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1183: ldc             "0"
        //  1185: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1188: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1191: goto            1198
        //  1194: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1197: athrow         
        //  1198: astore          8
        //  1200: new             Ljava/lang/StringBuilder;
        //  1203: dup            
        //  1204: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1207: aload           8
        //  1209: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1212: aload           10
        //  1214: iload           11
        //  1216: baload         
        //  1217: sipush          255
        //  1220: iand           
        //  1221: invokestatic    java/lang/Integer.toHexString:(I)Ljava/lang/String;
        //  1224: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1227: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1230: aload           4
        //  1232: ifnull          1198
        //  1235: astore          8
        //  1237: aload           4
        //  1239: ifnull          1321
        //  1242: iload           11
        //  1244: iconst_4       
        //  1245: irem           
        //  1246: goto            1253
        //  1249: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1252: athrow         
        //  1253: iconst_3       
        //  1254: aload           4
        //  1256: ifnull          1163
        //  1259: aload           4
        //  1261: ifnull          1288
        //  1264: if_icmpne       1318
        //  1267: goto            1274
        //  1270: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1273: athrow         
        //  1274: iload           11
        //  1276: aload           10
        //  1278: arraylength    
        //  1279: iconst_1       
        //  1280: isub           
        //  1281: goto            1288
        //  1284: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //  1287: athrow         
        //  1288: if_icmpge       1318
        //  1291: new             Ljava/lang/StringBuilder;
        //  1294: dup            
        //  1295: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1298: aload           8
        //  1300: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1303: ldc             "]"
        //  1305: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1308: aload           5
        //  1310: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1313: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1316: astore          8
        //  1318: iinc            11, 1
        //  1321: aload           4
        //  1323: ifnonnull       1068
        //  1326: new             Ljava/lang/StringBuilder;
        //  1329: dup            
        //  1330: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1333: aload           8
        //  1335: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1338: ldc             "]"
        //  1340: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1343: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1346: astore          8
        //  1348: new             Ljava/lang/StringBuilder;
        //  1351: dup            
        //  1352: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1355: aload           6
        //  1357: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1360: sipush          30812
        //  1363: bipush          -99
        //  1365: invokestatic    com/sun/jna/Structure.a:(II)Ljava/lang/String;
        //  1368: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1371: aload           8
        //  1373: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1376: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1379: areturn        
        //    StackMapTable: 00 61 FF 00 7A 00 07 07 00 01 01 01 01 07 04 26 07 00 08 07 00 08 00 01 07 00 4E 43 07 00 08 01 FD 00 0B 07 00 08 01 2F 41 07 00 08 FF 00 0E 00 09 07 00 01 01 01 01 07 04 26 07 00 08 07 00 08 07 00 08 07 00 08 00 01 07 00 4E 03 46 07 00 4E 03 0A 04 FC 00 0F 07 01 9B FF 00 5A 00 0E 07 00 01 01 01 01 07 04 26 07 00 08 07 00 08 07 00 08 07 00 08 07 01 9B 07 00 6C 07 01 29 07 00 08 07 00 08 00 01 07 00 4E 43 01 45 07 00 4E 03 41 07 01 29 15 1D F7 00 4F 07 01 29 42 01 4A 07 00 4E 03 41 07 01 29 5A 07 00 4E FF 00 03 00 0E 07 00 01 01 01 01 07 04 26 07 00 08 07 00 08 07 00 08 07 00 08 07 01 9B 07 00 6C 07 01 29 07 00 08 07 00 08 00 02 07 00 01 01 FF 00 00 00 0E 07 00 01 01 01 01 07 04 26 07 00 08 07 00 08 07 00 08 07 00 08 07 01 9B 07 00 6C 07 01 29 07 00 08 07 00 08 00 03 07 00 01 01 01 FF 00 02 00 0E 07 00 01 01 01 01 07 04 26 07 00 08 07 00 08 07 00 08 07 00 08 07 01 9B 07 00 6C 07 01 29 07 00 08 07 00 08 00 02 07 00 01 01 FF 00 00 00 0E 07 00 01 01 01 01 07 04 26 07 00 08 07 00 08 07 00 08 07 00 08 07 01 9B 07 00 6C 07 01 29 07 00 08 07 00 08 00 03 07 00 01 01 01 05 64 07 00 4E 43 07 01 29 42 01 4A 07 00 4E 03 1E 04 47 07 00 4E 43 01 4A 07 00 4E 03 23 47 07 00 4E 43 01 4A 07 00 4E 03 23 47 07 00 4E 43 01 62 07 00 4E 43 07 00 08 06 20 60 07 00 4E 43 07 00 08 67 07 00 4E 43 07 00 08 01 FF 00 04 00 09 07 00 01 01 01 01 07 04 26 07 00 08 07 00 08 07 00 08 07 00 08 00 00 40 01 4C 07 00 4E 43 01 45 07 00 4E 03 40 01 44 01 47 07 00 4E 43 01 45 07 00 4E 03 40 01 FE 00 39 01 07 01 F6 01 58 07 00 4E 43 01 45 07 00 4E 03 15 44 01 4A 07 00 4E 03 49 07 00 4E FF 00 03 00 0C 07 00 01 01 01 01 07 04 26 07 00 08 07 00 08 07 00 08 07 00 08 01 07 01 F6 01 00 02 01 01 5E 07 00 4E 43 07 00 08 01 70 07 00 4E 43 01 FF 00 0A 00 0C 07 00 01 01 01 01 07 04 26 07 00 08 07 00 08 07 00 08 07 00 08 01 07 01 F6 01 00 02 01 01 45 07 00 4E 03 49 07 00 4E FF 00 03 00 0C 07 00 01 01 01 01 07 04 26 07 00 08 07 00 08 07 00 08 07 00 08 01 07 01 F6 01 00 02 01 01 1D 02 04 F8 00 15
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                 
        //  -----  -----  -----  -----  -------------------------------------
        //  63     119    122    126    Ljava/lang/IndexOutOfBoundsException;
        //  192    202    205    209    Ljava/lang/IndexOutOfBoundsException;
        //  197    213    216    220    Ljava/lang/IndexOutOfBoundsException;
        //  322    340    343    347    Ljava/lang/IndexOutOfBoundsException;
        //  335    350    353    357    Ljava/lang/IndexOutOfBoundsException;
        //  494    502    505    509    Ljava/lang/IndexOutOfBoundsException;
        //  527    535    538    542    Ljava/lang/IndexOutOfBoundsException;
        //  575    587    590    594    Ljava/lang/IndexOutOfBoundsException;
        //  597    605    608    612    Ljava/lang/IndexOutOfBoundsException;
        //  643    653    656    660    Ljava/lang/IndexOutOfBoundsException;
        //  660    668    671    675    Ljava/lang/IndexOutOfBoundsException;
        //  706    716    719    723    Ljava/lang/IndexOutOfBoundsException;
        //  723    731    734    738    Ljava/lang/IndexOutOfBoundsException;
        //  769    779    782    786    Ljava/lang/IndexOutOfBoundsException;
        //  786    818    821    825    Ljava/lang/IndexOutOfBoundsException;
        //  865    895    898    902    Ljava/lang/IndexOutOfBoundsException;
        //  904    939    942    946    Ljava/lang/IndexOutOfBoundsException;
        //  954    964    967    971    Ljava/lang/IndexOutOfBoundsException;
        //  959    974    977    981    Ljava/lang/IndexOutOfBoundsException;
        //  982    992    995    999    Ljava/lang/IndexOutOfBoundsException;
        //  987    1002   1005   1009   Ljava/lang/IndexOutOfBoundsException;
        //  1076   1090   1093   1097   Ljava/lang/IndexOutOfBoundsException;
        //  1081   1100   1103   1107   Ljava/lang/IndexOutOfBoundsException;
        //  1134   1142   1145   1149   Ljava/lang/IndexOutOfBoundsException;
        //  1139   1156   1159   1163   Ljava/lang/IndexOutOfBoundsException;
        //  1168   1191   1194   1198   Ljava/lang/IndexOutOfBoundsException;
        //  1237   1246   1249   1253   Ljava/lang/IndexOutOfBoundsException;
        //  1259   1267   1270   1274   Ljava/lang/IndexOutOfBoundsException;
        //  1264   1281   1284   1288   Ljava/lang/IndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0987:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public Structure[] toArray(final Structure[] array) {
        this.ensureAllocated();
        if (this.memory instanceof Structure$AutoAllocated) {
            final Memory memory = (Memory)this.memory;
            final int n = array.length * this.size();
            try {
                if (memory.size() < n) {
                    this.useMemory(this.autoAllocate(n));
                }
            }
            catch (IndexOutOfBoundsException ex) {
                throw b(ex);
            }
        }
        array[0] = this;
        final int size = this.size();
        int i = 1;
        try {
            while (i < array.length) {
                (array[i] = newInstance(this.getClass(), this.memory.share(i * size, size))).conditionalAutoRead();
                ++i;
            }
        }
        catch (IndexOutOfBoundsException ex2) {
            throw b(ex2);
        }
        try {
            if (!(this instanceof Structure$ByValue)) {
                this.array = array;
            }
        }
        catch (IndexOutOfBoundsException ex3) {
            throw b(ex3);
        }
        return array;
    }
    
    public Structure[] toArray(final int length) {
        return this.toArray((Structure[])Array.newInstance(this.getClass(), length));
    }
    
    private Class<?> baseClass() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: aload_0        
        //     5: instanceof      Lcom/sun/jna/Structure$ByReference;
        //     8: aload_1        
        //     9: ifnull          67
        //    12: ifne            47
        //    15: goto            22
        //    18: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    21: athrow         
        //    22: aload_0        
        //    23: aload_1        
        //    24: ifnull          86
        //    27: goto            34
        //    30: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    33: athrow         
        //    34: instanceof      Lcom/sun/jna/Structure$ByValue;
        //    37: goto            44
        //    40: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    43: athrow         
        //    44: ifeq            85
        //    47: ldc             Lcom/sun/jna/Structure;.class
        //    49: aload_1        
        //    50: ifnull          97
        //    53: aload_0        
        //    54: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //    57: invokevirtual   java/lang/Class.getSuperclass:()Ljava/lang/Class;
        //    60: invokevirtual   java/lang/Class.isAssignableFrom:(Ljava/lang/Class;)Z
        //    63: aload_1        
        //    64: ifnull          44
        //    67: ifeq            85
        //    70: aload_0        
        //    71: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //    74: invokevirtual   java/lang/Class.getSuperclass:()Ljava/lang/Class;
        //    77: goto            84
        //    80: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    83: athrow         
        //    84: areturn        
        //    85: aload_0        
        //    86: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //    89: aload_1        
        //    90: ifnull          49
        //    93: aload_1        
        //    94: ifnull          84
        //    97: areturn        
        //    Signature:
        //  ()Ljava/lang/Class<*>;
        //    StackMapTable: 00 0E FF 00 12 00 02 07 00 01 07 04 26 00 01 07 00 4E 03 47 07 00 4E 43 07 00 01 45 07 00 4E 43 01 02 41 07 01 27 51 01 4C 07 00 4E 43 07 01 27 00 40 07 00 01 4A 07 01 27
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                 
        //  -----  -----  -----  -----  -------------------------------------
        //  4      15     18     22     Ljava/lang/IndexOutOfBoundsException;
        //  12     27     30     34     Ljava/lang/IndexOutOfBoundsException;
        //  22     37     40     44     Ljava/lang/IndexOutOfBoundsException;
        //  67     77     80     84     Ljava/lang/IndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0022:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public boolean dataEquals(final Structure structure) {
        return this.dataEquals(structure, false);
    }
    
    public boolean dataEquals(final Structure p0, final boolean p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_3       
        //     4: aload_3        
        //     5: ifnull          54
        //     8: iload_2        
        //     9: ifeq            58
        //    12: goto            19
        //    15: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    18: athrow         
        //    19: aload_1        
        //    20: invokevirtual   com/sun/jna/Structure.getPointer:()Lcom/sun/jna/Pointer;
        //    23: aload_1        
        //    24: invokevirtual   com/sun/jna/Structure.size:()I
        //    27: i2l            
        //    28: invokevirtual   com/sun/jna/Pointer.clear:(J)V
        //    31: aload_1        
        //    32: invokevirtual   com/sun/jna/Structure.write:()V
        //    35: aload_0        
        //    36: invokevirtual   com/sun/jna/Structure.getPointer:()Lcom/sun/jna/Pointer;
        //    39: aload_0        
        //    40: invokevirtual   com/sun/jna/Structure.size:()I
        //    43: i2l            
        //    44: invokevirtual   com/sun/jna/Pointer.clear:(J)V
        //    47: goto            54
        //    50: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    53: athrow         
        //    54: aload_0        
        //    55: invokevirtual   com/sun/jna/Structure.write:()V
        //    58: aload_1        
        //    59: invokevirtual   com/sun/jna/Structure.getPointer:()Lcom/sun/jna/Pointer;
        //    62: lconst_0       
        //    63: aload_1        
        //    64: invokevirtual   com/sun/jna/Structure.size:()I
        //    67: invokevirtual   com/sun/jna/Pointer.getByteArray:(JI)[B
        //    70: astore          4
        //    72: aload_0        
        //    73: invokevirtual   com/sun/jna/Structure.getPointer:()Lcom/sun/jna/Pointer;
        //    76: lconst_0       
        //    77: aload_0        
        //    78: invokevirtual   com/sun/jna/Structure.size:()I
        //    81: invokevirtual   com/sun/jna/Pointer.getByteArray:(JI)[B
        //    84: astore          5
        //    86: aload_3        
        //    87: ifnull          54
        //    90: aload           4
        //    92: arraylength    
        //    93: aload_3        
        //    94: ifnull          197
        //    97: aload           5
        //    99: arraylength    
        //   100: if_icmpne       192
        //   103: goto            110
        //   106: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   109: athrow         
        //   110: iconst_0       
        //   111: goto            118
        //   114: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   117: athrow         
        //   118: istore          6
        //   120: iload           6
        //   122: aload           4
        //   124: arraylength    
        //   125: if_icmpge       190
        //   128: aload           4
        //   130: iload           6
        //   132: baload         
        //   133: aload_3        
        //   134: ifnull          191
        //   137: aload_3        
        //   138: ifnull          182
        //   141: goto            148
        //   144: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   147: athrow         
        //   148: aload_3        
        //   149: ifnull          182
        //   152: goto            159
        //   155: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   158: athrow         
        //   159: aload           5
        //   161: iload           6
        //   163: baload         
        //   164: if_icmpeq       183
        //   167: goto            174
        //   170: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   173: athrow         
        //   174: iconst_0       
        //   175: goto            182
        //   178: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   181: athrow         
        //   182: ireturn        
        //   183: iinc            6, 1
        //   186: aload_3        
        //   187: ifnonnull       120
        //   190: iconst_1       
        //   191: ireturn        
        //   192: iconst_0       
        //   193: aload_3        
        //   194: ifnull          118
        //   197: ireturn        
        //    StackMapTable: 00 17 FF 00 0F 00 04 07 00 01 07 00 01 01 07 04 26 00 01 07 00 4E 03 5E 07 00 4E 03 03 FF 00 2F 00 06 07 00 01 07 00 01 01 07 04 26 07 01 F6 07 01 F6 00 01 07 00 4E 03 43 07 00 4E 43 01 FC 00 01 01 57 07 00 4E 43 01 46 07 00 4E 43 01 4A 07 00 4E 03 43 07 00 4E 43 01 00 06 40 01 FA 00 00 44 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                 
        //  -----  -----  -----  -----  -------------------------------------
        //  4      12     15     19     Ljava/lang/IndexOutOfBoundsException;
        //  8      47     50     54     Ljava/lang/IndexOutOfBoundsException;
        //  90     103    106    110    Ljava/lang/IndexOutOfBoundsException;
        //  97     111    114    118    Ljava/lang/IndexOutOfBoundsException;
        //  128    141    144    148    Ljava/lang/IndexOutOfBoundsException;
        //  137    152    155    159    Ljava/lang/IndexOutOfBoundsException;
        //  148    167    170    174    Ljava/lang/IndexOutOfBoundsException;
        //  159    175    178    182    Ljava/lang/IndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0148:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public boolean equals(final Object p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_1        
        //     5: aload_2        
        //     6: ifnull          41
        //     9: aload_2        
        //    10: ifnull          41
        //    13: goto            20
        //    16: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    19: athrow         
        //    20: instanceof      Lcom/sun/jna/Structure;
        //    23: ifeq            123
        //    26: goto            33
        //    29: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    32: athrow         
        //    33: aload_1        
        //    34: goto            41
        //    37: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    40: athrow         
        //    41: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //    44: aload_2        
        //    45: ifnull          81
        //    48: aload_2        
        //    49: ifnull          81
        //    52: goto            59
        //    55: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    58: athrow         
        //    59: aload_0        
        //    60: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //    63: if_acmpne       123
        //    66: goto            73
        //    69: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    72: athrow         
        //    73: aload_1        
        //    74: goto            81
        //    77: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    80: athrow         
        //    81: checkcast       Lcom/sun/jna/Structure;
        //    84: invokevirtual   com/sun/jna/Structure.getPointer:()Lcom/sun/jna/Pointer;
        //    87: aload_0        
        //    88: invokevirtual   com/sun/jna/Structure.getPointer:()Lcom/sun/jna/Pointer;
        //    91: invokevirtual   com/sun/jna/Pointer.equals:(Ljava/lang/Object;)Z
        //    94: aload_2        
        //    95: ifnull          120
        //    98: aload_2        
        //    99: ifnull          120
        //   102: goto            109
        //   105: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   108: athrow         
        //   109: ifeq            123
        //   112: goto            119
        //   115: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   118: athrow         
        //   119: iconst_1       
        //   120: goto            124
        //   123: iconst_0       
        //   124: ireturn        
        //    StackMapTable: 00 13 FF 00 10 00 03 07 00 01 07 01 29 07 04 26 00 01 07 00 4E 43 07 01 29 48 07 00 4E 03 43 07 00 4E 43 07 01 29 4D 07 00 4E 43 07 01 27 49 07 00 4E 03 43 07 00 4E 43 07 01 29 57 07 00 4E 43 01 45 07 00 4E 03 40 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                 
        //  -----  -----  -----  -----  -------------------------------------
        //  4      13     16     20     Ljava/lang/IndexOutOfBoundsException;
        //  9      26     29     33     Ljava/lang/IndexOutOfBoundsException;
        //  20     34     37     41     Ljava/lang/IndexOutOfBoundsException;
        //  41     52     55     59     Ljava/lang/IndexOutOfBoundsException;
        //  48     66     69     73     Ljava/lang/IndexOutOfBoundsException;
        //  59     74     77     81     Ljava/lang/IndexOutOfBoundsException;
        //  81     102    105    109    Ljava/lang/IndexOutOfBoundsException;
        //  98     112    115    119    Ljava/lang/IndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public int hashCode() {
        final Pointer pointer = this.getPointer();
        final int[] b = PointerType.b();
        Label_0039: {
            Pointer pointer3 = null;
            Label_0024: {
                Pointer pointer2;
                try {
                    pointer2 = (pointer3 = pointer);
                    if (b == null) {
                        break Label_0024;
                    }
                    if (pointer2 != null) {
                        break Label_0024;
                    }
                    break Label_0039;
                }
                catch (IndexOutOfBoundsException ex) {
                    throw b(ex);
                }
                try {
                    if (pointer2 == null) {
                        break Label_0039;
                    }
                    pointer3 = this.getPointer();
                }
                catch (IndexOutOfBoundsException ex2) {
                    throw b(ex2);
                }
            }
            pointer3.hashCode();
            return;
        }
        final int hashCode = this.getClass().hashCode();
        if (b != null) {
            return hashCode;
        }
        return hashCode;
    }
    
    protected void cacheTypeInfo(final Pointer pointer) {
        this.typeInfo = pointer.peer;
    }
    
    Pointer getFieldTypeInfo(final Structure$StructField structure$StructField) {
        Class<?> clazz = structure$StructField.type;
        Object o = this.getFieldValue(structure$StructField.field);
        if (this.typeMapper != null) {
            final ToNativeConverter toNativeConverter = this.typeMapper.getToNativeConverter(clazz);
            if (toNativeConverter != null) {
                clazz = toNativeConverter.nativeType();
                o = toNativeConverter.toNative(o, new ToNativeContext());
            }
        }
        return Structure$FFIType.access$800(o, clazz);
    }
    
    Pointer getTypeInfo() {
        final Pointer typeInfo = getTypeInfo(this);
        this.cacheTypeInfo(typeInfo);
        return typeInfo;
    }
    
    public void setAutoSynch(final boolean b) {
        this.setAutoRead(b);
        this.setAutoWrite(b);
    }
    
    public void setAutoRead(final boolean autoRead) {
        this.autoRead = autoRead;
    }
    
    public boolean getAutoRead() {
        return this.autoRead;
    }
    
    public void setAutoWrite(final boolean autoWrite) {
        this.autoWrite = autoWrite;
    }
    
    public boolean getAutoWrite() {
        return this.autoWrite;
    }
    
    static Pointer getTypeInfo(final Object o) {
        return Structure$FFIType.get(o);
    }
    
    private static Structure newInstance(final Class<?> clazz, final long n) {
        final int[] b = PointerType.b();
        try {
            Pointer placeholder_MEMORY = null;
            Label_0029: {
                try {
                    if (n == 0L) {
                        placeholder_MEMORY = Structure.PLACEHOLDER_MEMORY;
                        break Label_0029;
                    }
                }
                catch (Throwable t) {
                    throw b(t);
                }
                placeholder_MEMORY = new Pointer(n);
            }
            final Structure instance = newInstance(clazz, placeholder_MEMORY);
            while (true) {
                Label_0052: {
                    try {
                        if (n == 0L) {
                            break Label_0052;
                        }
                    }
                    catch (Throwable t2) {
                        throw b(t2);
                    }
                    final Structure structure;
                    structure.conditionalAutoRead();
                }
                final Structure structure = instance;
                if (b != null) {
                    return structure;
                }
                continue;
            }
        }
        catch (Throwable obj) {
            System.err.println(a(30791, -15254) + obj);
            return null;
        }
    }
    
    public static Structure newInstance(final Class<?> obj, final Pointer pointer) throws IllegalArgumentException {
        try {
            return (Structure)obj.getConstructor(Pointer.class).newInstance(pointer);
        }
        catch (NoSuchMethodException ex2) {}
        catch (SecurityException ex3) {}
        catch (InstantiationException cause) {
            throw new IllegalArgumentException(a(30829, -23814) + obj, cause);
        }
        catch (IllegalAccessException cause2) {
            throw new IllegalArgumentException(a(30826, 26160) + obj + a(30834, -13984), cause2);
        }
        catch (InvocationTargetException cause3) {
            final String string = a(30785, 19051) + obj;
            cause3.printStackTrace();
            throw new IllegalArgumentException(string, cause3);
        }
        final Structure instance = newInstance(obj);
        try {
            if (pointer != Structure.PLACEHOLDER_MEMORY) {
                instance.useMemory(pointer);
            }
        }
        catch (NoSuchMethodException ex) {
            throw b(ex);
        }
        return instance;
    }
    
    public static Structure newInstance(final Class<?> clazz) throws IllegalArgumentException {
        try {
            final Structure structure = (Structure)clazz.newInstance();
            try {
                if (structure instanceof Structure$ByValue) {
                    structure.allocateMemory();
                }
            }
            catch (InstantiationException ex) {
                throw b(ex);
            }
            return structure;
        }
        catch (InstantiationException cause) {
            throw new IllegalArgumentException(a(30829, -23814) + clazz, cause);
        }
        catch (IllegalAccessException cause2) {
            throw new IllegalArgumentException(a(30826, 26160) + clazz + a(30813, 16250), cause2);
        }
    }
    
    Structure$StructField typeInfoField() {
        final Structure$LayoutInfo structure$LayoutInfo;
        synchronized (Structure.layoutInfo) {
            structure$LayoutInfo = Structure.layoutInfo.get(this.getClass());
        }
        try {
            if (structure$LayoutInfo != null) {
                return Structure$LayoutInfo.access$700(structure$LayoutInfo);
            }
        }
        catch (IndexOutOfBoundsException ex) {
            throw b(ex);
        }
        return null;
    }
    
    private static void structureArrayCheck(final Structure[] array) {
        final int[] b = PointerType.b();
        try {
            if (Structure$ByReference[].class.isAssignableFrom(array.getClass())) {
                return;
            }
        }
        catch (IndexOutOfBoundsException ex) {
            throw b(ex);
        }
        final Pointer pointer = array[0].getPointer();
        final int size = array[0].size();
        int i = 1;
        while (i < array.length) {
            if (array[i].getPointer().peer != pointer.peer + size * i) {
                throw new IllegalArgumentException(a(30825, 23488) + i + ")");
            }
            ++i;
            if (b == null) {
                break;
            }
        }
    }
    
    public static void autoRead(final Structure[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: invokestatic    com/sun/jna/Structure.structureArrayCheck:([Lcom/sun/jna/Structure;)V
        //     7: astore_1       
        //     8: aload_0        
        //     9: iconst_0       
        //    10: aaload         
        //    11: getfield        com/sun/jna/Structure.array:[Lcom/sun/jna/Structure;
        //    14: aload_1        
        //    15: ifnull          48
        //    18: aload_1        
        //    19: ifnull          48
        //    22: goto            29
        //    25: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    28: athrow         
        //    29: aload_0        
        //    30: if_acmpne       57
        //    33: goto            40
        //    36: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    39: athrow         
        //    40: aload_0        
        //    41: goto            48
        //    44: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    47: athrow         
        //    48: iconst_0       
        //    49: aaload         
        //    50: invokevirtual   com/sun/jna/Structure.autoRead:()V
        //    53: aload_1        
        //    54: ifnonnull       113
        //    57: iconst_0       
        //    58: istore_2       
        //    59: iload_2        
        //    60: aload_0        
        //    61: arraylength    
        //    62: if_icmpge       113
        //    65: aload_0        
        //    66: iload_2        
        //    67: aaload         
        //    68: aload_1        
        //    69: ifnull          103
        //    72: aload_1        
        //    73: ifnull          103
        //    76: goto            83
        //    79: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    82: athrow         
        //    83: ifnull          106
        //    86: goto            93
        //    89: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    92: athrow         
        //    93: aload_0        
        //    94: iload_2        
        //    95: aaload         
        //    96: goto            103
        //    99: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   102: athrow         
        //   103: invokevirtual   com/sun/jna/Structure.autoRead:()V
        //   106: iinc            2, 1
        //   109: aload_1        
        //   110: ifnonnull       59
        //   113: return         
        //    StackMapTable: 00 10 FF 00 19 00 02 07 01 15 07 04 26 00 01 07 00 4E 43 07 01 15 46 07 00 4E 03 43 07 00 4E 43 07 01 15 08 FC 00 01 01 53 07 00 4E 43 07 00 01 45 07 00 4E 03 45 07 00 4E 43 07 00 01 02 FA 00 06
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                 
        //  -----  -----  -----  -----  -------------------------------------
        //  8      22     25     29     Ljava/lang/IndexOutOfBoundsException;
        //  18     33     36     40     Ljava/lang/IndexOutOfBoundsException;
        //  29     41     44     48     Ljava/lang/IndexOutOfBoundsException;
        //  65     76     79     83     Ljava/lang/IndexOutOfBoundsException;
        //  72     86     89     93     Ljava/lang/IndexOutOfBoundsException;
        //  83     96     99     103    Ljava/lang/IndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0029:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void autoRead() {
        try {
            if (!this.getAutoRead()) {
                return;
            }
            this.read();
            if (this.array == null) {
                return;
            }
        }
        catch (IndexOutOfBoundsException ex) {
            throw b(ex);
        }
        int i = 1;
        try {
            while (i < this.array.length) {
                this.array[i].autoRead();
                ++i;
            }
        }
        catch (IndexOutOfBoundsException ex2) {
            throw b(ex2);
        }
    }
    
    public static void autoWrite(final Structure[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: invokestatic    com/sun/jna/Structure.structureArrayCheck:([Lcom/sun/jna/Structure;)V
        //     7: astore_1       
        //     8: aload_0        
        //     9: iconst_0       
        //    10: aaload         
        //    11: getfield        com/sun/jna/Structure.array:[Lcom/sun/jna/Structure;
        //    14: aload_1        
        //    15: ifnull          48
        //    18: aload_1        
        //    19: ifnull          48
        //    22: goto            29
        //    25: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    28: athrow         
        //    29: aload_0        
        //    30: if_acmpne       57
        //    33: goto            40
        //    36: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    39: athrow         
        //    40: aload_0        
        //    41: goto            48
        //    44: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    47: athrow         
        //    48: iconst_0       
        //    49: aaload         
        //    50: invokevirtual   com/sun/jna/Structure.autoWrite:()V
        //    53: aload_1        
        //    54: ifnonnull       113
        //    57: iconst_0       
        //    58: istore_2       
        //    59: iload_2        
        //    60: aload_0        
        //    61: arraylength    
        //    62: if_icmpge       113
        //    65: aload_0        
        //    66: iload_2        
        //    67: aaload         
        //    68: aload_1        
        //    69: ifnull          103
        //    72: aload_1        
        //    73: ifnull          103
        //    76: goto            83
        //    79: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    82: athrow         
        //    83: ifnull          106
        //    86: goto            93
        //    89: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    92: athrow         
        //    93: aload_0        
        //    94: iload_2        
        //    95: aaload         
        //    96: goto            103
        //    99: invokestatic    com/sun/jna/Structure.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   102: athrow         
        //   103: invokevirtual   com/sun/jna/Structure.autoWrite:()V
        //   106: iinc            2, 1
        //   109: aload_1        
        //   110: ifnonnull       59
        //   113: return         
        //    StackMapTable: 00 10 FF 00 19 00 02 07 01 15 07 04 26 00 01 07 00 4E 43 07 01 15 46 07 00 4E 03 43 07 00 4E 43 07 01 15 08 FC 00 01 01 53 07 00 4E 43 07 00 01 45 07 00 4E 03 45 07 00 4E 43 07 00 01 02 FA 00 06
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                 
        //  -----  -----  -----  -----  -------------------------------------
        //  8      22     25     29     Ljava/lang/IndexOutOfBoundsException;
        //  18     33     36     40     Ljava/lang/IndexOutOfBoundsException;
        //  29     41     44     48     Ljava/lang/IndexOutOfBoundsException;
        //  65     76     79     83     Ljava/lang/IndexOutOfBoundsException;
        //  72     86     89     93     Ljava/lang/IndexOutOfBoundsException;
        //  83     96     99     103    Ljava/lang/IndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0029:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void autoWrite() {
        try {
            if (!this.getAutoWrite()) {
                return;
            }
            this.write();
            if (this.array == null) {
                return;
            }
        }
        catch (IndexOutOfBoundsException ex) {
            throw b(ex);
        }
        int i = 1;
        try {
            while (i < this.array.length) {
                this.array[i].autoWrite();
                ++i;
            }
        }
        catch (IndexOutOfBoundsException ex2) {
            throw b(ex2);
        }
    }
    
    protected int getNativeSize(final Class<?> clazz) {
        return this.getNativeSize(clazz, null);
    }
    
    protected int getNativeSize(final Class<?> clazz, final Object o) {
        return Native.getNativeSize(clazz, o);
    }
    
    static void validate(final Class<?> clazz) {
        newInstance(clazz, Structure.PLACEHOLDER_MEMORY);
    }
    
    static void access$1900(final Structure structure, final boolean b) {
        structure.ensureAllocated(b);
    }
    
    static Pointer access$2000() {
        return Structure.PLACEHOLDER_MEMORY;
    }
    
    static {
        final String[] a2 = new String[53];
        int n = 0;
        final int n2 = 0;
        String s;
        int n3 = (s = "e[\u00dfa\u0003\u00e70\u00ce\u0086\u00fc\u009f\u0005\u00d7´\u00de¹o\u001f\u00c9K-D\u00f6K+\u0081\u00f1:\u0088\u0088O\u00c9Ic`\u00c1\u00cd()²\u000e©y¤U¹8\u00f5\u001aud\u00e4\u00c1\u0011\u00ec\u00fa\u0095\fCK$¥\u00d5\u009a\u0018\n\u0017\u00d1e4\u0093\u009b\u0019@\u0082\u001cMR\u0012u²\u0085©\b¤v²\u00f7\u00ef\u0017\u0006©\u00ee\u00c2\u00e3\u001e3\u000eZWo3U0\u00c2K\u00ceº\u0011²c\u00ec+\u008c\u0090!\u00cb»\r¿\u00e2\u00f5eO°\u00d0%\u00d4#¥\u009cp\u00f0\u00e6\u0084\u008b`\r\u00fc\u009e\u0096\u0093O\u0017\u0018Ou\u0013\u0092'³.¶\u00cdºk\u0011a\u00c1Qz9©\u00fa\u0093\u00ca,\u00e8\u007fE©\by\u00cdb\u00e7(\u00d9\u001f\u000b>\u00ff#O\u0016\u00d4\u00fb\u00d7\u00c6\u00d3»'ª'«¬·&H\u008b\u0016R\u0095\u0089\u0081\u00d0\u00f2\u00cb\u00117\u0005\u00898n\u00f5\u008e¾\u0013(\u00f7\u00e0\u00d0\u00c3X¦\u00fe¦4\u00fd¸\u0011\u0016¦\u00e9\ft\u0095\u0002\u00fd\u00cd;l!eM\u008f\u001d¢JkV \u00f6A?\u00e2'T\u0088X\u0003\u00cd£\u00e9[\u009cj¢i\u00e1\u0084\u00de\u009d\u0004\u009c\u00e9w|+{§z-\u00d0\u00d1\u00d2yU\n\u00f7\u00c2\u00c7k6\u00f4\u00ed¿\u00fc\u0017T\u008f\u00c5\u0014\u0088\u0083\u00f0¼*p¥\u00d6\u0014\u0080\u00cb½\u00f1\u009ce\u00d4m\u0097\u00f4\u001b\u009b$\u000b\u00d3\u00da,:\u008d\u00f2\u008f\u0080\u0011=i±«\u00e6\u00fc\u001c ¨P¶¥\u00c2\u0091N\u0003\u000bH\u00d1 «e\u0000d*\u0093\u0091S\u00f3,Fxr\u009bs\u00ce¯q\u0002\u001dªo\u0011®`\u0097\u00e5>\u00f4R\u00d1\u008e8\u001c¢¨\u00d7\u0017\u00e0L\u00c0J\u001f\b`\u00ca$c(D\u00d1 \u00ee\u00ec@\u00de\u0001oZ~\u00ee\u00e0i¤\u00d7E\u0094\u00e4¶³yd\r1m\u00e71Z\u00cfr£¶¡\u0089F\u0013\u00e0\u0092\u0095\u001c\u0016]\u00d4u/3D¾¨+¯\u000b\u00c6\u000e\u0011¡\u00df\u0089\u00ccª\u00f3t¿\u00c8\u00cf\u00e4C>($±¡,\u0004X\u001e\u00efs\u008fW\u00c22®@v\u00dc\u0093\u0099V\u00c6\u00ec=/\u0013\u0006\u00f9¡\u0012\u0097\u008a\u00d5\u00c5\u00d4h½X5!\u0019#R\u00f6\u00cfc;\u00df\n\u00dfk\u0013\u00d2\u00eb\u00ee7\fk|¯\u0084\u00e057\u000e\u0094°¶¼\u0090¡Q\u0095\u0097pA%\u000f\u001c\u00f2«F3$\u0007Cq\u0015j`\u0099Z¤\u0011\u00f2\u00e1{&_\u0019u\u00c7\u001e\u008a\u00f9s\u0082¢\u0091\u009b\u0096\u0005d\u00c3H§\u0002\u000e\u0085|\u0011W\u0082°\u0019»«\\.\u00ccW\u0093*Y\u00e7\u000e\u00e6\u00f1\u0001 \u00c4¤\u00ea»\u007fb*5\u00ef\u0099\u00db\u00f34\u0002«@µ\u00cb7V¿\u008eqV\u00f3\u00e9\u0097\u00d2\u00f3\u008dQc\u00e3\u0018:2%\u00e3}\u00ff¤\u00c6\u0019\b\u00ad$\u00ad\u001a.\u00d4\u00e2C\u0090t,\u0091\u00caO[q\u00e2\u00c9o\u0080,~l¼\f?¤»\u00d7\u00d6G\u0018\b/X©!oc2I\u00e54\u00cb\u00dd 8\u001f\u0005Fxg\u00f4xS\u00fc\u00d9\u0097G\u00da\u008cu\u0092\u00ad«\u0017\u00cd\u009e\n\u00f6\u001b\u008f\u00c3\u00de\u0012;£h0®\u00c6\u00daup\u00d0\u0083\u0001\u0013\u00d0G_\u00db\u00ff\u00ee<\u0019\u00db\u00ea\u009b\u00dac\u0094\u009fk\u00d7¡¾\u001a\u00f8\nW\u00c9§/v\u00da\u00e5\u001f\u001fL¹\n\u00ccQ¼0§\u00dbj\u009f\u00fd\u0081\u0002\u0017\u008d\u0002\u0087e\u0004\u00d2'\u00f1\u00e7\u0003\u0011\u00fd§%$\u00d6\u009e\r\u008f?%M\"'\u00cd\u00e9\u0080\u000e\u00deT\u00fd>^#\u00c8\u00f5\u00f2\u0018\u000b;w\u00f7\u00d2\u0094¾V¤\u000f7\u000f\u0093>\u00cf; \u00e4\u000f¥ld\u0003©x«\u0094\u00e2µ\u0085z¬q\u008aa,.\u001dLe«\u0003\u00961\u0013\u00c9\u0085\u00f5\u001b;\u0007D\u0098\u00cb»\u009eV\u0019\u0081y2\u00da\u00ef\u00f8\u00db\u00dc|<\u00c8!1\u00e5`\u0084¢-\u0010\u008b5^{\u0018\u0095R\u0091\u00c7/(D_\u00dfn\u00c0\u000e£\u00ce\u0095mPe`\u00adª\u00d7\u00ec\u00dd\u00cd\u00d7\u001d2#c~\\\u0012\u0015¦\u0012¨y\u00f4¢\u00f5«[3S§\u0082\u00d2e\u00ce#Y\u0006:n\u0089\u0016\u0015\u00c1b\u00fc\u0090B\u00cb¼6\u00f7\u00fb\u00db`U*\u0094\u00ed\u008f}\u00de\u0082\u009f\u0005\u00c8\u00c6\u00d9~\n\u001d\u00d3\nQ\u00c2(B«\u0094¶\u0095\u009719\u000f\u000e8\u008b\u001e?)«\u0001_\u00c8T\u0090>X\u0016\u0007h\u00f9>\u00f0\u009b\u00e5w\u000b-\u0082fc\u0011\u00e5\u00da\u00e2\u0004·¾ e\u0085\u0089¨¯\u008eb\u00f6\u0095\u0012\u00ad{\u00d6\u00c1]\u00ea\u00e4\u0000_8©½\u00dej\u00e5)\u008b\u000f5\\!X\u001f;\fK©O\u007f[\u001c6£\u00f1D\u001a\u0006rs\u0004o\u00cc\u001c\u0085¿\u00d1\u0016\u00f0\u0002\u0016,\u0010\u008d\u0085lI\"³laa!\u00fbzZU{w\u00f1\n\u008e3\u00ec_\u00d0R3z~ª\u00f1\u0094u\u00c3/A\u00cez\u0003¯%ºPb/\u001f\u00ddf\u000e\u00f2\u001f¾\u00ce\u009c\u00cf\u0015)+\u00f7J\u0090\u0016B\u0016\u0096\u0090Vº=H¤\u0012·¯W#©m\u0081\u00d7\u00e4\\R[ha'\u00f2H\u009e\u008b\u0011J\u00f0\u00eb oO\u00e2\u0011\u00f2\u0011´\u00e3\u00d9\u008e\u00026\u0096w\u0010\u00c1«\u0012b\u00983\u00c3\u00e3g\u00e1\u00c1¹\u00f3\u00cc\u0082\u00c3\u00ec\u00fd\u001a\u0086»\u000fJ4\u0080\u00e2.P\u0092I_\n±\u0006\u00e9\u00ff\u0099\u00034(\u00c4\u0004\u00e3g\u008du4'¶\u0004Q\u0090\u00e5\u00e1E\u0018dA¯\u00d2\u001b}\u0081xq,¬h\u00d8\u00c2\u00d5\u0087\u00e2U\u00c4R¯\u00ee\u00fb\u0082) j\u0089\u00c9\u00ee;e\u00c9\u00f7\u00e0\u00ec\u001d\u00dc\u0017P(F\u00c9\t\u0088Y\u00cb\u00f3\u00fb \bck'¸\u00fd\u00e3\u00f1ª^¬\u001a\u00f1³\u000e\u0088r\u00d6hn¢yp\u009cW´>\r\u0004>º\u0002\u00e1\u00f3\u00191¨\u0019>gdC\u00d6\u001a[\u0087N\u00ea\u00f9\u0080¡\u00f4\u0084\u00ec\u008f·\u00c43w\u00e8\u00cd®\u00f9\u00c7\u0096[\u00f4¨\u00caµ\u001b\u0014\\§\u00c99\u00d0\u008bW\u00f1\u0012L\u00d0\u001e6o\u009f\u00e7\u0012\u00c3T\u0016·\u00d0/\u00c8\b\u0010").length();
        b(n2);
        int n4 = 37;
        int n5 = -1;
    Label_0027:
        while (true) {
            while (true) {
                int n9;
                int n8;
                int n7;
                int n6 = n7 = (n8 = (n9 = 100));
                ++n5;
                final String s2 = s;
                final int beginIndex = n5;
                String s3 = s2.substring(beginIndex, beginIndex + n4);
                int n10 = -1;
                while (true) {
                    final char[] charArray = s3.toCharArray();
                    final int length = charArray.length;
                    int n11 = 0;
                    while (true) {
                        Label_0264: {
                            if (length > 1) {
                                break Label_0264;
                            }
                            n8 = (n7 = n11);
                            do {
                                final char c2 = charArray[n7];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 7;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 74;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 102;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 52;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 75;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 28;
                                        break;
                                    }
                                    default: {
                                        n12 = 101;
                                        break;
                                    }
                                }
                                charArray[n8] = (char)(c2 ^ (n6 ^ n12));
                                ++n11;
                            } while (n9 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String intern = new String(charArray).intern();
                    switch (n10) {
                        default: {
                            a2[n++] = intern;
                            if ((n5 += n4) < n3) {
                                n4 = s.charAt(n5);
                                continue Label_0027;
                            }
                            n3 = (s = "ªZ5\u00c9\u00d0htI'\u00c3t¼\u00db\u009f\u000f´<2\u00cb\u00f5¹¹\u009a\u00ea\u0001\n \u0081P\u008b\u00fc\u00fc\u00cff\u00d7ºi\u009a¿\u001a³\b&f \u0012¤\u00e2 5(\u0094\u00d8£\u00d97").length();
                            n4 = 2;
                            n5 = -1;
                            break;
                        }
                        case 0: {
                            a2[n++] = intern;
                            if ((n5 += n4) < n3) {
                                n4 = s.charAt(n5);
                                break;
                            }
                            break Label_0027;
                        }
                    }
                    n6 = (n7 = (n8 = (n9 = 86)));
                    ++n5;
                    final String s4 = s;
                    final int beginIndex2 = n5;
                    s3 = s4.substring(beginIndex2, beginIndex2 + n4);
                    n10 = 0;
                }
            }
            break;
        }
        a = a2;
        c = new String[53];
        layoutInfo = new WeakHashMap<Class<?>, Structure$LayoutInfo>();
        fieldOrder = new WeakHashMap<Class<?>, List<String>>();
        reads = new Structure$1();
        busy = new Structure$2();
        PLACEHOLDER_MEMORY = new Structure$3(0L);
    }
    
    public static void b(final int b) {
        Structure.b = b;
    }
    
    public static int b() {
        return Structure.b;
    }
    
    public static int a() {
        final int b = b();
        try {
            if (b == 0) {
                return 75;
            }
        }
        catch (IndexOutOfBoundsException ex) {
            throw b(ex);
        }
        return 0;
    }
    
    private static Throwable b(final Throwable t) {
        return t;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0x786F) & 0xFFFF;
        if (Structure.c[n3] == null) {
            final char[] charArray = Structure.a[n3].toCharArray();
            int n4 = 0;
            switch (charArray[0] & '\u00ff') {
                case 0: {
                    n4 = 173;
                    break;
                }
                case 1: {
                    n4 = 83;
                    break;
                }
                case 2: {
                    n4 = 229;
                    break;
                }
                case 3: {
                    n4 = 211;
                    break;
                }
                case 4: {
                    n4 = 128;
                    break;
                }
                case 5: {
                    n4 = 202;
                    break;
                }
                case 6: {
                    n4 = 198;
                    break;
                }
                case 7: {
                    n4 = 189;
                    break;
                }
                case 8: {
                    n4 = 243;
                    break;
                }
                case 9: {
                    n4 = 162;
                    break;
                }
                case 10: {
                    n4 = 221;
                    break;
                }
                case 11: {
                    n4 = 166;
                    break;
                }
                case 12: {
                    n4 = 195;
                    break;
                }
                case 13: {
                    n4 = 236;
                    break;
                }
                case 14: {
                    n4 = 95;
                    break;
                }
                case 15: {
                    n4 = 100;
                    break;
                }
                case 16: {
                    n4 = 227;
                    break;
                }
                case 17: {
                    n4 = 234;
                    break;
                }
                case 18: {
                    n4 = 24;
                    break;
                }
                case 19: {
                    n4 = 155;
                    break;
                }
                case 20: {
                    n4 = 192;
                    break;
                }
                case 21: {
                    n4 = 218;
                    break;
                }
                case 22: {
                    n4 = 165;
                    break;
                }
                case 23: {
                    n4 = 93;
                    break;
                }
                case 24: {
                    n4 = 148;
                    break;
                }
                case 25: {
                    n4 = 230;
                    break;
                }
                case 26: {
                    n4 = 219;
                    break;
                }
                case 27: {
                    n4 = 153;
                    break;
                }
                case 28: {
                    n4 = 224;
                    break;
                }
                case 29: {
                    n4 = 228;
                    break;
                }
                case 30: {
                    n4 = 254;
                    break;
                }
                case 31: {
                    n4 = 65;
                    break;
                }
                case 32: {
                    n4 = 73;
                    break;
                }
                case 33: {
                    n4 = 53;
                    break;
                }
                case 34: {
                    n4 = 7;
                    break;
                }
                case 35: {
                    n4 = 161;
                    break;
                }
                case 36: {
                    n4 = 11;
                    break;
                }
                case 37: {
                    n4 = 137;
                    break;
                }
                case 38: {
                    n4 = 42;
                    break;
                }
                case 39: {
                    n4 = 70;
                    break;
                }
                case 40: {
                    n4 = 94;
                    break;
                }
                case 41: {
                    n4 = 87;
                    break;
                }
                case 42: {
                    n4 = 139;
                    break;
                }
                case 43: {
                    n4 = 206;
                    break;
                }
                case 44: {
                    n4 = 122;
                    break;
                }
                case 45: {
                    n4 = 231;
                    break;
                }
                case 46: {
                    n4 = 118;
                    break;
                }
                case 47: {
                    n4 = 19;
                    break;
                }
                case 48: {
                    n4 = 22;
                    break;
                }
                case 49: {
                    n4 = 77;
                    break;
                }
                case 50: {
                    n4 = 142;
                    break;
                }
                case 51: {
                    n4 = 168;
                    break;
                }
                case 52: {
                    n4 = 185;
                    break;
                }
                case 53: {
                    n4 = 75;
                    break;
                }
                case 54: {
                    n4 = 68;
                    break;
                }
                case 55: {
                    n4 = 178;
                    break;
                }
                case 56: {
                    n4 = 150;
                    break;
                }
                case 57: {
                    n4 = 54;
                    break;
                }
                case 58: {
                    n4 = 80;
                    break;
                }
                case 59: {
                    n4 = 125;
                    break;
                }
                case 60: {
                    n4 = 169;
                    break;
                }
                case 61: {
                    n4 = 223;
                    break;
                }
                case 62: {
                    n4 = 147;
                    break;
                }
                case 63: {
                    n4 = 105;
                    break;
                }
                case 64: {
                    n4 = 66;
                    break;
                }
                case 65: {
                    n4 = 232;
                    break;
                }
                case 66: {
                    n4 = 57;
                    break;
                }
                case 67: {
                    n4 = 120;
                    break;
                }
                case 68: {
                    n4 = 106;
                    break;
                }
                case 69: {
                    n4 = 25;
                    break;
                }
                case 70: {
                    n4 = 59;
                    break;
                }
                case 71: {
                    n4 = 249;
                    break;
                }
                case 72: {
                    n4 = 26;
                    break;
                }
                case 73: {
                    n4 = 31;
                    break;
                }
                case 74: {
                    n4 = 146;
                    break;
                }
                case 75: {
                    n4 = 215;
                    break;
                }
                case 76: {
                    n4 = 104;
                    break;
                }
                case 77: {
                    n4 = 240;
                    break;
                }
                case 78: {
                    n4 = 163;
                    break;
                }
                case 79: {
                    n4 = 27;
                    break;
                }
                case 80: {
                    n4 = 37;
                    break;
                }
                case 81: {
                    n4 = 130;
                    break;
                }
                case 82: {
                    n4 = 58;
                    break;
                }
                case 83: {
                    n4 = 103;
                    break;
                }
                case 84: {
                    n4 = 28;
                    break;
                }
                case 85: {
                    n4 = 203;
                    break;
                }
                case 86: {
                    n4 = 63;
                    break;
                }
                case 87: {
                    n4 = 242;
                    break;
                }
                case 88: {
                    n4 = 88;
                    break;
                }
                case 89: {
                    n4 = 102;
                    break;
                }
                case 90: {
                    n4 = 133;
                    break;
                }
                case 91: {
                    n4 = 4;
                    break;
                }
                case 92: {
                    n4 = 154;
                    break;
                }
                case 93: {
                    n4 = 226;
                    break;
                }
                case 94: {
                    n4 = 72;
                    break;
                }
                case 95: {
                    n4 = 245;
                    break;
                }
                case 96: {
                    n4 = 21;
                    break;
                }
                case 97: {
                    n4 = 247;
                    break;
                }
                case 98: {
                    n4 = 124;
                    break;
                }
                case 99: {
                    n4 = 86;
                    break;
                }
                case 100: {
                    n4 = 76;
                    break;
                }
                case 101: {
                    n4 = 30;
                    break;
                }
                case 102: {
                    n4 = 12;
                    break;
                }
                case 103: {
                    n4 = 135;
                    break;
                }
                case 104: {
                    n4 = 204;
                    break;
                }
                case 105: {
                    n4 = 208;
                    break;
                }
                case 106: {
                    n4 = 3;
                    break;
                }
                case 107: {
                    n4 = 81;
                    break;
                }
                case 108: {
                    n4 = 121;
                    break;
                }
                case 109: {
                    n4 = 174;
                    break;
                }
                case 110: {
                    n4 = 152;
                    break;
                }
                case 111: {
                    n4 = 126;
                    break;
                }
                case 112: {
                    n4 = 112;
                    break;
                }
                case 113: {
                    n4 = 217;
                    break;
                }
                case 114: {
                    n4 = 149;
                    break;
                }
                case 115: {
                    n4 = 92;
                    break;
                }
                case 116: {
                    n4 = 201;
                    break;
                }
                case 117: {
                    n4 = 177;
                    break;
                }
                case 118: {
                    n4 = 111;
                    break;
                }
                case 119: {
                    n4 = 35;
                    break;
                }
                case 120: {
                    n4 = 96;
                    break;
                }
                case 121: {
                    n4 = 14;
                    break;
                }
                case 122: {
                    n4 = 1;
                    break;
                }
                case 123: {
                    n4 = 84;
                    break;
                }
                case 124: {
                    n4 = 16;
                    break;
                }
                case 125: {
                    n4 = 114;
                    break;
                }
                case 126: {
                    n4 = 0;
                    break;
                }
                case 127: {
                    n4 = 210;
                    break;
                }
                case 128: {
                    n4 = 60;
                    break;
                }
                case 129: {
                    n4 = 48;
                    break;
                }
                case 130: {
                    n4 = 13;
                    break;
                }
                case 131: {
                    n4 = 246;
                    break;
                }
                case 132: {
                    n4 = 233;
                    break;
                }
                case 133: {
                    n4 = 8;
                    break;
                }
                case 134: {
                    n4 = 196;
                    break;
                }
                case 135: {
                    n4 = 62;
                    break;
                }
                case 136: {
                    n4 = 237;
                    break;
                }
                case 137: {
                    n4 = 140;
                    break;
                }
                case 138: {
                    n4 = 117;
                    break;
                }
                case 139: {
                    n4 = 145;
                    break;
                }
                case 140: {
                    n4 = 90;
                    break;
                }
                case 141: {
                    n4 = 47;
                    break;
                }
                case 142: {
                    n4 = 91;
                    break;
                }
                case 143: {
                    n4 = 110;
                    break;
                }
                case 144: {
                    n4 = 220;
                    break;
                }
                case 145: {
                    n4 = 10;
                    break;
                }
                case 146: {
                    n4 = 175;
                    break;
                }
                case 147: {
                    n4 = 64;
                    break;
                }
                case 148: {
                    n4 = 46;
                    break;
                }
                case 149: {
                    n4 = 136;
                    break;
                }
                case 150: {
                    n4 = 39;
                    break;
                }
                case 151: {
                    n4 = 67;
                    break;
                }
                case 152: {
                    n4 = 38;
                    break;
                }
                case 153: {
                    n4 = 184;
                    break;
                }
                case 154: {
                    n4 = 209;
                    break;
                }
                case 155: {
                    n4 = 159;
                    break;
                }
                case 156: {
                    n4 = 197;
                    break;
                }
                case 157: {
                    n4 = 187;
                    break;
                }
                case 158: {
                    n4 = 55;
                    break;
                }
                case 159: {
                    n4 = 207;
                    break;
                }
                case 160: {
                    n4 = 134;
                    break;
                }
                case 161: {
                    n4 = 129;
                    break;
                }
                case 162: {
                    n4 = 131;
                    break;
                }
                case 163: {
                    n4 = 41;
                    break;
                }
                case 164: {
                    n4 = 141;
                    break;
                }
                case 165: {
                    n4 = 79;
                    break;
                }
                case 166: {
                    n4 = 50;
                    break;
                }
                case 167: {
                    n4 = 56;
                    break;
                }
                case 168: {
                    n4 = 214;
                    break;
                }
                case 169: {
                    n4 = 151;
                    break;
                }
                case 170: {
                    n4 = 167;
                    break;
                }
                case 171: {
                    n4 = 193;
                    break;
                }
                case 172: {
                    n4 = 29;
                    break;
                }
                case 173: {
                    n4 = 180;
                    break;
                }
                case 174: {
                    n4 = 138;
                    break;
                }
                case 175: {
                    n4 = 18;
                    break;
                }
                case 176: {
                    n4 = 225;
                    break;
                }
                case 177: {
                    n4 = 43;
                    break;
                }
                case 178: {
                    n4 = 107;
                    break;
                }
                case 179: {
                    n4 = 23;
                    break;
                }
                case 180: {
                    n4 = 5;
                    break;
                }
                case 181: {
                    n4 = 253;
                    break;
                }
                case 182: {
                    n4 = 127;
                    break;
                }
                case 183: {
                    n4 = 171;
                    break;
                }
                case 184: {
                    n4 = 144;
                    break;
                }
                case 185: {
                    n4 = 123;
                    break;
                }
                case 186: {
                    n4 = 181;
                    break;
                }
                case 187: {
                    n4 = 235;
                    break;
                }
                case 188: {
                    n4 = 132;
                    break;
                }
                case 189: {
                    n4 = 179;
                    break;
                }
                case 190: {
                    n4 = 97;
                    break;
                }
                case 191: {
                    n4 = 40;
                    break;
                }
                case 192: {
                    n4 = 164;
                    break;
                }
                case 193: {
                    n4 = 255;
                    break;
                }
                case 194: {
                    n4 = 51;
                    break;
                }
                case 195: {
                    n4 = 172;
                    break;
                }
                case 196: {
                    n4 = 157;
                    break;
                }
                case 197: {
                    n4 = 89;
                    break;
                }
                case 198: {
                    n4 = 244;
                    break;
                }
                case 199: {
                    n4 = 49;
                    break;
                }
                case 200: {
                    n4 = 248;
                    break;
                }
                case 201: {
                    n4 = 250;
                    break;
                }
                case 202: {
                    n4 = 205;
                    break;
                }
                case 203: {
                    n4 = 188;
                    break;
                }
                case 204: {
                    n4 = 32;
                    break;
                }
                case 205: {
                    n4 = 99;
                    break;
                }
                case 206: {
                    n4 = 212;
                    break;
                }
                case 207: {
                    n4 = 199;
                    break;
                }
                case 208: {
                    n4 = 182;
                    break;
                }
                case 209: {
                    n4 = 69;
                    break;
                }
                case 210: {
                    n4 = 216;
                    break;
                }
                case 211: {
                    n4 = 45;
                    break;
                }
                case 212: {
                    n4 = 34;
                    break;
                }
                case 213: {
                    n4 = 2;
                    break;
                }
                case 214: {
                    n4 = 238;
                    break;
                }
                case 215: {
                    n4 = 15;
                    break;
                }
                case 216: {
                    n4 = 190;
                    break;
                }
                case 217: {
                    n4 = 143;
                    break;
                }
                case 218: {
                    n4 = 156;
                    break;
                }
                case 219: {
                    n4 = 191;
                    break;
                }
                case 220: {
                    n4 = 113;
                    break;
                }
                case 221: {
                    n4 = 119;
                    break;
                }
                case 222: {
                    n4 = 78;
                    break;
                }
                case 223: {
                    n4 = 6;
                    break;
                }
                case 224: {
                    n4 = 251;
                    break;
                }
                case 225: {
                    n4 = 36;
                    break;
                }
                case 226: {
                    n4 = 109;
                    break;
                }
                case 227: {
                    n4 = 116;
                    break;
                }
                case 228: {
                    n4 = 213;
                    break;
                }
                case 229: {
                    n4 = 33;
                    break;
                }
                case 230: {
                    n4 = 44;
                    break;
                }
                case 231: {
                    n4 = 20;
                    break;
                }
                case 232: {
                    n4 = 61;
                    break;
                }
                case 233: {
                    n4 = 252;
                    break;
                }
                case 234: {
                    n4 = 241;
                    break;
                }
                case 235: {
                    n4 = 17;
                    break;
                }
                case 236: {
                    n4 = 186;
                    break;
                }
                case 237: {
                    n4 = 82;
                    break;
                }
                case 238: {
                    n4 = 71;
                    break;
                }
                case 239: {
                    n4 = 170;
                    break;
                }
                case 240: {
                    n4 = 158;
                    break;
                }
                case 241: {
                    n4 = 101;
                    break;
                }
                case 242: {
                    n4 = 239;
                    break;
                }
                case 243: {
                    n4 = 74;
                    break;
                }
                case 244: {
                    n4 = 98;
                    break;
                }
                case 245: {
                    n4 = 9;
                    break;
                }
                case 246: {
                    n4 = 200;
                    break;
                }
                case 247: {
                    n4 = 52;
                    break;
                }
                case 248: {
                    n4 = 115;
                    break;
                }
                case 249: {
                    n4 = 176;
                    break;
                }
                case 250: {
                    n4 = 108;
                    break;
                }
                case 251: {
                    n4 = 194;
                    break;
                }
                case 252: {
                    n4 = 85;
                    break;
                }
                case 253: {
                    n4 = 160;
                    break;
                }
                case 254: {
                    n4 = 222;
                    break;
                }
                default: {
                    n4 = 183;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < charArray.length; ++i) {
                final int n8 = i % 2;
                final char[] array = charArray;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ charArray[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ charArray[i]) & 0xFF);
                }
            }
            Structure.c[n3] = new String(charArray).intern();
        }
        return Structure.c[n3];
    }
}
