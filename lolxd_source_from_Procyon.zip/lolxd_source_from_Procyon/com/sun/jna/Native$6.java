// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna;

final class Native$6 extends SecurityManager
{
    public Class<?>[] getClassContext() {
        return super.getClassContext();
    }
}
