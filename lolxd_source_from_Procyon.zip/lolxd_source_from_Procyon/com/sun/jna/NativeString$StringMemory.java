// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna;

class NativeString$StringMemory extends Memory
{
    final NativeString this$0;
    
    public NativeString$StringMemory(final NativeString this$0, final long n) {
        this.this$0 = this$0;
        super(n);
    }
    
    @Override
    public String toString() {
        return this.this$0.toString();
    }
}
