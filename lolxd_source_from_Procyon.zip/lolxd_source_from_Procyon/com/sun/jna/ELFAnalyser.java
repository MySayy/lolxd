// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna;

import java.nio.ByteOrder;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.io.RandomAccessFile;
import java.io.IOException;

class ELFAnalyser
{
    private static final byte[] ELF_MAGIC;
    private static final int EF_ARM_ABI_FLOAT_HARD = 1024;
    private static final int EF_ARM_ABI_FLOAT_SOFT = 512;
    private static final int EI_DATA_BIG_ENDIAN = 2;
    private static final int E_MACHINE_ARM = 40;
    private static final int EI_CLASS_64BIT = 2;
    private final String filename;
    private boolean ELF;
    private boolean _64Bit;
    private boolean bigEndian;
    private boolean armHardFloat;
    private boolean armSoftFloat;
    private boolean arm;
    
    public static ELFAnalyser analyse(final String s) throws IOException {
        final ELFAnalyser elfAnalyser = new ELFAnalyser(s);
        elfAnalyser.runDetection();
        return elfAnalyser;
    }
    
    public boolean isELF() {
        return this.ELF;
    }
    
    public boolean is64Bit() {
        return this._64Bit;
    }
    
    public boolean isBigEndian() {
        return this.bigEndian;
    }
    
    public String getFilename() {
        return this.filename;
    }
    
    public boolean isArmHardFloat() {
        return this.armHardFloat;
    }
    
    public boolean isArmSoftFloat() {
        return this.armSoftFloat;
    }
    
    public boolean isArm() {
        return this.arm;
    }
    
    private ELFAnalyser(final String filename) {
        this.ELF = false;
        this._64Bit = false;
        this.bigEndian = false;
        this.armHardFloat = false;
        this.armSoftFloat = false;
        this.arm = false;
        this.filename = filename;
    }
    
    private void runDetection() throws IOException {
        final RandomAccessFile randomAccessFile = new RandomAccessFile(this.filename, "r");
        if (randomAccessFile.length() > 4L) {
            final byte[] array = new byte[4];
            try {
                randomAccessFile.seek(0L);
                randomAccessFile.read(array);
                if (Arrays.equals(array, ELFAnalyser.ELF_MAGIC)) {
                    this.ELF = true;
                }
            }
            catch (IOException ex) {
                throw b(ex);
            }
        }
        try {
            if (!this.ELF) {
                return;
            }
        }
        catch (IOException ex2) {
            throw b(ex2);
        }
        randomAccessFile.seek(4L);
        final byte byte1 = randomAccessFile.readByte();
        int capacity = 0;
        Label_0127: {
            Label_0101: {
                try {
                    if (byte1 == 2) {
                        final boolean 64Bit = true;
                        break Label_0101;
                    }
                }
                catch (IOException ex3) {
                    throw b(ex3);
                }
                final boolean 64Bit = false;
                try {
                    this._64Bit = 64Bit;
                    randomAccessFile.seek(0L);
                    if (this._64Bit) {
                        capacity = 64;
                        break Label_0127;
                    }
                }
                catch (IOException ex4) {
                    throw b(ex4);
                }
            }
            capacity = 52;
        }
        final ByteBuffer allocate = ByteBuffer.allocate(capacity);
        ByteBuffer byteBuffer2 = null;
        int n = 0;
        Label_0245: {
            Label_0234: {
                Label_0209: {
                    Label_0184: {
                        ByteBuffer byteBuffer = null;
                        Label_0160: {
                            try {
                                randomAccessFile.getChannel().read(allocate, 0L);
                                if (allocate.get(5) == 2) {
                                    final boolean bigEndian = true;
                                    break Label_0160;
                                }
                            }
                            catch (IOException ex5) {
                                throw b(ex5);
                            }
                            final boolean bigEndian = false;
                            try {
                                this.bigEndian = bigEndian;
                                byteBuffer = allocate;
                                if (this.bigEndian) {
                                    final ByteOrder bo = ByteOrder.BIG_ENDIAN;
                                    break Label_0184;
                                }
                            }
                            catch (IOException ex6) {
                                throw b(ex6);
                            }
                        }
                        final ByteOrder bo = ByteOrder.LITTLE_ENDIAN;
                        try {
                            byteBuffer.order(bo);
                            if (allocate.get(18) == 40) {
                                final boolean arm = true;
                                break Label_0209;
                            }
                        }
                        catch (IOException ex7) {
                            throw b(ex7);
                        }
                    }
                    final boolean arm = false;
                    try {
                        this.arm = arm;
                        if (!this.arm) {
                            return;
                        }
                        byteBuffer2 = allocate;
                        final ELFAnalyser elfAnalyser = this;
                        final boolean b = elfAnalyser._64Bit;
                        if (b) {
                            break Label_0234;
                        }
                        break Label_0234;
                    }
                    catch (IOException ex8) {
                        throw b(ex8);
                    }
                }
                try {
                    byteBuffer2 = allocate;
                    final ELFAnalyser elfAnalyser = this;
                    final boolean b = elfAnalyser._64Bit;
                    if (b) {
                        n = 48;
                        break Label_0245;
                    }
                }
                catch (IOException ex9) {
                    throw b(ex9);
                }
            }
            n = 36;
        }
        final int int1 = byteBuffer2.getInt(n);
        boolean armHardFloat = false;
        Label_0297: {
            Label_0272: {
                try {
                    if ((int1 & 0x200) == 0x200) {
                        final boolean armSoftFloat = true;
                        break Label_0272;
                    }
                }
                catch (IOException ex10) {
                    throw b(ex10);
                }
                final boolean armSoftFloat = false;
                try {
                    this.armSoftFloat = armSoftFloat;
                    if ((int1 & 0x400) == 0x400) {
                        armHardFloat = true;
                        break Label_0297;
                    }
                }
                catch (IOException ex11) {
                    throw b(ex11);
                }
            }
            armHardFloat = false;
        }
        this.armHardFloat = armHardFloat;
    }
    
    static {
        ELF_MAGIC = new byte[] { 127, 69, 76, 70 };
    }
    
    private static IOException b(final IOException ex) {
        return ex;
    }
}
