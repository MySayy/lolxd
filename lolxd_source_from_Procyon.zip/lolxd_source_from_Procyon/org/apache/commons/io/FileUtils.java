// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import org.apache.commons.io.output.NullOutputStream;
import java.util.zip.CheckedInputStream;
import java.util.zip.Checksum;
import java.util.zip.CRC32;
import java.util.Date;
import java.io.BufferedOutputStream;
import java.nio.charset.Charset;
import java.net.URLConnection;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.ArrayList;
import java.io.InputStream;
import java.net.URL;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;
import java.util.Iterator;
import org.apache.commons.io.filefilter.FalseFileFilter;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.FileFilterUtils;
import java.util.LinkedList;
import java.io.FileFilter;
import org.apache.commons.io.filefilter.IOFileFilter;
import java.util.Collection;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.FileInputStream;
import q.o.m.s.q;
import java.io.File;
import java.math.BigInteger;

public class FileUtils
{
    public static final long ONE_KB = 1024L;
    public static final BigInteger ONE_KB_BI;
    public static final long ONE_MB = 1048576L;
    public static final BigInteger ONE_MB_BI;
    private static final long FILE_COPY_BUFFER_SIZE = 31457280L;
    public static final long ONE_GB = 1073741824L;
    public static final BigInteger ONE_GB_BI;
    public static final long ONE_TB = 1099511627776L;
    public static final BigInteger ONE_TB_BI;
    public static final long ONE_PB = 1125899906842624L;
    public static final BigInteger ONE_PB_BI;
    public static final long ONE_EB = 1152921504606846976L;
    public static final BigInteger ONE_EB_BI;
    public static final BigInteger ONE_ZB;
    public static final BigInteger ONE_YB;
    public static final File[] EMPTY_FILE_ARRAY;
    private static final String[] a;
    private static final String[] b;
    
    public static File getFile(final File file, final String... array) {
        final int c = IOCase.c();
        try {
            if (file == null) {
                throw new NullPointerException(a(2806, -28964));
            }
        }
        catch (NullPointerException ex) {
            throw b(ex);
        }
        try {
            if (array == null) {
                throw new NullPointerException(a(2790, -9554));
            }
        }
        catch (NullPointerException ex2) {
            throw b(ex2);
        }
        File parent = file;
        final int length = array.length;
        int i = 0;
        File file2 = null;
        while (i < length) {
            file2 = new File(parent, array[i]);
            if (c == 0) {
                return file2;
            }
            parent = file2;
            ++i;
            if (c == 0) {
                break;
            }
        }
        return file2;
    }
    
    public static File getFile(final String... p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: ifnonnull       29
        //     8: new             Ljava/lang/NullPointerException;
        //    11: dup            
        //    12: sipush          2790
        //    15: sipush          -9554
        //    18: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    21: invokespecial   java/lang/NullPointerException.<init>:(Ljava/lang/String;)V
        //    24: athrow         
        //    25: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    28: athrow         
        //    29: aconst_null    
        //    30: astore_2       
        //    31: aload_0        
        //    32: astore_3       
        //    33: aload_3        
        //    34: arraylength    
        //    35: istore          4
        //    37: iconst_0       
        //    38: istore          5
        //    40: iload           5
        //    42: iload           4
        //    44: if_icmpge       122
        //    47: aload_3        
        //    48: iload           5
        //    50: aaload         
        //    51: astore          6
        //    53: aload_2        
        //    54: iload_1        
        //    55: ifne            123
        //    58: iload_1        
        //    59: ifne            114
        //    62: goto            69
        //    65: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    68: athrow         
        //    69: ifnonnull       100
        //    72: goto            79
        //    75: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    78: athrow         
        //    79: new             Ljava/io/File;
        //    82: dup            
        //    83: aload           6
        //    85: invokespecial   java/io/File.<init>:(Ljava/lang/String;)V
        //    88: goto            95
        //    91: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    94: athrow         
        //    95: astore_2       
        //    96: iload_1        
        //    97: ifeq            115
        //   100: new             Ljava/io/File;
        //   103: dup            
        //   104: aload_2        
        //   105: aload           6
        //   107: invokespecial   java/io/File.<init>:(Ljava/io/File;Ljava/lang/String;)V
        //   110: iload_1        
        //   111: ifne            95
        //   114: astore_2       
        //   115: iinc            5, 1
        //   118: iload_1        
        //   119: ifeq            40
        //   122: aload_2        
        //   123: areturn        
        //    StackMapTable: 00 0E FF 00 19 00 02 07 00 40 01 00 01 07 00 31 03 FF 00 0A 00 06 07 00 40 01 07 00 3F 07 00 40 01 01 00 00 FF 00 18 00 07 07 00 40 01 07 00 3F 07 00 40 01 01 07 00 4B 00 01 07 00 31 43 07 00 3F 45 07 00 31 03 4B 07 00 31 43 07 00 3F 04 4D 07 00 3F 00 FA 00 06 40 07 00 3F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      25     25     29     Ljava/lang/NullPointerException;
        //  53     62     65     69     Ljava/lang/NullPointerException;
        //  58     72     75     79     Ljava/lang/NullPointerException;
        //  69     88     91     95     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0069:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static String getTempDirectoryPath() {
        return q.vr(a(2804, -32370));
    }
    
    public static File getTempDirectory() {
        return new File(getTempDirectoryPath());
    }
    
    public static String getUserDirectoryPath() {
        return q.vr(a(2783, -2368));
    }
    
    public static File getUserDirectory() {
        return new File(getUserDirectoryPath());
    }
    
    public static FileInputStream openInputStream(final File p0) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //     8: iload_1        
        //     9: ifeq            44
        //    12: iload_1        
        //    13: ifeq            44
        //    16: goto            23
        //    19: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    22: athrow         
        //    23: ifeq            165
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    32: athrow         
        //    33: aload_0        
        //    34: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //    37: goto            44
        //    40: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    43: athrow         
        //    44: iload_1        
        //    45: ifeq            112
        //    48: ifeq            108
        //    51: goto            58
        //    54: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    57: athrow         
        //    58: new             Ljava/io/IOException;
        //    61: dup            
        //    62: new             Ljava/lang/StringBuilder;
        //    65: dup            
        //    66: invokespecial   java/lang/StringBuilder.<init>:()V
        //    69: sipush          2763
        //    72: sipush          6526
        //    75: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    78: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    81: aload_0        
        //    82: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //    85: sipush          2767
        //    88: sipush          -21381
        //    91: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    94: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    97: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   100: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   103: athrow         
        //   104: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   107: athrow         
        //   108: aload_0        
        //   109: invokestatic    q/o/m/s/q.ee:(Ljava/io/File;)Z
        //   112: ifne            211
        //   115: new             Ljava/io/IOException;
        //   118: dup            
        //   119: new             Ljava/lang/StringBuilder;
        //   122: dup            
        //   123: invokespecial   java/lang/StringBuilder.<init>:()V
        //   126: sipush          2763
        //   129: sipush          6526
        //   132: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   135: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   138: aload_0        
        //   139: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   142: sipush          2755
        //   145: sipush          20006
        //   148: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   151: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   154: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   157: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   160: athrow         
        //   161: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   164: athrow         
        //   165: new             Ljava/io/FileNotFoundException;
        //   168: dup            
        //   169: new             Ljava/lang/StringBuilder;
        //   172: dup            
        //   173: invokespecial   java/lang/StringBuilder.<init>:()V
        //   176: sipush          2763
        //   179: sipush          6526
        //   182: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   185: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   188: aload_0        
        //   189: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   192: sipush          2739
        //   195: sipush          -14564
        //   198: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   201: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   204: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   207: invokespecial   java/io/FileNotFoundException.<init>:(Ljava/lang/String;)V
        //   210: athrow         
        //   211: new             Ljava/io/FileInputStream;
        //   214: dup            
        //   215: aload_0        
        //   216: invokespecial   java/io/FileInputStream.<init>:(Ljava/io/File;)V
        //   219: areturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 0E FF 00 13 00 02 07 00 3F 01 00 01 07 00 60 43 01 45 07 00 60 03 46 07 00 60 43 01 49 07 00 60 03 6D 07 00 60 03 43 01 70 07 00 60 03 2D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      16     19     23     Ljava/io/IOException;
        //  12     26     29     33     Ljava/io/IOException;
        //  23     37     40     44     Ljava/io/IOException;
        //  44     51     54     58     Ljava/io/IOException;
        //  48     104    104    108    Ljava/io/IOException;
        //  112    161    161    165    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0023:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static FileOutputStream openOutputStream(final File file) throws IOException {
        return openOutputStream(file, false);
    }
    
    public static FileOutputStream openOutputStream(final File p0, final boolean p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: iload_2        
        //     6: ifne            158
        //     9: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //    12: ifeq            154
        //    15: goto            22
        //    18: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    21: athrow         
        //    22: aload_0        
        //    23: goto            30
        //    26: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    29: athrow         
        //    30: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //    33: iload_2        
        //    34: ifne            101
        //    37: ifeq            97
        //    40: goto            47
        //    43: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    46: athrow         
        //    47: new             Ljava/io/IOException;
        //    50: dup            
        //    51: new             Ljava/lang/StringBuilder;
        //    54: dup            
        //    55: invokespecial   java/lang/StringBuilder.<init>:()V
        //    58: sipush          2763
        //    61: sipush          6526
        //    64: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    67: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    70: aload_0        
        //    71: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //    74: sipush          2767
        //    77: sipush          -21381
        //    80: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    83: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    86: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    89: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //    92: athrow         
        //    93: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    96: athrow         
        //    97: aload_0        
        //    98: invokestatic    q/o/m/s/q.en:(Ljava/io/File;)Z
        //   101: ifne            282
        //   104: new             Ljava/io/IOException;
        //   107: dup            
        //   108: new             Ljava/lang/StringBuilder;
        //   111: dup            
        //   112: invokespecial   java/lang/StringBuilder.<init>:()V
        //   115: sipush          2763
        //   118: sipush          6526
        //   121: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   124: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   127: aload_0        
        //   128: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   131: sipush          2787
        //   134: sipush          -661
        //   137: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   140: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   143: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   146: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   149: athrow         
        //   150: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   153: athrow         
        //   154: aload_0        
        //   155: invokestatic    q/o/m/s/q.ep:(Ljava/io/File;)Ljava/io/File;
        //   158: astore_3       
        //   159: aload_3        
        //   160: iload_2        
        //   161: ifne            30
        //   164: iload_2        
        //   165: ifne            190
        //   168: iload_2        
        //   169: ifne            190
        //   172: goto            179
        //   175: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   178: athrow         
        //   179: ifnull          282
        //   182: goto            189
        //   185: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   188: athrow         
        //   189: aload_3        
        //   190: invokestatic    q/o/m/s/q.ey:(Ljava/io/File;)Z
        //   193: iload_2        
        //   194: ifne            229
        //   197: iload_2        
        //   198: ifne            229
        //   201: goto            208
        //   204: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   207: athrow         
        //   208: ifne            282
        //   211: goto            218
        //   214: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   217: athrow         
        //   218: aload_3        
        //   219: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //   222: goto            229
        //   225: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   228: athrow         
        //   229: ifne            282
        //   232: new             Ljava/io/IOException;
        //   235: dup            
        //   236: new             Ljava/lang/StringBuilder;
        //   239: dup            
        //   240: invokespecial   java/lang/StringBuilder.<init>:()V
        //   243: sipush          2781
        //   246: sipush          31479
        //   249: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   252: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   255: aload_3        
        //   256: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   259: sipush          2737
        //   262: sipush          -26138
        //   265: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   268: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   271: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   274: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   277: athrow         
        //   278: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   281: athrow         
        //   282: new             Ljava/io/FileOutputStream;
        //   285: dup            
        //   286: aload_0        
        //   287: iload_1        
        //   288: invokespecial   java/io/FileOutputStream.<init>:(Ljava/io/File;Z)V
        //   291: areturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 19 FF 00 12 00 03 07 00 3F 01 01 00 01 07 00 60 03 43 07 00 60 43 07 00 3F 4C 07 00 60 03 6D 07 00 60 03 43 01 70 07 00 60 03 43 07 00 3F FF 00 10 00 04 07 00 3F 01 01 07 00 3F 00 01 07 00 60 43 07 00 3F 45 07 00 60 03 40 07 00 3F 4D 07 00 60 43 01 45 07 00 60 03 46 07 00 60 43 01 70 07 00 60 FA 00 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      15     18     22     Ljava/io/IOException;
        //  9      23     26     30     Ljava/io/IOException;
        //  30     40     43     47     Ljava/io/IOException;
        //  37     93     93     97     Ljava/io/IOException;
        //  101    150    150    154    Ljava/io/IOException;
        //  164    172    175    179    Ljava/io/IOException;
        //  168    182    185    189    Ljava/io/IOException;
        //  190    201    204    208    Ljava/io/IOException;
        //  197    211    214    218    Ljava/io/IOException;
        //  208    222    225    229    Ljava/io/IOException;
        //  229    278    278    282    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0208:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static String byteCountToDisplaySize(final BigInteger bigInteger) {
        final int c = IOCase.c();
        String s2 = null;
        while (true) {
            Label_0437: {
                Label_0387: {
                    int n4 = 0;
                    Label_0367: {
                        Label_0313: {
                            int ex = 0;
                            Label_0293: {
                                Label_0239: {
                                    int n3 = 0;
                                    Label_0219: {
                                        Label_0165: {
                                            int n2 = 0;
                                            Label_0145: {
                                                Label_0091: {
                                                    int n = 0;
                                                    Label_0071: {
                                                        try {
                                                            n = (n2 = (n3 = (ex = (n4 = q.ex(q.ec(bigInteger, FileUtils.ONE_EB_BI), x.dn.g.b.q.e())))));
                                                            if (c == 0) {
                                                                break Label_0091;
                                                            }
                                                            if (n <= 0) {
                                                                break Label_0071;
                                                            }
                                                        }
                                                        catch (NullPointerException ex2) {
                                                            throw b(ex2);
                                                        }
                                                        final String s = q.s(q.r(q.r(new StringBuilder(), q.eh(q.ec(bigInteger, FileUtils.ONE_EB_BI))), a(2809, -4134)));
                                                        try {
                                                            if (c != 0) {
                                                                return s;
                                                            }
                                                            n3 = (n2 = (ex = (n4 = q.ex(q.ec(bigInteger, FileUtils.ONE_PB_BI), x.dn.g.b.q.e()))));
                                                        }
                                                        catch (NullPointerException ex3) {
                                                            throw b(ex3);
                                                        }
                                                    }
                                                    try {
                                                        if (c == 0) {
                                                            break Label_0165;
                                                        }
                                                        if (n <= 0) {
                                                            break Label_0145;
                                                        }
                                                    }
                                                    catch (NullPointerException ex4) {
                                                        throw b(ex4);
                                                    }
                                                }
                                                final String s = q.s(q.r(q.r(new StringBuilder(), q.eh(q.ec(bigInteger, FileUtils.ONE_PB_BI))), a(2805, -24862)));
                                                try {
                                                    if (c != 0) {
                                                        return s;
                                                    }
                                                    n3 = (n2 = (ex = (n4 = q.ex(q.ec(bigInteger, FileUtils.ONE_TB_BI), x.dn.g.b.q.e()))));
                                                }
                                                catch (NullPointerException ex5) {
                                                    throw b(ex5);
                                                }
                                            }
                                            try {
                                                if (c == 0) {
                                                    break Label_0239;
                                                }
                                                if (n2 <= 0) {
                                                    break Label_0219;
                                                }
                                            }
                                            catch (NullPointerException ex6) {
                                                throw b(ex6);
                                            }
                                        }
                                        final String s = q.s(q.r(q.r(new StringBuilder(), q.eh(q.ec(bigInteger, FileUtils.ONE_TB_BI))), a(2771, 29968)));
                                        try {
                                            if (c != 0) {
                                                return s;
                                            }
                                            ex = (n3 = (n4 = q.ex(q.ec(bigInteger, FileUtils.ONE_GB_BI), x.dn.g.b.q.e())));
                                        }
                                        catch (NullPointerException ex7) {
                                            throw b(ex7);
                                        }
                                    }
                                    try {
                                        if (c == 0) {
                                            break Label_0313;
                                        }
                                        if (n3 <= 0) {
                                            break Label_0293;
                                        }
                                    }
                                    catch (NullPointerException ex8) {
                                        throw b(ex8);
                                    }
                                }
                                final String s = q.s(q.r(q.r(new StringBuilder(), q.eh(q.ec(bigInteger, FileUtils.ONE_GB_BI))), a(2769, 8966)));
                                try {
                                    if (c != 0) {
                                        return s;
                                    }
                                    n4 = (ex = q.ex(q.ec(bigInteger, FileUtils.ONE_MB_BI), x.dn.g.b.q.e()));
                                }
                                catch (NullPointerException ex9) {
                                    throw b(ex9);
                                }
                            }
                            try {
                                if (c == 0) {
                                    break Label_0387;
                                }
                                if (ex <= 0) {
                                    break Label_0367;
                                }
                            }
                            catch (NullPointerException ex10) {
                                throw b(ex10);
                            }
                        }
                        final String s = q.s(q.r(q.r(new StringBuilder(), q.eh(q.ec(bigInteger, FileUtils.ONE_MB_BI))), a(2793, -4357)));
                        try {
                            if (c != 0) {
                                return s;
                            }
                            n4 = q.ex(q.ec(bigInteger, FileUtils.ONE_KB_BI), x.dn.g.b.q.e());
                        }
                        catch (NullPointerException ex11) {
                            throw b(ex11);
                        }
                    }
                    try {
                        if (n4 <= 0) {
                            break Label_0437;
                        }
                        q.s(q.r(q.r(new StringBuilder(), q.eh(q.ec(bigInteger, FileUtils.ONE_KB_BI))), a(2807, -17566)));
                    }
                    catch (NullPointerException ex12) {
                        throw b(ex12);
                    }
                }
                final String s = s2;
                if (c != 0) {
                    return s;
                }
            }
            s2 = q.s(q.r(q.r(new StringBuilder(), q.eh(bigInteger)), a(2785, 15780)));
            if (c == 0) {
                continue;
            }
            break;
        }
        return s2;
    }
    
    public static String byteCountToDisplaySize(final long n) {
        return byteCountToDisplaySize(q.ej(n));
    }
    
    public static void touch(final File file) throws IOException {
        final int b = IOCase.b();
        boolean kc = false;
        Label_0042: {
            while (true) {
                Label_0031: {
                    try {
                        kc = q.kc(file);
                        if (b != 0) {
                            break Label_0042;
                        }
                        if (kc) {
                            break Label_0031;
                        }
                    }
                    catch (IOException ex) {
                        throw b(ex);
                    }
                    final File file2 = file;
                    IOUtils.closeQuietly(openOutputStream(file2));
                }
                final File file2 = file;
                if (b != 0) {
                    continue;
                }
                break;
            }
            q.eg(file, q.tj());
        }
        final boolean b2 = kc;
        try {
            if (!b2) {
                throw new IOException(q.s(q.kx(q.r(new StringBuilder(), a(2791, 8456)), file)));
            }
        }
        catch (IOException ex2) {
            throw b(ex2);
        }
    }
    
    public static File[] convertFileCollectionToFileArray(final Collection<File> collection) {
        return (File[])q.ez(collection, new File[q.kr(collection)]);
    }
    
    private static void innerListFiles(final Collection<File> collection, final File file, final IOFileFilter ioFileFilter, final boolean b) {
        final File[] si = q.si(file, ioFileFilter);
        final int b2 = IOCase.b();
        File[] array = null;
        Label_0031: {
            try {
                array = si;
                if (b2 != 0) {
                    break Label_0031;
                }
                final int n = b2;
                if (n == 0) {
                    break Label_0031;
                }
                break Label_0031;
            }
            catch (NullPointerException ex) {
                throw b(ex);
            }
            try {
                final int n = b2;
                if (n != 0) {
                    break Label_0031;
                }
                if (array == null) {
                    return;
                }
            }
            catch (NullPointerException ex2) {
                throw b(ex2);
            }
        }
        final File[] array2 = array;
        final int length = array2.length;
        int i = 0;
        while (i < length) {
            final File file2 = array2[i];
            Label_0128: {
                try {
                    final boolean su = q.su(file2);
                    if (b2 != 0) {
                        break Label_0128;
                    }
                    if (!su) {
                        break Label_0128;
                    }
                }
                catch (NullPointerException ex3) {
                    throw b(ex3);
                }
                boolean kp = b;
            Label_0106_Outer:
                while (true) {
                    File file3 = null;
                    while (true) {
                        Label_0109: {
                            if (b2 != 0) {
                                break Label_0109;
                            }
                            Collection<File> collection2;
                            try {
                                if (!kp) {
                                    break Label_0109;
                                }
                                collection2 = collection;
                            }
                            catch (NullPointerException ex4) {
                                throw b(ex4);
                            }
                            q.kp(collection2, file3);
                        }
                        Collection<File> collection2 = collection;
                        file3 = file2;
                        if (b2 != 0) {
                            continue;
                        }
                        break;
                    }
                    try {
                        innerListFiles(collection, file3, ioFileFilter, b);
                        if (b2 != 0) {
                            kp = q.kp(collection, file2);
                            if (b2 != 0) {
                                continue Label_0106_Outer;
                            }
                        }
                    }
                    catch (NullPointerException ex5) {
                        throw b(ex5);
                    }
                    break;
                }
            }
            ++i;
            if (b2 != 0) {
                break;
            }
        }
    }
    
    public static Collection<File> listFiles(final File file, final IOFileFilter upEffectiveFileFilter, final IOFileFilter upEffectiveDirFilter) {
        validateListFilesParameters(file, upEffectiveFileFilter);
        final IOFileFilter setUpEffectiveFileFilter = setUpEffectiveFileFilter(upEffectiveFileFilter);
        final IOFileFilter setUpEffectiveDirFilter = setUpEffectiveDirFilter(upEffectiveDirFilter);
        final LinkedList<File> list = new LinkedList<File>();
        innerListFiles(list, file, FileFilterUtils.or(setUpEffectiveFileFilter, setUpEffectiveDirFilter), false);
        return list;
    }
    
    private static void validateListFilesParameters(final File file, final IOFileFilter ioFileFilter) {
        try {
            if (!q.su(file)) {
                throw new IllegalArgumentException(q.s(q.kx(q.r(new StringBuilder(), a(2794, 8939)), file)));
            }
        }
        catch (NullPointerException ex) {
            throw b(ex);
        }
        try {
            if (ioFileFilter == null) {
                throw new NullPointerException(a(2752, 26580));
            }
        }
        catch (NullPointerException ex2) {
            throw b(ex2);
        }
    }
    
    private static IOFileFilter setUpEffectiveFileFilter(final IOFileFilter ioFileFilter) {
        return FileFilterUtils.and(ioFileFilter, FileFilterUtils.notFileFilter(DirectoryFileFilter.INSTANCE));
    }
    
    private static IOFileFilter setUpEffectiveDirFilter(final IOFileFilter ioFileFilter) {
        final int b = IOCase.b();
        Label_0020: {
            IOFileFilter ioFileFilter2;
            try {
                ioFileFilter2 = ioFileFilter;
                if (b != 0) {
                    return ioFileFilter2;
                }
                final int n = b;
                if (n == 0) {
                    break Label_0020;
                }
                return ioFileFilter2;
            }
            catch (NullPointerException ex) {
                throw b(ex);
            }
            try {
                final int n = b;
                if (n != 0) {
                    return ioFileFilter2;
                }
                if (ioFileFilter != null) {
                    return FileFilterUtils.and(ioFileFilter, DirectoryFileFilter.INSTANCE);
                }
            }
            catch (NullPointerException ex2) {
                throw b(ex2);
            }
        }
        return FalseFileFilter.INSTANCE;
        ioFileFilter2 = FileFilterUtils.and(ioFileFilter, DirectoryFileFilter.INSTANCE);
        return ioFileFilter2;
    }
    
    public static Collection<File> listFilesAndDirs(final File file, final IOFileFilter upEffectiveFileFilter, final IOFileFilter upEffectiveDirFilter) {
        validateListFilesParameters(file, upEffectiveFileFilter);
        final IOFileFilter setUpEffectiveFileFilter = setUpEffectiveFileFilter(upEffectiveFileFilter);
        final int c = IOCase.c();
        final IOFileFilter setUpEffectiveDirFilter = setUpEffectiveDirFilter(upEffectiveDirFilter);
        final LinkedList<File> list = new LinkedList<File>();
        final int n = c;
        while (true) {
            Label_0086: {
                Label_0062: {
                    LinkedList<File> list2 = null;
                    Label_0048: {
                        try {
                            if (n == 0) {
                                break Label_0086;
                            }
                            final File file2 = file;
                            final boolean b = q.su(file2);
                            if (b) {
                                break Label_0048;
                            }
                            break Label_0062;
                        }
                        catch (NullPointerException ex) {
                            throw b(ex);
                        }
                        try {
                            final File file2 = file;
                            final boolean b = q.su(file2);
                            if (!b) {
                                break Label_0062;
                            }
                            list2 = list;
                        }
                        catch (NullPointerException ex2) {
                            throw b(ex2);
                        }
                    }
                    q.kp(list2, file);
                }
                innerListFiles(list, file, FileFilterUtils.or(setUpEffectiveFileFilter, setUpEffectiveDirFilter), true);
            }
            LinkedList<File> list2;
            final LinkedList<File> list3 = list2 = list;
            if (n != 0) {
                return list3;
            }
            continue;
        }
    }
    
    public static Iterator<File> iterateFiles(final File file, final IOFileFilter ioFileFilter, final IOFileFilter ioFileFilter2) {
        return (Iterator<File>)q.ed(listFiles(file, ioFileFilter, ioFileFilter2));
    }
    
    public static Iterator<File> iterateFilesAndDirs(final File file, final IOFileFilter ioFileFilter, final IOFileFilter ioFileFilter2) {
        return (Iterator<File>)q.ed(listFilesAndDirs(file, ioFileFilter, ioFileFilter2));
    }
    
    private static String[] toSuffixes(final String[] array) {
        final String[] array2 = new String[array.length];
        final int b = IOCase.b();
        int i = 0;
        final int n = b;
        String[] array3 = null;
        while (i < array.length) {
            try {
                array3 = array2;
                if (n != 0) {
                    return array3;
                }
                array3[i] = q.s(q.r(q.r(new StringBuilder(), n.d.a.d.q.g()), array[i]));
                ++i;
                if (n == 0) {
                    continue;
                }
            }
            catch (NullPointerException ex) {
                throw b(ex);
            }
            break;
        }
        return array3;
    }
    
    public static Collection<File> listFiles(final File file, final String[] array, final boolean b) {
        final int c = IOCase.c();
        IOFileFilter ioFileFilter2 = null;
        Label_0049: {
            SuffixFileFilter suffixFileFilter;
            while (true) {
                String[] suffixes = null;
                Label_0032: {
                    Label_0028: {
                        try {
                            suffixes = array;
                            if (c == 0) {
                                break Label_0032;
                            }
                            if (array != null) {
                                break Label_0028;
                            }
                        }
                        catch (NullPointerException ex) {
                            throw b(ex);
                        }
                        final IOFileFilter instance = TrueFileFilter.INSTANCE;
                        final IOFileFilter ioFileFilter = instance;
                        if (c != 0) {
                            break Label_0049;
                        }
                    }
                    suffixes = toSuffixes(array);
                }
                IOFileFilter instance;
                suffixFileFilter = (SuffixFileFilter)(instance = new SuffixFileFilter(suffixes));
                if (c == 0) {
                    continue;
                }
                break;
            }
            final IOFileFilter ioFileFilter = suffixFileFilter;
            try {
                ioFileFilter2 = ioFileFilter;
                if (b) {
                    final IOFileFilter ioFileFilter3 = TrueFileFilter.INSTANCE;
                    return listFiles(file, ioFileFilter2, ioFileFilter3);
                }
            }
            catch (NullPointerException ex2) {
                throw b(ex2);
            }
        }
        final IOFileFilter ioFileFilter3 = FalseFileFilter.INSTANCE;
        return listFiles(file, ioFileFilter2, ioFileFilter3);
    }
    
    public static Iterator<File> iterateFiles(final File file, final String[] array, final boolean b) {
        return (Iterator<File>)q.ed(listFiles(file, array, b));
    }
    
    public static boolean contentEquals(final File p0, final File p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //     7: istore_3       
        //     8: istore_2       
        //     9: iload_3        
        //    10: iload_2        
        //    11: ifeq            42
        //    14: aload_1        
        //    15: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //    18: if_icmpeq       37
        //    21: goto            28
        //    24: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    27: athrow         
        //    28: iconst_0       
        //    29: goto            36
        //    32: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    35: athrow         
        //    36: ireturn        
        //    37: iload_3        
        //    38: iload_2        
        //    39: ifeq            36
        //    42: iload_2        
        //    43: ifeq            70
        //    46: ifne            58
        //    49: goto            56
        //    52: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    55: athrow         
        //    56: iconst_1       
        //    57: ireturn        
        //    58: aload_0        
        //    59: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //    62: iload_2        
        //    63: ifeq            57
        //    66: iload_2        
        //    67: ifeq            102
        //    70: iload_2        
        //    71: ifeq            102
        //    74: goto            81
        //    77: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    80: athrow         
        //    81: ifne            116
        //    84: goto            91
        //    87: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    90: athrow         
        //    91: aload_1        
        //    92: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //    95: goto            102
        //    98: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   101: athrow         
        //   102: iload_2        
        //   103: ifeq            146
        //   106: ifeq            137
        //   109: goto            116
        //   112: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   115: athrow         
        //   116: new             Ljava/io/IOException;
        //   119: dup            
        //   120: sipush          2795
        //   123: sipush          -8995
        //   126: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   129: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   132: athrow         
        //   133: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   136: athrow         
        //   137: aload_0        
        //   138: invokestatic    q/o/m/s/q.eb:(Ljava/io/File;)J
        //   141: aload_1        
        //   142: invokestatic    q/o/m/s/q.eb:(Ljava/io/File;)J
        //   145: lcmp           
        //   146: iload_2        
        //   147: ifeq            177
        //   150: ifeq            162
        //   153: goto            160
        //   156: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   159: athrow         
        //   160: iconst_0       
        //   161: ireturn        
        //   162: aload_0        
        //   163: invokestatic    q/o/m/s/q.ew:(Ljava/io/File;)Ljava/io/File;
        //   166: aload_1        
        //   167: invokestatic    q/o/m/s/q.ew:(Ljava/io/File;)Ljava/io/File;
        //   170: invokestatic    q/o/m/s/q.ek:(Ljava/io/File;Ljava/lang/Object;)Z
        //   173: iload_2        
        //   174: ifeq            161
        //   177: iload_2        
        //   178: ifeq            192
        //   181: ifeq            193
        //   184: goto            191
        //   187: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   190: athrow         
        //   191: iconst_1       
        //   192: ireturn        
        //   193: aconst_null    
        //   194: astore          4
        //   196: aconst_null    
        //   197: astore          5
        //   199: new             Ljava/io/FileInputStream;
        //   202: dup            
        //   203: aload_0        
        //   204: invokespecial   java/io/FileInputStream.<init>:(Ljava/io/File;)V
        //   207: astore          4
        //   209: new             Ljava/io/FileInputStream;
        //   212: dup            
        //   213: aload_1        
        //   214: invokespecial   java/io/FileInputStream.<init>:(Ljava/io/File;)V
        //   217: astore          5
        //   219: aload           4
        //   221: aload           5
        //   223: invokestatic    org/apache/commons/io/IOUtils.contentEquals:(Ljava/io/InputStream;Ljava/io/InputStream;)Z
        //   226: istore          6
        //   228: aload           4
        //   230: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/InputStream;)V
        //   233: aload           5
        //   235: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/InputStream;)V
        //   238: iload           6
        //   240: iload_2        
        //   241: ifeq            192
        //   244: ireturn        
        //   245: astore          7
        //   247: aload           4
        //   249: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/InputStream;)V
        //   252: aload           5
        //   254: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/InputStream;)V
        //   257: aload           7
        //   259: athrow         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 20 FF 00 18 00 04 07 00 3F 07 00 3F 01 01 00 01 07 00 60 03 43 07 00 60 43 01 00 44 01 49 07 00 60 03 40 01 00 4B 01 46 07 00 60 43 01 45 07 00 60 03 46 07 00 60 43 01 49 07 00 60 03 50 07 00 60 03 48 01 49 07 00 60 03 40 01 00 4E 01 49 07 00 60 03 40 01 00 FF 00 33 00 06 07 00 3F 07 00 3F 01 01 07 00 7F 07 00 7F 00 01 07 01 4F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  177    184    187    191    Ljava/io/IOException;
        //  146    153    156    160    Ljava/io/IOException;
        //  106    133    133    137    Ljava/io/IOException;
        //  102    109    112    116    Ljava/io/IOException;
        //  81     95     98     102    Ljava/io/IOException;
        //  70     84     87     91     Ljava/io/IOException;
        //  66     74     77     81     Ljava/io/IOException;
        //  42     49     52     56     Ljava/io/IOException;
        //  14     29     32     36     Ljava/io/IOException;
        //  9      21     24     28     Ljava/io/IOException;
        //  199    228    245    260    Any
        //  245    247    245    260    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0192 (coming from #0259).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static boolean contentEqualsIgnoreEOL(final File p0, final File p1, final String p2) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //     7: istore          4
        //     9: istore_3       
        //    10: iload           4
        //    12: iload_3        
        //    13: ifne            45
        //    16: aload_1        
        //    17: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //    20: if_icmpeq       39
        //    23: goto            30
        //    26: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    29: athrow         
        //    30: iconst_0       
        //    31: goto            38
        //    34: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    37: athrow         
        //    38: ireturn        
        //    39: iload           4
        //    41: iload_3        
        //    42: ifne            38
        //    45: iload_3        
        //    46: ifne            73
        //    49: ifne            61
        //    52: goto            59
        //    55: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    58: athrow         
        //    59: iconst_1       
        //    60: ireturn        
        //    61: aload_0        
        //    62: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //    65: iload_3        
        //    66: ifne            60
        //    69: iload_3        
        //    70: ifne            105
        //    73: iload_3        
        //    74: ifne            105
        //    77: goto            84
        //    80: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    83: athrow         
        //    84: ifne            119
        //    87: goto            94
        //    90: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    93: athrow         
        //    94: aload_1        
        //    95: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //    98: goto            105
        //   101: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   104: athrow         
        //   105: iload_3        
        //   106: ifne            155
        //   109: ifeq            140
        //   112: goto            119
        //   115: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   118: athrow         
        //   119: new             Ljava/io/IOException;
        //   122: dup            
        //   123: sipush          2795
        //   126: sipush          -8995
        //   129: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   132: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   135: athrow         
        //   136: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   139: athrow         
        //   140: aload_0        
        //   141: invokestatic    q/o/m/s/q.ew:(Ljava/io/File;)Ljava/io/File;
        //   144: aload_1        
        //   145: invokestatic    q/o/m/s/q.ew:(Ljava/io/File;)Ljava/io/File;
        //   148: invokestatic    q/o/m/s/q.ek:(Ljava/io/File;Ljava/lang/Object;)Z
        //   151: iload_3        
        //   152: ifne            177
        //   155: iload_3        
        //   156: ifne            177
        //   159: goto            166
        //   162: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   165: athrow         
        //   166: ifeq            178
        //   169: goto            176
        //   172: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   175: athrow         
        //   176: iconst_1       
        //   177: ireturn        
        //   178: aconst_null    
        //   179: astore          5
        //   181: aconst_null    
        //   182: astore          6
        //   184: aload_2        
        //   185: ifnonnull       231
        //   188: new             Ljava/io/InputStreamReader;
        //   191: dup            
        //   192: new             Ljava/io/FileInputStream;
        //   195: dup            
        //   196: aload_0        
        //   197: invokespecial   java/io/FileInputStream.<init>:(Ljava/io/File;)V
        //   200: invokestatic    q/o/m/s/q.sx:()Ljava/nio/charset/Charset;
        //   203: invokespecial   java/io/InputStreamReader.<init>:(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V
        //   206: astore          5
        //   208: new             Ljava/io/InputStreamReader;
        //   211: dup            
        //   212: new             Ljava/io/FileInputStream;
        //   215: dup            
        //   216: aload_1        
        //   217: invokespecial   java/io/FileInputStream.<init>:(Ljava/io/File;)V
        //   220: invokestatic    q/o/m/s/q.sx:()Ljava/nio/charset/Charset;
        //   223: invokespecial   java/io/InputStreamReader.<init>:(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V
        //   226: astore          6
        //   228: goto            271
        //   231: new             Ljava/io/InputStreamReader;
        //   234: dup            
        //   235: new             Ljava/io/FileInputStream;
        //   238: dup            
        //   239: aload_0        
        //   240: invokespecial   java/io/FileInputStream.<init>:(Ljava/io/File;)V
        //   243: aload_2        
        //   244: invokespecial   java/io/InputStreamReader.<init>:(Ljava/io/InputStream;Ljava/lang/String;)V
        //   247: astore          5
        //   249: new             Ljava/io/InputStreamReader;
        //   252: dup            
        //   253: new             Ljava/io/FileInputStream;
        //   256: dup            
        //   257: aload_1        
        //   258: invokespecial   java/io/FileInputStream.<init>:(Ljava/io/File;)V
        //   261: aload_2        
        //   262: invokespecial   java/io/InputStreamReader.<init>:(Ljava/io/InputStream;Ljava/lang/String;)V
        //   265: iload_3        
        //   266: ifne            226
        //   269: astore          6
        //   271: aload           5
        //   273: aload           6
        //   275: invokestatic    org/apache/commons/io/IOUtils.contentEqualsIgnoreEOL:(Ljava/io/Reader;Ljava/io/Reader;)Z
        //   278: istore          7
        //   280: aload           5
        //   282: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/Reader;)V
        //   285: aload           6
        //   287: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/Reader;)V
        //   290: iload           7
        //   292: ireturn        
        //   293: astore          8
        //   295: aload           5
        //   297: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/Reader;)V
        //   300: aload           6
        //   302: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/Reader;)V
        //   305: aload           8
        //   307: athrow         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 20 FF 00 1A 00 05 07 00 3F 07 00 3F 07 00 4B 01 01 00 01 07 00 60 03 43 07 00 60 43 01 00 45 01 49 07 00 60 03 40 01 00 4B 01 46 07 00 60 43 01 45 07 00 60 03 46 07 00 60 43 01 49 07 00 60 03 50 07 00 60 03 4E 01 46 07 00 60 43 01 45 07 00 60 03 40 01 00 FF 00 2F 00 07 07 00 3F 07 00 3F 07 00 4B 01 01 07 01 53 05 00 01 07 01 53 FF 00 04 00 07 07 00 3F 07 00 3F 07 00 4B 01 01 05 05 00 00 FF 00 27 00 07 07 00 3F 07 00 3F 07 00 4B 01 01 07 01 53 07 01 53 00 00 55 07 01 4F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  155    169    172    176    Ljava/io/IOException;
        //  140    159    162    166    Ljava/io/IOException;
        //  109    136    136    140    Ljava/io/IOException;
        //  105    112    115    119    Ljava/io/IOException;
        //  84     98     101    105    Ljava/io/IOException;
        //  73     87     90     94     Ljava/io/IOException;
        //  69     77     80     84     Ljava/io/IOException;
        //  45     52     55     59     Ljava/io/IOException;
        //  16     31     34     38     Ljava/io/IOException;
        //  10     23     26     30     Ljava/io/IOException;
        //  184    280    293    308    Any
        //  293    295    293    308    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0073:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static File toFile(final URL p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: ifnull          45
        //     8: sipush          2789
        //    11: sipush          3067
        //    14: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    17: iload_1        
        //    18: ifeq            63
        //    21: goto            28
        //    24: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    27: athrow         
        //    28: aload_0        
        //    29: invokestatic    q/o/m/s/q.ea:(Ljava/net/URL;)Ljava/lang/String;
        //    32: invokestatic    q/o/m/s/q.my:(Ljava/lang/String;Ljava/lang/String;)Z
        //    35: ifne            51
        //    38: goto            45
        //    41: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    44: athrow         
        //    45: aconst_null    
        //    46: areturn        
        //    47: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    50: athrow         
        //    51: aload_0        
        //    52: invokestatic    q/o/m/s/q.el:(Ljava/net/URL;)Ljava/lang/String;
        //    55: bipush          47
        //    57: invokestatic    x/dn/g/b/q.n:()C
        //    60: invokestatic    q/o/m/s/q.ei:(Ljava/lang/String;CC)Ljava/lang/String;
        //    63: astore_2       
        //    64: aload_2        
        //    65: invokestatic    org/apache/commons/io/FileUtils.decodeUrl:(Ljava/lang/String;)Ljava/lang/String;
        //    68: astore_2       
        //    69: new             Ljava/io/File;
        //    72: dup            
        //    73: aload_2        
        //    74: invokespecial   java/io/File.<init>:(Ljava/lang/String;)V
        //    77: areturn        
        //    StackMapTable: 00 07 FF 00 18 00 02 07 01 67 01 00 01 07 00 31 43 07 00 4B 4C 07 00 31 03 41 07 00 31 03 4B 07 00 4B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      21     24     28     Ljava/lang/NullPointerException;
        //  8      38     41     45     Ljava/lang/NullPointerException;
        //  28     47     47     51     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0028:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static String decodeUrl(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: astore_2       
        //     2: invokestatic    org/apache/commons/io/IOCase.c:()I
        //     5: istore_1       
        //     6: aload_0        
        //     7: iload_1        
        //     8: ifeq            404
        //    11: ifnull          395
        //    14: goto            21
        //    17: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    20: athrow         
        //    21: aload_0        
        //    22: iload_1        
        //    23: ifeq            404
        //    26: bipush          37
        //    28: invokestatic    q/o/m/s/q.eu:(Ljava/lang/String;I)I
        //    31: iflt            395
        //    34: aload_0        
        //    35: goto            42
        //    38: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    41: athrow         
        //    42: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //    45: istore_3       
        //    46: new             Ljava/lang/StringBuilder;
        //    49: dup            
        //    50: invokespecial   java/lang/StringBuilder.<init>:()V
        //    53: astore          4
        //    55: iload_3        
        //    56: invokestatic    q/o/m/s/q.nf:(I)Ljava/nio/ByteBuffer;
        //    59: astore          5
        //    61: iconst_0       
        //    62: istore          6
        //    64: iload           6
        //    66: iload_3        
        //    67: if_icmpge       389
        //    70: aload_0        
        //    71: iload_1        
        //    72: ifeq            394
        //    75: iload           6
        //    77: invokestatic    q/o/m/s/q.j:(Ljava/lang/String;I)C
        //    80: iload_1        
        //    81: ifeq            132
        //    84: goto            91
        //    87: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    90: athrow         
        //    91: iload_1        
        //    92: ifeq            132
        //    95: goto            102
        //    98: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   101: athrow         
        //   102: bipush          37
        //   104: if_icmpne       370
        //   107: goto            114
        //   110: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   113: athrow         
        //   114: aload_0        
        //   115: iload           6
        //   117: iconst_1       
        //   118: iadd           
        //   119: iload           6
        //   121: iconst_3       
        //   122: iadd           
        //   123: invokestatic    q/o/m/s/q.h:(Ljava/lang/String;II)Ljava/lang/String;
        //   126: bipush          16
        //   128: invokestatic    q/o/m/s/q.nm:(Ljava/lang/String;I)I
        //   131: i2b            
        //   132: istore          7
        //   134: aload           5
        //   136: iload           7
        //   138: invokestatic    q/o/m/s/q.nv:(Ljava/nio/ByteBuffer;B)Ljava/nio/ByteBuffer;
        //   141: pop            
        //   142: iinc            6, 3
        //   145: iload           6
        //   147: iload_3        
        //   148: if_icmpge       169
        //   151: aload_0        
        //   152: iload           6
        //   154: invokestatic    q/o/m/s/q.j:(Ljava/lang/String;I)C
        //   157: goto            164
        //   160: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   163: athrow         
        //   164: bipush          37
        //   166: if_icmpeq       114
        //   169: aload           5
        //   171: iload_1        
        //   172: ifeq            224
        //   175: invokestatic    q/o/m/s/q.no:(Ljava/nio/ByteBuffer;)I
        //   178: iload_1        
        //   179: ifeq            164
        //   182: goto            189
        //   185: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   188: athrow         
        //   189: iload_1        
        //   190: ifeq            66
        //   193: ifle            64
        //   196: aload           5
        //   198: invokestatic    q/o/m/s/q.nq:(Ljava/nio/ByteBuffer;)Ljava/nio/Buffer;
        //   201: pop            
        //   202: aload           4
        //   204: getstatic       org/apache/commons/io/Charsets.UTF_8:Ljava/nio/charset/Charset;
        //   207: aload           5
        //   209: invokestatic    q/o/m/s/q.nt:(Ljava/nio/charset/Charset;Ljava/nio/ByteBuffer;)Ljava/nio/CharBuffer;
        //   212: invokestatic    q/o/m/s/q.nr:(Ljava/nio/CharBuffer;)Ljava/lang/String;
        //   215: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   218: pop            
        //   219: aload           5
        //   221: invokestatic    q/o/m/s/q.ns:(Ljava/nio/ByteBuffer;)Ljava/nio/Buffer;
        //   224: pop            
        //   225: goto            64
        //   228: astore          7
        //   230: iload_1        
        //   231: ifeq            385
        //   234: aload           5
        //   236: iload_1        
        //   237: ifeq            295
        //   240: goto            247
        //   243: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   246: athrow         
        //   247: invokestatic    q/o/m/s/q.no:(Ljava/nio/ByteBuffer;)I
        //   250: ifle            370
        //   253: goto            260
        //   256: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   259: athrow         
        //   260: aload           5
        //   262: invokestatic    q/o/m/s/q.nq:(Ljava/nio/ByteBuffer;)Ljava/nio/Buffer;
        //   265: pop            
        //   266: aload           4
        //   268: getstatic       org/apache/commons/io/Charsets.UTF_8:Ljava/nio/charset/Charset;
        //   271: aload           5
        //   273: invokestatic    q/o/m/s/q.nt:(Ljava/nio/charset/Charset;Ljava/nio/ByteBuffer;)Ljava/nio/CharBuffer;
        //   276: invokestatic    q/o/m/s/q.nr:(Ljava/nio/CharBuffer;)Ljava/lang/String;
        //   279: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   282: pop            
        //   283: aload           5
        //   285: invokestatic    q/o/m/s/q.ns:(Ljava/nio/ByteBuffer;)Ljava/nio/Buffer;
        //   288: goto            295
        //   291: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   294: athrow         
        //   295: pop            
        //   296: goto            370
        //   299: astore          8
        //   301: aload           5
        //   303: iload_1        
        //   304: ifeq            366
        //   307: iload_1        
        //   308: ifeq            366
        //   311: goto            318
        //   314: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   317: athrow         
        //   318: invokestatic    q/o/m/s/q.no:(Ljava/nio/ByteBuffer;)I
        //   321: ifle            367
        //   324: goto            331
        //   327: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   330: athrow         
        //   331: aload           5
        //   333: invokestatic    q/o/m/s/q.nq:(Ljava/nio/ByteBuffer;)Ljava/nio/Buffer;
        //   336: pop            
        //   337: aload           4
        //   339: getstatic       org/apache/commons/io/Charsets.UTF_8:Ljava/nio/charset/Charset;
        //   342: aload           5
        //   344: invokestatic    q/o/m/s/q.nt:(Ljava/nio/charset/Charset;Ljava/nio/ByteBuffer;)Ljava/nio/CharBuffer;
        //   347: invokestatic    q/o/m/s/q.nr:(Ljava/nio/CharBuffer;)Ljava/lang/String;
        //   350: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   353: pop            
        //   354: aload           5
        //   356: invokestatic    q/o/m/s/q.ns:(Ljava/nio/ByteBuffer;)Ljava/nio/Buffer;
        //   359: goto            366
        //   362: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   365: athrow         
        //   366: pop            
        //   367: aload           8
        //   369: athrow         
        //   370: aload           4
        //   372: aload_0        
        //   373: iload           6
        //   375: iinc            6, 1
        //   378: invokestatic    q/o/m/s/q.j:(Ljava/lang/String;I)C
        //   381: invokestatic    q/o/m/s/q.sk:(Ljava/lang/StringBuilder;C)Ljava/lang/StringBuilder;
        //   384: pop            
        //   385: iload_1        
        //   386: ifne            64
        //   389: aload           4
        //   391: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   394: astore_2       
        //   395: aload_2        
        //   396: iload_1        
        //   397: ifeq            22
        //   400: iload_1        
        //   401: ifeq            42
        //   404: areturn        
        //    StackMapTable: 00 29 FF 00 11 00 03 07 00 4B 01 07 00 4B 00 01 07 01 7F 03 40 07 00 4B 4F 07 01 7F 43 07 00 4B FF 00 15 00 07 07 00 4B 01 07 00 4B 01 07 00 69 07 01 8D 01 00 00 41 01 54 07 01 7F 43 01 46 07 01 7F 43 01 47 07 01 7F 03 51 01 FF 00 1B 00 08 07 00 4B 01 07 00 4B 01 07 00 69 07 01 8D 01 01 00 01 07 01 7F 43 01 04 4F 07 01 7F 43 01 62 07 01 B7 FF 00 03 00 07 07 00 4B 01 07 00 4B 01 07 00 69 07 01 8D 01 00 01 07 01 7F FF 00 0E 00 08 07 00 4B 01 07 00 4B 01 07 00 69 07 01 8D 01 07 01 7F 00 01 07 01 7F 43 07 01 8D 48 07 01 7F 03 5E 07 01 7F 43 07 01 B7 FF 00 03 00 07 07 00 4B 01 07 00 4B 01 07 00 69 07 01 8D 01 00 01 07 01 4F FF 00 0E 00 09 07 00 4B 01 07 00 4B 01 07 00 69 07 01 8D 01 00 07 01 4F 00 01 07 01 7F 43 07 01 8D 48 07 01 7F 03 5E 07 01 7F 43 07 01 B7 00 F9 00 02 0E 03 44 07 00 4B FF 00 00 00 03 07 00 4B 01 07 00 4B 00 00 48 07 00 4B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  134    157    160    164    Ljava/lang/RuntimeException;
        //  91     107    110    114    Ljava/lang/RuntimeException;
        //  75     95     98     102    Ljava/lang/RuntimeException;
        //  70     84     87     91     Ljava/lang/RuntimeException;
        //  26     35     38     42     Ljava/lang/RuntimeException;
        //  6      14     17     21     Ljava/lang/RuntimeException;
        //  114    169    228    299    Ljava/lang/RuntimeException;
        //  114    169    299    370    Any
        //  169    182    185    189    Ljava/lang/RuntimeException;
        //  228    230    299    370    Any
        //  247    288    291    295    Ljava/lang/RuntimeException;
        //  234    253    256    260    Ljava/lang/RuntimeException;
        //  230    240    243    247    Ljava/lang/RuntimeException;
        //  299    301    299    370    Any
        //  301    311    314    318    Ljava/lang/RuntimeException;
        //  307    324    327    331    Ljava/lang/RuntimeException;
        //  318    359    362    366    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0066 (coming from #0369).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static File[] toFiles(final URL[] array) {
        final int b = IOCase.b();
        final File[] array3;
        Label_0046: {
            int length = 0;
            Label_0052: {
                Label_0050: {
                    Label_0031: {
                        Label_0020: {
                            try {
                                final URL[] array2 = array;
                                if (b != 0) {
                                    break Label_0031;
                                }
                                final int n = b;
                                if (n == 0) {
                                    break Label_0020;
                                }
                                break Label_0031;
                            }
                            catch (NullPointerException ex) {
                                throw b(ex);
                            }
                            try {
                                final int n = b;
                                if (n != 0) {
                                    break Label_0031;
                                }
                                if (array == null) {
                                    break Label_0046;
                                }
                            }
                            catch (NullPointerException ex2) {
                                throw b(ex2);
                            }
                        }
                        final URL[] array2 = array;
                        try {
                            length = array2.length;
                            if (b != 0) {
                                break Label_0052;
                            }
                            if (length != 0) {
                                break Label_0050;
                            }
                        }
                        catch (NullPointerException ex3) {
                            throw b(ex3);
                        }
                    }
                    break Label_0046;
                }
                final int length2 = array.length;
            }
            array3 = new File[length];
            if (b == 0) {
                final File[] array4 = array3;
                int i = 0;
                while (i < array.length) {
                    final URL url = array[i];
                    Label_0170: {
                        Label_0167: {
                            Label_0102: {
                                Label_0090: {
                                    try {
                                        if (b != 0) {
                                            break Label_0170;
                                        }
                                        final URL url3;
                                        final URL url2 = url3 = url;
                                        final int n2 = b;
                                        if (n2 == 0) {
                                            break Label_0090;
                                        }
                                        break Label_0102;
                                    }
                                    catch (NullPointerException ex4) {
                                        throw b(ex4);
                                    }
                                    try {
                                        final URL url3;
                                        final URL url2 = url3 = url;
                                        final int n2 = b;
                                        if (n2 != 0) {
                                            break Label_0102;
                                        }
                                        if (url3 == null) {
                                            break Label_0167;
                                        }
                                    }
                                    catch (NullPointerException ex5) {
                                        throw b(ex5);
                                    }
                                }
                                final URL url2 = url;
                                try {
                                    if (!q.th(q.ea(url2), a(2789, 3067))) {
                                        throw new IllegalArgumentException(q.s(q.kx(q.r(new StringBuilder(), a(2754, 24319)), url)));
                                    }
                                }
                                catch (NullPointerException ex6) {
                                    throw b(ex6);
                                }
                            }
                            array4[i] = toFile(url);
                        }
                        ++i;
                    }
                    if (b != 0) {
                        break;
                    }
                }
                return array4;
            }
            return array3;
        }
        final File[] empty_FILE_ARRAY = FileUtils.EMPTY_FILE_ARRAY;
        return array3;
    }
    
    public static URL[] toURLs(final File[] array) throws IOException {
        final URL[] array2 = new URL[array.length];
        final int b = IOCase.b();
        int i = 0;
        final int n = b;
        URL[] array3 = null;
        while (i < array2.length) {
            try {
                array3 = array2;
                if (n != 0) {
                    return array3;
                }
                array3[i] = q.ne(q.nk(array[i]));
                ++i;
                if (n == 0) {
                    continue;
                }
            }
            catch (IOException ex) {
                throw b(ex);
            }
            break;
        }
        return array3;
    }
    
    public static void copyFileToDirectory(final File file, final File file2) throws IOException {
        copyFileToDirectory(file, file2, true);
    }
    
    public static void copyFileToDirectory(final File file, final File parent, final boolean b) throws IOException {
        final int b2 = IOCase.b();
        while (true) {
            File file2 = null;
            Label_0138: {
                Label_0126: {
                    File file4 = null;
                    Label_0058: {
                        File file3 = null;
                        Label_0041: {
                            Label_0019: {
                                try {
                                    file2 = parent;
                                    file3 = parent;
                                    if (b2 != 0) {
                                        break Label_0041;
                                    }
                                    if (parent == null) {
                                        break Label_0019;
                                    }
                                    break Label_0019;
                                }
                                catch (IOException ex) {
                                    throw b(ex);
                                }
                                try {
                                    if (parent == null) {
                                        throw new NullPointerException(a(2773, 27064));
                                    }
                                }
                                catch (IOException ex2) {
                                    throw b(ex2);
                                }
                            }
                            file2 = parent;
                            file3 = parent;
                            try {
                                if (b2 != 0) {
                                    break Label_0138;
                                }
                                final boolean b3 = q.kc(file3);
                                if (b3) {
                                    break Label_0058;
                                }
                                break Label_0126;
                            }
                            catch (IOException ex3) {
                                throw b(ex3);
                            }
                        }
                        try {
                            final boolean b3 = q.kc(file3);
                            if (!b3) {
                                break Label_0126;
                            }
                            file2 = parent;
                            file4 = parent;
                        }
                        catch (IOException ex4) {
                            throw b(ex4);
                        }
                    }
                    if (b2 != 0) {
                        break Label_0138;
                    }
                    try {
                        if (!q.su(file4)) {
                            throw new IllegalArgumentException(q.s(q.r(q.kx(q.r(new StringBuilder(), a(2777, -14708)), parent), a(2753, -3610))));
                        }
                    }
                    catch (IOException ex5) {
                        throw b(ex5);
                    }
                }
                file2 = new File(parent, q.mh(file));
            }
            final File file5 = file2;
            file2 = file;
            File file4 = file;
            if (b2 == 0) {
                copyFile(file, file5, b);
                return;
            }
            continue;
        }
    }
    
    public static void copyFile(final File file, final File file2) throws IOException {
        copyFile(file, file2, true);
    }
    
    public static void copyFile(final File file, final File file2, final boolean b) throws IOException {
        final int c = IOCase.c();
        checkFileRequirements(file, file2);
        final int n = c;
        File ep = null;
        Label_0172: {
            Label_0099: {
                boolean b3 = false;
                Label_0077: {
                    Label_0027: {
                        boolean b2;
                        try {
                            b2 = (b3 = q.su(file));
                            if (n == 0) {
                                break Label_0099;
                            }
                            if (b2) {
                                break Label_0027;
                            }
                            break Label_0077;
                        }
                        catch (IOException ex) {
                            throw b(ex);
                        }
                        try {
                            if (b2) {
                                throw new IOException(q.s(q.r(q.kx(q.r(new StringBuilder(), a(2761, 655)), file), a(2767, -21381))));
                            }
                        }
                        catch (IOException ex2) {
                            throw b(ex2);
                        }
                    }
                    try {
                        ep = file;
                        if (n == 0) {
                            break Label_0172;
                        }
                        b3 = q.th(q.nn(file), q.nn(file2));
                    }
                    catch (IOException ex3) {
                        throw b(ex3);
                    }
                }
                try {
                    if (b3) {
                        throw new IOException(q.s(q.r(q.kx(q.r(q.kx(q.r(new StringBuilder(), a(2761, 655)), file), a(2768, 18439)), file2), a(2772, -6986))));
                    }
                }
                catch (IOException ex4) {
                    throw b(ex4);
                }
            }
            ep = q.ep(file2);
        }
        final File file3 = ep;
        File file6 = null;
        Label_0371: {
            boolean kc = false;
            Label_0302: {
                while (true) {
                    Label_0280: {
                        while (true) {
                            Label_0279: {
                                boolean ey = false;
                                Label_0190: {
                                    File file4;
                                    try {
                                        final File file5;
                                        file4 = (file5 = (file6 = file3));
                                        if (n == 0) {
                                            break Label_0280;
                                        }
                                        if (file4 != null) {
                                            break Label_0190;
                                        }
                                        break Label_0279;
                                    }
                                    catch (IOException ex5) {
                                        throw b(ex5);
                                    }
                                    try {
                                        if (file4 == null) {
                                            break Label_0279;
                                        }
                                        kc = (ey = q.ey(file3));
                                    }
                                    catch (IOException ex6) {
                                        throw b(ex6);
                                    }
                                }
                                if (n == 0) {
                                    break Label_0302;
                                }
                                boolean su;
                                try {
                                    if (ey) {
                                        break Label_0279;
                                    }
                                    kc = (su = q.su(file3));
                                }
                                catch (IOException ex7) {
                                    throw b(ex7);
                                }
                                if (n == 0) {
                                    break Label_0302;
                                }
                                try {
                                    if (!su) {
                                        throw new IOException(q.s(q.r(q.kx(q.r(new StringBuilder(), a(2777, -14708)), file3), a(2784, -28688))));
                                    }
                                }
                                catch (IOException ex8) {
                                    throw b(ex8);
                                }
                            }
                            file6 = file2;
                            File file5 = file2;
                            try {
                                if (n == 0) {
                                    break Label_0371;
                                }
                                final boolean ey;
                                final boolean su = ey = (kc = q.kc(file5));
                                if (n == 0) {
                                    continue;
                                }
                            }
                            catch (IOException ex9) {
                                throw b(ex9);
                            }
                            break;
                        }
                    }
                    if (n == 0) {
                        continue;
                    }
                    break;
                }
            }
            while (true) {
                Label_0366: {
                    if (!kc) {
                        break Label_0366;
                    }
                    file6 = file2;
                    final File file7 = file2;
                    if (n == 0) {
                        break Label_0371;
                    }
                    try {
                        if (!q.en(file7)) {
                            throw new IOException(q.s(q.r(q.kx(q.r(new StringBuilder(), a(2777, -14708)), file2), a(2780, -7809))));
                        }
                    }
                    catch (IOException ex10) {
                        throw b(ex10);
                    }
                }
                file6 = file;
                final File file7 = file;
                if (n == 0) {
                    continue;
                }
                break;
            }
        }
        doCopyFile(file6, file2, b);
    }
    
    public static long copyFile(final File file, final OutputStream outputStream) throws IOException {
        final FileInputStream fileInputStream = new FileInputStream(file);
        try {
            return IOUtils.copyLarge(fileInputStream, outputStream);
        }
        finally {
            q.np(fileInputStream);
        }
    }
    
    private static void doCopyFile(final File p0, final File p1, final boolean p2) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_3       
        //     4: aload_1        
        //     5: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //     8: iload_3        
        //     9: ifne            44
        //    12: iload_3        
        //    13: ifne            44
        //    16: goto            23
        //    19: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    22: athrow         
        //    23: ifeq            97
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    32: athrow         
        //    33: aload_1        
        //    34: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //    37: goto            44
        //    40: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    43: athrow         
        //    44: ifeq            97
        //    47: new             Ljava/io/IOException;
        //    50: dup            
        //    51: new             Ljava/lang/StringBuilder;
        //    54: dup            
        //    55: invokespecial   java/lang/StringBuilder.<init>:()V
        //    58: sipush          2777
        //    61: sipush          -14708
        //    64: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    67: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    70: aload_1        
        //    71: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //    74: sipush          2767
        //    77: sipush          -21381
        //    80: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    83: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    86: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    89: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //    92: athrow         
        //    93: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    96: athrow         
        //    97: aconst_null    
        //    98: astore          4
        //   100: aconst_null    
        //   101: astore          5
        //   103: aconst_null    
        //   104: astore          6
        //   106: aconst_null    
        //   107: astore          7
        //   109: new             Ljava/io/FileInputStream;
        //   112: dup            
        //   113: aload_0        
        //   114: invokespecial   java/io/FileInputStream.<init>:(Ljava/io/File;)V
        //   117: astore          4
        //   119: new             Ljava/io/FileOutputStream;
        //   122: dup            
        //   123: aload_1        
        //   124: invokespecial   java/io/FileOutputStream.<init>:(Ljava/io/File;)V
        //   127: astore          5
        //   129: aload           4
        //   131: invokestatic    q/o/m/s/q.ny:(Ljava/io/FileInputStream;)Ljava/nio/channels/FileChannel;
        //   134: astore          6
        //   136: aload           5
        //   138: invokestatic    q/o/m/s/q.nc:(Ljava/io/FileOutputStream;)Ljava/nio/channels/FileChannel;
        //   141: astore          7
        //   143: aload           6
        //   145: invokestatic    q/o/m/s/q.nx:(Ljava/nio/channels/FileChannel;)J
        //   148: lstore          8
        //   150: lconst_0       
        //   151: lstore          10
        //   153: lconst_0       
        //   154: lstore          12
        //   156: lload           10
        //   158: lload           8
        //   160: lcmp           
        //   161: ifge            283
        //   164: lload           8
        //   166: lload           10
        //   168: lsub           
        //   169: lstore          14
        //   171: lload           14
        //   173: iload_3        
        //   174: ifne            216
        //   177: iload_3        
        //   178: ifne            216
        //   181: goto            188
        //   184: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   187: athrow         
        //   188: ldc2_w          31457280
        //   191: lcmp           
        //   192: iload_3        
        //   193: ifne            284
        //   196: goto            203
        //   199: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   202: athrow         
        //   203: ifle            219
        //   206: goto            213
        //   209: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   212: athrow         
        //   213: ldc2_w          31457280
        //   216: goto            221
        //   219: lload           14
        //   221: lstore          12
        //   223: aload           7
        //   225: aload           6
        //   227: lload           10
        //   229: lload           12
        //   231: invokestatic    q/o/m/s/q.nh:(Ljava/nio/channels/FileChannel;Ljava/nio/channels/ReadableByteChannel;JJ)J
        //   234: lstore          16
        //   236: lload           16
        //   238: lconst_0       
        //   239: iload_3        
        //   240: ifne            276
        //   243: lcmp           
        //   244: ifne            265
        //   247: goto            254
        //   250: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   253: athrow         
        //   254: iload_3        
        //   255: ifeq            283
        //   258: goto            265
        //   261: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   264: athrow         
        //   265: lload           10
        //   267: lload           16
        //   269: goto            276
        //   272: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   275: athrow         
        //   276: ladd           
        //   277: lstore          10
        //   279: iload_3        
        //   280: ifeq            156
        //   283: iconst_4       
        //   284: anewarray       Ljava/io/Closeable;
        //   287: dup            
        //   288: iconst_0       
        //   289: aload           7
        //   291: aastore        
        //   292: dup            
        //   293: iconst_1       
        //   294: aload           5
        //   296: aastore        
        //   297: dup            
        //   298: iconst_2       
        //   299: aload           6
        //   301: aastore        
        //   302: dup            
        //   303: iconst_3       
        //   304: aload           4
        //   306: aastore        
        //   307: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:([Ljava/io/Closeable;)V
        //   310: goto            345
        //   313: astore          18
        //   315: iconst_4       
        //   316: anewarray       Ljava/io/Closeable;
        //   319: dup            
        //   320: iconst_0       
        //   321: aload           7
        //   323: aastore        
        //   324: dup            
        //   325: iconst_1       
        //   326: aload           5
        //   328: aastore        
        //   329: dup            
        //   330: iconst_2       
        //   331: aload           6
        //   333: aastore        
        //   334: dup            
        //   335: iconst_3       
        //   336: aload           4
        //   338: aastore        
        //   339: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:([Ljava/io/Closeable;)V
        //   342: aload           18
        //   344: athrow         
        //   345: aload_0        
        //   346: invokestatic    q/o/m/s/q.eb:(Ljava/io/File;)J
        //   349: lstore          8
        //   351: aload_1        
        //   352: invokestatic    q/o/m/s/q.eb:(Ljava/io/File;)J
        //   355: lstore          10
        //   357: lload           8
        //   359: lload           10
        //   361: lcmp           
        //   362: iload_3        
        //   363: ifne            469
        //   366: ifeq            464
        //   369: goto            376
        //   372: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   375: athrow         
        //   376: new             Ljava/io/IOException;
        //   379: dup            
        //   380: new             Ljava/lang/StringBuilder;
        //   383: dup            
        //   384: invokespecial   java/lang/StringBuilder.<init>:()V
        //   387: sipush          2738
        //   390: sipush          -29143
        //   393: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   396: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   399: aload_0        
        //   400: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   403: sipush          2811
        //   406: sipush          26022
        //   409: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   412: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   415: aload_1        
        //   416: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   419: sipush          2758
        //   422: sipush          6599
        //   425: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   428: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   431: lload           8
        //   433: invokestatic    q/o/m/s/q.es:(Ljava/lang/StringBuilder;J)Ljava/lang/StringBuilder;
        //   436: sipush          2814
        //   439: sipush          25072
        //   442: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   445: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   448: lload           10
        //   450: invokestatic    q/o/m/s/q.es:(Ljava/lang/StringBuilder;J)Ljava/lang/StringBuilder;
        //   453: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   456: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   459: athrow         
        //   460: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   463: athrow         
        //   464: iload_2        
        //   465: iload_3        
        //   466: ifne            505
        //   469: iload_3        
        //   470: ifne            505
        //   473: goto            480
        //   476: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   479: athrow         
        //   480: ifeq            506
        //   483: goto            490
        //   486: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   489: athrow         
        //   490: aload_1        
        //   491: aload_0        
        //   492: invokestatic    q/o/m/s/q.nj:(Ljava/io/File;)J
        //   495: invokestatic    q/o/m/s/q.eg:(Ljava/io/File;J)Z
        //   498: goto            505
        //   501: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   504: athrow         
        //   505: pop            
        //   506: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 28 FF 00 13 00 04 07 00 3F 07 00 3F 01 01 00 01 07 00 60 43 01 45 07 00 60 03 46 07 00 60 43 01 70 07 00 60 03 FF 00 3A 00 0B 07 00 3F 07 00 3F 01 01 07 00 7F 07 00 93 07 02 00 07 02 00 04 04 04 00 00 FF 00 1B 00 0C 07 00 3F 07 00 3F 01 01 07 00 7F 07 00 93 07 02 00 07 02 00 04 04 04 04 00 01 07 00 60 43 04 4A 07 00 60 43 01 45 07 00 60 03 42 04 02 41 04 FF 00 1C 00 0D 07 00 3F 07 00 3F 01 01 07 00 7F 07 00 93 07 02 00 07 02 00 04 04 04 04 04 00 01 07 00 60 03 46 07 00 60 03 46 07 00 60 FF 00 03 00 0D 07 00 3F 07 00 3F 01 01 07 00 7F 07 00 93 07 02 00 07 02 00 04 04 04 04 04 00 02 04 04 F9 00 06 40 01 FF 00 1C 00 08 07 00 3F 07 00 3F 01 01 07 00 7F 07 00 93 07 02 00 07 02 00 00 01 07 01 4F FE 00 1F 04 04 04 5A 07 00 60 03 F7 00 53 07 00 60 03 44 01 46 07 00 60 43 01 45 07 00 60 03 4A 07 00 60 43 01 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  254    269    272    276    Ljava/io/IOException;
        //  243    258    261    265    Ljava/io/IOException;
        //  236    247    250    254    Ljava/io/IOException;
        //  188    206    209    213    Ljava/io/IOException;
        //  177    196    199    203    Ljava/io/IOException;
        //  171    181    184    188    Ljava/io/IOException;
        //  44     93     93     97     Ljava/io/IOException;
        //  23     37     40     44     Ljava/io/IOException;
        //  12     26     29     33     Ljava/io/IOException;
        //  4      16     19     23     Ljava/io/IOException;
        //  109    283    313    345    Any
        //  313    315    313    345    Any
        //  357    369    372    376    Ljava/io/IOException;
        //  366    460    460    464    Ljava/io/IOException;
        //  464    473    476    480    Ljava/io/IOException;
        //  469    483    486    490    Ljava/io/IOException;
        //  480    498    501    505    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0023:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void copyDirectoryToDirectory(final File file, final File parent) throws IOException {
        final int c = IOCase.c();
        File file2 = null;
        Label_0257: {
            while (true) {
                Label_0252: {
                    File file7 = null;
                    Label_0184: {
                        File file3 = null;
                        Label_0167: {
                            Label_0145: {
                                File file4 = null;
                                Label_0131: {
                                    while (true) {
                                        Label_0126: {
                                            File file6 = null;
                                            Label_0058: {
                                                File file5 = null;
                                                Label_0041: {
                                                    Label_0019: {
                                                        try {
                                                            file2 = file;
                                                            file3 = file;
                                                            file4 = file;
                                                            file5 = file;
                                                            if (c == 0) {
                                                                break Label_0041;
                                                            }
                                                            if (file == null) {
                                                                break Label_0019;
                                                            }
                                                            break Label_0019;
                                                        }
                                                        catch (IOException ex) {
                                                            throw b(ex);
                                                        }
                                                        try {
                                                            if (file == null) {
                                                                throw new NullPointerException(a(2757, -31686));
                                                            }
                                                        }
                                                        catch (IOException ex2) {
                                                            throw b(ex2);
                                                        }
                                                    }
                                                    file2 = file;
                                                    file3 = file;
                                                    file4 = file;
                                                    file5 = file;
                                                    try {
                                                        if (c == 0) {
                                                            break Label_0131;
                                                        }
                                                        final boolean b = q.kc(file5);
                                                        if (b) {
                                                            break Label_0058;
                                                        }
                                                        break Label_0126;
                                                    }
                                                    catch (IOException ex3) {
                                                        throw b(ex3);
                                                    }
                                                }
                                                try {
                                                    final boolean b = q.kc(file5);
                                                    if (!b) {
                                                        break Label_0126;
                                                    }
                                                    file2 = file;
                                                    file3 = file;
                                                    file4 = file;
                                                    file6 = file;
                                                }
                                                catch (IOException ex4) {
                                                    throw b(ex4);
                                                }
                                            }
                                            if (c == 0) {
                                                break Label_0131;
                                            }
                                            try {
                                                if (!q.su(file6)) {
                                                    throw new IllegalArgumentException(q.s(q.r(q.kx(q.r(new StringBuilder(), a(2761, 655)), parent), a(2753, -3610))));
                                                }
                                            }
                                            catch (IOException ex5) {
                                                throw b(ex5);
                                            }
                                        }
                                        file2 = parent;
                                        file3 = parent;
                                        file4 = parent;
                                        File file6 = parent;
                                        if (c == 0) {
                                            continue;
                                        }
                                        break;
                                    }
                                    try {
                                        if (c == 0) {
                                            break Label_0167;
                                        }
                                        if (file4 == null) {
                                            break Label_0145;
                                        }
                                        break Label_0145;
                                    }
                                    catch (IOException ex6) {
                                        throw b(ex6);
                                    }
                                }
                                try {
                                    if (file4 == null) {
                                        throw new NullPointerException(a(2773, 27064));
                                    }
                                }
                                catch (IOException ex7) {
                                    throw b(ex7);
                                }
                            }
                            file2 = parent;
                            file3 = parent;
                            try {
                                if (c == 0) {
                                    break Label_0257;
                                }
                                final boolean b2 = q.kc(file3);
                                if (b2) {
                                    break Label_0184;
                                }
                                break Label_0252;
                            }
                            catch (IOException ex8) {
                                throw b(ex8);
                            }
                        }
                        try {
                            final boolean b2 = q.kc(file3);
                            if (!b2) {
                                break Label_0252;
                            }
                            file2 = parent;
                            file7 = parent;
                        }
                        catch (IOException ex9) {
                            throw b(ex9);
                        }
                    }
                    if (c == 0) {
                        break Label_0257;
                    }
                    try {
                        if (!q.su(file7)) {
                            throw new IllegalArgumentException(q.s(q.r(q.kx(q.r(new StringBuilder(), a(2777, -14708)), parent), a(2753, -3610))));
                        }
                    }
                    catch (IOException ex10) {
                        throw b(ex10);
                    }
                }
                file2 = file;
                File file7 = file;
                if (c == 0) {
                    continue;
                }
                break;
            }
        }
        copyDirectory(file2, new File(parent, q.mh(file)), true);
    }
    
    public static void copyDirectory(final File file, final File file2) throws IOException {
        copyDirectory(file, file2, true);
    }
    
    public static void copyDirectory(final File file, final File file2, final boolean b) throws IOException {
        copyDirectory(file, file2, null, b);
    }
    
    public static void copyDirectory(final File file, final File file2, final FileFilter fileFilter) throws IOException {
        copyDirectory(file, file2, fileFilter, true);
    }
    
    public static void copyDirectory(final File file, final File parent, final FileFilter fileFilter, final boolean b) throws IOException {
        final int b2 = IOCase.b();
        checkFileRequirements(file, parent);
        final int n = b2;
        Label_0090: {
            Label_0029: {
                boolean b3;
                try {
                    final boolean b4;
                    b3 = (b4 = q.su(file));
                    if (n != 0) {
                        break Label_0090;
                    }
                    if (!b3) {
                        break Label_0029;
                    }
                    break Label_0029;
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                try {
                    if (!b3) {
                        throw new IOException(q.s(q.r(q.kx(q.r(new StringBuilder(), a(2761, 655)), file), a(2764, 16406))));
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            boolean b4 = q.th(q.nn(file), q.nn(parent));
            try {
                if (b4) {
                    throw new IOException(q.s(q.r(q.kx(q.r(q.kx(q.r(new StringBuilder(), a(2761, 655)), file), a(2768, 18439)), parent), a(2772, -6986))));
                }
            }
            catch (IOException ex3) {
                throw b(ex3);
            }
        }
        ArrayList list = null;
        Label_0332: {
            File[] array = null;
            Label_0211: {
                while (true) {
                    Label_0201: {
                        File file2 = null;
                        Label_0187: {
                            try {
                                if (!q.t(q.nn(parent), q.nn(file))) {
                                    break Label_0332;
                                }
                                final FileFilter fileFilter2 = fileFilter;
                                if (fileFilter2 == null) {
                                    break Label_0187;
                                }
                                break Label_0201;
                            }
                            catch (IOException ex4) {
                                throw b(ex4);
                            }
                            try {
                                final FileFilter fileFilter2 = fileFilter;
                                if (fileFilter2 != null) {
                                    break Label_0201;
                                }
                                file2 = file;
                            }
                            catch (IOException ex5) {
                                throw b(ex5);
                            }
                        }
                        array = q.sl(file2);
                        break Label_0211;
                    }
                    File file2 = file;
                    if (n != 0) {
                        continue;
                    }
                    break;
                }
                array = q.si(file, fileFilter);
            }
            final File[] array2 = array;
            File[] array3 = null;
            Label_0232: {
                try {
                    array3 = array2;
                    if (n != 0) {
                        break Label_0232;
                    }
                    final int n2 = n;
                    if (n2 == 0) {
                        break Label_0232;
                    }
                    break Label_0232;
                }
                catch (IOException ex6) {
                    throw b(ex6);
                }
                try {
                    final int n2 = n;
                    if (n2 != 0) {
                        break Label_0232;
                    }
                    if (array3 == null) {
                        break Label_0332;
                    }
                }
                catch (IOException ex7) {
                    throw b(ex7);
                }
            }
            if (array3.length > 0) {
                list = new ArrayList<String>(array2.length);
                final File[] array4 = array2;
                final int length = array4.length;
                int i = 0;
                while (i < length) {
                    final File file3 = new File(parent, q.mh(array4[i]));
                    try {
                        q.qw(list, q.nn(file3));
                        ++i;
                        if (n != 0) {
                            return;
                        }
                        if (n == 0) {
                            continue;
                        }
                    }
                    catch (IOException ex8) {
                        throw b(ex8);
                    }
                    break;
                }
            }
        }
        doCopyDirectory(file, parent, fileFilter, b, (List<String>)list);
    }
    
    private static void checkFileRequirements(final File file, final File file2) throws FileNotFoundException {
        final int b = IOCase.b();
        Label_0077: {
            Label_0055: {
                File file4 = null;
                Label_0041: {
                    Label_0019: {
                        try {
                            final File file3 = file;
                            file4 = file;
                            if (b != 0) {
                                break Label_0041;
                            }
                            if (file == null) {
                                break Label_0019;
                            }
                            break Label_0019;
                        }
                        catch (FileNotFoundException ex) {
                            throw b(ex);
                        }
                        try {
                            if (file == null) {
                                throw new NullPointerException(a(2757, -31686));
                            }
                        }
                        catch (FileNotFoundException ex2) {
                            throw b(ex2);
                        }
                    }
                    final File file3 = file2;
                    file4 = file2;
                    try {
                        if (b != 0) {
                            break Label_0077;
                        }
                        if (file4 == null) {
                            break Label_0055;
                        }
                        break Label_0055;
                    }
                    catch (FileNotFoundException ex3) {
                        throw b(ex3);
                    }
                }
                try {
                    if (file4 == null) {
                        throw new NullPointerException(a(2773, 27064));
                    }
                }
                catch (FileNotFoundException ex4) {
                    throw b(ex4);
                }
            }
            final File file3 = file;
            try {
                if (!q.kc(file3)) {
                    throw new FileNotFoundException(q.s(q.r(q.kx(q.r(new StringBuilder(), a(2761, 655)), file), a(2739, -14564))));
                }
            }
            catch (FileNotFoundException ex5) {
                throw b(ex5);
            }
        }
    }
    
    private static void doCopyDirectory(final File p0, final File p1, final FileFilter p2, final boolean p3, final List<String> p4) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore          5
        //     5: aload_2        
        //     6: ifnonnull       23
        //     9: aload_0        
        //    10: goto            17
        //    13: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    16: athrow         
        //    17: invokestatic    q/o/m/s/q.sl:(Ljava/io/File;)[Ljava/io/File;
        //    20: goto            33
        //    23: aload_0        
        //    24: iload           5
        //    26: ifeq            17
        //    29: aload_2        
        //    30: invokestatic    q/o/m/s/q.si:(Ljava/io/File;Ljava/io/FileFilter;)[Ljava/io/File;
        //    33: astore          6
        //    35: aload           6
        //    37: ifnonnull       78
        //    40: new             Ljava/io/IOException;
        //    43: dup            
        //    44: new             Ljava/lang/StringBuilder;
        //    47: dup            
        //    48: invokespecial   java/lang/StringBuilder.<init>:()V
        //    51: sipush          2765
        //    54: sipush          -30463
        //    57: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    60: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    63: aload_0        
        //    64: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //    67: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    70: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //    73: athrow         
        //    74: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    77: athrow         
        //    78: aload_1        
        //    79: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //    82: iload           5
        //    84: ifeq            182
        //    87: ifeq            173
        //    90: goto            97
        //    93: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    96: athrow         
        //    97: aload_1        
        //    98: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //   101: goto            108
        //   104: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   107: athrow         
        //   108: iload           5
        //   110: ifeq            278
        //   113: ifne            269
        //   116: goto            123
        //   119: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   122: athrow         
        //   123: new             Ljava/io/IOException;
        //   126: dup            
        //   127: new             Ljava/lang/StringBuilder;
        //   130: dup            
        //   131: invokespecial   java/lang/StringBuilder.<init>:()V
        //   134: sipush          2777
        //   137: sipush          -14708
        //   140: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   143: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   146: aload_1        
        //   147: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   150: sipush          2764
        //   153: sipush          16406
        //   156: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   159: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   162: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   165: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   168: athrow         
        //   169: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   172: athrow         
        //   173: aload_1        
        //   174: invokestatic    q/o/m/s/q.ey:(Ljava/io/File;)Z
        //   177: iload           5
        //   179: ifeq            108
        //   182: iload           5
        //   184: ifeq            278
        //   187: ifne            269
        //   190: goto            197
        //   193: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   196: athrow         
        //   197: aload_1        
        //   198: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //   201: goto            208
        //   204: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   207: athrow         
        //   208: iload           5
        //   210: ifeq            278
        //   213: ifne            269
        //   216: goto            223
        //   219: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   222: athrow         
        //   223: new             Ljava/io/IOException;
        //   226: dup            
        //   227: new             Ljava/lang/StringBuilder;
        //   230: dup            
        //   231: invokespecial   java/lang/StringBuilder.<init>:()V
        //   234: sipush          2777
        //   237: sipush          -14708
        //   240: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   243: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   246: aload_1        
        //   247: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   250: sipush          2784
        //   253: sipush          -28688
        //   256: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   259: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   262: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   265: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   268: athrow         
        //   269: aload_1        
        //   270: invokestatic    q/o/m/s/q.en:(Ljava/io/File;)Z
        //   273: iload           5
        //   275: ifeq            208
        //   278: ifne            331
        //   281: new             Ljava/io/IOException;
        //   284: dup            
        //   285: new             Ljava/lang/StringBuilder;
        //   288: dup            
        //   289: invokespecial   java/lang/StringBuilder.<init>:()V
        //   292: sipush          2777
        //   295: sipush          -14708
        //   298: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   301: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   304: aload_1        
        //   305: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   308: sipush          2787
        //   311: sipush          -661
        //   314: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   317: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   320: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   323: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   326: athrow         
        //   327: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   330: athrow         
        //   331: aload           6
        //   333: astore          7
        //   335: aload           7
        //   337: arraylength    
        //   338: istore          8
        //   340: iconst_0       
        //   341: istore          9
        //   343: iload           9
        //   345: iload           8
        //   347: if_icmpge       507
        //   350: aload           7
        //   352: iload           9
        //   354: aaload         
        //   355: astore          10
        //   357: new             Ljava/io/File;
        //   360: dup            
        //   361: aload_1        
        //   362: aload           10
        //   364: invokestatic    q/o/m/s/q.mh:(Ljava/io/File;)Ljava/lang/String;
        //   367: invokespecial   java/io/File.<init>:(Ljava/io/File;Ljava/lang/String;)V
        //   370: astore          11
        //   372: iload           5
        //   374: ifeq            551
        //   377: aload           4
        //   379: iload           5
        //   381: ifeq            403
        //   384: goto            391
        //   387: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   390: athrow         
        //   391: ifnull          431
        //   394: goto            401
        //   397: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   400: athrow         
        //   401: aload           4
        //   403: aload           10
        //   405: invokestatic    q/o/m/s/q.nn:(Ljava/io/File;)Ljava/lang/String;
        //   408: invokestatic    q/o/m/s/q.ng:(Ljava/util/List;Ljava/lang/Object;)Z
        //   411: iload           5
        //   413: ifeq            460
        //   416: iload           5
        //   418: ifeq            460
        //   421: ifne            499
        //   424: goto            431
        //   427: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   430: athrow         
        //   431: aload           10
        //   433: iload           5
        //   435: ifeq            488
        //   438: goto            445
        //   441: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   444: athrow         
        //   445: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //   448: iload           5
        //   450: ifeq            411
        //   453: goto            460
        //   456: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   459: athrow         
        //   460: ifeq            486
        //   463: aload           10
        //   465: aload           11
        //   467: goto            474
        //   470: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   473: athrow         
        //   474: aload_2        
        //   475: iload_3        
        //   476: aload           4
        //   478: invokestatic    org/apache/commons/io/FileUtils.doCopyDirectory:(Ljava/io/File;Ljava/io/File;Ljava/io/FileFilter;ZLjava/util/List;)V
        //   481: iload           5
        //   483: ifne            499
        //   486: aload           10
        //   488: aload           11
        //   490: iload           5
        //   492: ifeq            474
        //   495: iload_3        
        //   496: invokestatic    org/apache/commons/io/FileUtils.doCopyFile:(Ljava/io/File;Ljava/io/File;Z)V
        //   499: iinc            9, 1
        //   502: iload           5
        //   504: ifne            343
        //   507: iload_3        
        //   508: iload           5
        //   510: ifeq            550
        //   513: iload           5
        //   515: ifeq            550
        //   518: goto            525
        //   521: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   524: athrow         
        //   525: ifeq            551
        //   528: goto            535
        //   531: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   534: athrow         
        //   535: aload_1        
        //   536: aload_0        
        //   537: invokestatic    q/o/m/s/q.nj:(Ljava/io/File;)J
        //   540: invokestatic    q/o/m/s/q.eg:(Ljava/io/File;J)Z
        //   543: goto            550
        //   546: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   549: athrow         
        //   550: pop            
        //   551: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    Signature:
        //  (Ljava/io/File;Ljava/io/File;Ljava/io/FileFilter;ZLjava/util/List<Ljava/lang/String;>;)V
        //    StackMapTable: 00 33 FF 00 0D 00 06 07 00 3F 07 00 3F 07 02 1A 01 07 02 31 01 00 01 07 00 60 43 07 00 3F 05 49 07 00 DC FF 00 28 00 07 07 00 3F 07 00 3F 07 02 1A 01 07 02 31 01 07 00 DC 00 01 07 00 60 03 4E 07 00 60 03 46 07 00 60 43 01 4A 07 00 60 03 6D 07 00 60 03 48 01 4A 07 00 60 03 46 07 00 60 43 01 4A 07 00 60 03 2D 48 01 70 07 00 60 03 FE 00 0B 07 00 DC 01 01 FF 00 2B 00 0C 07 00 3F 07 00 3F 07 02 1A 01 07 02 31 01 07 00 DC 07 00 DC 01 01 07 00 3F 07 00 3F 00 01 07 00 60 43 07 02 31 45 07 00 60 03 41 07 02 31 47 01 4F 07 00 60 03 49 07 00 60 43 07 00 3F 4A 07 00 60 43 01 49 07 00 60 FF 00 03 00 0C 07 00 3F 07 00 3F 07 02 1A 01 07 02 31 01 07 00 DC 07 00 DC 01 01 07 00 3F 07 00 3F 00 02 07 00 3F 07 00 3F 0B 41 07 00 3F 0A F9 00 07 4D 07 00 60 43 01 45 07 00 60 03 4A 07 00 60 43 01 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  5      10     13     17     Ljava/io/IOException;
        //  35     74     74     78     Ljava/io/IOException;
        //  78     90     93     97     Ljava/io/IOException;
        //  87     101    104    108    Ljava/io/IOException;
        //  108    116    119    123    Ljava/io/IOException;
        //  113    169    169    173    Ljava/io/IOException;
        //  182    190    193    197    Ljava/io/IOException;
        //  187    201    204    208    Ljava/io/IOException;
        //  208    216    219    223    Ljava/io/IOException;
        //  278    327    327    331    Ljava/io/IOException;
        //  372    384    387    391    Ljava/io/IOException;
        //  377    394    397    401    Ljava/io/IOException;
        //  416    424    427    431    Ljava/io/IOException;
        //  421    438    441    445    Ljava/io/IOException;
        //  431    453    456    460    Ljava/io/IOException;
        //  460    467    470    474    Ljava/io/IOException;
        //  507    518    521    525    Ljava/io/IOException;
        //  513    528    531    535    Ljava/io/IOException;
        //  525    543    546    550    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0431:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void copyURLToFile(final URL url, final File file) throws IOException {
        copyInputStreamToFile(q.nz(url), file);
    }
    
    public static void copyURLToFile(final URL url, final File file, final int n, final int n2) throws IOException {
        final URLConnection nd = q.nd(url);
        q.nb(nd, n);
        q.nw(nd, n2);
        copyInputStreamToFile(q.na(nd), file);
    }
    
    public static void copyInputStreamToFile(final InputStream inputStream, final File file) throws IOException {
        try {
            copyToFile(inputStream, file);
        }
        finally {
            IOUtils.closeQuietly(inputStream);
        }
    }
    
    public static void copyToFile(final InputStream inputStream, final File file) throws IOException {
        final FileOutputStream openOutputStream = openOutputStream(file);
        try {
            IOUtils.copy(inputStream, openOutputStream);
            q.nl(openOutputStream);
        }
        finally {
            IOUtils.closeQuietly(openOutputStream);
        }
    }
    
    public static void deleteDirectory(final File file) throws IOException {
        final int c = IOCase.c();
        boolean b2 = false;
        Label_0053: {
            while (true) {
                Label_0045: {
                    Label_0027: {
                        boolean b = false;
                        Label_0023: {
                            try {
                                b = (b2 = q.kc(file));
                                if (c == 0) {
                                    break Label_0027;
                                }
                                if (b) {
                                    break Label_0023;
                                }
                            }
                            catch (IOException ex) {
                                throw b(ex);
                            }
                            return;
                        }
                        final boolean symlink;
                        b2 = (symlink = isSymlink(file));
                        try {
                            if (c == 0) {
                                break Label_0053;
                            }
                            if (b) {
                                break Label_0045;
                            }
                        }
                        catch (IOException ex2) {
                            throw b(ex2);
                        }
                    }
                    final File file2 = file;
                    cleanDirectory(file2);
                }
                final File file2 = file;
                if (c == 0) {
                    continue;
                }
                break;
            }
            b2 = q.kh(file);
        }
        if (!b2) {
            throw new IOException(q.s(q.r(q.kx(q.r(new StringBuilder(), a(2788, 16769)), file), n.d.a.d.q.g())));
        }
    }
    
    public static boolean deleteQuietly(final File p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: iload_1        
        //     6: ifne            26
        //     9: ifnonnull       21
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: iconst_0       
        //    20: ireturn        
        //    21: aload_0        
        //    22: iload_1        
        //    23: ifne            55
        //    26: iload_1        
        //    27: ifne            55
        //    30: goto            37
        //    33: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    36: athrow         
        //    37: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //    40: iload_1        
        //    41: ifne            20
        //    44: goto            51
        //    47: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    50: athrow         
        //    51: ifeq            58
        //    54: aload_0        
        //    55: invokestatic    org/apache/commons/io/FileUtils.cleanDirectory:(Ljava/io/File;)V
        //    58: goto            62
        //    61: astore_2       
        //    62: aload_0        
        //    63: invokestatic    q/o/m/s/q.kh:(Ljava/io/File;)Z
        //    66: ireturn        
        //    67: astore_2       
        //    68: iconst_0       
        //    69: ireturn        
        //    StackMapTable: 00 0E FF 00 0F 00 02 07 00 3F 01 00 01 07 02 68 03 40 01 00 44 07 00 3F 46 07 02 68 43 07 00 3F 49 07 02 68 43 01 43 07 00 3F 02 42 07 02 68 00 44 07 02 68
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  26     44     47     51     Ljava/lang/Exception;
        //  21     30     33     37     Ljava/lang/Exception;
        //  4      12     15     19     Ljava/lang/Exception;
        //  21     58     61     62     Ljava/lang/Exception;
        //  62     66     67     70     Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0026:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static boolean directoryContains(final File p0, final File p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: iload_2        
        //     6: ifeq            41
        //     9: ifnonnull       40
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: new             Ljava/lang/IllegalArgumentException;
        //    22: dup            
        //    23: sipush          2812
        //    26: sipush          -9960
        //    29: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    32: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //    35: athrow         
        //    36: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    39: athrow         
        //    40: aload_0        
        //    41: iload_2        
        //    42: ifeq            97
        //    45: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //    48: ifne            96
        //    51: goto            58
        //    54: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    57: athrow         
        //    58: new             Ljava/lang/IllegalArgumentException;
        //    61: dup            
        //    62: new             Ljava/lang/StringBuilder;
        //    65: dup            
        //    66: invokespecial   java/lang/StringBuilder.<init>:()V
        //    69: sipush          2802
        //    72: sipush          14786
        //    75: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    78: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    81: aload_0        
        //    82: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //    85: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    88: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //    91: athrow         
        //    92: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    95: athrow         
        //    96: aload_1        
        //    97: iload_2        
        //    98: ifeq            114
        //   101: ifnonnull       113
        //   104: goto            111
        //   107: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   110: athrow         
        //   111: iconst_0       
        //   112: ireturn        
        //   113: aload_0        
        //   114: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //   117: iload_2        
        //   118: ifeq            112
        //   121: iload_2        
        //   122: ifeq            165
        //   125: ifeq            160
        //   128: goto            135
        //   131: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   134: athrow         
        //   135: aload_1        
        //   136: iload_2        
        //   137: ifeq            167
        //   140: goto            147
        //   143: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   146: athrow         
        //   147: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //   150: goto            157
        //   153: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   156: athrow         
        //   157: ifne            166
        //   160: iconst_0       
        //   161: iload_2        
        //   162: ifeq            157
        //   165: ireturn        
        //   166: aload_0        
        //   167: invokestatic    q/o/m/s/q.nn:(Ljava/io/File;)Ljava/lang/String;
        //   170: astore_3       
        //   171: aload_1        
        //   172: invokestatic    q/o/m/s/q.nn:(Ljava/io/File;)Ljava/lang/String;
        //   175: astore          4
        //   177: aload_3        
        //   178: aload           4
        //   180: invokestatic    org/apache/commons/io/FilenameUtils.directoryContains:(Ljava/lang/String;Ljava/lang/String;)Z
        //   183: iload_2        
        //   184: ifeq            165
        //   187: ireturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 19 FF 00 0F 00 03 07 00 3F 07 00 3F 01 00 01 07 00 60 03 50 07 00 60 03 40 07 00 3F 4C 07 00 60 03 61 07 00 60 03 40 07 00 3F 49 07 00 60 03 40 01 00 40 07 00 3F 50 07 00 60 03 47 07 00 60 43 07 00 3F 45 07 00 60 43 01 02 44 01 00 40 07 00 3F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      12     15     19     Ljava/io/IOException;
        //  9      36     36     40     Ljava/io/IOException;
        //  41     51     54     58     Ljava/io/IOException;
        //  45     92     92     96     Ljava/io/IOException;
        //  97     104    107    111    Ljava/io/IOException;
        //  121    128    131    135    Ljava/io/IOException;
        //  125    140    143    147    Ljava/io/IOException;
        //  135    150    153    157    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0135:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void cleanDirectory(final File file) throws IOException {
        final File[] verifiedListFiles = verifiedListFiles(file);
        final int c = IOCase.c();
        IOException ex = null;
        final int n = c;
        final File[] array = verifiedListFiles;
        final int length = array.length;
        int i = 0;
        while (i < length) {
            final File file2 = array[i];
            Label_0057: {
                try {
                    try {
                        forceDelete(file2);
                        if (n != 0) {
                            break Label_0057;
                        }
                        return;
                    }
                    catch (NullPointerException ex2) {
                        throw b(ex2);
                    }
                }
                catch (IOException ex3) {
                    ex = ex3;
                }
            }
            ++i;
            if (n == 0) {
                break;
            }
        }
        try {
            if (null != ex) {
                throw ex;
            }
        }
        catch (IOException ex4) {
            throw b(ex4);
        }
    }
    
    private static File[] verifiedListFiles(final File file) throws IOException {
        final int b = IOCase.b();
        File file2 = null;
        Label_0113: {
            boolean kc = false;
            Label_0058: {
                try {
                    kc = q.kc(file);
                    if (b != 0) {
                        break Label_0058;
                    }
                    if (kc) {
                        break Label_0058;
                    }
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                throw new IllegalArgumentException(q.s(q.r(q.kx(new StringBuilder(), file), a(2815, -22419))));
                try {
                    file2 = file;
                    if (b != 0) {
                        break Label_0113;
                    }
                    q.su(file);
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            if (!kc) {
                throw new IllegalArgumentException(q.s(q.r(q.kx(new StringBuilder(), file), a(2797, 13282))));
            }
            file2 = file;
        }
        final File[] sl = q.sl(file2);
        Label_0132: {
            File[] array;
            try {
                final File[] array2;
                array = (array2 = sl);
                if (b != 0) {
                    return array2;
                }
                if (array == null) {
                    break Label_0132;
                }
                return sl;
            }
            catch (IOException ex3) {
                throw b(ex3);
            }
            try {
                if (array == null) {
                    throw new IOException(q.s(q.kx(q.r(new StringBuilder(), a(2765, -30463)), file)));
                }
            }
            catch (IOException ex4) {
                throw b(ex4);
            }
        }
        return sl;
    }
    
    public static boolean waitFor(final File p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: invokestatic    q/o/m/s/q.tj:()J
        //     6: iload_1        
        //     7: i2l            
        //     8: ldc2_w          1000
        //    11: lmul           
        //    12: ladd           
        //    13: lstore_3       
        //    14: iconst_0       
        //    15: istore          5
        //    17: istore_2       
        //    18: aload_0        
        //    19: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //    22: ifne            146
        //    25: lload_3        
        //    26: invokestatic    q/o/m/s/q.tj:()J
        //    29: lsub           
        //    30: lstore          6
        //    32: lload           6
        //    34: lconst_0       
        //    35: iload_2        
        //    36: ifeq            112
        //    39: lcmp           
        //    40: iload_2        
        //    41: ifeq            148
        //    44: goto            51
        //    47: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    50: athrow         
        //    51: iload_2        
        //    52: ifeq            73
        //    55: goto            62
        //    58: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    61: athrow         
        //    62: ifge            107
        //    65: goto            72
        //    68: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    71: athrow         
        //    72: iconst_0       
        //    73: istore          8
        //    75: iload           5
        //    77: iload_2        
        //    78: ifeq            106
        //    81: ifeq            104
        //    84: goto            91
        //    87: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    90: athrow         
        //    91: invokestatic    q/o/m/s/q.ni:()Ljava/lang/Thread;
        //    94: invokestatic    q/o/m/s/q.ky:(Ljava/lang/Thread;)V
        //    97: goto            104
        //   100: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   103: athrow         
        //   104: iload           8
        //   106: ireturn        
        //   107: ldc2_w          100
        //   110: lload           6
        //   112: invokestatic    q/o/m/s/q.nu:(JJ)J
        //   115: invokestatic    q/o/m/s/q.mt:(J)V
        //   118: goto            135
        //   121: astore          8
        //   123: iconst_1       
        //   124: istore          5
        //   126: goto            135
        //   129: astore          8
        //   131: iload_2        
        //   132: ifne            146
        //   135: iload_2        
        //   136: ifne            18
        //   139: goto            146
        //   142: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   145: athrow         
        //   146: iload           5
        //   148: iload_2        
        //   149: ifeq            199
        //   152: ifeq            198
        //   155: goto            162
        //   158: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   161: athrow         
        //   162: invokestatic    q/o/m/s/q.ni:()Ljava/lang/Thread;
        //   165: invokestatic    q/o/m/s/q.ky:(Ljava/lang/Thread;)V
        //   168: goto            198
        //   171: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   174: athrow         
        //   175: astore          9
        //   177: iload           5
        //   179: ifeq            195
        //   182: invokestatic    q/o/m/s/q.ni:()Ljava/lang/Thread;
        //   185: invokestatic    q/o/m/s/q.ky:(Ljava/lang/Thread;)V
        //   188: goto            195
        //   191: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   194: athrow         
        //   195: aload           9
        //   197: athrow         
        //   198: iconst_1       
        //   199: ireturn        
        //    StackMapTable: 00 1D FE 00 12 01 04 01 FF 00 1C 00 06 07 00 3F 01 01 04 01 04 00 01 07 02 77 43 01 46 07 02 77 43 01 45 07 02 77 03 40 01 FF 00 0D 00 07 07 00 3F 01 01 04 01 04 01 00 01 07 02 77 03 48 07 02 77 03 41 01 FA 00 00 FF 00 04 00 06 07 00 3F 01 01 04 01 04 00 02 04 04 48 07 02 77 47 07 02 68 05 46 07 02 77 FA 00 03 41 01 49 07 02 77 03 48 07 02 77 43 07 01 4F FF 00 0F 00 09 07 00 3F 01 01 04 01 00 00 00 07 01 4F 00 01 07 02 77 03 FF 00 02 00 05 07 00 3F 01 01 04 01 00 00 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  51     65     68     72     Ljava/lang/InterruptedException;
        //  39     55     58     62     Ljava/lang/InterruptedException;
        //  32     44     47     51     Ljava/lang/InterruptedException;
        //  107    118    121    129    Ljava/lang/InterruptedException;
        //  107    118    129    135    Ljava/lang/Exception;
        //  18     75     175    198    Any
        //  131    139    142    146    Ljava/lang/InterruptedException;
        //  81     97     100    104    Ljava/lang/InterruptedException;
        //  75     84     87     91     Ljava/lang/InterruptedException;
        //  107    146    175    198    Any
        //  152    171    171    175    Ljava/lang/InterruptedException;
        //  148    155    158    162    Ljava/lang/InterruptedException;
        //  175    177    175    198    Any
        //  177    188    191    195    Ljava/lang/InterruptedException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:577)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static String readFileToString(final File file, final Charset charset) throws IOException {
        InputStream openInputStream = null;
        try {
            openInputStream = openInputStream(file);
            return IOUtils.toString(openInputStream, Charsets.toCharset(charset));
        }
        finally {
            IOUtils.closeQuietly(openInputStream);
        }
    }
    
    public static String readFileToString(final File file, final String s) throws IOException {
        return readFileToString(file, Charsets.toCharset(s));
    }
    
    @Deprecated
    public static String readFileToString(final File file) throws IOException {
        return readFileToString(file, q.sx());
    }
    
    public static byte[] readFileToByteArray(final File file) throws IOException {
        InputStream openInputStream = null;
        try {
            openInputStream = openInputStream(file);
            return IOUtils.toByteArray(openInputStream);
        }
        finally {
            IOUtils.closeQuietly(openInputStream);
        }
    }
    
    public static List<String> readLines(final File file, final Charset charset) throws IOException {
        InputStream openInputStream = null;
        try {
            openInputStream = openInputStream(file);
            return IOUtils.readLines(openInputStream, Charsets.toCharset(charset));
        }
        finally {
            IOUtils.closeQuietly(openInputStream);
        }
    }
    
    public static List<String> readLines(final File file, final String s) throws IOException {
        return readLines(file, Charsets.toCharset(s));
    }
    
    @Deprecated
    public static List<String> readLines(final File file) throws IOException {
        return readLines(file, q.sx());
    }
    
    public static LineIterator lineIterator(final File file, final String s) throws IOException {
        InputStream openInputStream = null;
        try {
            openInputStream = openInputStream(file);
            return IOUtils.lineIterator(openInputStream, s);
        }
        catch (IOException ex) {
            IOUtils.closeQuietly(openInputStream);
            throw ex;
        }
        catch (RuntimeException ex2) {
            IOUtils.closeQuietly(openInputStream);
            throw ex2;
        }
    }
    
    public static LineIterator lineIterator(final File file) throws IOException {
        return lineIterator(file, null);
    }
    
    public static void writeStringToFile(final File file, final String s, final Charset charset) throws IOException {
        writeStringToFile(file, s, charset, false);
    }
    
    public static void writeStringToFile(final File file, final String s, final String s2) throws IOException {
        writeStringToFile(file, s, s2, false);
    }
    
    public static void writeStringToFile(final File file, final String s, final Charset charset, final boolean b) throws IOException {
        OutputStream openOutputStream = null;
        try {
            openOutputStream = openOutputStream(file, b);
            IOUtils.write(s, openOutputStream, charset);
            q.pf(openOutputStream);
        }
        finally {
            IOUtils.closeQuietly(openOutputStream);
        }
    }
    
    public static void writeStringToFile(final File file, final String s, final String s2, final boolean b) throws IOException {
        writeStringToFile(file, s, Charsets.toCharset(s2), b);
    }
    
    @Deprecated
    public static void writeStringToFile(final File file, final String s) throws IOException {
        writeStringToFile(file, s, q.sx(), false);
    }
    
    @Deprecated
    public static void writeStringToFile(final File file, final String s, final boolean b) throws IOException {
        writeStringToFile(file, s, q.sx(), b);
    }
    
    @Deprecated
    public static void write(final File file, final CharSequence charSequence) throws IOException {
        write(file, charSequence, q.sx(), false);
    }
    
    @Deprecated
    public static void write(final File file, final CharSequence charSequence, final boolean b) throws IOException {
        write(file, charSequence, q.sx(), b);
    }
    
    public static void write(final File file, final CharSequence charSequence, final Charset charset) throws IOException {
        write(file, charSequence, charset, false);
    }
    
    public static void write(final File file, final CharSequence charSequence, final String s) throws IOException {
        write(file, charSequence, s, false);
    }
    
    public static void write(final File file, final CharSequence charSequence, final Charset charset, final boolean b) throws IOException {
        final int b2 = IOCase.b();
        String pm = null;
        Label_0033: {
            CharSequence charSequence2 = null;
            Label_0030: {
                Label_0021: {
                    try {
                        charSequence2 = charSequence;
                        if (b2 != 0) {
                            break Label_0030;
                        }
                        if (charSequence == null) {
                            break Label_0021;
                        }
                        break Label_0021;
                    }
                    catch (IOException ex) {
                        throw b(ex);
                    }
                    try {
                        if (charSequence == null) {
                            pm = null;
                            break Label_0033;
                        }
                    }
                    catch (IOException ex2) {
                        throw b(ex2);
                    }
                }
                charSequence2 = charSequence;
            }
            pm = q.pm(charSequence2);
        }
        writeStringToFile(file, pm, charset, b);
    }
    
    public static void write(final File file, final CharSequence charSequence, final String s, final boolean b) throws IOException {
        write(file, charSequence, Charsets.toCharset(s), b);
    }
    
    public static void writeByteArrayToFile(final File file, final byte[] array) throws IOException {
        writeByteArrayToFile(file, array, false);
    }
    
    public static void writeByteArrayToFile(final File file, final byte[] array, final boolean b) throws IOException {
        writeByteArrayToFile(file, array, 0, array.length, b);
    }
    
    public static void writeByteArrayToFile(final File file, final byte[] array, final int n, final int n2) throws IOException {
        writeByteArrayToFile(file, array, n, n2, false);
    }
    
    public static void writeByteArrayToFile(final File file, final byte[] array, final int n, final int n2, final boolean b) throws IOException {
        OutputStream openOutputStream = null;
        try {
            openOutputStream = openOutputStream(file, b);
            q.sz(openOutputStream, array, n, n2);
            q.pf(openOutputStream);
        }
        finally {
            IOUtils.closeQuietly(openOutputStream);
        }
    }
    
    public static void writeLines(final File file, final String s, final Collection<?> collection) throws IOException {
        writeLines(file, s, collection, null, false);
    }
    
    public static void writeLines(final File file, final String s, final Collection<?> collection, final boolean b) throws IOException {
        writeLines(file, s, collection, null, b);
    }
    
    public static void writeLines(final File file, final Collection<?> collection) throws IOException {
        writeLines(file, null, collection, null, false);
    }
    
    public static void writeLines(final File file, final Collection<?> collection, final boolean b) throws IOException {
        writeLines(file, null, collection, null, b);
    }
    
    public static void writeLines(final File file, final String s, final Collection<?> collection, final String s2) throws IOException {
        writeLines(file, s, collection, s2, false);
    }
    
    public static void writeLines(final File file, final String s, final Collection<?> collection, final String s2, final boolean b) throws IOException {
        OutputStream openOutputStream = null;
        try {
            openOutputStream = openOutputStream(file, b);
            final BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(openOutputStream);
            IOUtils.writeLines(collection, s2, bufferedOutputStream, s);
            q.pv(bufferedOutputStream);
            q.nl((FileOutputStream)openOutputStream);
        }
        finally {
            IOUtils.closeQuietly(openOutputStream);
        }
    }
    
    public static void writeLines(final File file, final Collection<?> collection, final String s) throws IOException {
        writeLines(file, null, collection, s, false);
    }
    
    public static void writeLines(final File file, final Collection<?> collection, final String s, final boolean b) throws IOException {
        writeLines(file, null, collection, s, b);
    }
    
    public static void forceDelete(final File file) throws IOException {
        final int c = IOCase.c();
        while (true) {
            boolean su = false;
            Label_0034: {
                Label_0030: {
                    try {
                        su = q.su(file);
                        if (c == 0) {
                            break Label_0034;
                        }
                        if (!su) {
                            break Label_0030;
                        }
                    }
                    catch (IOException ex) {
                        throw b(ex);
                    }
                    final File file2 = file;
                    deleteDirectory(file2);
                    if (c != 0) {
                        return;
                    }
                }
                q.kc(file);
            }
            final int n = su ? 1 : 0;
            final File file2 = file;
            if (c != 0) {
                Label_0069: {
                    boolean kh = false;
                    Label_0058: {
                        try {
                            kh = q.kh(file);
                            if (c == 0) {
                                break Label_0069;
                            }
                            final int n2 = c;
                            if (n2 != 0) {
                                break Label_0058;
                            }
                            break Label_0069;
                        }
                        catch (IOException ex2) {
                            throw b(ex2);
                        }
                        try {
                            final int n2 = c;
                            if (n2 == 0) {
                                break Label_0069;
                            }
                            if (kh) {
                                return;
                            }
                        }
                        catch (IOException ex3) {
                            throw b(ex3);
                        }
                    }
                    try {
                        if (!kh) {
                            throw new FileNotFoundException(q.s(q.kx(q.r(new StringBuilder(), a(2770, -19561)), file)));
                        }
                    }
                    catch (IOException ex4) {
                        throw b(ex4);
                    }
                }
                throw new IOException(q.s(q.kx(q.r(new StringBuilder(), a(2774, 24011)), file)));
            }
            continue;
        }
    }
    
    public static void forceDeleteOnExit(final File file) throws IOException {
        final int b = IOCase.b();
        File file2 = null;
        Label_0042: {
            while (true) {
                Label_0037: {
                    File file3 = null;
                    Label_0022: {
                        try {
                            file2 = file;
                            if (b != 0) {
                                break Label_0042;
                            }
                            final boolean b2 = q.su(file);
                            if (b2) {
                                break Label_0022;
                            }
                            break Label_0037;
                        }
                        catch (IOException ex) {
                            throw b(ex);
                        }
                        try {
                            final boolean b2 = q.su(file);
                            if (!b2) {
                                break Label_0037;
                            }
                            file3 = file;
                        }
                        catch (IOException ex2) {
                            throw b(ex2);
                        }
                    }
                    deleteDirectoryOnExit(file3);
                    if (b == 0) {
                        return;
                    }
                }
                file2 = file;
                File file3 = file;
                if (b != 0) {
                    continue;
                }
                break;
            }
        }
        q.po(file2);
    }
    
    private static void deleteDirectoryOnExit(final File file) throws IOException {
        final int c = IOCase.c();
        File file2 = null;
        Label_0057: {
            boolean kc = false;
            Label_0043: {
                Label_0023: {
                    try {
                        kc = q.kc(file);
                        if (c == 0) {
                            break Label_0043;
                        }
                        if (kc) {
                            break Label_0023;
                        }
                    }
                    catch (IOException ex) {
                        throw b(ex);
                    }
                    return;
                    try {
                        q.po(file);
                        file2 = file;
                        if (c == 0) {
                            break Label_0057;
                        }
                        final int n = c;
                        if (n != 0) {
                            break Label_0043;
                        }
                        break Label_0057;
                    }
                    catch (IOException ex2) {
                        throw b(ex2);
                    }
                }
                try {
                    final int n = c;
                    if (n == 0) {
                        break Label_0057;
                    }
                    isSymlink(file);
                }
                catch (IOException ex3) {
                    throw b(ex3);
                }
            }
            if (kc) {
                return;
            }
            file2 = file;
        }
        cleanDirectoryOnExit(file2);
    }
    
    private static void cleanDirectoryOnExit(final File file) throws IOException {
        final File[] verifiedListFiles = verifiedListFiles(file);
        final int c = IOCase.c();
        IOException ex = null;
        final File[] array = verifiedListFiles;
        final int n = c;
        final int length = array.length;
        int i = 0;
        while (i < length) {
            final File file2 = array[i];
            Label_0057: {
                try {
                    try {
                        forceDeleteOnExit(file2);
                        if (n != 0) {
                            break Label_0057;
                        }
                        return;
                    }
                    catch (NullPointerException ex2) {
                        throw b(ex2);
                    }
                }
                catch (IOException ex3) {
                    ex = ex3;
                }
            }
            ++i;
            if (n == 0) {
                break;
            }
        }
        try {
            if (null != ex) {
                throw ex;
            }
        }
        catch (IOException ex4) {
            throw b(ex4);
        }
    }
    
    public static void forceMkdir(final File p0) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //     8: iload_1        
        //     9: ifne            108
        //    12: ifeq            96
        //    15: goto            22
        //    18: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    21: athrow         
        //    22: aload_0        
        //    23: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    32: athrow         
        //    33: ifne            179
        //    36: new             Ljava/lang/StringBuilder;
        //    39: dup            
        //    40: invokespecial   java/lang/StringBuilder.<init>:()V
        //    43: sipush          2786
        //    46: sipush          30005
        //    49: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    52: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    55: aload_0        
        //    56: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //    59: sipush          2810
        //    62: sipush          -14059
        //    65: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    68: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    71: sipush          2766
        //    74: sipush          -23158
        //    77: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    80: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    83: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    86: astore_2       
        //    87: new             Ljava/io/IOException;
        //    90: dup            
        //    91: aload_2        
        //    92: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //    95: athrow         
        //    96: aload_0        
        //    97: invokestatic    q/o/m/s/q.ey:(Ljava/io/File;)Z
        //   100: iload_1        
        //   101: ifne            33
        //   104: iload_1        
        //   105: ifne            140
        //   108: iload_1        
        //   109: ifne            140
        //   112: goto            119
        //   115: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   118: athrow         
        //   119: ifne            179
        //   122: goto            129
        //   125: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   128: athrow         
        //   129: aload_0        
        //   130: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //   133: goto            140
        //   136: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   139: athrow         
        //   140: ifne            179
        //   143: new             Ljava/lang/StringBuilder;
        //   146: dup            
        //   147: invokespecial   java/lang/StringBuilder.<init>:()V
        //   150: sipush          2756
        //   153: sipush          23642
        //   156: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   159: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   162: aload_0        
        //   163: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   166: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   169: astore_2       
        //   170: new             Ljava/io/IOException;
        //   173: dup            
        //   174: aload_2        
        //   175: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   178: athrow         
        //   179: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 0D FF 00 12 00 02 07 00 3F 01 00 01 07 00 60 03 46 07 00 60 43 01 3E 4B 01 46 07 00 60 43 01 45 07 00 60 03 46 07 00 60 43 01 26
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      15     18     22     Ljava/io/IOException;
        //  12     26     29     33     Ljava/io/IOException;
        //  104    112    115    119    Ljava/io/IOException;
        //  108    122    125    129    Ljava/io/IOException;
        //  119    133    136    140    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0108:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void forceMkdirParent(final File file) throws IOException {
        final int c = IOCase.c();
        final File ep = q.ep(file);
        final int n = c;
        File file2 = null;
        Label_0025: {
            try {
                file2 = ep;
                if (n == 0) {
                    break Label_0025;
                }
                if (file2 != null) {
                    break Label_0025;
                }
            }
            catch (IOException ex) {
                throw b(ex);
            }
            return;
        }
        forceMkdir(file2);
    }
    
    public static long sizeOf(final File file) {
        final int b = IOCase.b();
        File file2 = null;
        Label_0089: {
            Label_0088: {
                Label_0073: {
                    boolean kc = false;
                    Label_0058: {
                        try {
                            kc = q.kc(file);
                            if (b != 0) {
                                break Label_0073;
                            }
                            if (kc) {
                                break Label_0058;
                            }
                        }
                        catch (NullPointerException ex) {
                            throw b(ex);
                        }
                        throw new IllegalArgumentException(q.s(q.r(q.kx(new StringBuilder(), file), a(2815, -22419))));
                        try {
                            file2 = file;
                            if (b != 0) {
                                break Label_0089;
                            }
                            q.su(file);
                        }
                        catch (NullPointerException ex2) {
                            throw b(ex2);
                        }
                    }
                    try {
                        if (!kc) {
                            break Label_0088;
                        }
                        sizeOfDirectory0(file);
                    }
                    catch (NullPointerException ex3) {
                        throw b(ex3);
                    }
                }
                return;
            }
            file2 = file;
        }
        final long eb = q.eb(file2);
        if (b == 0) {
            return eb;
        }
        return eb;
    }
    
    public static BigInteger sizeOfAsBigInteger(final File file) {
        final int c = IOCase.c();
        File file2 = null;
        Label_0089: {
            Label_0088: {
                Label_0073: {
                    boolean kc = false;
                    Label_0058: {
                        try {
                            kc = q.kc(file);
                            if (c == 0) {
                                break Label_0073;
                            }
                            if (kc) {
                                break Label_0058;
                            }
                        }
                        catch (NullPointerException ex) {
                            throw b(ex);
                        }
                        throw new IllegalArgumentException(q.s(q.r(q.kx(new StringBuilder(), file), a(2815, -22419))));
                        try {
                            file2 = file;
                            if (c == 0) {
                                break Label_0089;
                            }
                            q.su(file);
                        }
                        catch (NullPointerException ex2) {
                            throw b(ex2);
                        }
                    }
                    try {
                        if (!kc) {
                            break Label_0088;
                        }
                        sizeOfDirectoryBig0(file);
                    }
                    catch (NullPointerException ex3) {
                        throw b(ex3);
                    }
                }
                return;
            }
            file2 = file;
        }
        final BigInteger ej = q.ej(q.eb(file2));
        if (c != 0) {
            return ej;
        }
        return ej;
    }
    
    public static long sizeOfDirectory(final File file) {
        checkDirectory(file);
        return sizeOfDirectory0(file);
    }
    
    private static long sizeOfDirectory0(final File file) {
        final File[] sl = q.sl(file);
        final int c = IOCase.c();
        Label_0022: {
            try {
                if (sl != null) {
                    break Label_0022;
                }
            }
            catch (IOException ex) {
                throw b(ex);
            }
            return;
        }
        final long n = 0L;
        if (c != 0) {
            long n2 = n;
            final File[] array = sl;
            final int length = array.length;
            int i = 0;
            while (i < length) {
                final File file2 = array[i];
                Label_0110: {
                    try {
                        Label_0101: {
                            long symlink = 0L;
                            Label_0094: {
                                Label_0073: {
                                    int n3;
                                    try {
                                        n3 = (int)(symlink = (isSymlink(file2) ? 1 : 0));
                                        if (c == 0) {
                                            break Label_0094;
                                        }
                                        final int n4 = c;
                                        if (n4 != 0) {
                                            break Label_0073;
                                        }
                                        break Label_0094;
                                    }
                                    catch (IOException ex2) {
                                        throw b(ex2);
                                    }
                                    try {
                                        final int n4 = c;
                                        if (n4 == 0) {
                                            break Label_0094;
                                        }
                                        if (n3 != 0) {
                                            break Label_0101;
                                        }
                                    }
                                    catch (IOException ex3) {
                                        throw b(ex3);
                                    }
                                }
                                n2 += sizeOf0(file2);
                                symlink = lcmp(n2, 0L);
                            }
                            if (symlink >= 0) {
                                break Label_0101;
                            }
                            try {
                                if (c == 0) {
                                    break Label_0110;
                                }
                                break;
                            }
                            catch (IOException ex4) {
                                throw b(ex4);
                            }
                        }
                    }
                    catch (IOException ex5) {}
                }
                ++i;
                if (c == 0) {
                    break;
                }
            }
            return n2;
        }
        return n;
    }
    
    private static long sizeOf0(final File file) {
        final int c = IOCase.c();
        File file2 = null;
        Label_0035: {
            Label_0034: {
                Label_0022: {
                    try {
                        file2 = file;
                        if (c == 0) {
                            break Label_0035;
                        }
                        final boolean b = q.su(file);
                        if (b) {
                            break Label_0022;
                        }
                        break Label_0034;
                    }
                    catch (NullPointerException ex) {
                        throw b(ex);
                    }
                    try {
                        final boolean b = q.su(file);
                        if (!b) {
                            break Label_0034;
                        }
                        sizeOfDirectory0(file);
                    }
                    catch (NullPointerException ex2) {
                        throw b(ex2);
                    }
                }
                return;
            }
            file2 = file;
        }
        final long eb = q.eb(file2);
        if (c != 0) {
            return eb;
        }
        return eb;
    }
    
    public static BigInteger sizeOfDirectoryAsBigInteger(final File file) {
        checkDirectory(file);
        return sizeOfDirectoryBig0(file);
    }
    
    private static BigInteger sizeOfDirectoryBig0(final File file) {
        final File[] sl = q.sl(file);
        final int b = IOCase.b();
        Label_0024: {
            try {
                if (sl != null) {
                    break Label_0024;
                }
                x.dn.g.b.q.e();
            }
            catch (IOException ex) {
                throw b(ex);
            }
            return;
        }
        final BigInteger e = x.dn.g.b.q.e();
        if (b == 0) {
            BigInteger pq = e;
            final File[] array = sl;
            final int length = array.length;
            int i = 0;
            while (i < length) {
                final File file2 = array[i];
                try {
                    if (!isSymlink(file2)) {
                        pq = q.pq(pq, sizeOfBig0(file2));
                    }
                }
                catch (IOException ex2) {}
                ++i;
                if (b != 0) {
                    break;
                }
            }
            return pq;
        }
        return e;
    }
    
    private static BigInteger sizeOfBig0(final File file) {
        final int c = IOCase.c();
        File file2 = null;
        Label_0035: {
            Label_0034: {
                Label_0022: {
                    try {
                        file2 = file;
                        if (c == 0) {
                            break Label_0035;
                        }
                        final boolean b = q.su(file);
                        if (b) {
                            break Label_0022;
                        }
                        break Label_0034;
                    }
                    catch (NullPointerException ex) {
                        throw b(ex);
                    }
                    try {
                        final boolean b = q.su(file);
                        if (!b) {
                            break Label_0034;
                        }
                        sizeOfDirectoryBig0(file);
                    }
                    catch (NullPointerException ex2) {
                        throw b(ex2);
                    }
                }
                return;
            }
            file2 = file;
        }
        final BigInteger ej = q.ej(q.eb(file2));
        if (c != 0) {
            return ej;
        }
        return ej;
    }
    
    private static void checkDirectory(final File file) {
        final int b = IOCase.b();
        Label_0064: {
            Label_0022: {
                boolean b2;
                try {
                    final boolean b3;
                    b2 = (b3 = q.kc(file));
                    if (b != 0) {
                        break Label_0064;
                    }
                    if (!b2) {
                        break Label_0022;
                    }
                    break Label_0022;
                }
                catch (NullPointerException ex) {
                    throw b(ex);
                }
                try {
                    if (!b2) {
                        throw new IllegalArgumentException(q.s(q.r(q.kx(new StringBuilder(), file), a(2815, -22419))));
                    }
                }
                catch (NullPointerException ex2) {
                    throw b(ex2);
                }
            }
            boolean b3 = q.su(file);
            try {
                if (!b3) {
                    throw new IllegalArgumentException(q.s(q.r(q.kx(new StringBuilder(), file), a(2797, 13282))));
                }
            }
            catch (NullPointerException ex3) {
                throw b(ex3);
            }
        }
    }
    
    public static boolean isFileNewer(final File file, final File file2) {
        final int b = IOCase.b();
        Label_0058: {
            boolean b2 = false;
            Label_0041: {
                Label_0019: {
                    try {
                        final File file3 = file2;
                        if (b != 0) {
                            break Label_0041;
                        }
                        if (file2 == null) {
                            break Label_0019;
                        }
                        break Label_0019;
                    }
                    catch (NullPointerException ex) {
                        throw b(ex);
                    }
                    try {
                        if (file2 == null) {
                            throw new IllegalArgumentException(a(2808, -32748));
                        }
                    }
                    catch (NullPointerException ex2) {
                        throw b(ex2);
                    }
                }
                final File file3 = file2;
                try {
                    final boolean b3;
                    b2 = (b3 = q.kc(file3));
                    if (b != 0) {
                        return b3;
                    }
                    if (!b2) {
                        break Label_0058;
                    }
                    return isFileNewer(file, q.nj(file2));
                }
                catch (NullPointerException ex3) {
                    throw b(ex3);
                }
            }
            try {
                if (!b2) {
                    throw new IllegalArgumentException(q.s(q.r(q.kx(q.r(new StringBuilder(), a(2776, -8118)), file2), a(2775, -8917))));
                }
            }
            catch (NullPointerException ex4) {
                throw b(ex4);
            }
        }
        return isFileNewer(file, q.nj(file2));
    }
    
    public static boolean isFileNewer(final File file, final Date date) {
        try {
            if (date == null) {
                throw new IllegalArgumentException(a(2762, -26043));
            }
        }
        catch (NullPointerException ex) {
            throw b(ex);
        }
        return isFileNewer(file, q.pt(date));
    }
    
    public static boolean isFileNewer(final File p0, final long p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_3       
        //     4: aload_0        
        //     5: iload_3        
        //     6: ifne            41
        //     9: ifnonnull       40
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: new             Ljava/lang/IllegalArgumentException;
        //    22: dup            
        //    23: sipush          2798
        //    26: sipush          -3219
        //    29: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    32: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //    35: athrow         
        //    36: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    39: athrow         
        //    40: aload_0        
        //    41: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //    44: iload_3        
        //    45: ifne            74
        //    48: ifne            60
        //    51: goto            58
        //    54: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    57: athrow         
        //    58: iconst_0       
        //    59: ireturn        
        //    60: aload_0        
        //    61: invokestatic    q/o/m/s/q.nj:(Ljava/io/File;)J
        //    64: lload_1        
        //    65: lcmp           
        //    66: iload_3        
        //    67: ifne            59
        //    70: iload_3        
        //    71: ifne            96
        //    74: iload_3        
        //    75: ifne            96
        //    78: goto            85
        //    81: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    84: athrow         
        //    85: ifle            99
        //    88: goto            95
        //    91: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    94: athrow         
        //    95: iconst_1       
        //    96: goto            100
        //    99: iconst_0       
        //   100: ireturn        
        //    StackMapTable: 00 11 FF 00 0F 00 03 07 00 3F 04 01 00 01 07 00 31 03 50 07 00 31 03 40 07 00 3F 4C 07 00 31 03 40 01 00 4D 01 46 07 00 31 43 01 45 07 00 31 03 40 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      12     15     19     Ljava/lang/NullPointerException;
        //  9      36     36     40     Ljava/lang/NullPointerException;
        //  41     51     54     58     Ljava/lang/NullPointerException;
        //  70     78     81     85     Ljava/lang/NullPointerException;
        //  74     88     91     95     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0074:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static boolean isFileOlder(final File file, final File file2) {
        final int c = IOCase.c();
        Label_0058: {
            boolean b = false;
            Label_0041: {
                Label_0019: {
                    try {
                        final File file3 = file2;
                        if (c == 0) {
                            break Label_0041;
                        }
                        if (file2 == null) {
                            break Label_0019;
                        }
                        break Label_0019;
                    }
                    catch (NullPointerException ex) {
                        throw b(ex);
                    }
                    try {
                        if (file2 == null) {
                            throw new IllegalArgumentException(a(2808, -32748));
                        }
                    }
                    catch (NullPointerException ex2) {
                        throw b(ex2);
                    }
                }
                final File file3 = file2;
                try {
                    final boolean b2;
                    b = (b2 = q.kc(file3));
                    if (c == 0) {
                        return b2;
                    }
                    if (!b) {
                        break Label_0058;
                    }
                    return isFileOlder(file, q.nj(file2));
                }
                catch (NullPointerException ex3) {
                    throw b(ex3);
                }
            }
            try {
                if (!b) {
                    throw new IllegalArgumentException(q.s(q.r(q.kx(q.r(new StringBuilder(), a(2776, -8118)), file2), a(2775, -8917))));
                }
            }
            catch (NullPointerException ex4) {
                throw b(ex4);
            }
        }
        return isFileOlder(file, q.nj(file2));
    }
    
    public static boolean isFileOlder(final File file, final Date date) {
        try {
            if (date == null) {
                throw new IllegalArgumentException(a(2762, -26043));
            }
        }
        catch (NullPointerException ex) {
            throw b(ex);
        }
        return isFileOlder(file, q.pt(date));
    }
    
    public static boolean isFileOlder(final File p0, final long p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_3       
        //     4: aload_0        
        //     5: iload_3        
        //     6: ifne            41
        //     9: ifnonnull       40
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: new             Ljava/lang/IllegalArgumentException;
        //    22: dup            
        //    23: sipush          2798
        //    26: sipush          -3219
        //    29: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    32: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //    35: athrow         
        //    36: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    39: athrow         
        //    40: aload_0        
        //    41: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //    44: iload_3        
        //    45: ifne            74
        //    48: ifne            60
        //    51: goto            58
        //    54: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    57: athrow         
        //    58: iconst_0       
        //    59: ireturn        
        //    60: aload_0        
        //    61: invokestatic    q/o/m/s/q.nj:(Ljava/io/File;)J
        //    64: lload_1        
        //    65: lcmp           
        //    66: iload_3        
        //    67: ifne            59
        //    70: iload_3        
        //    71: ifne            96
        //    74: iload_3        
        //    75: ifne            96
        //    78: goto            85
        //    81: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    84: athrow         
        //    85: ifge            99
        //    88: goto            95
        //    91: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    94: athrow         
        //    95: iconst_1       
        //    96: goto            100
        //    99: iconst_0       
        //   100: ireturn        
        //    StackMapTable: 00 11 FF 00 0F 00 03 07 00 3F 04 01 00 01 07 00 31 03 50 07 00 31 03 40 07 00 3F 4C 07 00 31 03 40 01 00 4D 01 46 07 00 31 43 01 45 07 00 31 03 40 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      12     15     19     Ljava/lang/NullPointerException;
        //  9      36     36     40     Ljava/lang/NullPointerException;
        //  41     51     54     58     Ljava/lang/NullPointerException;
        //  70     78     81     85     Ljava/lang/NullPointerException;
        //  74     88     91     95     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0074:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static long checksumCRC32(final File file) throws IOException {
        final CRC32 crc32 = new CRC32();
        checksum(file, crc32);
        return q.pr(crc32);
    }
    
    public static Checksum checksum(final File file, final Checksum cksum) throws IOException {
        try {
            if (q.su(file)) {
                throw new IllegalArgumentException(a(2782, 3383));
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
        InputStream inputStream = null;
        try {
            inputStream = new CheckedInputStream(new FileInputStream(file), cksum);
            IOUtils.copy(inputStream, new NullOutputStream());
        }
        finally {
            IOUtils.closeQuietly(inputStream);
        }
        return cksum;
    }
    
    public static void moveDirectory(final File p0, final File p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: iload_2        
        //     6: ifeq            41
        //     9: ifnonnull       40
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: new             Ljava/lang/NullPointerException;
        //    22: dup            
        //    23: sipush          2757
        //    26: sipush          -31686
        //    29: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    32: invokespecial   java/lang/NullPointerException.<init>:(Ljava/lang/String;)V
        //    35: athrow         
        //    36: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    39: athrow         
        //    40: aload_1        
        //    41: iload_2        
        //    42: ifeq            77
        //    45: ifnonnull       76
        //    48: goto            55
        //    51: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    54: athrow         
        //    55: new             Ljava/lang/NullPointerException;
        //    58: dup            
        //    59: sipush          2773
        //    62: sipush          27064
        //    65: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    68: invokespecial   java/lang/NullPointerException.<init>:(Ljava/lang/String;)V
        //    71: athrow         
        //    72: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    75: athrow         
        //    76: aload_0        
        //    77: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //    80: iload_2        
        //    81: ifeq            148
        //    84: ifne            144
        //    87: goto            94
        //    90: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    93: athrow         
        //    94: new             Ljava/io/FileNotFoundException;
        //    97: dup            
        //    98: new             Ljava/lang/StringBuilder;
        //   101: dup            
        //   102: invokespecial   java/lang/StringBuilder.<init>:()V
        //   105: sipush          2761
        //   108: sipush          655
        //   111: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   114: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   117: aload_0        
        //   118: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   121: sipush          2739
        //   124: sipush          -14564
        //   127: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   130: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   133: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   136: invokespecial   java/io/FileNotFoundException.<init>:(Ljava/lang/String;)V
        //   139: athrow         
        //   140: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   143: athrow         
        //   144: aload_0        
        //   145: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //   148: iload_2        
        //   149: ifeq            216
        //   152: ifne            212
        //   155: goto            162
        //   158: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   161: athrow         
        //   162: new             Ljava/io/IOException;
        //   165: dup            
        //   166: new             Ljava/lang/StringBuilder;
        //   169: dup            
        //   170: invokespecial   java/lang/StringBuilder.<init>:()V
        //   173: sipush          2761
        //   176: sipush          655
        //   179: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   182: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   185: aload_0        
        //   186: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   189: sipush          2753
        //   192: sipush          -3610
        //   195: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   198: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   201: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   204: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   207: athrow         
        //   208: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   211: athrow         
        //   212: aload_1        
        //   213: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //   216: iload_2        
        //   217: ifeq            285
        //   220: ifeq            280
        //   223: goto            230
        //   226: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   229: athrow         
        //   230: new             Lorg/apache/commons/io/FileExistsException;
        //   233: dup            
        //   234: new             Ljava/lang/StringBuilder;
        //   237: dup            
        //   238: invokespecial   java/lang/StringBuilder.<init>:()V
        //   241: sipush          2777
        //   244: sipush          -14708
        //   247: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   250: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   253: aload_1        
        //   254: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   257: sipush          2799
        //   260: sipush          -9694
        //   263: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   266: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   269: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   272: invokespecial   org/apache/commons/io/FileExistsException.<init>:(Ljava/lang/String;)V
        //   275: athrow         
        //   276: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   279: athrow         
        //   280: aload_0        
        //   281: aload_1        
        //   282: invokestatic    q/o/m/s/q.ps:(Ljava/io/File;Ljava/io/File;)Z
        //   285: istore_3       
        //   286: iload_3        
        //   287: iload_2        
        //   288: ifeq            349
        //   291: iload_2        
        //   292: ifeq            349
        //   295: goto            302
        //   298: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   301: athrow         
        //   302: ifne            493
        //   305: goto            312
        //   308: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   311: athrow         
        //   312: aload_1        
        //   313: invokestatic    q/o/m/s/q.nn:(Ljava/io/File;)Ljava/lang/String;
        //   316: new             Ljava/lang/StringBuilder;
        //   319: dup            
        //   320: invokespecial   java/lang/StringBuilder.<init>:()V
        //   323: aload_0        
        //   324: invokestatic    q/o/m/s/q.nn:(Ljava/io/File;)Ljava/lang/String;
        //   327: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   330: invokestatic    x/dn/g/b/q.p:()Ljava/lang/String;
        //   333: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   336: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   339: invokestatic    q/o/m/s/q.t:(Ljava/lang/String;Ljava/lang/String;)Z
        //   342: goto            349
        //   345: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   348: athrow         
        //   349: iload_2        
        //   350: ifeq            430
        //   353: ifeq            417
        //   356: goto            363
        //   359: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   362: athrow         
        //   363: new             Ljava/io/IOException;
        //   366: dup            
        //   367: new             Ljava/lang/StringBuilder;
        //   370: dup            
        //   371: invokespecial   java/lang/StringBuilder.<init>:()V
        //   374: sipush          2760
        //   377: sipush          -15785
        //   380: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   383: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   386: aload_0        
        //   387: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   390: sipush          2759
        //   393: sipush          -5061
        //   396: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   399: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   402: aload_1        
        //   403: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   406: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   409: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   412: athrow         
        //   413: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   416: athrow         
        //   417: aload_0        
        //   418: aload_1        
        //   419: invokestatic    org/apache/commons/io/FileUtils.copyDirectory:(Ljava/io/File;Ljava/io/File;)V
        //   422: aload_0        
        //   423: invokestatic    org/apache/commons/io/FileUtils.deleteDirectory:(Ljava/io/File;)V
        //   426: aload_0        
        //   427: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //   430: ifeq            493
        //   433: new             Ljava/io/IOException;
        //   436: dup            
        //   437: new             Ljava/lang/StringBuilder;
        //   440: dup            
        //   441: invokespecial   java/lang/StringBuilder.<init>:()V
        //   444: sipush          2796
        //   447: sipush          992
        //   450: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   453: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   456: aload_0        
        //   457: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   460: sipush          2800
        //   463: sipush          -17977
        //   466: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   469: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   472: aload_1        
        //   473: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   476: invokestatic    n/d/a/d/q.vk:()Ljava/lang/String;
        //   479: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   482: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   485: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   488: athrow         
        //   489: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   492: athrow         
        //   493: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 26 FF 00 0F 00 03 07 00 3F 07 00 3F 01 00 01 07 00 60 03 50 07 00 60 03 40 07 00 3F 49 07 00 60 03 50 07 00 60 03 40 07 00 3F 4C 07 00 60 03 6D 07 00 60 03 43 01 49 07 00 60 03 6D 07 00 60 03 43 01 49 07 00 60 03 6D 07 00 60 03 44 01 FF 00 0C 00 04 07 00 3F 07 00 3F 01 01 00 01 07 00 60 43 01 45 07 00 60 03 60 07 00 60 43 01 49 07 00 60 03 71 07 00 60 03 4C 01 7A 07 00 60 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      12     15     19     Ljava/io/IOException;
        //  9      36     36     40     Ljava/io/IOException;
        //  41     48     51     55     Ljava/io/IOException;
        //  45     72     72     76     Ljava/io/IOException;
        //  77     87     90     94     Ljava/io/IOException;
        //  84     140    140    144    Ljava/io/IOException;
        //  148    155    158    162    Ljava/io/IOException;
        //  152    208    208    212    Ljava/io/IOException;
        //  216    223    226    230    Ljava/io/IOException;
        //  220    276    276    280    Ljava/io/IOException;
        //  286    295    298    302    Ljava/io/IOException;
        //  291    305    308    312    Ljava/io/IOException;
        //  302    342    345    349    Ljava/io/IOException;
        //  349    356    359    363    Ljava/io/IOException;
        //  353    413    413    417    Ljava/io/IOException;
        //  430    489    489    493    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0302:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void moveDirectoryToDirectory(final File file, final File parent, final boolean b) throws IOException {
        final int c = IOCase.c();
        File file4 = null;
        Label_0269: {
            Label_0215: {
                boolean b4 = false;
                Label_0200: {
                    Label_0140: {
                        boolean b3 = false;
                        Label_0126: {
                        Label_0095_Outer:
                            while (true) {
                                Label_0077: {
                                    Label_0055: {
                                        File file3 = null;
                                        Label_0041: {
                                            Label_0019: {
                                                try {
                                                    final File file2 = file;
                                                    file3 = file;
                                                    if (c == 0) {
                                                        break Label_0041;
                                                    }
                                                    if (file == null) {
                                                        break Label_0019;
                                                    }
                                                    break Label_0019;
                                                }
                                                catch (IOException ex) {
                                                    throw b(ex);
                                                }
                                                try {
                                                    if (file == null) {
                                                        throw new NullPointerException(a(2757, -31686));
                                                    }
                                                }
                                                catch (IOException ex2) {
                                                    throw b(ex2);
                                                }
                                            }
                                            final File file2 = parent;
                                            file3 = parent;
                                            try {
                                                if (c == 0) {
                                                    break Label_0077;
                                                }
                                                if (file3 == null) {
                                                    break Label_0055;
                                                }
                                                break Label_0055;
                                            }
                                            catch (IOException ex3) {
                                                throw b(ex3);
                                            }
                                        }
                                        try {
                                            if (file3 == null) {
                                                throw new NullPointerException(a(2801, -11080));
                                            }
                                        }
                                        catch (IOException ex4) {
                                            throw b(ex4);
                                        }
                                    }
                                    final File file2 = parent;
                                    try {
                                        final boolean b2 = b3 = (b4 = q.kc(file2));
                                        if (c == 0) {
                                            break Label_0126;
                                        }
                                        if (b2) {
                                            break Label_0113;
                                        }
                                    }
                                    catch (IOException ex5) {
                                        throw b(ex5);
                                    }
                                }
                                b4 = b;
                                b3 = b;
                                boolean b5 = b;
                                while (true) {
                                    if (c == 0) {
                                        break Label_0126;
                                    }
                                    try {
                                        if (b5) {
                                            q.ey(parent);
                                        }
                                    }
                                    catch (IOException ex6) {
                                        throw b(ex6);
                                    }
                                    b3 = (b5 = (b4 = q.kc(parent)));
                                    if (c == 0) {
                                        continue;
                                    }
                                    break;
                                }
                                if (c == 0) {
                                    continue Label_0095_Outer;
                                }
                                break;
                            }
                            try {
                                if (c == 0) {
                                    break Label_0215;
                                }
                                if (!b3) {
                                    break Label_0140;
                                }
                                break Label_0200;
                            }
                            catch (IOException ex7) {
                                throw b(ex7);
                            }
                        }
                        try {
                            if (!b3) {
                                throw new FileNotFoundException(q.s(q.r(q.pk(q.r(q.kx(q.r(new StringBuilder(), a(2792, -7585)), parent), a(2803, 7320)), b), n.d.a.d.q.vq())));
                            }
                        }
                        catch (IOException ex8) {
                            throw b(ex8);
                        }
                    }
                    try {
                        file4 = parent;
                        if (c == 0) {
                            break Label_0269;
                        }
                        b4 = q.su(parent);
                    }
                    catch (IOException ex9) {
                        throw b(ex9);
                    }
                }
                try {
                    if (!b4) {
                        throw new IOException(q.s(q.r(q.kx(q.r(new StringBuilder(), a(2777, -14708)), parent), a(2753, -3610))));
                    }
                }
                catch (IOException ex10) {
                    throw b(ex10);
                }
            }
            file4 = file;
        }
        moveDirectory(file4, new File(parent, q.mh(file)));
    }
    
    public static void moveFile(final File p0, final File p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: iload_2        
        //     6: ifeq            41
        //     9: ifnonnull       40
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: new             Ljava/lang/NullPointerException;
        //    22: dup            
        //    23: sipush          2757
        //    26: sipush          -31686
        //    29: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    32: invokespecial   java/lang/NullPointerException.<init>:(Ljava/lang/String;)V
        //    35: athrow         
        //    36: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    39: athrow         
        //    40: aload_1        
        //    41: iload_2        
        //    42: ifeq            77
        //    45: ifnonnull       76
        //    48: goto            55
        //    51: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    54: athrow         
        //    55: new             Ljava/lang/NullPointerException;
        //    58: dup            
        //    59: sipush          2773
        //    62: sipush          27064
        //    65: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //    68: invokespecial   java/lang/NullPointerException.<init>:(Ljava/lang/String;)V
        //    71: athrow         
        //    72: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    75: athrow         
        //    76: aload_0        
        //    77: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //    80: iload_2        
        //    81: ifeq            148
        //    84: ifne            144
        //    87: goto            94
        //    90: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    93: athrow         
        //    94: new             Ljava/io/FileNotFoundException;
        //    97: dup            
        //    98: new             Ljava/lang/StringBuilder;
        //   101: dup            
        //   102: invokespecial   java/lang/StringBuilder.<init>:()V
        //   105: sipush          2761
        //   108: sipush          655
        //   111: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   114: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   117: aload_0        
        //   118: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   121: sipush          2739
        //   124: sipush          -14564
        //   127: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   130: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   133: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   136: invokespecial   java/io/FileNotFoundException.<init>:(Ljava/lang/String;)V
        //   139: athrow         
        //   140: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   143: athrow         
        //   144: aload_0        
        //   145: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //   148: iload_2        
        //   149: ifeq            216
        //   152: ifeq            212
        //   155: goto            162
        //   158: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   161: athrow         
        //   162: new             Ljava/io/IOException;
        //   165: dup            
        //   166: new             Ljava/lang/StringBuilder;
        //   169: dup            
        //   170: invokespecial   java/lang/StringBuilder.<init>:()V
        //   173: sipush          2761
        //   176: sipush          655
        //   179: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   182: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   185: aload_0        
        //   186: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   189: sipush          2779
        //   192: sipush          4994
        //   195: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   198: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   201: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   204: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   207: athrow         
        //   208: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   211: athrow         
        //   212: aload_1        
        //   213: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //   216: iload_2        
        //   217: ifeq            284
        //   220: ifeq            280
        //   223: goto            230
        //   226: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   229: athrow         
        //   230: new             Lorg/apache/commons/io/FileExistsException;
        //   233: dup            
        //   234: new             Ljava/lang/StringBuilder;
        //   237: dup            
        //   238: invokespecial   java/lang/StringBuilder.<init>:()V
        //   241: sipush          2777
        //   244: sipush          -14708
        //   247: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   250: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   253: aload_1        
        //   254: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   257: sipush          2799
        //   260: sipush          -9694
        //   263: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   266: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   269: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   272: invokespecial   org/apache/commons/io/FileExistsException.<init>:(Ljava/lang/String;)V
        //   275: athrow         
        //   276: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   279: athrow         
        //   280: aload_1        
        //   281: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //   284: iload_2        
        //   285: ifeq            353
        //   288: ifeq            348
        //   291: goto            298
        //   294: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   297: athrow         
        //   298: new             Ljava/io/IOException;
        //   301: dup            
        //   302: new             Ljava/lang/StringBuilder;
        //   305: dup            
        //   306: invokespecial   java/lang/StringBuilder.<init>:()V
        //   309: sipush          2777
        //   312: sipush          -14708
        //   315: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   318: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   321: aload_1        
        //   322: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   325: sipush          2779
        //   328: sipush          4994
        //   331: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   334: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   337: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   340: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   343: athrow         
        //   344: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   347: athrow         
        //   348: aload_0        
        //   349: aload_1        
        //   350: invokestatic    q/o/m/s/q.ps:(Ljava/io/File;Ljava/io/File;)Z
        //   353: istore_3       
        //   354: iload_3        
        //   355: iload_2        
        //   356: ifeq            396
        //   359: iload_2        
        //   360: ifeq            400
        //   363: goto            370
        //   366: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   369: athrow         
        //   370: ifne            489
        //   373: goto            380
        //   376: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   379: athrow         
        //   380: aload_0        
        //   381: aload_1        
        //   382: invokestatic    org/apache/commons/io/FileUtils.copyFile:(Ljava/io/File;Ljava/io/File;)V
        //   385: aload_0        
        //   386: invokestatic    q/o/m/s/q.kh:(Ljava/io/File;)Z
        //   389: goto            396
        //   392: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   395: athrow         
        //   396: iload_2        
        //   397: ifeq            432
        //   400: iload_2        
        //   401: ifeq            432
        //   404: goto            411
        //   407: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   410: athrow         
        //   411: ifne            489
        //   414: goto            421
        //   417: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   420: athrow         
        //   421: aload_1        
        //   422: invokestatic    org/apache/commons/io/FileUtils.deleteQuietly:(Ljava/io/File;)Z
        //   425: goto            432
        //   428: invokestatic    org/apache/commons/io/FileUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   431: athrow         
        //   432: pop            
        //   433: new             Ljava/io/IOException;
        //   436: dup            
        //   437: new             Ljava/lang/StringBuilder;
        //   440: dup            
        //   441: invokespecial   java/lang/StringBuilder.<init>:()V
        //   444: sipush          2813
        //   447: sipush          5746
        //   450: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   453: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   456: aload_0        
        //   457: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   460: sipush          2800
        //   463: sipush          -17977
        //   466: invokestatic    org/apache/commons/io/FileUtils.a:(II)Ljava/lang/String;
        //   469: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   472: aload_1        
        //   473: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   476: invokestatic    n/d/a/d/q.vk:()Ljava/lang/String;
        //   479: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   482: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   485: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   488: athrow         
        //   489: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 2C FF 00 0F 00 03 07 00 3F 07 00 3F 01 00 01 07 00 60 03 50 07 00 60 03 40 07 00 3F 49 07 00 60 03 50 07 00 60 03 40 07 00 3F 4C 07 00 60 03 6D 07 00 60 03 43 01 49 07 00 60 03 6D 07 00 60 03 43 01 49 07 00 60 03 6D 07 00 60 03 43 01 49 07 00 60 03 6D 07 00 60 03 44 01 FF 00 0C 00 04 07 00 3F 07 00 3F 01 01 00 01 07 00 60 43 01 45 07 00 60 03 4B 07 00 60 43 01 43 01 46 07 00 60 43 01 45 07 00 60 03 46 07 00 60 43 01 38
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      12     15     19     Ljava/io/IOException;
        //  9      36     36     40     Ljava/io/IOException;
        //  41     48     51     55     Ljava/io/IOException;
        //  45     72     72     76     Ljava/io/IOException;
        //  77     87     90     94     Ljava/io/IOException;
        //  84     140    140    144    Ljava/io/IOException;
        //  148    155    158    162    Ljava/io/IOException;
        //  152    208    208    212    Ljava/io/IOException;
        //  216    223    226    230    Ljava/io/IOException;
        //  220    276    276    280    Ljava/io/IOException;
        //  284    291    294    298    Ljava/io/IOException;
        //  288    344    344    348    Ljava/io/IOException;
        //  354    363    366    370    Ljava/io/IOException;
        //  359    373    376    380    Ljava/io/IOException;
        //  370    389    392    396    Ljava/io/IOException;
        //  396    404    407    411    Ljava/io/IOException;
        //  400    414    417    421    Ljava/io/IOException;
        //  411    425    428    432    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0370:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void moveFileToDirectory(final File file, final File parent, final boolean b) throws IOException {
        final int b2 = IOCase.b();
        File file4 = null;
        Label_0269: {
            Label_0215: {
                boolean b5 = false;
                Label_0200: {
                    Label_0140: {
                        boolean b4 = false;
                        Label_0126: {
                        Label_0095_Outer:
                            while (true) {
                                Label_0077: {
                                    Label_0055: {
                                        File file3 = null;
                                        Label_0041: {
                                            Label_0019: {
                                                try {
                                                    final File file2 = file;
                                                    file3 = file;
                                                    if (b2 != 0) {
                                                        break Label_0041;
                                                    }
                                                    if (file == null) {
                                                        break Label_0019;
                                                    }
                                                    break Label_0019;
                                                }
                                                catch (IOException ex) {
                                                    throw b(ex);
                                                }
                                                try {
                                                    if (file == null) {
                                                        throw new NullPointerException(a(2757, -31686));
                                                    }
                                                }
                                                catch (IOException ex2) {
                                                    throw b(ex2);
                                                }
                                            }
                                            final File file2 = parent;
                                            file3 = parent;
                                            try {
                                                if (b2 != 0) {
                                                    break Label_0077;
                                                }
                                                if (file3 == null) {
                                                    break Label_0055;
                                                }
                                                break Label_0055;
                                            }
                                            catch (IOException ex3) {
                                                throw b(ex3);
                                            }
                                        }
                                        try {
                                            if (file3 == null) {
                                                throw new NullPointerException(a(2801, -11080));
                                            }
                                        }
                                        catch (IOException ex4) {
                                            throw b(ex4);
                                        }
                                    }
                                    final File file2 = parent;
                                    try {
                                        final boolean b3 = b4 = (b5 = q.kc(file2));
                                        if (b2 != 0) {
                                            break Label_0126;
                                        }
                                        if (b3) {
                                            break Label_0113;
                                        }
                                    }
                                    catch (IOException ex5) {
                                        throw b(ex5);
                                    }
                                }
                                b5 = b;
                                b4 = b;
                                boolean b6 = b;
                                while (true) {
                                    if (b2 != 0) {
                                        break Label_0126;
                                    }
                                    try {
                                        if (b6) {
                                            q.ey(parent);
                                        }
                                    }
                                    catch (IOException ex6) {
                                        throw b(ex6);
                                    }
                                    b4 = (b6 = (b5 = q.kc(parent)));
                                    if (b2 != 0) {
                                        continue;
                                    }
                                    break;
                                }
                                if (b2 != 0) {
                                    continue Label_0095_Outer;
                                }
                                break;
                            }
                            try {
                                if (b2 != 0) {
                                    break Label_0215;
                                }
                                if (!b4) {
                                    break Label_0140;
                                }
                                break Label_0200;
                            }
                            catch (IOException ex7) {
                                throw b(ex7);
                            }
                        }
                        try {
                            if (!b4) {
                                throw new FileNotFoundException(q.s(q.r(q.pk(q.r(q.kx(q.r(new StringBuilder(), a(2792, -7585)), parent), a(2803, 7320)), b), n.d.a.d.q.vq())));
                            }
                        }
                        catch (IOException ex8) {
                            throw b(ex8);
                        }
                    }
                    try {
                        file4 = parent;
                        if (b2 != 0) {
                            break Label_0269;
                        }
                        b5 = q.su(parent);
                    }
                    catch (IOException ex9) {
                        throw b(ex9);
                    }
                }
                try {
                    if (!b5) {
                        throw new IOException(q.s(q.r(q.kx(q.r(new StringBuilder(), a(2777, -14708)), parent), a(2753, -3610))));
                    }
                }
                catch (IOException ex10) {
                    throw b(ex10);
                }
            }
            file4 = file;
        }
        moveFile(file4, new File(parent, q.mh(file)));
    }
    
    public static void moveToDirectory(final File file, final File file2, final boolean b) throws IOException {
        final int c = IOCase.c();
        File file5 = null;
        while (true) {
            Label_0180: {
                Label_0179: {
                    File file6 = null;
                    File file7 = null;
                    boolean b4 = false;
                    Label_0159: {
                        boolean b3 = false;
                        Label_0144: {
                            Label_0094: {
                                boolean b2 = false;
                                Label_0077: {
                                    Label_0055: {
                                        File file4 = null;
                                        Label_0041: {
                                            Label_0019: {
                                                try {
                                                    final File file3 = file;
                                                    file4 = file;
                                                    if (c == 0) {
                                                        break Label_0041;
                                                    }
                                                    if (file == null) {
                                                        break Label_0019;
                                                    }
                                                    break Label_0019;
                                                }
                                                catch (IOException ex) {
                                                    throw b(ex);
                                                }
                                                try {
                                                    if (file == null) {
                                                        throw new NullPointerException(a(2757, -31686));
                                                    }
                                                }
                                                catch (IOException ex2) {
                                                    throw b(ex2);
                                                }
                                            }
                                            final File file3 = file2;
                                            file4 = file2;
                                            try {
                                                if (c == 0) {
                                                    break Label_0077;
                                                }
                                                if (file4 == null) {
                                                    break Label_0055;
                                                }
                                                break Label_0055;
                                            }
                                            catch (IOException ex3) {
                                                throw b(ex3);
                                            }
                                        }
                                        try {
                                            if (file4 == null) {
                                                throw new NullPointerException(a(2773, 27064));
                                            }
                                        }
                                        catch (IOException ex4) {
                                            throw b(ex4);
                                        }
                                    }
                                    final File file3 = file;
                                    try {
                                        b2 = (b3 = q.kc(file3));
                                        if (c == 0) {
                                            break Label_0159;
                                        }
                                        if (!b2) {
                                            break Label_0094;
                                        }
                                        break Label_0144;
                                    }
                                    catch (IOException ex5) {
                                        throw b(ex5);
                                    }
                                }
                                try {
                                    if (!b2) {
                                        throw new FileNotFoundException(q.s(q.r(q.kx(q.r(new StringBuilder(), a(2761, 655)), file), a(2739, -14564))));
                                    }
                                }
                                catch (IOException ex6) {
                                    throw b(ex6);
                                }
                            }
                            try {
                                file5 = file;
                                file6 = file;
                                if (c == 0) {
                                    break Label_0180;
                                }
                                b3 = q.su(file);
                            }
                            catch (IOException ex7) {
                                throw b(ex7);
                            }
                        }
                        try {
                            if (!b3) {
                                break Label_0179;
                            }
                            file6 = file;
                            file7 = file2;
                            b4 = b;
                        }
                        catch (IOException ex8) {
                            throw b(ex8);
                        }
                    }
                    moveDirectoryToDirectory(file6, file7, b4);
                    if (c != 0) {
                        return;
                    }
                }
                file5 = file;
                File file6 = file;
            }
            File file7 = file2;
            boolean b4 = b;
            if (c == 0) {
                continue;
            }
            break;
        }
        moveFileToDirectory(file5, file2, b);
    }
    
    public static boolean isSymlink(final File file) throws IOException {
        final int b = IOCase.b();
        while (true) {
            Label_0026: {
                boolean atLeastJava7;
                try {
                    atLeastJava7 = Java7Support.isAtLeastJava7();
                    if (b != 0) {
                        return atLeastJava7;
                    }
                    if (!atLeastJava7) {
                        break Label_0026;
                    }
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                final File file2 = file;
                Java7Support.isSymLink(file2);
                return atLeastJava7;
            }
            final File file2 = file;
            if (b == 0) {
                try {
                    if (file == null) {
                        throw new NullPointerException(a(2778, -12868));
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
                Label_0085: {
                    boolean systemWindows = false;
                    Label_0073: {
                        try {
                            systemWindows = FilenameUtils.isSystemWindows();
                            if (b != 0) {
                                return systemWindows;
                            }
                            final int n = b;
                            if (n == 0) {
                                break Label_0073;
                            }
                            return systemWindows;
                        }
                        catch (IOException ex3) {
                            throw b(ex3);
                        }
                        try {
                            final int n = b;
                            if (n != 0) {
                                return systemWindows;
                            }
                            if (!systemWindows) {
                                break Label_0085;
                            }
                        }
                        catch (IOException ex4) {
                            throw b(ex4);
                        }
                    }
                    return systemWindows;
                }
                Label_0179: {
                    boolean brokenSymlink = false;
                    Label_0167: {
                        boolean b2 = false;
                        Label_0142: {
                            File file4 = null;
                            while (true) {
                                File ew = null;
                                Label_0124: {
                                    Label_0117: {
                                        Label_0105: {
                                            try {
                                                ew = file;
                                                if (b != 0) {
                                                    break Label_0124;
                                                }
                                                final String s = q.pe(file);
                                                if (s == null) {
                                                    break Label_0105;
                                                }
                                                break Label_0117;
                                            }
                                            catch (IOException ex5) {
                                                throw b(ex5);
                                            }
                                            try {
                                                final String s = q.pe(file);
                                                if (s != null) {
                                                    break Label_0117;
                                                }
                                            }
                                            catch (IOException ex6) {
                                                throw b(ex6);
                                            }
                                        }
                                        final File file3 = file4;
                                        break Label_0142;
                                    }
                                    ew = q.ew(q.ep(file));
                                }
                                file4 = new File(ew, q.mh(file));
                                if (b != 0) {
                                    continue;
                                }
                                break;
                            }
                            final File file3 = file4;
                            try {
                                final boolean ek;
                                b2 = (ek = q.ek(q.ew(file3), q.pn(file3)));
                                if (b != 0) {
                                    return ek;
                                }
                                if (b2) {
                                    break Label_0167;
                                }
                                break Label_0179;
                            }
                            catch (IOException ex7) {
                                throw b(ex7);
                            }
                        }
                        try {
                            if (!b2) {
                                break Label_0179;
                            }
                            brokenSymlink = isBrokenSymlink(file);
                        }
                        catch (IOException ex8) {
                            throw b(ex8);
                        }
                    }
                    return brokenSymlink;
                }
                boolean brokenSymlink;
                boolean ek = brokenSymlink = true;
                if (b != 0) {
                    return brokenSymlink;
                }
                return ek;
            }
            continue;
        }
    }
    
    private static boolean isBrokenSymlink(final File file) throws IOException {
        final int c = IOCase.c();
        File ew = null;
        Label_0039: {
            Label_0035: {
                Label_0023: {
                    try {
                        ew = file;
                        if (c == 0) {
                            break Label_0039;
                        }
                        final boolean b2;
                        final boolean b = b2 = q.kc(file);
                        final int n = c;
                        if (n != 0) {
                            break Label_0023;
                        }
                        return b;
                    }
                    catch (IOException ex) {
                        throw b(ex);
                    }
                    try {
                        final boolean b2;
                        final boolean b = b2 = q.kc(file);
                        final int n = c;
                        if (n == 0) {
                            return b;
                        }
                        if (!b2) {
                            break Label_0035;
                        }
                    }
                    catch (IOException ex2) {
                        throw b(ex2);
                    }
                }
                return false;
            }
            ew = q.ew(file);
        }
        final File file2 = ew;
        final File ep = q.ep(file2);
        File file4 = null;
        Label_0096: {
            Label_0095: {
                boolean b3 = false;
                Label_0082: {
                    boolean kc = false;
                    Label_0061: {
                        File file3;
                        try {
                            file3 = (file4 = ep);
                            if (c == 0) {
                                break Label_0061;
                            }
                            if (file3 == null) {
                                break Label_0082;
                            }
                        }
                        catch (IOException ex3) {
                            throw b(ex3);
                        }
                        final File file5;
                        file4 = (file5 = ep);
                        try {
                            if (c == 0) {
                                break Label_0096;
                            }
                            b3 = (kc = q.kc(file3));
                        }
                        catch (IOException ex4) {
                            throw b(ex4);
                        }
                    }
                    while (true) {
                        if (c == 0) {
                            return b3;
                        }
                        try {
                            if (kc) {
                                break Label_0095;
                            }
                            b3 = (kc = false);
                            if (c == 0) {
                                continue;
                            }
                        }
                        catch (IOException ex5) {
                            throw b(ex5);
                        }
                        break;
                    }
                }
                return b3;
            }
            file4 = ep;
        }
        final File[] si = q.si(file4, new FileUtils$1(file2));
        Label_0154: {
            int length = 0;
            int n3 = 0;
            Label_0138: {
                File[] array = null;
                Label_0126: {
                    try {
                        array = si;
                        if (c == 0) {
                            break Label_0138;
                        }
                        final int n2 = c;
                        if (n2 != 0) {
                            break Label_0126;
                        }
                        break Label_0138;
                    }
                    catch (IOException ex6) {
                        throw b(ex6);
                    }
                    try {
                        final int n2 = c;
                        if (n2 == 0) {
                            break Label_0138;
                        }
                        if (array == null) {
                            return false;
                        }
                    }
                    catch (IOException ex7) {
                        throw b(ex7);
                    }
                }
                try {
                    n3 = (length = array.length);
                    if (c == 0) {
                        return length != 0;
                    }
                    final int n4 = c;
                    if (n4 != 0) {
                        break Label_0154;
                    }
                    return length != 0;
                }
                catch (IOException ex8) {
                    throw b(ex8);
                }
            }
            try {
                final int n4 = c;
                if (n4 == 0) {
                    return length != 0;
                }
                if (n3 <= 0) {
                    return false;
                }
            }
            catch (IOException ex9) {
                throw b(ex9);
            }
        }
        int length = 1;
        return length != 0;
        length = 0;
        return length != 0;
    }
    
    static {
        final String[] a2 = new String[67];
        int n = 0;
        String s;
        int n2 = q.q(s = n.d.a.d.q.vx());
        int n3 = 32;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 109));
                ++n4;
                final String s2 = s;
                final int n9 = n4;
                String s3 = q.h(s2, n9, n9 + n3);
                int n10 = -1;
                while (true) {
                    final char[] g = q.g(s3);
                    final int length = g.length;
                    int n11 = 0;
                    while (true) {
                        Label_0264: {
                            if (length > 1) {
                                break Label_0264;
                            }
                            n7 = (n6 = n11);
                            do {
                                final char c = g[n6];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 85;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 23;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 117;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 123;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 29;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 81;
                                        break;
                                    }
                                    default: {
                                        n12 = 90;
                                        break;
                                    }
                                }
                                g[n7] = (char)(c ^ (n5 ^ n12));
                                ++n11;
                            } while (n8 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.z(new String(g));
                    switch (n10) {
                        default: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                continue Label_0024;
                            }
                            n2 = q.q(s = n.d.a.d.q.vh());
                            n3 = 35;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 92)));
                    ++n4;
                    final String s4 = s;
                    final int n13 = n4;
                    s3 = q.h(s4, n13, n13 + n3);
                    n10 = 0;
                }
            }
            break;
        }
        a = a2;
        b = new String[67];
        ONE_KB_BI = q.ej(1024L);
        ONE_MB_BI = q.pp(FileUtils.ONE_KB_BI, FileUtils.ONE_KB_BI);
        ONE_GB_BI = q.pp(FileUtils.ONE_KB_BI, FileUtils.ONE_MB_BI);
        ONE_TB_BI = q.pp(FileUtils.ONE_KB_BI, FileUtils.ONE_GB_BI);
        ONE_PB_BI = q.pp(FileUtils.ONE_KB_BI, FileUtils.ONE_TB_BI);
        ONE_EB_BI = q.pp(FileUtils.ONE_KB_BI, FileUtils.ONE_PB_BI);
        ONE_ZB = q.pp(q.ej(1024L), q.ej(1152921504606846976L));
        ONE_YB = q.pp(FileUtils.ONE_KB_BI, FileUtils.ONE_ZB);
        EMPTY_FILE_ARRAY = new File[0];
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0xAF3) & 0xFFFF;
        if (FileUtils.b[n3] == null) {
            final char[] g = q.g(FileUtils.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 250;
                    break;
                }
                case 1: {
                    n4 = 238;
                    break;
                }
                case 2: {
                    n4 = 168;
                    break;
                }
                case 3: {
                    n4 = 137;
                    break;
                }
                case 4: {
                    n4 = 128;
                    break;
                }
                case 5: {
                    n4 = 127;
                    break;
                }
                case 6: {
                    n4 = 41;
                    break;
                }
                case 7: {
                    n4 = 23;
                    break;
                }
                case 8: {
                    n4 = 188;
                    break;
                }
                case 9: {
                    n4 = 236;
                    break;
                }
                case 10: {
                    n4 = 208;
                    break;
                }
                case 11: {
                    n4 = 3;
                    break;
                }
                case 12: {
                    n4 = 44;
                    break;
                }
                case 13: {
                    n4 = 254;
                    break;
                }
                case 14: {
                    n4 = 37;
                    break;
                }
                case 15: {
                    n4 = 38;
                    break;
                }
                case 16: {
                    n4 = 65;
                    break;
                }
                case 17: {
                    n4 = 56;
                    break;
                }
                case 18: {
                    n4 = 207;
                    break;
                }
                case 19: {
                    n4 = 35;
                    break;
                }
                case 20: {
                    n4 = 108;
                    break;
                }
                case 21: {
                    n4 = 230;
                    break;
                }
                case 22: {
                    n4 = 102;
                    break;
                }
                case 23: {
                    n4 = 156;
                    break;
                }
                case 24: {
                    n4 = 136;
                    break;
                }
                case 25: {
                    n4 = 178;
                    break;
                }
                case 26: {
                    n4 = 104;
                    break;
                }
                case 27: {
                    n4 = 163;
                    break;
                }
                case 28: {
                    n4 = 141;
                    break;
                }
                case 29: {
                    n4 = 157;
                    break;
                }
                case 30: {
                    n4 = 84;
                    break;
                }
                case 31: {
                    n4 = 50;
                    break;
                }
                case 32: {
                    n4 = 219;
                    break;
                }
                case 33: {
                    n4 = 76;
                    break;
                }
                case 34: {
                    n4 = 167;
                    break;
                }
                case 35: {
                    n4 = 202;
                    break;
                }
                case 36: {
                    n4 = 148;
                    break;
                }
                case 37: {
                    n4 = 239;
                    break;
                }
                case 38: {
                    n4 = 52;
                    break;
                }
                case 39: {
                    n4 = 114;
                    break;
                }
                case 40: {
                    n4 = 172;
                    break;
                }
                case 41: {
                    n4 = 91;
                    break;
                }
                case 42: {
                    n4 = 9;
                    break;
                }
                case 43: {
                    n4 = 111;
                    break;
                }
                case 44: {
                    n4 = 171;
                    break;
                }
                case 45: {
                    n4 = 118;
                    break;
                }
                case 46: {
                    n4 = 213;
                    break;
                }
                case 47: {
                    n4 = 83;
                    break;
                }
                case 48: {
                    n4 = 20;
                    break;
                }
                case 49: {
                    n4 = 13;
                    break;
                }
                case 50: {
                    n4 = 106;
                    break;
                }
                case 51: {
                    n4 = 139;
                    break;
                }
                case 52: {
                    n4 = 120;
                    break;
                }
                case 53: {
                    n4 = 75;
                    break;
                }
                case 54: {
                    n4 = 204;
                    break;
                }
                case 55: {
                    n4 = 195;
                    break;
                }
                case 56: {
                    n4 = 154;
                    break;
                }
                case 57: {
                    n4 = 132;
                    break;
                }
                case 58: {
                    n4 = 100;
                    break;
                }
                case 59: {
                    n4 = 39;
                    break;
                }
                case 60: {
                    n4 = 64;
                    break;
                }
                case 61: {
                    n4 = 61;
                    break;
                }
                case 62: {
                    n4 = 122;
                    break;
                }
                case 63: {
                    n4 = 221;
                    break;
                }
                case 64: {
                    n4 = 138;
                    break;
                }
                case 65: {
                    n4 = 214;
                    break;
                }
                case 66: {
                    n4 = 0;
                    break;
                }
                case 67: {
                    n4 = 252;
                    break;
                }
                case 68: {
                    n4 = 124;
                    break;
                }
                case 69: {
                    n4 = 36;
                    break;
                }
                case 70: {
                    n4 = 229;
                    break;
                }
                case 71: {
                    n4 = 190;
                    break;
                }
                case 72: {
                    n4 = 201;
                    break;
                }
                case 73: {
                    n4 = 6;
                    break;
                }
                case 74: {
                    n4 = 95;
                    break;
                }
                case 75: {
                    n4 = 105;
                    break;
                }
                case 76: {
                    n4 = 8;
                    break;
                }
                case 77: {
                    n4 = 131;
                    break;
                }
                case 78: {
                    n4 = 177;
                    break;
                }
                case 79: {
                    n4 = 159;
                    break;
                }
                case 80: {
                    n4 = 10;
                    break;
                }
                case 81: {
                    n4 = 12;
                    break;
                }
                case 82: {
                    n4 = 49;
                    break;
                }
                case 83: {
                    n4 = 88;
                    break;
                }
                case 84: {
                    n4 = 130;
                    break;
                }
                case 85: {
                    n4 = 19;
                    break;
                }
                case 86: {
                    n4 = 200;
                    break;
                }
                case 87: {
                    n4 = 193;
                    break;
                }
                case 88: {
                    n4 = 144;
                    break;
                }
                case 89: {
                    n4 = 24;
                    break;
                }
                case 90: {
                    n4 = 28;
                    break;
                }
                case 91: {
                    n4 = 7;
                    break;
                }
                case 92: {
                    n4 = 227;
                    break;
                }
                case 93: {
                    n4 = 58;
                    break;
                }
                case 94: {
                    n4 = 183;
                    break;
                }
                case 95: {
                    n4 = 243;
                    break;
                }
                case 96: {
                    n4 = 247;
                    break;
                }
                case 97: {
                    n4 = 145;
                    break;
                }
                case 98: {
                    n4 = 33;
                    break;
                }
                case 99: {
                    n4 = 77;
                    break;
                }
                case 100: {
                    n4 = 55;
                    break;
                }
                case 101: {
                    n4 = 231;
                    break;
                }
                case 102: {
                    n4 = 192;
                    break;
                }
                case 103: {
                    n4 = 217;
                    break;
                }
                case 104: {
                    n4 = 34;
                    break;
                }
                case 105: {
                    n4 = 222;
                    break;
                }
                case 106: {
                    n4 = 166;
                    break;
                }
                case 107: {
                    n4 = 47;
                    break;
                }
                case 108: {
                    n4 = 211;
                    break;
                }
                case 109: {
                    n4 = 27;
                    break;
                }
                case 110: {
                    n4 = 112;
                    break;
                }
                case 111: {
                    n4 = 225;
                    break;
                }
                case 112: {
                    n4 = 246;
                    break;
                }
                case 113: {
                    n4 = 48;
                    break;
                }
                case 114: {
                    n4 = 46;
                    break;
                }
                case 115: {
                    n4 = 186;
                    break;
                }
                case 116: {
                    n4 = 234;
                    break;
                }
                case 117: {
                    n4 = 116;
                    break;
                }
                case 118: {
                    n4 = 79;
                    break;
                }
                case 119: {
                    n4 = 22;
                    break;
                }
                case 120: {
                    n4 = 184;
                    break;
                }
                case 121: {
                    n4 = 151;
                    break;
                }
                case 122: {
                    n4 = 226;
                    break;
                }
                case 123: {
                    n4 = 174;
                    break;
                }
                case 124: {
                    n4 = 5;
                    break;
                }
                case 125: {
                    n4 = 196;
                    break;
                }
                case 126: {
                    n4 = 152;
                    break;
                }
                case 127: {
                    n4 = 240;
                    break;
                }
                case 128: {
                    n4 = 149;
                    break;
                }
                case 129: {
                    n4 = 143;
                    break;
                }
                case 130: {
                    n4 = 228;
                    break;
                }
                case 131: {
                    n4 = 158;
                    break;
                }
                case 132: {
                    n4 = 133;
                    break;
                }
                case 133: {
                    n4 = 249;
                    break;
                }
                case 134: {
                    n4 = 203;
                    break;
                }
                case 135: {
                    n4 = 175;
                    break;
                }
                case 136: {
                    n4 = 155;
                    break;
                }
                case 137: {
                    n4 = 67;
                    break;
                }
                case 138: {
                    n4 = 218;
                    break;
                }
                case 139: {
                    n4 = 11;
                    break;
                }
                case 140: {
                    n4 = 210;
                    break;
                }
                case 141: {
                    n4 = 140;
                    break;
                }
                case 142: {
                    n4 = 215;
                    break;
                }
                case 143: {
                    n4 = 164;
                    break;
                }
                case 144: {
                    n4 = 107;
                    break;
                }
                case 145: {
                    n4 = 181;
                    break;
                }
                case 146: {
                    n4 = 26;
                    break;
                }
                case 147: {
                    n4 = 68;
                    break;
                }
                case 148: {
                    n4 = 119;
                    break;
                }
                case 149: {
                    n4 = 115;
                    break;
                }
                case 150: {
                    n4 = 194;
                    break;
                }
                case 151: {
                    n4 = 191;
                    break;
                }
                case 152: {
                    n4 = 245;
                    break;
                }
                case 153: {
                    n4 = 92;
                    break;
                }
                case 154: {
                    n4 = 129;
                    break;
                }
                case 155: {
                    n4 = 78;
                    break;
                }
                case 156: {
                    n4 = 63;
                    break;
                }
                case 157: {
                    n4 = 30;
                    break;
                }
                case 158: {
                    n4 = 70;
                    break;
                }
                case 159: {
                    n4 = 170;
                    break;
                }
                case 160: {
                    n4 = 134;
                    break;
                }
                case 161: {
                    n4 = 176;
                    break;
                }
                case 162: {
                    n4 = 180;
                    break;
                }
                case 163: {
                    n4 = 182;
                    break;
                }
                case 164: {
                    n4 = 99;
                    break;
                }
                case 165: {
                    n4 = 16;
                    break;
                }
                case 166: {
                    n4 = 162;
                    break;
                }
                case 167: {
                    n4 = 73;
                    break;
                }
                case 168: {
                    n4 = 146;
                    break;
                }
                case 169: {
                    n4 = 199;
                    break;
                }
                case 170: {
                    n4 = 147;
                    break;
                }
                case 171: {
                    n4 = 244;
                    break;
                }
                case 172: {
                    n4 = 255;
                    break;
                }
                case 173: {
                    n4 = 160;
                    break;
                }
                case 174: {
                    n4 = 18;
                    break;
                }
                case 175: {
                    n4 = 223;
                    break;
                }
                case 176: {
                    n4 = 1;
                    break;
                }
                case 177: {
                    n4 = 86;
                    break;
                }
                case 178: {
                    n4 = 126;
                    break;
                }
                case 179: {
                    n4 = 25;
                    break;
                }
                case 180: {
                    n4 = 121;
                    break;
                }
                case 181: {
                    n4 = 15;
                    break;
                }
                case 182: {
                    n4 = 241;
                    break;
                }
                case 183: {
                    n4 = 232;
                    break;
                }
                case 184: {
                    n4 = 45;
                    break;
                }
                case 185: {
                    n4 = 72;
                    break;
                }
                case 186: {
                    n4 = 98;
                    break;
                }
                case 187: {
                    n4 = 96;
                    break;
                }
                case 188: {
                    n4 = 21;
                    break;
                }
                case 189: {
                    n4 = 123;
                    break;
                }
                case 190: {
                    n4 = 197;
                    break;
                }
                case 191: {
                    n4 = 2;
                    break;
                }
                case 192: {
                    n4 = 32;
                    break;
                }
                case 193: {
                    n4 = 87;
                    break;
                }
                case 194: {
                    n4 = 31;
                    break;
                }
                case 195: {
                    n4 = 71;
                    break;
                }
                case 196: {
                    n4 = 237;
                    break;
                }
                case 197: {
                    n4 = 51;
                    break;
                }
                case 198: {
                    n4 = 94;
                    break;
                }
                case 199: {
                    n4 = 187;
                    break;
                }
                case 200: {
                    n4 = 189;
                    break;
                }
                case 201: {
                    n4 = 109;
                    break;
                }
                case 202: {
                    n4 = 206;
                    break;
                }
                case 203: {
                    n4 = 90;
                    break;
                }
                case 204: {
                    n4 = 173;
                    break;
                }
                case 205: {
                    n4 = 209;
                    break;
                }
                case 206: {
                    n4 = 248;
                    break;
                }
                case 207: {
                    n4 = 80;
                    break;
                }
                case 208: {
                    n4 = 74;
                    break;
                }
                case 209: {
                    n4 = 253;
                    break;
                }
                case 210: {
                    n4 = 205;
                    break;
                }
                case 211: {
                    n4 = 212;
                    break;
                }
                case 212: {
                    n4 = 53;
                    break;
                }
                case 213: {
                    n4 = 216;
                    break;
                }
                case 214: {
                    n4 = 110;
                    break;
                }
                case 215: {
                    n4 = 14;
                    break;
                }
                case 216: {
                    n4 = 220;
                    break;
                }
                case 217: {
                    n4 = 125;
                    break;
                }
                case 218: {
                    n4 = 198;
                    break;
                }
                case 219: {
                    n4 = 43;
                    break;
                }
                case 220: {
                    n4 = 57;
                    break;
                }
                case 221: {
                    n4 = 142;
                    break;
                }
                case 222: {
                    n4 = 85;
                    break;
                }
                case 223: {
                    n4 = 54;
                    break;
                }
                case 224: {
                    n4 = 233;
                    break;
                }
                case 225: {
                    n4 = 153;
                    break;
                }
                case 226: {
                    n4 = 97;
                    break;
                }
                case 227: {
                    n4 = 150;
                    break;
                }
                case 228: {
                    n4 = 59;
                    break;
                }
                case 229: {
                    n4 = 69;
                    break;
                }
                case 230: {
                    n4 = 93;
                    break;
                }
                case 231: {
                    n4 = 42;
                    break;
                }
                case 232: {
                    n4 = 251;
                    break;
                }
                case 233: {
                    n4 = 82;
                    break;
                }
                case 234: {
                    n4 = 161;
                    break;
                }
                case 235: {
                    n4 = 113;
                    break;
                }
                case 236: {
                    n4 = 81;
                    break;
                }
                case 237: {
                    n4 = 185;
                    break;
                }
                case 238: {
                    n4 = 235;
                    break;
                }
                case 239: {
                    n4 = 29;
                    break;
                }
                case 240: {
                    n4 = 101;
                    break;
                }
                case 241: {
                    n4 = 165;
                    break;
                }
                case 242: {
                    n4 = 103;
                    break;
                }
                case 243: {
                    n4 = 135;
                    break;
                }
                case 244: {
                    n4 = 66;
                    break;
                }
                case 245: {
                    n4 = 17;
                    break;
                }
                case 246: {
                    n4 = 242;
                    break;
                }
                case 247: {
                    n4 = 62;
                    break;
                }
                case 248: {
                    n4 = 179;
                    break;
                }
                case 249: {
                    n4 = 117;
                    break;
                }
                case 250: {
                    n4 = 60;
                    break;
                }
                case 251: {
                    n4 = 89;
                    break;
                }
                case 252: {
                    n4 = 224;
                    break;
                }
                case 253: {
                    n4 = 40;
                    break;
                }
                case 254: {
                    n4 = 4;
                    break;
                }
                default: {
                    n4 = 169;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            FileUtils.b[n3] = q.z(new String(g));
        }
        return FileUtils.b[n3];
    }
}
