// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import n.d.a.d.q;

final class FileCleaningTracker$Reaper extends Thread
{
    final FileCleaningTracker this$0;
    private static final String a;
    
    FileCleaningTracker$Reaper(final FileCleaningTracker this$0) {
        this.this$0 = this$0;
        super(FileCleaningTracker$Reaper.a);
        this.setPriority(10);
        this.setDaemon(true);
    }
    
    @Override
    public void run() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: getfield        org/apache/commons/io/FileCleaningTracker$Reaper.this$0:Lorg/apache/commons/io/FileCleaningTracker;
        //     8: getfield        org/apache/commons/io/FileCleaningTracker.exitWhenFinished:Z
        //    11: ifeq            67
        //    14: aload_0        
        //    15: getfield        org/apache/commons/io/FileCleaningTracker$Reaper.this$0:Lorg/apache/commons/io/FileCleaningTracker;
        //    18: iload_1        
        //    19: ifeq            71
        //    22: goto            29
        //    25: invokestatic    org/apache/commons/io/FileCleaningTracker$Reaper.b:(Ljava/lang/InterruptedException;)Ljava/lang/InterruptedException;
        //    28: athrow         
        //    29: iload_1        
        //    30: ifeq            71
        //    33: goto            40
        //    36: invokestatic    org/apache/commons/io/FileCleaningTracker$Reaper.b:(Ljava/lang/InterruptedException;)Ljava/lang/InterruptedException;
        //    39: athrow         
        //    40: iload_1        
        //    41: ifeq            71
        //    44: goto            51
        //    47: invokestatic    org/apache/commons/io/FileCleaningTracker$Reaper.b:(Ljava/lang/InterruptedException;)Ljava/lang/InterruptedException;
        //    50: athrow         
        //    51: getfield        org/apache/commons/io/FileCleaningTracker.trackers:Ljava/util/Collection;
        //    54: invokestatic    q/o/m/s/q.kr:(Ljava/util/Collection;)I
        //    57: ifle            156
        //    60: goto            67
        //    63: invokestatic    org/apache/commons/io/FileCleaningTracker$Reaper.b:(Ljava/lang/InterruptedException;)Ljava/lang/InterruptedException;
        //    66: athrow         
        //    67: aload_0        
        //    68: getfield        org/apache/commons/io/FileCleaningTracker$Reaper.this$0:Lorg/apache/commons/io/FileCleaningTracker;
        //    71: getfield        org/apache/commons/io/FileCleaningTracker.q:Ljava/lang/ref/ReferenceQueue;
        //    74: invokestatic    q/o/m/s/q.ks:(Ljava/lang/ref/ReferenceQueue;)Ljava/lang/ref/Reference;
        //    77: checkcast       Lorg/apache/commons/io/FileCleaningTracker$Tracker;
        //    80: astore_2       
        //    81: aload_0        
        //    82: getfield        org/apache/commons/io/FileCleaningTracker$Reaper.this$0:Lorg/apache/commons/io/FileCleaningTracker;
        //    85: getfield        org/apache/commons/io/FileCleaningTracker.trackers:Ljava/util/Collection;
        //    88: aload_2        
        //    89: invokestatic    q/o/m/s/q.kk:(Ljava/util/Collection;Ljava/lang/Object;)Z
        //    92: pop            
        //    93: aload_2        
        //    94: iload_1        
        //    95: ifeq            145
        //    98: invokevirtual   org/apache/commons/io/FileCleaningTracker$Tracker.delete:()Z
        //   101: iload_1        
        //   102: ifeq            143
        //   105: goto            112
        //   108: invokestatic    org/apache/commons/io/FileCleaningTracker$Reaper.b:(Ljava/lang/InterruptedException;)Ljava/lang/InterruptedException;
        //   111: athrow         
        //   112: ifne            144
        //   115: goto            122
        //   118: invokestatic    org/apache/commons/io/FileCleaningTracker$Reaper.b:(Ljava/lang/InterruptedException;)Ljava/lang/InterruptedException;
        //   121: athrow         
        //   122: aload_0        
        //   123: getfield        org/apache/commons/io/FileCleaningTracker$Reaper.this$0:Lorg/apache/commons/io/FileCleaningTracker;
        //   126: getfield        org/apache/commons/io/FileCleaningTracker.deleteFailures:Ljava/util/List;
        //   129: aload_2        
        //   130: invokevirtual   org/apache/commons/io/FileCleaningTracker$Tracker.getPath:()Ljava/lang/String;
        //   133: invokestatic    q/o/m/s/q.qw:(Ljava/util/List;Ljava/lang/Object;)Z
        //   136: goto            143
        //   139: invokestatic    org/apache/commons/io/FileCleaningTracker$Reaper.b:(Ljava/lang/InterruptedException;)Ljava/lang/InterruptedException;
        //   142: athrow         
        //   143: pop            
        //   144: aload_2        
        //   145: invokevirtual   org/apache/commons/io/FileCleaningTracker$Tracker.clear:()V
        //   148: goto            4
        //   151: astore_2       
        //   152: iload_1        
        //   153: ifne            4
        //   156: return         
        //    StackMapTable: 00 14 FC 00 04 01 54 07 00 1E 43 07 00 26 46 07 00 1E 43 07 00 26 46 07 00 1E 43 07 00 26 4B 07 00 1E 03 43 07 00 26 FF 00 24 00 03 07 00 02 01 07 00 42 00 01 07 00 1E 43 01 45 07 00 1E 03 50 07 00 1E 43 01 00 40 07 00 42 FF 00 05 00 02 07 00 02 01 00 01 07 00 1E 04
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  112    136    139    143    Ljava/lang/InterruptedException;
        //  98     115    118    122    Ljava/lang/InterruptedException;
        //  81     105    108    112    Ljava/lang/InterruptedException;
        //  40     60     63     67     Ljava/lang/InterruptedException;
        //  29     44     47     51     Ljava/lang/InterruptedException;
        //  14     33     36     40     Ljava/lang/InterruptedException;
        //  4      22     25     29     Ljava/lang/InterruptedException;
        //  67     148    151    156    Ljava/lang/InterruptedException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0029:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static InterruptedException b(final InterruptedException ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 79);
        final char[] g = q.o.m.s.q.g(q.vm());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0127: {
                if (length > 1) {
                    break Label_0127;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 32;
                            break;
                        }
                        case 1: {
                            n5 = 34;
                            break;
                        }
                        case 2: {
                            n5 = 76;
                            break;
                        }
                        case 3: {
                            n5 = 116;
                            break;
                        }
                        case 4: {
                            n5 = 20;
                            break;
                        }
                        case 5: {
                            n5 = 1;
                            break;
                        }
                        default: {
                            n5 = 52;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.o.m.s.q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
