// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import q.o.m.s.q;
import java.io.File;
import java.lang.reflect.Method;

class Java7Support
{
    private static final boolean IS_JAVA7;
    private static Method isSymbolicLink;
    private static Method delete;
    private static Method toPath;
    private static Method exists;
    private static Method toFile;
    private static Method readSymlink;
    private static Method createSymlink;
    private static Object emptyLinkOpts;
    private static Object emptyFileAttributes;
    
    public static boolean isSymLink(final File file) {
        try {
            return q.yl((Boolean)q.qz(Java7Support.isSymbolicLink, null, new Object[] { q.qz(Java7Support.toPath, file, new Object[0]) }));
        }
        catch (IllegalAccessException cause) {
            throw new RuntimeException(cause);
        }
        catch (InvocationTargetException cause2) {
            throw new RuntimeException(cause2);
        }
    }
    
    public static File readSymbolicLink(final File file) throws IOException {
        try {
            return (File)q.qz(Java7Support.toFile, q.qz(Java7Support.readSymlink, null, new Object[] { q.qz(Java7Support.toPath, file, new Object[0]) }), new Object[0]);
        }
        catch (IllegalAccessException cause) {
            throw new RuntimeException(cause);
        }
        catch (InvocationTargetException cause2) {
            throw new RuntimeException(cause2);
        }
    }
    
    private static boolean exists(final File file) throws IOException {
        try {
            return q.yl((Boolean)q.qz(Java7Support.exists, null, new Object[] { q.qz(Java7Support.toPath, file, new Object[0]), Java7Support.emptyLinkOpts }));
        }
        catch (IllegalAccessException cause) {
            throw new RuntimeException(cause);
        }
        catch (InvocationTargetException ex) {
            throw (RuntimeException)q.yi(ex);
        }
    }
    
    public static File createSymbolicLink(final File file, final File file2) throws IOException {
        final int b = IOCase.b();
        try {
            Label_0094: {
                Object qz = null;
                Label_0022: {
                    try {
                        final File file3 = file;
                        if (b != 0) {
                            return file3;
                        }
                        final boolean b2 = exists(file);
                        if (!b2) {
                            break Label_0022;
                        }
                        break Label_0094;
                    }
                    catch (IllegalAccessException ex) {
                        throw b(ex);
                    }
                    try {
                        final boolean b2 = exists(file);
                        if (b2) {
                            break Label_0094;
                        }
                        qz = q.qz(Java7Support.toPath, file, new Object[0]);
                    }
                    catch (IllegalAccessException ex2) {
                        throw b(ex2);
                    }
                }
                return (File)q.qz(Java7Support.toFile, q.qz(Java7Support.createSymlink, null, new Object[] { qz, q.qz(Java7Support.toPath, file2, new Object[0]), Java7Support.emptyFileAttributes }), new Object[0]);
            }
            final File file3 = file;
            Object qz = file;
            if (b != 0) {
                return (File)q.qz(Java7Support.toFile, q.qz(Java7Support.createSymlink, null, new Object[] { qz, q.qz(Java7Support.toPath, file2, new Object[0]), Java7Support.emptyFileAttributes }), new Object[0]);
            }
            return file3;
        }
        catch (IllegalAccessException cause) {
            throw new RuntimeException(cause);
        }
        catch (InvocationTargetException ex3) {
            throw (IOException)q.yi(ex3);
        }
    }
    
    public static void delete(final File file) throws IOException {
        try {
            q.qz(Java7Support.delete, null, new Object[] { q.qz(Java7Support.toPath, file, new Object[0]) });
        }
        catch (IllegalAccessException cause) {
            throw new RuntimeException(cause);
        }
        catch (InvocationTargetException ex) {
            throw (IOException)q.yi(ex);
        }
    }
    
    public static boolean isAtLeastJava7() {
        return Java7Support.IS_JAVA7;
    }
    
    static {
        final String[] array = new String[11];
        int n = 0;
        String s;
        int n2 = q.q(s = n.d.a.d.q.vu());
        int n3 = 19;
        int n4 = -1;
    Label_0025:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 15));
                ++n4;
                final String s2 = s;
                final int n9 = n4;
                String s3 = q.h(s2, n9, n9 + n3);
                int n10 = -1;
                while (true) {
                    final char[] g = q.g(s3);
                    final int length = g.length;
                    int n11 = 0;
                    while (true) {
                        Label_0256: {
                            if (length > 1) {
                                break Label_0256;
                            }
                            n7 = (n6 = n11);
                            do {
                                final char c = g[n6];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 91;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 94;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 125;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 45;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 103;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 33;
                                        break;
                                    }
                                    default: {
                                        n12 = 93;
                                        break;
                                    }
                                }
                                g[n7] = (char)(c ^ (n5 ^ n12));
                                ++n11;
                            } while (n8 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.z(new String(g));
                    switch (n10) {
                        default: {
                            array[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                continue Label_0025;
                            }
                            n2 = q.q(s = n.d.a.d.q.of());
                            n3 = 16;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                break;
                            }
                            break Label_0025;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 66)));
                    ++n4;
                    final String s4 = s;
                    final int n13 = n4;
                    s3 = q.h(s4, n13, n13 + n3);
                    n10 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        boolean is_JAVA7 = true;
        try {
            final ClassLoader yu = q.yu(q.ni());
            final Class cf = q.cf(yu, array2[0]);
            final Class cf2 = q.cf(yu, array2[2]);
            final Class cf3 = q.cf(yu, array2[7]);
            final Class cf4 = q.cf(yu, array2[8]);
            Java7Support.isSymbolicLink = q.cm(cf, array2[10], new Class[] { cf2 });
            Java7Support.delete = q.cm(cf, array2[4], new Class[] { cf2 });
            Java7Support.readSymlink = q.cm(cf, array2[9], new Class[] { cf2 });
            Java7Support.emptyFileAttributes = q.cv(cf3, 0);
            Java7Support.createSymlink = q.cm(cf, array2[3], new Class[] { cf2, cf2, q.qi(Java7Support.emptyFileAttributes) });
            Java7Support.emptyLinkOpts = q.cv(cf4, 0);
            Java7Support.exists = q.cm(cf, array2[6], new Class[] { cf2, q.qi(Java7Support.emptyLinkOpts) });
            Java7Support.toPath = q.cm(File.class, array2[5], new Class[0]);
            Java7Support.toFile = q.cm(cf2, array2[1], new Class[0]);
        }
        catch (ClassNotFoundException ex) {
            is_JAVA7 = false;
        }
        catch (NoSuchMethodException ex2) {
            is_JAVA7 = false;
        }
        IS_JAVA7 = is_JAVA7;
    }
    
    private static IllegalAccessException b(final IllegalAccessException ex) {
        return ex;
    }
}
