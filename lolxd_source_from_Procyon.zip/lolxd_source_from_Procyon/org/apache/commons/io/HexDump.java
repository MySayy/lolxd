// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import q.o.m.s.q;
import java.io.IOException;
import java.io.OutputStream;

public class HexDump
{
    public static final String EOL;
    private static final char[] _hexcodes;
    private static final int[] _shifts;
    private static final String[] a;
    private static final String[] b;
    
    public static void dump(final byte[] p0, final long p1, final OutputStream p2, final int p3) throws IOException, ArrayIndexOutOfBoundsException, IllegalArgumentException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore          5
        //     5: iload           4
        //     7: iload           5
        //     9: ifne            36
        //    12: iload           5
        //    14: ifne            36
        //    17: goto            24
        //    20: invokestatic    org/apache/commons/io/HexDump.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    23: athrow         
        //    24: iflt            41
        //    27: goto            34
        //    30: invokestatic    org/apache/commons/io/HexDump.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    33: athrow         
        //    34: iload           4
        //    36: aload_0        
        //    37: arraylength    
        //    38: if_icmplt       97
        //    41: new             Ljava/lang/ArrayIndexOutOfBoundsException;
        //    44: dup            
        //    45: new             Ljava/lang/StringBuilder;
        //    48: dup            
        //    49: invokespecial   java/lang/StringBuilder.<init>:()V
        //    52: sipush          7317
        //    55: sipush          10889
        //    58: invokestatic    org/apache/commons/io/HexDump.a:(II)Ljava/lang/String;
        //    61: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    64: iload           4
        //    66: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //    69: sipush          7319
        //    72: sipush          -1543
        //    75: invokestatic    org/apache/commons/io/HexDump.a:(II)Ljava/lang/String;
        //    78: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    81: aload_0        
        //    82: arraylength    
        //    83: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //    86: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    89: invokespecial   java/lang/ArrayIndexOutOfBoundsException.<init>:(Ljava/lang/String;)V
        //    92: athrow         
        //    93: invokestatic    org/apache/commons/io/HexDump.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    96: athrow         
        //    97: aload_3        
        //    98: ifnonnull       122
        //   101: new             Ljava/lang/IllegalArgumentException;
        //   104: dup            
        //   105: sipush          7312
        //   108: sipush          -26528
        //   111: invokestatic    org/apache/commons/io/HexDump.a:(II)Ljava/lang/String;
        //   114: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //   117: athrow         
        //   118: invokestatic    org/apache/commons/io/HexDump.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   121: athrow         
        //   122: lload_1        
        //   123: iload           4
        //   125: i2l            
        //   126: ladd           
        //   127: lstore          6
        //   129: new             Ljava/lang/StringBuilder;
        //   132: dup            
        //   133: bipush          74
        //   135: invokespecial   java/lang/StringBuilder.<init>:(I)V
        //   138: astore          8
        //   140: iload           4
        //   142: istore          9
        //   144: iload           9
        //   146: aload_0        
        //   147: arraylength    
        //   148: if_icmpge       470
        //   151: aload_0        
        //   152: arraylength    
        //   153: iload           9
        //   155: isub           
        //   156: istore          10
        //   158: iload           10
        //   160: iload           5
        //   162: ifne            207
        //   165: bipush          16
        //   167: if_icmple       188
        //   170: goto            177
        //   173: invokestatic    org/apache/commons/io/HexDump.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   176: athrow         
        //   177: bipush          16
        //   179: goto            186
        //   182: invokestatic    org/apache/commons/io/HexDump.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   185: athrow         
        //   186: istore          10
        //   188: aload           8
        //   190: lload           6
        //   192: invokestatic    org/apache/commons/io/HexDump.dump:(Ljava/lang/StringBuilder;J)Ljava/lang/StringBuilder;
        //   195: bipush          32
        //   197: invokestatic    q/o/m/s/q.sk:(Ljava/lang/StringBuilder;C)Ljava/lang/StringBuilder;
        //   200: pop            
        //   201: iconst_0       
        //   202: iload           5
        //   204: ifne            186
        //   207: istore          11
        //   209: iload           11
        //   211: bipush          16
        //   213: if_icmpge       296
        //   216: iload           11
        //   218: iload           10
        //   220: iload           5
        //   222: ifne            303
        //   225: if_icmpge       260
        //   228: goto            235
        //   231: invokestatic    org/apache/commons/io/HexDump.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   234: athrow         
        //   235: aload           8
        //   237: aload_0        
        //   238: iload           11
        //   240: iload           9
        //   242: iadd           
        //   243: baload         
        //   244: invokestatic    org/apache/commons/io/HexDump.dump:(Ljava/lang/StringBuilder;B)Ljava/lang/StringBuilder;
        //   247: goto            254
        //   250: invokestatic    org/apache/commons/io/HexDump.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   253: athrow         
        //   254: pop            
        //   255: iload           5
        //   257: ifeq            280
        //   260: aload           8
        //   262: sipush          7318
        //   265: sipush          -24021
        //   268: invokestatic    org/apache/commons/io/HexDump.a:(II)Ljava/lang/String;
        //   271: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   274: iload           5
        //   276: ifne            254
        //   279: pop            
        //   280: aload           8
        //   282: bipush          32
        //   284: invokestatic    q/o/m/s/q.sk:(Ljava/lang/StringBuilder;C)Ljava/lang/StringBuilder;
        //   287: pop            
        //   288: iinc            11, 1
        //   291: iload           5
        //   293: ifeq            209
        //   296: iconst_0       
        //   297: istore          11
        //   299: iload           11
        //   301: iload           10
        //   303: if_icmpge       420
        //   306: aload_0        
        //   307: iload           11
        //   309: iload           9
        //   311: iadd           
        //   312: baload         
        //   313: bipush          32
        //   315: iload           5
        //   317: ifne            148
        //   320: goto            327
        //   323: invokestatic    org/apache/commons/io/HexDump.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   326: athrow         
        //   327: iload           5
        //   329: ifne            370
        //   332: iload           5
        //   334: ifne            370
        //   337: goto            344
        //   340: invokestatic    org/apache/commons/io/HexDump.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   343: athrow         
        //   344: if_icmplt       399
        //   347: goto            354
        //   350: invokestatic    org/apache/commons/io/HexDump.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   353: athrow         
        //   354: aload_0        
        //   355: iload           11
        //   357: iload           9
        //   359: iadd           
        //   360: baload         
        //   361: bipush          127
        //   363: goto            370
        //   366: invokestatic    org/apache/commons/io/HexDump.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   369: athrow         
        //   370: if_icmpge       399
        //   373: aload           8
        //   375: aload_0        
        //   376: iload           11
        //   378: iload           9
        //   380: iadd           
        //   381: baload         
        //   382: i2c            
        //   383: invokestatic    q/o/m/s/q.sk:(Ljava/lang/StringBuilder;C)Ljava/lang/StringBuilder;
        //   386: goto            393
        //   389: invokestatic    org/apache/commons/io/HexDump.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   392: athrow         
        //   393: pop            
        //   394: iload           5
        //   396: ifeq            412
        //   399: aload           8
        //   401: bipush          46
        //   403: invokestatic    q/o/m/s/q.sk:(Ljava/lang/StringBuilder;C)Ljava/lang/StringBuilder;
        //   406: iload           5
        //   408: ifne            393
        //   411: pop            
        //   412: iinc            11, 1
        //   415: iload           5
        //   417: ifeq            299
        //   420: aload           8
        //   422: getstatic       org/apache/commons/io/HexDump.EOL:Ljava/lang/String;
        //   425: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   428: pop            
        //   429: aload_3        
        //   430: aload           8
        //   432: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   435: invokestatic    q/o/m/s/q.sx:()Ljava/nio/charset/Charset;
        //   438: invokestatic    q/o/m/s/q.yf:(Ljava/lang/String;Ljava/nio/charset/Charset;)[B
        //   441: invokestatic    q/o/m/s/q.sj:(Ljava/io/OutputStream;[B)V
        //   444: aload_3        
        //   445: invokestatic    q/o/m/s/q.ym:(Ljava/io/OutputStream;)V
        //   448: aload           8
        //   450: iconst_0       
        //   451: invokestatic    q/o/m/s/q.pl:(Ljava/lang/StringBuilder;I)V
        //   454: lload           6
        //   456: iload           10
        //   458: i2l            
        //   459: ladd           
        //   460: lstore          6
        //   462: iinc            9, 16
        //   465: iload           5
        //   467: ifeq            144
        //   470: return         
        //    Exceptions:
        //  throws java.io.IOException
        //  throws java.lang.ArrayIndexOutOfBoundsException
        //  throws java.lang.IllegalArgumentException
        //    StackMapTable: 00 2A FF 00 14 00 05 07 00 21 04 07 00 23 01 01 00 01 07 00 16 43 01 45 07 00 16 03 41 01 04 73 07 00 16 03 54 07 00 16 03 FE 00 15 04 07 00 28 01 FF 00 03 00 08 07 00 21 04 07 00 23 01 01 04 07 00 28 01 00 02 01 01 FF 00 18 00 09 07 00 21 04 07 00 23 01 01 04 07 00 28 01 01 00 01 07 00 16 03 44 07 00 16 43 01 01 52 01 FC 00 01 01 55 07 00 16 03 4E 07 00 16 43 07 00 28 05 13 0F 02 FF 00 03 00 0A 07 00 21 04 07 00 23 01 01 04 07 00 28 01 01 01 00 02 01 01 53 07 00 16 FF 00 03 00 0A 07 00 21 04 07 00 23 01 01 04 07 00 28 01 01 01 00 02 01 01 4C 07 00 16 FF 00 03 00 0A 07 00 21 04 07 00 23 01 01 04 07 00 28 01 01 01 00 02 01 01 45 07 00 16 03 4B 07 00 16 FF 00 03 00 0A 07 00 21 04 07 00 23 01 01 04 07 00 28 01 01 01 00 02 01 01 52 07 00 16 43 07 00 28 05 0C 07 F9 00 31
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  5      17     20     24     Ljava/io/IOException;
        //  12     27     30     34     Ljava/io/IOException;
        //  36     93     93     97     Ljava/io/IOException;
        //  97     118    118    122    Ljava/io/IOException;
        //  158    170    173    177    Ljava/io/IOException;
        //  165    179    182    186    Ljava/io/IOException;
        //  216    228    231    235    Ljava/io/IOException;
        //  225    247    250    254    Ljava/io/IOException;
        //  303    320    323    327    Ljava/io/IOException;
        //  327    337    340    344    Ljava/io/IOException;
        //  332    347    350    354    Ljava/io/IOException;
        //  344    363    366    370    Ljava/io/IOException;
        //  370    386    389    393    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0344:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static StringBuilder dump(final StringBuilder sb, final long n) {
        final int b = IOCase.b();
        int i = 0;
        final int n2 = b;
        while (i < 8) {
            try {
                final StringBuilder sk = q.sk(sb, HexDump._hexcodes[(int)(n >> HexDump._shifts[i]) & 0xF]);
                if (n2 != 0) {
                    return sk;
                }
                ++i;
                if (n2 == 0) {
                    continue;
                }
            }
            catch (ArrayIndexOutOfBoundsException ex) {
                throw b(ex);
            }
            break;
        }
        return sb;
    }
    
    private static StringBuilder dump(final StringBuilder sb, final byte b) {
        final int c = IOCase.c();
        int i = 0;
        final int n = c;
        while (i < 2) {
            try {
                final StringBuilder sk = q.sk(sb, HexDump._hexcodes[b >> HexDump._shifts[i + 6] & 0xF]);
                if (n == 0) {
                    return sk;
                }
                ++i;
                if (n != 0) {
                    continue;
                }
            }
            catch (ArrayIndexOutOfBoundsException ex) {
                throw b(ex);
            }
            break;
        }
        return sb;
    }
    
    static {
        final String[] a2 = new String[5];
        int n = 0;
        String s;
        int n2 = q.q(s = n.d.a.d.q.vd());
        int n3 = 14;
        int n4 = -1;
    Label_0023:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 87));
                ++n4;
                final String s2 = s;
                final int n9 = n4;
                String s3 = q.h(s2, n9, n9 + n3);
                int n10 = -1;
                while (true) {
                    final char[] g = q.g(s3);
                    final int length = g.length;
                    int n11 = 0;
                    while (true) {
                        Label_0260: {
                            if (length > 1) {
                                break Label_0260;
                            }
                            n7 = (n6 = n11);
                            do {
                                final char c = g[n6];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 56;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 83;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 34;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 68;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 14;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 106;
                                        break;
                                    }
                                    default: {
                                        n12 = 73;
                                        break;
                                    }
                                }
                                g[n7] = (char)(c ^ (n5 ^ n12));
                                ++n11;
                            } while (n8 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.z(new String(g));
                    switch (n10) {
                        default: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                continue Label_0023;
                            }
                            n2 = q.q(s = n.d.a.d.q.vb());
                            n3 = 22;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                break;
                            }
                            break Label_0023;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 27)));
                    ++n4;
                    final String s4 = s;
                    final int n13 = n4;
                    s3 = q.h(s4, n13, n13 + n3);
                    n10 = 0;
                }
            }
            break;
        }
        a = a2;
        b = new String[5];
        EOL = q.vr(a(7316, 25045));
        _hexcodes = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
        _shifts = new int[] { 28, 24, 20, 16, 12, 8, 4, 0 };
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0x1C94) & 0xFFFF;
        if (HexDump.b[n3] == null) {
            final char[] g = q.g(HexDump.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 183;
                    break;
                }
                case 1: {
                    n4 = 23;
                    break;
                }
                case 2: {
                    n4 = 158;
                    break;
                }
                case 3: {
                    n4 = 151;
                    break;
                }
                case 4: {
                    n4 = 164;
                    break;
                }
                case 5: {
                    n4 = 226;
                    break;
                }
                case 6: {
                    n4 = 18;
                    break;
                }
                case 7: {
                    n4 = 5;
                    break;
                }
                case 8: {
                    n4 = 122;
                    break;
                }
                case 9: {
                    n4 = 147;
                    break;
                }
                case 10: {
                    n4 = 19;
                    break;
                }
                case 11: {
                    n4 = 35;
                    break;
                }
                case 12: {
                    n4 = 65;
                    break;
                }
                case 13: {
                    n4 = 193;
                    break;
                }
                case 14: {
                    n4 = 83;
                    break;
                }
                case 15: {
                    n4 = 179;
                    break;
                }
                case 16: {
                    n4 = 109;
                    break;
                }
                case 17: {
                    n4 = 112;
                    break;
                }
                case 18: {
                    n4 = 46;
                    break;
                }
                case 19: {
                    n4 = 191;
                    break;
                }
                case 20: {
                    n4 = 63;
                    break;
                }
                case 21: {
                    n4 = 102;
                    break;
                }
                case 22: {
                    n4 = 64;
                    break;
                }
                case 23: {
                    n4 = 222;
                    break;
                }
                case 24: {
                    n4 = 111;
                    break;
                }
                case 25: {
                    n4 = 161;
                    break;
                }
                case 26: {
                    n4 = 248;
                    break;
                }
                case 27: {
                    n4 = 160;
                    break;
                }
                case 28: {
                    n4 = 22;
                    break;
                }
                case 29: {
                    n4 = 92;
                    break;
                }
                case 30: {
                    n4 = 131;
                    break;
                }
                case 31: {
                    n4 = 49;
                    break;
                }
                case 32: {
                    n4 = 148;
                    break;
                }
                case 33: {
                    n4 = 207;
                    break;
                }
                case 34: {
                    n4 = 16;
                    break;
                }
                case 35: {
                    n4 = 54;
                    break;
                }
                case 36: {
                    n4 = 213;
                    break;
                }
                case 37: {
                    n4 = 123;
                    break;
                }
                case 38: {
                    n4 = 105;
                    break;
                }
                case 39: {
                    n4 = 72;
                    break;
                }
                case 40: {
                    n4 = 61;
                    break;
                }
                case 41: {
                    n4 = 146;
                    break;
                }
                case 42: {
                    n4 = 90;
                    break;
                }
                case 43: {
                    n4 = 51;
                    break;
                }
                case 44: {
                    n4 = 199;
                    break;
                }
                case 45: {
                    n4 = 247;
                    break;
                }
                case 46: {
                    n4 = 184;
                    break;
                }
                case 47: {
                    n4 = 80;
                    break;
                }
                case 48: {
                    n4 = 15;
                    break;
                }
                case 49: {
                    n4 = 177;
                    break;
                }
                case 50: {
                    n4 = 241;
                    break;
                }
                case 51: {
                    n4 = 132;
                    break;
                }
                case 52: {
                    n4 = 166;
                    break;
                }
                case 53: {
                    n4 = 57;
                    break;
                }
                case 54: {
                    n4 = 110;
                    break;
                }
                case 55: {
                    n4 = 195;
                    break;
                }
                case 56: {
                    n4 = 86;
                    break;
                }
                case 57: {
                    n4 = 225;
                    break;
                }
                case 58: {
                    n4 = 67;
                    break;
                }
                case 59: {
                    n4 = 245;
                    break;
                }
                case 60: {
                    n4 = 48;
                    break;
                }
                case 61: {
                    n4 = 66;
                    break;
                }
                case 62: {
                    n4 = 95;
                    break;
                }
                case 63: {
                    n4 = 56;
                    break;
                }
                case 64: {
                    n4 = 253;
                    break;
                }
                case 65: {
                    n4 = 208;
                    break;
                }
                case 66: {
                    n4 = 94;
                    break;
                }
                case 67: {
                    n4 = 252;
                    break;
                }
                case 68: {
                    n4 = 70;
                    break;
                }
                case 69: {
                    n4 = 173;
                    break;
                }
                case 70: {
                    n4 = 232;
                    break;
                }
                case 71: {
                    n4 = 120;
                    break;
                }
                case 72: {
                    n4 = 21;
                    break;
                }
                case 73: {
                    n4 = 237;
                    break;
                }
                case 74: {
                    n4 = 249;
                    break;
                }
                case 75: {
                    n4 = 89;
                    break;
                }
                case 76: {
                    n4 = 138;
                    break;
                }
                case 77: {
                    n4 = 181;
                    break;
                }
                case 78: {
                    n4 = 9;
                    break;
                }
                case 79: {
                    n4 = 216;
                    break;
                }
                case 80: {
                    n4 = 39;
                    break;
                }
                case 81: {
                    n4 = 116;
                    break;
                }
                case 82: {
                    n4 = 38;
                    break;
                }
                case 83: {
                    n4 = 246;
                    break;
                }
                case 84: {
                    n4 = 189;
                    break;
                }
                case 85: {
                    n4 = 76;
                    break;
                }
                case 86: {
                    n4 = 212;
                    break;
                }
                case 87: {
                    n4 = 71;
                    break;
                }
                case 88: {
                    n4 = 244;
                    break;
                }
                case 89: {
                    n4 = 68;
                    break;
                }
                case 90: {
                    n4 = 103;
                    break;
                }
                case 91: {
                    n4 = 28;
                    break;
                }
                case 92: {
                    n4 = 13;
                    break;
                }
                case 93: {
                    n4 = 209;
                    break;
                }
                case 94: {
                    n4 = 215;
                    break;
                }
                case 95: {
                    n4 = 231;
                    break;
                }
                case 96: {
                    n4 = 97;
                    break;
                }
                case 97: {
                    n4 = 251;
                    break;
                }
                case 98: {
                    n4 = 27;
                    break;
                }
                case 99: {
                    n4 = 163;
                    break;
                }
                case 100: {
                    n4 = 196;
                    break;
                }
                case 101: {
                    n4 = 121;
                    break;
                }
                case 102: {
                    n4 = 211;
                    break;
                }
                case 103: {
                    n4 = 192;
                    break;
                }
                case 104: {
                    n4 = 29;
                    break;
                }
                case 105: {
                    n4 = 180;
                    break;
                }
                case 106: {
                    n4 = 119;
                    break;
                }
                case 107: {
                    n4 = 59;
                    break;
                }
                case 108: {
                    n4 = 202;
                    break;
                }
                case 109: {
                    n4 = 52;
                    break;
                }
                case 110: {
                    n4 = 149;
                    break;
                }
                case 111: {
                    n4 = 60;
                    break;
                }
                case 112: {
                    n4 = 14;
                    break;
                }
                case 113: {
                    n4 = 229;
                    break;
                }
                case 114: {
                    n4 = 217;
                    break;
                }
                case 115: {
                    n4 = 100;
                    break;
                }
                case 116: {
                    n4 = 4;
                    break;
                }
                case 117: {
                    n4 = 136;
                    break;
                }
                case 118: {
                    n4 = 141;
                    break;
                }
                case 119: {
                    n4 = 78;
                    break;
                }
                case 120: {
                    n4 = 33;
                    break;
                }
                case 121: {
                    n4 = 114;
                    break;
                }
                case 122: {
                    n4 = 154;
                    break;
                }
                case 123: {
                    n4 = 203;
                    break;
                }
                case 124: {
                    n4 = 88;
                    break;
                }
                case 125: {
                    n4 = 0;
                    break;
                }
                case 126: {
                    n4 = 157;
                    break;
                }
                case 127: {
                    n4 = 118;
                    break;
                }
                case 128: {
                    n4 = 53;
                    break;
                }
                case 129: {
                    n4 = 8;
                    break;
                }
                case 130: {
                    n4 = 43;
                    break;
                }
                case 131: {
                    n4 = 182;
                    break;
                }
                case 132: {
                    n4 = 150;
                    break;
                }
                case 133: {
                    n4 = 11;
                    break;
                }
                case 134: {
                    n4 = 37;
                    break;
                }
                case 135: {
                    n4 = 106;
                    break;
                }
                case 136: {
                    n4 = 117;
                    break;
                }
                case 137: {
                    n4 = 87;
                    break;
                }
                case 138: {
                    n4 = 20;
                    break;
                }
                case 139: {
                    n4 = 153;
                    break;
                }
                case 140: {
                    n4 = 221;
                    break;
                }
                case 141: {
                    n4 = 134;
                    break;
                }
                case 142: {
                    n4 = 58;
                    break;
                }
                case 143: {
                    n4 = 133;
                    break;
                }
                case 144: {
                    n4 = 145;
                    break;
                }
                case 145: {
                    n4 = 224;
                    break;
                }
                case 146: {
                    n4 = 176;
                    break;
                }
                case 147: {
                    n4 = 143;
                    break;
                }
                case 148: {
                    n4 = 82;
                    break;
                }
                case 149: {
                    n4 = 45;
                    break;
                }
                case 150: {
                    n4 = 113;
                    break;
                }
                case 151: {
                    n4 = 139;
                    break;
                }
                case 152: {
                    n4 = 62;
                    break;
                }
                case 153: {
                    n4 = 12;
                    break;
                }
                case 154: {
                    n4 = 223;
                    break;
                }
                case 155: {
                    n4 = 26;
                    break;
                }
                case 156: {
                    n4 = 135;
                    break;
                }
                case 157: {
                    n4 = 230;
                    break;
                }
                case 158: {
                    n4 = 84;
                    break;
                }
                case 159: {
                    n4 = 77;
                    break;
                }
                case 160: {
                    n4 = 155;
                    break;
                }
                case 161: {
                    n4 = 50;
                    break;
                }
                case 162: {
                    n4 = 75;
                    break;
                }
                case 163: {
                    n4 = 107;
                    break;
                }
                case 164: {
                    n4 = 42;
                    break;
                }
                case 165: {
                    n4 = 255;
                    break;
                }
                case 166: {
                    n4 = 162;
                    break;
                }
                case 167: {
                    n4 = 174;
                    break;
                }
                case 168: {
                    n4 = 165;
                    break;
                }
                case 169: {
                    n4 = 93;
                    break;
                }
                case 170: {
                    n4 = 140;
                    break;
                }
                case 171: {
                    n4 = 234;
                    break;
                }
                case 172: {
                    n4 = 108;
                    break;
                }
                case 173: {
                    n4 = 218;
                    break;
                }
                case 174: {
                    n4 = 186;
                    break;
                }
                case 175: {
                    n4 = 47;
                    break;
                }
                case 176: {
                    n4 = 250;
                    break;
                }
                case 177: {
                    n4 = 74;
                    break;
                }
                case 178: {
                    n4 = 242;
                    break;
                }
                case 179: {
                    n4 = 7;
                    break;
                }
                case 180: {
                    n4 = 40;
                    break;
                }
                case 181: {
                    n4 = 167;
                    break;
                }
                case 182: {
                    n4 = 81;
                    break;
                }
                case 183: {
                    n4 = 214;
                    break;
                }
                case 184: {
                    n4 = 190;
                    break;
                }
                case 185: {
                    n4 = 130;
                    break;
                }
                case 186: {
                    n4 = 227;
                    break;
                }
                case 187: {
                    n4 = 128;
                    break;
                }
                case 188: {
                    n4 = 24;
                    break;
                }
                case 189: {
                    n4 = 187;
                    break;
                }
                case 190: {
                    n4 = 1;
                    break;
                }
                case 191: {
                    n4 = 194;
                    break;
                }
                case 192: {
                    n4 = 168;
                    break;
                }
                case 193: {
                    n4 = 41;
                    break;
                }
                case 194: {
                    n4 = 240;
                    break;
                }
                case 195: {
                    n4 = 236;
                    break;
                }
                case 196: {
                    n4 = 125;
                    break;
                }
                case 197: {
                    n4 = 25;
                    break;
                }
                case 198: {
                    n4 = 55;
                    break;
                }
                case 199: {
                    n4 = 238;
                    break;
                }
                case 200: {
                    n4 = 31;
                    break;
                }
                case 201: {
                    n4 = 185;
                    break;
                }
                case 202: {
                    n4 = 101;
                    break;
                }
                case 203: {
                    n4 = 137;
                    break;
                }
                case 204: {
                    n4 = 124;
                    break;
                }
                case 205: {
                    n4 = 36;
                    break;
                }
                case 206: {
                    n4 = 126;
                    break;
                }
                case 207: {
                    n4 = 99;
                    break;
                }
                case 208: {
                    n4 = 204;
                    break;
                }
                case 209: {
                    n4 = 44;
                    break;
                }
                case 210: {
                    n4 = 6;
                    break;
                }
                case 211: {
                    n4 = 115;
                    break;
                }
                case 212: {
                    n4 = 104;
                    break;
                }
                case 213: {
                    n4 = 178;
                    break;
                }
                case 214: {
                    n4 = 171;
                    break;
                }
                case 215: {
                    n4 = 169;
                    break;
                }
                case 216: {
                    n4 = 69;
                    break;
                }
                case 217: {
                    n4 = 17;
                    break;
                }
                case 218: {
                    n4 = 142;
                    break;
                }
                case 219: {
                    n4 = 3;
                    break;
                }
                case 220: {
                    n4 = 152;
                    break;
                }
                case 221: {
                    n4 = 220;
                    break;
                }
                case 222: {
                    n4 = 85;
                    break;
                }
                case 223: {
                    n4 = 243;
                    break;
                }
                case 224: {
                    n4 = 159;
                    break;
                }
                case 225: {
                    n4 = 30;
                    break;
                }
                case 226: {
                    n4 = 188;
                    break;
                }
                case 227: {
                    n4 = 127;
                    break;
                }
                case 228: {
                    n4 = 156;
                    break;
                }
                case 229: {
                    n4 = 210;
                    break;
                }
                case 230: {
                    n4 = 206;
                    break;
                }
                case 231: {
                    n4 = 79;
                    break;
                }
                case 232: {
                    n4 = 198;
                    break;
                }
                case 233: {
                    n4 = 205;
                    break;
                }
                case 234: {
                    n4 = 228;
                    break;
                }
                case 235: {
                    n4 = 96;
                    break;
                }
                case 236: {
                    n4 = 235;
                    break;
                }
                case 237: {
                    n4 = 219;
                    break;
                }
                case 238: {
                    n4 = 197;
                    break;
                }
                case 239: {
                    n4 = 239;
                    break;
                }
                case 240: {
                    n4 = 200;
                    break;
                }
                case 241: {
                    n4 = 91;
                    break;
                }
                case 242: {
                    n4 = 170;
                    break;
                }
                case 243: {
                    n4 = 129;
                    break;
                }
                case 244: {
                    n4 = 172;
                    break;
                }
                case 245: {
                    n4 = 144;
                    break;
                }
                case 246: {
                    n4 = 2;
                    break;
                }
                case 247: {
                    n4 = 34;
                    break;
                }
                case 248: {
                    n4 = 32;
                    break;
                }
                case 249: {
                    n4 = 233;
                    break;
                }
                case 250: {
                    n4 = 254;
                    break;
                }
                case 251: {
                    n4 = 10;
                    break;
                }
                case 252: {
                    n4 = 98;
                    break;
                }
                case 253: {
                    n4 = 201;
                    break;
                }
                case 254: {
                    n4 = 175;
                    break;
                }
                default: {
                    n4 = 73;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            HexDump.b[n3] = q.z(new String(g));
        }
        return HexDump.b[n3];
    }
}
