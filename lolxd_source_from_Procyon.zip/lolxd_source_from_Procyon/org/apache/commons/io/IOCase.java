// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import q.o.m.s.q;
import java.io.Serializable;

public enum IOCase implements Serializable
{
    SENSITIVE(a(-5184, -6722), true), 
    INSENSITIVE(a(-5181, -2329), false), 
    SYSTEM(a4, b);
    
    private static final long serialVersionUID = -6343169151696340687L;
    private final String name;
    private final transient boolean sensitive;
    private static int b;
    private static final String[] a;
    private static final String[] c;
    
    public static IOCase forName(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: invokestatic    org/apache/commons/io/IOCase.c:()I
        //     7: aload_2        
        //     8: arraylength    
        //     9: istore_3       
        //    10: istore_1       
        //    11: iconst_0       
        //    12: istore          4
        //    14: iload           4
        //    16: iload_3        
        //    17: if_icmpge       77
        //    20: aload_2        
        //    21: iload           4
        //    23: aaload         
        //    24: astore          5
        //    26: iload_1        
        //    27: ifeq            73
        //    30: aload           5
        //    32: iload_1        
        //    33: ifeq            69
        //    36: goto            43
        //    39: invokestatic    org/apache/commons/io/IOCase.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    42: athrow         
        //    43: invokevirtual   org/apache/commons/io/IOCase.getName:()Ljava/lang/String;
        //    46: aload_0        
        //    47: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //    50: ifeq            70
        //    53: goto            60
        //    56: invokestatic    org/apache/commons/io/IOCase.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    59: athrow         
        //    60: aload           5
        //    62: goto            69
        //    65: invokestatic    org/apache/commons/io/IOCase.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    68: athrow         
        //    69: areturn        
        //    70: iinc            4, 1
        //    73: iload_1        
        //    74: ifne            14
        //    77: new             Ljava/lang/IllegalArgumentException;
        //    80: dup            
        //    81: new             Ljava/lang/StringBuilder;
        //    84: dup            
        //    85: invokespecial   java/lang/StringBuilder.<init>:()V
        //    88: sipush          -5183
        //    91: sipush          7976
        //    94: invokestatic    org/apache/commons/io/IOCase.a:(II)Ljava/lang/String;
        //    97: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   100: aload_0        
        //   101: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   104: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   107: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //   110: athrow         
        //    StackMapTable: 00 0A FF 00 0E 00 05 07 00 36 01 07 00 20 01 01 00 00 FF 00 18 00 06 07 00 36 01 07 00 20 01 01 07 00 02 00 01 07 00 2F 43 07 00 02 4C 07 00 2F 03 44 07 00 2F 43 07 00 02 00 02 FA 00 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  26     36     39     43     Ljava/lang/IllegalArgumentException;
        //  30     53     56     60     Ljava/lang/IllegalArgumentException;
        //  43     62     65     69     Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0043:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private IOCase(final String name2, final boolean sensitive) {
        this.name = name2;
        this.sensitive = sensitive;
    }
    
    private Object readResolve() {
        return forName(this.name);
    }
    
    public String getName() {
        return this.name;
    }
    
    public boolean isCaseSensitive() {
        return this.sensitive;
    }
    
    public int checkCompareTo(final String s, final String s2) {
        final int b = b();
        Label_0034: {
            Label_0020: {
                try {
                    final String s3 = s;
                    if (b != 0) {
                        break Label_0034;
                    }
                    final int n = b;
                    if (n == 0) {
                        break Label_0020;
                    }
                    break Label_0034;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    final int n = b;
                    if (n != 0) {
                        break Label_0034;
                    }
                    if (s == null) {
                        break Label_0034;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            final String s3 = s2;
            try {
                if (s3 == null) {
                    throw new NullPointerException(a(-5177, -17440));
                }
            }
            catch (IllegalArgumentException ex3) {
                throw b(ex3);
            }
        }
        Label_0088: {
            String s4 = null;
            String s5 = null;
            Label_0073: {
                boolean b2;
                try {
                    final int n2;
                    b2 = ((n2 = (this.sensitive ? 1 : 0)) != 0);
                    if (b != 0) {
                        return n2;
                    }
                    if (b2) {
                        break Label_0073;
                    }
                    break Label_0088;
                }
                catch (IllegalArgumentException ex4) {
                    throw b(ex4);
                }
                try {
                    if (!b2) {
                        break Label_0088;
                    }
                    s4 = s;
                    s5 = s2;
                }
                catch (IllegalArgumentException ex5) {
                    throw b(ex5);
                }
            }
            return q.yo(s4, s5);
        }
        String s4 = s;
        String s5 = s2;
        if (b != 0) {
            return q.yo(s4, s5);
        }
        return q.yq(s, s2);
    }
    
    public boolean checkEquals(final String s, final String s2) {
        final int b = b();
        Label_0034: {
            Label_0020: {
                try {
                    final String s3 = s;
                    if (b != 0) {
                        break Label_0034;
                    }
                    final int n = b;
                    if (n == 0) {
                        break Label_0020;
                    }
                    break Label_0034;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    final int n = b;
                    if (n != 0) {
                        break Label_0034;
                    }
                    if (s == null) {
                        break Label_0034;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            final String s3 = s2;
            try {
                if (s3 == null) {
                    throw new NullPointerException(a(-5177, -17440));
                }
            }
            catch (IllegalArgumentException ex3) {
                throw b(ex3);
            }
        }
        Label_0088: {
            String s4 = null;
            String s5 = null;
            Label_0073: {
                boolean b2;
                try {
                    final boolean b3;
                    b2 = (b3 = this.sensitive);
                    if (b != 0) {
                        return b3;
                    }
                    if (b2) {
                        break Label_0073;
                    }
                    break Label_0088;
                }
                catch (IllegalArgumentException ex4) {
                    throw b(ex4);
                }
                try {
                    if (!b2) {
                        break Label_0088;
                    }
                    s4 = s;
                    s5 = s2;
                }
                catch (IllegalArgumentException ex5) {
                    throw b(ex5);
                }
            }
            return q.th(s4, s5);
        }
        String s4 = s;
        String s5 = s2;
        if (b != 0) {
            return q.th(s4, s5);
        }
        return q.my(s, s2);
    }
    
    public boolean checkStartsWith(final String s, final String s2) {
        final int b = b();
        boolean sensitive = false;
        Label_0038: {
            Label_0024: {
                try {
                    sensitive = this.sensitive;
                    if (b != 0) {
                        return q.yt(s, sensitive, 0, s2, 0, q.q(s2));
                    }
                    final int n = b;
                    if (n == 0) {
                        break Label_0024;
                    }
                    return q.yt(s, sensitive, 0, s2, 0, q.q(s2));
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    final int n = b;
                    if (n != 0) {
                        return q.yt(s, sensitive, 0, s2, 0, q.q(s2));
                    }
                    if (sensitive) {
                        break Label_0038;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            return q.yt(s, sensitive, 0, s2, 0, q.q(s2));
        }
        return q.yt(s, sensitive, 0, s2, 0, q.q(s2));
    }
    
    public boolean checkEndsWith(final String s, final String s2) {
        final int q = q.o.m.s.q.q(s2);
        final int c = c();
        boolean sensitive = false;
        Label_0044: {
            Label_0030: {
                try {
                    sensitive = this.sensitive;
                    if (c == 0) {
                        return q.o.m.s.q.yt(s, sensitive, q.o.m.s.q.q(s) - q, s2, 0, q);
                    }
                    final int n = c;
                    if (n != 0) {
                        break Label_0030;
                    }
                    return q.o.m.s.q.yt(s, sensitive, q.o.m.s.q.q(s) - q, s2, 0, q);
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    final int n = c;
                    if (n == 0) {
                        return q.o.m.s.q.yt(s, sensitive, q.o.m.s.q.q(s) - q, s2, 0, q);
                    }
                    if (sensitive) {
                        break Label_0044;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            return q.o.m.s.q.yt(s, sensitive, q.o.m.s.q.q(s) - q, s2, 0, q);
        }
        return q.o.m.s.q.yt(s, sensitive, q.o.m.s.q.q(s) - q, s2, 0, q);
    }
    
    public int checkIndexOf(final String p0, final int p1, final String p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //     4: aload_3        
        //     5: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //     8: isub           
        //     9: istore          5
        //    11: invokestatic    org/apache/commons/io/IOCase.c:()I
        //    14: istore          4
        //    16: iload           5
        //    18: iload           4
        //    20: ifeq            115
        //    23: iload_2        
        //    24: if_icmplt       109
        //    27: goto            34
        //    30: invokestatic    org/apache/commons/io/IOCase.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    33: athrow         
        //    34: iload_2        
        //    35: goto            42
        //    38: invokestatic    org/apache/commons/io/IOCase.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    41: athrow         
        //    42: istore          6
        //    44: iload           6
        //    46: iload           5
        //    48: if_icmpgt       109
        //    51: aload_0        
        //    52: aload_1        
        //    53: iload           6
        //    55: aload_3        
        //    56: invokevirtual   org/apache/commons/io/IOCase.checkRegionMatches:(Ljava/lang/String;ILjava/lang/String;)Z
        //    59: iload           4
        //    61: ifeq            110
        //    64: iload           4
        //    66: ifeq            100
        //    69: goto            76
        //    72: invokestatic    org/apache/commons/io/IOCase.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    75: athrow         
        //    76: iload           4
        //    78: ifeq            100
        //    81: goto            88
        //    84: invokestatic    org/apache/commons/io/IOCase.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    87: athrow         
        //    88: ifeq            101
        //    91: goto            98
        //    94: invokestatic    org/apache/commons/io/IOCase.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    97: athrow         
        //    98: iload           6
        //   100: ireturn        
        //   101: iinc            6, 1
        //   104: iload           4
        //   106: ifne            44
        //   109: iconst_m1      
        //   110: iload           4
        //   112: ifeq            42
        //   115: ireturn        
        //    StackMapTable: 00 10 FF 00 1E 00 06 07 00 02 07 00 36 01 07 00 36 01 01 00 01 07 00 2F 03 43 07 00 2F 43 01 FC 00 01 01 5B 07 00 2F 43 01 47 07 00 2F 43 01 45 07 00 2F 03 41 01 00 FA 00 07 40 01 44 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  16     27     30     34     Ljava/lang/IllegalArgumentException;
        //  23     35     38     42     Ljava/lang/IllegalArgumentException;
        //  51     69     72     76     Ljava/lang/IllegalArgumentException;
        //  64     81     84     88     Ljava/lang/IllegalArgumentException;
        //  76     91     94     98     Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0076:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public boolean checkRegionMatches(final String s, final int n, final String s2) {
        final int c = c();
        boolean sensitive = false;
        Label_0041: {
            Label_0027: {
                try {
                    sensitive = this.sensitive;
                    if (c == 0) {
                        return q.yt(s, sensitive, n, s2, 0, q.q(s2));
                    }
                    final int n2 = c;
                    if (n2 != 0) {
                        break Label_0027;
                    }
                    return q.yt(s, sensitive, n, s2, 0, q.q(s2));
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    final int n2 = c;
                    if (n2 == 0) {
                        return q.yt(s, sensitive, n, s2, 0, q.q(s2));
                    }
                    if (sensitive) {
                        break Label_0041;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            return q.yt(s, sensitive, n, s2, 0, q.q(s2));
        }
        return q.yt(s, sensitive, n, s2, 0, q.q(s2));
    }
    
    @Override
    public String toString() {
        return this.name;
    }
    
    static {
        final String[] a2 = new String[8];
        final int n = 0;
        int n2 = 0;
        String s;
        int n3 = q.q(s = n.d.a.d.q.vw());
        int n4 = 11;
        b(n);
        int n5 = -1;
    Label_0028:
        while (true) {
            while (true) {
                int n9;
                int n8;
                int n7;
                int n6 = n7 = (n8 = (n9 = 74));
                ++n5;
                final String s2 = s;
                final int n10 = n5;
                String s3 = q.h(s2, n10, n10 + n4);
                int n11 = -1;
                while (true) {
                    final char[] g = q.g(s3);
                    final int length = g.length;
                    int n12 = 0;
                    while (true) {
                        Label_0267: {
                            if (length > 1) {
                                break Label_0267;
                            }
                            n8 = (n7 = n12);
                            do {
                                final char c2 = g[n7];
                                int n13 = 0;
                                switch (n12 % 7) {
                                    case 0: {
                                        n13 = 76;
                                        break;
                                    }
                                    case 1: {
                                        n13 = 13;
                                        break;
                                    }
                                    case 2: {
                                        n13 = 27;
                                        break;
                                    }
                                    case 3: {
                                        n13 = 67;
                                        break;
                                    }
                                    case 4: {
                                        n13 = 17;
                                        break;
                                    }
                                    case 5: {
                                        n13 = 4;
                                        break;
                                    }
                                    default: {
                                        n13 = 112;
                                        break;
                                    }
                                }
                                g[n8] = (char)(c2 ^ (n6 ^ n13));
                                ++n12;
                            } while (n9 == 0);
                        }
                        if (length > n12) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.z(new String(g));
                    switch (n11) {
                        default: {
                            a2[n2++] = z;
                            if ((n5 += n4) < n3) {
                                n4 = q.j(s, n5);
                                continue Label_0028;
                            }
                            n3 = q.q(s = n.d.a.d.q.va());
                            n4 = 11;
                            n5 = -1;
                            break;
                        }
                        case 0: {
                            a2[n2++] = z;
                            if ((n5 += n4) < n3) {
                                n4 = q.j(s, n5);
                                break;
                            }
                            break Label_0028;
                        }
                    }
                    n6 = (n7 = (n8 = (n9 = 121)));
                    ++n5;
                    final String s4 = s;
                    final int n14 = n5;
                    s3 = q.h(s4, n14, n14 + n4);
                    n11 = 0;
                }
            }
            break;
        }
        a = a2;
        c = new String[8];
        Label_0406: {
            try {
                final String a3 = a(-5182, -1289);
                final int n15 = 2;
                final String a4 = a(-5180, -30336);
                if (!FilenameUtils.isSystemWindows()) {
                    final boolean b = true;
                    break Label_0406;
                }
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            final boolean b = false;
        }
    }
    
    public static void b(final int b) {
        IOCase.b = b;
    }
    
    public static int b() {
        return IOCase.b;
    }
    
    public static int c() {
        final int b = b();
        try {
            if (b == 0) {
                return 65;
            }
        }
        catch (IllegalArgumentException ex) {
            throw b(ex);
        }
        return 0;
    }
    
    private static IllegalArgumentException b(final IllegalArgumentException ex) {
        return ex;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0xFFFFEBC3) & 0xFFFF;
        if (IOCase.c[n3] == null) {
            final char[] g = q.g(IOCase.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 115;
                    break;
                }
                case 1: {
                    n4 = 140;
                    break;
                }
                case 2: {
                    n4 = 44;
                    break;
                }
                case 3: {
                    n4 = 128;
                    break;
                }
                case 4: {
                    n4 = 129;
                    break;
                }
                case 5: {
                    n4 = 214;
                    break;
                }
                case 6: {
                    n4 = 179;
                    break;
                }
                case 7: {
                    n4 = 75;
                    break;
                }
                case 8: {
                    n4 = 18;
                    break;
                }
                case 9: {
                    n4 = 105;
                    break;
                }
                case 10: {
                    n4 = 90;
                    break;
                }
                case 11: {
                    n4 = 29;
                    break;
                }
                case 12: {
                    n4 = 172;
                    break;
                }
                case 13: {
                    n4 = 11;
                    break;
                }
                case 14: {
                    n4 = 19;
                    break;
                }
                case 15: {
                    n4 = 180;
                    break;
                }
                case 16: {
                    n4 = 114;
                    break;
                }
                case 17: {
                    n4 = 192;
                    break;
                }
                case 18: {
                    n4 = 110;
                    break;
                }
                case 19: {
                    n4 = 76;
                    break;
                }
                case 20: {
                    n4 = 166;
                    break;
                }
                case 21: {
                    n4 = 132;
                    break;
                }
                case 22: {
                    n4 = 86;
                    break;
                }
                case 23: {
                    n4 = 78;
                    break;
                }
                case 24: {
                    n4 = 102;
                    break;
                }
                case 25: {
                    n4 = 88;
                    break;
                }
                case 26: {
                    n4 = 175;
                    break;
                }
                case 27: {
                    n4 = 50;
                    break;
                }
                case 28: {
                    n4 = 220;
                    break;
                }
                case 29: {
                    n4 = 222;
                    break;
                }
                case 30: {
                    n4 = 3;
                    break;
                }
                case 31: {
                    n4 = 190;
                    break;
                }
                case 32: {
                    n4 = 93;
                    break;
                }
                case 33: {
                    n4 = 239;
                    break;
                }
                case 34: {
                    n4 = 27;
                    break;
                }
                case 35: {
                    n4 = 8;
                    break;
                }
                case 36: {
                    n4 = 150;
                    break;
                }
                case 37: {
                    n4 = 61;
                    break;
                }
                case 38: {
                    n4 = 49;
                    break;
                }
                case 39: {
                    n4 = 22;
                    break;
                }
                case 40: {
                    n4 = 56;
                    break;
                }
                case 41: {
                    n4 = 177;
                    break;
                }
                case 42: {
                    n4 = 7;
                    break;
                }
                case 43: {
                    n4 = 218;
                    break;
                }
                case 44: {
                    n4 = 63;
                    break;
                }
                case 45: {
                    n4 = 60;
                    break;
                }
                case 46: {
                    n4 = 195;
                    break;
                }
                case 47: {
                    n4 = 162;
                    break;
                }
                case 48: {
                    n4 = 225;
                    break;
                }
                case 49: {
                    n4 = 30;
                    break;
                }
                case 50: {
                    n4 = 152;
                    break;
                }
                case 51: {
                    n4 = 205;
                    break;
                }
                case 52: {
                    n4 = 236;
                    break;
                }
                case 53: {
                    n4 = 91;
                    break;
                }
                case 54: {
                    n4 = 254;
                    break;
                }
                case 55: {
                    n4 = 47;
                    break;
                }
                case 56: {
                    n4 = 107;
                    break;
                }
                case 57: {
                    n4 = 208;
                    break;
                }
                case 58: {
                    n4 = 174;
                    break;
                }
                case 59: {
                    n4 = 211;
                    break;
                }
                case 60: {
                    n4 = 163;
                    break;
                }
                case 61: {
                    n4 = 108;
                    break;
                }
                case 62: {
                    n4 = 135;
                    break;
                }
                case 63: {
                    n4 = 216;
                    break;
                }
                case 64: {
                    n4 = 67;
                    break;
                }
                case 65: {
                    n4 = 116;
                    break;
                }
                case 66: {
                    n4 = 99;
                    break;
                }
                case 67: {
                    n4 = 74;
                    break;
                }
                case 68: {
                    n4 = 210;
                    break;
                }
                case 69: {
                    n4 = 230;
                    break;
                }
                case 70: {
                    n4 = 82;
                    break;
                }
                case 71: {
                    n4 = 167;
                    break;
                }
                case 72: {
                    n4 = 155;
                    break;
                }
                case 73: {
                    n4 = 142;
                    break;
                }
                case 74: {
                    n4 = 243;
                    break;
                }
                case 75: {
                    n4 = 187;
                    break;
                }
                case 76: {
                    n4 = 171;
                    break;
                }
                case 77: {
                    n4 = 24;
                    break;
                }
                case 78: {
                    n4 = 10;
                    break;
                }
                case 79: {
                    n4 = 25;
                    break;
                }
                case 80: {
                    n4 = 199;
                    break;
                }
                case 81: {
                    n4 = 0;
                    break;
                }
                case 82: {
                    n4 = 121;
                    break;
                }
                case 83: {
                    n4 = 127;
                    break;
                }
                case 84: {
                    n4 = 238;
                    break;
                }
                case 85: {
                    n4 = 37;
                    break;
                }
                case 86: {
                    n4 = 35;
                    break;
                }
                case 87: {
                    n4 = 223;
                    break;
                }
                case 88: {
                    n4 = 21;
                    break;
                }
                case 89: {
                    n4 = 118;
                    break;
                }
                case 90: {
                    n4 = 65;
                    break;
                }
                case 91: {
                    n4 = 232;
                    break;
                }
                case 92: {
                    n4 = 130;
                    break;
                }
                case 93: {
                    n4 = 169;
                    break;
                }
                case 94: {
                    n4 = 111;
                    break;
                }
                case 95: {
                    n4 = 5;
                    break;
                }
                case 96: {
                    n4 = 235;
                    break;
                }
                case 97: {
                    n4 = 117;
                    break;
                }
                case 98: {
                    n4 = 244;
                    break;
                }
                case 99: {
                    n4 = 215;
                    break;
                }
                case 100: {
                    n4 = 184;
                    break;
                }
                case 101: {
                    n4 = 62;
                    break;
                }
                case 102: {
                    n4 = 255;
                    break;
                }
                case 103: {
                    n4 = 161;
                    break;
                }
                case 104: {
                    n4 = 245;
                    break;
                }
                case 105: {
                    n4 = 55;
                    break;
                }
                case 106: {
                    n4 = 26;
                    break;
                }
                case 107: {
                    n4 = 198;
                    break;
                }
                case 108: {
                    n4 = 57;
                    break;
                }
                case 109: {
                    n4 = 15;
                    break;
                }
                case 110: {
                    n4 = 158;
                    break;
                }
                case 111: {
                    n4 = 46;
                    break;
                }
                case 112: {
                    n4 = 120;
                    break;
                }
                case 113: {
                    n4 = 149;
                    break;
                }
                case 114: {
                    n4 = 253;
                    break;
                }
                case 115: {
                    n4 = 189;
                    break;
                }
                case 116: {
                    n4 = 23;
                    break;
                }
                case 117: {
                    n4 = 156;
                    break;
                }
                case 118: {
                    n4 = 12;
                    break;
                }
                case 119: {
                    n4 = 48;
                    break;
                }
                case 120: {
                    n4 = 38;
                    break;
                }
                case 121: {
                    n4 = 134;
                    break;
                }
                case 122: {
                    n4 = 97;
                    break;
                }
                case 123: {
                    n4 = 69;
                    break;
                }
                case 124: {
                    n4 = 170;
                    break;
                }
                case 125: {
                    n4 = 249;
                    break;
                }
                case 126: {
                    n4 = 45;
                    break;
                }
                case 127: {
                    n4 = 168;
                    break;
                }
                case 128: {
                    n4 = 137;
                    break;
                }
                case 129: {
                    n4 = 39;
                    break;
                }
                case 130: {
                    n4 = 87;
                    break;
                }
                case 131: {
                    n4 = 92;
                    break;
                }
                case 132: {
                    n4 = 224;
                    break;
                }
                case 133: {
                    n4 = 151;
                    break;
                }
                case 134: {
                    n4 = 219;
                    break;
                }
                case 135: {
                    n4 = 84;
                    break;
                }
                case 136: {
                    n4 = 226;
                    break;
                }
                case 137: {
                    n4 = 77;
                    break;
                }
                case 138: {
                    n4 = 200;
                    break;
                }
                case 139: {
                    n4 = 40;
                    break;
                }
                case 140: {
                    n4 = 33;
                    break;
                }
                case 141: {
                    n4 = 100;
                    break;
                }
                case 142: {
                    n4 = 32;
                    break;
                }
                case 143: {
                    n4 = 160;
                    break;
                }
                case 144: {
                    n4 = 20;
                    break;
                }
                case 145: {
                    n4 = 241;
                    break;
                }
                case 146: {
                    n4 = 203;
                    break;
                }
                case 147: {
                    n4 = 79;
                    break;
                }
                case 148: {
                    n4 = 28;
                    break;
                }
                case 149: {
                    n4 = 52;
                    break;
                }
                case 150: {
                    n4 = 212;
                    break;
                }
                case 151: {
                    n4 = 176;
                    break;
                }
                case 152: {
                    n4 = 157;
                    break;
                }
                case 153: {
                    n4 = 94;
                    break;
                }
                case 154: {
                    n4 = 173;
                    break;
                }
                case 155: {
                    n4 = 9;
                    break;
                }
                case 156: {
                    n4 = 217;
                    break;
                }
                case 157: {
                    n4 = 124;
                    break;
                }
                case 158: {
                    n4 = 122;
                    break;
                }
                case 159: {
                    n4 = 104;
                    break;
                }
                case 160: {
                    n4 = 126;
                    break;
                }
                case 161: {
                    n4 = 252;
                    break;
                }
                case 162: {
                    n4 = 246;
                    break;
                }
                case 163: {
                    n4 = 17;
                    break;
                }
                case 164: {
                    n4 = 213;
                    break;
                }
                case 165: {
                    n4 = 1;
                    break;
                }
                case 166: {
                    n4 = 240;
                    break;
                }
                case 167: {
                    n4 = 85;
                    break;
                }
                case 168: {
                    n4 = 183;
                    break;
                }
                case 169: {
                    n4 = 103;
                    break;
                }
                case 170: {
                    n4 = 59;
                    break;
                }
                case 171: {
                    n4 = 34;
                    break;
                }
                case 172: {
                    n4 = 201;
                    break;
                }
                case 173: {
                    n4 = 43;
                    break;
                }
                case 174: {
                    n4 = 119;
                    break;
                }
                case 175: {
                    n4 = 165;
                    break;
                }
                case 176: {
                    n4 = 13;
                    break;
                }
                case 177: {
                    n4 = 146;
                    break;
                }
                case 178: {
                    n4 = 191;
                    break;
                }
                case 179: {
                    n4 = 182;
                    break;
                }
                case 180: {
                    n4 = 247;
                    break;
                }
                case 181: {
                    n4 = 41;
                    break;
                }
                case 182: {
                    n4 = 64;
                    break;
                }
                case 183: {
                    n4 = 148;
                    break;
                }
                case 184: {
                    n4 = 237;
                    break;
                }
                case 185: {
                    n4 = 227;
                    break;
                }
                case 186: {
                    n4 = 197;
                    break;
                }
                case 187: {
                    n4 = 73;
                    break;
                }
                case 188: {
                    n4 = 101;
                    break;
                }
                case 189: {
                    n4 = 51;
                    break;
                }
                case 190: {
                    n4 = 185;
                    break;
                }
                case 191: {
                    n4 = 194;
                    break;
                }
                case 192: {
                    n4 = 6;
                    break;
                }
                case 193: {
                    n4 = 106;
                    break;
                }
                case 194: {
                    n4 = 136;
                    break;
                }
                case 195: {
                    n4 = 181;
                    break;
                }
                case 196: {
                    n4 = 95;
                    break;
                }
                case 197: {
                    n4 = 188;
                    break;
                }
                case 198: {
                    n4 = 206;
                    break;
                }
                case 199: {
                    n4 = 251;
                    break;
                }
                case 200: {
                    n4 = 2;
                    break;
                }
                case 201: {
                    n4 = 83;
                    break;
                }
                case 202: {
                    n4 = 66;
                    break;
                }
                case 203: {
                    n4 = 229;
                    break;
                }
                case 204: {
                    n4 = 233;
                    break;
                }
                case 205: {
                    n4 = 204;
                    break;
                }
                case 206: {
                    n4 = 178;
                    break;
                }
                case 207: {
                    n4 = 144;
                    break;
                }
                case 208: {
                    n4 = 234;
                    break;
                }
                case 209: {
                    n4 = 31;
                    break;
                }
                case 210: {
                    n4 = 164;
                    break;
                }
                case 211: {
                    n4 = 14;
                    break;
                }
                case 212: {
                    n4 = 89;
                    break;
                }
                case 213: {
                    n4 = 147;
                    break;
                }
                case 214: {
                    n4 = 70;
                    break;
                }
                case 215: {
                    n4 = 248;
                    break;
                }
                case 216: {
                    n4 = 138;
                    break;
                }
                case 217: {
                    n4 = 112;
                    break;
                }
                case 218: {
                    n4 = 53;
                    break;
                }
                case 219: {
                    n4 = 109;
                    break;
                }
                case 220: {
                    n4 = 153;
                    break;
                }
                case 221: {
                    n4 = 80;
                    break;
                }
                case 222: {
                    n4 = 42;
                    break;
                }
                case 223: {
                    n4 = 193;
                    break;
                }
                case 224: {
                    n4 = 207;
                    break;
                }
                case 225: {
                    n4 = 196;
                    break;
                }
                case 226: {
                    n4 = 209;
                    break;
                }
                case 227: {
                    n4 = 36;
                    break;
                }
                case 228: {
                    n4 = 143;
                    break;
                }
                case 229: {
                    n4 = 228;
                    break;
                }
                case 230: {
                    n4 = 231;
                    break;
                }
                case 231: {
                    n4 = 4;
                    break;
                }
                case 232: {
                    n4 = 133;
                    break;
                }
                case 233: {
                    n4 = 96;
                    break;
                }
                case 234: {
                    n4 = 68;
                    break;
                }
                case 235: {
                    n4 = 186;
                    break;
                }
                case 236: {
                    n4 = 98;
                    break;
                }
                case 237: {
                    n4 = 113;
                    break;
                }
                case 238: {
                    n4 = 250;
                    break;
                }
                case 239: {
                    n4 = 123;
                    break;
                }
                case 240: {
                    n4 = 58;
                    break;
                }
                case 241: {
                    n4 = 221;
                    break;
                }
                case 242: {
                    n4 = 202;
                    break;
                }
                case 243: {
                    n4 = 81;
                    break;
                }
                case 244: {
                    n4 = 139;
                    break;
                }
                case 245: {
                    n4 = 125;
                    break;
                }
                case 246: {
                    n4 = 71;
                    break;
                }
                case 247: {
                    n4 = 131;
                    break;
                }
                case 248: {
                    n4 = 242;
                    break;
                }
                case 249: {
                    n4 = 141;
                    break;
                }
                case 250: {
                    n4 = 154;
                    break;
                }
                case 251: {
                    n4 = 54;
                    break;
                }
                case 252: {
                    n4 = 145;
                    break;
                }
                case 253: {
                    n4 = 72;
                    break;
                }
                case 254: {
                    n4 = 159;
                    break;
                }
                default: {
                    n4 = 16;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            IOCase.c[n3] = q.z(new String(g));
        }
        return IOCase.c[n3];
    }
}
