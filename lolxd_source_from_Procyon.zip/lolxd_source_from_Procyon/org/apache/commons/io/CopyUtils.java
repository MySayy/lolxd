// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import java.io.StringReader;
import java.io.OutputStreamWriter;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.Writer;
import java.io.IOException;
import q.o.m.s.q;
import java.io.OutputStream;

@Deprecated
public class CopyUtils
{
    private static final int DEFAULT_BUFFER_SIZE = 4096;
    
    public static void copy(final byte[] array, final OutputStream outputStream) throws IOException {
        q.sj(outputStream, array);
    }
    
    @Deprecated
    public static void copy(final byte[] buf, final Writer writer) throws IOException {
        copy(new ByteArrayInputStream(buf), writer);
    }
    
    public static void copy(final byte[] buf, final Writer writer, final String s) throws IOException {
        copy(new ByteArrayInputStream(buf), writer, s);
    }
    
    public static int copy(final InputStream inputStream, final OutputStream outputStream) throws IOException {
        final byte[] array = new byte[4096];
        final int b = IOCase.b();
        int n = 0;
        final int n2 = b;
        int sg;
        int n3 = 0;
        while (-1 != (sg = q.sg(inputStream, array))) {
            q.sz(outputStream, array, 0, sg);
            n3 = n + sg;
            if (n2 != 0) {
                return n3;
            }
            n = n3;
            if (n2 != 0) {
                break;
            }
        }
        return n3;
    }
    
    public static int copy(final Reader reader, final Writer writer) throws IOException {
        final int b = IOCase.b();
        final char[] array = new char[4096];
        final int n = b;
        int n2 = 0;
        int sd;
        int n3 = 0;
        while (-1 != (sd = q.sd(reader, array))) {
            q.sb(writer, array, 0, sd);
            n3 = n2 + sd;
            if (n != 0) {
                return n3;
            }
            n2 = n3;
            if (n != 0) {
                break;
            }
        }
        return n3;
    }
    
    @Deprecated
    public static void copy(final InputStream in, final Writer writer) throws IOException {
        copy(new InputStreamReader(in, q.sx()), writer);
    }
    
    public static void copy(final InputStream in, final Writer writer, final String charsetName) throws IOException {
        copy(new InputStreamReader(in, charsetName), writer);
    }
    
    @Deprecated
    public static void copy(final Reader reader, final OutputStream out) throws IOException {
        final OutputStreamWriter outputStreamWriter = new OutputStreamWriter(out, q.sx());
        copy(reader, outputStreamWriter);
        q.sw(outputStreamWriter);
    }
    
    public static void copy(final Reader reader, final OutputStream out, final String charsetName) throws IOException {
        final OutputStreamWriter outputStreamWriter = new OutputStreamWriter(out, charsetName);
        copy(reader, outputStreamWriter);
        q.sw(outputStreamWriter);
    }
    
    @Deprecated
    public static void copy(final String s, final OutputStream out) throws IOException {
        final StringReader stringReader = new StringReader(s);
        final OutputStreamWriter outputStreamWriter = new OutputStreamWriter(out, q.sx());
        copy(stringReader, outputStreamWriter);
        q.sw(outputStreamWriter);
    }
    
    public static void copy(final String s, final OutputStream out, final String charsetName) throws IOException {
        final StringReader stringReader = new StringReader(s);
        final OutputStreamWriter outputStreamWriter = new OutputStreamWriter(out, charsetName);
        copy(stringReader, outputStreamWriter);
        q.sw(outputStreamWriter);
    }
    
    public static void copy(final String s, final Writer writer) throws IOException {
        q.sa(writer, s);
    }
}
