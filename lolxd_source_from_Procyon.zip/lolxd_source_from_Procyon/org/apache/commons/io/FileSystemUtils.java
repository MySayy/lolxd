// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import java.io.OutputStream;
import java.io.InputStream;
import com.sun.jna.Structure;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import n.d.a.d.q;
import java.io.IOException;

public class FileSystemUtils
{
    private static final FileSystemUtils INSTANCE;
    private static final int INIT_PROBLEM = -1;
    private static final int OTHER = 0;
    private static final int WINDOWS = 1;
    private static final int UNIX = 2;
    private static final int POSIX_UNIX = 3;
    private static final int OS;
    private static final String DF;
    private static final String[] a;
    private static final String[] b;
    
    @Deprecated
    public static long freeSpace(final String s) throws IOException {
        return FileSystemUtils.INSTANCE.freeSpaceOS(s, FileSystemUtils.OS, false, -1L);
    }
    
    public static long freeSpaceKb(final String s) throws IOException {
        return freeSpaceKb(s, -1L);
    }
    
    public static long freeSpaceKb(final String s, final long n) throws IOException {
        return FileSystemUtils.INSTANCE.freeSpaceOS(s, FileSystemUtils.OS, true, n);
    }
    
    public static long freeSpaceKb() throws IOException {
        return freeSpaceKb(-1L);
    }
    
    public static long freeSpaceKb(final long n) throws IOException {
        return freeSpaceKb(q.o.m.s.q.kj(new File(q.g())), n);
    }
    
    long freeSpaceOS(final String s, final int n, final boolean b, final long n2) throws IOException {
        final int c = IOCase.c();
        try {
            if (s == null) {
                throw new IllegalArgumentException(a(-28091, 51));
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
        Label_0105: {
            FileSystemUtils fileSystemUtils = null;
            String s2 = null;
            long n4 = 0L;
            Label_0081: {
                Label_0047: {
                    try {
                        final boolean b2 = n != 0;
                        if (c == 0) {
                            break Label_0081;
                        }
                        final int n3 = c;
                        if (n3 != 0) {
                            break Label_0047;
                        }
                        break Label_0081;
                    }
                    catch (IOException ex2) {
                        throw b(ex2);
                    }
                    try {
                        final int n3 = c;
                        if (n3 == 0) {
                            break Label_0081;
                        }
                        switch (n) {
                            case 1: {
                                break;
                            }
                            case 2: {
                                return this.freeSpaceUnix(s, b, false, n2);
                            }
                            case 3: {
                                return this.freeSpaceUnix(s, b, true, n2);
                            }
                            case 0: {
                                throw new IllegalStateException(a(-28057, 27165));
                            }
                            default: {
                                throw new IllegalStateException(a(-28092, -6983));
                            }
                        }
                    }
                    catch (IOException ex3) {
                        throw b(ex3);
                    }
                }
                final boolean b2 = b;
                try {
                    if (!b2) {
                        break Label_0105;
                    }
                    fileSystemUtils = this;
                    s2 = s;
                    n4 = n2;
                }
                catch (IOException ex4) {
                    throw b(ex4);
                }
            }
            return fileSystemUtils.freeSpaceWindows(s2, n4) / 1024L;
        }
        FileSystemUtils fileSystemUtils = this;
        String s2 = s;
        long n4 = n2;
        if (c == 0) {
            return fileSystemUtils.freeSpaceWindows(s2, n4) / 1024L;
        }
        return this.freeSpaceWindows(s, n2);
    }
    
    long freeSpaceWindows(final String p0, final long p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     4: iconst_0       
        //     5: invokestatic    org/apache/commons/io/FilenameUtils.normalize:(Ljava/lang/String;Z)Ljava/lang/String;
        //     8: astore_1       
        //     9: istore          4
        //    11: aload_1        
        //    12: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //    15: iload           4
        //    17: ifeq            99
        //    20: ifle            98
        //    23: goto            30
        //    26: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    29: athrow         
        //    30: aload_1        
        //    31: iload           4
        //    33: ifeq            97
        //    36: goto            43
        //    39: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    42: athrow         
        //    43: iconst_0       
        //    44: invokestatic    q/o/m/s/q.j:(Ljava/lang/String;I)C
        //    47: goto            54
        //    50: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    53: athrow         
        //    54: iload           4
        //    56: ifeq            99
        //    59: bipush          34
        //    61: if_icmpeq       98
        //    64: new             Ljava/lang/StringBuilder;
        //    67: dup            
        //    68: invokespecial   java/lang/StringBuilder.<init>:()V
        //    71: invokestatic    n/d/a/d/q.vs:()Ljava/lang/String;
        //    74: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    77: aload_1        
        //    78: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    81: invokestatic    n/d/a/d/q.vs:()Ljava/lang/String;
        //    84: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    87: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    90: goto            97
        //    93: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    96: athrow         
        //    97: astore_1       
        //    98: iconst_3       
        //    99: anewarray       Ljava/lang/String;
        //   102: dup            
        //   103: iconst_0       
        //   104: sipush          -28062
        //   107: sipush          29468
        //   110: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   113: aastore        
        //   114: dup            
        //   115: iconst_1       
        //   116: sipush          -28086
        //   119: sipush          13068
        //   122: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   125: aastore        
        //   126: dup            
        //   127: iconst_2       
        //   128: new             Ljava/lang/StringBuilder;
        //   131: dup            
        //   132: invokespecial   java/lang/StringBuilder.<init>:()V
        //   135: sipush          -28077
        //   138: sipush          -17849
        //   141: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   144: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   147: aload_1        
        //   148: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   151: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   154: aastore        
        //   155: astore          5
        //   157: aload_0        
        //   158: aload           5
        //   160: ldc             2147483647
        //   162: lload_2        
        //   163: invokevirtual   org/apache/commons/io/FileSystemUtils.performCommand:([Ljava/lang/String;IJ)Ljava/util/List;
        //   166: astore          6
        //   168: aload           6
        //   170: invokestatic    q/o/m/s/q.kg:(Ljava/util/List;)I
        //   173: iconst_1       
        //   174: isub           
        //   175: iload           4
        //   177: ifeq            54
        //   180: istore          7
        //   182: iload           7
        //   184: iflt            239
        //   187: aload           6
        //   189: iload           7
        //   191: invokestatic    q/o/m/s/q.kz:(Ljava/util/List;I)Ljava/lang/Object;
        //   194: checkcast       Ljava/lang/String;
        //   197: astore          8
        //   199: iload           4
        //   201: ifeq            234
        //   204: aload           8
        //   206: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //   209: ifle            231
        //   212: goto            219
        //   215: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   218: athrow         
        //   219: aload_0        
        //   220: aload           8
        //   222: aload_1        
        //   223: invokevirtual   org/apache/commons/io/FileSystemUtils.parseDir:(Ljava/lang/String;Ljava/lang/String;)J
        //   226: lreturn        
        //   227: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   230: athrow         
        //   231: iinc            7, -1
        //   234: iload           4
        //   236: ifne            182
        //   239: new             Ljava/io/IOException;
        //   242: dup            
        //   243: new             Ljava/lang/StringBuilder;
        //   246: dup            
        //   247: invokespecial   java/lang/StringBuilder.<init>:()V
        //   250: sipush          -28075
        //   253: sipush          -26165
        //   256: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   259: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   262: aload_1        
        //   263: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   266: invokestatic    n/d/a/d/q.vk:()Ljava/lang/String;
        //   269: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   272: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   275: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   278: athrow         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 11 FF 00 1A 00 04 07 00 02 07 00 52 04 01 00 01 07 00 20 03 48 07 00 20 43 07 00 52 46 07 00 20 43 01 66 07 00 20 43 07 00 52 00 40 01 FE 00 52 07 00 87 07 00 89 01 FF 00 20 00 08 07 00 02 07 00 52 04 01 07 00 87 07 00 89 01 07 00 52 00 01 07 00 20 03 47 07 00 20 03 02 FA 00 04
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  11     23     26     30     Ljava/io/IOException;
        //  20     36     39     43     Ljava/io/IOException;
        //  30     47     50     54     Ljava/io/IOException;
        //  59     90     93     97     Ljava/io/IOException;
        //  199    212    215    219    Ljava/io/IOException;
        //  204    227    227    231    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0030:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    long parseDir(final String p0, final String p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     4: istore          4
        //     6: iconst_0       
        //     7: istore          5
        //     9: istore_3       
        //    10: aload_1        
        //    11: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //    14: iconst_1       
        //    15: isub           
        //    16: istore          6
        //    18: iload           6
        //    20: iflt            82
        //    23: aload_1        
        //    24: iload           6
        //    26: invokestatic    q/o/m/s/q.j:(Ljava/lang/String;I)C
        //    29: istore          7
        //    31: iload_3        
        //    32: ifeq            78
        //    35: iload           7
        //    37: invokestatic    q/o/m/s/q.kd:(C)Z
        //    40: iload_3        
        //    41: ifeq            84
        //    44: goto            51
        //    47: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    50: athrow         
        //    51: ifeq            71
        //    54: goto            61
        //    57: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    60: athrow         
        //    61: iload           6
        //    63: iconst_1       
        //    64: iadd           
        //    65: istore          5
        //    67: iload_3        
        //    68: ifne            82
        //    71: iinc            6, -1
        //    74: iload_3        
        //    75: ifeq            67
        //    78: iload_3        
        //    79: ifne            18
        //    82: iload           6
        //    84: iflt            218
        //    87: aload_1        
        //    88: iload           6
        //    90: invokestatic    q/o/m/s/q.j:(Ljava/lang/String;I)C
        //    93: istore          7
        //    95: iload_3        
        //    96: ifeq            214
        //    99: iload           7
        //   101: invokestatic    q/o/m/s/q.kd:(C)Z
        //   104: iload_3        
        //   105: ifeq            220
        //   108: goto            115
        //   111: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   114: athrow         
        //   115: iload_3        
        //   116: ifeq            138
        //   119: goto            126
        //   122: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   125: athrow         
        //   126: ifne            207
        //   129: goto            136
        //   132: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   135: athrow         
        //   136: iload           7
        //   138: bipush          44
        //   140: iload_3        
        //   141: ifeq            176
        //   144: iload_3        
        //   145: ifeq            176
        //   148: goto            155
        //   151: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   154: athrow         
        //   155: if_icmpeq       207
        //   158: goto            165
        //   161: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   164: athrow         
        //   165: iload           7
        //   167: bipush          46
        //   169: goto            176
        //   172: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   175: athrow         
        //   176: iload_3        
        //   177: ifeq            200
        //   180: if_icmpeq       207
        //   183: goto            190
        //   186: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   189: athrow         
        //   190: iload           6
        //   192: iconst_1       
        //   193: goto            200
        //   196: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   199: athrow         
        //   200: iadd           
        //   201: istore          4
        //   203: iload_3        
        //   204: ifne            218
        //   207: iinc            6, -1
        //   210: iload_3        
        //   211: ifeq            203
        //   214: iload_3        
        //   215: ifne            82
        //   218: iload           6
        //   220: ifge            267
        //   223: new             Ljava/io/IOException;
        //   226: dup            
        //   227: new             Ljava/lang/StringBuilder;
        //   230: dup            
        //   231: invokespecial   java/lang/StringBuilder.<init>:()V
        //   234: sipush          -28081
        //   237: sipush          -19682
        //   240: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   243: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   246: aload_2        
        //   247: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   250: invokestatic    n/d/a/d/q.vk:()Ljava/lang/String;
        //   253: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   256: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   259: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   262: athrow         
        //   263: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   266: athrow         
        //   267: new             Ljava/lang/StringBuilder;
        //   270: dup            
        //   271: aload_1        
        //   272: iload           4
        //   274: iload           5
        //   276: invokestatic    q/o/m/s/q.h:(Ljava/lang/String;II)Ljava/lang/String;
        //   279: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   282: astore          7
        //   284: iconst_0       
        //   285: istore          8
        //   287: iload           8
        //   289: aload           7
        //   291: invokestatic    q/o/m/s/q.kb:(Ljava/lang/StringBuilder;)I
        //   294: if_icmpge       383
        //   297: aload           7
        //   299: iload           8
        //   301: iload_3        
        //   302: ifeq            368
        //   305: invokestatic    q/o/m/s/q.kw:(Ljava/lang/StringBuilder;I)C
        //   308: bipush          44
        //   310: if_icmpeq       354
        //   313: goto            320
        //   316: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   319: athrow         
        //   320: aload           7
        //   322: goto            329
        //   325: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   328: athrow         
        //   329: iload           8
        //   331: iload_3        
        //   332: ifeq            368
        //   335: iload_3        
        //   336: ifeq            368
        //   339: invokestatic    q/o/m/s/q.kw:(Ljava/lang/StringBuilder;I)C
        //   342: bipush          46
        //   344: if_icmpne       376
        //   347: goto            354
        //   350: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   353: athrow         
        //   354: aload           7
        //   356: iload           8
        //   358: iinc            8, -1
        //   361: goto            368
        //   364: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   367: athrow         
        //   368: invokestatic    q/o/m/s/q.ka:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   371: iload_3        
        //   372: ifeq            329
        //   375: pop            
        //   376: iinc            8, 1
        //   379: iload_3        
        //   380: ifne            287
        //   383: aload_0        
        //   384: aload           7
        //   386: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   389: aload_2        
        //   390: invokevirtual   org/apache/commons/io/FileSystemUtils.parseBytes:(Ljava/lang/String;Ljava/lang/String;)J
        //   393: lreturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 2D FF 00 12 00 07 07 00 02 07 00 52 07 00 52 01 01 01 01 00 00 FF 00 1C 00 08 07 00 02 07 00 52 07 00 52 01 01 01 01 01 00 01 07 00 20 43 01 45 07 00 20 03 05 03 06 FA 00 03 41 01 FF 00 1A 00 08 07 00 02 07 00 52 07 00 52 01 01 01 01 01 00 01 07 00 20 43 01 46 07 00 20 43 01 45 07 00 20 03 41 01 4C 07 00 20 FF 00 03 00 08 07 00 02 07 00 52 07 00 52 01 01 01 01 01 00 02 01 01 45 07 00 20 03 46 07 00 20 FF 00 03 00 08 07 00 02 07 00 52 07 00 52 01 01 01 01 01 00 02 01 01 49 07 00 20 03 45 07 00 20 FF 00 03 00 08 07 00 02 07 00 52 07 00 52 01 01 01 01 01 00 02 01 01 02 03 06 FA 00 03 41 01 6A 07 00 20 03 FD 00 13 07 00 71 01 5C 07 00 20 03 44 07 00 20 43 07 00 71 54 07 00 20 03 49 07 00 20 FF 00 03 00 09 07 00 02 07 00 52 07 00 52 01 01 01 01 07 00 71 01 00 02 07 00 71 01 07 06
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  31     44     47     51     Ljava/io/IOException;
        //  35     54     57     61     Ljava/io/IOException;
        //  95     108    111    115    Ljava/io/IOException;
        //  99     119    122    126    Ljava/io/IOException;
        //  115    129    132    136    Ljava/io/IOException;
        //  138    148    151    155    Ljava/io/IOException;
        //  144    158    161    165    Ljava/io/IOException;
        //  155    169    172    176    Ljava/io/IOException;
        //  176    183    186    190    Ljava/io/IOException;
        //  180    193    196    200    Ljava/io/IOException;
        //  220    263    263    267    Ljava/io/IOException;
        //  297    313    316    320    Ljava/io/IOException;
        //  305    322    325    329    Ljava/io/IOException;
        //  335    347    350    354    Ljava/io/IOException;
        //  339    361    364    368    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0115:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    long freeSpaceUnix(final String p0, final boolean p1, final boolean p2, final long p3) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     5: aload_1        
        //     6: iload           6
        //     8: ifeq            48
        //    11: invokestatic    q/o/m/s/q.sq:(Ljava/lang/String;)Z
        //    14: ifeq            45
        //    17: goto            24
        //    20: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    23: athrow         
        //    24: new             Ljava/lang/IllegalArgumentException;
        //    27: dup            
        //    28: sipush          -28068
        //    31: sipush          -13239
        //    34: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //    37: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //    40: athrow         
        //    41: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    44: athrow         
        //    45: invokestatic    n/d/a/d/q.ve:()Ljava/lang/String;
        //    48: astore          7
        //    50: iload_2        
        //    51: iload           6
        //    53: ifeq            90
        //    56: ifeq            89
        //    59: goto            66
        //    62: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    65: athrow         
        //    66: new             Ljava/lang/StringBuilder;
        //    69: dup            
        //    70: invokespecial   java/lang/StringBuilder.<init>:()V
        //    73: aload           7
        //    75: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    78: invokestatic    n/d/a/d/q.vn:()Ljava/lang/String;
        //    81: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    84: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    87: astore          7
        //    89: iload_3        
        //    90: iload           6
        //    92: ifeq            145
        //    95: ifeq            135
        //    98: goto            105
        //   101: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   104: athrow         
        //   105: new             Ljava/lang/StringBuilder;
        //   108: dup            
        //   109: invokespecial   java/lang/StringBuilder.<init>:()V
        //   112: aload           7
        //   114: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   117: invokestatic    n/d/a/d/q.vp:()Ljava/lang/String;
        //   120: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   123: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   126: goto            133
        //   129: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   132: athrow         
        //   133: astore          7
        //   135: aload           7
        //   137: iload           6
        //   139: ifeq            133
        //   142: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //   145: iload           6
        //   147: ifeq            191
        //   150: iconst_1       
        //   151: if_icmple       190
        //   154: goto            161
        //   157: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   160: athrow         
        //   161: iconst_3       
        //   162: anewarray       Ljava/lang/String;
        //   165: dup            
        //   166: iconst_0       
        //   167: getstatic       org/apache/commons/io/FileSystemUtils.DF:Ljava/lang/String;
        //   170: aastore        
        //   171: dup            
        //   172: iconst_1       
        //   173: aload           7
        //   175: aastore        
        //   176: dup            
        //   177: iconst_2       
        //   178: aload_1        
        //   179: goto            186
        //   182: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   185: athrow         
        //   186: aastore        
        //   187: goto            209
        //   190: iconst_2       
        //   191: anewarray       Ljava/lang/String;
        //   194: dup            
        //   195: iconst_0       
        //   196: getstatic       org/apache/commons/io/FileSystemUtils.DF:Ljava/lang/String;
        //   199: aastore        
        //   200: dup            
        //   201: iconst_1       
        //   202: aload_1        
        //   203: iload           6
        //   205: ifeq            186
        //   208: aastore        
        //   209: astore          8
        //   211: aload_0        
        //   212: aload           8
        //   214: iconst_3       
        //   215: lload           4
        //   217: invokevirtual   org/apache/commons/io/FileSystemUtils.performCommand:([Ljava/lang/String;IJ)Ljava/util/List;
        //   220: astore          9
        //   222: aload           9
        //   224: iload           6
        //   226: ifeq            334
        //   229: invokestatic    q/o/m/s/q.kg:(Ljava/util/List;)I
        //   232: iconst_2       
        //   233: if_icmpge       328
        //   236: goto            243
        //   239: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   242: athrow         
        //   243: new             Ljava/io/IOException;
        //   246: dup            
        //   247: new             Ljava/lang/StringBuilder;
        //   250: dup            
        //   251: invokespecial   java/lang/StringBuilder.<init>:()V
        //   254: sipush          -28090
        //   257: sipush          -2296
        //   260: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   263: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   266: getstatic       org/apache/commons/io/FileSystemUtils.DF:Ljava/lang/String;
        //   269: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   272: sipush          -28088
        //   275: sipush          -19551
        //   278: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   281: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   284: sipush          -28061
        //   287: sipush          1886
        //   290: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   293: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   296: aload_1        
        //   297: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   300: sipush          -28071
        //   303: sipush          -22547
        //   306: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   309: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   312: aload           9
        //   314: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   317: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   320: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   323: athrow         
        //   324: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   327: athrow         
        //   328: aload           9
        //   330: iconst_1       
        //   331: invokestatic    q/o/m/s/q.kz:(Ljava/util/List;I)Ljava/lang/Object;
        //   334: checkcast       Ljava/lang/String;
        //   337: astore          10
        //   339: new             Ljava/util/StringTokenizer;
        //   342: dup            
        //   343: aload           10
        //   345: invokestatic    n/d/a/d/q.m:()Ljava/lang/String;
        //   348: invokespecial   java/util/StringTokenizer.<init>:(Ljava/lang/String;Ljava/lang/String;)V
        //   351: astore          11
        //   353: aload           11
        //   355: iload           6
        //   357: ifeq            574
        //   360: invokestatic    q/o/m/s/q.kl:(Ljava/util/StringTokenizer;)I
        //   363: iconst_4       
        //   364: if_icmpge       567
        //   367: goto            374
        //   370: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   373: athrow         
        //   374: aload           11
        //   376: goto            383
        //   379: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   382: athrow         
        //   383: invokestatic    q/o/m/s/q.kl:(Ljava/util/StringTokenizer;)I
        //   386: iconst_1       
        //   387: iload           6
        //   389: ifeq            439
        //   392: iload           6
        //   394: ifeq            439
        //   397: goto            404
        //   400: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   403: athrow         
        //   404: if_icmpne       479
        //   407: goto            414
        //   410: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   413: athrow         
        //   414: aload           9
        //   416: iload           6
        //   418: ifeq            455
        //   421: goto            428
        //   424: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   427: athrow         
        //   428: invokestatic    q/o/m/s/q.kg:(Ljava/util/List;)I
        //   431: iconst_3       
        //   432: goto            439
        //   435: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   438: athrow         
        //   439: if_icmplt       479
        //   442: aload           9
        //   444: iconst_2       
        //   445: invokestatic    q/o/m/s/q.kz:(Ljava/util/List;I)Ljava/lang/Object;
        //   448: goto            455
        //   451: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   454: athrow         
        //   455: checkcast       Ljava/lang/String;
        //   458: astore          12
        //   460: new             Ljava/util/StringTokenizer;
        //   463: dup            
        //   464: aload           12
        //   466: invokestatic    n/d/a/d/q.m:()Ljava/lang/String;
        //   469: invokespecial   java/util/StringTokenizer.<init>:(Ljava/lang/String;Ljava/lang/String;)V
        //   472: astore          11
        //   474: iload           6
        //   476: ifne            578
        //   479: new             Ljava/io/IOException;
        //   482: dup            
        //   483: new             Ljava/lang/StringBuilder;
        //   486: dup            
        //   487: invokespecial   java/lang/StringBuilder.<init>:()V
        //   490: sipush          -28090
        //   493: sipush          -2296
        //   496: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   499: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   502: getstatic       org/apache/commons/io/FileSystemUtils.DF:Ljava/lang/String;
        //   505: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   508: sipush          -28079
        //   511: sipush          -5125
        //   514: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   517: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   520: sipush          -28061
        //   523: sipush          1886
        //   526: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   529: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   532: aload_1        
        //   533: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   536: sipush          -28060
        //   539: sipush          -23035
        //   542: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   545: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   548: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   551: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   554: iload           6
        //   556: ifeq            455
        //   559: goto            566
        //   562: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   565: athrow         
        //   566: athrow         
        //   567: aload           11
        //   569: iload           6
        //   571: ifeq            383
        //   574: invokestatic    q/o/m/s/q.ki:(Ljava/util/StringTokenizer;)Ljava/lang/String;
        //   577: pop            
        //   578: aload           11
        //   580: invokestatic    q/o/m/s/q.ki:(Ljava/util/StringTokenizer;)Ljava/lang/String;
        //   583: pop            
        //   584: aload           11
        //   586: invokestatic    q/o/m/s/q.ki:(Ljava/util/StringTokenizer;)Ljava/lang/String;
        //   589: pop            
        //   590: aload           11
        //   592: invokestatic    q/o/m/s/q.ki:(Ljava/util/StringTokenizer;)Ljava/lang/String;
        //   595: astore          12
        //   597: aload_0        
        //   598: aload           12
        //   600: aload_1        
        //   601: invokevirtual   org/apache/commons/io/FileSystemUtils.parseBytes:(Ljava/lang/String;Ljava/lang/String;)J
        //   604: lreturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 2F FF 00 14 00 06 07 00 02 07 00 52 01 01 04 01 00 01 07 00 20 03 50 07 00 20 03 42 07 00 52 FF 00 0D 00 07 07 00 02 07 00 52 01 01 04 01 07 00 52 00 01 07 00 20 03 16 40 01 4A 07 00 20 03 57 07 00 20 43 07 00 52 01 49 01 4B 07 00 20 03 54 07 00 20 FF 00 03 00 07 07 00 02 07 00 52 01 01 04 01 07 00 52 00 04 07 00 87 07 00 87 01 07 00 52 03 40 01 51 07 00 87 FF 00 1D 00 09 07 00 02 07 00 52 01 01 04 01 07 00 52 07 00 87 07 00 89 00 01 07 00 20 03 F7 00 50 07 00 20 03 45 07 00 04 FF 00 23 00 0B 07 00 02 07 00 52 01 01 04 01 07 00 52 07 00 87 07 00 89 07 00 52 07 00 C2 00 01 07 00 20 03 44 07 00 20 43 07 00 C2 50 07 00 20 FF 00 03 00 0B 07 00 02 07 00 52 01 01 04 01 07 00 52 07 00 87 07 00 89 07 00 52 07 00 C2 00 02 01 01 45 07 00 20 03 49 07 00 20 43 07 00 89 46 07 00 20 FF 00 03 00 0B 07 00 02 07 00 52 01 01 04 01 07 00 52 07 00 87 07 00 89 07 00 52 07 00 C2 00 02 01 01 4B 07 00 20 43 07 00 04 17 F7 00 52 07 00 20 43 07 00 20 00 46 07 00 C2 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  5      17     20     24     Ljava/io/IOException;
        //  11     41     41     45     Ljava/io/IOException;
        //  50     59     62     66     Ljava/io/IOException;
        //  90     98     101    105    Ljava/io/IOException;
        //  95     126    129    133    Ljava/io/IOException;
        //  145    154    157    161    Ljava/io/IOException;
        //  150    179    182    186    Ljava/io/IOException;
        //  222    236    239    243    Ljava/io/IOException;
        //  229    324    324    328    Ljava/io/IOException;
        //  353    367    370    374    Ljava/io/IOException;
        //  360    376    379    383    Ljava/io/IOException;
        //  383    397    400    404    Ljava/io/IOException;
        //  392    407    410    414    Ljava/io/IOException;
        //  404    421    424    428    Ljava/io/IOException;
        //  414    432    435    439    Ljava/io/IOException;
        //  439    448    451    455    Ljava/io/IOException;
        //  474    559    562    566    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0404:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    long parseBytes(final String s, final String s2) throws IOException {
        final int c = IOCase.c();
        try {
            final long ku = q.o.m.s.q.ku(s);
            Label_0028: {
                long n;
                try {
                    final long n2;
                    n = (n2 = ku);
                    if (c == 0) {
                        return n2;
                    }
                    final long n3 = 0L;
                    final long n4 = lcmp(n, n3);
                    if (n4 < 0) {
                        break Label_0028;
                    }
                    return ku;
                }
                catch (NumberFormatException ex) {
                    throw b(ex);
                }
                try {
                    final long n3 = 0L;
                    final long n4 = lcmp(n, n3);
                    if (n4 < 0) {
                        throw new IOException(q.o.m.s.q.s(q.o.m.s.q.r(q.o.m.s.q.r(q.o.m.s.q.r(q.o.m.s.q.r(q.o.m.s.q.r(q.o.m.s.q.r(new StringBuilder(), a(-28090, -2296)), FileSystemUtils.DF), a(-28059, -19600)), a(-28061, 1886)), s2), a(-28060, -23035))));
                    }
                }
                catch (NumberFormatException ex2) {
                    throw b(ex2);
                }
            }
            return ku;
        }
        catch (NumberFormatException cause) {
            throw new IOException(q.o.m.s.q.s(q.o.m.s.q.r(q.o.m.s.q.r(q.o.m.s.q.r(q.o.m.s.q.r(q.o.m.s.q.r(q.o.m.s.q.r(new StringBuilder(), a(-28090, -2296)), FileSystemUtils.DF), a(-28073, 28032)), a(-28061, 1886)), s2), a(-28060, -23035))), cause);
        }
    }
    
    List<String> performCommand(final String[] array, final int n, final long n2) throws IOException {
        final int b = IOCase.b();
        final ArrayList<String> list = new ArrayList<String>(20);
        int n3 = b;
        Process openProcess = null;
        InputStream v = null;
        OutputStream ef = null;
        InputStream em = null;
        BufferedReader bufferedReader = null;
        try {
            final Thread start = ThreadMonitor.start(n2);
            openProcess = this.openProcess(array);
            v = q.o.m.s.q.v(openProcess);
            ef = q.o.m.s.q.ef(openProcess);
            em = q.o.m.s.q.em(openProcess);
            bufferedReader = new BufferedReader(new InputStreamReader(v, q.o.m.s.q.sx()));
            String s = q.o.m.s.q.o(bufferedReader);
            int n5 = 0;
            int eq = 0;
        Label_0151_Outer:
            while (true) {
                while (true) {
                    Label_0180: {
                        Label_0164: {
                            if (s == null) {
                                break Label_0164;
                            }
                            Label_0120: {
                                int n4;
                                try {
                                    n4 = (eq = (n5 = q.o.m.s.q.kg(list)));
                                    if (n3 != 0) {
                                        break Label_0180;
                                    }
                                    final int n6 = n3;
                                    if (n6 == 0) {
                                        break Label_0120;
                                    }
                                    break;
                                }
                                catch (InterruptedException ex) {
                                    throw b(ex);
                                }
                                try {
                                    final int n6 = n3;
                                    if (n6 != 0) {
                                        break;
                                    }
                                    if (n4 >= n) {
                                        break Label_0164;
                                    }
                                }
                                catch (InterruptedException ex2) {
                                    throw b(ex2);
                                }
                            }
                            q.o.m.s.q.qw(list, q.o.m.s.q.qd(q.o.m.s.q.ev(s, x.dn.g.b.q.k())));
                            s = q.o.m.s.q.o(bufferedReader);
                            if (n3 == 0) {
                                continue Label_0151_Outer;
                            }
                        }
                        q.o.m.s.q.eo(openProcess);
                        ThreadMonitor.stop(start);
                        n5 = (eq = q.o.m.s.q.eq(openProcess));
                    }
                    if (n3 == 0) {
                        break;
                    }
                    continue;
                }
            }
            ArrayList<String> list2 = null;
            Label_0278: {
                Label_0261: {
                    Label_0200: {
                        try {
                            if (n3 != 0) {
                                break Label_0278;
                            }
                            if (eq != 0) {
                                break Label_0200;
                            }
                            break Label_0261;
                        }
                        catch (InterruptedException ex3) {
                            throw b(ex3);
                        }
                        try {
                            if (eq != 0) {
                                throw new IOException(q.o.m.s.q.s(q.o.m.s.q.kx(q.o.m.s.q.r(q.o.m.s.q.qg(q.o.m.s.q.r(new StringBuilder(), a(-28087, 30394)), q.o.m.s.q.eq(openProcess)), a(-28093, -28780)), q.o.m.s.q.et(array))));
                            }
                        }
                        catch (InterruptedException ex4) {
                            throw b(ex4);
                        }
                    }
                    try {
                        list2 = list;
                        if (n3 != 0) {
                            break Label_0278;
                        }
                        n5 = (q.o.m.s.q.rr(list2) ? 1 : 0);
                    }
                    catch (InterruptedException ex5) {
                        throw b(ex5);
                    }
                }
                try {
                    if (n5 != 0) {
                        throw new IOException(q.o.m.s.q.s(q.o.m.s.q.kx(q.o.m.s.q.r(new StringBuilder(), a(-28070, -27981)), q.o.m.s.q.et(array))));
                    }
                }
                catch (InterruptedException ex6) {
                    throw b(ex6);
                }
            }
            final ArrayList<String> list3 = list2;
            ArrayList<String> list4 = null;
            Label_0380: {
                Process process = null;
                Label_0365: {
                    try {
                        IOUtils.closeQuietly(v);
                        IOUtils.closeQuietly(ef);
                        IOUtils.closeQuietly(em);
                        IOUtils.closeQuietly(bufferedReader);
                        process = openProcess;
                        if (n3 != 0) {
                            break Label_0365;
                        }
                        final int n7 = n3;
                        if (n7 == 0) {
                            break Label_0365;
                        }
                        break Label_0365;
                    }
                    catch (InterruptedException ex7) {
                        throw b(ex7);
                    }
                    try {
                        final int n7 = n3;
                        if (n7 != 0) {
                            break Label_0365;
                        }
                        if (process == null) {
                            break Label_0380;
                        }
                    }
                    catch (InterruptedException ex8) {
                        throw b(ex8);
                    }
                }
                q.o.m.s.q.er(process);
                try {
                    list4 = list3;
                    if (Structure.b() != 0) {
                        IOCase.b(++n3);
                    }
                }
                catch (InterruptedException ex9) {
                    throw b(ex9);
                }
            }
            return list4;
        }
        catch (InterruptedException cause) {
            throw new IOException(q.o.m.s.q.s(q.o.m.s.q.es(q.o.m.s.q.r(q.o.m.s.q.kx(q.o.m.s.q.r(new StringBuilder(), a(-28058, 16517)), q.o.m.s.q.et(array)), a(-28085, -23177)), n2)), cause);
        }
        finally {
            Label_0517: {
                Process process2 = null;
                Label_0502: {
                    try {
                        IOUtils.closeQuietly(v);
                        IOUtils.closeQuietly(ef);
                        IOUtils.closeQuietly(em);
                        IOUtils.closeQuietly(bufferedReader);
                        process2 = openProcess;
                        if (n3 != 0) {
                            break Label_0502;
                        }
                        final int n8 = n3;
                        if (n8 == 0) {
                            break Label_0502;
                        }
                        break Label_0502;
                    }
                    catch (InterruptedException ex10) {
                        throw b(ex10);
                    }
                    try {
                        final int n8 = n3;
                        if (n8 != 0) {
                            break Label_0502;
                        }
                        if (process2 == null) {
                            break Label_0517;
                        }
                    }
                    catch (InterruptedException ex11) {
                        throw b(ex11);
                    }
                }
                q.o.m.s.q.er(process2);
            }
        }
    }
    
    Process openProcess(final String[] array) throws IOException {
        return q.o.m.s.q.m(q.o.m.s.q.f(), array);
    }
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     2: anewarray       Ljava/lang/String;
        //     5: astore          5
        //     7: iconst_0       
        //     8: istore_3       
        //     9: invokestatic    n/d/a/d/q.vy:()Ljava/lang/String;
        //    12: dup            
        //    13: astore_2       
        //    14: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //    17: istore          4
        //    19: iconst_5       
        //    20: istore_1       
        //    21: iconst_m1      
        //    22: istore_0       
        //    23: bipush          111
        //    25: iinc            0, 1
        //    28: aload_2        
        //    29: iload_0        
        //    30: dup            
        //    31: iload_1        
        //    32: iadd           
        //    33: invokestatic    q/o/m/s/q.h:(Ljava/lang/String;II)Ljava/lang/String;
        //    36: iconst_m1      
        //    37: goto            144
        //    40: aload           5
        //    42: swap           
        //    43: iload_3        
        //    44: iinc            3, 1
        //    47: swap           
        //    48: aastore        
        //    49: iload_0        
        //    50: iload_1        
        //    51: iadd           
        //    52: dup            
        //    53: istore_0       
        //    54: iload           4
        //    56: if_icmpge       68
        //    59: aload_2        
        //    60: iload_0        
        //    61: invokestatic    q/o/m/s/q.j:(Ljava/lang/String;I)C
        //    64: istore_1       
        //    65: goto            23
        //    68: invokestatic    n/d/a/d/q.vc:()Ljava/lang/String;
        //    71: dup            
        //    72: astore_2       
        //    73: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //    76: istore          4
        //    78: bipush          7
        //    80: istore_1       
        //    81: iconst_m1      
        //    82: istore_0       
        //    83: bipush          44
        //    85: iinc            0, 1
        //    88: aload_2        
        //    89: iload_0        
        //    90: dup            
        //    91: iload_1        
        //    92: iadd           
        //    93: invokestatic    q/o/m/s/q.h:(Ljava/lang/String;II)Ljava/lang/String;
        //    96: iconst_0       
        //    97: goto            144
        //   100: aload           5
        //   102: swap           
        //   103: iload_3        
        //   104: iinc            3, 1
        //   107: swap           
        //   108: aastore        
        //   109: iload_0        
        //   110: iload_1        
        //   111: iadd           
        //   112: dup            
        //   113: istore_0       
        //   114: iload           4
        //   116: if_icmpge       128
        //   119: aload_2        
        //   120: iload_0        
        //   121: invokestatic    q/o/m/s/q.j:(Ljava/lang/String;I)C
        //   124: istore_1       
        //   125: goto            83
        //   128: aload           5
        //   130: putstatic       org/apache/commons/io/FileSystemUtils.a:[Ljava/lang/String;
        //   133: bipush          39
        //   135: anewarray       Ljava/lang/String;
        //   138: putstatic       org/apache/commons/io/FileSystemUtils.b:[Ljava/lang/String;
        //   141: goto            300
        //   144: dup_x2         
        //   145: pop            
        //   146: invokestatic    q/o/m/s/q.g:(Ljava/lang/String;)[C
        //   149: dup_x1         
        //   150: arraylength    
        //   151: dup_x2         
        //   152: pop            
        //   153: iconst_0       
        //   154: istore          6
        //   156: dup2_x1        
        //   157: pop2           
        //   158: dup_x2         
        //   159: iconst_1       
        //   160: if_icmpgt       260
        //   163: dup2           
        //   164: swap           
        //   165: iload           6
        //   167: dup2_x1        
        //   168: caload         
        //   169: swap           
        //   170: iload           6
        //   172: bipush          7
        //   174: irem           
        //   175: tableswitch {
        //                0: 212
        //                1: 217
        //                2: 222
        //                3: 227
        //                4: 232
        //                5: 237
        //          default: 242
        //        }
        //   212: bipush          6
        //   214: goto            244
        //   217: bipush          66
        //   219: goto            244
        //   222: bipush          108
        //   224: goto            244
        //   227: bipush          85
        //   229: goto            244
        //   232: bipush          82
        //   234: goto            244
        //   237: bipush          27
        //   239: goto            244
        //   242: bipush          27
        //   244: ixor           
        //   245: ixor           
        //   246: i2c            
        //   247: castore        
        //   248: iinc            6, 1
        //   251: dup            
        //   252: ifne            260
        //   255: dup2           
        //   256: dup_x1         
        //   257: goto            167
        //   260: dup2_x1        
        //   261: pop2           
        //   262: dup_x2         
        //   263: iload           6
        //   265: if_icmpgt       163
        //   268: pop            
        //   269: new             Ljava/lang/String;
        //   272: dup_x1         
        //   273: swap           
        //   274: invokespecial   java/lang/String.<init>:([C)V
        //   277: invokestatic    q/o/m/s/q.z:(Ljava/lang/String;)Ljava/lang/String;
        //   280: swap           
        //   281: pop            
        //   282: swap           
        //   283: tableswitch {
        //                0: 100
        //          default: 40
        //        }
        //   300: new             Lorg/apache/commons/io/FileSystemUtils;
        //   303: dup            
        //   304: invokespecial   org/apache/commons/io/FileSystemUtils.<init>:()V
        //   307: putstatic       org/apache/commons/io/FileSystemUtils.INSTANCE:Lorg/apache/commons/io/FileSystemUtils;
        //   310: iconst_0       
        //   311: istore          7
        //   313: sipush          -28069
        //   316: sipush          18337
        //   319: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   322: astore          8
        //   324: sipush          -28066
        //   327: sipush          28452
        //   330: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   333: invokestatic    q/o/m/s/q.vr:(Ljava/lang/String;)Ljava/lang/String;
        //   336: astore          9
        //   338: aload           9
        //   340: ifnonnull       364
        //   343: new             Ljava/io/IOException;
        //   346: dup            
        //   347: sipush          -28078
        //   350: sipush          -4091
        //   353: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   356: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   359: athrow         
        //   360: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   363: athrow         
        //   364: aload           9
        //   366: invokestatic    x/dn/g/b/q.k:()Ljava/util/Locale;
        //   369: invokestatic    q/o/m/s/q.ev:(Ljava/lang/String;Ljava/util/Locale;)Ljava/lang/String;
        //   372: astore          9
        //   374: aload           9
        //   376: sipush          -28080
        //   379: sipush          27722
        //   382: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   385: invokestatic    q/o/m/s/q.vk:(Ljava/lang/String;Ljava/lang/CharSequence;)Z
        //   388: ifeq            397
        //   391: iconst_1       
        //   392: istore          7
        //   394: goto            695
        //   397: aload           9
        //   399: sipush          -28072
        //   402: sipush          -32473
        //   405: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   408: invokestatic    q/o/m/s/q.vk:(Ljava/lang/String;Ljava/lang/CharSequence;)Z
        //   411: ifne            557
        //   414: aload           9
        //   416: sipush          -28067
        //   419: sipush          28793
        //   422: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   425: invokestatic    q/o/m/s/q.vk:(Ljava/lang/String;Ljava/lang/CharSequence;)Z
        //   428: ifne            557
        //   431: goto            438
        //   434: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   437: athrow         
        //   438: aload           9
        //   440: sipush          -28063
        //   443: sipush          10826
        //   446: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   449: invokestatic    q/o/m/s/q.vk:(Ljava/lang/String;Ljava/lang/CharSequence;)Z
        //   452: ifne            557
        //   455: goto            462
        //   458: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   461: athrow         
        //   462: aload           9
        //   464: sipush          -28094
        //   467: bipush          11
        //   469: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   472: invokestatic    q/o/m/s/q.vk:(Ljava/lang/String;Ljava/lang/CharSequence;)Z
        //   475: ifne            557
        //   478: goto            485
        //   481: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   484: athrow         
        //   485: aload           9
        //   487: sipush          -28065
        //   490: sipush          -6204
        //   493: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   496: invokestatic    q/o/m/s/q.vk:(Ljava/lang/String;Ljava/lang/CharSequence;)Z
        //   499: ifne            557
        //   502: goto            509
        //   505: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   508: athrow         
        //   509: aload           9
        //   511: sipush          -28095
        //   514: sipush          -27404
        //   517: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   520: invokestatic    q/o/m/s/q.vk:(Ljava/lang/String;Ljava/lang/CharSequence;)Z
        //   523: ifne            557
        //   526: goto            533
        //   529: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   532: athrow         
        //   533: aload           9
        //   535: sipush          -28082
        //   538: sipush          22236
        //   541: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   544: invokestatic    q/o/m/s/q.vk:(Ljava/lang/String;Ljava/lang/CharSequence;)Z
        //   547: ifeq            563
        //   550: goto            557
        //   553: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   556: athrow         
        //   557: iconst_2       
        //   558: istore          7
        //   560: goto            695
        //   563: aload           9
        //   565: sipush          -28084
        //   568: sipush          -21109
        //   571: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   574: invokestatic    q/o/m/s/q.vk:(Ljava/lang/String;Ljava/lang/CharSequence;)Z
        //   577: ifne            628
        //   580: aload           9
        //   582: sipush          -28089
        //   585: sipush          16681
        //   588: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   591: invokestatic    q/o/m/s/q.vk:(Ljava/lang/String;Ljava/lang/CharSequence;)Z
        //   594: ifne            628
        //   597: goto            604
        //   600: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   603: athrow         
        //   604: aload           9
        //   606: sipush          -28074
        //   609: sipush          -13794
        //   612: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   615: invokestatic    q/o/m/s/q.vk:(Ljava/lang/String;Ljava/lang/CharSequence;)Z
        //   618: ifeq            645
        //   621: goto            628
        //   624: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   627: athrow         
        //   628: iconst_3       
        //   629: istore          7
        //   631: sipush          -28096
        //   634: sipush          2236
        //   637: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   640: astore          8
        //   642: goto            695
        //   645: aload           9
        //   647: sipush          -28076
        //   650: sipush          6575
        //   653: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   656: invokestatic    q/o/m/s/q.vk:(Ljava/lang/String;Ljava/lang/CharSequence;)Z
        //   659: ifne            686
        //   662: aload           9
        //   664: sipush          -28083
        //   667: sipush          26530
        //   670: invokestatic    org/apache/commons/io/FileSystemUtils.a:(II)Ljava/lang/String;
        //   673: invokestatic    q/o/m/s/q.vk:(Ljava/lang/String;Ljava/lang/CharSequence;)Z
        //   676: ifeq            692
        //   679: goto            686
        //   682: invokestatic    org/apache/commons/io/FileSystemUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   685: athrow         
        //   686: iconst_3       
        //   687: istore          7
        //   689: goto            695
        //   692: iconst_0       
        //   693: istore          7
        //   695: goto            703
        //   698: astore          9
        //   700: iconst_m1      
        //   701: istore          7
        //   703: iload           7
        //   705: putstatic       org/apache/commons/io/FileSystemUtils.OS:I
        //   708: aload           8
        //   710: putstatic       org/apache/commons/io/FileSystemUtils.DF:Ljava/lang/String;
        //   713: return         
        //    StackMapTable: 00 2E FF 00 17 00 06 01 01 07 00 52 01 01 07 00 87 00 00 FF 00 10 00 07 01 01 07 00 52 01 01 07 00 87 01 00 01 07 00 52 1B 0E 50 07 00 52 1B FF 00 0F 00 06 01 01 07 00 52 01 01 07 00 87 00 03 01 07 00 52 01 FF 00 12 00 07 01 01 07 00 52 01 01 07 00 87 01 00 04 01 01 07 01 6C 01 FF 00 03 00 07 01 01 07 00 52 01 01 07 00 87 01 00 07 01 01 07 01 6C 01 01 07 01 6C 01 FF 00 2C 00 07 01 01 07 00 52 01 01 07 00 87 01 00 08 01 01 07 01 6C 01 07 01 6C 01 01 01 FF 00 04 00 07 01 01 07 00 52 01 01 07 00 87 01 00 08 01 01 07 01 6C 01 07 01 6C 01 01 01 FF 00 04 00 07 01 01 07 00 52 01 01 07 00 87 01 00 08 01 01 07 01 6C 01 07 01 6C 01 01 01 FF 00 04 00 07 01 01 07 00 52 01 01 07 00 87 01 00 08 01 01 07 01 6C 01 07 01 6C 01 01 01 FF 00 04 00 07 01 01 07 00 52 01 01 07 00 87 01 00 08 01 01 07 01 6C 01 07 01 6C 01 01 01 FF 00 04 00 07 01 01 07 00 52 01 01 07 00 87 01 00 08 01 01 07 01 6C 01 07 01 6C 01 01 01 FF 00 04 00 07 01 01 07 00 52 01 01 07 00 87 01 00 08 01 01 07 01 6C 01 07 01 6C 01 01 01 FF 00 01 00 07 01 01 07 00 52 01 01 07 00 87 01 00 09 01 01 07 01 6C 01 07 01 6C 01 01 01 01 FF 00 0F 00 07 01 01 07 00 52 01 01 07 00 87 01 00 04 01 01 07 01 6C 01 27 FF 00 3B 00 0A 01 01 07 00 52 01 01 07 00 87 01 01 07 00 52 07 00 52 00 01 07 01 5D 03 20 64 07 01 5D 03 53 07 01 5D 03 52 07 01 5D 03 53 07 01 5D 03 53 07 01 5D 03 53 07 01 5D 03 05 64 07 01 5D 03 53 07 01 5D 03 10 64 07 01 5D 03 05 02 FF 00 02 00 09 01 01 07 00 52 01 01 07 00 87 01 01 07 00 52 00 01 07 01 5D 04
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  645    679    682    686    Ljava/lang/Exception;
        //  580    621    624    628    Ljava/lang/Exception;
        //  563    597    600    604    Ljava/lang/Exception;
        //  509    550    553    557    Ljava/lang/Exception;
        //  485    526    529    533    Ljava/lang/Exception;
        //  462    502    505    509    Ljava/lang/Exception;
        //  438    478    481    485    Ljava/lang/Exception;
        //  414    455    458    462    Ljava/lang/Exception;
        //  397    431    434    438    Ljava/lang/Exception;
        //  338    360    360    364    Ljava/lang/Exception;
        //  324    695    698    703    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0438:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0xFFFF9247) & 0xFFFF;
        if (FileSystemUtils.b[n3] == null) {
            final char[] g = q.o.m.s.q.g(FileSystemUtils.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 111;
                    break;
                }
                case 1: {
                    n4 = 54;
                    break;
                }
                case 2: {
                    n4 = 76;
                    break;
                }
                case 3: {
                    n4 = 243;
                    break;
                }
                case 4: {
                    n4 = 232;
                    break;
                }
                case 5: {
                    n4 = 45;
                    break;
                }
                case 6: {
                    n4 = 253;
                    break;
                }
                case 7: {
                    n4 = 103;
                    break;
                }
                case 8: {
                    n4 = 2;
                    break;
                }
                case 9: {
                    n4 = 212;
                    break;
                }
                case 10: {
                    n4 = 207;
                    break;
                }
                case 11: {
                    n4 = 107;
                    break;
                }
                case 12: {
                    n4 = 43;
                    break;
                }
                case 13: {
                    n4 = 183;
                    break;
                }
                case 14: {
                    n4 = 98;
                    break;
                }
                case 15: {
                    n4 = 165;
                    break;
                }
                case 16: {
                    n4 = 32;
                    break;
                }
                case 17: {
                    n4 = 88;
                    break;
                }
                case 18: {
                    n4 = 51;
                    break;
                }
                case 19: {
                    n4 = 250;
                    break;
                }
                case 20: {
                    n4 = 211;
                    break;
                }
                case 21: {
                    n4 = 84;
                    break;
                }
                case 22: {
                    n4 = 191;
                    break;
                }
                case 23: {
                    n4 = 150;
                    break;
                }
                case 24: {
                    n4 = 25;
                    break;
                }
                case 25: {
                    n4 = 72;
                    break;
                }
                case 26: {
                    n4 = 120;
                    break;
                }
                case 27: {
                    n4 = 132;
                    break;
                }
                case 28: {
                    n4 = 147;
                    break;
                }
                case 29: {
                    n4 = 127;
                    break;
                }
                case 30: {
                    n4 = 52;
                    break;
                }
                case 31: {
                    n4 = 5;
                    break;
                }
                case 32: {
                    n4 = 79;
                    break;
                }
                case 33: {
                    n4 = 92;
                    break;
                }
                case 34: {
                    n4 = 114;
                    break;
                }
                case 35: {
                    n4 = 194;
                    break;
                }
                case 36: {
                    n4 = 197;
                    break;
                }
                case 37: {
                    n4 = 39;
                    break;
                }
                case 38: {
                    n4 = 164;
                    break;
                }
                case 39: {
                    n4 = 229;
                    break;
                }
                case 40: {
                    n4 = 173;
                    break;
                }
                case 41: {
                    n4 = 222;
                    break;
                }
                case 42: {
                    n4 = 247;
                    break;
                }
                case 43: {
                    n4 = 31;
                    break;
                }
                case 44: {
                    n4 = 87;
                    break;
                }
                case 45: {
                    n4 = 121;
                    break;
                }
                case 46: {
                    n4 = 102;
                    break;
                }
                case 47: {
                    n4 = 8;
                    break;
                }
                case 48: {
                    n4 = 71;
                    break;
                }
                case 49: {
                    n4 = 138;
                    break;
                }
                case 50: {
                    n4 = 136;
                    break;
                }
                case 51: {
                    n4 = 118;
                    break;
                }
                case 52: {
                    n4 = 20;
                    break;
                }
                case 53: {
                    n4 = 119;
                    break;
                }
                case 54: {
                    n4 = 221;
                    break;
                }
                case 55: {
                    n4 = 179;
                    break;
                }
                case 56: {
                    n4 = 143;
                    break;
                }
                case 57: {
                    n4 = 37;
                    break;
                }
                case 58: {
                    n4 = 126;
                    break;
                }
                case 59: {
                    n4 = 245;
                    break;
                }
                case 60: {
                    n4 = 13;
                    break;
                }
                case 61: {
                    n4 = 90;
                    break;
                }
                case 62: {
                    n4 = 27;
                    break;
                }
                case 63: {
                    n4 = 159;
                    break;
                }
                case 64: {
                    n4 = 42;
                    break;
                }
                case 65: {
                    n4 = 44;
                    break;
                }
                case 66: {
                    n4 = 209;
                    break;
                }
                case 67: {
                    n4 = 100;
                    break;
                }
                case 68: {
                    n4 = 154;
                    break;
                }
                case 69: {
                    n4 = 66;
                    break;
                }
                case 70: {
                    n4 = 134;
                    break;
                }
                case 71: {
                    n4 = 14;
                    break;
                }
                case 72: {
                    n4 = 115;
                    break;
                }
                case 73: {
                    n4 = 81;
                    break;
                }
                case 74: {
                    n4 = 3;
                    break;
                }
                case 75: {
                    n4 = 182;
                    break;
                }
                case 76: {
                    n4 = 116;
                    break;
                }
                case 77: {
                    n4 = 163;
                    break;
                }
                case 78: {
                    n4 = 91;
                    break;
                }
                case 79: {
                    n4 = 131;
                    break;
                }
                case 80: {
                    n4 = 113;
                    break;
                }
                case 81: {
                    n4 = 29;
                    break;
                }
                case 82: {
                    n4 = 176;
                    break;
                }
                case 83: {
                    n4 = 85;
                    break;
                }
                case 84: {
                    n4 = 231;
                    break;
                }
                case 85: {
                    n4 = 255;
                    break;
                }
                case 86: {
                    n4 = 93;
                    break;
                }
                case 87: {
                    n4 = 174;
                    break;
                }
                case 88: {
                    n4 = 47;
                    break;
                }
                case 89: {
                    n4 = 148;
                    break;
                }
                case 90: {
                    n4 = 89;
                    break;
                }
                case 91: {
                    n4 = 234;
                    break;
                }
                case 92: {
                    n4 = 140;
                    break;
                }
                case 93: {
                    n4 = 64;
                    break;
                }
                case 94: {
                    n4 = 240;
                    break;
                }
                case 95: {
                    n4 = 195;
                    break;
                }
                case 96: {
                    n4 = 177;
                    break;
                }
                case 97: {
                    n4 = 26;
                    break;
                }
                case 98: {
                    n4 = 11;
                    break;
                }
                case 99: {
                    n4 = 128;
                    break;
                }
                case 100: {
                    n4 = 155;
                    break;
                }
                case 101: {
                    n4 = 166;
                    break;
                }
                case 102: {
                    n4 = 18;
                    break;
                }
                case 103: {
                    n4 = 189;
                    break;
                }
                case 104: {
                    n4 = 101;
                    break;
                }
                case 105: {
                    n4 = 230;
                    break;
                }
                case 106: {
                    n4 = 196;
                    break;
                }
                case 107: {
                    n4 = 17;
                    break;
                }
                case 108: {
                    n4 = 117;
                    break;
                }
                case 109: {
                    n4 = 112;
                    break;
                }
                case 110: {
                    n4 = 15;
                    break;
                }
                case 111: {
                    n4 = 73;
                    break;
                }
                case 112: {
                    n4 = 74;
                    break;
                }
                case 113: {
                    n4 = 69;
                    break;
                }
                case 114: {
                    n4 = 246;
                    break;
                }
                case 115: {
                    n4 = 48;
                    break;
                }
                case 116: {
                    n4 = 206;
                    break;
                }
                case 117: {
                    n4 = 97;
                    break;
                }
                case 118: {
                    n4 = 41;
                    break;
                }
                case 119: {
                    n4 = 162;
                    break;
                }
                case 120: {
                    n4 = 22;
                    break;
                }
                case 121: {
                    n4 = 63;
                    break;
                }
                case 122: {
                    n4 = 59;
                    break;
                }
                case 123: {
                    n4 = 228;
                    break;
                }
                case 124: {
                    n4 = 146;
                    break;
                }
                case 125: {
                    n4 = 141;
                    break;
                }
                case 126: {
                    n4 = 199;
                    break;
                }
                case 127: {
                    n4 = 56;
                    break;
                }
                case 128: {
                    n4 = 235;
                    break;
                }
                case 129: {
                    n4 = 9;
                    break;
                }
                case 130: {
                    n4 = 223;
                    break;
                }
                case 131: {
                    n4 = 151;
                    break;
                }
                case 132: {
                    n4 = 169;
                    break;
                }
                case 133: {
                    n4 = 129;
                    break;
                }
                case 134: {
                    n4 = 144;
                    break;
                }
                case 135: {
                    n4 = 160;
                    break;
                }
                case 136: {
                    n4 = 86;
                    break;
                }
                case 137: {
                    n4 = 30;
                    break;
                }
                case 138: {
                    n4 = 77;
                    break;
                }
                case 139: {
                    n4 = 242;
                    break;
                }
                case 140: {
                    n4 = 70;
                    break;
                }
                case 141: {
                    n4 = 68;
                    break;
                }
                case 142: {
                    n4 = 219;
                    break;
                }
                case 143: {
                    n4 = 58;
                    break;
                }
                case 144: {
                    n4 = 244;
                    break;
                }
                case 145: {
                    n4 = 178;
                    break;
                }
                case 146: {
                    n4 = 171;
                    break;
                }
                case 147: {
                    n4 = 65;
                    break;
                }
                case 148: {
                    n4 = 23;
                    break;
                }
                case 149: {
                    n4 = 142;
                    break;
                }
                case 150: {
                    n4 = 33;
                    break;
                }
                case 151: {
                    n4 = 61;
                    break;
                }
                case 152: {
                    n4 = 145;
                    break;
                }
                case 153: {
                    n4 = 224;
                    break;
                }
                case 154: {
                    n4 = 225;
                    break;
                }
                case 155: {
                    n4 = 122;
                    break;
                }
                case 156: {
                    n4 = 137;
                    break;
                }
                case 157: {
                    n4 = 10;
                    break;
                }
                case 158: {
                    n4 = 236;
                    break;
                }
                case 159: {
                    n4 = 184;
                    break;
                }
                case 160: {
                    n4 = 204;
                    break;
                }
                case 161: {
                    n4 = 99;
                    break;
                }
                case 162: {
                    n4 = 233;
                    break;
                }
                case 163: {
                    n4 = 172;
                    break;
                }
                case 164: {
                    n4 = 40;
                    break;
                }
                case 165: {
                    n4 = 105;
                    break;
                }
                case 166: {
                    n4 = 251;
                    break;
                }
                case 167: {
                    n4 = 149;
                    break;
                }
                case 168: {
                    n4 = 108;
                    break;
                }
                case 169: {
                    n4 = 203;
                    break;
                }
                case 170: {
                    n4 = 7;
                    break;
                }
                case 171: {
                    n4 = 237;
                    break;
                }
                case 172: {
                    n4 = 175;
                    break;
                }
                case 173: {
                    n4 = 62;
                    break;
                }
                case 174: {
                    n4 = 133;
                    break;
                }
                case 175: {
                    n4 = 249;
                    break;
                }
                case 176: {
                    n4 = 168;
                    break;
                }
                case 177: {
                    n4 = 214;
                    break;
                }
                case 178: {
                    n4 = 187;
                    break;
                }
                case 179: {
                    n4 = 158;
                    break;
                }
                case 180: {
                    n4 = 28;
                    break;
                }
                case 181: {
                    n4 = 78;
                    break;
                }
                case 182: {
                    n4 = 24;
                    break;
                }
                case 183: {
                    n4 = 241;
                    break;
                }
                case 184: {
                    n4 = 161;
                    break;
                }
                case 185: {
                    n4 = 16;
                    break;
                }
                case 186: {
                    n4 = 215;
                    break;
                }
                case 187: {
                    n4 = 94;
                    break;
                }
                case 188: {
                    n4 = 190;
                    break;
                }
                case 189: {
                    n4 = 55;
                    break;
                }
                case 190: {
                    n4 = 188;
                    break;
                }
                case 191: {
                    n4 = 139;
                    break;
                }
                case 192: {
                    n4 = 167;
                    break;
                }
                case 193: {
                    n4 = 201;
                    break;
                }
                case 194: {
                    n4 = 135;
                    break;
                }
                case 195: {
                    n4 = 82;
                    break;
                }
                case 196: {
                    n4 = 104;
                    break;
                }
                case 197: {
                    n4 = 153;
                    break;
                }
                case 198: {
                    n4 = 198;
                    break;
                }
                case 199: {
                    n4 = 50;
                    break;
                }
                case 200: {
                    n4 = 193;
                    break;
                }
                case 201: {
                    n4 = 38;
                    break;
                }
                case 202: {
                    n4 = 0;
                    break;
                }
                case 203: {
                    n4 = 80;
                    break;
                }
                case 204: {
                    n4 = 125;
                    break;
                }
                case 205: {
                    n4 = 60;
                    break;
                }
                case 206: {
                    n4 = 46;
                    break;
                }
                case 207: {
                    n4 = 252;
                    break;
                }
                case 208: {
                    n4 = 67;
                    break;
                }
                case 209: {
                    n4 = 12;
                    break;
                }
                case 210: {
                    n4 = 200;
                    break;
                }
                case 211: {
                    n4 = 35;
                    break;
                }
                case 212: {
                    n4 = 216;
                    break;
                }
                case 213: {
                    n4 = 170;
                    break;
                }
                case 214: {
                    n4 = 213;
                    break;
                }
                case 215: {
                    n4 = 220;
                    break;
                }
                case 216: {
                    n4 = 109;
                    break;
                }
                case 217: {
                    n4 = 6;
                    break;
                }
                case 218: {
                    n4 = 49;
                    break;
                }
                case 219: {
                    n4 = 156;
                    break;
                }
                case 220: {
                    n4 = 110;
                    break;
                }
                case 221: {
                    n4 = 34;
                    break;
                }
                case 222: {
                    n4 = 106;
                    break;
                }
                case 223: {
                    n4 = 205;
                    break;
                }
                case 224: {
                    n4 = 75;
                    break;
                }
                case 225: {
                    n4 = 4;
                    break;
                }
                case 226: {
                    n4 = 202;
                    break;
                }
                case 227: {
                    n4 = 53;
                    break;
                }
                case 228: {
                    n4 = 254;
                    break;
                }
                case 229: {
                    n4 = 218;
                    break;
                }
                case 230: {
                    n4 = 130;
                    break;
                }
                case 231: {
                    n4 = 192;
                    break;
                }
                case 232: {
                    n4 = 248;
                    break;
                }
                case 233: {
                    n4 = 217;
                    break;
                }
                case 234: {
                    n4 = 36;
                    break;
                }
                case 235: {
                    n4 = 208;
                    break;
                }
                case 236: {
                    n4 = 83;
                    break;
                }
                case 237: {
                    n4 = 227;
                    break;
                }
                case 238: {
                    n4 = 180;
                    break;
                }
                case 239: {
                    n4 = 95;
                    break;
                }
                case 240: {
                    n4 = 210;
                    break;
                }
                case 241: {
                    n4 = 238;
                    break;
                }
                case 242: {
                    n4 = 157;
                    break;
                }
                case 243: {
                    n4 = 152;
                    break;
                }
                case 244: {
                    n4 = 19;
                    break;
                }
                case 245: {
                    n4 = 21;
                    break;
                }
                case 246: {
                    n4 = 226;
                    break;
                }
                case 247: {
                    n4 = 239;
                    break;
                }
                case 248: {
                    n4 = 57;
                    break;
                }
                case 249: {
                    n4 = 124;
                    break;
                }
                case 250: {
                    n4 = 96;
                    break;
                }
                case 251: {
                    n4 = 1;
                    break;
                }
                case 252: {
                    n4 = 185;
                    break;
                }
                case 253: {
                    n4 = 186;
                    break;
                }
                case 254: {
                    n4 = 181;
                    break;
                }
                default: {
                    n4 = 123;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            FileSystemUtils.b[n3] = q.o.m.s.q.z(new String(g));
        }
        return FileSystemUtils.b[n3];
    }
}
