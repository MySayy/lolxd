// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import n.d.a.d.q;
import java.io.IOException;
import java.util.Collection;
import java.io.File;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.commons.io.filefilter.IOFileFilter;
import java.io.FileFilter;

public abstract class DirectoryWalker<T>
{
    private final FileFilter filter;
    private final int depthLimit;
    private static final String a;
    
    protected DirectoryWalker() {
        this(null, -1);
    }
    
    protected DirectoryWalker(final FileFilter filter, final int depthLimit) {
        this.filter = filter;
        this.depthLimit = depthLimit;
    }
    
    protected DirectoryWalker(IOFileFilter directoryOnly, IOFileFilter fileOnly, final int depthLimit) {
        final int c = IOCase.c();
        Label_0157: {
            final IOFileFilter ioFileFilter2;
            Label_0085: {
                Label_0088: {
                    Label_0069: {
                        IOFileFilter ioFileFilter = null;
                        Label_0051: {
                            try {
                                final IOFileFilter true;
                                ioFileFilter = (true = directoryOnly);
                                if (c == 0) {
                                    break Label_0069;
                                }
                                if (ioFileFilter != null) {
                                    break Label_0051;
                                }
                            }
                            catch (NullPointerException ex) {
                                throw b(ex);
                            }
                            ioFileFilter2 = fileOnly;
                            while (true) {
                                if (c == 0) {
                                    break Label_0069;
                                }
                                try {
                                    if (ioFileFilter2 != null) {
                                        break Label_0051;
                                    }
                                    final DirectoryWalker directoryWalker = this;
                                    final FileFilter fileFilter = null;
                                    directoryWalker.filter = fileFilter;
                                    final int n = c;
                                    if (n == 0) {
                                        break Label_0051;
                                    }
                                    break Label_0157;
                                }
                                catch (NullPointerException ex2) {
                                    throw b(ex2);
                                }
                                try {
                                    final DirectoryWalker directoryWalker = this;
                                    final FileFilter fileFilter = null;
                                    directoryWalker.filter = fileFilter;
                                    final int n = c;
                                    if (n != 0) {
                                        break Label_0157;
                                    }
                                    final IOFileFilter ioFileFilter3;
                                    final IOFileFilter true = ioFileFilter3 = directoryOnly;
                                    if (c == 0) {
                                        continue;
                                    }
                                }
                                catch (NullPointerException ex3) {
                                    throw b(ex3);
                                }
                                break;
                            }
                        }
                        if (c == 0) {
                            break Label_0085;
                        }
                        try {
                            if (c == 0) {
                                break Label_0085;
                            }
                            if (ioFileFilter == null) {
                                break Label_0088;
                            }
                        }
                        catch (NullPointerException ex4) {
                            throw b(ex4);
                        }
                    }
                    IOFileFilter true = directoryOnly;
                    break Label_0085;
                }
                IOFileFilter true = TrueFileFilter.TRUE;
            }
            directoryOnly = ioFileFilter2;
            IOFileFilter ioFileFilter4 = null;
            Label_0127: {
                Label_0124: {
                    Label_0110: {
                        try {
                            ioFileFilter4 = fileOnly;
                            if (c == 0) {
                                break Label_0110;
                            }
                            final int n2 = c;
                            if (n2 != 0) {
                                break Label_0110;
                            }
                            break Label_0110;
                        }
                        catch (NullPointerException ex5) {
                            throw b(ex5);
                        }
                        try {
                            final int n2 = c;
                            if (n2 == 0) {
                                break Label_0110;
                            }
                            if (ioFileFilter4 == null) {
                                break Label_0124;
                            }
                        }
                        catch (NullPointerException ex6) {
                            throw b(ex6);
                        }
                    }
                    break Label_0127;
                }
                final IOFileFilter true2 = TrueFileFilter.TRUE;
            }
            fileOnly = ioFileFilter4;
            directoryOnly = FileFilterUtils.makeDirectoryOnly(directoryOnly);
            fileOnly = FileFilterUtils.makeFileOnly(fileOnly);
            this.filter = FileFilterUtils.or(directoryOnly, fileOnly);
        }
        this.depthLimit = depthLimit;
    }
    
    protected final void walk(final File file, final Collection<T> collection) throws IOException {
        final int b = IOCase.b();
        Label_0034: {
            Label_0019: {
                try {
                    if (b != 0) {
                        break Label_0034;
                    }
                    final File file2 = file;
                    if (file2 == null) {
                        break Label_0019;
                    }
                    break Label_0034;
                }
                catch (DirectoryWalker$CancelException ex) {
                    throw b(ex);
                }
                try {
                    final File file2 = file;
                    if (file2 == null) {
                        throw new NullPointerException(DirectoryWalker.a);
                    }
                }
                catch (DirectoryWalker$CancelException ex2) {
                    throw b(ex2);
                }
            }
            try {
                this.handleStart(file, collection);
                this.walk(file, 0, collection);
                this.handleEnd(collection);
            }
            catch (DirectoryWalker$CancelException ex3) {
                this.handleCancelled(file, collection, ex3);
            }
        }
    }
    
    private void walk(final File p0, final int p1, final Collection<T> p2) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: aload_1        
        //     2: iload_2        
        //     3: aload_3        
        //     4: invokevirtual   org/apache/commons/io/DirectoryWalker.checkIfCancelled:(Ljava/io/File;ILjava/util/Collection;)V
        //     7: invokestatic    org/apache/commons/io/IOCase.b:()I
        //    10: istore          4
        //    12: aload_0        
        //    13: aload_1        
        //    14: iload_2        
        //    15: aload_3        
        //    16: iload           4
        //    18: ifne            323
        //    21: invokevirtual   org/apache/commons/io/DirectoryWalker.handleDirectory:(Ljava/io/File;ILjava/util/Collection;)Z
        //    24: ifeq            319
        //    27: goto            34
        //    30: invokestatic    org/apache/commons/io/DirectoryWalker.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    33: athrow         
        //    34: aload_0        
        //    35: aload_1        
        //    36: iload_2        
        //    37: aload_3        
        //    38: invokevirtual   org/apache/commons/io/DirectoryWalker.handleDirectoryStart:(Ljava/io/File;ILjava/util/Collection;)V
        //    41: goto            48
        //    44: invokestatic    org/apache/commons/io/DirectoryWalker.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    47: athrow         
        //    48: iload_2        
        //    49: iconst_1       
        //    50: iadd           
        //    51: istore          5
        //    53: aload_0        
        //    54: iload           4
        //    56: ifne            101
        //    59: getfield        org/apache/commons/io/DirectoryWalker.depthLimit:I
        //    62: iload           4
        //    64: ifne            79
        //    67: iflt            86
        //    70: goto            77
        //    73: invokestatic    org/apache/commons/io/DirectoryWalker.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    76: athrow         
        //    77: iload           5
        //    79: aload_0        
        //    80: getfield        org/apache/commons/io/DirectoryWalker.depthLimit:I
        //    83: if_icmpgt       307
        //    86: aload_0        
        //    87: aload_1        
        //    88: iload_2        
        //    89: aload_3        
        //    90: goto            97
        //    93: invokestatic    org/apache/commons/io/DirectoryWalker.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    96: athrow         
        //    97: invokevirtual   org/apache/commons/io/DirectoryWalker.checkIfCancelled:(Ljava/io/File;ILjava/util/Collection;)V
        //   100: aload_0        
        //   101: getfield        org/apache/commons/io/DirectoryWalker.filter:Ljava/io/FileFilter;
        //   104: ifnonnull       121
        //   107: aload_1        
        //   108: goto            115
        //   111: invokestatic    org/apache/commons/io/DirectoryWalker.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   114: athrow         
        //   115: invokestatic    q/o/m/s/q.sl:(Ljava/io/File;)[Ljava/io/File;
        //   118: goto            134
        //   121: aload_1        
        //   122: iload           4
        //   124: ifne            115
        //   127: aload_0        
        //   128: getfield        org/apache/commons/io/DirectoryWalker.filter:Ljava/io/FileFilter;
        //   131: invokestatic    q/o/m/s/q.si:(Ljava/io/File;Ljava/io/FileFilter;)[Ljava/io/File;
        //   134: astore          6
        //   136: aload_0        
        //   137: aload_1        
        //   138: iload_2        
        //   139: aload           6
        //   141: invokevirtual   org/apache/commons/io/DirectoryWalker.filterDirectoryContents:(Ljava/io/File;I[Ljava/io/File;)[Ljava/io/File;
        //   144: astore          6
        //   146: aload           6
        //   148: iload           4
        //   150: ifne            185
        //   153: ifnonnull       183
        //   156: goto            163
        //   159: invokestatic    org/apache/commons/io/DirectoryWalker.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   162: athrow         
        //   163: aload_0        
        //   164: aload_1        
        //   165: iload           5
        //   167: aload_3        
        //   168: invokevirtual   org/apache/commons/io/DirectoryWalker.handleRestricted:(Ljava/io/File;ILjava/util/Collection;)V
        //   171: goto            178
        //   174: invokestatic    org/apache/commons/io/DirectoryWalker.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   177: athrow         
        //   178: iload           4
        //   180: ifeq            307
        //   183: aload           6
        //   185: astore          7
        //   187: aload           7
        //   189: arraylength    
        //   190: istore          8
        //   192: iload           4
        //   194: ifne            178
        //   197: iconst_0       
        //   198: istore          9
        //   200: iload           9
        //   202: iload           8
        //   204: if_icmpge       307
        //   207: aload           7
        //   209: iload           9
        //   211: aaload         
        //   212: astore          10
        //   214: iload           4
        //   216: ifne            326
        //   219: iload           4
        //   221: ifne            285
        //   224: goto            231
        //   227: invokestatic    org/apache/commons/io/DirectoryWalker.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   230: athrow         
        //   231: aload           10
        //   233: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //   236: ifeq            267
        //   239: goto            246
        //   242: invokestatic    org/apache/commons/io/DirectoryWalker.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   245: athrow         
        //   246: aload_0        
        //   247: aload           10
        //   249: iload           5
        //   251: aload_3        
        //   252: goto            259
        //   255: invokestatic    org/apache/commons/io/DirectoryWalker.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   258: athrow         
        //   259: invokespecial   org/apache/commons/io/DirectoryWalker.walk:(Ljava/io/File;ILjava/util/Collection;)V
        //   262: iload           4
        //   264: ifeq            299
        //   267: aload_0        
        //   268: aload           10
        //   270: iload           5
        //   272: aload_3        
        //   273: invokevirtual   org/apache/commons/io/DirectoryWalker.checkIfCancelled:(Ljava/io/File;ILjava/util/Collection;)V
        //   276: aload_0        
        //   277: aload           10
        //   279: iload           5
        //   281: aload_3        
        //   282: invokevirtual   org/apache/commons/io/DirectoryWalker.handleFile:(Ljava/io/File;ILjava/util/Collection;)V
        //   285: aload_0        
        //   286: aload           10
        //   288: iload           5
        //   290: aload_3        
        //   291: iload           4
        //   293: ifne            259
        //   296: invokevirtual   org/apache/commons/io/DirectoryWalker.checkIfCancelled:(Ljava/io/File;ILjava/util/Collection;)V
        //   299: iinc            9, 1
        //   302: iload           4
        //   304: ifeq            200
        //   307: aload_0        
        //   308: aload_1        
        //   309: iload_2        
        //   310: aload_3        
        //   311: iload           4
        //   313: ifne            97
        //   316: invokevirtual   org/apache/commons/io/DirectoryWalker.handleDirectoryEnd:(Ljava/io/File;ILjava/util/Collection;)V
        //   319: aload_0        
        //   320: aload_1        
        //   321: iload_2        
        //   322: aload_3        
        //   323: invokevirtual   org/apache/commons/io/DirectoryWalker.checkIfCancelled:(Ljava/io/File;ILjava/util/Collection;)V
        //   326: iload           4
        //   328: ifne            48
        //   331: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    Signature:
        //  (Ljava/io/File;ILjava/util/Collection<TT;>;)V
        //    StackMapTable: 00 23 FF 00 1E 00 05 07 00 02 07 00 44 01 07 00 46 01 00 01 07 00 3E 03 49 07 00 3E 03 FF 00 18 00 06 07 00 02 07 00 44 01 07 00 46 01 01 00 01 07 00 3E 03 41 01 06 46 07 00 3E FF 00 03 00 06 07 00 02 07 00 44 01 07 00 46 01 01 00 04 07 00 02 07 00 44 01 07 00 46 43 07 00 02 49 07 00 3E 43 07 00 44 05 4C 07 00 70 FF 00 18 00 07 07 00 02 07 00 44 01 07 00 46 01 01 07 00 70 00 01 07 00 3E 03 4A 07 00 3E 03 04 41 07 00 70 FE 00 0E 07 00 70 01 01 FF 00 1A 00 0B 07 00 02 07 00 44 01 07 00 46 01 01 07 00 70 07 00 70 01 01 07 00 44 00 01 07 00 3E 03 4A 07 00 3E 03 48 07 00 3E FF 00 03 00 0B 07 00 02 07 00 44 01 07 00 46 01 01 07 00 70 07 00 70 01 01 07 00 44 00 04 07 00 02 07 00 44 01 07 00 46 07 11 0D FF 00 07 00 06 07 00 02 07 00 44 01 07 00 46 01 01 00 00 FA 00 0B FF 00 03 00 05 07 00 02 07 00 44 01 07 00 46 01 00 04 07 00 02 07 00 44 01 07 00 46 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  12     27     30     34     Ljava/io/IOException;
        //  21     41     44     48     Ljava/io/IOException;
        //  59     70     73     77     Ljava/io/IOException;
        //  79     90     93     97     Ljava/io/IOException;
        //  101    108    111    115    Ljava/io/IOException;
        //  146    156    159    163    Ljava/io/IOException;
        //  153    171    174    178    Ljava/io/IOException;
        //  214    224    227    231    Ljava/io/IOException;
        //  219    239    242    246    Ljava/io/IOException;
        //  231    252    255    259    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0231:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    protected final void checkIfCancelled(final File file, final int n, final Collection<T> collection) throws IOException {
        try {
            if (this.handleIsCancelled(file, n, collection)) {
                throw new DirectoryWalker$CancelException(file, n);
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    protected boolean handleIsCancelled(final File file, final int n, final Collection<T> collection) throws IOException {
        return false;
    }
    
    protected void handleCancelled(final File file, final Collection<T> collection, final DirectoryWalker$CancelException ex) throws IOException {
        throw ex;
    }
    
    protected void handleStart(final File file, final Collection<T> collection) throws IOException {
    }
    
    protected boolean handleDirectory(final File file, final int n, final Collection<T> collection) throws IOException {
        return true;
    }
    
    protected void handleDirectoryStart(final File file, final int n, final Collection<T> collection) throws IOException {
    }
    
    protected File[] filterDirectoryContents(final File file, final int n, final File[] array) throws IOException {
        return array;
    }
    
    protected void handleFile(final File file, final int n, final Collection<T> collection) throws IOException {
    }
    
    protected void handleRestricted(final File file, final int n, final Collection<T> collection) throws IOException {
    }
    
    protected void handleDirectoryEnd(final File file, final int n, final Collection<T> collection) throws IOException {
    }
    
    protected void handleEnd(final Collection<T> collection) throws IOException {
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 3);
        final char[] g = q.o.m.s.q.g(q.mu());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0126: {
                if (length > 1) {
                    break Label_0126;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 60;
                            break;
                        }
                        case 1: {
                            n5 = 99;
                            break;
                        }
                        case 2: {
                            n5 = 26;
                            break;
                        }
                        case 3: {
                            n5 = 36;
                            break;
                        }
                        case 4: {
                            n5 = 5;
                            break;
                        }
                        case 5: {
                            n5 = 48;
                            break;
                        }
                        default: {
                            n5 = 3;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.o.m.s.q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
