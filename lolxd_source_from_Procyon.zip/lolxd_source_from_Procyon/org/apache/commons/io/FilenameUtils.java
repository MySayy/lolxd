// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import java.util.Collection;
import java.io.IOException;
import q.o.m.s.q;

public class FilenameUtils
{
    private static final int NOT_FOUND = -1;
    public static final char EXTENSION_SEPARATOR = '.';
    public static final String EXTENSION_SEPARATOR_STR;
    private static final char UNIX_SEPARATOR = '/';
    private static final char WINDOWS_SEPARATOR = '\\';
    private static final char SYSTEM_SEPARATOR;
    private static final char OTHER_SEPARATOR;
    private static final String[] a;
    private static final String[] b;
    
    static boolean isSystemWindows() {
        try {
            if (FilenameUtils.SYSTEM_SEPARATOR == '\\') {
                return true;
            }
        }
        catch (IllegalArgumentException ex) {
            throw b(ex);
        }
        return false;
    }
    
    private static boolean isSeparator(final char c) {
        final int b = IOCase.b();
        char c2 = '\0';
        Label_0049: {
            char c4 = '\0';
            Label_0021: {
                try {
                    c2 = c;
                    if (b != 0) {
                        return c2 != '\0';
                    }
                    final char c3 = '/';
                    if (c != c3) {
                        break Label_0021;
                    }
                    break Label_0049;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    final char c3 = '/';
                    if (c == c3) {
                        break Label_0049;
                    }
                    c2 = c;
                    c4 = c;
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            while (true) {
                if (b != 0) {
                    return c2 != '\0';
                }
                try {
                    if (b != 0) {
                        return c2 != '\0';
                    }
                    final char c5 = '\\';
                    if (c4 == c5) {
                        break Label_0049;
                    }
                    return false;
                }
                catch (IllegalArgumentException ex3) {
                    throw b(ex3);
                }
                try {
                    final char c5 = '\\';
                    if (c4 != c5) {
                        return false;
                    }
                    c2 = (c4 = '\u0001');
                    if (b != 0) {
                        continue;
                    }
                }
                catch (IllegalArgumentException ex4) {
                    throw b(ex4);
                }
                break;
            }
        }
        return c2 != '\0';
        c2 = '\0';
        return c2 != '\0';
    }
    
    public static String normalize(final String s) {
        return doNormalize(s, FilenameUtils.SYSTEM_SEPARATOR, true);
    }
    
    public static String normalize(final String s, final boolean b) {
        final int c = IOCase.c();
        Label_0035: {
            Label_0020: {
                char c2;
                try {
                    c2 = (char)(b ? 1 : 0);
                    if (c == 0) {
                        return doNormalize(s, c2, true);
                    }
                    final int n = c;
                    if (n != 0) {
                        break Label_0020;
                    }
                    return doNormalize(s, c2, true);
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    final int n = c;
                    if (n == 0) {
                        return doNormalize(s, c2, true);
                    }
                    if (!b) {
                        break Label_0035;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            char c2 = '/';
            return doNormalize(s, c2, true);
        }
        char c2 = '\\';
        return doNormalize(s, c2, true);
    }
    
    public static String normalizeNoEndSeparator(final String s) {
        return doNormalize(s, FilenameUtils.SYSTEM_SEPARATOR, false);
    }
    
    public static String normalizeNoEndSeparator(final String s, final boolean b) {
        final int c = IOCase.c();
        Label_0035: {
            Label_0020: {
                char c2;
                try {
                    c2 = (char)(b ? 1 : 0);
                    if (c == 0) {
                        return doNormalize(s, c2, false);
                    }
                    final int n = c;
                    if (n != 0) {
                        break Label_0020;
                    }
                    return doNormalize(s, c2, false);
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    final int n = c;
                    if (n == 0) {
                        return doNormalize(s, c2, false);
                    }
                    if (!b) {
                        break Label_0035;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            char c2 = '/';
            return doNormalize(s, c2, false);
        }
        char c2 = '\\';
        return doNormalize(s, c2, false);
    }
    
    private static String doNormalize(final String p0, final char p1, final boolean p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_3       
        //     4: aload_0        
        //     5: iload_3        
        //     6: ifeq            30
        //     9: ifnonnull       25
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: aconst_null    
        //    20: areturn        
        //    21: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    24: athrow         
        //    25: aload_0        
        //    26: invokestatic    org/apache/commons/io/FilenameUtils.failIfNullBytePresent:(Ljava/lang/String;)V
        //    29: aload_0        
        //    30: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //    33: istore          4
        //    35: iload           4
        //    37: iload_3        
        //    38: ifeq            61
        //    41: ifne            53
        //    44: goto            51
        //    47: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    50: athrow         
        //    51: aload_0        
        //    52: areturn        
        //    53: aload_0        
        //    54: iload_3        
        //    55: ifeq            52
        //    58: invokestatic    org/apache/commons/io/FilenameUtils.getPrefixLength:(Ljava/lang/String;)I
        //    61: istore          5
        //    63: iload           5
        //    65: iload_3        
        //    66: ifeq            89
        //    69: ifge            85
        //    72: goto            79
        //    75: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    78: athrow         
        //    79: aconst_null    
        //    80: areturn        
        //    81: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    84: athrow         
        //    85: iload           4
        //    87: iconst_2       
        //    88: iadd           
        //    89: newarray        C
        //    91: astore          6
        //    93: aload_0        
        //    94: iconst_0       
        //    95: aload_0        
        //    96: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //    99: aload           6
        //   101: iconst_0       
        //   102: invokestatic    q/o/m/s/q.py:(Ljava/lang/String;II[CI)V
        //   105: iload_1        
        //   106: iload_3        
        //   107: ifeq            144
        //   110: iload_3        
        //   111: ifeq            144
        //   114: goto            121
        //   117: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   120: athrow         
        //   121: getstatic       org/apache/commons/io/FilenameUtils.SYSTEM_SEPARATOR:C
        //   124: if_icmpne       147
        //   127: goto            134
        //   130: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   133: athrow         
        //   134: getstatic       org/apache/commons/io/FilenameUtils.OTHER_SEPARATOR:C
        //   137: goto            144
        //   140: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   143: athrow         
        //   144: goto            150
        //   147: getstatic       org/apache/commons/io/FilenameUtils.SYSTEM_SEPARATOR:C
        //   150: istore          7
        //   152: iconst_0       
        //   153: istore          8
        //   155: iload           8
        //   157: aload           6
        //   159: arraylength    
        //   160: if_icmpge       226
        //   163: aload           6
        //   165: iload           8
        //   167: iload_3        
        //   168: ifeq            217
        //   171: iload_3        
        //   172: ifeq            217
        //   175: goto            182
        //   178: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   181: athrow         
        //   182: caload         
        //   183: iload           7
        //   185: iload_3        
        //   186: ifeq            237
        //   189: goto            196
        //   192: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   195: athrow         
        //   196: if_icmpne       219
        //   199: goto            206
        //   202: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   205: athrow         
        //   206: aload           6
        //   208: iload           8
        //   210: goto            217
        //   213: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   216: athrow         
        //   217: iload_1        
        //   218: castore        
        //   219: iinc            8, 1
        //   222: iload_3        
        //   223: ifne            155
        //   226: iconst_1       
        //   227: istore          8
        //   229: aload           6
        //   231: iload           4
        //   233: iconst_1       
        //   234: isub           
        //   235: caload         
        //   236: iload_1        
        //   237: iload_3        
        //   238: ifeq            273
        //   241: if_icmpeq       270
        //   244: goto            251
        //   247: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   250: athrow         
        //   251: aload           6
        //   253: iload           4
        //   255: iinc            4, 1
        //   258: iload_1        
        //   259: castore        
        //   260: iconst_0       
        //   261: goto            268
        //   264: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   267: athrow         
        //   268: istore          8
        //   270: iload           5
        //   272: iconst_1       
        //   273: iadd           
        //   274: iload_3        
        //   275: ifeq            268
        //   278: istore          9
        //   280: iload           9
        //   282: iload           4
        //   284: if_icmpge       400
        //   287: aload           6
        //   289: iload           9
        //   291: caload         
        //   292: iload_1        
        //   293: iload_3        
        //   294: ifeq            403
        //   297: iload_3        
        //   298: ifeq            355
        //   301: goto            308
        //   304: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   307: athrow         
        //   308: iload_3        
        //   309: ifeq            355
        //   312: goto            319
        //   315: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   318: athrow         
        //   319: if_icmpne       389
        //   322: goto            329
        //   325: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   328: athrow         
        //   329: aload           6
        //   331: iload           9
        //   333: iconst_1       
        //   334: isub           
        //   335: iload_3        
        //   336: ifeq            369
        //   339: goto            346
        //   342: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   345: athrow         
        //   346: caload         
        //   347: iload_1        
        //   348: goto            355
        //   351: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   354: athrow         
        //   355: if_icmpne       389
        //   358: aload           6
        //   360: iload           9
        //   362: goto            369
        //   365: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   368: athrow         
        //   369: aload           6
        //   371: iload           9
        //   373: iconst_1       
        //   374: isub           
        //   375: iload           4
        //   377: iload           9
        //   379: isub           
        //   380: invokestatic    q/o/m/s/q.st:(Ljava/lang/Object;ILjava/lang/Object;II)V
        //   383: iinc            4, -1
        //   386: iinc            9, -1
        //   389: iinc            9, 1
        //   392: iload_3        
        //   393: ifeq            386
        //   396: iload_3        
        //   397: ifne            280
        //   400: iload           5
        //   402: iconst_1       
        //   403: iadd           
        //   404: istore          9
        //   406: iload           9
        //   408: iload           4
        //   410: if_icmpge       634
        //   413: aload           6
        //   415: iload           9
        //   417: caload         
        //   418: iload_1        
        //   419: iload_3        
        //   420: ifeq            637
        //   423: iload_3        
        //   424: ifeq            471
        //   427: goto            434
        //   430: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   433: athrow         
        //   434: iload_3        
        //   435: ifeq            475
        //   438: goto            445
        //   441: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   444: athrow         
        //   445: if_icmpne       627
        //   448: goto            455
        //   451: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   454: athrow         
        //   455: aload           6
        //   457: iload           9
        //   459: iconst_1       
        //   460: isub           
        //   461: caload         
        //   462: bipush          46
        //   464: goto            471
        //   467: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   470: athrow         
        //   471: iload_3        
        //   472: ifeq            509
        //   475: iload_3        
        //   476: ifeq            509
        //   479: goto            486
        //   482: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   485: athrow         
        //   486: if_icmpne       627
        //   489: goto            496
        //   492: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   495: athrow         
        //   496: iload           9
        //   498: iload           5
        //   500: iconst_1       
        //   501: iadd           
        //   502: goto            509
        //   505: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   508: athrow         
        //   509: iload_3        
        //   510: ifeq            595
        //   513: if_icmpeq       556
        //   516: goto            523
        //   519: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   522: athrow         
        //   523: aload           6
        //   525: iload           9
        //   527: iconst_2       
        //   528: isub           
        //   529: caload         
        //   530: iload_1        
        //   531: goto            538
        //   534: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   537: athrow         
        //   538: iload_3        
        //   539: ifeq            595
        //   542: iload_3        
        //   543: ifeq            595
        //   546: if_icmpne       627
        //   549: goto            556
        //   552: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   555: athrow         
        //   556: iload           9
        //   558: iload_3        
        //   559: ifeq            599
        //   562: goto            569
        //   565: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   568: athrow         
        //   569: iload_3        
        //   570: ifeq            599
        //   573: goto            580
        //   576: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   579: athrow         
        //   580: iload           4
        //   582: iconst_1       
        //   583: isub           
        //   584: iload_3        
        //   585: ifeq            538
        //   588: goto            595
        //   591: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   594: athrow         
        //   595: if_icmpne       601
        //   598: iconst_1       
        //   599: istore          8
        //   601: aload           6
        //   603: iload           9
        //   605: iconst_1       
        //   606: iadd           
        //   607: aload           6
        //   609: iload           9
        //   611: iconst_1       
        //   612: isub           
        //   613: iload           4
        //   615: iload           9
        //   617: isub           
        //   618: invokestatic    q/o/m/s/q.st:(Ljava/lang/Object;ILjava/lang/Object;II)V
        //   621: iinc            4, -2
        //   624: iinc            9, -1
        //   627: iinc            9, 1
        //   630: iload_3        
        //   631: ifne            406
        //   634: iload           5
        //   636: iconst_2       
        //   637: iadd           
        //   638: istore          9
        //   640: iload           9
        //   642: iload           4
        //   644: if_icmpge       1033
        //   647: aload           6
        //   649: iload           9
        //   651: caload         
        //   652: iload_1        
        //   653: iload_3        
        //   654: ifeq            1072
        //   657: iload_3        
        //   658: ifeq            705
        //   661: goto            668
        //   664: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   667: athrow         
        //   668: iload_3        
        //   669: ifeq            709
        //   672: goto            679
        //   675: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   678: athrow         
        //   679: if_icmpne       1026
        //   682: goto            689
        //   685: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   688: athrow         
        //   689: aload           6
        //   691: iload           9
        //   693: iconst_1       
        //   694: isub           
        //   695: caload         
        //   696: bipush          46
        //   698: goto            705
        //   701: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   704: athrow         
        //   705: iload_3        
        //   706: ifeq            746
        //   709: iload_3        
        //   710: ifeq            750
        //   713: goto            720
        //   716: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   719: athrow         
        //   720: if_icmpne       1026
        //   723: goto            730
        //   726: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   729: athrow         
        //   730: aload           6
        //   732: iload           9
        //   734: iconst_2       
        //   735: isub           
        //   736: caload         
        //   737: bipush          46
        //   739: goto            746
        //   742: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   745: athrow         
        //   746: iload_3        
        //   747: ifeq            784
        //   750: iload_3        
        //   751: ifeq            784
        //   754: goto            761
        //   757: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   760: athrow         
        //   761: if_icmpne       1026
        //   764: goto            771
        //   767: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   770: athrow         
        //   771: iload           9
        //   773: iload           5
        //   775: iconst_2       
        //   776: iadd           
        //   777: goto            784
        //   780: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   783: athrow         
        //   784: iload_3        
        //   785: ifeq            848
        //   788: if_icmpeq       831
        //   791: goto            798
        //   794: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   797: athrow         
        //   798: aload           6
        //   800: iload           9
        //   802: iconst_3       
        //   803: isub           
        //   804: caload         
        //   805: iload_1        
        //   806: goto            813
        //   809: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   812: athrow         
        //   813: iload_3        
        //   814: ifeq            848
        //   817: iload_3        
        //   818: ifeq            848
        //   821: if_icmpne       1026
        //   824: goto            831
        //   827: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   830: athrow         
        //   831: iload           9
        //   833: iload           5
        //   835: iconst_2       
        //   836: iadd           
        //   837: iload_3        
        //   838: ifeq            813
        //   841: goto            848
        //   844: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   847: athrow         
        //   848: iload_3        
        //   849: ifeq            874
        //   852: if_icmpne       868
        //   855: goto            862
        //   858: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   861: athrow         
        //   862: aconst_null    
        //   863: areturn        
        //   864: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   867: athrow         
        //   868: iload           9
        //   870: iload           4
        //   872: iconst_1       
        //   873: isub           
        //   874: iload_3        
        //   875: ifeq            894
        //   878: if_icmpne       891
        //   881: goto            888
        //   884: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   887: athrow         
        //   888: iconst_1       
        //   889: istore          8
        //   891: iload           9
        //   893: iconst_4       
        //   894: isub           
        //   895: iload_3        
        //   896: ifeq            889
        //   899: istore          10
        //   901: iload           10
        //   903: iload           5
        //   905: if_icmplt       990
        //   908: aload           6
        //   910: iload           10
        //   912: caload         
        //   913: iload_1        
        //   914: iload_3        
        //   915: ifeq            1023
        //   918: iload_3        
        //   919: ifeq            972
        //   922: goto            929
        //   925: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   928: athrow         
        //   929: if_icmpne       979
        //   932: goto            939
        //   935: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   938: athrow         
        //   939: aload           6
        //   941: iload           9
        //   943: iconst_1       
        //   944: iadd           
        //   945: aload           6
        //   947: iload           10
        //   949: iconst_1       
        //   950: iadd           
        //   951: iload           4
        //   953: iload           9
        //   955: isub           
        //   956: invokestatic    q/o/m/s/q.st:(Ljava/lang/Object;ILjava/lang/Object;II)V
        //   959: iload           4
        //   961: iload           9
        //   963: iload           10
        //   965: isub           
        //   966: isub           
        //   967: istore          4
        //   969: iload           10
        //   971: iconst_1       
        //   972: iadd           
        //   973: istore          9
        //   975: iload_3        
        //   976: ifne            1026
        //   979: iinc            10, -1
        //   982: iload_3        
        //   983: ifeq            975
        //   986: iload_3        
        //   987: ifne            901
        //   990: aload           6
        //   992: iload           9
        //   994: iconst_1       
        //   995: iadd           
        //   996: aload           6
        //   998: iload           5
        //  1000: iload           4
        //  1002: iload           9
        //  1004: isub           
        //  1005: invokestatic    q/o/m/s/q.st:(Ljava/lang/Object;ILjava/lang/Object;II)V
        //  1008: iload           4
        //  1010: iload           9
        //  1012: iconst_1       
        //  1013: iadd           
        //  1014: iload           5
        //  1016: isub           
        //  1017: isub           
        //  1018: istore          4
        //  1020: iload           5
        //  1022: iconst_1       
        //  1023: iadd           
        //  1024: istore          9
        //  1026: iinc            9, 1
        //  1029: iload_3        
        //  1030: ifne            640
        //  1033: iload           4
        //  1035: iload_3        
        //  1036: ifeq            1059
        //  1039: ifgt            1057
        //  1042: goto            1049
        //  1045: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //  1048: athrow         
        //  1049: invokestatic    n/d/a/d/q.f:()Ljava/lang/String;
        //  1052: areturn        
        //  1053: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //  1056: athrow         
        //  1057: iload           4
        //  1059: iload_3        
        //  1060: ifeq            1098
        //  1063: iload           5
        //  1065: goto            1072
        //  1068: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //  1071: athrow         
        //  1072: if_icmpgt       1092
        //  1075: new             Ljava/lang/String;
        //  1078: dup            
        //  1079: aload           6
        //  1081: iconst_0       
        //  1082: iload           4
        //  1084: invokespecial   java/lang/String.<init>:([CII)V
        //  1087: areturn        
        //  1088: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //  1091: athrow         
        //  1092: iload           8
        //  1094: iload_3        
        //  1095: ifeq            1120
        //  1098: iload_3        
        //  1099: ifeq            1120
        //  1102: goto            1109
        //  1105: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //  1108: athrow         
        //  1109: ifeq            1143
        //  1112: goto            1119
        //  1115: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //  1118: athrow         
        //  1119: iload_2        
        //  1120: ifeq            1143
        //  1123: new             Ljava/lang/String;
        //  1126: dup            
        //  1127: aload           6
        //  1129: iconst_0       
        //  1130: iload           4
        //  1132: invokespecial   java/lang/String.<init>:([CII)V
        //  1135: goto            1142
        //  1138: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //  1141: athrow         
        //  1142: areturn        
        //  1143: new             Ljava/lang/String;
        //  1146: dup            
        //  1147: aload           6
        //  1149: iconst_0       
        //  1150: iload           4
        //  1152: iconst_1       
        //  1153: isub           
        //  1154: invokespecial   java/lang/String.<init>:([CII)V
        //  1157: iload_3        
        //  1158: ifeq            1142
        //  1161: areturn        
        //    StackMapTable: 00 A2 FF 00 0F 00 04 07 00 36 01 01 01 00 01 07 00 1E 03 41 07 00 1E 03 44 07 00 36 FF 00 10 00 05 07 00 36 01 01 01 01 00 01 07 00 1E 03 40 07 00 36 00 47 01 FF 00 0D 00 06 07 00 36 01 01 01 01 01 00 01 07 00 1E 03 41 07 00 1E 03 43 01 FF 00 1B 00 07 07 00 36 01 01 01 01 01 07 00 4A 00 01 07 00 1E 43 01 48 07 00 1E 03 45 07 00 1E 43 01 02 42 01 FD 00 04 01 01 56 07 00 1E FF 00 03 00 09 07 00 36 01 01 01 01 01 07 00 4A 01 01 00 02 07 00 4A 01 49 07 00 1E FF 00 03 00 09 07 00 36 01 01 01 01 01 07 00 4A 01 01 00 02 01 01 45 07 00 1E 03 46 07 00 1E FF 00 03 00 09 07 00 36 01 01 01 01 01 07 00 4A 01 01 00 02 07 00 4A 01 01 06 FF 00 0A 00 09 07 00 36 01 01 01 01 01 07 00 4A 01 01 00 02 01 01 49 07 00 1E 03 4C 07 00 1E 43 01 01 FF 00 02 00 09 07 00 36 01 01 01 01 01 07 00 4A 01 01 00 02 01 01 FC 00 06 01 57 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 46 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 45 07 00 1E 03 4C 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 07 00 4A 01 44 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 49 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 07 00 4A 01 10 02 0A FF 00 02 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 02 57 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 46 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 45 07 00 1E 03 4B 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 46 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 45 07 00 1E 03 48 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 49 07 00 1E 03 4A 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 4D 07 00 1E 03 48 07 00 1E 43 01 46 07 00 1E 43 01 4A 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 43 01 01 19 06 FF 00 02 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 02 57 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 46 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 45 07 00 1E 03 4B 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 46 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 45 07 00 1E 03 4B 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 46 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 45 07 00 1E 03 48 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 49 07 00 1E 03 4A 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 4D 07 00 1E 03 4C 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 49 07 00 1E 03 41 07 00 1E 03 FF 00 05 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 49 07 00 1E 03 40 01 01 FF 00 02 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 FC 00 06 01 57 07 00 1E FF 00 03 00 0B 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 01 00 02 01 01 45 07 00 1E 03 FF 00 20 00 0B 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 01 00 02 01 01 02 03 0A FF 00 20 00 0B 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 01 00 02 01 01 FA 00 02 06 4B 07 00 1E 03 43 07 00 1E 03 41 01 48 07 00 1E FF 00 03 00 0A 07 00 36 01 01 01 01 01 07 00 4A 01 01 01 00 02 01 01 4F 07 00 1E 03 45 01 46 07 00 1E 43 01 45 07 00 1E 03 40 01 51 07 00 1E 43 07 00 36 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  4      12     15     19     Ljava/lang/IllegalArgumentException;
        //  9      21     21     25     Ljava/lang/IllegalArgumentException;
        //  35     44     47     51     Ljava/lang/IllegalArgumentException;
        //  63     72     75     79     Ljava/lang/IllegalArgumentException;
        //  69     81     81     85     Ljava/lang/IllegalArgumentException;
        //  93     114    117    121    Ljava/lang/IllegalArgumentException;
        //  110    127    130    134    Ljava/lang/IllegalArgumentException;
        //  121    137    140    144    Ljava/lang/IllegalArgumentException;
        //  163    175    178    182    Ljava/lang/IllegalArgumentException;
        //  171    189    192    196    Ljava/lang/IllegalArgumentException;
        //  182    199    202    206    Ljava/lang/IllegalArgumentException;
        //  196    210    213    217    Ljava/lang/IllegalArgumentException;
        //  237    244    247    251    Ljava/lang/IllegalArgumentException;
        //  241    261    264    268    Ljava/lang/IllegalArgumentException;
        //  287    301    304    308    Ljava/lang/IllegalArgumentException;
        //  297    312    315    319    Ljava/lang/IllegalArgumentException;
        //  308    322    325    329    Ljava/lang/IllegalArgumentException;
        //  319    339    342    346    Ljava/lang/IllegalArgumentException;
        //  329    348    351    355    Ljava/lang/IllegalArgumentException;
        //  355    362    365    369    Ljava/lang/IllegalArgumentException;
        //  413    427    430    434    Ljava/lang/IllegalArgumentException;
        //  423    438    441    445    Ljava/lang/IllegalArgumentException;
        //  434    448    451    455    Ljava/lang/IllegalArgumentException;
        //  445    464    467    471    Ljava/lang/IllegalArgumentException;
        //  471    479    482    486    Ljava/lang/IllegalArgumentException;
        //  475    489    492    496    Ljava/lang/IllegalArgumentException;
        //  486    502    505    509    Ljava/lang/IllegalArgumentException;
        //  509    516    519    523    Ljava/lang/IllegalArgumentException;
        //  513    531    534    538    Ljava/lang/IllegalArgumentException;
        //  542    549    552    556    Ljava/lang/IllegalArgumentException;
        //  546    562    565    569    Ljava/lang/IllegalArgumentException;
        //  556    573    576    580    Ljava/lang/IllegalArgumentException;
        //  569    588    591    595    Ljava/lang/IllegalArgumentException;
        //  647    661    664    668    Ljava/lang/IllegalArgumentException;
        //  657    672    675    679    Ljava/lang/IllegalArgumentException;
        //  668    682    685    689    Ljava/lang/IllegalArgumentException;
        //  679    698    701    705    Ljava/lang/IllegalArgumentException;
        //  705    713    716    720    Ljava/lang/IllegalArgumentException;
        //  709    723    726    730    Ljava/lang/IllegalArgumentException;
        //  720    739    742    746    Ljava/lang/IllegalArgumentException;
        //  746    754    757    761    Ljava/lang/IllegalArgumentException;
        //  750    764    767    771    Ljava/lang/IllegalArgumentException;
        //  761    777    780    784    Ljava/lang/IllegalArgumentException;
        //  784    791    794    798    Ljava/lang/IllegalArgumentException;
        //  788    806    809    813    Ljava/lang/IllegalArgumentException;
        //  817    824    827    831    Ljava/lang/IllegalArgumentException;
        //  821    841    844    848    Ljava/lang/IllegalArgumentException;
        //  848    855    858    862    Ljava/lang/IllegalArgumentException;
        //  852    864    864    868    Ljava/lang/IllegalArgumentException;
        //  874    881    884    888    Ljava/lang/IllegalArgumentException;
        //  908    922    925    929    Ljava/lang/IllegalArgumentException;
        //  918    932    935    939    Ljava/lang/IllegalArgumentException;
        //  1033   1042   1045   1049   Ljava/lang/IllegalArgumentException;
        //  1039   1053   1053   1057   Ljava/lang/IllegalArgumentException;
        //  1059   1065   1068   1072   Ljava/lang/IllegalArgumentException;
        //  1072   1088   1088   1092   Ljava/lang/IllegalArgumentException;
        //  1092   1102   1105   1109   Ljava/lang/IllegalArgumentException;
        //  1098   1112   1115   1119   Ljava/lang/IllegalArgumentException;
        //  1120   1135   1138   1142   Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0121:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static String concat(final String s, final String s2) {
        final int b = IOCase.b();
        final int prefixLength = getPrefixLength(s2);
        final int n = b;
        Label_0046: {
            String normalize = null;
            Label_0031: {
                Label_0024: {
                    int n2;
                    try {
                        final int n3;
                        n2 = (n3 = prefixLength);
                        if (n != 0) {
                            break Label_0031;
                        }
                        if (n2 < 0) {
                            break Label_0024;
                        }
                        break Label_0024;
                    }
                    catch (IllegalArgumentException ex) {
                        throw b(ex);
                    }
                    try {
                        if (n2 < 0) {
                            return null;
                        }
                    }
                    catch (IllegalArgumentException ex2) {
                        throw b(ex2);
                    }
                }
                int n3 = prefixLength;
                try {
                    if (n3 <= 0) {
                        break Label_0046;
                    }
                    normalize = normalize(s2);
                }
                catch (IllegalArgumentException ex3) {
                    throw b(ex3);
                }
            }
            return normalize;
        }
        String s3 = s;
        String normalize = s;
        if (n != 0) {
            return normalize;
        }
        Label_0072: {
            Label_0065: {
                try {
                    if (n != 0) {
                        break Label_0072;
                    }
                    if (s == null) {
                        break Label_0065;
                    }
                    break Label_0065;
                }
                catch (IllegalArgumentException ex4) {
                    throw b(ex4);
                }
                try {
                    if (s == null) {
                        return null;
                    }
                }
                catch (IllegalArgumentException ex5) {
                    throw b(ex5);
                }
            }
            s3 = s;
        }
        final int q = q.o.m.s.q.q(s3);
        int j = 0;
        Label_0117: {
            Label_0105: {
                String normalize2 = null;
                Label_0093: {
                    int n4;
                    try {
                        n4 = (j = q);
                        if (n != 0) {
                            break Label_0117;
                        }
                        if (n4 == 0) {
                            break Label_0093;
                        }
                        break Label_0105;
                    }
                    catch (IllegalArgumentException ex6) {
                        throw b(ex6);
                    }
                    try {
                        if (n4 != 0) {
                            break Label_0105;
                        }
                        normalize2 = normalize(s2);
                    }
                    catch (IllegalArgumentException ex7) {
                        throw b(ex7);
                    }
                }
                return normalize2;
            }
            String normalize2 = s;
            if (n != 0) {
                return normalize2;
            }
            j = q.o.m.s.q.j(s, q - 1);
        }
        final int n5 = j;
        Label_0156: {
            try {
                if (!isSeparator((char)n5)) {
                    break Label_0156;
                }
                normalize(q.o.m.s.q.s(q.o.m.s.q.r(q.o.m.s.q.r(new StringBuilder(), s), s2)));
            }
            catch (IllegalArgumentException ex8) {
                throw b(ex8);
            }
            return;
        }
        final String normalize3 = normalize(q.o.m.s.q.s(q.o.m.s.q.r(q.o.m.s.q.sk(q.o.m.s.q.r(new StringBuilder(), s), '/'), s2)));
        if (n == 0) {
            return normalize3;
        }
        return normalize3;
    }
    
    public static boolean directoryContains(final String s, final String s2) throws IOException {
        final int c = IOCase.c();
        String s3 = null;
        Label_0041: {
            Label_0019: {
                try {
                    s3 = s;
                    if (c == 0) {
                        break Label_0041;
                    }
                    if (s == null) {
                        break Label_0019;
                    }
                    break Label_0019;
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                try {
                    if (s == null) {
                        throw new IllegalArgumentException(a(5144, -26833));
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            s3 = s2;
        }
        boolean b = false;
        if (s3 != null) {
            boolean checkEquals;
            b = (checkEquals = IOCase.SYSTEM.checkEquals(s, s2));
            if (c != 0) {
                Label_0074: {
                    try {
                        if (c == 0) {
                            return checkEquals;
                        }
                        if (!b) {
                            break Label_0074;
                        }
                    }
                    catch (IOException ex3) {
                        throw b(ex3);
                    }
                    return false;
                }
                boolean checkStartsWith;
                checkEquals = (checkStartsWith = IOCase.SYSTEM.checkStartsWith(s2, s));
                if (c == 0) {
                    return checkStartsWith;
                }
                return checkEquals;
            }
        }
        return b;
    }
    
    public static String separatorsToUnix(final String s) {
        final int b = IOCase.b();
        String s2 = null;
        char c2 = '\0';
        Label_0049: {
            Label_0046: {
                final String ei;
                Label_0033: {
                    try {
                        if (b != 0) {
                            return ei;
                        }
                        if (s == null) {
                            break Label_0033;
                        }
                    }
                    catch (IllegalArgumentException ex) {
                        throw b(ex);
                    }
                    s2 = s;
                    String s3 = s;
                    while (true) {
                        final char c = c2 = '\\';
                        if (b != 0) {
                            break Label_0049;
                        }
                        try {
                            if (q.eu(s3, c) != -1) {
                                break Label_0046;
                            }
                            s2 = s;
                            s3 = s;
                            if (b != 0) {
                                continue;
                            }
                        }
                        catch (IllegalArgumentException ex2) {
                            throw b(ex2);
                        }
                        break;
                    }
                }
                return ei;
            }
            s2 = s;
            c2 = '\\';
        }
        final String ei = q.ei(s2, c2, '/');
        if (b == 0) {
            return ei;
        }
        return ei;
    }
    
    public static String separatorsToWindows(final String s) {
        final int c = IOCase.c();
        String s2 = null;
        char c3 = '\0';
        Label_0049: {
            Label_0046: {
                final String ei;
                Label_0033: {
                    try {
                        if (c == 0) {
                            return ei;
                        }
                        if (s == null) {
                            break Label_0033;
                        }
                    }
                    catch (IllegalArgumentException ex) {
                        throw b(ex);
                    }
                    s2 = s;
                    String s3 = s;
                    while (true) {
                        final char c2 = c3 = '/';
                        if (c == 0) {
                            break Label_0049;
                        }
                        try {
                            if (q.eu(s3, c2) != -1) {
                                break Label_0046;
                            }
                            s2 = s;
                            s3 = s;
                            if (c == 0) {
                                continue;
                            }
                        }
                        catch (IllegalArgumentException ex2) {
                            throw b(ex2);
                        }
                        break;
                    }
                }
                return ei;
            }
            s2 = s;
            c3 = '/';
        }
        final String ei = q.ei(s2, c3, '\\');
        if (c != 0) {
            return ei;
        }
        return ei;
    }
    
    public static String separatorsToSystem(final String s) {
        final int b = IOCase.b();
        try {
            if (s == null) {
                return null;
            }
        }
        catch (IllegalArgumentException ex) {
            throw b(ex);
        }
        Label_0032: {
            try {
                if (!isSystemWindows()) {
                    break Label_0032;
                }
                separatorsToWindows(s);
            }
            catch (IllegalArgumentException ex2) {
                throw b(ex2);
            }
            return;
        }
        final String separatorsToUnix = separatorsToUnix(s);
        if (b == 0) {
            return separatorsToUnix;
        }
        return separatorsToUnix;
    }
    
    public static int getPrefixLength(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: iload_1        
        //     6: ifne            22
        //     9: ifnonnull       21
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: iconst_m1      
        //    20: ireturn        
        //    21: aload_0        
        //    22: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //    25: istore_2       
        //    26: iload_2        
        //    27: iload_1        
        //    28: ifne            20
        //    31: iload_1        
        //    32: ifne            52
        //    35: ifne            47
        //    38: goto            45
        //    41: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    44: athrow         
        //    45: iconst_0       
        //    46: ireturn        
        //    47: aload_0        
        //    48: iconst_0       
        //    49: invokestatic    q/o/m/s/q.j:(Ljava/lang/String;I)C
        //    52: istore_3       
        //    53: iload_3        
        //    54: iload_1        
        //    55: ifne            46
        //    58: bipush          58
        //    60: iload_1        
        //    61: ifne            82
        //    64: if_icmpne       76
        //    67: goto            74
        //    70: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    73: athrow         
        //    74: iconst_m1      
        //    75: ireturn        
        //    76: iload_2        
        //    77: iload_1        
        //    78: ifne            75
        //    81: iconst_1       
        //    82: iload_1        
        //    83: ifne            179
        //    86: if_icmpne       161
        //    89: goto            96
        //    92: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    95: athrow         
        //    96: iload_3        
        //    97: iload_1        
        //    98: ifne            134
        //   101: goto            108
        //   104: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   107: athrow         
        //   108: bipush          126
        //   110: goto            117
        //   113: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   116: athrow         
        //   117: if_icmpne       122
        //   120: iconst_2       
        //   121: ireturn        
        //   122: iload_3        
        //   123: invokestatic    org/apache/commons/io/FilenameUtils.isSeparator:(C)Z
        //   126: iload_1        
        //   127: ifne            121
        //   130: iload_1        
        //   131: ifne            156
        //   134: iload_1        
        //   135: ifne            156
        //   138: goto            145
        //   141: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   144: athrow         
        //   145: ifeq            159
        //   148: goto            155
        //   151: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   154: athrow         
        //   155: iconst_1       
        //   156: goto            160
        //   159: iconst_0       
        //   160: ireturn        
        //   161: iload_3        
        //   162: iload_1        
        //   163: ifne            349
        //   166: bipush          126
        //   168: iload_1        
        //   169: ifne            117
        //   172: goto            179
        //   175: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   178: athrow         
        //   179: if_icmpne       344
        //   182: aload_0        
        //   183: bipush          47
        //   185: iconst_1       
        //   186: invokestatic    q/o/m/s/q.pc:(Ljava/lang/String;II)I
        //   189: istore          4
        //   191: aload_0        
        //   192: bipush          92
        //   194: iconst_1       
        //   195: invokestatic    q/o/m/s/q.pc:(Ljava/lang/String;II)I
        //   198: istore          5
        //   200: iload           4
        //   202: iconst_m1      
        //   203: iload_1        
        //   204: ifne            278
        //   207: if_icmpne       245
        //   210: goto            217
        //   213: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   216: athrow         
        //   217: iload           5
        //   219: iconst_m1      
        //   220: goto            227
        //   223: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   226: athrow         
        //   227: iload_1        
        //   228: ifne            278
        //   231: if_icmpne       245
        //   234: iload_2        
        //   235: iconst_1       
        //   236: goto            243
        //   239: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   242: athrow         
        //   243: iadd           
        //   244: ireturn        
        //   245: iload           4
        //   247: iload_1        
        //   248: ifne            283
        //   251: iload_1        
        //   252: ifne            283
        //   255: goto            262
        //   258: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   261: athrow         
        //   262: iconst_m1      
        //   263: iload_1        
        //   264: ifne            227
        //   267: goto            274
        //   270: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   273: athrow         
        //   274: iload_1        
        //   275: ifne            243
        //   278: if_icmpne       286
        //   281: iload           5
        //   283: goto            288
        //   286: iload           4
        //   288: istore          4
        //   290: iload           5
        //   292: iload_1        
        //   293: ifne            327
        //   296: iload_1        
        //   297: ifne            327
        //   300: goto            307
        //   303: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   306: athrow         
        //   307: iconst_m1      
        //   308: if_icmpne       330
        //   311: goto            318
        //   314: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   317: athrow         
        //   318: iload           4
        //   320: goto            327
        //   323: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   326: athrow         
        //   327: goto            332
        //   330: iload           5
        //   332: istore          5
        //   334: iload           4
        //   336: iload           5
        //   338: invokestatic    q/o/m/s/q.px:(II)I
        //   341: iconst_1       
        //   342: iadd           
        //   343: ireturn        
        //   344: aload_0        
        //   345: iconst_1       
        //   346: invokestatic    q/o/m/s/q.j:(Ljava/lang/String;I)C
        //   349: istore          4
        //   351: iload           4
        //   353: iload_1        
        //   354: ifne            198
        //   357: iload_1        
        //   358: ifne            494
        //   361: bipush          58
        //   363: if_icmpne       486
        //   366: goto            373
        //   369: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   372: athrow         
        //   373: iload_3        
        //   374: invokestatic    q/o/m/s/q.ph:(C)C
        //   377: istore_3       
        //   378: iload_3        
        //   379: iload_1        
        //   380: ifne            485
        //   383: bipush          65
        //   385: if_icmplt       476
        //   388: goto            395
        //   391: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   394: athrow         
        //   395: iload_3        
        //   396: goto            403
        //   399: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   402: athrow         
        //   403: iload_1        
        //   404: ifne            485
        //   407: bipush          90
        //   409: if_icmpgt       476
        //   412: iload_2        
        //   413: goto            420
        //   416: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   419: athrow         
        //   420: iload_1        
        //   421: ifne            469
        //   424: iconst_2       
        //   425: if_icmpeq       457
        //   428: goto            435
        //   431: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   434: athrow         
        //   435: aload_0        
        //   436: iconst_2       
        //   437: invokestatic    q/o/m/s/q.j:(Ljava/lang/String;I)C
        //   440: invokestatic    org/apache/commons/io/FilenameUtils.isSeparator:(C)Z
        //   443: goto            450
        //   446: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   449: athrow         
        //   450: iload_1        
        //   451: ifne            475
        //   454: ifne            470
        //   457: iconst_2       
        //   458: iload_1        
        //   459: ifne            450
        //   462: goto            469
        //   465: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   468: athrow         
        //   469: ireturn        
        //   470: iconst_3       
        //   471: iload_1        
        //   472: ifne            469
        //   475: ireturn        
        //   476: iconst_m1      
        //   477: iload_1        
        //   478: ifne            403
        //   481: iload_1        
        //   482: ifne            420
        //   485: ireturn        
        //   486: iload_3        
        //   487: invokestatic    org/apache/commons/io/FilenameUtils.isSeparator:(C)Z
        //   490: iload_1        
        //   491: ifne            379
        //   494: iload_1        
        //   495: ifne            745
        //   498: ifeq            729
        //   501: goto            508
        //   504: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   507: athrow         
        //   508: iload           4
        //   510: invokestatic    org/apache/commons/io/FilenameUtils.isSeparator:(C)Z
        //   513: goto            520
        //   516: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   519: athrow         
        //   520: iload_1        
        //   521: ifne            745
        //   524: ifeq            729
        //   527: aload_0        
        //   528: bipush          47
        //   530: iconst_2       
        //   531: invokestatic    q/o/m/s/q.pc:(Ljava/lang/String;II)I
        //   534: goto            541
        //   537: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   540: athrow         
        //   541: istore          5
        //   543: aload_0        
        //   544: bipush          92
        //   546: iconst_2       
        //   547: invokestatic    q/o/m/s/q.pc:(Ljava/lang/String;II)I
        //   550: istore          6
        //   552: iload           5
        //   554: iconst_m1      
        //   555: iload_1        
        //   556: ifne            604
        //   559: if_icmpne       593
        //   562: goto            569
        //   565: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   568: athrow         
        //   569: iload           6
        //   571: iload_1        
        //   572: ifne            633
        //   575: goto            582
        //   578: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   581: athrow         
        //   582: iconst_m1      
        //   583: goto            590
        //   586: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   589: athrow         
        //   590: if_icmpeq       617
        //   593: iload           5
        //   595: iload_1        
        //   596: ifne            633
        //   599: iconst_2       
        //   600: iload_1        
        //   601: ifne            590
        //   604: if_icmpeq       617
        //   607: iload           6
        //   609: iconst_2       
        //   610: iload_1        
        //   611: ifne            663
        //   614: if_icmpne       634
        //   617: iconst_m1      
        //   618: iload_1        
        //   619: ifne            595
        //   622: goto            629
        //   625: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   628: athrow         
        //   629: iload_1        
        //   630: ifne            609
        //   633: ireturn        
        //   634: iload           5
        //   636: iload_1        
        //   637: ifne            633
        //   640: iload_1        
        //   641: ifne            668
        //   644: iload_1        
        //   645: ifne            668
        //   648: goto            655
        //   651: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   654: athrow         
        //   655: iconst_m1      
        //   656: goto            663
        //   659: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   662: athrow         
        //   663: if_icmpne       671
        //   666: iload           6
        //   668: goto            673
        //   671: iload           5
        //   673: istore          5
        //   675: iload           6
        //   677: iload_1        
        //   678: ifne            712
        //   681: iload_1        
        //   682: ifne            712
        //   685: goto            692
        //   688: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   691: athrow         
        //   692: iconst_m1      
        //   693: if_icmpne       715
        //   696: goto            703
        //   699: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   702: athrow         
        //   703: iload           5
        //   705: goto            712
        //   708: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   711: athrow         
        //   712: goto            717
        //   715: iload           6
        //   717: istore          6
        //   719: iload           5
        //   721: iload           6
        //   723: invokestatic    q/o/m/s/q.px:(II)I
        //   726: iconst_1       
        //   727: iadd           
        //   728: ireturn        
        //   729: iload_3        
        //   730: invokestatic    org/apache/commons/io/FilenameUtils.isSeparator:(C)Z
        //   733: iload_1        
        //   734: ifne            520
        //   737: iload_1        
        //   738: ifne            541
        //   741: iload_1        
        //   742: ifne            760
        //   745: iload_1        
        //   746: ifne            760
        //   749: ifeq            763
        //   752: goto            759
        //   755: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   758: athrow         
        //   759: iconst_1       
        //   760: goto            764
        //   763: iconst_0       
        //   764: ireturn        
        //    StackMapTable: 00 7D FF 00 0F 00 02 07 00 36 01 00 01 07 00 1E 03 40 01 00 40 07 00 36 FF 00 12 00 03 07 00 36 01 01 00 01 07 00 1E 03 40 01 00 44 01 FF 00 11 00 04 07 00 36 01 01 01 00 01 07 00 1E 03 40 01 00 FF 00 05 00 04 07 00 36 01 01 01 00 02 01 01 49 07 00 1E 03 47 07 00 1E 43 01 44 07 00 1E FF 00 03 00 04 07 00 36 01 01 01 00 02 01 01 43 01 00 4B 01 46 07 00 1E 43 01 45 07 00 1E 03 40 01 02 40 01 00 4D 07 00 1E FF 00 03 00 04 07 00 36 01 01 01 00 02 01 01 FF 00 12 00 05 07 00 36 01 01 01 01 00 01 01 FF 00 0E 00 06 07 00 36 01 01 01 01 01 00 01 07 00 1E 03 45 07 00 1E FF 00 03 00 06 07 00 36 01 01 01 01 01 00 02 01 01 4B 07 00 1E FF 00 03 00 06 07 00 36 01 01 01 01 01 00 02 01 01 01 4C 07 00 1E 43 01 47 07 00 1E FF 00 03 00 06 07 00 36 01 01 01 01 01 00 02 01 01 FF 00 03 00 06 07 00 36 01 01 01 01 01 00 02 01 01 44 01 02 41 01 4E 07 00 1E 43 01 46 07 00 1E 03 44 07 00 1E 43 01 02 41 01 F9 00 0B 44 01 FF 00 13 00 05 07 00 36 01 01 01 01 00 01 07 00 1E 03 45 01 4B 07 00 1E 03 43 07 00 1E 43 01 4C 07 00 1E 43 01 4A 07 00 1E 03 4A 07 00 1E 43 01 06 47 07 00 1E 43 01 00 44 01 00 48 01 00 47 01 49 07 00 1E 03 47 07 00 1E 43 01 50 07 00 1E 43 01 FF 00 17 00 07 07 00 36 01 01 01 01 01 01 00 01 07 00 1E 03 48 07 00 1E 43 01 43 07 00 1E FF 00 03 00 07 07 00 36 01 01 01 01 01 01 00 02 01 01 02 41 01 FF 00 08 00 07 07 00 36 01 01 01 01 01 01 00 02 01 01 44 01 07 47 07 00 1E 43 01 43 01 00 50 07 00 1E 43 01 43 07 00 1E FF 00 03 00 07 07 00 36 01 01 01 01 01 01 00 02 01 01 44 01 02 41 01 4E 07 00 1E 43 01 46 07 00 1E 03 44 07 00 1E 43 01 02 41 01 F9 00 0B 4F 01 49 07 00 1E 03 40 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  4      12     15     19     Ljava/lang/IllegalArgumentException;
        //  31     38     41     45     Ljava/lang/IllegalArgumentException;
        //  58     67     70     74     Ljava/lang/IllegalArgumentException;
        //  82     89     92     96     Ljava/lang/IllegalArgumentException;
        //  86     101    104    108    Ljava/lang/IllegalArgumentException;
        //  96     110    113    117    Ljava/lang/IllegalArgumentException;
        //  130    138    141    145    Ljava/lang/IllegalArgumentException;
        //  134    148    151    155    Ljava/lang/IllegalArgumentException;
        //  161    172    175    179    Ljava/lang/IllegalArgumentException;
        //  200    210    213    217    Ljava/lang/IllegalArgumentException;
        //  207    220    223    227    Ljava/lang/IllegalArgumentException;
        //  231    236    239    243    Ljava/lang/IllegalArgumentException;
        //  245    255    258    262    Ljava/lang/IllegalArgumentException;
        //  251    267    270    274    Ljava/lang/IllegalArgumentException;
        //  290    300    303    307    Ljava/lang/IllegalArgumentException;
        //  296    311    314    318    Ljava/lang/IllegalArgumentException;
        //  307    320    323    327    Ljava/lang/IllegalArgumentException;
        //  357    366    369    373    Ljava/lang/IllegalArgumentException;
        //  379    388    391    395    Ljava/lang/IllegalArgumentException;
        //  383    396    399    403    Ljava/lang/IllegalArgumentException;
        //  407    413    416    420    Ljava/lang/IllegalArgumentException;
        //  420    428    431    435    Ljava/lang/IllegalArgumentException;
        //  424    443    446    450    Ljava/lang/IllegalArgumentException;
        //  454    462    465    469    Ljava/lang/IllegalArgumentException;
        //  494    501    504    508    Ljava/lang/IllegalArgumentException;
        //  498    513    516    520    Ljava/lang/IllegalArgumentException;
        //  524    534    537    541    Ljava/lang/IllegalArgumentException;
        //  552    562    565    569    Ljava/lang/IllegalArgumentException;
        //  559    575    578    582    Ljava/lang/IllegalArgumentException;
        //  569    583    586    590    Ljava/lang/IllegalArgumentException;
        //  614    622    625    629    Ljava/lang/IllegalArgumentException;
        //  640    648    651    655    Ljava/lang/IllegalArgumentException;
        //  644    656    659    663    Ljava/lang/IllegalArgumentException;
        //  675    685    688    692    Ljava/lang/IllegalArgumentException;
        //  681    696    699    703    Ljava/lang/IllegalArgumentException;
        //  692    705    708    712    Ljava/lang/IllegalArgumentException;
        //  745    752    755    759    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0096:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static int indexOfLastSeparator(final String s) {
        final int b = IOCase.b();
        String s2 = null;
        Label_0022: {
            Label_0021: {
                try {
                    s2 = s;
                    if (b != 0) {
                        break Label_0022;
                    }
                    if (s != null) {
                        break Label_0021;
                    }
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                return;
            }
            s2 = s;
        }
        final int pg = q.pg(q.pj(s2, 47), q.pj(s, 92));
        if (b == 0) {
            return pg;
        }
        return pg;
    }
    
    public static int indexOfExtension(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: iload_1        
        //     6: ifne            22
        //     9: ifnonnull       21
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: iconst_m1      
        //    20: ireturn        
        //    21: aload_0        
        //    22: bipush          46
        //    24: invokestatic    q/o/m/s/q.pj:(Ljava/lang/String;I)I
        //    27: istore_2       
        //    28: aload_0        
        //    29: invokestatic    org/apache/commons/io/FilenameUtils.indexOfLastSeparator:(Ljava/lang/String;)I
        //    32: istore_3       
        //    33: iload_3        
        //    34: iload_1        
        //    35: ifne            20
        //    38: iload_1        
        //    39: ifne            72
        //    42: iload_1        
        //    43: ifne            72
        //    46: goto            53
        //    49: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    52: athrow         
        //    53: iload_2        
        //    54: if_icmple       75
        //    57: goto            64
        //    60: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    63: athrow         
        //    64: iconst_m1      
        //    65: goto            72
        //    68: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    71: athrow         
        //    72: goto            76
        //    75: iload_2        
        //    76: ireturn        
        //    StackMapTable: 00 0D FF 00 0F 00 02 07 00 36 01 00 01 07 00 1E 03 40 01 00 40 07 00 36 FF 00 1A 00 04 07 00 36 01 01 01 00 01 07 00 1E 43 01 46 07 00 1E 03 43 07 00 1E 43 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  4      12     15     19     Ljava/lang/IllegalArgumentException;
        //  38     46     49     53     Ljava/lang/IllegalArgumentException;
        //  42     57     60     64     Ljava/lang/IllegalArgumentException;
        //  53     65     68     72     Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0053:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static String getPrefix(final String s) {
        final int c = IOCase.c();
        String s2 = null;
        Label_0026: {
            Label_0019: {
                try {
                    s2 = s;
                    if (c == 0) {
                        break Label_0026;
                    }
                    if (s == null) {
                        break Label_0019;
                    }
                    break Label_0019;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    if (s == null) {
                        return null;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            s2 = s;
        }
        final int prefixLength = getPrefixLength(s2);
        Label_0108: {
            Label_0052: {
                Label_0045: {
                    int n;
                    try {
                        final int n2;
                        n = (n2 = prefixLength);
                        if (c == 0) {
                            break Label_0052;
                        }
                        if (n < 0) {
                            break Label_0045;
                        }
                        break Label_0045;
                    }
                    catch (IllegalArgumentException ex3) {
                        throw b(ex3);
                    }
                    try {
                        if (n < 0) {
                            return null;
                        }
                    }
                    catch (IllegalArgumentException ex4) {
                        throw b(ex4);
                    }
                }
                int n2 = prefixLength;
                try {
                    if (n2 <= q.q(s)) {
                        break Label_0108;
                    }
                    failIfNullBytePresent(q.s(q.sk(q.r(new StringBuilder(), s), '/')));
                    q.s(q.sk(q.r(new StringBuilder(), s), '/'));
                }
                catch (IllegalArgumentException ex5) {
                    throw b(ex5);
                }
            }
            return;
        }
        final String h = q.h(s, 0, prefixLength);
        failIfNullBytePresent(h);
        final String s3 = h;
        if (c != 0) {
            return s3;
        }
        return s3;
    }
    
    public static String getPath(final String s) {
        return doGetPath(s, 1);
    }
    
    public static String getPathNoEndSeparator(final String s) {
        return doGetPath(s, 0);
    }
    
    private static String doGetPath(final String p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: iload_2        
        //     6: ifne            26
        //     9: ifnonnull       25
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: aconst_null    
        //    20: areturn        
        //    21: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    24: athrow         
        //    25: aload_0        
        //    26: invokestatic    org/apache/commons/io/FilenameUtils.getPrefixLength:(Ljava/lang/String;)I
        //    29: istore_3       
        //    30: iload_3        
        //    31: iload_2        
        //    32: ifne            55
        //    35: ifge            51
        //    38: goto            45
        //    41: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    44: athrow         
        //    45: aconst_null    
        //    46: areturn        
        //    47: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    50: athrow         
        //    51: aload_0        
        //    52: invokestatic    org/apache/commons/io/FilenameUtils.indexOfLastSeparator:(Ljava/lang/String;)I
        //    55: istore          4
        //    57: iload           4
        //    59: iload_1        
        //    60: iadd           
        //    61: istore          5
        //    63: iload_3        
        //    64: iload_2        
        //    65: ifne            102
        //    68: iload_2        
        //    69: ifne            106
        //    72: goto            79
        //    75: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    78: athrow         
        //    79: aload_0        
        //    80: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //    83: if_icmpge       133
        //    86: goto            93
        //    89: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    92: athrow         
        //    93: iload           4
        //    95: goto            102
        //    98: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   101: athrow         
        //   102: iload_2        
        //   103: ifne            128
        //   106: iload_2        
        //   107: ifne            128
        //   110: goto            117
        //   113: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   116: athrow         
        //   117: iflt            133
        //   120: goto            127
        //   123: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   126: athrow         
        //   127: iload_3        
        //   128: iload           5
        //   130: if_icmplt       144
        //   133: invokestatic    n/d/a/d/q.f:()Ljava/lang/String;
        //   136: goto            143
        //   139: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   142: athrow         
        //   143: areturn        
        //   144: aload_0        
        //   145: iload_3        
        //   146: iload           5
        //   148: invokestatic    q/o/m/s/q.h:(Ljava/lang/String;II)Ljava/lang/String;
        //   151: astore          6
        //   153: aload           6
        //   155: invokestatic    org/apache/commons/io/FilenameUtils.failIfNullBytePresent:(Ljava/lang/String;)V
        //   158: aload           6
        //   160: iload_2        
        //   161: ifne            143
        //   164: areturn        
        //    StackMapTable: 00 1A FF 00 0F 00 03 07 00 36 01 01 00 01 07 00 1E 03 41 07 00 1E 03 40 07 00 36 FF 00 0E 00 04 07 00 36 01 01 01 00 01 07 00 1E 03 41 07 00 1E 03 43 01 FF 00 13 00 06 07 00 36 01 01 01 01 01 00 01 07 00 1E 43 01 49 07 00 1E 03 44 07 00 1E 43 01 43 01 46 07 00 1E 43 01 45 07 00 1E 03 40 01 04 45 07 00 1E 43 07 00 36 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  4      12     15     19     Ljava/lang/IllegalArgumentException;
        //  9      21     21     25     Ljava/lang/IllegalArgumentException;
        //  30     38     41     45     Ljava/lang/IllegalArgumentException;
        //  35     47     47     51     Ljava/lang/IllegalArgumentException;
        //  63     72     75     79     Ljava/lang/IllegalArgumentException;
        //  68     86     89     93     Ljava/lang/IllegalArgumentException;
        //  79     95     98     102    Ljava/lang/IllegalArgumentException;
        //  102    110    113    117    Ljava/lang/IllegalArgumentException;
        //  106    120    123    127    Ljava/lang/IllegalArgumentException;
        //  128    136    139    143    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0079:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static String getFullPath(final String s) {
        return doGetFullPath(s, true);
    }
    
    public static String getFullPathNoEndSeparator(final String s) {
        return doGetFullPath(s, false);
    }
    
    private static String doGetFullPath(final String s, final boolean b) {
        final int c = IOCase.c();
        String s2 = null;
        Label_0026: {
            Label_0019: {
                try {
                    s2 = s;
                    if (c == 0) {
                        break Label_0026;
                    }
                    if (s == null) {
                        break Label_0019;
                    }
                    break Label_0019;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    if (s == null) {
                        return null;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            s2 = s;
        }
        final int prefixLength = getPrefixLength(s2);
        while (true) {
            int indexOfLastSeparator = 0;
            Label_0103: {
                Label_0099: {
                    int n4 = 0;
                    Label_0070: {
                        int n2 = 0;
                        Label_0052: {
                            Label_0045: {
                                int n;
                                try {
                                    n = (n2 = (indexOfLastSeparator = prefixLength));
                                    if (c == 0) {
                                        break Label_0052;
                                    }
                                    if (n < 0) {
                                        break Label_0045;
                                    }
                                    break Label_0045;
                                }
                                catch (IllegalArgumentException ex3) {
                                    throw b(ex3);
                                }
                                try {
                                    if (n < 0) {
                                        return null;
                                    }
                                }
                                catch (IllegalArgumentException ex4) {
                                    throw b(ex4);
                                }
                            }
                            indexOfLastSeparator = (n2 = prefixLength);
                            try {
                                if (c == 0) {
                                    break Label_0103;
                                }
                                final String s3 = s;
                                final int n3 = q.q(s3);
                                if (n2 >= n3) {
                                    break Label_0070;
                                }
                                break Label_0099;
                            }
                            catch (IllegalArgumentException ex5) {
                                throw b(ex5);
                            }
                        }
                        try {
                            final String s3 = s;
                            final int n3 = q.q(s3);
                            if (n2 < n3) {
                                break Label_0099;
                            }
                            n4 = (b ? 1 : 0);
                        }
                        catch (IllegalArgumentException ex6) {
                            throw b(ex6);
                        }
                    }
                    Label_0093: {
                        String prefix;
                        try {
                            if (n4 == 0) {
                                break Label_0093;
                            }
                            prefix = getPrefix(s);
                        }
                        catch (IllegalArgumentException ex7) {
                            throw b(ex7);
                        }
                        return prefix;
                    }
                    String prefix = s;
                    if (c != 0) {
                        return s;
                    }
                    return prefix;
                }
                indexOfLastSeparator = indexOfLastSeparator(s);
            }
            final int n5 = indexOfLastSeparator;
            int n4;
            int n7;
            final int n6 = n4 = (n7 = n5);
            if (c != 0) {
                int n8 = 0;
                Label_0169: {
                    Label_0168: {
                        Label_0165: {
                            Label_0154: {
                                Label_0138: {
                                    Label_0125: {
                                        try {
                                            if (c == 0) {
                                                break Label_0138;
                                            }
                                            if (n6 < 0) {
                                                break Label_0125;
                                            }
                                            break Label_0125;
                                        }
                                        catch (IllegalArgumentException ex8) {
                                            throw b(ex8);
                                        }
                                        try {
                                            if (n6 < 0) {
                                                return q.h(s, 0, prefixLength);
                                            }
                                        }
                                        catch (IllegalArgumentException ex9) {
                                            throw b(ex9);
                                        }
                                    }
                                    n7 = n5;
                                    try {
                                        n8 = (b ? 1 : 0);
                                        if (c == 0) {
                                            break Label_0165;
                                        }
                                        final int n9 = c;
                                        if (n9 != 0) {
                                            break Label_0154;
                                        }
                                        break Label_0165;
                                    }
                                    catch (IllegalArgumentException ex10) {
                                        throw b(ex10);
                                    }
                                }
                                try {
                                    final int n9 = c;
                                    if (n9 == 0) {
                                        break Label_0165;
                                    }
                                    if (!b) {
                                        break Label_0168;
                                    }
                                }
                                catch (IllegalArgumentException ex11) {
                                    throw b(ex11);
                                }
                            }
                            n8 = 1;
                        }
                        break Label_0169;
                    }
                    n8 = 0;
                }
                int n10 = n7 + n8;
                try {
                    if (n10 == 0) {
                        ++n10;
                    }
                }
                catch (IllegalArgumentException ex12) {
                    throw b(ex12);
                }
                return q.h(s, 0, n10);
            }
            continue;
        }
    }
    
    public static String getName(final String s) {
        final int c = IOCase.c();
        Label_0019: {
            try {
                final String s2 = s;
                if (c == 0) {
                    return q.pz(s, indexOfLastSeparator(s2) + 1);
                }
                if (s == null) {
                    break Label_0019;
                }
                break Label_0019;
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            try {
                if (s == null) {
                    return null;
                }
            }
            catch (IllegalArgumentException ex2) {
                throw b(ex2);
            }
        }
        failIfNullBytePresent(s);
        final String s2 = s;
        return q.pz(s, indexOfLastSeparator(s2) + 1);
    }
    
    private static void failIfNullBytePresent(final String s) {
        final int b = IOCase.b();
        final int q = q.o.m.s.q.q(s);
        int i = 0;
        final int n = b;
        while (i < q) {
            try {
                if (q.o.m.s.q.j(s, i) == '\0') {
                    throw new IllegalArgumentException(a(5146, 1215));
                }
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            ++i;
            if (n != 0) {
                break;
            }
        }
    }
    
    public static String getBaseName(final String s) {
        return removeExtension(getName(s));
    }
    
    public static String getExtension(final String s) {
        final int b = IOCase.b();
        String s2 = null;
        Label_0026: {
            Label_0019: {
                try {
                    s2 = s;
                    if (b != 0) {
                        break Label_0026;
                    }
                    if (s == null) {
                        break Label_0019;
                    }
                    break Label_0019;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    if (s == null) {
                        return null;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            s2 = s;
        }
        final int indexOfExtension = indexOfExtension(s2);
        Label_0046: {
            try {
                if (indexOfExtension != -1) {
                    break Label_0046;
                }
                n.d.a.d.q.f();
            }
            catch (IllegalArgumentException ex3) {
                throw b(ex3);
            }
            return;
        }
        final String pz = q.pz(s, indexOfExtension + 1);
        if (b == 0) {
            return pz;
        }
        return pz;
    }
    
    public static String removeExtension(final String s) {
        final int b = IOCase.b();
        String s2 = null;
        Label_0030: {
            Label_0019: {
                try {
                    s2 = s;
                    if (b != 0) {
                        break Label_0030;
                    }
                    if (s == null) {
                        break Label_0019;
                    }
                    break Label_0019;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    if (s == null) {
                        return null;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            failIfNullBytePresent(s);
            s2 = s;
        }
        final int indexOfExtension = indexOfExtension(s2);
        Label_0048: {
            try {
                if (indexOfExtension != -1) {
                    break Label_0048;
                }
            }
            catch (IllegalArgumentException ex3) {
                throw b(ex3);
            }
            return;
        }
        final String h = q.h(s, 0, indexOfExtension);
        if (b == 0) {
            return h;
        }
        return h;
    }
    
    public static boolean equals(final String s, final String s2) {
        return equals(s, s2, false, IOCase.SENSITIVE);
    }
    
    public static boolean equalsOnSystem(final String s, final String s2) {
        return equals(s, s2, false, IOCase.SYSTEM);
    }
    
    public static boolean equalsNormalized(final String s, final String s2) {
        return equals(s, s2, true, IOCase.SENSITIVE);
    }
    
    public static boolean equalsNormalizedOnSystem(final String s, final String s2) {
        return equals(s, s2, true, IOCase.SYSTEM);
    }
    
    public static boolean equals(String normalize, String normalize2, final boolean b, IOCase ioCase) {
        final int b2 = IOCase.b();
        Label_0076: {
            Label_0060: {
                String s = null;
                Label_0055: {
                    Label_0089: {
                        Label_0042: {
                            try {
                                final String s2;
                                s = (s2 = normalize);
                                if (b2 != 0) {
                                    break Label_0060;
                                }
                                if (s == null) {
                                    break Label_0042;
                                }
                            }
                            catch (IllegalArgumentException ex) {
                                throw b(ex);
                            }
                            String s2;
                            String s3 = s2 = normalize2;
                            while (true) {
                                if (b2 != 0) {
                                    break Label_0055;
                                }
                                try {
                                    if (b2 != 0) {
                                        break Label_0060;
                                    }
                                    if (s3 == null) {
                                        break Label_0042;
                                    }
                                    break Label_0089;
                                }
                                catch (IllegalArgumentException ex2) {
                                    throw b(ex2);
                                }
                                try {
                                    if (s3 != null) {
                                        break Label_0089;
                                    }
                                    s2 = (s3 = normalize);
                                    if (b2 != 0) {
                                        continue;
                                    }
                                }
                                catch (IllegalArgumentException ex3) {
                                    throw b(ex3);
                                }
                                break;
                            }
                        }
                        break Label_0055;
                    }
                    if (b) {
                        normalize = normalize(normalize);
                        normalize2 = normalize(normalize2);
                        Label_0135: {
                            String s4 = null;
                            Label_0121: {
                                try {
                                    s4 = normalize;
                                    if (b2 != 0) {
                                        break Label_0135;
                                    }
                                    final int n = b2;
                                    if (n == 0) {
                                        break Label_0121;
                                    }
                                    break Label_0135;
                                }
                                catch (IllegalArgumentException ex4) {
                                    throw b(ex4);
                                }
                                try {
                                    final int n = b2;
                                    if (n != 0) {
                                        break Label_0135;
                                    }
                                    if (s4 == null) {
                                        break Label_0135;
                                    }
                                }
                                catch (IllegalArgumentException ex5) {
                                    throw b(ex5);
                                }
                            }
                            try {
                                if (s4 == null) {
                                    throw new NullPointerException(a(5147, -29563));
                                }
                            }
                            catch (IllegalArgumentException ex6) {
                                throw b(ex6);
                            }
                        }
                    }
                    IOCase ioCase2 = null;
                    while (true) {
                        Label_0176: {
                            try {
                                ioCase2 = ioCase;
                                if (b2 != 0) {
                                    return ioCase2.checkEquals(normalize, normalize2);
                                }
                                if (ioCase2 != null) {
                                    break Label_0176;
                                }
                            }
                            catch (IllegalArgumentException ex7) {
                                throw b(ex7);
                            }
                            final IOCase sensitive = IOCase.SENSITIVE;
                            final IOCase ioCase3;
                            ioCase = ioCase3;
                        }
                        final IOCase ioCase3 = ioCase;
                        if (b2 != 0) {
                            continue;
                        }
                        break;
                    }
                    return ioCase2.checkEquals(normalize, normalize2);
                }
                if (b2 != 0) {
                    break Label_0076;
                }
                try {
                    if (b2 != 0) {
                        break Label_0076;
                    }
                    if (s != null) {
                        return false;
                    }
                }
                catch (IllegalArgumentException ex8) {
                    throw b(ex8);
                }
            }
            String s2 = normalize2;
            try {
                if (s2 == null) {
                    return true;
                }
            }
            catch (IllegalArgumentException ex9) {
                throw b(ex9);
            }
        }
        return false;
    }
    
    public static boolean isExtension(final String p0, final String p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: iload_2        
        //     6: ifne            30
        //     9: ifnonnull       25
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: iconst_0       
        //    20: ireturn        
        //    21: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    24: athrow         
        //    25: aload_0        
        //    26: invokestatic    org/apache/commons/io/FilenameUtils.failIfNullBytePresent:(Ljava/lang/String;)V
        //    29: aload_1        
        //    30: iload_2        
        //    31: ifne            70
        //    34: ifnull          69
        //    37: goto            44
        //    40: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    43: athrow         
        //    44: aload_1        
        //    45: iload_2        
        //    46: ifne            120
        //    49: goto            56
        //    52: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    55: athrow         
        //    56: invokestatic    q/o/m/s/q.sq:(Ljava/lang/String;)Z
        //    59: goto            66
        //    62: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    65: athrow         
        //    66: ifeq            116
        //    69: aload_0        
        //    70: invokestatic    org/apache/commons/io/FilenameUtils.indexOfExtension:(Ljava/lang/String;)I
        //    73: iload_2        
        //    74: ifne            66
        //    77: iload_2        
        //    78: ifne            111
        //    81: iload_2        
        //    82: ifne            111
        //    85: goto            92
        //    88: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    91: athrow         
        //    92: iconst_m1      
        //    93: if_icmpne       114
        //    96: goto            103
        //    99: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   102: athrow         
        //   103: iconst_1       
        //   104: goto            111
        //   107: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   110: athrow         
        //   111: goto            115
        //   114: iconst_0       
        //   115: ireturn        
        //   116: aload_0        
        //   117: invokestatic    org/apache/commons/io/FilenameUtils.getExtension:(Ljava/lang/String;)Ljava/lang/String;
        //   120: astore_3       
        //   121: aload_3        
        //   122: aload_1        
        //   123: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   126: iload_2        
        //   127: ifne            77
        //   130: ireturn        
        //    StackMapTable: 00 18 FF 00 0F 00 03 07 00 36 07 00 36 01 00 01 07 00 1E 03 41 07 00 1E 03 44 07 00 36 49 07 00 1E 03 47 07 00 1E 43 07 00 36 45 07 00 1E 43 01 02 40 07 00 36 46 01 4A 07 00 1E 43 01 46 07 00 1E 03 43 07 00 1E 43 01 02 40 01 00 43 07 00 36
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  4      12     15     19     Ljava/lang/IllegalArgumentException;
        //  9      21     21     25     Ljava/lang/IllegalArgumentException;
        //  30     37     40     44     Ljava/lang/IllegalArgumentException;
        //  34     49     52     56     Ljava/lang/IllegalArgumentException;
        //  44     59     62     66     Ljava/lang/IllegalArgumentException;
        //  77     85     88     92     Ljava/lang/IllegalArgumentException;
        //  81     96     99     103    Ljava/lang/IllegalArgumentException;
        //  92     104    107    111    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0044:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static boolean isExtension(final String p0, final String[] p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: iload_2        
        //     6: ifeq            26
        //     9: ifnonnull       25
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: iconst_0       
        //    20: ireturn        
        //    21: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    24: athrow         
        //    25: aload_0        
        //    26: iload_2        
        //    27: ifeq            61
        //    30: invokestatic    org/apache/commons/io/FilenameUtils.failIfNullBytePresent:(Ljava/lang/String;)V
        //    33: aload_1        
        //    34: ifnull          60
        //    37: goto            44
        //    40: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    43: athrow         
        //    44: aload_1        
        //    45: arraylength    
        //    46: goto            53
        //    49: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    52: athrow         
        //    53: iload_2        
        //    54: ifeq            72
        //    57: ifne            107
        //    60: aload_0        
        //    61: invokestatic    org/apache/commons/io/FilenameUtils.indexOfExtension:(Ljava/lang/String;)I
        //    64: iload_2        
        //    65: ifeq            53
        //    68: iload_2        
        //    69: ifeq            102
        //    72: iload_2        
        //    73: ifeq            102
        //    76: goto            83
        //    79: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    82: athrow         
        //    83: iconst_m1      
        //    84: if_icmpne       105
        //    87: goto            94
        //    90: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    93: athrow         
        //    94: iconst_1       
        //    95: goto            102
        //    98: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   101: athrow         
        //   102: goto            106
        //   105: iconst_0       
        //   106: ireturn        
        //   107: aload_0        
        //   108: invokestatic    org/apache/commons/io/FilenameUtils.getExtension:(Ljava/lang/String;)Ljava/lang/String;
        //   111: astore_3       
        //   112: aload_1        
        //   113: astore          4
        //   115: aload           4
        //   117: arraylength    
        //   118: istore          5
        //   120: iconst_0       
        //   121: iload_2        
        //   122: ifeq            68
        //   125: istore          6
        //   127: iload           6
        //   129: iload           5
        //   131: if_icmpge       192
        //   134: aload           4
        //   136: iload           6
        //   138: aaload         
        //   139: astore          7
        //   141: iload_2        
        //   142: ifeq            188
        //   145: aload_3        
        //   146: aload           7
        //   148: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   151: iload_2        
        //   152: ifeq            193
        //   155: goto            162
        //   158: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   161: athrow         
        //   162: iload_2        
        //   163: ifeq            184
        //   166: goto            173
        //   169: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   172: athrow         
        //   173: ifeq            185
        //   176: goto            183
        //   179: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   182: athrow         
        //   183: iconst_1       
        //   184: ireturn        
        //   185: iinc            6, 1
        //   188: iload_2        
        //   189: ifne            127
        //   192: iconst_0       
        //   193: ireturn        
        //    StackMapTable: 00 22 FF 00 0F 00 03 07 00 36 07 00 E5 01 00 01 07 00 1E 03 41 07 00 1E 03 40 07 00 36 4D 07 00 1E 03 44 07 00 1E 43 01 06 40 07 00 36 46 01 43 01 46 07 00 1E 43 01 46 07 00 1E 03 43 07 00 1E 43 01 02 40 01 00 FF 00 13 00 07 07 00 36 07 00 E5 01 07 00 36 07 00 E5 01 01 00 00 FF 00 1E 00 08 07 00 36 07 00 E5 01 07 00 36 07 00 E5 01 01 07 00 36 00 01 07 00 1E 43 01 46 07 00 1E 43 01 45 07 00 1E 03 40 01 00 02 FA 00 03 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  4      12     15     19     Ljava/lang/IllegalArgumentException;
        //  9      21     21     25     Ljava/lang/IllegalArgumentException;
        //  26     37     40     44     Ljava/lang/IllegalArgumentException;
        //  30     46     49     53     Ljava/lang/IllegalArgumentException;
        //  68     76     79     83     Ljava/lang/IllegalArgumentException;
        //  72     87     90     94     Ljava/lang/IllegalArgumentException;
        //  83     95     98     102    Ljava/lang/IllegalArgumentException;
        //  141    155    158    162    Ljava/lang/IllegalArgumentException;
        //  145    166    169    173    Ljava/lang/IllegalArgumentException;
        //  162    176    179    183    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0072:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static boolean isExtension(final String p0, final Collection<String> p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: iload_2        
        //     6: ifne            26
        //     9: ifnonnull       25
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: iconst_0       
        //    20: ireturn        
        //    21: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    24: athrow         
        //    25: aload_0        
        //    26: iload_2        
        //    27: ifne            63
        //    30: invokestatic    org/apache/commons/io/FilenameUtils.failIfNullBytePresent:(Ljava/lang/String;)V
        //    33: aload_1        
        //    34: ifnull          62
        //    37: goto            44
        //    40: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    43: athrow         
        //    44: aload_1        
        //    45: invokestatic    q/o/m/s/q.pd:(Ljava/util/Collection;)Z
        //    48: goto            55
        //    51: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    54: athrow         
        //    55: iload_2        
        //    56: ifne            74
        //    59: ifeq            109
        //    62: aload_0        
        //    63: invokestatic    org/apache/commons/io/FilenameUtils.indexOfExtension:(Ljava/lang/String;)I
        //    66: iload_2        
        //    67: ifne            55
        //    70: iload_2        
        //    71: ifne            104
        //    74: iload_2        
        //    75: ifne            104
        //    78: goto            85
        //    81: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    84: athrow         
        //    85: iconst_m1      
        //    86: if_icmpne       107
        //    89: goto            96
        //    92: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    95: athrow         
        //    96: iconst_1       
        //    97: goto            104
        //   100: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   103: athrow         
        //   104: goto            108
        //   107: iconst_0       
        //   108: ireturn        
        //   109: aload_0        
        //   110: invokestatic    org/apache/commons/io/FilenameUtils.getExtension:(Ljava/lang/String;)Ljava/lang/String;
        //   113: iload_2        
        //   114: ifne            63
        //   117: astore_3       
        //   118: aload_1        
        //   119: invokestatic    q/o/m/s/q.ed:(Ljava/util/Collection;)Ljava/util/Iterator;
        //   122: astore          4
        //   124: aload           4
        //   126: invokestatic    q/o/m/s/q.oi:(Ljava/util/Iterator;)Z
        //   129: ifeq            190
        //   132: aload           4
        //   134: invokestatic    q/o/m/s/q.ou:(Ljava/util/Iterator;)Ljava/lang/Object;
        //   137: checkcast       Ljava/lang/String;
        //   140: astore          5
        //   142: aload_3        
        //   143: aload           5
        //   145: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   148: iload_2        
        //   149: ifne            191
        //   152: iload_2        
        //   153: ifne            185
        //   156: goto            163
        //   159: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   162: athrow         
        //   163: iload_2        
        //   164: ifne            185
        //   167: goto            174
        //   170: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   173: athrow         
        //   174: ifeq            186
        //   177: goto            184
        //   180: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   183: athrow         
        //   184: iconst_1       
        //   185: ireturn        
        //   186: iload_2        
        //   187: ifeq            124
        //   190: iconst_0       
        //   191: ireturn        
        //    Signature:
        //  (Ljava/lang/String;Ljava/util/Collection<Ljava/lang/String;>;)Z
        //    StackMapTable: 00 20 FF 00 0F 00 03 07 00 36 07 00 E9 01 00 01 07 00 1E 03 41 07 00 1E 03 40 07 00 36 4D 07 00 1E 03 46 07 00 1E 43 01 06 40 07 00 36 4A 01 46 07 00 1E 43 01 46 07 00 1E 03 43 07 00 1E 43 01 02 40 01 00 FD 00 0E 07 00 36 07 00 F3 FF 00 22 00 06 07 00 36 07 00 E9 01 07 00 36 07 00 F3 07 00 36 00 01 07 00 1E 43 01 46 07 00 1E 43 01 45 07 00 1E 03 40 01 00 FA 00 03 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  4      12     15     19     Ljava/lang/IllegalArgumentException;
        //  9      21     21     25     Ljava/lang/IllegalArgumentException;
        //  26     37     40     44     Ljava/lang/IllegalArgumentException;
        //  30     48     51     55     Ljava/lang/IllegalArgumentException;
        //  70     78     81     85     Ljava/lang/IllegalArgumentException;
        //  74     89     92     96     Ljava/lang/IllegalArgumentException;
        //  85     97     100    104    Ljava/lang/IllegalArgumentException;
        //  142    156    159    163    Ljava/lang/IllegalArgumentException;
        //  152    167    170    174    Ljava/lang/IllegalArgumentException;
        //  163    177    180    184    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0074:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static boolean wildcardMatch(final String s, final String s2) {
        return wildcardMatch(s, s2, IOCase.SENSITIVE);
    }
    
    public static boolean wildcardMatchOnSystem(final String s, final String s2) {
        return wildcardMatch(s, s2, IOCase.SYSTEM);
    }
    
    public static boolean wildcardMatch(final String p0, final String p1, final IOCase p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_3       
        //     4: aload_0        
        //     5: iload_3        
        //     6: ifeq            42
        //     9: ifnonnull       33
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: aload_1        
        //    20: iload_3        
        //    21: ifeq            42
        //    24: ifnonnull       33
        //    27: iconst_1       
        //    28: ireturn        
        //    29: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    32: athrow         
        //    33: aload_0        
        //    34: iload_3        
        //    35: ifeq            20
        //    38: iload_3        
        //    39: ifeq            57
        //    42: iload_3        
        //    43: ifeq            57
        //    46: ifnull          60
        //    49: goto            56
        //    52: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    55: athrow         
        //    56: aload_1        
        //    57: ifnonnull       66
        //    60: iconst_0       
        //    61: ireturn        
        //    62: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    65: athrow         
        //    66: aload_2        
        //    67: iload_3        
        //    68: ifeq            95
        //    71: iload_3        
        //    72: ifeq            95
        //    75: goto            82
        //    78: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    81: athrow         
        //    82: ifnonnull       96
        //    85: goto            92
        //    88: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    91: athrow         
        //    92: getstatic       org/apache/commons/io/IOCase.SENSITIVE:Lorg/apache/commons/io/IOCase;
        //    95: astore_2       
        //    96: aload_1        
        //    97: invokestatic    org/apache/commons/io/FilenameUtils.splitOnTokens:(Ljava/lang/String;)[Ljava/lang/String;
        //   100: astore          4
        //   102: iconst_0       
        //   103: istore          5
        //   105: iconst_0       
        //   106: istore          6
        //   108: iconst_0       
        //   109: istore          7
        //   111: new             Ljava/util/Stack;
        //   114: dup            
        //   115: invokespecial   java/util/Stack.<init>:()V
        //   118: astore          8
        //   120: aload           8
        //   122: invokestatic    q/o/m/s/q.pb:(Ljava/util/Stack;)I
        //   125: ifle            153
        //   128: aload           8
        //   130: invokestatic    q/o/m/s/q.pw:(Ljava/util/Stack;)Ljava/lang/Object;
        //   133: checkcast       [I
        //   136: astore          9
        //   138: aload           9
        //   140: iconst_0       
        //   141: iaload         
        //   142: istore          7
        //   144: aload           9
        //   146: iconst_1       
        //   147: iaload         
        //   148: istore          6
        //   150: iconst_1       
        //   151: istore          5
        //   153: iload           7
        //   155: aload           4
        //   157: arraylength    
        //   158: if_icmpge       503
        //   161: aload           4
        //   163: iload           7
        //   165: aaload         
        //   166: invokestatic    n/d/a/d/q.vj:()Ljava/lang/String;
        //   169: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   172: iload_3        
        //   173: ifeq            505
        //   176: iload_3        
        //   177: ifeq            267
        //   180: goto            187
        //   183: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   186: athrow         
        //   187: ifeq            245
        //   190: goto            197
        //   193: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   196: athrow         
        //   197: iinc            6, 1
        //   200: iload           6
        //   202: goto            209
        //   205: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   208: athrow         
        //   209: iload_3        
        //   210: ifeq            239
        //   213: aload_0        
        //   214: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //   217: if_icmple       231
        //   220: iload_3        
        //   221: ifne            503
        //   224: goto            231
        //   227: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   230: athrow         
        //   231: iconst_0       
        //   232: goto            239
        //   235: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   238: athrow         
        //   239: istore          5
        //   241: iload_3        
        //   242: ifne            492
        //   245: aload           4
        //   247: iload           7
        //   249: aaload         
        //   250: invokestatic    n/d/a/d/q.vg:()Ljava/lang/String;
        //   253: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   256: iload_3        
        //   257: ifeq            209
        //   260: goto            267
        //   263: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   266: athrow         
        //   267: iload_3        
        //   268: ifeq            321
        //   271: ifeq            315
        //   274: goto            281
        //   277: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   280: athrow         
        //   281: iconst_1       
        //   282: istore          5
        //   284: iload_3        
        //   285: ifeq            499
        //   288: iload           7
        //   290: goto            297
        //   293: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   296: athrow         
        //   297: aload           4
        //   299: arraylength    
        //   300: iconst_1       
        //   301: isub           
        //   302: if_icmpne       492
        //   305: aload_0        
        //   306: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //   309: istore          6
        //   311: iload_3        
        //   312: ifne            492
        //   315: iload           5
        //   317: iload_3        
        //   318: ifeq            297
        //   321: iload_3        
        //   322: ifeq            451
        //   325: ifeq            428
        //   328: goto            335
        //   331: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   334: athrow         
        //   335: aload_2        
        //   336: aload_0        
        //   337: iload           6
        //   339: aload           4
        //   341: iload           7
        //   343: aaload         
        //   344: invokevirtual   org/apache/commons/io/IOCase.checkIndexOf:(Ljava/lang/String;ILjava/lang/String;)I
        //   347: istore          6
        //   349: iload           6
        //   351: iload_3        
        //   352: ifeq            391
        //   355: iconst_m1      
        //   356: if_icmpne       370
        //   359: iload_3        
        //   360: ifne            503
        //   363: goto            370
        //   366: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   369: athrow         
        //   370: aload_2        
        //   371: aload_0        
        //   372: iload           6
        //   374: iconst_1       
        //   375: iadd           
        //   376: aload           4
        //   378: iload           7
        //   380: aaload         
        //   381: invokevirtual   org/apache/commons/io/IOCase.checkIndexOf:(Ljava/lang/String;ILjava/lang/String;)I
        //   384: goto            391
        //   387: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   390: athrow         
        //   391: istore          9
        //   393: iload           9
        //   395: iflt            424
        //   398: aload           8
        //   400: iconst_2       
        //   401: newarray        I
        //   403: dup            
        //   404: iconst_0       
        //   405: iload           7
        //   407: iastore        
        //   408: dup            
        //   409: iconst_1       
        //   410: iload           9
        //   412: iastore        
        //   413: invokestatic    q/o/m/s/q.pa:(Ljava/util/Stack;Ljava/lang/Object;)Ljava/lang/Object;
        //   416: pop            
        //   417: goto            424
        //   420: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   423: athrow         
        //   424: iload_3        
        //   425: ifne            476
        //   428: aload_2        
        //   429: aload_0        
        //   430: iload           6
        //   432: aload           4
        //   434: iload           7
        //   436: aaload         
        //   437: invokevirtual   org/apache/commons/io/IOCase.checkRegionMatches:(Ljava/lang/String;ILjava/lang/String;)Z
        //   440: iload_3        
        //   441: ifeq            351
        //   444: goto            451
        //   447: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   450: athrow         
        //   451: iload_3        
        //   452: ifeq            490
        //   455: ifne            476
        //   458: goto            465
        //   461: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   464: athrow         
        //   465: iload_3        
        //   466: ifne            503
        //   469: goto            476
        //   472: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   475: athrow         
        //   476: iload           6
        //   478: aload           4
        //   480: iload           7
        //   482: aaload         
        //   483: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //   486: iadd           
        //   487: istore          6
        //   489: iconst_0       
        //   490: istore          5
        //   492: iinc            7, 1
        //   495: iload_3        
        //   496: ifeq            311
        //   499: iload_3        
        //   500: ifne            153
        //   503: iload           7
        //   505: iload_3        
        //   506: ifeq            564
        //   509: aload           4
        //   511: arraylength    
        //   512: if_icmpne       551
        //   515: goto            522
        //   518: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   521: athrow         
        //   522: iload           6
        //   524: goto            531
        //   527: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   530: athrow         
        //   531: iload_3        
        //   532: ifeq            564
        //   535: aload_0        
        //   536: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //   539: if_icmpne       551
        //   542: iconst_1       
        //   543: goto            550
        //   546: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   549: athrow         
        //   550: ireturn        
        //   551: aload           8
        //   553: invokestatic    q/o/m/s/q.pb:(Ljava/util/Stack;)I
        //   556: iload_3        
        //   557: ifeq            531
        //   560: iload_3        
        //   561: ifeq            550
        //   564: ifgt            120
        //   567: iconst_0       
        //   568: iload_3        
        //   569: ifeq            155
        //   572: ireturn        
        //    StackMapTable: 00 46 FF 00 0F 00 04 07 00 36 07 00 36 07 00 27 01 00 01 07 00 1E 03 40 07 00 36 48 07 00 1E 03 48 07 00 36 49 07 00 1E 03 40 07 00 36 02 41 07 00 1E 03 4B 07 00 1E 43 07 00 27 45 07 00 1E 03 42 07 00 27 00 FF 00 17 00 09 07 00 36 07 00 36 07 00 27 01 07 00 E5 01 01 01 07 01 06 00 00 20 41 01 5B 07 00 1E 43 01 45 07 00 1E 03 47 07 00 1E 43 01 51 07 00 1E 03 43 07 00 1E 43 01 05 51 07 00 1E 43 01 49 07 00 1E 03 4B 07 00 1E 43 01 0D 03 45 01 49 07 00 1E 03 4F 01 4E 07 00 1E 03 50 07 00 1E 43 01 FF 00 1C 00 0A 07 00 36 07 00 36 07 00 27 01 07 00 E5 01 01 01 07 01 06 01 00 01 07 00 1E 03 FA 00 03 52 07 00 1E 43 01 49 07 00 1E 03 46 07 00 1E 03 4D 01 01 06 03 41 01 4C 07 00 1E 03 44 07 00 1E 43 01 4E 07 00 1E 43 01 00 4C 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  4      12     15     19     Ljava/lang/IllegalArgumentException;
        //  24     29     29     33     Ljava/lang/IllegalArgumentException;
        //  42     49     52     56     Ljava/lang/IllegalArgumentException;
        //  57     62     62     66     Ljava/lang/IllegalArgumentException;
        //  66     75     78     82     Ljava/lang/IllegalArgumentException;
        //  71     85     88     92     Ljava/lang/IllegalArgumentException;
        //  161    180    183    187    Ljava/lang/IllegalArgumentException;
        //  176    190    193    197    Ljava/lang/IllegalArgumentException;
        //  187    202    205    209    Ljava/lang/IllegalArgumentException;
        //  213    224    227    231    Ljava/lang/IllegalArgumentException;
        //  220    232    235    239    Ljava/lang/IllegalArgumentException;
        //  241    260    263    267    Ljava/lang/IllegalArgumentException;
        //  267    274    277    281    Ljava/lang/IllegalArgumentException;
        //  284    290    293    297    Ljava/lang/IllegalArgumentException;
        //  321    328    331    335    Ljava/lang/IllegalArgumentException;
        //  355    363    366    370    Ljava/lang/IllegalArgumentException;
        //  359    384    387    391    Ljava/lang/IllegalArgumentException;
        //  393    417    420    424    Ljava/lang/IllegalArgumentException;
        //  424    444    447    451    Ljava/lang/IllegalArgumentException;
        //  451    458    461    465    Ljava/lang/IllegalArgumentException;
        //  455    469    472    476    Ljava/lang/IllegalArgumentException;
        //  505    515    518    522    Ljava/lang/IllegalArgumentException;
        //  509    524    527    531    Ljava/lang/IllegalArgumentException;
        //  535    543    546    550    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0187:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static String[] splitOnTokens(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: iload_1        
        //     6: ifne            63
        //     9: bipush          63
        //    11: invokestatic    q/o/m/s/q.eu:(Ljava/lang/String;I)I
        //    14: iconst_m1      
        //    15: if_icmpne       62
        //    18: goto            25
        //    21: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    24: athrow         
        //    25: aload_0        
        //    26: iload_1        
        //    27: ifne            63
        //    30: goto            37
        //    33: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    36: athrow         
        //    37: bipush          42
        //    39: invokestatic    q/o/m/s/q.eu:(Ljava/lang/String;I)I
        //    42: goto            49
        //    45: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    48: athrow         
        //    49: iconst_m1      
        //    50: if_icmpne       62
        //    53: iconst_1       
        //    54: anewarray       Ljava/lang/String;
        //    57: dup            
        //    58: iconst_0       
        //    59: aload_0        
        //    60: aastore        
        //    61: areturn        
        //    62: aload_0        
        //    63: invokestatic    q/o/m/s/q.g:(Ljava/lang/String;)[C
        //    66: astore_2       
        //    67: new             Ljava/util/ArrayList;
        //    70: dup            
        //    71: invokespecial   java/util/ArrayList.<init>:()V
        //    74: astore_3       
        //    75: new             Ljava/lang/StringBuilder;
        //    78: dup            
        //    79: invokespecial   java/lang/StringBuilder.<init>:()V
        //    82: astore          4
        //    84: iconst_0       
        //    85: istore          5
        //    87: aload_2        
        //    88: astore          6
        //    90: aload           6
        //    92: arraylength    
        //    93: istore          7
        //    95: iconst_0       
        //    96: iload_1        
        //    97: ifne            49
        //   100: iload_1        
        //   101: ifne            54
        //   104: istore          8
        //   106: iload           8
        //   108: iload           7
        //   110: if_icmpge       329
        //   113: aload           6
        //   115: iload           8
        //   117: caload         
        //   118: istore          9
        //   120: iload           9
        //   122: iload_1        
        //   123: ifne            334
        //   126: iload_1        
        //   127: ifne            183
        //   130: goto            137
        //   133: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   136: athrow         
        //   137: bipush          63
        //   139: if_icmpeq       167
        //   142: goto            149
        //   145: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   148: athrow         
        //   149: iload           9
        //   151: goto            158
        //   154: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   157: athrow         
        //   158: iload_1        
        //   159: ifne            183
        //   162: bipush          42
        //   164: if_icmpne       302
        //   167: aload           4
        //   169: goto            176
        //   172: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   175: athrow         
        //   176: invokestatic    q/o/m/s/q.kb:(Ljava/lang/StringBuilder;)I
        //   179: iload_1        
        //   180: ifne            158
        //   183: iload_1        
        //   184: ifne            226
        //   187: ifeq            220
        //   190: goto            197
        //   193: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   196: athrow         
        //   197: aload_3        
        //   198: aload           4
        //   200: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   203: invokestatic    q/o/m/s/q.ob:(Ljava/util/ArrayList;Ljava/lang/Object;)Z
        //   206: goto            213
        //   209: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   212: athrow         
        //   213: pop            
        //   214: aload           4
        //   216: iconst_0       
        //   217: invokestatic    q/o/m/s/q.pl:(Ljava/lang/StringBuilder;I)V
        //   220: iload           9
        //   222: iload_1        
        //   223: ifne            213
        //   226: bipush          63
        //   228: iload_1        
        //   229: ifne            280
        //   232: if_icmpne       261
        //   235: goto            242
        //   238: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   241: athrow         
        //   242: aload_3        
        //   243: invokestatic    n/d/a/d/q.vj:()Ljava/lang/String;
        //   246: invokestatic    q/o/m/s/q.ob:(Ljava/util/ArrayList;Ljava/lang/Object;)Z
        //   249: goto            256
        //   252: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   255: athrow         
        //   256: pop            
        //   257: iload_1        
        //   258: ifeq            314
        //   261: iload           5
        //   263: iload_1        
        //   264: ifne            256
        //   267: iload_1        
        //   268: ifne            316
        //   271: bipush          42
        //   273: goto            280
        //   276: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   279: athrow         
        //   280: if_icmpeq       314
        //   283: aload_3        
        //   284: invokestatic    n/d/a/d/q.vg:()Ljava/lang/String;
        //   287: invokestatic    q/o/m/s/q.ob:(Ljava/util/ArrayList;Ljava/lang/Object;)Z
        //   290: pop            
        //   291: goto            298
        //   294: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   297: athrow         
        //   298: iload_1        
        //   299: ifeq            314
        //   302: aload           4
        //   304: iload           9
        //   306: invokestatic    q/o/m/s/q.sk:(Ljava/lang/StringBuilder;C)Ljava/lang/StringBuilder;
        //   309: iload_1        
        //   310: ifne            176
        //   313: pop            
        //   314: iload           9
        //   316: istore          5
        //   318: iinc            8, 1
        //   321: iload_1        
        //   322: ifne            298
        //   325: iload_1        
        //   326: ifeq            106
        //   329: aload           4
        //   331: invokestatic    q/o/m/s/q.kb:(Ljava/lang/StringBuilder;)I
        //   334: iload_1        
        //   335: ifne            357
        //   338: ifeq            358
        //   341: goto            348
        //   344: invokestatic    org/apache/commons/io/FilenameUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   347: athrow         
        //   348: aload_3        
        //   349: aload           4
        //   351: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   354: invokestatic    q/o/m/s/q.ob:(Ljava/util/ArrayList;Ljava/lang/Object;)Z
        //   357: pop            
        //   358: aload_3        
        //   359: iload_1        
        //   360: ifne            349
        //   363: aload_3        
        //   364: invokestatic    q/o/m/s/q.td:(Ljava/util/ArrayList;)I
        //   367: anewarray       Ljava/lang/String;
        //   370: invokestatic    q/o/m/s/q.pi:(Ljava/util/ArrayList;[Ljava/lang/Object;)[Ljava/lang/Object;
        //   373: checkcast       [Ljava/lang/String;
        //   376: areturn        
        //    StackMapTable: 00 2D FF 00 15 00 02 07 00 36 01 00 01 07 00 1E 03 47 07 00 1E 43 07 00 36 47 07 00 1E 43 01 44 01 07 40 07 00 36 FF 00 2A 00 09 07 00 36 01 07 00 4A 07 01 29 07 00 65 01 07 00 4A 01 01 00 00 FF 00 1A 00 0A 07 00 36 01 07 00 4A 07 01 29 07 00 65 01 07 00 4A 01 01 01 00 01 07 00 1E 43 01 47 07 00 1E 03 44 07 00 1E 43 01 08 44 07 00 1E 43 07 00 65 46 01 49 07 00 1E 03 4B 07 00 1E 43 01 06 45 01 4B 07 00 1E 03 49 07 00 1E 43 01 04 4E 07 00 1E FF 00 03 00 0A 07 00 36 01 07 00 4A 07 01 29 07 00 65 01 07 00 4A 01 01 01 00 02 01 01 4D 07 00 1E 03 03 0B 41 01 FA 00 0C 44 01 49 07 00 1E 03 40 07 01 29 47 01 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  4      18     21     25     Ljava/lang/IllegalArgumentException;
        //  9      30     33     37     Ljava/lang/IllegalArgumentException;
        //  25     42     45     49     Ljava/lang/IllegalArgumentException;
        //  120    130    133    137    Ljava/lang/IllegalArgumentException;
        //  126    142    145    149    Ljava/lang/IllegalArgumentException;
        //  137    151    154    158    Ljava/lang/IllegalArgumentException;
        //  162    169    172    176    Ljava/lang/IllegalArgumentException;
        //  183    190    193    197    Ljava/lang/IllegalArgumentException;
        //  187    206    209    213    Ljava/lang/IllegalArgumentException;
        //  226    235    238    242    Ljava/lang/IllegalArgumentException;
        //  232    249    252    256    Ljava/lang/IllegalArgumentException;
        //  267    273    276    280    Ljava/lang/IllegalArgumentException;
        //  280    291    294    298    Ljava/lang/IllegalArgumentException;
        //  334    341    344    348    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0025:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        final String[] a2 = new String[3];
        int n = 0;
        final String vz;
        final int q = q.o.m.s.q.q(vz = n.d.a.d.q.vz());
        int j = 132;
        int n2 = -1;
        Label_0024: {
            break Label_0024;
            do {
                j = q.o.m.s.q.j(vz, n2);
                int n5;
                int n4;
                final int n3 = n4 = (n5 = 17);
                ++n2;
                final String s = vz;
                final int n6 = n2;
                final char[] g = q.o.m.s.q.g(q.o.m.s.q.h(s, n6, n6 + j));
                final int length = g.length;
                int n7 = 0;
                while (true) {
                    Label_0200: {
                        if (length > 1) {
                            break Label_0200;
                        }
                        n5 = (n4 = n7);
                        do {
                            final char c = g[n4];
                            int n8 = 0;
                            switch (n7 % 7) {
                                case 0: {
                                    n8 = 23;
                                    break;
                                }
                                case 1: {
                                    n8 = 19;
                                    break;
                                }
                                case 2: {
                                    n8 = 115;
                                    break;
                                }
                                case 3: {
                                    n8 = 105;
                                    break;
                                }
                                case 4: {
                                    n8 = 65;
                                    break;
                                }
                                case 5: {
                                    n8 = 43;
                                    break;
                                }
                                default: {
                                    n8 = 75;
                                    break;
                                }
                            }
                            g[n5] = (char)(c ^ (n3 ^ n8));
                            ++n7;
                        } while (n3 == 0);
                    }
                    if (length > n7) {
                        continue;
                    }
                    break;
                }
                a2[n++] = q.o.m.s.q.z(new String(g));
            } while ((n2 += j) < q);
        }
        a = a2;
        b = new String[3];
        try {
            EXTENSION_SEPARATOR_STR = q.o.m.s.q.pu('.');
            SYSTEM_SEPARATOR = x.dn.g.b.q.n();
            if (isSystemWindows()) {
                OTHER_SEPARATOR = '/';
                return;
            }
        }
        catch (IllegalArgumentException ex) {
            throw b(ex);
        }
        OTHER_SEPARATOR = '\\';
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0x141A) & 0xFFFF;
        if (FilenameUtils.b[n3] == null) {
            final char[] g = q.g(FilenameUtils.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 232;
                    break;
                }
                case 1: {
                    n4 = 53;
                    break;
                }
                case 2: {
                    n4 = 161;
                    break;
                }
                case 3: {
                    n4 = 163;
                    break;
                }
                case 4: {
                    n4 = 254;
                    break;
                }
                case 5: {
                    n4 = 82;
                    break;
                }
                case 6: {
                    n4 = 91;
                    break;
                }
                case 7: {
                    n4 = 34;
                    break;
                }
                case 8: {
                    n4 = 84;
                    break;
                }
                case 9: {
                    n4 = 180;
                    break;
                }
                case 10: {
                    n4 = 55;
                    break;
                }
                case 11: {
                    n4 = 141;
                    break;
                }
                case 12: {
                    n4 = 201;
                    break;
                }
                case 13: {
                    n4 = 95;
                    break;
                }
                case 14: {
                    n4 = 121;
                    break;
                }
                case 15: {
                    n4 = 177;
                    break;
                }
                case 16: {
                    n4 = 147;
                    break;
                }
                case 17: {
                    n4 = 204;
                    break;
                }
                case 18: {
                    n4 = 237;
                    break;
                }
                case 19: {
                    n4 = 183;
                    break;
                }
                case 20: {
                    n4 = 195;
                    break;
                }
                case 21: {
                    n4 = 42;
                    break;
                }
                case 22: {
                    n4 = 196;
                    break;
                }
                case 23: {
                    n4 = 241;
                    break;
                }
                case 24: {
                    n4 = 152;
                    break;
                }
                case 25: {
                    n4 = 125;
                    break;
                }
                case 26: {
                    n4 = 194;
                    break;
                }
                case 27: {
                    n4 = 215;
                    break;
                }
                case 28: {
                    n4 = 170;
                    break;
                }
                case 29: {
                    n4 = 162;
                    break;
                }
                case 30: {
                    n4 = 155;
                    break;
                }
                case 31: {
                    n4 = 157;
                    break;
                }
                case 32: {
                    n4 = 81;
                    break;
                }
                case 33: {
                    n4 = 119;
                    break;
                }
                case 34: {
                    n4 = 135;
                    break;
                }
                case 35: {
                    n4 = 132;
                    break;
                }
                case 36: {
                    n4 = 76;
                    break;
                }
                case 37: {
                    n4 = 27;
                    break;
                }
                case 38: {
                    n4 = 123;
                    break;
                }
                case 39: {
                    n4 = 87;
                    break;
                }
                case 40: {
                    n4 = 97;
                    break;
                }
                case 41: {
                    n4 = 108;
                    break;
                }
                case 42: {
                    n4 = 37;
                    break;
                }
                case 43: {
                    n4 = 240;
                    break;
                }
                case 44: {
                    n4 = 94;
                    break;
                }
                case 45: {
                    n4 = 56;
                    break;
                }
                case 46: {
                    n4 = 185;
                    break;
                }
                case 47: {
                    n4 = 199;
                    break;
                }
                case 48: {
                    n4 = 102;
                    break;
                }
                case 49: {
                    n4 = 186;
                    break;
                }
                case 50: {
                    n4 = 4;
                    break;
                }
                case 51: {
                    n4 = 54;
                    break;
                }
                case 52: {
                    n4 = 101;
                    break;
                }
                case 53: {
                    n4 = 107;
                    break;
                }
                case 54: {
                    n4 = 165;
                    break;
                }
                case 55: {
                    n4 = 229;
                    break;
                }
                case 56: {
                    n4 = 64;
                    break;
                }
                case 57: {
                    n4 = 129;
                    break;
                }
                case 58: {
                    n4 = 89;
                    break;
                }
                case 59: {
                    n4 = 189;
                    break;
                }
                case 60: {
                    n4 = 187;
                    break;
                }
                case 61: {
                    n4 = 120;
                    break;
                }
                case 62: {
                    n4 = 227;
                    break;
                }
                case 63: {
                    n4 = 48;
                    break;
                }
                case 64: {
                    n4 = 154;
                    break;
                }
                case 65: {
                    n4 = 68;
                    break;
                }
                case 66: {
                    n4 = 71;
                    break;
                }
                case 67: {
                    n4 = 251;
                    break;
                }
                case 68: {
                    n4 = 31;
                    break;
                }
                case 69: {
                    n4 = 65;
                    break;
                }
                case 70: {
                    n4 = 85;
                    break;
                }
                case 71: {
                    n4 = 137;
                    break;
                }
                case 72: {
                    n4 = 134;
                    break;
                }
                case 73: {
                    n4 = 179;
                    break;
                }
                case 74: {
                    n4 = 113;
                    break;
                }
                case 75: {
                    n4 = 138;
                    break;
                }
                case 76: {
                    n4 = 116;
                    break;
                }
                case 77: {
                    n4 = 70;
                    break;
                }
                case 78: {
                    n4 = 228;
                    break;
                }
                case 79: {
                    n4 = 216;
                    break;
                }
                case 80: {
                    n4 = 128;
                    break;
                }
                case 81: {
                    n4 = 50;
                    break;
                }
                case 82: {
                    n4 = 127;
                    break;
                }
                case 83: {
                    n4 = 193;
                    break;
                }
                case 84: {
                    n4 = 38;
                    break;
                }
                case 85: {
                    n4 = 114;
                    break;
                }
                case 86: {
                    n4 = 10;
                    break;
                }
                case 87: {
                    n4 = 182;
                    break;
                }
                case 88: {
                    n4 = 39;
                    break;
                }
                case 89: {
                    n4 = 190;
                    break;
                }
                case 90: {
                    n4 = 77;
                    break;
                }
                case 91: {
                    n4 = 75;
                    break;
                }
                case 92: {
                    n4 = 213;
                    break;
                }
                case 93: {
                    n4 = 236;
                    break;
                }
                case 94: {
                    n4 = 235;
                    break;
                }
                case 95: {
                    n4 = 198;
                    break;
                }
                case 96: {
                    n4 = 35;
                    break;
                }
                case 97: {
                    n4 = 62;
                    break;
                }
                case 98: {
                    n4 = 16;
                    break;
                }
                case 99: {
                    n4 = 202;
                    break;
                }
                case 100: {
                    n4 = 149;
                    break;
                }
                case 101: {
                    n4 = 30;
                    break;
                }
                case 102: {
                    n4 = 96;
                    break;
                }
                case 103: {
                    n4 = 6;
                    break;
                }
                case 104: {
                    n4 = 44;
                    break;
                }
                case 105: {
                    n4 = 115;
                    break;
                }
                case 106: {
                    n4 = 22;
                    break;
                }
                case 107: {
                    n4 = 83;
                    break;
                }
                case 108: {
                    n4 = 239;
                    break;
                }
                case 109: {
                    n4 = 231;
                    break;
                }
                case 110: {
                    n4 = 1;
                    break;
                }
                case 111: {
                    n4 = 47;
                    break;
                }
                case 112: {
                    n4 = 248;
                    break;
                }
                case 113: {
                    n4 = 11;
                    break;
                }
                case 114: {
                    n4 = 218;
                    break;
                }
                case 115: {
                    n4 = 233;
                    break;
                }
                case 116: {
                    n4 = 197;
                    break;
                }
                case 117: {
                    n4 = 146;
                    break;
                }
                case 118: {
                    n4 = 133;
                    break;
                }
                case 119: {
                    n4 = 206;
                    break;
                }
                case 120: {
                    n4 = 19;
                    break;
                }
                case 121: {
                    n4 = 200;
                    break;
                }
                case 122: {
                    n4 = 130;
                    break;
                }
                case 123: {
                    n4 = 166;
                    break;
                }
                case 124: {
                    n4 = 66;
                    break;
                }
                case 125: {
                    n4 = 243;
                    break;
                }
                case 126: {
                    n4 = 15;
                    break;
                }
                case 127: {
                    n4 = 246;
                    break;
                }
                case 128: {
                    n4 = 104;
                    break;
                }
                case 129: {
                    n4 = 5;
                    break;
                }
                case 130: {
                    n4 = 203;
                    break;
                }
                case 131: {
                    n4 = 51;
                    break;
                }
                case 132: {
                    n4 = 14;
                    break;
                }
                case 133: {
                    n4 = 223;
                    break;
                }
                case 134: {
                    n4 = 191;
                    break;
                }
                case 135: {
                    n4 = 105;
                    break;
                }
                case 136: {
                    n4 = 92;
                    break;
                }
                case 137: {
                    n4 = 29;
                    break;
                }
                case 138: {
                    n4 = 32;
                    break;
                }
                case 139: {
                    n4 = 255;
                    break;
                }
                case 140: {
                    n4 = 109;
                    break;
                }
                case 141: {
                    n4 = 148;
                    break;
                }
                case 142: {
                    n4 = 144;
                    break;
                }
                case 143: {
                    n4 = 145;
                    break;
                }
                case 144: {
                    n4 = 188;
                    break;
                }
                case 145: {
                    n4 = 111;
                    break;
                }
                case 146: {
                    n4 = 151;
                    break;
                }
                case 147: {
                    n4 = 210;
                    break;
                }
                case 148: {
                    n4 = 90;
                    break;
                }
                case 149: {
                    n4 = 252;
                    break;
                }
                case 150: {
                    n4 = 173;
                    break;
                }
                case 151: {
                    n4 = 211;
                    break;
                }
                case 152: {
                    n4 = 122;
                    break;
                }
                case 153: {
                    n4 = 36;
                    break;
                }
                case 154: {
                    n4 = 40;
                    break;
                }
                case 155: {
                    n4 = 28;
                    break;
                }
                case 156: {
                    n4 = 23;
                    break;
                }
                case 157: {
                    n4 = 139;
                    break;
                }
                case 158: {
                    n4 = 41;
                    break;
                }
                case 159: {
                    n4 = 43;
                    break;
                }
                case 160: {
                    n4 = 13;
                    break;
                }
                case 161: {
                    n4 = 244;
                    break;
                }
                case 162: {
                    n4 = 12;
                    break;
                }
                case 163: {
                    n4 = 88;
                    break;
                }
                case 164: {
                    n4 = 225;
                    break;
                }
                case 165: {
                    n4 = 126;
                    break;
                }
                case 166: {
                    n4 = 106;
                    break;
                }
                case 167: {
                    n4 = 18;
                    break;
                }
                case 168: {
                    n4 = 67;
                    break;
                }
                case 169: {
                    n4 = 153;
                    break;
                }
                case 170: {
                    n4 = 131;
                    break;
                }
                case 171: {
                    n4 = 175;
                    break;
                }
                case 172: {
                    n4 = 192;
                    break;
                }
                case 173: {
                    n4 = 124;
                    break;
                }
                case 174: {
                    n4 = 117;
                    break;
                }
                case 175: {
                    n4 = 78;
                    break;
                }
                case 176: {
                    n4 = 160;
                    break;
                }
                case 177: {
                    n4 = 178;
                    break;
                }
                case 178: {
                    n4 = 181;
                    break;
                }
                case 179: {
                    n4 = 69;
                    break;
                }
                case 180: {
                    n4 = 219;
                    break;
                }
                case 181: {
                    n4 = 221;
                    break;
                }
                case 182: {
                    n4 = 247;
                    break;
                }
                case 183: {
                    n4 = 112;
                    break;
                }
                case 184: {
                    n4 = 118;
                    break;
                }
                case 185: {
                    n4 = 150;
                    break;
                }
                case 186: {
                    n4 = 164;
                    break;
                }
                case 187: {
                    n4 = 222;
                    break;
                }
                case 188: {
                    n4 = 57;
                    break;
                }
                case 189: {
                    n4 = 224;
                    break;
                }
                case 190: {
                    n4 = 174;
                    break;
                }
                case 191: {
                    n4 = 158;
                    break;
                }
                case 192: {
                    n4 = 136;
                    break;
                }
                case 193: {
                    n4 = 103;
                    break;
                }
                case 194: {
                    n4 = 46;
                    break;
                }
                case 195: {
                    n4 = 250;
                    break;
                }
                case 196: {
                    n4 = 60;
                    break;
                }
                case 197: {
                    n4 = 74;
                    break;
                }
                case 198: {
                    n4 = 209;
                    break;
                }
                case 199: {
                    n4 = 207;
                    break;
                }
                case 200: {
                    n4 = 0;
                    break;
                }
                case 201: {
                    n4 = 230;
                    break;
                }
                case 202: {
                    n4 = 61;
                    break;
                }
                case 203: {
                    n4 = 7;
                    break;
                }
                case 204: {
                    n4 = 59;
                    break;
                }
                case 205: {
                    n4 = 156;
                    break;
                }
                case 206: {
                    n4 = 253;
                    break;
                }
                case 207: {
                    n4 = 21;
                    break;
                }
                case 208: {
                    n4 = 245;
                    break;
                }
                case 209: {
                    n4 = 58;
                    break;
                }
                case 210: {
                    n4 = 8;
                    break;
                }
                case 211: {
                    n4 = 98;
                    break;
                }
                case 212: {
                    n4 = 212;
                    break;
                }
                case 213: {
                    n4 = 24;
                    break;
                }
                case 214: {
                    n4 = 142;
                    break;
                }
                case 215: {
                    n4 = 176;
                    break;
                }
                case 216: {
                    n4 = 100;
                    break;
                }
                case 217: {
                    n4 = 238;
                    break;
                }
                case 218: {
                    n4 = 217;
                    break;
                }
                case 219: {
                    n4 = 168;
                    break;
                }
                case 220: {
                    n4 = 220;
                    break;
                }
                case 221: {
                    n4 = 140;
                    break;
                }
                case 222: {
                    n4 = 234;
                    break;
                }
                case 223: {
                    n4 = 9;
                    break;
                }
                case 224: {
                    n4 = 20;
                    break;
                }
                case 225: {
                    n4 = 249;
                    break;
                }
                case 226: {
                    n4 = 86;
                    break;
                }
                case 227: {
                    n4 = 45;
                    break;
                }
                case 228: {
                    n4 = 93;
                    break;
                }
                case 229: {
                    n4 = 205;
                    break;
                }
                case 230: {
                    n4 = 172;
                    break;
                }
                case 231: {
                    n4 = 159;
                    break;
                }
                case 232: {
                    n4 = 143;
                    break;
                }
                case 233: {
                    n4 = 73;
                    break;
                }
                case 234: {
                    n4 = 214;
                    break;
                }
                case 235: {
                    n4 = 25;
                    break;
                }
                case 236: {
                    n4 = 184;
                    break;
                }
                case 237: {
                    n4 = 17;
                    break;
                }
                case 238: {
                    n4 = 52;
                    break;
                }
                case 239: {
                    n4 = 2;
                    break;
                }
                case 240: {
                    n4 = 242;
                    break;
                }
                case 241: {
                    n4 = 171;
                    break;
                }
                case 242: {
                    n4 = 167;
                    break;
                }
                case 243: {
                    n4 = 72;
                    break;
                }
                case 244: {
                    n4 = 110;
                    break;
                }
                case 245: {
                    n4 = 80;
                    break;
                }
                case 246: {
                    n4 = 33;
                    break;
                }
                case 247: {
                    n4 = 99;
                    break;
                }
                case 248: {
                    n4 = 208;
                    break;
                }
                case 249: {
                    n4 = 226;
                    break;
                }
                case 250: {
                    n4 = 3;
                    break;
                }
                case 251: {
                    n4 = 26;
                    break;
                }
                case 252: {
                    n4 = 63;
                    break;
                }
                case 253: {
                    n4 = 79;
                    break;
                }
                case 254: {
                    n4 = 49;
                    break;
                }
                default: {
                    n4 = 169;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            FilenameUtils.b[n3] = q.z(new String(g));
        }
        return FilenameUtils.b[n3];
    }
}
