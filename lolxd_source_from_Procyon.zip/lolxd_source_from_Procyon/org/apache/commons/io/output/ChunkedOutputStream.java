// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.output;

import java.io.IOException;
import q.o.m.s.q;
import java.io.OutputStream;
import java.io.FilterOutputStream;

public class ChunkedOutputStream extends FilterOutputStream
{
    private static final int DEFAULT_CHUNK_SIZE = 4096;
    private final int chunkSize;
    
    public ChunkedOutputStream(final OutputStream out, final int chunkSize) {
        final int b = ProxyOutputStream.b();
        super(out);
        final int n = b;
        Label_0024: {
            try {
                if (n == 0) {
                    return;
                }
                final int n2 = chunkSize;
                if (n2 <= 0) {
                    break Label_0024;
                }
                break Label_0024;
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            try {
                final int n2 = chunkSize;
                if (n2 <= 0) {
                    throw new IllegalArgumentException();
                }
            }
            catch (IllegalArgumentException ex2) {
                throw b(ex2);
            }
        }
        this.chunkSize = chunkSize;
    }
    
    public ChunkedOutputStream(final OutputStream outputStream) {
        this(outputStream, 4096);
    }
    
    @Override
    public void write(final byte[] array, final int n, final int n2) throws IOException {
        final int a = ProxyOutputStream.a();
        int i = n2;
        final int n3 = a;
        int n4 = n;
        while (i > 0) {
            final int px = q.px(i, this.chunkSize);
            q.sz(this.out, array, n4, px);
            i -= px;
            n4 += px;
            if (n3 != 0) {
                break;
            }
        }
    }
    
    private static IllegalArgumentException b(final IllegalArgumentException ex) {
        return ex;
    }
}
