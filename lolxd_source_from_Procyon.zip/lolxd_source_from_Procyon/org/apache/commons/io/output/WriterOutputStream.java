// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.output;

import java.nio.charset.CoderResult;
import java.io.IOException;
import java.nio.charset.Charset;
import q.o.m.s.q;
import java.nio.CharBuffer;
import java.nio.ByteBuffer;
import java.nio.charset.CharsetDecoder;
import java.io.Writer;
import java.io.OutputStream;

public class WriterOutputStream extends OutputStream
{
    private static final int DEFAULT_BUFFER_SIZE = 1024;
    private final Writer writer;
    private final CharsetDecoder decoder;
    private final boolean writeImmediately;
    private final ByteBuffer decoderIn;
    private final CharBuffer decoderOut;
    private static final String[] a;
    private static final String[] b;
    
    public WriterOutputStream(final Writer writer, final CharsetDecoder charsetDecoder) {
        this(writer, charsetDecoder, 1024, false);
    }
    
    public WriterOutputStream(final Writer writer, final CharsetDecoder decoder, final int n, final boolean writeImmediately) {
        this.decoderIn = q.nf(128);
        checkIbmJdkWithBrokenUTF16(q.gv(decoder));
        this.writer = writer;
        this.decoder = decoder;
        this.writeImmediately = writeImmediately;
        this.decoderOut = q.hj(n);
    }
    
    public WriterOutputStream(final Writer writer, final Charset charset, final int n, final boolean b) {
        this(writer, q.gr(q.gt(q.gq(q.go(charset), x.dn.g.b.q.y()), x.dn.g.b.q.y()), n.d.a.d.q.vj()), n, b);
    }
    
    public WriterOutputStream(final Writer writer, final Charset charset) {
        this(writer, charset, 1024, false);
    }
    
    public WriterOutputStream(final Writer writer, final String s, final int n, final boolean b) {
        this(writer, q.sh(s), n, b);
    }
    
    public WriterOutputStream(final Writer writer, final String s) {
        this(writer, s, 1024, false);
    }
    
    @Deprecated
    public WriterOutputStream(final Writer writer) {
        this(writer, q.sx(), 1024, false);
    }
    
    @Override
    public void write(final byte[] p0, final int p1, final int p2) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore          4
        //     5: iload_3        
        //     6: ifle            66
        //     9: iload_3        
        //    10: aload_0        
        //    11: getfield        org/apache/commons/io/output/WriterOutputStream.decoderIn:Ljava/nio/ByteBuffer;
        //    14: invokestatic    q/o/m/s/q.yw:(Ljava/nio/ByteBuffer;)I
        //    17: invokestatic    q/o/m/s/q.px:(II)I
        //    20: istore          5
        //    22: aload_0        
        //    23: getfield        org/apache/commons/io/output/WriterOutputStream.decoderIn:Ljava/nio/ByteBuffer;
        //    26: aload_1        
        //    27: iload_2        
        //    28: iload           5
        //    30: invokestatic    q/o/m/s/q.gs:(Ljava/nio/ByteBuffer;[BII)Ljava/nio/ByteBuffer;
        //    33: pop            
        //    34: aload_0        
        //    35: iconst_0       
        //    36: invokespecial   org/apache/commons/io/output/WriterOutputStream.processInput:(Z)V
        //    39: iload_3        
        //    40: iload           5
        //    42: isub           
        //    43: istore_3       
        //    44: iload_2        
        //    45: iload           5
        //    47: iadd           
        //    48: istore_2       
        //    49: iload           4
        //    51: ifne            108
        //    54: iload           4
        //    56: ifeq            5
        //    59: goto            66
        //    62: invokestatic    org/apache/commons/io/output/WriterOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    65: athrow         
        //    66: aload_0        
        //    67: iload           4
        //    69: ifne            105
        //    72: iload           4
        //    74: ifne            105
        //    77: goto            84
        //    80: invokestatic    org/apache/commons/io/output/WriterOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    83: athrow         
        //    84: getfield        org/apache/commons/io/output/WriterOutputStream.writeImmediately:Z
        //    87: ifeq            108
        //    90: goto            97
        //    93: invokestatic    org/apache/commons/io/output/WriterOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    96: athrow         
        //    97: aload_0        
        //    98: goto            105
        //   101: invokestatic    org/apache/commons/io/output/WriterOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   104: athrow         
        //   105: invokespecial   org/apache/commons/io/output/WriterOutputStream.flushOutput:()V
        //   108: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 0A FC 00 05 01 FF 00 38 00 06 07 00 02 07 00 81 01 01 01 01 00 01 07 00 6A FA 00 03 4D 07 00 6A 43 07 00 02 48 07 00 6A 03 43 07 00 6A 43 07 00 02 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  49     59     62     66     Ljava/io/IOException;
        //  66     77     80     84     Ljava/io/IOException;
        //  72     90     93     97     Ljava/io/IOException;
        //  84     98     101    105    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0084:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void write(final byte[] array) throws IOException {
        this.write(array, 0, array.length);
    }
    
    @Override
    public void write(final int n) throws IOException {
        this.write(new byte[] { (byte)n }, 0, 1);
    }
    
    @Override
    public void flush() throws IOException {
        this.flushOutput();
        q.jd(this.writer);
    }
    
    @Override
    public void close() throws IOException {
        this.processInput(true);
        this.flushOutput();
        q.jb(this.writer);
    }
    
    private void processInput(final boolean b) throws IOException {
        final int b2 = ProxyOutputStream.b();
        q.nq(this.decoderIn);
        final int n = b2;
        CoderResult gk;
        while (true) {
            gk = q.gk(this.decoder, this.decoderIn, this.decoderOut, b);
            if (q.ge(gk)) {
                try {
                    this.flushOutput();
                    if (n == 0) {
                        throw new IOException(a(23084, -908));
                    }
                    if (n != 0) {
                        continue;
                    }
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                break;
            }
            break;
        }
        Label_0090: {
            try {
                if (q.hz(gk)) {
                    if (n != 0) {
                        break Label_0090;
                    }
                }
            }
            catch (IOException ex2) {
                throw b(ex2);
            }
            throw new IOException(a(23084, -908));
        }
        q.xh(this.decoderIn);
    }
    
    private void flushOutput() throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: getfield        org/apache/commons/io/output/WriterOutputStream.decoderOut:Ljava/nio/CharBuffer;
        //     8: iload_1        
        //     9: ifne            72
        //    12: iload_1        
        //    13: ifne            72
        //    16: goto            23
        //    19: invokestatic    org/apache/commons/io/output/WriterOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    22: athrow         
        //    23: invokestatic    q/o/m/s/q.xi:(Ljava/nio/CharBuffer;)I
        //    26: ifle            73
        //    29: goto            36
        //    32: invokestatic    org/apache/commons/io/output/WriterOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    35: athrow         
        //    36: aload_0        
        //    37: getfield        org/apache/commons/io/output/WriterOutputStream.writer:Ljava/io/Writer;
        //    40: aload_0        
        //    41: getfield        org/apache/commons/io/output/WriterOutputStream.decoderOut:Ljava/nio/CharBuffer;
        //    44: invokestatic    q/o/m/s/q.hb:(Ljava/nio/CharBuffer;)[C
        //    47: iconst_0       
        //    48: aload_0        
        //    49: getfield        org/apache/commons/io/output/WriterOutputStream.decoderOut:Ljava/nio/CharBuffer;
        //    52: invokestatic    q/o/m/s/q.xi:(Ljava/nio/CharBuffer;)I
        //    55: invokestatic    q/o/m/s/q.sb:(Ljava/io/Writer;[CII)V
        //    58: aload_0        
        //    59: getfield        org/apache/commons/io/output/WriterOutputStream.decoderOut:Ljava/nio/CharBuffer;
        //    62: invokestatic    q/o/m/s/q.hv:(Ljava/nio/CharBuffer;)Ljava/nio/Buffer;
        //    65: goto            72
        //    68: invokestatic    org/apache/commons/io/output/WriterOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    71: athrow         
        //    72: pop            
        //    73: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 07 53 07 00 6A 43 07 00 B2 48 07 00 6A 03 5F 07 00 6A 43 07 00 C4 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      16     19     23     Ljava/io/IOException;
        //  12     29     32     36     Ljava/io/IOException;
        //  23     65     68     72     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0023:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static void checkIbmJdkWithBrokenUTF16(final Charset p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: sipush          23085
        //     7: sipush          -32013
        //    10: invokestatic    org/apache/commons/io/output/WriterOutputStream.a:(II)Ljava/lang/String;
        //    13: iload_1        
        //    14: ifeq            48
        //    17: aload_0        
        //    18: invokestatic    q/o/m/s/q.sp:(Ljava/nio/charset/Charset;)Ljava/lang/String;
        //    21: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //    24: ifne            39
        //    27: goto            34
        //    30: invokestatic    org/apache/commons/io/output/WriterOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    33: athrow         
        //    34: return         
        //    35: invokestatic    org/apache/commons/io/output/WriterOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    38: athrow         
        //    39: sipush          23087
        //    42: sipush          14148
        //    45: invokestatic    org/apache/commons/io/output/WriterOutputStream.a:(II)Ljava/lang/String;
        //    48: astore_2       
        //    49: sipush          23087
        //    52: sipush          14148
        //    55: invokestatic    org/apache/commons/io/output/WriterOutputStream.a:(II)Ljava/lang/String;
        //    58: aload_0        
        //    59: invokestatic    q/o/m/s/q.yf:(Ljava/lang/String;Ljava/nio/charset/Charset;)[B
        //    62: astore_3       
        //    63: aload_0        
        //    64: invokestatic    q/o/m/s/q.go:(Ljava/nio/charset/Charset;)Ljava/nio/charset/CharsetDecoder;
        //    67: astore          4
        //    69: bipush          16
        //    71: invokestatic    q/o/m/s/q.nf:(I)Ljava/nio/ByteBuffer;
        //    74: astore          5
        //    76: sipush          23087
        //    79: sipush          14148
        //    82: invokestatic    org/apache/commons/io/output/WriterOutputStream.a:(II)Ljava/lang/String;
        //    85: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //    88: invokestatic    q/o/m/s/q.hj:(I)Ljava/nio/CharBuffer;
        //    91: astore          6
        //    93: aload_3        
        //    94: arraylength    
        //    95: istore          7
        //    97: iconst_0       
        //    98: istore          8
        //   100: iload           8
        //   102: iload           7
        //   104: if_icmpge       215
        //   107: aload           5
        //   109: aload_3        
        //   110: iload           8
        //   112: baload         
        //   113: invokestatic    q/o/m/s/q.nv:(Ljava/nio/ByteBuffer;B)Ljava/nio/ByteBuffer;
        //   116: pop            
        //   117: aload           5
        //   119: invokestatic    q/o/m/s/q.nq:(Ljava/nio/ByteBuffer;)Ljava/nio/Buffer;
        //   122: pop            
        //   123: iload_1        
        //   124: ifeq            221
        //   127: aload           4
        //   129: aload           5
        //   131: aload           6
        //   133: iload           8
        //   135: iload_1        
        //   136: ifeq            172
        //   139: iload_1        
        //   140: ifeq            172
        //   143: goto            150
        //   146: invokestatic    org/apache/commons/io/output/WriterOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   149: athrow         
        //   150: iload           7
        //   152: iconst_1       
        //   153: isub           
        //   154: if_icmpne       175
        //   157: goto            164
        //   160: invokestatic    org/apache/commons/io/output/WriterOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   163: athrow         
        //   164: iconst_1       
        //   165: goto            172
        //   168: invokestatic    org/apache/commons/io/output/WriterOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   171: athrow         
        //   172: goto            176
        //   175: iconst_0       
        //   176: invokestatic    q/o/m/s/q.gk:(Ljava/nio/charset/CharsetDecoder;Ljava/nio/ByteBuffer;Ljava/nio/CharBuffer;Z)Ljava/nio/charset/CoderResult;
        //   179: pop            
        //   180: goto            202
        //   183: astore          9
        //   185: new             Ljava/lang/UnsupportedOperationException;
        //   188: dup            
        //   189: sipush          23086
        //   192: sipush          20825
        //   195: invokestatic    org/apache/commons/io/output/WriterOutputStream.a:(II)Ljava/lang/String;
        //   198: invokespecial   java/lang/UnsupportedOperationException.<init>:(Ljava/lang/String;)V
        //   201: athrow         
        //   202: aload           5
        //   204: invokestatic    q/o/m/s/q.xh:(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;
        //   207: pop            
        //   208: iinc            8, 1
        //   211: iload_1        
        //   212: ifne            100
        //   215: aload           6
        //   217: invokestatic    q/o/m/s/q.hv:(Ljava/nio/CharBuffer;)Ljava/nio/Buffer;
        //   220: pop            
        //   221: sipush          23087
        //   224: sipush          14148
        //   227: invokestatic    org/apache/commons/io/output/WriterOutputStream.a:(II)Ljava/lang/String;
        //   230: aload           6
        //   232: invokestatic    q/o/m/s/q.nr:(Ljava/nio/CharBuffer;)Ljava/lang/String;
        //   235: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   238: ifne            262
        //   241: new             Ljava/lang/UnsupportedOperationException;
        //   244: dup            
        //   245: sipush          23086
        //   248: sipush          20825
        //   251: invokestatic    org/apache/commons/io/output/WriterOutputStream.a:(II)Ljava/lang/String;
        //   254: invokespecial   java/lang/UnsupportedOperationException.<init>:(Ljava/lang/String;)V
        //   257: athrow         
        //   258: invokestatic    org/apache/commons/io/output/WriterOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   261: athrow         
        //   262: return         
        //    StackMapTable: 00 14 FF 00 1E 00 02 07 00 D0 01 00 01 07 00 C6 03 40 07 00 C6 03 48 07 00 D2 FF 00 33 00 09 07 00 D0 01 07 00 D2 07 00 81 07 00 DC 07 00 DE 07 00 B2 01 01 00 00 6D 07 00 C6 FF 00 03 00 09 07 00 D0 01 07 00 D2 07 00 81 07 00 DC 07 00 DE 07 00 B2 01 01 00 04 07 00 DC 07 00 DE 07 00 B2 01 49 07 00 C6 FF 00 03 00 09 07 00 D0 01 07 00 D2 07 00 81 07 00 DC 07 00 DE 07 00 B2 01 01 00 03 07 00 DC 07 00 DE 07 00 B2 43 07 00 C6 FF 00 03 00 09 07 00 D0 01 07 00 D2 07 00 81 07 00 DC 07 00 DE 07 00 B2 01 01 00 04 07 00 DC 07 00 DE 07 00 B2 01 FF 00 02 00 09 07 00 D0 01 07 00 D2 07 00 81 07 00 DC 07 00 DE 07 00 B2 01 01 00 03 07 00 DC 07 00 DE 07 00 B2 FF 00 00 00 09 07 00 D0 01 07 00 D2 07 00 81 07 00 DC 07 00 DE 07 00 B2 01 01 00 04 07 00 DC 07 00 DE 07 00 B2 01 46 07 00 C6 12 0C 05 64 07 00 C6 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  150    165    168    172    Ljava/lang/IllegalArgumentException;
        //  139    157    160    164    Ljava/lang/IllegalArgumentException;
        //  127    143    146    150    Ljava/lang/IllegalArgumentException;
        //  17     35     35     39     Ljava/lang/IllegalArgumentException;
        //  4      27     30     34     Ljava/lang/IllegalArgumentException;
        //  123    180    183    202    Ljava/lang/IllegalArgumentException;
        //  221    258    258    262    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0150:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    static {
        final String[] a2 = new String[4];
        int n = 0;
        String s;
        int n2 = q.q(s = n.d.a.d.q.tc());
        int n3 = 23;
        int n4 = -1;
    Label_0023:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 2));
                ++n4;
                final String s2 = s;
                final int n9 = n4;
                String s3 = q.h(s2, n9, n9 + n3);
                int n10 = -1;
                while (true) {
                    final char[] g = q.g(s3);
                    final int length = g.length;
                    int n11 = 0;
                    while (true) {
                        Label_0260: {
                            if (length > 1) {
                                break Label_0260;
                            }
                            n7 = (n6 = n11);
                            do {
                                final char c = g[n6];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 82;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 108;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 123;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 25;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 123;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 28;
                                        break;
                                    }
                                    default: {
                                        n12 = 7;
                                        break;
                                    }
                                }
                                g[n7] = (char)(c ^ (n5 ^ n12));
                                ++n11;
                            } while (n8 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.z(new String(g));
                    switch (n10) {
                        default: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                continue Label_0023;
                            }
                            n2 = q.q(s = n.d.a.d.q.tx());
                            n3 = 162;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                break;
                            }
                            break Label_0023;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 53)));
                    ++n4;
                    final String s4 = s;
                    final int n13 = n4;
                    s3 = q.h(s4, n13, n13 + n3);
                    n10 = 0;
                }
            }
            break;
        }
        a = a2;
        b = new String[4];
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0x5A2C) & 0xFFFF;
        if (WriterOutputStream.b[n3] == null) {
            final char[] g = q.g(WriterOutputStream.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 238;
                    break;
                }
                case 1: {
                    n4 = 198;
                    break;
                }
                case 2: {
                    n4 = 100;
                    break;
                }
                case 3: {
                    n4 = 98;
                    break;
                }
                case 4: {
                    n4 = 185;
                    break;
                }
                case 5: {
                    n4 = 234;
                    break;
                }
                case 6: {
                    n4 = 72;
                    break;
                }
                case 7: {
                    n4 = 216;
                    break;
                }
                case 8: {
                    n4 = 107;
                    break;
                }
                case 9: {
                    n4 = 56;
                    break;
                }
                case 10: {
                    n4 = 18;
                    break;
                }
                case 11: {
                    n4 = 186;
                    break;
                }
                case 12: {
                    n4 = 27;
                    break;
                }
                case 13: {
                    n4 = 184;
                    break;
                }
                case 14: {
                    n4 = 9;
                    break;
                }
                case 15: {
                    n4 = 187;
                    break;
                }
                case 16: {
                    n4 = 144;
                    break;
                }
                case 17: {
                    n4 = 188;
                    break;
                }
                case 18: {
                    n4 = 87;
                    break;
                }
                case 19: {
                    n4 = 248;
                    break;
                }
                case 20: {
                    n4 = 84;
                    break;
                }
                case 21: {
                    n4 = 240;
                    break;
                }
                case 22: {
                    n4 = 108;
                    break;
                }
                case 23: {
                    n4 = 103;
                    break;
                }
                case 24: {
                    n4 = 30;
                    break;
                }
                case 25: {
                    n4 = 149;
                    break;
                }
                case 26: {
                    n4 = 5;
                    break;
                }
                case 27: {
                    n4 = 49;
                    break;
                }
                case 28: {
                    n4 = 14;
                    break;
                }
                case 29: {
                    n4 = 10;
                    break;
                }
                case 30: {
                    n4 = 118;
                    break;
                }
                case 31: {
                    n4 = 114;
                    break;
                }
                case 32: {
                    n4 = 15;
                    break;
                }
                case 33: {
                    n4 = 61;
                    break;
                }
                case 34: {
                    n4 = 242;
                    break;
                }
                case 35: {
                    n4 = 228;
                    break;
                }
                case 36: {
                    n4 = 32;
                    break;
                }
                case 37: {
                    n4 = 85;
                    break;
                }
                case 38: {
                    n4 = 41;
                    break;
                }
                case 39: {
                    n4 = 202;
                    break;
                }
                case 40: {
                    n4 = 155;
                    break;
                }
                case 41: {
                    n4 = 88;
                    break;
                }
                case 42: {
                    n4 = 110;
                    break;
                }
                case 43: {
                    n4 = 215;
                    break;
                }
                case 44: {
                    n4 = 26;
                    break;
                }
                case 45: {
                    n4 = 213;
                    break;
                }
                case 46: {
                    n4 = 177;
                    break;
                }
                case 47: {
                    n4 = 59;
                    break;
                }
                case 48: {
                    n4 = 67;
                    break;
                }
                case 49: {
                    n4 = 245;
                    break;
                }
                case 50: {
                    n4 = 252;
                    break;
                }
                case 51: {
                    n4 = 81;
                    break;
                }
                case 52: {
                    n4 = 124;
                    break;
                }
                case 53: {
                    n4 = 36;
                    break;
                }
                case 54: {
                    n4 = 246;
                    break;
                }
                case 55: {
                    n4 = 132;
                    break;
                }
                case 56: {
                    n4 = 136;
                    break;
                }
                case 57: {
                    n4 = 121;
                    break;
                }
                case 58: {
                    n4 = 209;
                    break;
                }
                case 59: {
                    n4 = 6;
                    break;
                }
                case 60: {
                    n4 = 112;
                    break;
                }
                case 61: {
                    n4 = 19;
                    break;
                }
                case 62: {
                    n4 = 175;
                    break;
                }
                case 63: {
                    n4 = 137;
                    break;
                }
                case 64: {
                    n4 = 143;
                    break;
                }
                case 65: {
                    n4 = 105;
                    break;
                }
                case 66: {
                    n4 = 220;
                    break;
                }
                case 67: {
                    n4 = 89;
                    break;
                }
                case 68: {
                    n4 = 64;
                    break;
                }
                case 69: {
                    n4 = 76;
                    break;
                }
                case 70: {
                    n4 = 244;
                    break;
                }
                case 71: {
                    n4 = 83;
                    break;
                }
                case 72: {
                    n4 = 24;
                    break;
                }
                case 73: {
                    n4 = 167;
                    break;
                }
                case 74: {
                    n4 = 48;
                    break;
                }
                case 75: {
                    n4 = 253;
                    break;
                }
                case 76: {
                    n4 = 133;
                    break;
                }
                case 77: {
                    n4 = 96;
                    break;
                }
                case 78: {
                    n4 = 126;
                    break;
                }
                case 79: {
                    n4 = 201;
                    break;
                }
                case 80: {
                    n4 = 241;
                    break;
                }
                case 81: {
                    n4 = 35;
                    break;
                }
                case 82: {
                    n4 = 214;
                    break;
                }
                case 83: {
                    n4 = 117;
                    break;
                }
                case 84: {
                    n4 = 66;
                    break;
                }
                case 85: {
                    n4 = 189;
                    break;
                }
                case 86: {
                    n4 = 191;
                    break;
                }
                case 87: {
                    n4 = 151;
                    break;
                }
                case 88: {
                    n4 = 176;
                    break;
                }
                case 89: {
                    n4 = 80;
                    break;
                }
                case 90: {
                    n4 = 237;
                    break;
                }
                case 91: {
                    n4 = 135;
                    break;
                }
                case 92: {
                    n4 = 159;
                    break;
                }
                case 93: {
                    n4 = 226;
                    break;
                }
                case 94: {
                    n4 = 0;
                    break;
                }
                case 95: {
                    n4 = 207;
                    break;
                }
                case 96: {
                    n4 = 251;
                    break;
                }
                case 97: {
                    n4 = 166;
                    break;
                }
                case 98: {
                    n4 = 115;
                    break;
                }
                case 99: {
                    n4 = 40;
                    break;
                }
                case 100: {
                    n4 = 190;
                    break;
                }
                case 101: {
                    n4 = 123;
                    break;
                }
                case 102: {
                    n4 = 204;
                    break;
                }
                case 103: {
                    n4 = 23;
                    break;
                }
                case 104: {
                    n4 = 211;
                    break;
                }
                case 105: {
                    n4 = 94;
                    break;
                }
                case 106: {
                    n4 = 50;
                    break;
                }
                case 107: {
                    n4 = 221;
                    break;
                }
                case 108: {
                    n4 = 243;
                    break;
                }
                case 109: {
                    n4 = 46;
                    break;
                }
                case 110: {
                    n4 = 153;
                    break;
                }
                case 111: {
                    n4 = 86;
                    break;
                }
                case 112: {
                    n4 = 250;
                    break;
                }
                case 113: {
                    n4 = 239;
                    break;
                }
                case 114: {
                    n4 = 235;
                    break;
                }
                case 115: {
                    n4 = 33;
                    break;
                }
                case 116: {
                    n4 = 157;
                    break;
                }
                case 117: {
                    n4 = 120;
                    break;
                }
                case 118: {
                    n4 = 3;
                    break;
                }
                case 119: {
                    n4 = 11;
                    break;
                }
                case 120: {
                    n4 = 230;
                    break;
                }
                case 121: {
                    n4 = 2;
                    break;
                }
                case 122: {
                    n4 = 29;
                    break;
                }
                case 123: {
                    n4 = 1;
                    break;
                }
                case 124: {
                    n4 = 125;
                    break;
                }
                case 125: {
                    n4 = 34;
                    break;
                }
                case 126: {
                    n4 = 57;
                    break;
                }
                case 127: {
                    n4 = 182;
                    break;
                }
                case 128: {
                    n4 = 179;
                    break;
                }
                case 129: {
                    n4 = 206;
                    break;
                }
                case 130: {
                    n4 = 156;
                    break;
                }
                case 131: {
                    n4 = 129;
                    break;
                }
                case 132: {
                    n4 = 183;
                    break;
                }
                case 133: {
                    n4 = 92;
                    break;
                }
                case 134: {
                    n4 = 38;
                    break;
                }
                case 135: {
                    n4 = 90;
                    break;
                }
                case 136: {
                    n4 = 7;
                    break;
                }
                case 137: {
                    n4 = 212;
                    break;
                }
                case 138: {
                    n4 = 111;
                    break;
                }
                case 139: {
                    n4 = 39;
                    break;
                }
                case 140: {
                    n4 = 180;
                    break;
                }
                case 141: {
                    n4 = 154;
                    break;
                }
                case 142: {
                    n4 = 54;
                    break;
                }
                case 143: {
                    n4 = 43;
                    break;
                }
                case 144: {
                    n4 = 74;
                    break;
                }
                case 145: {
                    n4 = 28;
                    break;
                }
                case 146: {
                    n4 = 203;
                    break;
                }
                case 147: {
                    n4 = 113;
                    break;
                }
                case 148: {
                    n4 = 140;
                    break;
                }
                case 149: {
                    n4 = 160;
                    break;
                }
                case 150: {
                    n4 = 200;
                    break;
                }
                case 151: {
                    n4 = 60;
                    break;
                }
                case 152: {
                    n4 = 171;
                    break;
                }
                case 153: {
                    n4 = 147;
                    break;
                }
                case 154: {
                    n4 = 232;
                    break;
                }
                case 155: {
                    n4 = 196;
                    break;
                }
                case 156: {
                    n4 = 128;
                    break;
                }
                case 157: {
                    n4 = 247;
                    break;
                }
                case 158: {
                    n4 = 31;
                    break;
                }
                case 159: {
                    n4 = 139;
                    break;
                }
                case 160: {
                    n4 = 44;
                    break;
                }
                case 161: {
                    n4 = 109;
                    break;
                }
                case 162: {
                    n4 = 150;
                    break;
                }
                case 163: {
                    n4 = 97;
                    break;
                }
                case 164: {
                    n4 = 101;
                    break;
                }
                case 165: {
                    n4 = 102;
                    break;
                }
                case 166: {
                    n4 = 73;
                    break;
                }
                case 167: {
                    n4 = 37;
                    break;
                }
                case 168: {
                    n4 = 17;
                    break;
                }
                case 169: {
                    n4 = 8;
                    break;
                }
                case 170: {
                    n4 = 161;
                    break;
                }
                case 171: {
                    n4 = 172;
                    break;
                }
                case 172: {
                    n4 = 217;
                    break;
                }
                case 173: {
                    n4 = 195;
                    break;
                }
                case 174: {
                    n4 = 145;
                    break;
                }
                case 175: {
                    n4 = 116;
                    break;
                }
                case 176: {
                    n4 = 51;
                    break;
                }
                case 177: {
                    n4 = 16;
                    break;
                }
                case 178: {
                    n4 = 169;
                    break;
                }
                case 179: {
                    n4 = 181;
                    break;
                }
                case 180: {
                    n4 = 122;
                    break;
                }
                case 181: {
                    n4 = 224;
                    break;
                }
                case 182: {
                    n4 = 255;
                    break;
                }
                case 183: {
                    n4 = 210;
                    break;
                }
                case 184: {
                    n4 = 148;
                    break;
                }
                case 185: {
                    n4 = 158;
                    break;
                }
                case 186: {
                    n4 = 13;
                    break;
                }
                case 187: {
                    n4 = 58;
                    break;
                }
                case 188: {
                    n4 = 21;
                    break;
                }
                case 189: {
                    n4 = 106;
                    break;
                }
                case 190: {
                    n4 = 95;
                    break;
                }
                case 191: {
                    n4 = 42;
                    break;
                }
                case 192: {
                    n4 = 138;
                    break;
                }
                case 193: {
                    n4 = 197;
                    break;
                }
                case 194: {
                    n4 = 218;
                    break;
                }
                case 195: {
                    n4 = 168;
                    break;
                }
                case 196: {
                    n4 = 164;
                    break;
                }
                case 197: {
                    n4 = 142;
                    break;
                }
                case 198: {
                    n4 = 53;
                    break;
                }
                case 199: {
                    n4 = 69;
                    break;
                }
                case 200: {
                    n4 = 165;
                    break;
                }
                case 201: {
                    n4 = 227;
                    break;
                }
                case 202: {
                    n4 = 75;
                    break;
                }
                case 203: {
                    n4 = 70;
                    break;
                }
                case 204: {
                    n4 = 77;
                    break;
                }
                case 205: {
                    n4 = 63;
                    break;
                }
                case 206: {
                    n4 = 45;
                    break;
                }
                case 207: {
                    n4 = 93;
                    break;
                }
                case 208: {
                    n4 = 52;
                    break;
                }
                case 209: {
                    n4 = 55;
                    break;
                }
                case 210: {
                    n4 = 20;
                    break;
                }
                case 211: {
                    n4 = 236;
                    break;
                }
                case 212: {
                    n4 = 205;
                    break;
                }
                case 213: {
                    n4 = 91;
                    break;
                }
                case 214: {
                    n4 = 82;
                    break;
                }
                case 215: {
                    n4 = 47;
                    break;
                }
                case 216: {
                    n4 = 163;
                    break;
                }
                case 217: {
                    n4 = 249;
                    break;
                }
                case 218: {
                    n4 = 12;
                    break;
                }
                case 219: {
                    n4 = 62;
                    break;
                }
                case 220: {
                    n4 = 146;
                    break;
                }
                case 221: {
                    n4 = 4;
                    break;
                }
                case 222: {
                    n4 = 104;
                    break;
                }
                case 223: {
                    n4 = 127;
                    break;
                }
                case 224: {
                    n4 = 99;
                    break;
                }
                case 225: {
                    n4 = 192;
                    break;
                }
                case 226: {
                    n4 = 71;
                    break;
                }
                case 227: {
                    n4 = 130;
                    break;
                }
                case 228: {
                    n4 = 199;
                    break;
                }
                case 229: {
                    n4 = 174;
                    break;
                }
                case 230: {
                    n4 = 25;
                    break;
                }
                case 231: {
                    n4 = 173;
                    break;
                }
                case 232: {
                    n4 = 22;
                    break;
                }
                case 233: {
                    n4 = 68;
                    break;
                }
                case 234: {
                    n4 = 222;
                    break;
                }
                case 235: {
                    n4 = 119;
                    break;
                }
                case 236: {
                    n4 = 223;
                    break;
                }
                case 237: {
                    n4 = 65;
                    break;
                }
                case 238: {
                    n4 = 78;
                    break;
                }
                case 239: {
                    n4 = 162;
                    break;
                }
                case 240: {
                    n4 = 231;
                    break;
                }
                case 241: {
                    n4 = 170;
                    break;
                }
                case 242: {
                    n4 = 193;
                    break;
                }
                case 243: {
                    n4 = 219;
                    break;
                }
                case 244: {
                    n4 = 194;
                    break;
                }
                case 245: {
                    n4 = 233;
                    break;
                }
                case 246: {
                    n4 = 178;
                    break;
                }
                case 247: {
                    n4 = 152;
                    break;
                }
                case 248: {
                    n4 = 79;
                    break;
                }
                case 249: {
                    n4 = 131;
                    break;
                }
                case 250: {
                    n4 = 141;
                    break;
                }
                case 251: {
                    n4 = 134;
                    break;
                }
                case 252: {
                    n4 = 208;
                    break;
                }
                case 253: {
                    n4 = 254;
                    break;
                }
                case 254: {
                    n4 = 229;
                    break;
                }
                default: {
                    n4 = 225;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            WriterOutputStream.b[n3] = q.z(new String(g));
        }
        return WriterOutputStream.b[n3];
    }
}
