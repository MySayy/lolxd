// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.output;

import q.o.m.s.q;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.Charset;
import java.io.IOException;
import java.io.File;
import java.io.Writer;

public class FileWriterWithEncoding extends Writer
{
    private final Writer out;
    private static final String[] a;
    private static final String[] b;
    
    public FileWriterWithEncoding(final String pathname, final String s) throws IOException {
        this(new File(pathname), s, false);
    }
    
    public FileWriterWithEncoding(final String pathname, final String s, final boolean b) throws IOException {
        this(new File(pathname), s, b);
    }
    
    public FileWriterWithEncoding(final String pathname, final Charset charset) throws IOException {
        this(new File(pathname), charset, false);
    }
    
    public FileWriterWithEncoding(final String pathname, final Charset charset, final boolean b) throws IOException {
        this(new File(pathname), charset, b);
    }
    
    public FileWriterWithEncoding(final String pathname, final CharsetEncoder charsetEncoder) throws IOException {
        this(new File(pathname), charsetEncoder, false);
    }
    
    public FileWriterWithEncoding(final String pathname, final CharsetEncoder charsetEncoder, final boolean b) throws IOException {
        this(new File(pathname), charsetEncoder, b);
    }
    
    public FileWriterWithEncoding(final File file, final String s) throws IOException {
        this(file, s, false);
    }
    
    public FileWriterWithEncoding(final File file, final String s, final boolean b) throws IOException {
        this.out = initWriter(file, s, b);
    }
    
    public FileWriterWithEncoding(final File file, final Charset charset) throws IOException {
        this(file, charset, false);
    }
    
    public FileWriterWithEncoding(final File file, final Charset charset, final boolean b) throws IOException {
        this.out = initWriter(file, charset, b);
    }
    
    public FileWriterWithEncoding(final File file, final CharsetEncoder charsetEncoder) throws IOException {
        this(file, charsetEncoder, false);
    }
    
    public FileWriterWithEncoding(final File file, final CharsetEncoder charsetEncoder, final boolean b) throws IOException {
        this.out = initWriter(file, charsetEncoder, b);
    }
    
    private static Writer initWriter(final File p0, final Object p1, final boolean p2) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_3       
        //     4: aload_0        
        //     5: iload_3        
        //     6: ifne            41
        //     9: ifnonnull       40
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/output/FileWriterWithEncoding.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    18: athrow         
        //    19: new             Ljava/lang/NullPointerException;
        //    22: dup            
        //    23: sipush          -4348
        //    26: sipush          -2253
        //    29: invokestatic    org/apache/commons/io/output/FileWriterWithEncoding.a:(II)Ljava/lang/String;
        //    32: invokespecial   java/lang/NullPointerException.<init>:(Ljava/lang/String;)V
        //    35: athrow         
        //    36: invokestatic    org/apache/commons/io/output/FileWriterWithEncoding.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    39: athrow         
        //    40: aload_1        
        //    41: ifnonnull       65
        //    44: new             Ljava/lang/NullPointerException;
        //    47: dup            
        //    48: sipush          -4347
        //    51: sipush          -27528
        //    54: invokestatic    org/apache/commons/io/output/FileWriterWithEncoding.a:(II)Ljava/lang/String;
        //    57: invokespecial   java/lang/NullPointerException.<init>:(Ljava/lang/String;)V
        //    60: athrow         
        //    61: invokestatic    org/apache/commons/io/output/FileWriterWithEncoding.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    64: athrow         
        //    65: aload_0        
        //    66: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //    69: istore          4
        //    71: aconst_null    
        //    72: astore          5
        //    74: aconst_null    
        //    75: astore          6
        //    77: new             Ljava/io/FileOutputStream;
        //    80: dup            
        //    81: aload_0        
        //    82: iload_2        
        //    83: invokespecial   java/io/FileOutputStream.<init>:(Ljava/io/File;Z)V
        //    86: astore          5
        //    88: aload_1        
        //    89: instanceof      Ljava/nio/charset/Charset;
        //    92: iload_3        
        //    93: ifne            128
        //    96: ifeq            124
        //    99: goto            106
        //   102: invokestatic    org/apache/commons/io/output/FileWriterWithEncoding.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   105: athrow         
        //   106: new             Ljava/io/OutputStreamWriter;
        //   109: dup            
        //   110: aload           5
        //   112: aload_1        
        //   113: checkcast       Ljava/nio/charset/Charset;
        //   116: invokespecial   java/io/OutputStreamWriter.<init>:(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V
        //   119: astore          6
        //   121: goto            175
        //   124: aload_1        
        //   125: instanceof      Ljava/nio/charset/CharsetEncoder;
        //   128: ifeq            156
        //   131: new             Ljava/io/OutputStreamWriter;
        //   134: dup            
        //   135: aload           5
        //   137: aload_1        
        //   138: checkcast       Ljava/nio/charset/CharsetEncoder;
        //   141: invokespecial   java/io/OutputStreamWriter.<init>:(Ljava/io/OutputStream;Ljava/nio/charset/CharsetEncoder;)V
        //   144: goto            151
        //   147: invokestatic    org/apache/commons/io/output/FileWriterWithEncoding.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   150: athrow         
        //   151: astore          6
        //   153: goto            175
        //   156: new             Ljava/io/OutputStreamWriter;
        //   159: dup            
        //   160: aload           5
        //   162: aload_1        
        //   163: checkcast       Ljava/lang/String;
        //   166: invokespecial   java/io/OutputStreamWriter.<init>:(Ljava/io/OutputStream;Ljava/lang/String;)V
        //   169: iload_3        
        //   170: ifne            151
        //   173: astore          6
        //   175: goto            286
        //   178: astore          7
        //   180: aload           6
        //   182: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/Writer;)V
        //   185: aload           5
        //   187: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/OutputStream;)V
        //   190: iload           4
        //   192: iload_3        
        //   193: ifne            228
        //   196: iload_3        
        //   197: ifne            228
        //   200: goto            207
        //   203: invokestatic    org/apache/commons/io/output/FileWriterWithEncoding.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   206: athrow         
        //   207: ifne            229
        //   210: goto            217
        //   213: invokestatic    org/apache/commons/io/output/FileWriterWithEncoding.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   216: athrow         
        //   217: aload_0        
        //   218: invokestatic    org/apache/commons/io/FileUtils.deleteQuietly:(Ljava/io/File;)Z
        //   221: goto            228
        //   224: invokestatic    org/apache/commons/io/output/FileWriterWithEncoding.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   227: athrow         
        //   228: pop            
        //   229: aload           7
        //   231: athrow         
        //   232: astore          7
        //   234: aload           6
        //   236: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/Writer;)V
        //   239: aload           5
        //   241: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/OutputStream;)V
        //   244: iload           4
        //   246: iload_3        
        //   247: ifne            282
        //   250: iload_3        
        //   251: ifne            282
        //   254: goto            261
        //   257: invokestatic    org/apache/commons/io/output/FileWriterWithEncoding.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   260: athrow         
        //   261: ifne            283
        //   264: goto            271
        //   267: invokestatic    org/apache/commons/io/output/FileWriterWithEncoding.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   270: athrow         
        //   271: aload_0        
        //   272: invokestatic    org/apache/commons/io/FileUtils.deleteQuietly:(Ljava/io/File;)Z
        //   275: goto            282
        //   278: invokestatic    org/apache/commons/io/output/FileWriterWithEncoding.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   281: athrow         
        //   282: pop            
        //   283: aload           7
        //   285: athrow         
        //   286: aload           6
        //   288: areturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 20 FF 00 0F 00 04 07 00 10 07 00 36 01 01 00 01 07 00 0E 03 50 07 00 0E 03 40 07 00 36 53 07 00 0E 03 FF 00 24 00 07 07 00 10 07 00 36 01 01 01 07 00 47 05 00 01 07 00 0E 03 11 43 01 52 07 00 0E 43 07 00 4E 04 FF 00 12 00 07 07 00 10 07 00 36 01 01 01 07 00 47 07 00 4E 00 00 42 07 00 0E FF 00 18 00 08 07 00 10 07 00 36 01 01 01 07 00 47 07 00 4E 07 00 0E 00 01 07 00 0E 43 01 45 07 00 0E 03 46 07 00 0E 43 01 00 FF 00 02 00 07 07 00 10 07 00 36 01 01 01 07 00 47 07 00 4E 00 01 07 00 2F FF 00 18 00 08 07 00 10 07 00 36 01 01 01 07 00 47 07 00 4E 07 00 2F 00 01 07 00 0E 43 01 45 07 00 0E 03 46 07 00 0E 43 01 00 FA 00 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  128    144    147    151    Ljava/io/IOException;
        //  88     99     102    106    Ljava/io/IOException;
        //  41     61     61     65     Ljava/io/IOException;
        //  9      36     36     40     Ljava/io/IOException;
        //  4      12     15     19     Ljava/io/IOException;
        //  77     175    178    232    Ljava/io/IOException;
        //  77     175    232    286    Ljava/lang/RuntimeException;
        //  180    200    203    207    Ljava/io/IOException;
        //  196    210    213    217    Ljava/io/IOException;
        //  207    221    224    228    Ljava/io/IOException;
        //  234    254    257    261    Ljava/io/IOException;
        //  250    264    267    271    Ljava/io/IOException;
        //  261    275    278    282    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0207:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void write(final int n) throws IOException {
        q.jg(this.out, n);
    }
    
    @Override
    public void write(final char[] array) throws IOException {
        q.yc(this.out, array);
    }
    
    @Override
    public void write(final char[] array, final int n, final int n2) throws IOException {
        q.sb(this.out, array, n, n2);
    }
    
    @Override
    public void write(final String s) throws IOException {
        q.sa(this.out, s);
    }
    
    @Override
    public void write(final String s, final int n, final int n2) throws IOException {
        q.jz(this.out, s, n, n2);
    }
    
    @Override
    public void flush() throws IOException {
        q.jd(this.out);
    }
    
    @Override
    public void close() throws IOException {
        q.jb(this.out);
    }
    
    private static IOException b(final IOException ex) {
        return ex;
    }
    
    static {
        final String[] a2 = new String[2];
        int n = 0;
        final String tn;
        final int q = q.o.m.s.q.q(tn = n.d.a.d.q.tn());
        int j = 15;
        int n2 = -1;
        Label_0023: {
            break Label_0023;
            do {
                j = q.o.m.s.q.j(tn, n2);
                int n5;
                int n4;
                final int n3 = n4 = (n5 = 92);
                ++n2;
                final String s = tn;
                final int n6 = n2;
                final char[] g = q.o.m.s.q.g(q.o.m.s.q.h(s, n6, n6 + j));
                final int length = g.length;
                int n7 = 0;
                while (true) {
                    Label_0200: {
                        if (length > 1) {
                            break Label_0200;
                        }
                        n5 = (n4 = n7);
                        do {
                            final char c = g[n4];
                            int n8 = 0;
                            switch (n7 % 7) {
                                case 0: {
                                    n8 = 48;
                                    break;
                                }
                                case 1: {
                                    n8 = 33;
                                    break;
                                }
                                case 2: {
                                    n8 = 60;
                                    break;
                                }
                                case 3: {
                                    n8 = 65;
                                    break;
                                }
                                case 4: {
                                    n8 = 90;
                                    break;
                                }
                                case 5: {
                                    n8 = 25;
                                    break;
                                }
                                default: {
                                    n8 = 127;
                                    break;
                                }
                            }
                            g[n5] = (char)(c ^ (n3 ^ n8));
                            ++n7;
                        } while (n3 == 0);
                    }
                    if (length > n7) {
                        continue;
                    }
                    break;
                }
                a2[n++] = q.o.m.s.q.z(new String(g));
            } while ((n2 += j) < q);
        }
        a = a2;
        b = new String[2];
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0xFFFFEF04) & 0xFFFF;
        if (FileWriterWithEncoding.b[n3] == null) {
            final char[] g = q.g(FileWriterWithEncoding.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 77;
                    break;
                }
                case 1: {
                    n4 = 159;
                    break;
                }
                case 2: {
                    n4 = 249;
                    break;
                }
                case 3: {
                    n4 = 56;
                    break;
                }
                case 4: {
                    n4 = 1;
                    break;
                }
                case 5: {
                    n4 = 109;
                    break;
                }
                case 6: {
                    n4 = 29;
                    break;
                }
                case 7: {
                    n4 = 5;
                    break;
                }
                case 8: {
                    n4 = 43;
                    break;
                }
                case 9: {
                    n4 = 117;
                    break;
                }
                case 10: {
                    n4 = 214;
                    break;
                }
                case 11: {
                    n4 = 144;
                    break;
                }
                case 12: {
                    n4 = 21;
                    break;
                }
                case 13: {
                    n4 = 24;
                    break;
                }
                case 14: {
                    n4 = 252;
                    break;
                }
                case 15: {
                    n4 = 82;
                    break;
                }
                case 16: {
                    n4 = 215;
                    break;
                }
                case 17: {
                    n4 = 135;
                    break;
                }
                case 18: {
                    n4 = 101;
                    break;
                }
                case 19: {
                    n4 = 220;
                    break;
                }
                case 20: {
                    n4 = 242;
                    break;
                }
                case 21: {
                    n4 = 113;
                    break;
                }
                case 22: {
                    n4 = 224;
                    break;
                }
                case 23: {
                    n4 = 71;
                    break;
                }
                case 24: {
                    n4 = 209;
                    break;
                }
                case 25: {
                    n4 = 157;
                    break;
                }
                case 26: {
                    n4 = 10;
                    break;
                }
                case 27: {
                    n4 = 66;
                    break;
                }
                case 28: {
                    n4 = 74;
                    break;
                }
                case 29: {
                    n4 = 202;
                    break;
                }
                case 30: {
                    n4 = 173;
                    break;
                }
                case 31: {
                    n4 = 49;
                    break;
                }
                case 32: {
                    n4 = 183;
                    break;
                }
                case 33: {
                    n4 = 211;
                    break;
                }
                case 34: {
                    n4 = 142;
                    break;
                }
                case 35: {
                    n4 = 114;
                    break;
                }
                case 36: {
                    n4 = 122;
                    break;
                }
                case 37: {
                    n4 = 148;
                    break;
                }
                case 38: {
                    n4 = 35;
                    break;
                }
                case 39: {
                    n4 = 50;
                    break;
                }
                case 40: {
                    n4 = 181;
                    break;
                }
                case 41: {
                    n4 = 34;
                    break;
                }
                case 42: {
                    n4 = 64;
                    break;
                }
                case 43: {
                    n4 = 137;
                    break;
                }
                case 44: {
                    n4 = 115;
                    break;
                }
                case 45: {
                    n4 = 154;
                    break;
                }
                case 46: {
                    n4 = 129;
                    break;
                }
                case 47: {
                    n4 = 81;
                    break;
                }
                case 48: {
                    n4 = 124;
                    break;
                }
                case 49: {
                    n4 = 158;
                    break;
                }
                case 50: {
                    n4 = 210;
                    break;
                }
                case 51: {
                    n4 = 176;
                    break;
                }
                case 52: {
                    n4 = 193;
                    break;
                }
                case 53: {
                    n4 = 140;
                    break;
                }
                case 54: {
                    n4 = 44;
                    break;
                }
                case 55: {
                    n4 = 218;
                    break;
                }
                case 56: {
                    n4 = 107;
                    break;
                }
                case 57: {
                    n4 = 65;
                    break;
                }
                case 58: {
                    n4 = 45;
                    break;
                }
                case 59: {
                    n4 = 123;
                    break;
                }
                case 60: {
                    n4 = 247;
                    break;
                }
                case 61: {
                    n4 = 136;
                    break;
                }
                case 62: {
                    n4 = 18;
                    break;
                }
                case 63: {
                    n4 = 41;
                    break;
                }
                case 64: {
                    n4 = 125;
                    break;
                }
                case 65: {
                    n4 = 8;
                    break;
                }
                case 66: {
                    n4 = 205;
                    break;
                }
                case 67: {
                    n4 = 69;
                    break;
                }
                case 68: {
                    n4 = 84;
                    break;
                }
                case 69: {
                    n4 = 229;
                    break;
                }
                case 70: {
                    n4 = 149;
                    break;
                }
                case 71: {
                    n4 = 96;
                    break;
                }
                case 72: {
                    n4 = 12;
                    break;
                }
                case 73: {
                    n4 = 254;
                    break;
                }
                case 74: {
                    n4 = 30;
                    break;
                }
                case 75: {
                    n4 = 54;
                    break;
                }
                case 76: {
                    n4 = 170;
                    break;
                }
                case 77: {
                    n4 = 25;
                    break;
                }
                case 78: {
                    n4 = 59;
                    break;
                }
                case 79: {
                    n4 = 212;
                    break;
                }
                case 80: {
                    n4 = 153;
                    break;
                }
                case 81: {
                    n4 = 216;
                    break;
                }
                case 82: {
                    n4 = 75;
                    break;
                }
                case 83: {
                    n4 = 2;
                    break;
                }
                case 84: {
                    n4 = 78;
                    break;
                }
                case 85: {
                    n4 = 248;
                    break;
                }
                case 86: {
                    n4 = 160;
                    break;
                }
                case 87: {
                    n4 = 112;
                    break;
                }
                case 88: {
                    n4 = 219;
                    break;
                }
                case 89: {
                    n4 = 226;
                    break;
                }
                case 90: {
                    n4 = 39;
                    break;
                }
                case 91: {
                    n4 = 182;
                    break;
                }
                case 92: {
                    n4 = 192;
                    break;
                }
                case 93: {
                    n4 = 139;
                    break;
                }
                case 94: {
                    n4 = 94;
                    break;
                }
                case 95: {
                    n4 = 191;
                    break;
                }
                case 96: {
                    n4 = 251;
                    break;
                }
                case 97: {
                    n4 = 232;
                    break;
                }
                case 98: {
                    n4 = 185;
                    break;
                }
                case 99: {
                    n4 = 61;
                    break;
                }
                case 100: {
                    n4 = 189;
                    break;
                }
                case 101: {
                    n4 = 38;
                    break;
                }
                case 102: {
                    n4 = 60;
                    break;
                }
                case 103: {
                    n4 = 106;
                    break;
                }
                case 104: {
                    n4 = 208;
                    break;
                }
                case 105: {
                    n4 = 201;
                    break;
                }
                case 106: {
                    n4 = 138;
                    break;
                }
                case 107: {
                    n4 = 92;
                    break;
                }
                case 108: {
                    n4 = 126;
                    break;
                }
                case 109: {
                    n4 = 52;
                    break;
                }
                case 110: {
                    n4 = 19;
                    break;
                }
                case 111: {
                    n4 = 104;
                    break;
                }
                case 112: {
                    n4 = 195;
                    break;
                }
                case 113: {
                    n4 = 98;
                    break;
                }
                case 114: {
                    n4 = 228;
                    break;
                }
                case 115: {
                    n4 = 178;
                    break;
                }
                case 116: {
                    n4 = 237;
                    break;
                }
                case 117: {
                    n4 = 230;
                    break;
                }
                case 118: {
                    n4 = 174;
                    break;
                }
                case 119: {
                    n4 = 28;
                    break;
                }
                case 120: {
                    n4 = 53;
                    break;
                }
                case 121: {
                    n4 = 235;
                    break;
                }
                case 122: {
                    n4 = 238;
                    break;
                }
                case 123: {
                    n4 = 17;
                    break;
                }
                case 124: {
                    n4 = 26;
                    break;
                }
                case 125: {
                    n4 = 161;
                    break;
                }
                case 126: {
                    n4 = 51;
                    break;
                }
                case 127: {
                    n4 = 196;
                    break;
                }
                case 128: {
                    n4 = 83;
                    break;
                }
                case 129: {
                    n4 = 204;
                    break;
                }
                case 130: {
                    n4 = 223;
                    break;
                }
                case 131: {
                    n4 = 116;
                    break;
                }
                case 132: {
                    n4 = 20;
                    break;
                }
                case 133: {
                    n4 = 236;
                    break;
                }
                case 134: {
                    n4 = 240;
                    break;
                }
                case 135: {
                    n4 = 243;
                    break;
                }
                case 136: {
                    n4 = 163;
                    break;
                }
                case 137: {
                    n4 = 23;
                    break;
                }
                case 138: {
                    n4 = 166;
                    break;
                }
                case 139: {
                    n4 = 3;
                    break;
                }
                case 140: {
                    n4 = 164;
                    break;
                }
                case 141: {
                    n4 = 188;
                    break;
                }
                case 142: {
                    n4 = 217;
                    break;
                }
                case 143: {
                    n4 = 14;
                    break;
                }
                case 144: {
                    n4 = 168;
                    break;
                }
                case 145: {
                    n4 = 13;
                    break;
                }
                case 146: {
                    n4 = 187;
                    break;
                }
                case 147: {
                    n4 = 102;
                    break;
                }
                case 148: {
                    n4 = 134;
                    break;
                }
                case 149: {
                    n4 = 241;
                    break;
                }
                case 150: {
                    n4 = 7;
                    break;
                }
                case 151: {
                    n4 = 213;
                    break;
                }
                case 152: {
                    n4 = 120;
                    break;
                }
                case 153: {
                    n4 = 132;
                    break;
                }
                case 154: {
                    n4 = 79;
                    break;
                }
                case 155: {
                    n4 = 253;
                    break;
                }
                case 156: {
                    n4 = 171;
                    break;
                }
                case 157: {
                    n4 = 203;
                    break;
                }
                case 158: {
                    n4 = 27;
                    break;
                }
                case 159: {
                    n4 = 99;
                    break;
                }
                case 160: {
                    n4 = 40;
                    break;
                }
                case 161: {
                    n4 = 150;
                    break;
                }
                case 162: {
                    n4 = 67;
                    break;
                }
                case 163: {
                    n4 = 146;
                    break;
                }
                case 164: {
                    n4 = 199;
                    break;
                }
                case 165: {
                    n4 = 227;
                    break;
                }
                case 166: {
                    n4 = 197;
                    break;
                }
                case 167: {
                    n4 = 198;
                    break;
                }
                case 168: {
                    n4 = 57;
                    break;
                }
                case 169: {
                    n4 = 233;
                    break;
                }
                case 170: {
                    n4 = 88;
                    break;
                }
                case 171: {
                    n4 = 36;
                    break;
                }
                case 172: {
                    n4 = 80;
                    break;
                }
                case 173: {
                    n4 = 130;
                    break;
                }
                case 174: {
                    n4 = 70;
                    break;
                }
                case 175: {
                    n4 = 145;
                    break;
                }
                case 176: {
                    n4 = 105;
                    break;
                }
                case 177: {
                    n4 = 32;
                    break;
                }
                case 178: {
                    n4 = 234;
                    break;
                }
                case 179: {
                    n4 = 231;
                    break;
                }
                case 180: {
                    n4 = 48;
                    break;
                }
                case 181: {
                    n4 = 87;
                    break;
                }
                case 182: {
                    n4 = 46;
                    break;
                }
                case 183: {
                    n4 = 194;
                    break;
                }
                case 184: {
                    n4 = 85;
                    break;
                }
                case 185: {
                    n4 = 245;
                    break;
                }
                case 186: {
                    n4 = 156;
                    break;
                }
                case 187: {
                    n4 = 200;
                    break;
                }
                case 188: {
                    n4 = 42;
                    break;
                }
                case 189: {
                    n4 = 0;
                    break;
                }
                case 190: {
                    n4 = 246;
                    break;
                }
                case 191: {
                    n4 = 97;
                    break;
                }
                case 192: {
                    n4 = 58;
                    break;
                }
                case 193: {
                    n4 = 33;
                    break;
                }
                case 194: {
                    n4 = 121;
                    break;
                }
                case 195: {
                    n4 = 22;
                    break;
                }
                case 196: {
                    n4 = 206;
                    break;
                }
                case 197: {
                    n4 = 131;
                    break;
                }
                case 198: {
                    n4 = 95;
                    break;
                }
                case 199: {
                    n4 = 190;
                    break;
                }
                case 200: {
                    n4 = 184;
                    break;
                }
                case 201: {
                    n4 = 63;
                    break;
                }
                case 202: {
                    n4 = 47;
                    break;
                }
                case 203: {
                    n4 = 162;
                    break;
                }
                case 204: {
                    n4 = 225;
                    break;
                }
                case 205: {
                    n4 = 147;
                    break;
                }
                case 206: {
                    n4 = 76;
                    break;
                }
                case 207: {
                    n4 = 141;
                    break;
                }
                case 208: {
                    n4 = 250;
                    break;
                }
                case 209: {
                    n4 = 172;
                    break;
                }
                case 210: {
                    n4 = 9;
                    break;
                }
                case 211: {
                    n4 = 4;
                    break;
                }
                case 212: {
                    n4 = 108;
                    break;
                }
                case 213: {
                    n4 = 55;
                    break;
                }
                case 214: {
                    n4 = 222;
                    break;
                }
                case 215: {
                    n4 = 143;
                    break;
                }
                case 216: {
                    n4 = 110;
                    break;
                }
                case 217: {
                    n4 = 11;
                    break;
                }
                case 218: {
                    n4 = 73;
                    break;
                }
                case 219: {
                    n4 = 128;
                    break;
                }
                case 220: {
                    n4 = 37;
                    break;
                }
                case 221: {
                    n4 = 186;
                    break;
                }
                case 222: {
                    n4 = 165;
                    break;
                }
                case 223: {
                    n4 = 111;
                    break;
                }
                case 224: {
                    n4 = 167;
                    break;
                }
                case 225: {
                    n4 = 119;
                    break;
                }
                case 226: {
                    n4 = 16;
                    break;
                }
                case 227: {
                    n4 = 255;
                    break;
                }
                case 228: {
                    n4 = 93;
                    break;
                }
                case 229: {
                    n4 = 180;
                    break;
                }
                case 230: {
                    n4 = 179;
                    break;
                }
                case 231: {
                    n4 = 103;
                    break;
                }
                case 232: {
                    n4 = 68;
                    break;
                }
                case 233: {
                    n4 = 100;
                    break;
                }
                case 234: {
                    n4 = 244;
                    break;
                }
                case 235: {
                    n4 = 127;
                    break;
                }
                case 236: {
                    n4 = 15;
                    break;
                }
                case 237: {
                    n4 = 72;
                    break;
                }
                case 238: {
                    n4 = 86;
                    break;
                }
                case 239: {
                    n4 = 175;
                    break;
                }
                case 240: {
                    n4 = 239;
                    break;
                }
                case 241: {
                    n4 = 207;
                    break;
                }
                case 242: {
                    n4 = 221;
                    break;
                }
                case 243: {
                    n4 = 155;
                    break;
                }
                case 244: {
                    n4 = 151;
                    break;
                }
                case 245: {
                    n4 = 152;
                    break;
                }
                case 246: {
                    n4 = 31;
                    break;
                }
                case 247: {
                    n4 = 62;
                    break;
                }
                case 248: {
                    n4 = 91;
                    break;
                }
                case 249: {
                    n4 = 177;
                    break;
                }
                case 250: {
                    n4 = 90;
                    break;
                }
                case 251: {
                    n4 = 133;
                    break;
                }
                case 252: {
                    n4 = 89;
                    break;
                }
                case 253: {
                    n4 = 118;
                    break;
                }
                case 254: {
                    n4 = 169;
                    break;
                }
                default: {
                    n4 = 6;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            FileWriterWithEncoding.b[n3] = q.z(new String(g));
        }
        return FileWriterWithEncoding.b[n3];
    }
}
