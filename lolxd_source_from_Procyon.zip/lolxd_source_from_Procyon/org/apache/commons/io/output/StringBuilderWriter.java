// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.output;

import java.io.IOException;
import q.o.m.s.q;
import java.io.Serializable;
import java.io.Writer;

public class StringBuilderWriter extends Writer implements Serializable
{
    private static final long serialVersionUID = -146927496096066153L;
    private final StringBuilder builder;
    
    public StringBuilderWriter() {
        this.builder = new StringBuilder();
    }
    
    public StringBuilderWriter(final int capacity) {
        this.builder = new StringBuilder(capacity);
    }
    
    public StringBuilderWriter(final StringBuilder sb) {
        final int b = ProxyOutputStream.b();
        final int n = b;
        StringBuilder builder = null;
        Label_0046: {
            Label_0039: {
                Label_0036: {
                    Label_0025: {
                        try {
                            builder = sb;
                            if (n == 0) {
                                break Label_0036;
                            }
                            final int n2 = n;
                            if (n2 != 0) {
                                break Label_0025;
                            }
                            break Label_0036;
                        }
                        catch (RuntimeException ex) {
                            throw b(ex);
                        }
                        try {
                            final int n2 = n;
                            if (n2 == 0) {
                                break Label_0036;
                            }
                            if (sb == null) {
                                break Label_0039;
                            }
                        }
                        catch (RuntimeException ex2) {
                            throw b(ex2);
                        }
                    }
                    builder = sb;
                }
                break Label_0046;
            }
            builder = new StringBuilder();
        }
        this.builder = builder;
    }
    
    @Override
    public Writer append(final char c) {
        q.sk(this.builder, c);
        return this;
    }
    
    @Override
    public Writer append(final CharSequence charSequence) {
        q.ju(this.builder, charSequence);
        return this;
    }
    
    @Override
    public Writer append(final CharSequence charSequence, final int n, final int n2) {
        q.gf(this.builder, charSequence, n, n2);
        return this;
    }
    
    @Override
    public void close() {
    }
    
    @Override
    public void flush() {
    }
    
    @Override
    public void write(final String s) {
        try {
            if (s != null) {
                q.r(this.builder, s);
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
    }
    
    @Override
    public void write(final char[] array, final int n, final int n2) {
        try {
            if (array != null) {
                q.gm(this.builder, array, n, n2);
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
    }
    
    public StringBuilder getBuilder() {
        return this.builder;
    }
    
    @Override
    public String toString() {
        return q.s(this.builder);
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
