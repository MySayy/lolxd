// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.output;

import java.io.IOException;
import q.o.m.s.q;
import java.io.OutputStream;

public class DemuxOutputStream extends OutputStream
{
    private final InheritableThreadLocal<OutputStream> outputStreamThreadLocal;
    
    public DemuxOutputStream() {
        this.outputStreamThreadLocal = new InheritableThreadLocal<OutputStream>();
    }
    
    public OutputStream bindStream(final OutputStream outputStream) {
        final OutputStream outputStream2 = (OutputStream)q.he(this.outputStreamThreadLocal);
        q.hn(this.outputStreamThreadLocal, outputStream);
        return outputStream2;
    }
    
    @Override
    public void close() throws IOException {
        final OutputStream outputStream = (OutputStream)q.he(this.outputStreamThreadLocal);
        try {
            if (null != outputStream) {
                q.pf(outputStream);
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    @Override
    public void flush() throws IOException {
        final OutputStream outputStream = (OutputStream)q.he(this.outputStreamThreadLocal);
        try {
            if (null != outputStream) {
                q.ym(outputStream);
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    @Override
    public void write(final int n) throws IOException {
        final OutputStream outputStream = (OutputStream)q.he(this.outputStreamThreadLocal);
        try {
            if (null != outputStream) {
                q.kq(outputStream, n);
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    private static IOException b(final IOException ex) {
        return ex;
    }
}
