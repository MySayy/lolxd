// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.output;

import java.io.IOException;
import q.o.m.s.q;
import java.io.Writer;
import java.io.FilterWriter;

public class ProxyWriter extends FilterWriter
{
    public ProxyWriter(final Writer out) {
        super(out);
    }
    
    @Override
    public Writer append(final char c) throws IOException {
        try {
            this.beforeWrite(1);
            q.ja(this.out, c);
            this.afterWrite(1);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
        return this;
    }
    
    @Override
    public Writer append(final CharSequence charSequence, final int n, final int n2) throws IOException {
        try {
            this.beforeWrite(n2 - n);
            q.jl(this.out, charSequence, n, n2);
            this.afterWrite(n2 - n);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
        return this;
    }
    
    @Override
    public Writer append(final CharSequence charSequence) throws IOException {
        final int a = ProxyOutputStream.a();
        try {
            int hq = 0;
            Label_0037: {
                CharSequence charSequence2 = null;
                Label_0033: {
                    Label_0022: {
                        try {
                            if (a != 0) {
                                return this;
                            }
                            charSequence2 = charSequence;
                            final CharSequence charSequence3 = charSequence;
                            final int n = a;
                            if (n == 0) {
                                break Label_0022;
                            }
                            break Label_0033;
                        }
                        catch (IOException ex) {
                            throw b(ex);
                        }
                        try {
                            charSequence2 = charSequence;
                            final CharSequence charSequence3 = charSequence;
                            final int n = a;
                            if (n != 0) {
                                break Label_0033;
                            }
                            if (charSequence3 == null) {
                                break Label_0037;
                            }
                        }
                        catch (IOException ex2) {
                            throw b(ex2);
                        }
                    }
                    charSequence2 = charSequence;
                }
                hq = q.hq(charSequence2);
            }
            this.beforeWrite(hq);
            q.ji(this.out, charSequence);
            this.afterWrite(hq);
        }
        catch (IOException ex3) {
            this.handleIOException(ex3);
        }
        return this;
    }
    
    @Override
    public void write(final int n) throws IOException {
        try {
            this.beforeWrite(1);
            q.jg(this.out, n);
            this.afterWrite(1);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
    }
    
    @Override
    public void write(final char[] array) throws IOException {
        final int a = ProxyOutputStream.a();
        try {
            int length = 0;
            Label_0035: {
                char[] array2 = null;
                Label_0033: {
                    Label_0022: {
                        try {
                            if (a != 0) {
                                return;
                            }
                            array2 = array;
                            final char[] array3 = array;
                            final int n = a;
                            if (n == 0) {
                                break Label_0022;
                            }
                            break Label_0033;
                        }
                        catch (IOException ex) {
                            throw b(ex);
                        }
                        try {
                            array2 = array;
                            final char[] array3 = array;
                            final int n = a;
                            if (n != 0) {
                                break Label_0033;
                            }
                            if (array3 == null) {
                                break Label_0035;
                            }
                        }
                        catch (IOException ex2) {
                            throw b(ex2);
                        }
                    }
                    array2 = array;
                }
                length = array2.length;
            }
            this.beforeWrite(length);
            q.yc(this.out, array);
            this.afterWrite(length);
        }
        catch (IOException ex3) {
            this.handleIOException(ex3);
        }
    }
    
    @Override
    public void write(final char[] array, final int n, final int n2) throws IOException {
        try {
            this.beforeWrite(n2);
            q.sb(this.out, array, n, n2);
            this.afterWrite(n2);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
    }
    
    @Override
    public void write(final String s) throws IOException {
        final int a = ProxyOutputStream.a();
        try {
            int q = 0;
            Label_0037: {
                String s2 = null;
                Label_0033: {
                    Label_0022: {
                        try {
                            if (a != 0) {
                                return;
                            }
                            s2 = s;
                            final String s3 = s;
                            final int n = a;
                            if (n == 0) {
                                break Label_0022;
                            }
                            break Label_0033;
                        }
                        catch (IOException ex) {
                            throw b(ex);
                        }
                        try {
                            s2 = s;
                            final String s3 = s;
                            final int n = a;
                            if (n != 0) {
                                break Label_0033;
                            }
                            if (s3 == null) {
                                break Label_0037;
                            }
                        }
                        catch (IOException ex2) {
                            throw b(ex2);
                        }
                    }
                    s2 = s;
                }
                q = q.o.m.s.q.q(s2);
            }
            this.beforeWrite(q);
            q.o.m.s.q.sa(this.out, s);
            this.afterWrite(q);
        }
        catch (IOException ex3) {
            this.handleIOException(ex3);
        }
    }
    
    @Override
    public void write(final String s, final int n, final int n2) throws IOException {
        try {
            this.beforeWrite(n2);
            q.jz(this.out, s, n, n2);
            this.afterWrite(n2);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
    }
    
    @Override
    public void flush() throws IOException {
        try {
            q.jd(this.out);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
    }
    
    @Override
    public void close() throws IOException {
        try {
            q.jb(this.out);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
    }
    
    protected void beforeWrite(final int n) throws IOException {
    }
    
    protected void afterWrite(final int n) throws IOException {
    }
    
    protected void handleIOException(final IOException ex) throws IOException {
        throw ex;
    }
    
    private static IOException b(final IOException ex) {
        return ex;
    }
}
