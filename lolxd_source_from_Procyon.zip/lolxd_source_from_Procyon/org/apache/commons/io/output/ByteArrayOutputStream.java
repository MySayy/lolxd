// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.output;

import java.nio.charset.Charset;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.io.IOException;
import java.io.InputStream;
import com.sun.jna.Structure;
import q.o.m.s.q;
import java.util.ArrayList;
import java.util.List;
import java.io.OutputStream;

public class ByteArrayOutputStream extends OutputStream
{
    private static final byte[] EMPTY_BYTE_ARRAY;
    private final List<byte[]> buffers;
    private int currentBufferIndex;
    private int filledBufferSum;
    private byte[] currentBuffer;
    private int count;
    private boolean reuseBuffers;
    private static final String a;
    
    public ByteArrayOutputStream() {
        this(1024);
    }
    
    public ByteArrayOutputStream(final int n) {
        final int a = ProxyOutputStream.a();
        this.buffers = new ArrayList<byte[]>();
        int n2 = a;
        ByteArrayOutputStream byteArrayOutputStream = null;
        ByteArrayOutputStream byteArrayOutputStream2 = null;
        Label_0072: {
            Label_0039: {
                try {
                    byteArrayOutputStream = this;
                    byteArrayOutputStream2 = this;
                    if (n2 != 0) {
                        break Label_0072;
                    }
                    final boolean b = true;
                    this.reuseBuffers = b;
                    final int n3 = n;
                    if (n3 < 0) {
                        break Label_0039;
                    }
                    break Label_0039;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    final boolean b = true;
                    this.reuseBuffers = b;
                    final int n3 = n;
                    if (n3 < 0) {
                        throw new IllegalArgumentException(q.s(q.qg(q.r(new StringBuilder(), ByteArrayOutputStream.a), n)));
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            byteArrayOutputStream = this;
            byteArrayOutputStream2 = this;
        }
        final ByteArrayOutputStream byteArrayOutputStream3 = byteArrayOutputStream2;
        synchronized (byteArrayOutputStream) {
            this.needNewBuffer(n);
        }
        try {
            if (Structure.b() != 0) {
                ProxyOutputStream.b(++n2);
            }
        }
        catch (IllegalArgumentException ex3) {
            throw b(ex3);
        }
    }
    
    private void needNewBuffer(final int n) {
        final int b = ProxyOutputStream.b();
        int pg = 0;
        Label_0152: {
            int n6 = 0;
            while (true) {
                byte[] currentBuffer = null;
                Label_0121: {
                    Label_0117: {
                        Label_0089: {
                            ByteArrayOutputStream byteArrayOutputStream;
                            while (true) {
                                Label_0084: {
                                    ByteArrayOutputStream byteArrayOutputStream3 = null;
                                    Label_0031: {
                                        try {
                                            byteArrayOutputStream = this;
                                            if (b == 0) {
                                                break Label_0089;
                                            }
                                            final int n2 = this.currentBufferIndex;
                                            final ByteArrayOutputStream byteArrayOutputStream2 = this;
                                            final List<byte[]> list = byteArrayOutputStream2.buffers;
                                            final int n3 = q.kg(list);
                                            final int n4 = 1;
                                            final int n5 = n3 - n4;
                                            if (n2 < n5) {
                                                break Label_0031;
                                            }
                                            break Label_0084;
                                        }
                                        catch (IllegalArgumentException ex) {
                                            throw b(ex);
                                        }
                                        try {
                                            final int n2 = this.currentBufferIndex;
                                            final ByteArrayOutputStream byteArrayOutputStream2 = this;
                                            final List<byte[]> list = byteArrayOutputStream2.buffers;
                                            final int n3 = q.kg(list);
                                            final int n4 = 1;
                                            final int n5 = n3 - n4;
                                            if (n2 >= n5) {
                                                break Label_0084;
                                            }
                                            this.filledBufferSum += this.currentBuffer.length;
                                            ++this.currentBufferIndex;
                                            byteArrayOutputStream3 = this;
                                        }
                                        catch (IllegalArgumentException ex2) {
                                            throw b(ex2);
                                        }
                                    }
                                    byteArrayOutputStream3.currentBuffer = (byte[])q.kz(this.buffers, this.currentBufferIndex);
                                    if (b != 0) {
                                        return;
                                    }
                                }
                                byteArrayOutputStream = this;
                                ByteArrayOutputStream byteArrayOutputStream3 = this;
                                if (b == 0) {
                                    continue;
                                }
                                break;
                            }
                            try {
                                currentBuffer = byteArrayOutputStream.currentBuffer;
                                if (b == 0) {
                                    break Label_0121;
                                }
                                if (currentBuffer != null) {
                                    break Label_0117;
                                }
                            }
                            catch (IllegalArgumentException ex3) {
                                throw b(ex3);
                            }
                        }
                        pg = n;
                        final ByteArrayOutputStream byteArrayOutputStream4 = this;
                        byteArrayOutputStream4.filledBufferSum = n6;
                        if (b != 0) {
                            break Label_0152;
                        }
                    }
                    final byte[] currentBuffer2 = this.currentBuffer;
                }
                pg = q.pg(currentBuffer.length << 1, n - this.filledBufferSum);
                final ByteArrayOutputStream byteArrayOutputStream4 = this;
                n6 = this.filledBufferSum + this.currentBuffer.length;
                if (b == 0) {
                    continue;
                }
                break;
            }
            this.filledBufferSum = n6;
        }
        ++this.currentBufferIndex;
        this.currentBuffer = new byte[pg];
        q.qw(this.buffers, this.currentBuffer);
    }
    
    @Override
    public void write(final byte[] p0, final int p1, final int p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore          4
        //     5: iload_2        
        //     6: iload           4
        //     8: ifne            34
        //    11: iload           4
        //    13: ifne            39
        //    16: goto            23
        //    19: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    22: athrow         
        //    23: iflt            162
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    32: athrow         
        //    33: iload_2        
        //    34: iload           4
        //    36: ifne            71
        //    39: iload           4
        //    41: ifne            76
        //    44: goto            51
        //    47: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    50: athrow         
        //    51: aload_1        
        //    52: arraylength    
        //    53: if_icmpgt       162
        //    56: goto            63
        //    59: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    62: athrow         
        //    63: iload_3        
        //    64: goto            71
        //    67: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    70: athrow         
        //    71: iload           4
        //    73: ifne            108
        //    76: iload           4
        //    78: ifne            108
        //    81: goto            88
        //    84: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    87: athrow         
        //    88: iflt            162
        //    91: goto            98
        //    94: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    97: athrow         
        //    98: iload_2        
        //    99: iload_3        
        //   100: iadd           
        //   101: goto            108
        //   104: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   107: athrow         
        //   108: aload_1        
        //   109: arraylength    
        //   110: iload           4
        //   112: ifne            146
        //   115: iload           4
        //   117: ifne            146
        //   120: goto            127
        //   123: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   126: athrow         
        //   127: if_icmpgt       162
        //   130: goto            137
        //   133: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   136: athrow         
        //   137: iload_2        
        //   138: iload_3        
        //   139: goto            146
        //   142: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   145: athrow         
        //   146: iadd           
        //   147: iload           4
        //   149: ifne            175
        //   152: ifge            174
        //   155: goto            162
        //   158: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   161: athrow         
        //   162: new             Ljava/lang/IndexOutOfBoundsException;
        //   165: dup            
        //   166: invokespecial   java/lang/IndexOutOfBoundsException.<init>:()V
        //   169: athrow         
        //   170: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   173: athrow         
        //   174: iload_3        
        //   175: ifne            179
        //   178: return         
        //   179: aload_0        
        //   180: dup            
        //   181: astore          5
        //   183: monitorenter   
        //   184: aload_0        
        //   185: getfield        org/apache/commons/io/output/ByteArrayOutputStream.count:I
        //   188: iload_3        
        //   189: iadd           
        //   190: istore          6
        //   192: iload_3        
        //   193: istore          7
        //   195: aload_0        
        //   196: getfield        org/apache/commons/io/output/ByteArrayOutputStream.count:I
        //   199: aload_0        
        //   200: getfield        org/apache/commons/io/output/ByteArrayOutputStream.filledBufferSum:I
        //   203: isub           
        //   204: istore          8
        //   206: iload           7
        //   208: ifle            313
        //   211: iload           7
        //   213: aload_0        
        //   214: getfield        org/apache/commons/io/output/ByteArrayOutputStream.currentBuffer:[B
        //   217: arraylength    
        //   218: iload           8
        //   220: isub           
        //   221: invokestatic    q/o/m/s/q.px:(II)I
        //   224: istore          9
        //   226: aload_1        
        //   227: iload_2        
        //   228: iload_3        
        //   229: iadd           
        //   230: iload           7
        //   232: isub           
        //   233: aload_0        
        //   234: getfield        org/apache/commons/io/output/ByteArrayOutputStream.currentBuffer:[B
        //   237: iload           8
        //   239: iload           9
        //   241: invokestatic    q/o/m/s/q.st:(Ljava/lang/Object;ILjava/lang/Object;II)V
        //   244: iload           7
        //   246: iload           9
        //   248: isub           
        //   249: istore          7
        //   251: iload           4
        //   253: ifne            322
        //   256: iload           7
        //   258: iload           4
        //   260: ifne            306
        //   263: goto            270
        //   266: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   269: athrow         
        //   270: iload           4
        //   272: ifne            306
        //   275: goto            282
        //   278: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   281: athrow         
        //   282: ifle            308
        //   285: goto            292
        //   288: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   291: athrow         
        //   292: aload_0        
        //   293: iload           6
        //   295: invokespecial   org/apache/commons/io/output/ByteArrayOutputStream.needNewBuffer:(I)V
        //   298: iconst_0       
        //   299: goto            306
        //   302: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   305: athrow         
        //   306: istore          8
        //   308: iload           4
        //   310: ifeq            206
        //   313: aload_0        
        //   314: iload           6
        //   316: putfield        org/apache/commons/io/output/ByteArrayOutputStream.count:I
        //   319: aload           5
        //   321: monitorexit    
        //   322: goto            333
        //   325: astore          10
        //   327: aload           5
        //   329: monitorexit    
        //   330: aload           10
        //   332: athrow         
        //   333: return         
        //    StackMapTable: 00 2D FF 00 13 00 05 07 00 02 07 00 5D 01 01 01 00 01 07 00 1A 43 01 45 07 00 1A 03 40 01 44 01 47 07 00 1A 43 01 47 07 00 1A 03 43 07 00 1A 43 01 44 01 47 07 00 1A 43 01 45 07 00 1A 03 45 07 00 1A 43 01 4E 07 00 1A FF 00 03 00 05 07 00 02 07 00 5D 01 01 01 00 02 01 01 45 07 00 1A 03 44 07 00 1A FF 00 03 00 05 07 00 02 07 00 5D 01 01 01 00 02 01 01 4B 07 00 1A 03 47 07 00 1A 03 40 01 03 FF 00 1A 00 09 07 00 02 07 00 5D 01 01 01 07 00 02 01 01 01 00 00 FF 00 3B 00 0A 07 00 02 07 00 5D 01 01 01 07 00 02 01 01 01 01 00 01 07 00 1A 43 01 47 07 00 1A 43 01 45 07 00 1A 03 49 07 00 1A 43 01 01 FA 00 04 08 FF 00 02 00 06 07 00 02 07 00 5D 01 01 01 07 00 02 00 01 07 00 47 07
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  282    299    302    306    Ljava/lang/IllegalArgumentException;
        //  270    285    288    292    Ljava/lang/IllegalArgumentException;
        //  256    275    278    282    Ljava/lang/IllegalArgumentException;
        //  251    263    266    270    Ljava/lang/IllegalArgumentException;
        //  152    170    170    174    Ljava/lang/IllegalArgumentException;
        //  146    155    158    162    Ljava/lang/IllegalArgumentException;
        //  127    139    142    146    Ljava/lang/IllegalArgumentException;
        //  115    130    133    137    Ljava/lang/IllegalArgumentException;
        //  108    120    123    127    Ljava/lang/IllegalArgumentException;
        //  88     101    104    108    Ljava/lang/IllegalArgumentException;
        //  76     91     94     98     Ljava/lang/IllegalArgumentException;
        //  71     81     84     88     Ljava/lang/IllegalArgumentException;
        //  51     64     67     71     Ljava/lang/IllegalArgumentException;
        //  39     56     59     63     Ljava/lang/IllegalArgumentException;
        //  34     44     47     51     Ljava/lang/IllegalArgumentException;
        //  11     26     29     33     Ljava/lang/IllegalArgumentException;
        //  5      16     19     23     Ljava/lang/IllegalArgumentException;
        //  184    322    325    333    Any
        //  325    330    325    333    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0039:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public synchronized void write(final int n) {
        final int b = ProxyOutputStream.b();
        int n2 = this.count - this.filledBufferSum;
        final int n3 = b;
        while (true) {
            Label_0053: {
                Label_0034: {
                    try {
                        if (n3 == 0) {
                            return;
                        }
                        final int n4 = n2;
                        final ByteArrayOutputStream byteArrayOutputStream = this;
                        final byte[] array = byteArrayOutputStream.currentBuffer;
                        final int n5 = array.length;
                        if (n4 == n5) {
                            break Label_0034;
                        }
                        break Label_0053;
                    }
                    catch (IllegalArgumentException ex) {
                        throw b(ex);
                    }
                    try {
                        final int n4 = n2;
                        final ByteArrayOutputStream byteArrayOutputStream = this;
                        final byte[] array = byteArrayOutputStream.currentBuffer;
                        final int n5 = array.length;
                        if (n4 != n5) {
                            break Label_0053;
                        }
                        this.needNewBuffer(this.count + 1);
                    }
                    catch (IllegalArgumentException ex2) {
                        throw b(ex2);
                    }
                }
                n2 = 0;
            }
            this.currentBuffer[n2] = (byte)n;
            ++this.count;
            if (n3 == 0) {
                continue;
            }
            break;
        }
    }
    
    public synchronized int write(final InputStream p0) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: istore_3       
        //     2: invokestatic    org/apache/commons/io/output/ProxyOutputStream.a:()I
        //     5: istore_2       
        //     6: aload_0        
        //     7: getfield        org/apache/commons/io/output/ByteArrayOutputStream.count:I
        //    10: aload_0        
        //    11: getfield        org/apache/commons/io/output/ByteArrayOutputStream.filledBufferSum:I
        //    14: isub           
        //    15: istore          4
        //    17: aload_1        
        //    18: aload_0        
        //    19: getfield        org/apache/commons/io/output/ByteArrayOutputStream.currentBuffer:[B
        //    22: iload           4
        //    24: aload_0        
        //    25: getfield        org/apache/commons/io/output/ByteArrayOutputStream.currentBuffer:[B
        //    28: arraylength    
        //    29: iload           4
        //    31: isub           
        //    32: invokestatic    q/o/m/s/q.yn:(Ljava/io/InputStream;[BII)I
        //    35: istore          5
        //    37: iload           5
        //    39: iconst_m1      
        //    40: if_icmpeq       145
        //    43: iload_3        
        //    44: iload           5
        //    46: iadd           
        //    47: istore_3       
        //    48: iload           4
        //    50: iload           5
        //    52: iadd           
        //    53: istore          4
        //    55: aload_0        
        //    56: dup            
        //    57: getfield        org/apache/commons/io/output/ByteArrayOutputStream.count:I
        //    60: iload           5
        //    62: iadd           
        //    63: putfield        org/apache/commons/io/output/ByteArrayOutputStream.count:I
        //    66: iload           4
        //    68: iload_2        
        //    69: ifne            146
        //    72: iload_2        
        //    73: ifne            135
        //    76: goto            83
        //    79: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    82: athrow         
        //    83: aload_0        
        //    84: getfield        org/apache/commons/io/output/ByteArrayOutputStream.currentBuffer:[B
        //    87: arraylength    
        //    88: if_icmpne       117
        //    91: goto            98
        //    94: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    97: athrow         
        //    98: aload_0        
        //    99: aload_0        
        //   100: getfield        org/apache/commons/io/output/ByteArrayOutputStream.currentBuffer:[B
        //   103: arraylength    
        //   104: invokespecial   org/apache/commons/io/output/ByteArrayOutputStream.needNewBuffer:(I)V
        //   107: goto            114
        //   110: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   113: athrow         
        //   114: iconst_0       
        //   115: istore          4
        //   117: aload_1        
        //   118: aload_0        
        //   119: getfield        org/apache/commons/io/output/ByteArrayOutputStream.currentBuffer:[B
        //   122: iload           4
        //   124: aload_0        
        //   125: getfield        org/apache/commons/io/output/ByteArrayOutputStream.currentBuffer:[B
        //   128: arraylength    
        //   129: iload           4
        //   131: isub           
        //   132: invokestatic    q/o/m/s/q.yn:(Ljava/io/InputStream;[BII)I
        //   135: istore          5
        //   137: iload_2        
        //   138: ifne            114
        //   141: iload_2        
        //   142: ifeq            37
        //   145: iload_3        
        //   146: ireturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 0B FF 00 25 00 06 07 00 02 07 00 7C 01 01 01 01 00 00 69 07 00 76 43 01 4A 07 00 76 03 4B 07 00 76 03 02 51 01 09 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  55     76     79     83     Ljava/io/IOException;
        //  72     91     94     98     Ljava/io/IOException;
        //  83     107    110    114    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0083:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public synchronized int size() {
        return this.count;
    }
    
    @Override
    public void close() throws IOException {
    }
    
    public synchronized void reset() {
        final int b = ProxyOutputStream.b();
        this.count = 0;
        final int n = b;
        while (true) {
            int n3 = 0;
            Label_0076: {
                Label_0059: {
                    try {
                        this.filledBufferSum = 0;
                        this.currentBufferIndex = 0;
                        final int n2 = n3 = (this.reuseBuffers ? 1 : 0);
                        if (n == 0) {
                            break Label_0076;
                        }
                        if (n2 == 0) {
                            break Label_0059;
                        }
                    }
                    catch (IllegalArgumentException ex) {
                        throw b(ex);
                    }
                    final ByteArrayOutputStream byteArrayOutputStream = this;
                    byteArrayOutputStream.currentBuffer = (byte[])q.kz(this.buffers, this.currentBufferIndex);
                    if (n != 0) {
                        return;
                    }
                }
                this.currentBuffer = null;
                n3 = ((byte[])q.kz(this.buffers, 0)).length;
            }
            final int n4 = n3;
            q.cx(this.buffers);
            this.needNewBuffer(n4);
            final ByteArrayOutputStream byteArrayOutputStream = this;
            if (n == 0) {
                continue;
            }
            break;
        }
        this.reuseBuffers = true;
    }
    
    public synchronized void writeTo(final OutputStream outputStream) throws IOException {
        final int a = ProxyOutputStream.a();
        int count = this.count;
        final int n = a;
        final Iterator rs = q.rs(this.buffers);
        while (q.oi(rs)) {
            final byte[] array = (byte[])q.ou(rs);
            final int px = q.px(array.length, count);
            q.sz(outputStream, array, 0, px);
            count -= px;
            Label_0074: {
                try {
                    if (count != 0) {
                        break Label_0074;
                    }
                    final int n2 = n;
                    if (n2 != 0) {
                        break Label_0074;
                    }
                    break;
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                try {
                    final int n2 = n;
                    if (n2 != 0) {
                        if (n == 0) {
                            continue;
                        }
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            break;
        }
    }
    
    public static InputStream toBufferedInputStream(final InputStream inputStream) throws IOException {
        return toBufferedInputStream(inputStream, 1024);
    }
    
    public static InputStream toBufferedInputStream(final InputStream inputStream, final int n) throws IOException {
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(n);
        byteArrayOutputStream.write(inputStream);
        return byteArrayOutputStream.toInputStream();
    }
    
    public synchronized InputStream toInputStream() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: getfield        org/apache/commons/io/output/ByteArrayOutputStream.count:I
        //     7: istore_2       
        //     8: istore_1       
        //     9: iload_2        
        //    10: ifne            25
        //    13: new             Lorg/apache/commons/io/input/ClosedInputStream;
        //    16: dup            
        //    17: invokespecial   org/apache/commons/io/input/ClosedInputStream.<init>:()V
        //    20: areturn        
        //    21: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    24: athrow         
        //    25: new             Ljava/util/ArrayList;
        //    28: dup            
        //    29: aload_0        
        //    30: getfield        org/apache/commons/io/output/ByteArrayOutputStream.buffers:Ljava/util/List;
        //    33: invokestatic    q/o/m/s/q.kg:(Ljava/util/List;)I
        //    36: invokespecial   java/util/ArrayList.<init>:(I)V
        //    39: astore_3       
        //    40: aload_0        
        //    41: getfield        org/apache/commons/io/output/ByteArrayOutputStream.buffers:Ljava/util/List;
        //    44: invokestatic    q/o/m/s/q.rs:(Ljava/util/List;)Ljava/util/Iterator;
        //    47: astore          4
        //    49: aload           4
        //    51: invokestatic    q/o/m/s/q.oi:(Ljava/util/Iterator;)Z
        //    54: ifeq            135
        //    57: aload           4
        //    59: invokestatic    q/o/m/s/q.ou:(Ljava/util/Iterator;)Ljava/lang/Object;
        //    62: checkcast       [B
        //    65: astore          5
        //    67: aload           5
        //    69: arraylength    
        //    70: iload_2        
        //    71: invokestatic    q/o/m/s/q.px:(II)I
        //    74: istore          6
        //    76: aload_3        
        //    77: new             Ljava/io/ByteArrayInputStream;
        //    80: dup            
        //    81: aload           5
        //    83: iconst_0       
        //    84: iload           6
        //    86: invokespecial   java/io/ByteArrayInputStream.<init>:([BII)V
        //    89: invokestatic    q/o/m/s/q.qw:(Ljava/util/List;Ljava/lang/Object;)Z
        //    92: pop            
        //    93: iload_2        
        //    94: iload           6
        //    96: isub           
        //    97: istore_2       
        //    98: iload_1        
        //    99: ifeq            140
        //   102: iload_2        
        //   103: ifne            124
        //   106: goto            113
        //   109: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   112: athrow         
        //   113: iload_1        
        //   114: ifne            135
        //   117: goto            124
        //   120: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   123: athrow         
        //   124: iload_1        
        //   125: ifne            49
        //   128: goto            135
        //   131: invokestatic    org/apache/commons/io/output/ByteArrayOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   134: athrow         
        //   135: aload_0        
        //   136: iconst_0       
        //   137: putfield        org/apache/commons/io/output/ByteArrayOutputStream.reuseBuffers:Z
        //   140: new             Ljava/io/SequenceInputStream;
        //   143: dup            
        //   144: aload_3        
        //   145: invokestatic    q/o/m/s/q.jh:(Ljava/util/Collection;)Ljava/util/Enumeration;
        //   148: invokespecial   java/io/SequenceInputStream.<init>:(Ljava/util/Enumeration;)V
        //   151: areturn        
        //    StackMapTable: 00 0A FF 00 15 00 03 07 00 02 01 01 00 01 07 00 1A 03 FD 00 17 07 00 23 07 00 8B FF 00 3B 00 07 07 00 02 01 01 07 00 23 07 00 8B 07 00 5D 01 00 01 07 00 1A 03 46 07 00 1A 03 46 07 00 1A F9 00 03 04
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  9      21     21     25     Ljava/lang/IllegalArgumentException;
        //  98     106    109    113    Ljava/lang/IllegalArgumentException;
        //  102    117    120    124    Ljava/lang/IllegalArgumentException;
        //  113    128    131    135    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0113:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public synchronized byte[] toByteArray() {
        int count = this.count;
        final int a = ProxyOutputStream.a();
        int n = 0;
        Label_0028: {
            try {
                n = count;
                if (a != 0) {
                    break Label_0028;
                }
                if (n != 0) {
                    break Label_0028;
                }
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            final byte[] empty_BYTE_ARRAY = ByteArrayOutputStream.EMPTY_BYTE_ARRAY;
            return;
        }
        final byte[] array = new byte[n];
        if (a == 0) {
            final byte[] array2 = array;
            int n2 = 0;
            final Iterator rs = q.rs(this.buffers);
            byte[] array4 = null;
            while (q.oi(rs)) {
                final byte[] array3 = (byte[])q.ou(rs);
                final int px = q.px(array3.length, count);
                array4 = array3;
                if (a == 0) {
                    q.st(array4, 0, array2, n2, px);
                    n2 += px;
                    count -= px;
                    Label_0117: {
                        try {
                            if (count != 0) {
                                break Label_0117;
                            }
                            final int n3 = a;
                            if (n3 != 0) {
                                break Label_0117;
                            }
                            break;
                        }
                        catch (IllegalArgumentException ex2) {
                            throw b(ex2);
                        }
                        try {
                            final int n3 = a;
                            if (n3 != 0) {
                                if (a == 0) {
                                    continue;
                                }
                            }
                        }
                        catch (IllegalArgumentException ex3) {
                            throw b(ex3);
                        }
                    }
                    break;
                }
                return array4;
            }
            return array4;
        }
        return array;
    }
    
    @Deprecated
    @Override
    public String toString() {
        return new String(this.toByteArray(), q.sx());
    }
    
    public String toString(final String charsetName) throws UnsupportedEncodingException {
        return new String(this.toByteArray(), charsetName);
    }
    
    public String toString(final Charset charset) {
        return new String(this.toByteArray(), charset);
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 2);
        final char[] g = q.g(n.d.a.d.q.tr());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 44;
                            break;
                        }
                        case 1: {
                            n5 = 30;
                            break;
                        }
                        case 2: {
                            n5 = 120;
                            break;
                        }
                        case 3: {
                            n5 = 112;
                            break;
                        }
                        case 4: {
                            n5 = 23;
                            break;
                        }
                        case 5: {
                            n5 = 111;
                            break;
                        }
                        default: {
                            n5 = 11;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.z(new String(g));
                EMPTY_BYTE_ARRAY = new byte[0];
                return;
            }
            continue;
        }
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
}
