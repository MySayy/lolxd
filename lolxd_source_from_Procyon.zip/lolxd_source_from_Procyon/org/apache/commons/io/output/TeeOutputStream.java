// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.output;

import java.io.IOException;
import q.o.m.s.q;
import java.io.OutputStream;

public class TeeOutputStream extends ProxyOutputStream
{
    protected OutputStream branch;
    
    public TeeOutputStream(final OutputStream outputStream, final OutputStream branch) {
        super(outputStream);
        this.branch = branch;
    }
    
    @Override
    public synchronized void write(final byte[] array) throws IOException {
        super.write(array);
        q.sj(this.branch, array);
    }
    
    @Override
    public synchronized void write(final byte[] array, final int n, final int n2) throws IOException {
        super.write(array, n, n2);
        q.sz(this.branch, array, n, n2);
    }
    
    @Override
    public synchronized void write(final int n) throws IOException {
        super.write(n);
        q.kq(this.branch, n);
    }
    
    @Override
    public void flush() throws IOException {
        super.flush();
        q.ym(this.branch);
    }
    
    @Override
    public void close() throws IOException {
        try {
            super.close();
        }
        finally {
            q.pf(this.branch);
        }
    }
}
