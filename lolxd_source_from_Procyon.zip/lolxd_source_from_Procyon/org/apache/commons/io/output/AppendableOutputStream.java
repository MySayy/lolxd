// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.output;

import java.io.IOException;
import q.o.m.s.q;
import java.io.OutputStream;

public class AppendableOutputStream<T extends Appendable> extends OutputStream
{
    private final T appendable;
    
    public AppendableOutputStream(final T appendable) {
        this.appendable = appendable;
    }
    
    @Override
    public void write(final int n) throws IOException {
        q.jx(this.appendable, (char)n);
    }
    
    public T getAppendable() {
        return this.appendable;
    }
}
