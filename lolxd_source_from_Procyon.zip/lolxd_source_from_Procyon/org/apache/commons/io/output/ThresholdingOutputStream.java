// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.output;

import java.io.IOException;
import q.o.m.s.q;
import java.io.OutputStream;

public abstract class ThresholdingOutputStream extends OutputStream
{
    private final int threshold;
    private long written;
    private boolean thresholdExceeded;
    
    public ThresholdingOutputStream(final int threshold) {
        this.threshold = threshold;
    }
    
    @Override
    public void write(final int n) throws IOException {
        this.checkThreshold(1);
        q.kq(this.getStream(), n);
        ++this.written;
    }
    
    @Override
    public void write(final byte[] array) throws IOException {
        this.checkThreshold(array.length);
        q.sj(this.getStream(), array);
        this.written += array.length;
    }
    
    @Override
    public void write(final byte[] array, final int n, final int n2) throws IOException {
        this.checkThreshold(n2);
        q.sz(this.getStream(), array, n, n2);
        this.written += n2;
    }
    
    @Override
    public void flush() throws IOException {
        q.ym(this.getStream());
    }
    
    @Override
    public void close() throws IOException {
        try {
            this.flush();
        }
        catch (IOException ex) {}
        q.pf(this.getStream());
    }
    
    public int getThreshold() {
        return this.threshold;
    }
    
    public long getByteCount() {
        return this.written;
    }
    
    public boolean isThresholdExceeded() {
        final int b = ProxyOutputStream.b();
        long n = 0L;
        Label_0043: {
            Label_0029: {
                try {
                    n = lcmp(this.written, (long)this.threshold);
                    if (b == 0) {
                        return n != 0L;
                    }
                    final int n2 = b;
                    if (n2 != 0) {
                        break Label_0029;
                    }
                    return n != 0L;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final int n2 = b;
                    if (n2 == 0) {
                        return n != 0L;
                    }
                    if (n <= 0) {
                        break Label_0043;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            return n != 0L;
        }
        return n != 0L;
    }
    
    protected void checkThreshold(final int p0) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: getfield        org/apache/commons/io/output/ThresholdingOutputStream.thresholdExceeded:Z
        //     8: iload_2        
        //     9: ifeq            75
        //    12: iload_2        
        //    13: ifeq            75
        //    16: goto            23
        //    19: invokestatic    org/apache/commons/io/output/ThresholdingOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    22: athrow         
        //    23: ifne            94
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/output/ThresholdingOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    32: athrow         
        //    33: aload_0        
        //    34: iload_2        
        //    35: ifeq            91
        //    38: goto            45
        //    41: invokestatic    org/apache/commons/io/output/ThresholdingOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    44: athrow         
        //    45: iload_2        
        //    46: ifeq            91
        //    49: goto            56
        //    52: invokestatic    org/apache/commons/io/output/ThresholdingOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    55: athrow         
        //    56: getfield        org/apache/commons/io/output/ThresholdingOutputStream.written:J
        //    59: iload_1        
        //    60: i2l            
        //    61: ladd           
        //    62: aload_0        
        //    63: getfield        org/apache/commons/io/output/ThresholdingOutputStream.threshold:I
        //    66: i2l            
        //    67: lcmp           
        //    68: goto            75
        //    71: invokestatic    org/apache/commons/io/output/ThresholdingOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    74: athrow         
        //    75: ifle            94
        //    78: aload_0        
        //    79: iconst_1       
        //    80: putfield        org/apache/commons/io/output/ThresholdingOutputStream.thresholdExceeded:Z
        //    83: aload_0        
        //    84: goto            91
        //    87: invokestatic    org/apache/commons/io/output/ThresholdingOutputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    90: athrow         
        //    91: invokevirtual   org/apache/commons/io/output/ThresholdingOutputStream.thresholdReached:()V
        //    94: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 0D FF 00 13 00 03 07 00 02 01 01 00 01 07 00 15 43 01 45 07 00 15 03 47 07 00 15 43 07 00 02 46 07 00 15 43 07 00 02 4E 07 00 15 43 01 4B 07 00 15 43 07 00 02 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      16     19     23     Ljava/io/IOException;
        //  12     26     29     33     Ljava/io/IOException;
        //  23     38     41     45     Ljava/io/IOException;
        //  33     49     52     56     Ljava/io/IOException;
        //  45     68     71     75     Ljava/io/IOException;
        //  75     84     87     91     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0023:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    protected void resetByteCount() {
        this.thresholdExceeded = false;
        this.written = 0L;
    }
    
    protected void setByteCount(final long written) {
        this.written = written;
    }
    
    protected abstract OutputStream getStream() throws IOException;
    
    protected abstract void thresholdReached() throws IOException;
    
    private static Exception b(final Exception ex) {
        return ex;
    }
}
