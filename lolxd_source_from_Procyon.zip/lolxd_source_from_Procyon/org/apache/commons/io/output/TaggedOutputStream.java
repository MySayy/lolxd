// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.output;

import java.io.IOException;
import org.apache.commons.io.TaggedIOException;
import q.o.m.s.q;
import java.io.OutputStream;
import java.io.Serializable;

public class TaggedOutputStream extends ProxyOutputStream
{
    private final Serializable tag;
    
    public TaggedOutputStream(final OutputStream outputStream) {
        super(outputStream);
        this.tag = q.hu();
    }
    
    public boolean isCauseOf(final Exception ex) {
        return TaggedIOException.isTaggedWith(ex, this.tag);
    }
    
    public void throwIfCauseOf(final Exception ex) throws IOException {
        TaggedIOException.throwCauseIfTaggedWith(ex, this.tag);
    }
    
    @Override
    protected void handleIOException(final IOException ex) throws IOException {
        throw new TaggedIOException(ex, this.tag);
    }
}
