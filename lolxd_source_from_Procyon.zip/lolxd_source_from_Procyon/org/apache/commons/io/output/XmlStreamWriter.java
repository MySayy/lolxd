// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.output;

import org.apache.commons.io.input.XmlStreamReader;
import q.o.m.s.q;
import java.io.OutputStreamWriter;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.File;
import java.util.regex.Pattern;
import java.io.StringWriter;
import java.io.OutputStream;
import java.io.Writer;

public class XmlStreamWriter extends Writer
{
    private static final int BUFFER_SIZE = 4096;
    private final OutputStream out;
    private final String defaultEncoding;
    private StringWriter xmlPrologWriter;
    private Writer writer;
    private String encoding;
    static final Pattern ENCODING_PATTERN;
    private static final String[] a;
    private static final String[] b;
    
    public XmlStreamWriter(final OutputStream outputStream) {
        this(outputStream, null);
    }
    
    public XmlStreamWriter(final OutputStream out, final String s) {
        final int b = ProxyOutputStream.b();
        final int n = b;
        String a = null;
        Label_0067: {
            Label_0058: {
                Label_0055: {
                    Label_0044: {
                        try {
                            this.xmlPrologWriter = new StringWriter(4096);
                            this.out = out;
                            a = s;
                            if (n == 0) {
                                break Label_0055;
                            }
                            final int n2 = n;
                            if (n2 != 0) {
                                break Label_0044;
                            }
                            break Label_0055;
                        }
                        catch (RuntimeException ex) {
                            throw b(ex);
                        }
                        try {
                            final int n2 = n;
                            if (n2 == 0) {
                                break Label_0055;
                            }
                            if (s == null) {
                                break Label_0058;
                            }
                        }
                        catch (RuntimeException ex2) {
                            throw b(ex2);
                        }
                    }
                    a = s;
                }
                break Label_0067;
            }
            a = a(18495, 17596);
        }
        this.defaultEncoding = a;
    }
    
    public XmlStreamWriter(final File file) throws FileNotFoundException {
        this(file, null);
    }
    
    public XmlStreamWriter(final File file, final String s) throws FileNotFoundException {
        this(new FileOutputStream(file), s);
    }
    
    public String getEncoding() {
        return this.encoding;
    }
    
    public String getDefaultEncoding() {
        return this.defaultEncoding;
    }
    
    @Override
    public void close() throws IOException {
        final int b = ProxyOutputStream.b();
        while (true) {
            Writer writer2 = null;
            Label_0074: {
                Label_0070: {
                    Label_0022: {
                        Writer writer;
                        try {
                            writer = (writer2 = this.writer);
                            if (b == 0) {
                                break Label_0074;
                            }
                            if (writer == null) {
                                break Label_0022;
                            }
                            break Label_0070;
                        }
                        catch (IOException ex) {
                            throw b(ex);
                        }
                        try {
                            if (writer != null) {
                                break Label_0070;
                            }
                            this.encoding = this.defaultEncoding;
                            this.writer = new OutputStreamWriter(this.out, this.encoding);
                        }
                        catch (IOException ex2) {
                            throw b(ex2);
                        }
                    }
                    q.sa(this.writer, q.gn(this.xmlPrologWriter));
                }
                writer2 = this.writer;
            }
            q.jb(writer2);
            if (b != 0) {
                return;
            }
            continue;
        }
    }
    
    @Override
    public void flush() throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: getfield        org/apache/commons/io/output/XmlStreamWriter.writer:Ljava/io/Writer;
        //     8: iload_1        
        //     9: ifeq            44
        //    12: iload_1        
        //    13: ifeq            44
        //    16: goto            23
        //    19: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    22: athrow         
        //    23: ifnull          47
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    32: athrow         
        //    33: aload_0        
        //    34: getfield        org/apache/commons/io/output/XmlStreamWriter.writer:Ljava/io/Writer;
        //    37: goto            44
        //    40: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    43: athrow         
        //    44: invokestatic    q/o/m/s/q.jd:(Ljava/io/Writer;)V
        //    47: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 07 53 07 00 4C 43 07 00 04 45 07 00 4C 03 46 07 00 4C 43 07 00 04 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      16     19     23     Ljava/io/IOException;
        //  12     26     29     33     Ljava/io/IOException;
        //  23     37     40     44     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0023:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void detectEncoding(final char[] p0, final int p1, final int p2) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: iload_3        
        //     4: istore          5
        //     6: istore          4
        //     8: aload_0        
        //     9: getfield        org/apache/commons/io/output/XmlStreamWriter.xmlPrologWriter:Ljava/io/StringWriter;
        //    12: invokestatic    q/o/m/s/q.gp:(Ljava/io/StringWriter;)Ljava/lang/StringBuffer;
        //    15: astore          6
        //    17: aload           6
        //    19: invokestatic    q/o/m/s/q.gy:(Ljava/lang/StringBuffer;)I
        //    22: iload_3        
        //    23: iadd           
        //    24: sipush          4096
        //    27: iload           4
        //    29: ifeq            106
        //    32: if_icmple       60
        //    35: goto            42
        //    38: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    41: athrow         
        //    42: sipush          4096
        //    45: aload           6
        //    47: invokestatic    q/o/m/s/q.gy:(Ljava/lang/StringBuffer;)I
        //    50: goto            57
        //    53: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    56: athrow         
        //    57: isub           
        //    58: istore          5
        //    60: aload_0        
        //    61: getfield        org/apache/commons/io/output/XmlStreamWriter.xmlPrologWriter:Ljava/io/StringWriter;
        //    64: aload_1        
        //    65: iload_2        
        //    66: iload           5
        //    68: invokestatic    q/o/m/s/q.gc:(Ljava/io/StringWriter;[CII)V
        //    71: aload           6
        //    73: invokestatic    q/o/m/s/q.gy:(Ljava/lang/StringBuffer;)I
        //    76: iload           4
        //    78: ifeq            134
        //    81: iload           4
        //    83: ifeq            139
        //    86: goto            93
        //    89: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    92: athrow         
        //    93: iconst_5       
        //    94: iload           4
        //    96: ifeq            57
        //    99: goto            106
        //   102: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   105: athrow         
        //   106: if_icmplt       488
        //   109: aload           6
        //   111: iconst_0       
        //   112: iconst_5       
        //   113: invokestatic    q/o/m/s/q.gx:(Ljava/lang/StringBuffer;II)Ljava/lang/String;
        //   116: sipush          18493
        //   119: bipush          95
        //   121: invokestatic    org/apache/commons/io/output/XmlStreamWriter.a:(II)Ljava/lang/String;
        //   124: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   127: goto            134
        //   130: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   133: athrow         
        //   134: iload           4
        //   136: ifeq            182
        //   139: iload           4
        //   141: ifeq            182
        //   144: goto            151
        //   147: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   150: athrow         
        //   151: ifeq            346
        //   154: goto            161
        //   157: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   160: athrow         
        //   161: aload           6
        //   163: sipush          18494
        //   166: sipush          -21017
        //   169: invokestatic    org/apache/commons/io/output/XmlStreamWriter.a:(II)Ljava/lang/String;
        //   172: invokestatic    q/o/m/s/q.gh:(Ljava/lang/StringBuffer;Ljava/lang/String;)I
        //   175: goto            182
        //   178: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   181: athrow         
        //   182: istore          7
        //   184: iload           7
        //   186: iload           4
        //   188: ifeq            320
        //   191: ifle            308
        //   194: goto            201
        //   197: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   200: athrow         
        //   201: getstatic       org/apache/commons/io/output/XmlStreamWriter.ENCODING_PATTERN:Ljava/util/regex/Pattern;
        //   204: aload           6
        //   206: iconst_0       
        //   207: iload           7
        //   209: invokestatic    q/o/m/s/q.gx:(Ljava/lang/StringBuffer;II)Ljava/lang/String;
        //   212: invokestatic    q/o/m/s/q.cu:(Ljava/util/regex/Pattern;Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
        //   215: astore          8
        //   217: iload           4
        //   219: ifeq            278
        //   222: aload           8
        //   224: invokestatic    q/o/m/s/q.js:(Ljava/util/regex/Matcher;)Z
        //   227: ifeq            283
        //   230: goto            237
        //   233: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   236: athrow         
        //   237: aload_0        
        //   238: aload           8
        //   240: iconst_1       
        //   241: invokestatic    q/o/m/s/q.jk:(Ljava/util/regex/Matcher;I)Ljava/lang/String;
        //   244: invokestatic    q/o/m/s/q.sn:(Ljava/lang/String;)Ljava/lang/String;
        //   247: putfield        org/apache/commons/io/output/XmlStreamWriter.encoding:Ljava/lang/String;
        //   250: aload_0        
        //   251: aload_0        
        //   252: getfield        org/apache/commons/io/output/XmlStreamWriter.encoding:Ljava/lang/String;
        //   255: iconst_1       
        //   256: aload_0        
        //   257: getfield        org/apache/commons/io/output/XmlStreamWriter.encoding:Ljava/lang/String;
        //   260: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //   263: iconst_1       
        //   264: isub           
        //   265: invokestatic    q/o/m/s/q.h:(Ljava/lang/String;II)Ljava/lang/String;
        //   268: goto            275
        //   271: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   274: athrow         
        //   275: putfield        org/apache/commons/io/output/XmlStreamWriter.encoding:Ljava/lang/String;
        //   278: iload           4
        //   280: ifne            303
        //   283: aload_0        
        //   284: aload_0        
        //   285: getfield        org/apache/commons/io/output/XmlStreamWriter.defaultEncoding:Ljava/lang/String;
        //   288: iload           4
        //   290: ifeq            275
        //   293: goto            300
        //   296: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   299: athrow         
        //   300: putfield        org/apache/commons/io/output/XmlStreamWriter.encoding:Ljava/lang/String;
        //   303: iload           4
        //   305: ifne            341
        //   308: aload           6
        //   310: invokestatic    q/o/m/s/q.gy:(Ljava/lang/StringBuffer;)I
        //   313: goto            320
        //   316: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   319: athrow         
        //   320: sipush          4096
        //   323: if_icmplt       341
        //   326: aload_0        
        //   327: aload_0        
        //   328: getfield        org/apache/commons/io/output/XmlStreamWriter.defaultEncoding:Ljava/lang/String;
        //   331: putfield        org/apache/commons/io/output/XmlStreamWriter.encoding:Ljava/lang/String;
        //   334: goto            341
        //   337: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   340: athrow         
        //   341: iload           4
        //   343: ifne            361
        //   346: aload_0        
        //   347: aload_0        
        //   348: getfield        org/apache/commons/io/output/XmlStreamWriter.defaultEncoding:Ljava/lang/String;
        //   351: putfield        org/apache/commons/io/output/XmlStreamWriter.encoding:Ljava/lang/String;
        //   354: goto            361
        //   357: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   360: athrow         
        //   361: aload_0        
        //   362: iload           4
        //   364: ifeq            427
        //   367: iload           4
        //   369: ifeq            432
        //   372: goto            379
        //   375: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   378: athrow         
        //   379: getfield        org/apache/commons/io/output/XmlStreamWriter.encoding:Ljava/lang/String;
        //   382: ifnull          488
        //   385: goto            392
        //   388: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   391: athrow         
        //   392: aload_0        
        //   393: aconst_null    
        //   394: putfield        org/apache/commons/io/output/XmlStreamWriter.xmlPrologWriter:Ljava/io/StringWriter;
        //   397: aload_0        
        //   398: new             Ljava/io/OutputStreamWriter;
        //   401: dup            
        //   402: aload_0        
        //   403: getfield        org/apache/commons/io/output/XmlStreamWriter.out:Ljava/io/OutputStream;
        //   406: aload_0        
        //   407: getfield        org/apache/commons/io/output/XmlStreamWriter.encoding:Ljava/lang/String;
        //   410: invokespecial   java/io/OutputStreamWriter.<init>:(Ljava/io/OutputStream;Ljava/lang/String;)V
        //   413: putfield        org/apache/commons/io/output/XmlStreamWriter.writer:Ljava/io/Writer;
        //   416: aload_0        
        //   417: getfield        org/apache/commons/io/output/XmlStreamWriter.writer:Ljava/io/Writer;
        //   420: goto            427
        //   423: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   426: athrow         
        //   427: iload           4
        //   429: ifeq            476
        //   432: iload           4
        //   434: ifeq            476
        //   437: goto            444
        //   440: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   443: athrow         
        //   444: aload           6
        //   446: invokestatic    q/o/m/s/q.yx:(Ljava/lang/StringBuffer;)Ljava/lang/String;
        //   449: invokestatic    q/o/m/s/q.sa:(Ljava/io/Writer;Ljava/lang/String;)V
        //   452: iload_3        
        //   453: iload           5
        //   455: if_icmple       488
        //   458: goto            465
        //   461: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   464: athrow         
        //   465: aload_0        
        //   466: getfield        org/apache/commons/io/output/XmlStreamWriter.writer:Ljava/io/Writer;
        //   469: goto            476
        //   472: invokestatic    org/apache/commons/io/output/XmlStreamWriter.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   475: athrow         
        //   476: aload_1        
        //   477: iload_2        
        //   478: iload           5
        //   480: iadd           
        //   481: iload_3        
        //   482: iload           5
        //   484: isub           
        //   485: invokestatic    q/o/m/s/q.sb:(Ljava/io/Writer;[CII)V
        //   488: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 33 FF 00 26 00 07 07 00 02 07 00 6F 01 01 01 01 07 00 71 00 01 07 00 4C 03 4A 07 00 4C FF 00 03 00 07 07 00 02 07 00 6F 01 01 01 01 07 00 71 00 02 01 01 02 5C 07 00 4C 43 01 48 07 00 4C FF 00 03 00 07 07 00 02 07 00 6F 01 01 01 01 07 00 71 00 02 01 01 57 07 00 4C 43 01 44 01 47 07 00 4C 43 01 45 07 00 4C 03 50 07 00 4C 43 01 FF 00 0E 00 08 07 00 02 07 00 6F 01 01 01 01 07 00 71 01 00 01 07 00 4C 03 FF 00 1F 00 09 07 00 02 07 00 6F 01 01 01 01 07 00 71 01 07 00 8D 00 01 07 00 4C 03 61 07 00 4C FF 00 03 00 09 07 00 02 07 00 6F 01 01 01 01 07 00 71 01 07 00 8D 00 02 07 00 02 07 00 32 02 04 4C 07 00 4C FF 00 03 00 09 07 00 02 07 00 6F 01 01 01 01 07 00 71 01 07 00 8D 00 02 07 00 02 07 00 32 02 FA 00 04 47 07 00 4C 43 01 50 07 00 4C 03 FA 00 04 4A 07 00 4C 03 4D 07 00 4C 43 07 00 02 48 07 00 4C 03 5E 07 00 4C 43 07 00 04 44 07 00 04 47 07 00 4C 43 07 00 04 50 07 00 4C 03 46 07 00 4C 43 07 00 04 0B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  17     35     38     42     Ljava/io/IOException;
        //  32     50     53     57     Ljava/io/IOException;
        //  60     86     89     93     Ljava/io/IOException;
        //  81     99     102    106    Ljava/io/IOException;
        //  106    127    130    134    Ljava/io/IOException;
        //  134    144    147    151    Ljava/io/IOException;
        //  139    154    157    161    Ljava/io/IOException;
        //  151    175    178    182    Ljava/io/IOException;
        //  184    194    197    201    Ljava/io/IOException;
        //  217    230    233    237    Ljava/io/IOException;
        //  222    268    271    275    Ljava/io/IOException;
        //  278    293    296    300    Ljava/io/IOException;
        //  303    313    316    320    Ljava/io/IOException;
        //  320    334    337    341    Ljava/io/IOException;
        //  341    354    357    361    Ljava/io/IOException;
        //  361    372    375    379    Ljava/io/IOException;
        //  367    385    388    392    Ljava/io/IOException;
        //  379    420    423    427    Ljava/io/IOException;
        //  427    437    440    444    Ljava/io/IOException;
        //  432    458    461    465    Ljava/io/IOException;
        //  444    469    472    476    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0139:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void write(final char[] array, final int n, final int n2) throws IOException {
        final int b = ProxyOutputStream.b();
        Writer writer = null;
        Label_0045: {
            while (true) {
                Label_0036: {
                    try {
                        final StringWriter stringWriter = (StringWriter)(writer = this.xmlPrologWriter);
                        if (b == 0) {
                            break Label_0045;
                        }
                        if (stringWriter == null) {
                            break Label_0036;
                        }
                    }
                    catch (IOException ex) {
                        throw b(ex);
                    }
                    final XmlStreamWriter xmlStreamWriter = this;
                    xmlStreamWriter.detectEncoding(array, n, n2);
                    if (b != 0) {
                        return;
                    }
                }
                final XmlStreamWriter xmlStreamWriter = this;
                if (b == 0) {
                    continue;
                }
                break;
            }
            writer = this.writer;
        }
        q.sb(writer, array, n, n2);
    }
    
    static {
        final String[] a2 = new String[3];
        int n = 0;
        final String th;
        final int q = q.o.m.s.q.q(th = n.d.a.d.q.th());
        int j = 5;
        int n2 = -1;
        Label_0022: {
            break Label_0022;
            do {
                j = q.o.m.s.q.j(th, n2);
                int n5;
                int n4;
                final int n3 = n4 = (n5 = 31);
                ++n2;
                final String s = th;
                final int n6 = n2;
                final char[] g = q.o.m.s.q.g(q.o.m.s.q.h(s, n6, n6 + j));
                final int length = g.length;
                int n7 = 0;
                while (true) {
                    Label_0200: {
                        if (length > 1) {
                            break Label_0200;
                        }
                        n5 = (n4 = n7);
                        do {
                            final char c = g[n4];
                            int n8 = 0;
                            switch (n7 % 7) {
                                case 0: {
                                    n8 = 24;
                                    break;
                                }
                                case 1: {
                                    n8 = 77;
                                    break;
                                }
                                case 2: {
                                    n8 = 47;
                                    break;
                                }
                                case 3: {
                                    n8 = 115;
                                    break;
                                }
                                case 4: {
                                    n8 = 114;
                                    break;
                                }
                                case 5: {
                                    n8 = 77;
                                    break;
                                }
                                default: {
                                    n8 = 63;
                                    break;
                                }
                            }
                            g[n5] = (char)(c ^ (n3 ^ n8));
                            ++n7;
                        } while (n3 == 0);
                    }
                    if (length > n7) {
                        continue;
                    }
                    break;
                }
                a2[n++] = q.o.m.s.q.z(new String(g));
            } while ((n2 += j) < q);
        }
        a = a2;
        b = new String[3];
        ENCODING_PATTERN = XmlStreamReader.ENCODING_PATTERN;
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0x483F) & 0xFFFF;
        if (XmlStreamWriter.b[n3] == null) {
            final char[] g = q.g(XmlStreamWriter.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 110;
                    break;
                }
                case 1: {
                    n4 = 27;
                    break;
                }
                case 2: {
                    n4 = 107;
                    break;
                }
                case 3: {
                    n4 = 68;
                    break;
                }
                case 4: {
                    n4 = 243;
                    break;
                }
                case 5: {
                    n4 = 96;
                    break;
                }
                case 6: {
                    n4 = 233;
                    break;
                }
                case 7: {
                    n4 = 212;
                    break;
                }
                case 8: {
                    n4 = 193;
                    break;
                }
                case 9: {
                    n4 = 146;
                    break;
                }
                case 10: {
                    n4 = 236;
                    break;
                }
                case 11: {
                    n4 = 239;
                    break;
                }
                case 12: {
                    n4 = 245;
                    break;
                }
                case 13: {
                    n4 = 224;
                    break;
                }
                case 14: {
                    n4 = 86;
                    break;
                }
                case 15: {
                    n4 = 190;
                    break;
                }
                case 16: {
                    n4 = 12;
                    break;
                }
                case 17: {
                    n4 = 98;
                    break;
                }
                case 18: {
                    n4 = 163;
                    break;
                }
                case 19: {
                    n4 = 32;
                    break;
                }
                case 20: {
                    n4 = 207;
                    break;
                }
                case 21: {
                    n4 = 29;
                    break;
                }
                case 22: {
                    n4 = 140;
                    break;
                }
                case 23: {
                    n4 = 1;
                    break;
                }
                case 24: {
                    n4 = 178;
                    break;
                }
                case 25: {
                    n4 = 112;
                    break;
                }
                case 26: {
                    n4 = 5;
                    break;
                }
                case 27: {
                    n4 = 17;
                    break;
                }
                case 28: {
                    n4 = 201;
                    break;
                }
                case 29: {
                    n4 = 197;
                    break;
                }
                case 30: {
                    n4 = 180;
                    break;
                }
                case 31: {
                    n4 = 145;
                    break;
                }
                case 32: {
                    n4 = 129;
                    break;
                }
                case 33: {
                    n4 = 92;
                    break;
                }
                case 34: {
                    n4 = 65;
                    break;
                }
                case 35: {
                    n4 = 63;
                    break;
                }
                case 36: {
                    n4 = 185;
                    break;
                }
                case 37: {
                    n4 = 67;
                    break;
                }
                case 38: {
                    n4 = 226;
                    break;
                }
                case 39: {
                    n4 = 241;
                    break;
                }
                case 40: {
                    n4 = 85;
                    break;
                }
                case 41: {
                    n4 = 72;
                    break;
                }
                case 42: {
                    n4 = 28;
                    break;
                }
                case 43: {
                    n4 = 167;
                    break;
                }
                case 44: {
                    n4 = 244;
                    break;
                }
                case 45: {
                    n4 = 218;
                    break;
                }
                case 46: {
                    n4 = 170;
                    break;
                }
                case 47: {
                    n4 = 220;
                    break;
                }
                case 48: {
                    n4 = 151;
                    break;
                }
                case 49: {
                    n4 = 81;
                    break;
                }
                case 50: {
                    n4 = 221;
                    break;
                }
                case 51: {
                    n4 = 217;
                    break;
                }
                case 52: {
                    n4 = 59;
                    break;
                }
                case 53: {
                    n4 = 228;
                    break;
                }
                case 54: {
                    n4 = 138;
                    break;
                }
                case 55: {
                    n4 = 135;
                    break;
                }
                case 56: {
                    n4 = 38;
                    break;
                }
                case 57: {
                    n4 = 46;
                    break;
                }
                case 58: {
                    n4 = 118;
                    break;
                }
                case 59: {
                    n4 = 148;
                    break;
                }
                case 60: {
                    n4 = 66;
                    break;
                }
                case 61: {
                    n4 = 22;
                    break;
                }
                case 62: {
                    n4 = 144;
                    break;
                }
                case 63: {
                    n4 = 249;
                    break;
                }
                case 64: {
                    n4 = 116;
                    break;
                }
                case 65: {
                    n4 = 19;
                    break;
                }
                case 66: {
                    n4 = 232;
                    break;
                }
                case 67: {
                    n4 = 215;
                    break;
                }
                case 68: {
                    n4 = 84;
                    break;
                }
                case 69: {
                    n4 = 109;
                    break;
                }
                case 70: {
                    n4 = 40;
                    break;
                }
                case 71: {
                    n4 = 111;
                    break;
                }
                case 72: {
                    n4 = 91;
                    break;
                }
                case 73: {
                    n4 = 196;
                    break;
                }
                case 74: {
                    n4 = 222;
                    break;
                }
                case 75: {
                    n4 = 124;
                    break;
                }
                case 76: {
                    n4 = 142;
                    break;
                }
                case 77: {
                    n4 = 21;
                    break;
                }
                case 78: {
                    n4 = 141;
                    break;
                }
                case 79: {
                    n4 = 90;
                    break;
                }
                case 80: {
                    n4 = 25;
                    break;
                }
                case 81: {
                    n4 = 11;
                    break;
                }
                case 82: {
                    n4 = 251;
                    break;
                }
                case 83: {
                    n4 = 160;
                    break;
                }
                case 84: {
                    n4 = 177;
                    break;
                }
                case 85: {
                    n4 = 56;
                    break;
                }
                case 86: {
                    n4 = 75;
                    break;
                }
                case 87: {
                    n4 = 179;
                    break;
                }
                case 88: {
                    n4 = 101;
                    break;
                }
                case 89: {
                    n4 = 119;
                    break;
                }
                case 90: {
                    n4 = 143;
                    break;
                }
                case 91: {
                    n4 = 166;
                    break;
                }
                case 92: {
                    n4 = 18;
                    break;
                }
                case 93: {
                    n4 = 195;
                    break;
                }
                case 94: {
                    n4 = 45;
                    break;
                }
                case 95: {
                    n4 = 55;
                    break;
                }
                case 96: {
                    n4 = 155;
                    break;
                }
                case 97: {
                    n4 = 252;
                    break;
                }
                case 98: {
                    n4 = 235;
                    break;
                }
                case 99: {
                    n4 = 153;
                    break;
                }
                case 100: {
                    n4 = 149;
                    break;
                }
                case 101: {
                    n4 = 194;
                    break;
                }
                case 102: {
                    n4 = 4;
                    break;
                }
                case 103: {
                    n4 = 159;
                    break;
                }
                case 104: {
                    n4 = 9;
                    break;
                }
                case 105: {
                    n4 = 134;
                    break;
                }
                case 106: {
                    n4 = 208;
                    break;
                }
                case 107: {
                    n4 = 246;
                    break;
                }
                case 108: {
                    n4 = 57;
                    break;
                }
                case 109: {
                    n4 = 206;
                    break;
                }
                case 110: {
                    n4 = 248;
                    break;
                }
                case 111: {
                    n4 = 225;
                    break;
                }
                case 112: {
                    n4 = 255;
                    break;
                }
                case 113: {
                    n4 = 123;
                    break;
                }
                case 114: {
                    n4 = 0;
                    break;
                }
                case 115: {
                    n4 = 131;
                    break;
                }
                case 116: {
                    n4 = 26;
                    break;
                }
                case 117: {
                    n4 = 31;
                    break;
                }
                case 118: {
                    n4 = 161;
                    break;
                }
                case 119: {
                    n4 = 122;
                    break;
                }
                case 120: {
                    n4 = 79;
                    break;
                }
                case 121: {
                    n4 = 214;
                    break;
                }
                case 122: {
                    n4 = 106;
                    break;
                }
                case 123: {
                    n4 = 95;
                    break;
                }
                case 124: {
                    n4 = 62;
                    break;
                }
                case 125: {
                    n4 = 127;
                    break;
                }
                case 126: {
                    n4 = 64;
                    break;
                }
                case 127: {
                    n4 = 168;
                    break;
                }
                case 128: {
                    n4 = 37;
                    break;
                }
                case 129: {
                    n4 = 100;
                    break;
                }
                case 130: {
                    n4 = 181;
                    break;
                }
                case 131: {
                    n4 = 10;
                    break;
                }
                case 132: {
                    n4 = 199;
                    break;
                }
                case 133: {
                    n4 = 69;
                    break;
                }
                case 134: {
                    n4 = 33;
                    break;
                }
                case 135: {
                    n4 = 117;
                    break;
                }
                case 136: {
                    n4 = 186;
                    break;
                }
                case 137: {
                    n4 = 80;
                    break;
                }
                case 138: {
                    n4 = 49;
                    break;
                }
                case 139: {
                    n4 = 157;
                    break;
                }
                case 140: {
                    n4 = 189;
                    break;
                }
                case 141: {
                    n4 = 231;
                    break;
                }
                case 142: {
                    n4 = 54;
                    break;
                }
                case 143: {
                    n4 = 184;
                    break;
                }
                case 144: {
                    n4 = 230;
                    break;
                }
                case 145: {
                    n4 = 175;
                    break;
                }
                case 146: {
                    n4 = 174;
                    break;
                }
                case 147: {
                    n4 = 87;
                    break;
                }
                case 148: {
                    n4 = 8;
                    break;
                }
                case 149: {
                    n4 = 20;
                    break;
                }
                case 150: {
                    n4 = 102;
                    break;
                }
                case 151: {
                    n4 = 103;
                    break;
                }
                case 152: {
                    n4 = 219;
                    break;
                }
                case 153: {
                    n4 = 192;
                    break;
                }
                case 154: {
                    n4 = 198;
                    break;
                }
                case 155: {
                    n4 = 169;
                    break;
                }
                case 156: {
                    n4 = 70;
                    break;
                }
                case 157: {
                    n4 = 113;
                    break;
                }
                case 158: {
                    n4 = 172;
                    break;
                }
                case 159: {
                    n4 = 24;
                    break;
                }
                case 160: {
                    n4 = 234;
                    break;
                }
                case 161: {
                    n4 = 250;
                    break;
                }
                case 162: {
                    n4 = 147;
                    break;
                }
                case 163: {
                    n4 = 53;
                    break;
                }
                case 164: {
                    n4 = 173;
                    break;
                }
                case 165: {
                    n4 = 154;
                    break;
                }
                case 166: {
                    n4 = 227;
                    break;
                }
                case 167: {
                    n4 = 242;
                    break;
                }
                case 168: {
                    n4 = 133;
                    break;
                }
                case 169: {
                    n4 = 83;
                    break;
                }
                case 170: {
                    n4 = 104;
                    break;
                }
                case 171: {
                    n4 = 114;
                    break;
                }
                case 172: {
                    n4 = 97;
                    break;
                }
                case 173: {
                    n4 = 203;
                    break;
                }
                case 174: {
                    n4 = 171;
                    break;
                }
                case 175: {
                    n4 = 253;
                    break;
                }
                case 176: {
                    n4 = 125;
                    break;
                }
                case 177: {
                    n4 = 120;
                    break;
                }
                case 178: {
                    n4 = 74;
                    break;
                }
                case 179: {
                    n4 = 14;
                    break;
                }
                case 180: {
                    n4 = 7;
                    break;
                }
                case 181: {
                    n4 = 139;
                    break;
                }
                case 182: {
                    n4 = 35;
                    break;
                }
                case 183: {
                    n4 = 128;
                    break;
                }
                case 184: {
                    n4 = 78;
                    break;
                }
                case 185: {
                    n4 = 237;
                    break;
                }
                case 186: {
                    n4 = 13;
                    break;
                }
                case 187: {
                    n4 = 16;
                    break;
                }
                case 188: {
                    n4 = 165;
                    break;
                }
                case 189: {
                    n4 = 44;
                    break;
                }
                case 190: {
                    n4 = 132;
                    break;
                }
                case 191: {
                    n4 = 108;
                    break;
                }
                case 192: {
                    n4 = 205;
                    break;
                }
                case 193: {
                    n4 = 61;
                    break;
                }
                case 194: {
                    n4 = 162;
                    break;
                }
                case 195: {
                    n4 = 238;
                    break;
                }
                case 196: {
                    n4 = 183;
                    break;
                }
                case 197: {
                    n4 = 41;
                    break;
                }
                case 198: {
                    n4 = 152;
                    break;
                }
                case 199: {
                    n4 = 191;
                    break;
                }
                case 200: {
                    n4 = 50;
                    break;
                }
                case 201: {
                    n4 = 137;
                    break;
                }
                case 202: {
                    n4 = 121;
                    break;
                }
                case 203: {
                    n4 = 89;
                    break;
                }
                case 204: {
                    n4 = 211;
                    break;
                }
                case 205: {
                    n4 = 3;
                    break;
                }
                case 206: {
                    n4 = 200;
                    break;
                }
                case 207: {
                    n4 = 182;
                    break;
                }
                case 208: {
                    n4 = 115;
                    break;
                }
                case 209: {
                    n4 = 60;
                    break;
                }
                case 210: {
                    n4 = 23;
                    break;
                }
                case 211: {
                    n4 = 34;
                    break;
                }
                case 212: {
                    n4 = 150;
                    break;
                }
                case 213: {
                    n4 = 88;
                    break;
                }
                case 214: {
                    n4 = 30;
                    break;
                }
                case 215: {
                    n4 = 210;
                    break;
                }
                case 216: {
                    n4 = 6;
                    break;
                }
                case 217: {
                    n4 = 47;
                    break;
                }
                case 218: {
                    n4 = 99;
                    break;
                }
                case 219: {
                    n4 = 156;
                    break;
                }
                case 220: {
                    n4 = 77;
                    break;
                }
                case 221: {
                    n4 = 52;
                    break;
                }
                case 222: {
                    n4 = 2;
                    break;
                }
                case 223: {
                    n4 = 136;
                    break;
                }
                case 224: {
                    n4 = 204;
                    break;
                }
                case 225: {
                    n4 = 247;
                    break;
                }
                case 226: {
                    n4 = 43;
                    break;
                }
                case 227: {
                    n4 = 15;
                    break;
                }
                case 228: {
                    n4 = 93;
                    break;
                }
                case 229: {
                    n4 = 94;
                    break;
                }
                case 230: {
                    n4 = 82;
                    break;
                }
                case 231: {
                    n4 = 76;
                    break;
                }
                case 232: {
                    n4 = 240;
                    break;
                }
                case 233: {
                    n4 = 254;
                    break;
                }
                case 234: {
                    n4 = 188;
                    break;
                }
                case 235: {
                    n4 = 126;
                    break;
                }
                case 236: {
                    n4 = 42;
                    break;
                }
                case 237: {
                    n4 = 213;
                    break;
                }
                case 238: {
                    n4 = 216;
                    break;
                }
                case 239: {
                    n4 = 36;
                    break;
                }
                case 240: {
                    n4 = 105;
                    break;
                }
                case 241: {
                    n4 = 164;
                    break;
                }
                case 242: {
                    n4 = 223;
                    break;
                }
                case 243: {
                    n4 = 51;
                    break;
                }
                case 244: {
                    n4 = 209;
                    break;
                }
                case 245: {
                    n4 = 158;
                    break;
                }
                case 246: {
                    n4 = 71;
                    break;
                }
                case 247: {
                    n4 = 202;
                    break;
                }
                case 248: {
                    n4 = 130;
                    break;
                }
                case 249: {
                    n4 = 39;
                    break;
                }
                case 250: {
                    n4 = 48;
                    break;
                }
                case 251: {
                    n4 = 73;
                    break;
                }
                case 252: {
                    n4 = 58;
                    break;
                }
                case 253: {
                    n4 = 176;
                    break;
                }
                case 254: {
                    n4 = 187;
                    break;
                }
                default: {
                    n4 = 229;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            XmlStreamWriter.b[n3] = q.z(new String(g));
        }
        return XmlStreamWriter.b[n3];
    }
}
