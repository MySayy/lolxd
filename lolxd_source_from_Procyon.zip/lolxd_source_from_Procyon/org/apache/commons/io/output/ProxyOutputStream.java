// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.output;

import java.io.IOException;
import q.o.m.s.q;
import java.io.OutputStream;
import java.io.FilterOutputStream;

public class ProxyOutputStream extends FilterOutputStream
{
    private static int b;
    
    public ProxyOutputStream(final OutputStream out) {
        super(out);
    }
    
    @Override
    public void write(final int n) throws IOException {
        try {
            this.beforeWrite(1);
            q.kq(this.out, n);
            this.afterWrite(1);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
    }
    
    @Override
    public void write(final byte[] array) throws IOException {
        final int a = a();
        try {
            int length = 0;
            Label_0036: {
                Label_0035: {
                    byte[] array2 = null;
                    Label_0031: {
                        Label_0020: {
                            try {
                                array2 = array;
                                if (a != 0) {
                                    break Label_0031;
                                }
                                final int n = a;
                                if (n == 0) {
                                    break Label_0020;
                                }
                                break Label_0031;
                            }
                            catch (IOException ex) {
                                throw b(ex);
                            }
                            try {
                                final int n = a;
                                if (n != 0) {
                                    break Label_0031;
                                }
                                if (array == null) {
                                    break Label_0035;
                                }
                            }
                            catch (IOException ex2) {
                                throw b(ex2);
                            }
                        }
                        array2 = array;
                    }
                    length = array2.length;
                    break Label_0036;
                }
                length = 0;
            }
            final int n2 = length;
            this.beforeWrite(n2);
            q.sj(this.out, array);
            this.afterWrite(n2);
        }
        catch (IOException ex3) {
            this.handleIOException(ex3);
        }
    }
    
    @Override
    public void write(final byte[] array, final int n, final int n2) throws IOException {
        try {
            this.beforeWrite(n2);
            q.sz(this.out, array, n, n2);
            this.afterWrite(n2);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
    }
    
    @Override
    public void flush() throws IOException {
        try {
            q.ym(this.out);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
    }
    
    @Override
    public void close() throws IOException {
        try {
            q.pf(this.out);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
    }
    
    protected void beforeWrite(final int n) throws IOException {
    }
    
    protected void afterWrite(final int n) throws IOException {
    }
    
    protected void handleIOException(final IOException ex) throws IOException {
        throw ex;
    }
    
    public static void b(final int b) {
        ProxyOutputStream.b = b;
    }
    
    public static int b() {
        return ProxyOutputStream.b;
    }
    
    public static int a() {
        final int b = b();
        try {
            if (b == 0) {
                return 88;
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
        return 0;
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    static {
        if (b() == 0) {
            b(7);
        }
    }
}
