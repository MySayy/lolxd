// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import q.o.m.s.q;

class ThreadMonitor implements Runnable
{
    private final Thread thread;
    private final long timeout;
    
    public static Thread start(final long n) {
        return start(q.ni(), n);
    }
    
    public static Thread start(final Thread thread, final long n) {
        Thread thread2 = null;
        if (n > 0L) {
            thread2 = new Thread(new ThreadMonitor(thread, n), q.ss(ThreadMonitor.class));
            q.ct(thread2, true);
            q.rn(thread2);
        }
        return thread2;
    }
    
    public static void stop(final Thread thread) {
        final int c = IOCase.c();
        Thread thread2 = null;
        Label_0031: {
            Label_0020: {
                try {
                    thread2 = thread;
                    if (c == 0) {
                        break Label_0031;
                    }
                    final int n = c;
                    if (n != 0) {
                        break Label_0020;
                    }
                    break Label_0031;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final int n = c;
                    if (n == 0) {
                        break Label_0031;
                    }
                    if (thread == null) {
                        return;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            thread2 = thread;
        }
        q.ky(thread2);
    }
    
    private ThreadMonitor(final Thread thread, final long timeout) {
        this.thread = thread;
        this.timeout = timeout;
    }
    
    @Override
    public void run() {
        try {
            sleep(this.timeout);
            q.ky(this.thread);
        }
        catch (InterruptedException ex) {}
    }
    
    private static void sleep(final long n) throws InterruptedException {
        final long n2 = q.tj() + n;
        final int b = IOCase.b();
        long n3 = n;
    Block_2:
        while (true) {
            q.mt(n3);
            n3 = n2 - q.tj();
            while (n3 <= 0L) {
                if (b == 0) {
                    break Block_2;
                }
            }
        }
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
