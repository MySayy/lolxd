// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import java.io.File;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.PhantomReference;

final class FileCleaningTracker$Tracker extends PhantomReference<Object>
{
    private final String path;
    private final FileDeleteStrategy deleteStrategy;
    
    FileCleaningTracker$Tracker(final String path, final FileDeleteStrategy fileDeleteStrategy, final Object referent, final ReferenceQueue<? super Object> q) {
        final int c = IOCase.c();
        super(referent, q);
        this.path = path;
        final int n = c;
        FileDeleteStrategy normal = null;
        Label_0053: {
            Label_0052: {
                Label_0049: {
                    Label_0036: {
                        try {
                            normal = fileDeleteStrategy;
                            if (n == 0) {
                                break Label_0049;
                            }
                            final int n2 = n;
                            if (n2 != 0) {
                                break Label_0036;
                            }
                            break Label_0049;
                        }
                        catch (RuntimeException ex) {
                            throw b(ex);
                        }
                        try {
                            final int n2 = n;
                            if (n2 == 0) {
                                break Label_0049;
                            }
                            if (fileDeleteStrategy != null) {
                                break Label_0052;
                            }
                        }
                        catch (RuntimeException ex2) {
                            throw b(ex2);
                        }
                    }
                    normal = FileDeleteStrategy.NORMAL;
                }
                break Label_0053;
            }
            normal = fileDeleteStrategy;
        }
        this.deleteStrategy = normal;
    }
    
    public String getPath() {
        return this.path;
    }
    
    public boolean delete() {
        return this.deleteStrategy.deleteQuietly(new File(this.path));
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
