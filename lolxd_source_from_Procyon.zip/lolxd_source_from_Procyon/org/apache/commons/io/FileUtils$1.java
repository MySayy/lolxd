// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import q.o.m.s.q;
import java.io.File;
import java.io.FileFilter;

final class FileUtils$1 implements FileFilter
{
    final File val$canon;
    
    FileUtils$1(final File val$canon) {
        this.val$canon = val$canon;
    }
    
    @Override
    public boolean accept(final File file) {
        return q.ek(file, this.val$canon);
    }
}
