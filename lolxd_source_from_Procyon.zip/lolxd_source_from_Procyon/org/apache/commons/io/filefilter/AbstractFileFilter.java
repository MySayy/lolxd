// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.filefilter;

import q.o.m.s.q;
import java.io.File;

public abstract class AbstractFileFilter implements IOFileFilter
{
    private static boolean b;
    
    @Override
    public boolean accept(final File file) {
        return this.accept(q.ep(file), q.mh(file));
    }
    
    @Override
    public boolean accept(final File parent, final String child) {
        return this.accept(new File(parent, child));
    }
    
    @Override
    public String toString() {
        return q.ss(q.qi(this));
    }
    
    public static void b(final boolean b) {
        AbstractFileFilter.b = b;
    }
    
    public static boolean b() {
        return AbstractFileFilter.b;
    }
    
    public static boolean c() {
        final boolean b = b();
        try {
            if (!b) {
                return true;
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
        return false;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
    
    static {
        if (c()) {
            b(true);
        }
    }
}
