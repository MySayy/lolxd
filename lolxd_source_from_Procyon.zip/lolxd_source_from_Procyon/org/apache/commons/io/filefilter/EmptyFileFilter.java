// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.filefilter;

import java.io.File;
import java.io.Serializable;

public class EmptyFileFilter extends AbstractFileFilter implements Serializable
{
    private static final long serialVersionUID = 3631422087512832211L;
    public static final IOFileFilter EMPTY;
    public static final IOFileFilter NOT_EMPTY;
    
    protected EmptyFileFilter() {
    }
    
    @Override
    public boolean accept(final File p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_1        
        //     5: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //     8: iload_2        
        //     9: ifeq            93
        //    12: ifeq            79
        //    15: goto            22
        //    18: invokestatic    org/apache/commons/io/filefilter/EmptyFileFilter.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    21: athrow         
        //    22: aload_1        
        //    23: invokestatic    q/o/m/s/q.sl:(Ljava/io/File;)[Ljava/io/File;
        //    26: astore_3       
        //    27: aload_3        
        //    28: iload_2        
        //    29: ifeq            43
        //    32: ifnull          62
        //    35: goto            42
        //    38: invokestatic    org/apache/commons/io/filefilter/EmptyFileFilter.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    41: athrow         
        //    42: aload_3        
        //    43: arraylength    
        //    44: iload_2        
        //    45: ifeq            74
        //    48: iload_2        
        //    49: ifeq            74
        //    52: ifne            77
        //    55: goto            62
        //    58: invokestatic    org/apache/commons/io/filefilter/EmptyFileFilter.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    61: athrow         
        //    62: iconst_1       
        //    63: iload_2        
        //    64: ifeq            44
        //    67: goto            74
        //    70: invokestatic    org/apache/commons/io/filefilter/EmptyFileFilter.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    73: athrow         
        //    74: goto            78
        //    77: iconst_0       
        //    78: ireturn        
        //    79: aload_1        
        //    80: iload_2        
        //    81: ifeq            23
        //    84: invokestatic    q/o/m/s/q.eb:(Ljava/io/File;)J
        //    87: lconst_0       
        //    88: lcmp           
        //    89: iload_2        
        //    90: ifeq            115
        //    93: iload_2        
        //    94: ifeq            115
        //    97: goto            104
        //   100: invokestatic    org/apache/commons/io/filefilter/EmptyFileFilter.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   103: athrow         
        //   104: ifne            118
        //   107: goto            114
        //   110: invokestatic    org/apache/commons/io/filefilter/EmptyFileFilter.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   113: athrow         
        //   114: iconst_1       
        //   115: goto            119
        //   118: iconst_0       
        //   119: ireturn        
        //    StackMapTable: 00 16 FF 00 12 00 03 07 00 02 07 00 21 01 00 01 07 00 16 03 40 07 00 21 FF 00 0E 00 04 07 00 02 07 00 21 01 07 00 2B 00 01 07 00 16 03 40 07 00 2B 40 01 4D 07 00 16 03 47 07 00 16 43 01 02 40 01 FA 00 00 4D 01 46 07 00 16 43 01 45 07 00 16 03 40 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      15     18     22     Ljava/lang/RuntimeException;
        //  27     35     38     42     Ljava/lang/RuntimeException;
        //  48     55     58     62     Ljava/lang/RuntimeException;
        //  52     67     70     74     Ljava/lang/RuntimeException;
        //  84     97     100    104    Ljava/lang/RuntimeException;
        //  93     107    110    114    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0093:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        EMPTY = new EmptyFileFilter();
        NOT_EMPTY = new NotFileFilter(EmptyFileFilter.EMPTY);
    }
    
    private static RuntimeException c(final RuntimeException ex) {
        return ex;
    }
}
