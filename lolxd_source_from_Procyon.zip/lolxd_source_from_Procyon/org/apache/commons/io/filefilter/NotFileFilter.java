// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.filefilter;

import q.o.m.s.q;
import java.io.File;
import java.io.Serializable;

public class NotFileFilter extends AbstractFileFilter implements Serializable
{
    private static final long serialVersionUID = 6131563330944994230L;
    private final IOFileFilter filter;
    private static final String a;
    
    public NotFileFilter(final IOFileFilter filter) {
        if (filter == null) {
            throw new IllegalArgumentException(NotFileFilter.a);
        }
        this.filter = filter;
    }
    
    @Override
    public boolean accept(final File file) {
        final boolean c = AbstractFileFilter.c();
        boolean accept = false;
        Label_0043: {
            Label_0029: {
                try {
                    accept = this.filter.accept(file);
                    if (c) {
                        return accept;
                    }
                    final boolean b = c;
                    if (!b) {
                        break Label_0029;
                    }
                    return accept;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    final boolean b = c;
                    if (b) {
                        return accept;
                    }
                    if (accept) {
                        break Label_0043;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            return accept;
        }
        return accept;
    }
    
    @Override
    public boolean accept(final File file, final String s) {
        final boolean c = AbstractFileFilter.c();
        boolean accept = false;
        Label_0044: {
            Label_0030: {
                try {
                    accept = this.filter.accept(file, s);
                    if (c) {
                        return accept;
                    }
                    final boolean b = c;
                    if (!b) {
                        break Label_0030;
                    }
                    return accept;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    final boolean b = c;
                    if (b) {
                        return accept;
                    }
                    if (accept) {
                        break Label_0044;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            return accept;
        }
        return accept;
    }
    
    @Override
    public String toString() {
        return q.s(q.r(q.r(q.r(q.r(new StringBuilder(), super.toString()), n.d.a.d.q.oe()), q.yh(this.filter)), n.d.a.d.q.on()));
    }
    
    private static IllegalArgumentException b(final IllegalArgumentException ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 71);
        final char[] g = q.g(n.d.a.d.q.od());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 105;
                            break;
                        }
                        case 1: {
                            n5 = 62;
                            break;
                        }
                        case 2: {
                            n5 = 37;
                            break;
                        }
                        case 3: {
                            n5 = 29;
                            break;
                        }
                        case 4: {
                            n5 = 88;
                            break;
                        }
                        case 5: {
                            n5 = 29;
                            break;
                        }
                        default: {
                            n5 = 47;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
