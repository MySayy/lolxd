// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.filefilter;

import org.apache.commons.io.FileUtils;
import java.io.File;
import q.o.m.s.q;
import java.util.Date;
import java.io.Serializable;

public class AgeFileFilter extends AbstractFileFilter implements Serializable
{
    private static final long serialVersionUID = -2132740084016138541L;
    private final long cutoff;
    private final boolean acceptOlder;
    private static final String a;
    
    public AgeFileFilter(final long n) {
        this(n, true);
    }
    
    public AgeFileFilter(final long cutoff, final boolean acceptOlder) {
        this.acceptOlder = acceptOlder;
        this.cutoff = cutoff;
    }
    
    public AgeFileFilter(final Date date) {
        this(date, true);
    }
    
    public AgeFileFilter(final Date date, final boolean b) {
        this(q.pt(date), b);
    }
    
    public AgeFileFilter(final File file) {
        this(file, true);
    }
    
    public AgeFileFilter(final File file, final boolean b) {
        this(q.nj(file), b);
    }
    
    @Override
    public boolean accept(final File file) {
        final boolean c = AbstractFileFilter.c();
        final boolean fileNewer = FileUtils.isFileNewer(file, this.cutoff);
        final boolean b = c;
        Label_0061: {
            Label_0043: {
                boolean b2 = false;
                Label_0032: {
                    try {
                        final boolean acceptOlder;
                        b2 = (acceptOlder = this.acceptOlder);
                        if (b) {
                            break Label_0043;
                        }
                        final boolean b3 = b;
                        if (!b3) {
                            break Label_0032;
                        }
                        break Label_0043;
                    }
                    catch (RuntimeException ex) {
                        throw c(ex);
                    }
                    try {
                        final boolean b3 = b;
                        if (b3) {
                            break Label_0043;
                        }
                        if (!b2) {
                            return fileNewer;
                        }
                    }
                    catch (RuntimeException ex2) {
                        throw c(ex2);
                    }
                }
                final boolean b4;
                boolean acceptOlder = b4 = fileNewer;
                try {
                    if (b) {
                        return acceptOlder;
                    }
                    if (b2) {
                        break Label_0061;
                    }
                }
                catch (RuntimeException ex3) {
                    throw c(ex3);
                }
            }
            return true;
        }
        boolean acceptOlder = false;
        if (b) {
            return acceptOlder;
        }
        return acceptOlder;
        acceptOlder = fileNewer;
        return acceptOlder;
    }
    
    @Override
    public String toString() {
        try {
            if (this.acceptOlder) {
                final String s = AgeFileFilter.a;
                return q.s(q.r(q.es(q.r(q.r(q.r(new StringBuilder(), super.toString()), n.d.a.d.q.oe()), s), this.cutoff), n.d.a.d.q.on()));
            }
        }
        catch (RuntimeException ex) {
            throw c(ex);
        }
        final String s = n.d.a.d.q.ok();
        return q.s(q.r(q.es(q.r(q.r(q.r(new StringBuilder(), super.toString()), n.d.a.d.q.oe()), s), this.cutoff), n.d.a.d.q.on()));
    }
    
    private static RuntimeException c(final RuntimeException ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 55);
        final char[] g = q.g(n.d.a.d.q.op());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 13;
                            break;
                        }
                        case 1: {
                            n5 = 7;
                            break;
                        }
                        case 2: {
                            n5 = 83;
                            break;
                        }
                        case 3: {
                            n5 = 33;
                            break;
                        }
                        case 4: {
                            n5 = 8;
                            break;
                        }
                        case 5: {
                            n5 = 89;
                            break;
                        }
                        default: {
                            n5 = 127;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
