// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.filefilter;

import java.io.File;
import org.apache.commons.io.IOCase;
import q.o.m.s.q;
import java.util.regex.Pattern;
import java.io.Serializable;

public class RegexFileFilter extends AbstractFileFilter implements Serializable
{
    private static final long serialVersionUID = 4269646126155225062L;
    private final Pattern pattern;
    private static final String a;
    
    public RegexFileFilter(final String s) {
        final boolean b = AbstractFileFilter.b();
        final boolean b2 = b;
        Label_0023: {
            try {
                if (!b2) {
                    return;
                }
                final String s2 = s;
                if (s2 == null) {
                    break Label_0023;
                }
                break Label_0023;
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            try {
                final String s2 = s;
                if (s2 == null) {
                    throw new IllegalArgumentException(RegexFileFilter.a);
                }
            }
            catch (IllegalArgumentException ex2) {
                throw b(ex2);
            }
        }
        this.pattern = q.cl(s);
    }
    
    public RegexFileFilter(final String s, final IOCase ioCase) {
        final boolean b = AbstractFileFilter.b();
        final boolean b2 = b;
        try {
            if (s == null) {
                throw new IllegalArgumentException(RegexFileFilter.a);
            }
        }
        catch (IllegalArgumentException ex) {
            throw b(ex);
        }
        int n = 0;
        Label_0088: {
            int caseSensitive = 0;
            Label_0075: {
                Label_0057: {
                    Label_0046: {
                        try {
                            if (!b2) {
                                return;
                            }
                            final IOCase ioCase2 = ioCase;
                            final IOCase ioCase3 = ioCase;
                            final boolean b3 = b2;
                            if (b3) {
                                break Label_0046;
                            }
                            break Label_0057;
                        }
                        catch (IllegalArgumentException ex2) {
                            throw b(ex2);
                        }
                        try {
                            final IOCase ioCase2 = ioCase;
                            final IOCase ioCase3 = ioCase;
                            final boolean b3 = b2;
                            if (!b3) {
                                break Label_0057;
                            }
                            if (ioCase3 == null) {
                                break Label_0088;
                            }
                        }
                        catch (IllegalArgumentException ex3) {
                            throw b(ex3);
                        }
                    }
                    final IOCase ioCase2 = ioCase;
                    try {
                        caseSensitive = (ioCase2.isCaseSensitive() ? 1 : 0);
                        if (!b2) {
                            break Label_0075;
                        }
                        final boolean b4 = b2;
                        if (b4) {
                            break Label_0075;
                        }
                        break Label_0075;
                    }
                    catch (IllegalArgumentException ex4) {
                        throw b(ex4);
                    }
                }
                try {
                    final boolean b4 = b2;
                    if (!b4) {
                        break Label_0075;
                    }
                    if (caseSensitive != 0) {
                        break Label_0088;
                    }
                }
                catch (IllegalArgumentException ex5) {
                    throw b(ex5);
                }
            }
            n = caseSensitive;
        }
        this.pattern = q.ci(s, n);
    }
    
    public RegexFileFilter(final String s, final int n) {
        final boolean b = AbstractFileFilter.b();
        final boolean b2 = b;
        Label_0023: {
            try {
                if (!b2) {
                    return;
                }
                final String s2 = s;
                if (s2 == null) {
                    break Label_0023;
                }
                break Label_0023;
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            try {
                final String s2 = s;
                if (s2 == null) {
                    throw new IllegalArgumentException(RegexFileFilter.a);
                }
            }
            catch (IllegalArgumentException ex2) {
                throw b(ex2);
            }
        }
        this.pattern = q.ci(s, n);
    }
    
    public RegexFileFilter(final Pattern pattern) {
        final boolean b = AbstractFileFilter.b();
        final boolean b2 = b;
        Label_0023: {
            try {
                if (!b2) {
                    return;
                }
                final Pattern pattern2 = pattern;
                if (pattern2 == null) {
                    break Label_0023;
                }
                break Label_0023;
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            try {
                final Pattern pattern2 = pattern;
                if (pattern2 == null) {
                    throw new IllegalArgumentException(RegexFileFilter.a);
                }
            }
            catch (IllegalArgumentException ex2) {
                throw b(ex2);
            }
        }
        this.pattern = pattern;
    }
    
    @Override
    public boolean accept(final File file, final String s) {
        return q.xf(q.cu(this.pattern, s));
    }
    
    private static IllegalArgumentException b(final IllegalArgumentException ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 28);
        final char[] g = q.g(n.d.a.d.q.oa());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 124;
                            break;
                        }
                        case 1: {
                            n5 = 87;
                            break;
                        }
                        case 2: {
                            n5 = 63;
                            break;
                        }
                        case 3: {
                            n5 = 32;
                            break;
                        }
                        case 4: {
                            n5 = 122;
                            break;
                        }
                        case 5: {
                            n5 = 57;
                            break;
                        }
                        default: {
                            n5 = 64;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
