// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.serialization;

import q.o.m.s.q;
import java.util.regex.Pattern;

final class RegexpClassNameMatcher implements ClassNameMatcher
{
    private final Pattern pattern;
    private static final String a;
    
    public RegexpClassNameMatcher(final String s) {
        this(q.cl(s));
    }
    
    public RegexpClassNameMatcher(final Pattern pattern) {
        final int[] b = ValidatingObjectInputStream.b();
        final int[] array = b;
        Label_0023: {
            try {
                if (array == null) {
                    return;
                }
                final Pattern pattern2 = pattern;
                if (pattern2 == null) {
                    break Label_0023;
                }
                break Label_0023;
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            try {
                final Pattern pattern2 = pattern;
                if (pattern2 == null) {
                    throw new IllegalArgumentException(RegexpClassNameMatcher.a);
                }
            }
            catch (IllegalArgumentException ex2) {
                throw b(ex2);
            }
        }
        this.pattern = pattern;
    }
    
    @Override
    public boolean matches(final String s) {
        return q.xf(q.cu(this.pattern, s));
    }
    
    private static IllegalArgumentException b(final IllegalArgumentException ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 5);
        final char[] g = q.g(n.d.a.d.q.tj());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 119;
                            break;
                        }
                        case 1: {
                            n5 = 25;
                            break;
                        }
                        case 2: {
                            n5 = 85;
                            break;
                        }
                        case 3: {
                            n5 = 126;
                            break;
                        }
                        case 4: {
                            n5 = 79;
                            break;
                        }
                        case 5: {
                            n5 = 23;
                            break;
                        }
                        default: {
                            n5 = 65;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
