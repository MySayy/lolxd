// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.serialization;

import java.util.regex.Pattern;
import java.io.ObjectStreamClass;
import q.o.m.s.q;
import java.io.InvalidClassException;
import java.io.IOException;
import com.sun.jna.Structure;
import java.util.ArrayList;
import java.io.InputStream;
import java.util.List;
import java.io.ObjectInputStream;

public class ValidatingObjectInputStream extends ObjectInputStream
{
    private final List<ClassNameMatcher> acceptMatchers;
    private final List<ClassNameMatcher> rejectMatchers;
    private static int[] b;
    private static final String a;
    
    public ValidatingObjectInputStream(final InputStream in) throws IOException {
        final int[] b = b();
        super(in);
        final int[] array = b;
        this.acceptMatchers = new ArrayList<ClassNameMatcher>();
        this.rejectMatchers = new ArrayList<ClassNameMatcher>();
        if (array == null) {
            int a = Structure.a();
            Structure.b(++a);
        }
    }
    
    private void validateClassName(final String p0) throws InvalidClassException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: getfield        org/apache/commons/io/serialization/ValidatingObjectInputStream.rejectMatchers:Ljava/util/List;
        //     7: invokestatic    q/o/m/s/q.rs:(Ljava/util/List;)Ljava/util/Iterator;
        //    10: astore_3       
        //    11: astore_2       
        //    12: aload_3        
        //    13: invokestatic    q/o/m/s/q.oi:(Ljava/util/Iterator;)Z
        //    16: ifeq            66
        //    19: aload_3        
        //    20: invokestatic    q/o/m/s/q.ou:(Ljava/util/Iterator;)Ljava/lang/Object;
        //    23: checkcast       Lorg/apache/commons/io/serialization/ClassNameMatcher;
        //    26: astore          4
        //    28: aload           4
        //    30: aload_1        
        //    31: invokeinterface org/apache/commons/io/serialization/ClassNameMatcher.matches:(Ljava/lang/String;)Z
        //    36: aload_2        
        //    37: ifnull          67
        //    40: ifeq            62
        //    43: goto            50
        //    46: invokestatic    org/apache/commons/io/serialization/ValidatingObjectInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    49: athrow         
        //    50: aload_0        
        //    51: aload_1        
        //    52: invokevirtual   org/apache/commons/io/serialization/ValidatingObjectInputStream.invalidClassNameFound:(Ljava/lang/String;)V
        //    55: goto            62
        //    58: invokestatic    org/apache/commons/io/serialization/ValidatingObjectInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    61: athrow         
        //    62: aload_2        
        //    63: ifnonnull       12
        //    66: iconst_0       
        //    67: istore_3       
        //    68: aload_0        
        //    69: getfield        org/apache/commons/io/serialization/ValidatingObjectInputStream.acceptMatchers:Ljava/util/List;
        //    72: invokestatic    q/o/m/s/q.rs:(Ljava/util/List;)Ljava/util/Iterator;
        //    75: astore          4
        //    77: aload           4
        //    79: invokestatic    q/o/m/s/q.oi:(Ljava/util/Iterator;)Z
        //    82: ifeq            156
        //    85: aload           4
        //    87: invokestatic    q/o/m/s/q.ou:(Ljava/util/Iterator;)Ljava/lang/Object;
        //    90: checkcast       Lorg/apache/commons/io/serialization/ClassNameMatcher;
        //    93: astore          5
        //    95: aload           5
        //    97: aload_1        
        //    98: invokeinterface org/apache/commons/io/serialization/ClassNameMatcher.matches:(Ljava/lang/String;)Z
        //   103: aload_2        
        //   104: ifnull          157
        //   107: aload_2        
        //   108: ifnull          140
        //   111: goto            118
        //   114: invokestatic    org/apache/commons/io/serialization/ValidatingObjectInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   117: athrow         
        //   118: aload_2        
        //   119: ifnull          140
        //   122: goto            129
        //   125: invokestatic    org/apache/commons/io/serialization/ValidatingObjectInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   128: athrow         
        //   129: ifeq            145
        //   132: goto            139
        //   135: invokestatic    org/apache/commons/io/serialization/ValidatingObjectInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   138: athrow         
        //   139: iconst_1       
        //   140: istore_3       
        //   141: aload_2        
        //   142: ifnonnull       156
        //   145: aload_2        
        //   146: ifnonnull       77
        //   149: goto            156
        //   152: invokestatic    org/apache/commons/io/serialization/ValidatingObjectInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   155: athrow         
        //   156: iload_3        
        //   157: ifne            172
        //   160: aload_0        
        //   161: aload_1        
        //   162: invokevirtual   org/apache/commons/io/serialization/ValidatingObjectInputStream.invalidClassNameFound:(Ljava/lang/String;)V
        //   165: goto            172
        //   168: invokestatic    org/apache/commons/io/serialization/ValidatingObjectInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   171: athrow         
        //   172: return         
        //    Exceptions:
        //  throws java.io.InvalidClassException
        //    StackMapTable: 00 15 FD 00 0C 07 00 32 07 00 34 FF 00 21 00 05 07 00 02 07 00 44 07 00 32 07 00 34 07 00 3E 00 01 07 00 2B 03 47 07 00 2B 03 FA 00 03 40 01 FF 00 09 00 05 07 00 02 07 00 44 07 00 32 01 07 00 34 00 00 FF 00 24 00 06 07 00 02 07 00 44 07 00 32 01 07 00 34 07 00 3E 00 01 07 00 2B 43 01 46 07 00 2B 43 01 45 07 00 2B 03 40 01 04 46 07 00 2B FA 00 03 40 01 4A 07 00 2B 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                           
        //  -----  -----  -----  -----  -------------------------------
        //  28     43     46     50     Ljava/io/InvalidClassException;
        //  40     55     58     62     Ljava/io/InvalidClassException;
        //  95     111    114    118    Ljava/io/InvalidClassException;
        //  107    122    125    129    Ljava/io/InvalidClassException;
        //  118    132    135    139    Ljava/io/InvalidClassException;
        //  141    149    152    156    Ljava/io/InvalidClassException;
        //  157    165    168    172    Ljava/io/InvalidClassException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0118:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    protected void invalidClassNameFound(final String s) throws InvalidClassException {
        throw new InvalidClassException(q.s(q.r(q.r(new StringBuilder(), ValidatingObjectInputStream.a), s)));
    }
    
    @Override
    protected Class<?> resolveClass(final ObjectStreamClass desc) throws IOException, ClassNotFoundException {
        this.validateClassName(q.hr(desc));
        return super.resolveClass(desc);
    }
    
    public ValidatingObjectInputStream accept(final Class<?>... array) {
        final int length = array.length;
        final int[] b = b();
        int i = 0;
        while (i < length) {
            final Class<?> clazz = array[i];
            try {
                final ValidatingObjectInputStream validatingObjectInputStream = this;
                if (b == null) {
                    return validatingObjectInputStream;
                }
                q.qw(this.acceptMatchers, new FullClassNameMatcher(new String[] { q.gz(clazz) }));
                ++i;
                if (b != null) {
                    continue;
                }
            }
            catch (RuntimeException ex) {
                throw b(ex);
            }
            break;
        }
        return this;
    }
    
    public ValidatingObjectInputStream reject(final Class<?>... array) {
        final int[] b = b();
        final int length = array.length;
        final int[] array2 = b;
        int i = 0;
        while (i < length) {
            final Class<?> clazz = array[i];
            try {
                final ValidatingObjectInputStream validatingObjectInputStream = this;
                if (array2 == null) {
                    return validatingObjectInputStream;
                }
                q.qw(this.rejectMatchers, new FullClassNameMatcher(new String[] { q.gz(clazz) }));
                ++i;
                if (array2 != null) {
                    continue;
                }
            }
            catch (RuntimeException ex) {
                throw b(ex);
            }
            break;
        }
        return this;
    }
    
    public ValidatingObjectInputStream accept(final String... array) {
        final int[] b = b();
        final int length = array.length;
        final int[] array2 = b;
        int i = 0;
        while (i < length) {
            final String s = array[i];
            try {
                final ValidatingObjectInputStream validatingObjectInputStream = this;
                if (array2 == null) {
                    return validatingObjectInputStream;
                }
                q.qw(this.acceptMatchers, new WildcardClassNameMatcher(s));
                ++i;
                if (array2 != null) {
                    continue;
                }
            }
            catch (RuntimeException ex) {
                throw b(ex);
            }
            break;
        }
        return this;
    }
    
    public ValidatingObjectInputStream reject(final String... array) {
        final int[] b = b();
        final int length = array.length;
        int i = 0;
        while (true) {
            while (i < length) {
                final String s = array[i];
                ValidatingObjectInputStream validatingObjectInputStream = null;
                Label_0062: {
                    try {
                        validatingObjectInputStream = this;
                        if (b == null) {
                            break Label_0062;
                        }
                        q.qw(this.rejectMatchers, new WildcardClassNameMatcher(s));
                        ++i;
                        if (b != null) {
                            continue;
                        }
                    }
                    catch (RuntimeException ex) {
                        throw b(ex);
                    }
                    break;
                    try {
                        if (Structure.a() == 0) {
                            b(new int[4]);
                        }
                    }
                    catch (RuntimeException ex2) {
                        throw b(ex2);
                    }
                }
                return validatingObjectInputStream;
            }
            ValidatingObjectInputStream validatingObjectInputStream = this;
            continue;
        }
    }
    
    public ValidatingObjectInputStream accept(final Pattern pattern) {
        q.qw(this.acceptMatchers, new RegexpClassNameMatcher(pattern));
        return this;
    }
    
    public ValidatingObjectInputStream reject(final Pattern pattern) {
        q.qw(this.rejectMatchers, new RegexpClassNameMatcher(pattern));
        return this;
    }
    
    public ValidatingObjectInputStream accept(final ClassNameMatcher classNameMatcher) {
        q.qw(this.acceptMatchers, classNameMatcher);
        return this;
    }
    
    public ValidatingObjectInputStream reject(final ClassNameMatcher classNameMatcher) {
        q.qw(this.rejectMatchers, classNameMatcher);
        return this;
    }
    
    public static void b(final int[] b) {
        ValidatingObjectInputStream.b = b;
    }
    
    public static int[] b() {
        return ValidatingObjectInputStream.b;
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    static {
        b(new int[2]);
        int n3;
        int n2;
        final int n = n2 = (n3 = 81);
        final char[] g = q.g(n.d.a.d.q.tg());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0135: {
                if (length > 1) {
                    break Label_0135;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 95;
                            break;
                        }
                        case 1: {
                            n5 = 113;
                            break;
                        }
                        case 2: {
                            n5 = 87;
                            break;
                        }
                        case 3: {
                            n5 = 122;
                            break;
                        }
                        case 4: {
                            n5 = 126;
                            break;
                        }
                        case 5: {
                            n5 = 66;
                            break;
                        }
                        default: {
                            n5 = 4;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
