// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.serialization;

import java.util.Collection;
import java.util.HashSet;
import q.o.m.s.q;
import java.util.Set;

final class FullClassNameMatcher implements ClassNameMatcher
{
    private final Set<String> classesSet;
    
    public FullClassNameMatcher(final String... array) {
        this.classesSet = (Set<String>)q.gj(new HashSet(q.et(array)));
    }
    
    @Override
    public boolean matches(final String s) {
        return q.gg(this.classesSet, s);
    }
}
