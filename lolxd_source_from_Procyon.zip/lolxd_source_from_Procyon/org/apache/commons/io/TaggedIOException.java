// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import q.o.m.s.q;
import java.io.IOException;
import java.io.Serializable;

public class TaggedIOException extends IOExceptionWithCause
{
    private static final long serialVersionUID = -6994123481142850163L;
    private final Serializable tag;
    
    public static boolean isTaggedWith(final Throwable p0, final Object p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_1        
        //     5: ifnull          91
        //     8: aload_0        
        //     9: instanceof      Lorg/apache/commons/io/TaggedIOException;
        //    12: iload_2        
        //    13: ifne            62
        //    16: goto            23
        //    19: invokestatic    org/apache/commons/io/TaggedIOException.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    22: athrow         
        //    23: iload_2        
        //    24: ifne            66
        //    27: goto            34
        //    30: invokestatic    org/apache/commons/io/TaggedIOException.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    33: athrow         
        //    34: ifeq            91
        //    37: goto            44
        //    40: invokestatic    org/apache/commons/io/TaggedIOException.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    43: athrow         
        //    44: aload_1        
        //    45: aload_0        
        //    46: checkcast       Lorg/apache/commons/io/TaggedIOException;
        //    49: getfield        org/apache/commons/io/TaggedIOException.tag:Ljava/io/Serializable;
        //    52: invokestatic    q/o/m/s/q.co:(Ljava/lang/Object;Ljava/lang/Object;)Z
        //    55: goto            62
        //    58: invokestatic    org/apache/commons/io/TaggedIOException.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    61: athrow         
        //    62: iload_2        
        //    63: ifne            88
        //    66: iload_2        
        //    67: ifne            88
        //    70: goto            77
        //    73: invokestatic    org/apache/commons/io/TaggedIOException.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    76: athrow         
        //    77: ifeq            91
        //    80: goto            87
        //    83: invokestatic    org/apache/commons/io/TaggedIOException.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    86: athrow         
        //    87: iconst_1       
        //    88: goto            92
        //    91: iconst_0       
        //    92: ireturn        
        //    StackMapTable: 00 10 FF 00 13 00 03 07 00 17 07 00 19 01 00 01 07 00 0F 43 01 46 07 00 0F 43 01 45 07 00 0F 03 4D 07 00 0F 43 01 43 01 46 07 00 0F 43 01 45 07 00 0F 03 40 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      16     19     23     Ljava/lang/RuntimeException;
        //  8      27     30     34     Ljava/lang/RuntimeException;
        //  23     37     40     44     Ljava/lang/RuntimeException;
        //  34     55     58     62     Ljava/lang/RuntimeException;
        //  62     70     73     77     Ljava/lang/RuntimeException;
        //  66     80     83     87     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0023:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void throwCauseIfTaggedWith(final Throwable p0, final Object p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: iload_2        
        //     6: ifeq            42
        //     9: iload_2        
        //    10: ifeq            42
        //    13: goto            20
        //    16: invokestatic    org/apache/commons/io/TaggedIOException.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    19: athrow         
        //    20: aload_1        
        //    21: invokestatic    org/apache/commons/io/TaggedIOException.isTaggedWith:(Ljava/lang/Throwable;Ljava/lang/Object;)Z
        //    24: ifeq            49
        //    27: goto            34
        //    30: invokestatic    org/apache/commons/io/TaggedIOException.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    33: athrow         
        //    34: aload_0        
        //    35: goto            42
        //    38: invokestatic    org/apache/commons/io/TaggedIOException.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    41: athrow         
        //    42: checkcast       Lorg/apache/commons/io/TaggedIOException;
        //    45: invokevirtual   org/apache/commons/io/TaggedIOException.getCause:()Ljava/io/IOException;
        //    48: athrow         
        //    49: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 07 FF 00 10 00 03 07 00 17 07 00 19 01 00 01 07 00 28 43 07 00 17 49 07 00 28 03 43 07 00 28 43 07 00 17 06
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      13     16     20     Ljava/io/IOException;
        //  9      27     30     34     Ljava/io/IOException;
        //  20     35     38     42     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public TaggedIOException(final IOException ex, final Serializable tag) {
        super(q.cq(ex), ex);
        this.tag = tag;
    }
    
    public Serializable getTag() {
        return this.tag;
    }
    
    @Override
    public IOException getCause() {
        return (IOException)super.getCause();
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
}
