// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import java.util.Comparator;
import java.util.TreeMap;
import x.dn.g.b.q;
import java.util.SortedMap;
import java.nio.charset.Charset;

public class Charsets
{
    @Deprecated
    public static final Charset ISO_8859_1;
    @Deprecated
    public static final Charset US_ASCII;
    @Deprecated
    public static final Charset UTF_16;
    @Deprecated
    public static final Charset UTF_16BE;
    @Deprecated
    public static final Charset UTF_16LE;
    @Deprecated
    public static final Charset UTF_8;
    
    public static SortedMap<String, Charset> requiredCharsets() {
        final TreeMap treeMap = new TreeMap(q.s());
        q.o.m.s.q.sy(treeMap, q.o.m.s.q.sp(Charsets.ISO_8859_1), Charsets.ISO_8859_1);
        q.o.m.s.q.sy(treeMap, q.o.m.s.q.sp(Charsets.US_ASCII), Charsets.US_ASCII);
        q.o.m.s.q.sy(treeMap, q.o.m.s.q.sp(Charsets.UTF_16), Charsets.UTF_16);
        q.o.m.s.q.sy(treeMap, q.o.m.s.q.sp(Charsets.UTF_16BE), Charsets.UTF_16BE);
        q.o.m.s.q.sy(treeMap, q.o.m.s.q.sp(Charsets.UTF_16LE), Charsets.UTF_16LE);
        q.o.m.s.q.sy(treeMap, q.o.m.s.q.sp(Charsets.UTF_8), Charsets.UTF_8);
        return (SortedMap<String, Charset>)q.o.m.s.q.sc(treeMap);
    }
    
    public static Charset toCharset(final Charset charset) {
        final int b = IOCase.b();
        Label_0020: {
            Charset sx;
            try {
                sx = charset;
                if (b != 0) {
                    return sx;
                }
                final int n = b;
                if (n == 0) {
                    break Label_0020;
                }
                return sx;
            }
            catch (RuntimeException ex) {
                throw b(ex);
            }
            try {
                final int n = b;
                if (n != 0) {
                    return sx;
                }
                if (charset != null) {
                    return charset;
                }
            }
            catch (RuntimeException ex2) {
                throw b(ex2);
            }
        }
        return q.o.m.s.q.sx();
        sx = charset;
        return sx;
    }
    
    public static Charset toCharset(final String s) {
        final int b = IOCase.b();
        Label_0019: {
            try {
                final String s2 = s;
                if (b != 0) {
                    return q.o.m.s.q.sh(s2);
                }
                if (s == null) {
                    break Label_0019;
                }
                break Label_0019;
            }
            catch (RuntimeException ex) {
                throw b(ex);
            }
            try {
                if (s == null) {
                    return q.o.m.s.q.sx();
                }
            }
            catch (RuntimeException ex2) {
                throw b(ex2);
            }
        }
        final String s2 = s;
        return q.o.m.s.q.sh(s2);
    }
    
    static {
        final String[] array = new String[6];
        int n = 0;
        String s;
        int n2 = q.o.m.s.q.q(s = n.d.a.d.q.ma());
        int n3 = 5;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 57));
                ++n4;
                final String s2 = s;
                final int n9 = n4;
                String s3 = q.o.m.s.q.h(s2, n9, n9 + n3);
                int n10 = -1;
                while (true) {
                    final char[] g = q.o.m.s.q.g(s3);
                    final int length = g.length;
                    int n11 = 0;
                    while (true) {
                        Label_0256: {
                            if (length > 1) {
                                break Label_0256;
                            }
                            n7 = (n6 = n11);
                            do {
                                final char c = g[n6];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 71;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 88;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 120;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 64;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 54;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 44;
                                        break;
                                    }
                                    default: {
                                        n12 = 56;
                                        break;
                                    }
                                }
                                g[n7] = (char)(c ^ (n5 ^ n12));
                                ++n11;
                            } while (n8 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.o.m.s.q.z(new String(g));
                    switch (n10) {
                        default: {
                            array[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.o.m.s.q.j(s, n4);
                                continue Label_0024;
                            }
                            n2 = q.o.m.s.q.q(s = n.d.a.d.q.ml());
                            n3 = 10;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            array[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.o.m.s.q.j(s, n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 105)));
                    ++n4;
                    final String s4 = s;
                    final int n13 = n4;
                    s3 = q.o.m.s.q.h(s4, n13, n13 + n3);
                    n10 = 0;
                }
            }
            break;
        }
        final String[] array2 = array;
        ISO_8859_1 = q.o.m.s.q.sh(array2[4]);
        US_ASCII = q.o.m.s.q.sh(array2[2]);
        UTF_16 = q.o.m.s.q.sh(array2[5]);
        UTF_16BE = q.o.m.s.q.sh(array2[1]);
        UTF_16LE = q.o.m.s.q.sh(array2[3]);
        UTF_8 = q.o.m.s.q.sh(array2[0]);
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
