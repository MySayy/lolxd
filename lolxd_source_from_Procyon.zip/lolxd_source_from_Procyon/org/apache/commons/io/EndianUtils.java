// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import java.io.EOFException;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import com.sun.jna.Structure;
import q.o.m.s.q;

public class EndianUtils
{
    private static final String a;
    
    public static short swapShort(final short n) {
        return (short)(((n >> 0 & 0xFF) << 8) + ((n >> 8 & 0xFF) << 0));
    }
    
    public static int swapInteger(final int n) {
        return ((n >> 0 & 0xFF) << 24) + ((n >> 8 & 0xFF) << 16) + ((n >> 16 & 0xFF) << 8) + ((n >> 24 & 0xFF) << 0);
    }
    
    public static long swapLong(final long n) {
        return ((n >> 0 & 0xFFL) << 56) + ((n >> 8 & 0xFFL) << 48) + ((n >> 16 & 0xFFL) << 40) + ((n >> 24 & 0xFFL) << 32) + ((n >> 32 & 0xFFL) << 24) + ((n >> 40 & 0xFFL) << 16) + ((n >> 48 & 0xFFL) << 8) + ((n >> 56 & 0xFFL) << 0);
    }
    
    public static float swapFloat(final float n) {
        return q.km(swapInteger(q.kf(n)));
    }
    
    public static double swapDouble(final double n) {
        return q.ko(swapLong(q.kv(n)));
    }
    
    public static void writeSwappedShort(final byte[] array, final int n, final short n2) {
        array[n + 0] = (byte)(n2 >> 0 & 0xFF);
        array[n + 1] = (byte)(n2 >> 8 & 0xFF);
    }
    
    public static short readSwappedShort(final byte[] array, final int n) {
        return (short)(((array[n + 0] & 0xFF) << 0) + ((array[n + 1] & 0xFF) << 8));
    }
    
    public static int readSwappedUnsignedShort(final byte[] array, final int n) {
        return ((array[n + 0] & 0xFF) << 0) + ((array[n + 1] & 0xFF) << 8);
    }
    
    public static void writeSwappedInteger(final byte[] array, final int n, final int n2) {
        array[n + 0] = (byte)(n2 >> 0 & 0xFF);
        array[n + 1] = (byte)(n2 >> 8 & 0xFF);
        array[n + 2] = (byte)(n2 >> 16 & 0xFF);
        array[n + 3] = (byte)(n2 >> 24 & 0xFF);
    }
    
    public static int readSwappedInteger(final byte[] array, final int n) {
        return ((array[n + 0] & 0xFF) << 0) + ((array[n + 1] & 0xFF) << 8) + ((array[n + 2] & 0xFF) << 16) + ((array[n + 3] & 0xFF) << 24);
    }
    
    public static long readSwappedUnsignedInteger(final byte[] array, final int n) {
        return ((long)(array[n + 3] & 0xFF) << 24) + (0xFFFFFFFFL & (long)(((array[n + 0] & 0xFF) << 0) + ((array[n + 1] & 0xFF) << 8) + ((array[n + 2] & 0xFF) << 16)));
    }
    
    public static void writeSwappedLong(final byte[] array, final int n, final long n2) {
        array[n + 0] = (byte)(n2 >> 0 & 0xFFL);
        array[n + 1] = (byte)(n2 >> 8 & 0xFFL);
        array[n + 2] = (byte)(n2 >> 16 & 0xFFL);
        final int c = IOCase.c();
        array[n + 3] = (byte)(n2 >> 24 & 0xFFL);
        array[n + 4] = (byte)(n2 >> 32 & 0xFFL);
        array[n + 5] = (byte)(n2 >> 40 & 0xFFL);
        array[n + 6] = (byte)(n2 >> 48 & 0xFFL);
        array[n + 7] = (byte)(n2 >> 56 & 0xFFL);
        if (c == 0) {
            int b = Structure.b();
            Structure.b(++b);
        }
    }
    
    public static long readSwappedLong(final byte[] array, final int n) {
        return ((long)readSwappedInteger(array, n + 4) << 32) + (0xFFFFFFFFL & (long)readSwappedInteger(array, n));
    }
    
    public static void writeSwappedFloat(final byte[] array, final int n, final float n2) {
        writeSwappedInteger(array, n, q.kf(n2));
    }
    
    public static float readSwappedFloat(final byte[] array, final int n) {
        return q.km(readSwappedInteger(array, n));
    }
    
    public static void writeSwappedDouble(final byte[] array, final int n, final double n2) {
        writeSwappedLong(array, n, q.kv(n2));
    }
    
    public static double readSwappedDouble(final byte[] array, final int n) {
        return q.ko(readSwappedLong(array, n));
    }
    
    public static void writeSwappedShort(final OutputStream outputStream, final short n) throws IOException {
        q.kq(outputStream, (byte)(n >> 0 & 0xFF));
        q.kq(outputStream, (byte)(n >> 8 & 0xFF));
    }
    
    public static short readSwappedShort(final InputStream inputStream) throws IOException {
        return (short)(((read(inputStream) & 0xFF) << 0) + ((read(inputStream) & 0xFF) << 8));
    }
    
    public static int readSwappedUnsignedShort(final InputStream inputStream) throws IOException {
        return ((read(inputStream) & 0xFF) << 0) + ((read(inputStream) & 0xFF) << 8);
    }
    
    public static void writeSwappedInteger(final OutputStream outputStream, final int n) throws IOException {
        q.kq(outputStream, (byte)(n >> 0 & 0xFF));
        q.kq(outputStream, (byte)(n >> 8 & 0xFF));
        q.kq(outputStream, (byte)(n >> 16 & 0xFF));
        q.kq(outputStream, (byte)(n >> 24 & 0xFF));
    }
    
    public static int readSwappedInteger(final InputStream inputStream) throws IOException {
        return ((read(inputStream) & 0xFF) << 0) + ((read(inputStream) & 0xFF) << 8) + ((read(inputStream) & 0xFF) << 16) + ((read(inputStream) & 0xFF) << 24);
    }
    
    public static long readSwappedUnsignedInteger(final InputStream inputStream) throws IOException {
        return ((long)(read(inputStream) & 0xFF) << 24) + (0xFFFFFFFFL & (long)(((read(inputStream) & 0xFF) << 0) + ((read(inputStream) & 0xFF) << 8) + ((read(inputStream) & 0xFF) << 16)));
    }
    
    public static void writeSwappedLong(final OutputStream outputStream, final long n) throws IOException {
        q.kq(outputStream, (byte)(n >> 0 & 0xFFL));
        q.kq(outputStream, (byte)(n >> 8 & 0xFFL));
        q.kq(outputStream, (byte)(n >> 16 & 0xFFL));
        q.kq(outputStream, (byte)(n >> 24 & 0xFFL));
        q.kq(outputStream, (byte)(n >> 32 & 0xFFL));
        q.kq(outputStream, (byte)(n >> 40 & 0xFFL));
        q.kq(outputStream, (byte)(n >> 48 & 0xFFL));
        q.kq(outputStream, (byte)(n >> 56 & 0xFFL));
    }
    
    public static long readSwappedLong(final InputStream inputStream) throws IOException {
        final int c = IOCase.c();
        final byte[] array = new byte[8];
        final int n = c;
        int i = 0;
        byte[] array2 = null;
        int n2 = 0;
        while (i < 8) {
            try {
                array2 = array;
                n2 = i;
                if (n == 0) {
                    return readSwappedLong(array2, n2);
                }
                array2[n2] = (byte)read(inputStream);
                ++i;
                if (n != 0) {
                    continue;
                }
            }
            catch (IOException ex) {
                throw b(ex);
            }
            break;
        }
        return readSwappedLong(array2, n2);
    }
    
    public static void writeSwappedFloat(final OutputStream outputStream, final float n) throws IOException {
        writeSwappedInteger(outputStream, q.kf(n));
    }
    
    public static float readSwappedFloat(final InputStream inputStream) throws IOException {
        return q.km(readSwappedInteger(inputStream));
    }
    
    public static void writeSwappedDouble(final OutputStream outputStream, final double n) throws IOException {
        writeSwappedLong(outputStream, q.kv(n));
    }
    
    public static double readSwappedDouble(final InputStream inputStream) throws IOException {
        return q.ko(readSwappedLong(inputStream));
    }
    
    private static int read(final InputStream inputStream) throws IOException {
        final int c = IOCase.c();
        final int kt = q.kt(inputStream);
        final int n = c;
        Label_0025: {
            int n2;
            try {
                final int n3;
                n2 = (n3 = -1);
                if (n == 0) {
                    return n3;
                }
                final int n4 = kt;
                if (n2 == n4) {
                    break Label_0025;
                }
                return kt;
            }
            catch (IOException ex) {
                throw b(ex);
            }
            try {
                final int n4 = kt;
                if (n2 == n4) {
                    throw new EOFException(EndianUtils.a);
                }
            }
            catch (IOException ex2) {
                throw b(ex2);
            }
        }
        return kt;
    }
    
    private static IOException b(final IOException ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 123);
        final char[] g = q.g(n.d.a.d.q.vf());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 6;
                            break;
                        }
                        case 1: {
                            n5 = 112;
                            break;
                        }
                        case 2: {
                            n5 = 119;
                            break;
                        }
                        case 3: {
                            n5 = 24;
                            break;
                        }
                        case 4: {
                            n5 = 23;
                            break;
                        }
                        case 5: {
                            n5 = 19;
                            break;
                        }
                        default: {
                            n5 = 35;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
