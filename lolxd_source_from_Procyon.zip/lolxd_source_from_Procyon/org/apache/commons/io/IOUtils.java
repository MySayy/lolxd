// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import java.io.PrintWriter;
import java.io.EOFException;
import java.nio.ByteBuffer;
import java.nio.channels.ReadableByteChannel;
import java.io.OutputStreamWriter;
import java.util.Iterator;
import java.util.Collection;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.io.InputStreamReader;
import java.util.List;
import org.apache.commons.io.output.StringBuilderWriter;
import java.io.CharArrayWriter;
import java.net.URL;
import java.net.URI;
import java.nio.charset.Charset;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import org.apache.commons.io.output.ByteArrayOutputStream;
import java.net.ServerSocket;
import java.nio.channels.Selector;
import java.net.Socket;
import q.o.m.s.q;
import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.Writer;
import java.io.Closeable;
import java.io.Reader;
import java.net.URLConnection;

public class IOUtils
{
    public static final int EOF = -1;
    public static final char DIR_SEPARATOR_UNIX = '/';
    public static final char DIR_SEPARATOR_WINDOWS = '\\';
    public static final char DIR_SEPARATOR;
    public static final String LINE_SEPARATOR_UNIX = "\n";
    public static final String LINE_SEPARATOR_WINDOWS;
    public static final String LINE_SEPARATOR;
    private static final int DEFAULT_BUFFER_SIZE = 4096;
    private static final int SKIP_BUFFER_SIZE = 2048;
    private static char[] SKIP_CHAR_BUFFER;
    private static byte[] SKIP_BYTE_BUFFER;
    private static final String[] a;
    private static final String[] b;
    
    public static void close(final URLConnection p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: iload_1        
        //     6: ifeq            41
        //     9: iload_1        
        //    10: ifeq            41
        //    13: goto            20
        //    16: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    19: athrow         
        //    20: instanceof      Ljava/net/HttpURLConnection;
        //    23: ifeq            47
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    32: athrow         
        //    33: aload_0        
        //    34: goto            41
        //    37: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    40: athrow         
        //    41: checkcast       Ljava/net/HttpURLConnection;
        //    44: invokestatic    q/o/m/s/q.yr:(Ljava/net/HttpURLConnection;)V
        //    47: return         
        //    StackMapTable: 00 07 FF 00 10 00 02 07 00 2F 01 00 01 07 00 27 43 07 00 2F 48 07 00 27 03 43 07 00 27 43 07 00 2F 05
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      13     16     20     Ljava/lang/NullPointerException;
        //  9      26     29     33     Ljava/lang/NullPointerException;
        //  20     34     37     41     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void closeQuietly(final Reader reader) {
        closeQuietly((Closeable)reader);
    }
    
    public static void closeQuietly(final Writer writer) {
        closeQuietly((Closeable)writer);
    }
    
    public static void closeQuietly(final InputStream inputStream) {
        closeQuietly((Closeable)inputStream);
    }
    
    public static void closeQuietly(final OutputStream outputStream) {
        closeQuietly((Closeable)outputStream);
    }
    
    public static void closeQuietly(final Closeable closeable) {
        final int c = IOCase.c();
        try {
            Closeable closeable2 = null;
            Label_0031: {
                Label_0020: {
                    try {
                        closeable2 = closeable;
                        if (c == 0) {
                            break Label_0031;
                        }
                        final int n = c;
                        if (n != 0) {
                            break Label_0020;
                        }
                        break Label_0031;
                    }
                    catch (IOException ex) {
                        throw b(ex);
                    }
                    try {
                        final int n = c;
                        if (n == 0) {
                            break Label_0031;
                        }
                        if (closeable == null) {
                            return;
                        }
                    }
                    catch (IOException ex2) {
                        throw b(ex2);
                    }
                }
                closeable2 = closeable;
            }
            q.ys(closeable2);
        }
        catch (IOException ex3) {}
    }
    
    public static void closeQuietly(final Closeable... array) {
        final int c = IOCase.c();
        Closeable[] array2 = null;
        Label_0021: {
            Label_0020: {
                try {
                    array2 = array;
                    if (c == 0) {
                        break Label_0021;
                    }
                    if (array != null) {
                        break Label_0020;
                    }
                }
                catch (NullPointerException ex) {
                    throw b(ex);
                }
                return;
            }
            array2 = array;
        }
        final Closeable[] array3 = array2;
        final int length = array3.length;
        int i = 0;
        while (i < length) {
            closeQuietly(array3[i]);
            ++i;
            if (c == 0) {
                break;
            }
        }
    }
    
    public static void closeQuietly(final Socket socket) {
        final int b = IOCase.b();
        Label_0031: {
            Label_0020: {
                try {
                    final Socket socket2 = socket;
                    if (b != 0) {
                        break Label_0031;
                    }
                    final int n = b;
                    if (n == 0) {
                        break Label_0020;
                    }
                    break Label_0031;
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                try {
                    final int n = b;
                    if (n != 0) {
                        break Label_0031;
                    }
                    if (socket == null) {
                        return;
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            try {
                final Socket socket2 = socket;
                q.mc(socket2);
            }
            catch (IOException ex3) {}
        }
    }
    
    public static void closeQuietly(final Selector selector) {
        final int b = IOCase.b();
        Label_0031: {
            Label_0020: {
                try {
                    final Selector selector2 = selector;
                    if (b != 0) {
                        break Label_0031;
                    }
                    final int n = b;
                    if (n == 0) {
                        break Label_0020;
                    }
                    break Label_0031;
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                try {
                    final int n = b;
                    if (n != 0) {
                        break Label_0031;
                    }
                    if (selector == null) {
                        return;
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            try {
                final Selector selector2 = selector;
                q.yk(selector2);
            }
            catch (IOException ex3) {}
        }
    }
    
    public static void closeQuietly(final ServerSocket serverSocket) {
        final int c = IOCase.c();
        Label_0031: {
            Label_0020: {
                try {
                    final ServerSocket serverSocket2 = serverSocket;
                    if (c == 0) {
                        break Label_0031;
                    }
                    final int n = c;
                    if (n != 0) {
                        break Label_0020;
                    }
                    break Label_0031;
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                try {
                    final int n = c;
                    if (n == 0) {
                        break Label_0031;
                    }
                    if (serverSocket == null) {
                        return;
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            try {
                final ServerSocket serverSocket2 = serverSocket;
                q.ye(serverSocket2);
            }
            catch (IOException ex3) {}
        }
    }
    
    public static InputStream toBufferedInputStream(final InputStream inputStream) throws IOException {
        return ByteArrayOutputStream.toBufferedInputStream(inputStream);
    }
    
    public static InputStream toBufferedInputStream(final InputStream inputStream, final int n) throws IOException {
        return ByteArrayOutputStream.toBufferedInputStream(inputStream, n);
    }
    
    public static BufferedReader toBufferedReader(final Reader p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: iload_1        
        //     6: ifne            41
        //     9: iload_1        
        //    10: ifne            41
        //    13: goto            20
        //    16: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    19: athrow         
        //    20: instanceof      Ljava/io/BufferedReader;
        //    23: ifeq            47
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    32: athrow         
        //    33: aload_0        
        //    34: goto            41
        //    37: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    40: athrow         
        //    41: checkcast       Ljava/io/BufferedReader;
        //    44: goto            55
        //    47: new             Ljava/io/BufferedReader;
        //    50: dup            
        //    51: aload_0        
        //    52: invokespecial   java/io/BufferedReader.<init>:(Ljava/io/Reader;)V
        //    55: areturn        
        //    StackMapTable: 00 08 FF 00 10 00 02 07 00 6D 01 00 01 07 00 27 43 07 00 6D 48 07 00 27 03 43 07 00 27 43 07 00 6D 05 47 07 00 6F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      13     16     20     Ljava/lang/NullPointerException;
        //  9      26     29     33     Ljava/lang/NullPointerException;
        //  20     34     37     41     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static BufferedReader toBufferedReader(final Reader p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: iload_2        
        //     6: ifeq            41
        //     9: iload_2        
        //    10: ifeq            41
        //    13: goto            20
        //    16: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    19: athrow         
        //    20: instanceof      Ljava/io/BufferedReader;
        //    23: ifeq            47
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    32: athrow         
        //    33: aload_0        
        //    34: goto            41
        //    37: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    40: athrow         
        //    41: checkcast       Ljava/io/BufferedReader;
        //    44: goto            56
        //    47: new             Ljava/io/BufferedReader;
        //    50: dup            
        //    51: aload_0        
        //    52: iload_1        
        //    53: invokespecial   java/io/BufferedReader.<init>:(Ljava/io/Reader;I)V
        //    56: areturn        
        //    StackMapTable: 00 08 FF 00 10 00 03 07 00 6D 01 01 00 01 07 00 27 43 07 00 6D 48 07 00 27 03 43 07 00 27 43 07 00 6D 05 48 07 00 6F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      13     16     20     Ljava/lang/NullPointerException;
        //  9      26     29     33     Ljava/lang/NullPointerException;
        //  20     34     37     41     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static BufferedReader buffer(final Reader p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: iload_1        
        //     6: ifne            41
        //     9: iload_1        
        //    10: ifne            41
        //    13: goto            20
        //    16: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    19: athrow         
        //    20: instanceof      Ljava/io/BufferedReader;
        //    23: ifeq            47
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    32: athrow         
        //    33: aload_0        
        //    34: goto            41
        //    37: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    40: athrow         
        //    41: checkcast       Ljava/io/BufferedReader;
        //    44: goto            55
        //    47: new             Ljava/io/BufferedReader;
        //    50: dup            
        //    51: aload_0        
        //    52: invokespecial   java/io/BufferedReader.<init>:(Ljava/io/Reader;)V
        //    55: areturn        
        //    StackMapTable: 00 08 FF 00 10 00 02 07 00 6D 01 00 01 07 00 27 43 07 00 6D 48 07 00 27 03 43 07 00 27 43 07 00 6D 05 47 07 00 6F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      13     16     20     Ljava/lang/NullPointerException;
        //  9      26     29     33     Ljava/lang/NullPointerException;
        //  20     34     37     41     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static BufferedReader buffer(final Reader p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: iload_2        
        //     6: ifne            41
        //     9: iload_2        
        //    10: ifne            41
        //    13: goto            20
        //    16: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    19: athrow         
        //    20: instanceof      Ljava/io/BufferedReader;
        //    23: ifeq            47
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    32: athrow         
        //    33: aload_0        
        //    34: goto            41
        //    37: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    40: athrow         
        //    41: checkcast       Ljava/io/BufferedReader;
        //    44: goto            56
        //    47: new             Ljava/io/BufferedReader;
        //    50: dup            
        //    51: aload_0        
        //    52: iload_1        
        //    53: invokespecial   java/io/BufferedReader.<init>:(Ljava/io/Reader;I)V
        //    56: areturn        
        //    StackMapTable: 00 08 FF 00 10 00 03 07 00 6D 01 01 00 01 07 00 27 43 07 00 6D 48 07 00 27 03 43 07 00 27 43 07 00 6D 05 48 07 00 6F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      13     16     20     Ljava/lang/NullPointerException;
        //  9      26     29     33     Ljava/lang/NullPointerException;
        //  20     34     37     41     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static BufferedWriter buffer(final Writer p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: iload_1        
        //     6: ifne            41
        //     9: iload_1        
        //    10: ifne            41
        //    13: goto            20
        //    16: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    19: athrow         
        //    20: instanceof      Ljava/io/BufferedWriter;
        //    23: ifeq            47
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    32: athrow         
        //    33: aload_0        
        //    34: goto            41
        //    37: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    40: athrow         
        //    41: checkcast       Ljava/io/BufferedWriter;
        //    44: goto            55
        //    47: new             Ljava/io/BufferedWriter;
        //    50: dup            
        //    51: aload_0        
        //    52: invokespecial   java/io/BufferedWriter.<init>:(Ljava/io/Writer;)V
        //    55: areturn        
        //    StackMapTable: 00 08 FF 00 10 00 02 07 00 79 01 00 01 07 00 27 43 07 00 79 48 07 00 27 03 43 07 00 27 43 07 00 79 05 47 07 00 7B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      13     16     20     Ljava/lang/NullPointerException;
        //  9      26     29     33     Ljava/lang/NullPointerException;
        //  20     34     37     41     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static BufferedWriter buffer(final Writer p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: iload_2        
        //     6: ifeq            41
        //     9: iload_2        
        //    10: ifeq            41
        //    13: goto            20
        //    16: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    19: athrow         
        //    20: instanceof      Ljava/io/BufferedWriter;
        //    23: ifeq            47
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    32: athrow         
        //    33: aload_0        
        //    34: goto            41
        //    37: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    40: athrow         
        //    41: checkcast       Ljava/io/BufferedWriter;
        //    44: goto            56
        //    47: new             Ljava/io/BufferedWriter;
        //    50: dup            
        //    51: aload_0        
        //    52: iload_1        
        //    53: invokespecial   java/io/BufferedWriter.<init>:(Ljava/io/Writer;I)V
        //    56: areturn        
        //    StackMapTable: 00 08 FF 00 10 00 03 07 00 79 01 01 00 01 07 00 27 43 07 00 79 48 07 00 27 03 43 07 00 27 43 07 00 79 05 48 07 00 7B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      13     16     20     Ljava/lang/NullPointerException;
        //  9      26     29     33     Ljava/lang/NullPointerException;
        //  20     34     37     41     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static BufferedOutputStream buffer(final OutputStream p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: iload_1        
        //     6: ifne            36
        //     9: ifnonnull       31
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: new             Ljava/lang/NullPointerException;
        //    22: dup            
        //    23: invokespecial   java/lang/NullPointerException.<init>:()V
        //    26: athrow         
        //    27: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    30: athrow         
        //    31: aload_0        
        //    32: iload_1        
        //    33: ifne            68
        //    36: iload_1        
        //    37: ifne            68
        //    40: goto            47
        //    43: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    46: athrow         
        //    47: instanceof      Ljava/io/BufferedOutputStream;
        //    50: ifeq            74
        //    53: goto            60
        //    56: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    59: athrow         
        //    60: aload_0        
        //    61: goto            68
        //    64: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    67: athrow         
        //    68: checkcast       Ljava/io/BufferedOutputStream;
        //    71: goto            82
        //    74: new             Ljava/io/BufferedOutputStream;
        //    77: dup            
        //    78: aload_0        
        //    79: invokespecial   java/io/BufferedOutputStream.<init>:(Ljava/io/OutputStream;)V
        //    82: areturn        
        //    StackMapTable: 00 0D FF 00 0F 00 02 07 00 84 01 00 01 07 00 27 03 47 07 00 27 03 44 07 00 84 46 07 00 27 43 07 00 84 48 07 00 27 03 43 07 00 27 43 07 00 84 05 47 07 00 87
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      12     15     19     Ljava/lang/NullPointerException;
        //  9      27     27     31     Ljava/lang/NullPointerException;
        //  31     40     43     47     Ljava/lang/NullPointerException;
        //  36     53     56     60     Ljava/lang/NullPointerException;
        //  47     61     64     68     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0036:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static BufferedOutputStream buffer(final OutputStream p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: iload_2        
        //     6: ifeq            36
        //     9: ifnonnull       31
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: new             Ljava/lang/NullPointerException;
        //    22: dup            
        //    23: invokespecial   java/lang/NullPointerException.<init>:()V
        //    26: athrow         
        //    27: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    30: athrow         
        //    31: aload_0        
        //    32: iload_2        
        //    33: ifeq            68
        //    36: iload_2        
        //    37: ifeq            68
        //    40: goto            47
        //    43: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    46: athrow         
        //    47: instanceof      Ljava/io/BufferedOutputStream;
        //    50: ifeq            74
        //    53: goto            60
        //    56: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    59: athrow         
        //    60: aload_0        
        //    61: goto            68
        //    64: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    67: athrow         
        //    68: checkcast       Ljava/io/BufferedOutputStream;
        //    71: goto            83
        //    74: new             Ljava/io/BufferedOutputStream;
        //    77: dup            
        //    78: aload_0        
        //    79: iload_1        
        //    80: invokespecial   java/io/BufferedOutputStream.<init>:(Ljava/io/OutputStream;I)V
        //    83: areturn        
        //    StackMapTable: 00 0D FF 00 0F 00 03 07 00 84 01 01 00 01 07 00 27 03 47 07 00 27 03 44 07 00 84 46 07 00 27 43 07 00 84 48 07 00 27 03 43 07 00 27 43 07 00 84 05 48 07 00 87
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      12     15     19     Ljava/lang/NullPointerException;
        //  9      27     27     31     Ljava/lang/NullPointerException;
        //  31     40     43     47     Ljava/lang/NullPointerException;
        //  36     53     56     60     Ljava/lang/NullPointerException;
        //  47     61     64     68     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0036:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static BufferedInputStream buffer(final InputStream p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: aload_0        
        //     5: iload_1        
        //     6: ifne            36
        //     9: ifnonnull       31
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: new             Ljava/lang/NullPointerException;
        //    22: dup            
        //    23: invokespecial   java/lang/NullPointerException.<init>:()V
        //    26: athrow         
        //    27: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    30: athrow         
        //    31: aload_0        
        //    32: iload_1        
        //    33: ifne            68
        //    36: iload_1        
        //    37: ifne            68
        //    40: goto            47
        //    43: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    46: athrow         
        //    47: instanceof      Ljava/io/BufferedInputStream;
        //    50: ifeq            74
        //    53: goto            60
        //    56: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    59: athrow         
        //    60: aload_0        
        //    61: goto            68
        //    64: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    67: athrow         
        //    68: checkcast       Ljava/io/BufferedInputStream;
        //    71: goto            82
        //    74: new             Ljava/io/BufferedInputStream;
        //    77: dup            
        //    78: aload_0        
        //    79: invokespecial   java/io/BufferedInputStream.<init>:(Ljava/io/InputStream;)V
        //    82: areturn        
        //    StackMapTable: 00 0D FF 00 0F 00 02 07 00 90 01 00 01 07 00 27 03 47 07 00 27 03 44 07 00 90 46 07 00 27 43 07 00 90 48 07 00 27 03 43 07 00 27 43 07 00 90 05 47 07 00 92
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      12     15     19     Ljava/lang/NullPointerException;
        //  9      27     27     31     Ljava/lang/NullPointerException;
        //  31     40     43     47     Ljava/lang/NullPointerException;
        //  36     53     56     60     Ljava/lang/NullPointerException;
        //  47     61     64     68     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0036:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static BufferedInputStream buffer(final InputStream p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_0        
        //     5: iload_2        
        //     6: ifne            36
        //     9: ifnonnull       31
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: new             Ljava/lang/NullPointerException;
        //    22: dup            
        //    23: invokespecial   java/lang/NullPointerException.<init>:()V
        //    26: athrow         
        //    27: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    30: athrow         
        //    31: aload_0        
        //    32: iload_2        
        //    33: ifne            68
        //    36: iload_2        
        //    37: ifne            68
        //    40: goto            47
        //    43: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    46: athrow         
        //    47: instanceof      Ljava/io/BufferedInputStream;
        //    50: ifeq            74
        //    53: goto            60
        //    56: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    59: athrow         
        //    60: aload_0        
        //    61: goto            68
        //    64: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    67: athrow         
        //    68: checkcast       Ljava/io/BufferedInputStream;
        //    71: goto            83
        //    74: new             Ljava/io/BufferedInputStream;
        //    77: dup            
        //    78: aload_0        
        //    79: iload_1        
        //    80: invokespecial   java/io/BufferedInputStream.<init>:(Ljava/io/InputStream;I)V
        //    83: areturn        
        //    StackMapTable: 00 0D FF 00 0F 00 03 07 00 90 01 01 00 01 07 00 27 03 47 07 00 27 03 44 07 00 90 46 07 00 27 43 07 00 90 48 07 00 27 03 43 07 00 27 43 07 00 90 05 48 07 00 92
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      12     15     19     Ljava/lang/NullPointerException;
        //  9      27     27     31     Ljava/lang/NullPointerException;
        //  31     40     43     47     Ljava/lang/NullPointerException;
        //  36     53     56     60     Ljava/lang/NullPointerException;
        //  47     61     64     68     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0036:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static byte[] toByteArray(final InputStream inputStream) throws IOException {
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        copy(inputStream, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }
    
    public static byte[] toByteArray(final InputStream inputStream, final long n) throws IOException {
        try {
            if (n > 2147483647L) {
                throw new IllegalArgumentException(q.s(q.es(q.r(new StringBuilder(), a(-22675, 6821)), n)));
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
        return toByteArray(inputStream, (int)n);
    }
    
    public static byte[] toByteArray(final InputStream p0, final int p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: iload_1        
        //     5: iload_2        
        //     6: ifne            58
        //     9: ifge            57
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: new             Ljava/lang/IllegalArgumentException;
        //    22: dup            
        //    23: new             Ljava/lang/StringBuilder;
        //    26: dup            
        //    27: invokespecial   java/lang/StringBuilder.<init>:()V
        //    30: sipush          -22677
        //    33: sipush          -17021
        //    36: invokestatic    org/apache/commons/io/IOUtils.a:(II)Ljava/lang/String;
        //    39: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    42: iload_1        
        //    43: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //    46: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    49: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //    52: athrow         
        //    53: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    56: athrow         
        //    57: iload_1        
        //    58: iload_2        
        //    59: ifne            77
        //    62: ifne            76
        //    65: goto            72
        //    68: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    71: athrow         
        //    72: iconst_0       
        //    73: newarray        B
        //    75: areturn        
        //    76: iload_1        
        //    77: newarray        B
        //    79: astore_3       
        //    80: iconst_0       
        //    81: iload_2        
        //    82: ifne            73
        //    85: istore          4
        //    87: iload           4
        //    89: iload_1        
        //    90: if_icmpge       162
        //    93: aload_0        
        //    94: aload_3        
        //    95: iload           4
        //    97: iload_1        
        //    98: iload           4
        //   100: isub           
        //   101: invokestatic    q/o/m/s/q.yn:(Ljava/io/InputStream;[BII)I
        //   104: dup            
        //   105: istore          5
        //   107: iconst_m1      
        //   108: iload_2        
        //   109: ifne            165
        //   112: iload_2        
        //   113: ifne            155
        //   116: goto            123
        //   119: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   122: athrow         
        //   123: iload_2        
        //   124: ifne            165
        //   127: goto            134
        //   130: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   133: athrow         
        //   134: if_icmpeq       162
        //   137: goto            144
        //   140: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   143: athrow         
        //   144: iload           4
        //   146: iload           5
        //   148: goto            155
        //   151: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   154: athrow         
        //   155: iadd           
        //   156: istore          4
        //   158: iload_2        
        //   159: ifeq            87
        //   162: iload           4
        //   164: iload_1        
        //   165: if_icmpeq       223
        //   168: new             Ljava/io/IOException;
        //   171: dup            
        //   172: new             Ljava/lang/StringBuilder;
        //   175: dup            
        //   176: invokespecial   java/lang/StringBuilder.<init>:()V
        //   179: sipush          -22686
        //   182: sipush          13851
        //   185: invokestatic    org/apache/commons/io/IOUtils.a:(II)Ljava/lang/String;
        //   188: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   191: iload           4
        //   193: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   196: sipush          -22688
        //   199: sipush          -17558
        //   202: invokestatic    org/apache/commons/io/IOUtils.a:(II)Ljava/lang/String;
        //   205: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   208: iload_1        
        //   209: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   212: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   215: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   218: athrow         
        //   219: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   222: athrow         
        //   223: aload_3        
        //   224: areturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 17 FF 00 0F 00 03 07 00 90 01 01 00 01 07 00 44 03 61 07 00 44 03 40 01 49 07 00 44 03 40 01 02 40 01 FD 00 09 07 00 C4 01 FF 00 1F 00 06 07 00 90 01 01 07 00 C4 01 01 00 01 07 00 44 FF 00 03 00 06 07 00 90 01 01 07 00 C4 01 01 00 02 01 01 46 07 00 44 FF 00 03 00 06 07 00 90 01 01 07 00 C4 01 01 00 02 01 01 45 07 00 44 03 46 07 00 44 FF 00 03 00 06 07 00 90 01 01 07 00 C4 01 01 00 02 01 01 FA 00 06 FF 00 02 00 05 07 00 90 01 01 07 00 C4 01 00 02 01 01 75 07 00 44 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      12     15     19     Ljava/io/IOException;
        //  9      53     53     57     Ljava/io/IOException;
        //  58     65     68     72     Ljava/io/IOException;
        //  107    116    119    123    Ljava/io/IOException;
        //  112    127    130    134    Ljava/io/IOException;
        //  123    137    140    144    Ljava/io/IOException;
        //  134    148    151    155    Ljava/io/IOException;
        //  165    219    219    223    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0123:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Deprecated
    public static byte[] toByteArray(final Reader reader) throws IOException {
        return toByteArray(reader, q.sx());
    }
    
    public static byte[] toByteArray(final Reader reader, final Charset charset) throws IOException {
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        copy(reader, byteArrayOutputStream, charset);
        return byteArrayOutputStream.toByteArray();
    }
    
    public static byte[] toByteArray(final Reader reader, final String s) throws IOException {
        return toByteArray(reader, Charsets.toCharset(s));
    }
    
    @Deprecated
    public static byte[] toByteArray(final String s) throws IOException {
        return q.yf(s, q.sx());
    }
    
    public static byte[] toByteArray(final URI uri) throws IOException {
        return toByteArray(q.ne(uri));
    }
    
    public static byte[] toByteArray(final URL url) throws IOException {
        final URLConnection nd = q.nd(url);
        try {
            return toByteArray(nd);
        }
        finally {
            close(nd);
        }
    }
    
    public static byte[] toByteArray(final URLConnection urlConnection) throws IOException {
        final InputStream na = q.na(urlConnection);
        try {
            return toByteArray(na);
        }
        finally {
            q.yp(na);
        }
    }
    
    @Deprecated
    public static char[] toCharArray(final InputStream inputStream) throws IOException {
        return toCharArray(inputStream, q.sx());
    }
    
    public static char[] toCharArray(final InputStream inputStream, final Charset charset) throws IOException {
        final CharArrayWriter charArrayWriter = new CharArrayWriter();
        copy(inputStream, charArrayWriter, charset);
        return q.yy(charArrayWriter);
    }
    
    public static char[] toCharArray(final InputStream inputStream, final String s) throws IOException {
        return toCharArray(inputStream, Charsets.toCharset(s));
    }
    
    public static char[] toCharArray(final Reader reader) throws IOException {
        final CharArrayWriter charArrayWriter = new CharArrayWriter();
        copy(reader, charArrayWriter);
        return q.yy(charArrayWriter);
    }
    
    @Deprecated
    public static String toString(final InputStream inputStream) throws IOException {
        return toString(inputStream, q.sx());
    }
    
    public static String toString(final InputStream inputStream, final Charset charset) throws IOException {
        final StringBuilderWriter stringBuilderWriter = new StringBuilderWriter();
        copy(inputStream, stringBuilderWriter, charset);
        return stringBuilderWriter.toString();
    }
    
    public static String toString(final InputStream inputStream, final String s) throws IOException {
        return toString(inputStream, Charsets.toCharset(s));
    }
    
    public static String toString(final Reader reader) throws IOException {
        final StringBuilderWriter stringBuilderWriter = new StringBuilderWriter();
        copy(reader, stringBuilderWriter);
        return stringBuilderWriter.toString();
    }
    
    @Deprecated
    public static String toString(final URI uri) throws IOException {
        return toString(uri, q.sx());
    }
    
    public static String toString(final URI uri, final Charset charset) throws IOException {
        return toString(q.ne(uri), Charsets.toCharset(charset));
    }
    
    public static String toString(final URI uri, final String s) throws IOException {
        return toString(uri, Charsets.toCharset(s));
    }
    
    @Deprecated
    public static String toString(final URL url) throws IOException {
        return toString(url, q.sx());
    }
    
    public static String toString(final URL url, final Charset charset) throws IOException {
        final InputStream nz = q.nz(url);
        try {
            return toString(nz, charset);
        }
        finally {
            q.yp(nz);
        }
    }
    
    public static String toString(final URL url, final String s) throws IOException {
        return toString(url, Charsets.toCharset(s));
    }
    
    @Deprecated
    public static String toString(final byte[] bytes) throws IOException {
        return new String(bytes, q.sx());
    }
    
    public static String toString(final byte[] bytes, final String s) throws IOException {
        return new String(bytes, Charsets.toCharset(s));
    }
    
    @Deprecated
    public static List<String> readLines(final InputStream inputStream) throws IOException {
        return readLines(inputStream, q.sx());
    }
    
    public static List<String> readLines(final InputStream in, final Charset charset) throws IOException {
        return readLines(new InputStreamReader(in, Charsets.toCharset(charset)));
    }
    
    public static List<String> readLines(final InputStream inputStream, final String s) throws IOException {
        return readLines(inputStream, Charsets.toCharset(s));
    }
    
    public static List<String> readLines(final Reader reader) throws IOException {
        final BufferedReader bufferedReader = toBufferedReader(reader);
        final int c = IOCase.c();
        final ArrayList list = new ArrayList<String>();
        final int n = c;
        String s = q.o(bufferedReader);
        while (s != null) {
            final ArrayList list3;
            final ArrayList<String> list2 = (ArrayList<String>)(list3 = list);
            if (n == 0) {
                return (List<String>)list3;
            }
            q.qw(list2, s);
            s = q.o(bufferedReader);
            if (n == 0) {
                break;
            }
        }
        ArrayList list3 = list;
        return (List<String>)list3;
    }
    
    public static LineIterator lineIterator(final Reader reader) {
        return new LineIterator(reader);
    }
    
    public static LineIterator lineIterator(final InputStream in, final Charset charset) throws IOException {
        return new LineIterator(new InputStreamReader(in, Charsets.toCharset(charset)));
    }
    
    public static LineIterator lineIterator(final InputStream inputStream, final String s) throws IOException {
        return lineIterator(inputStream, Charsets.toCharset(s));
    }
    
    @Deprecated
    public static InputStream toInputStream(final CharSequence charSequence) {
        return toInputStream(charSequence, q.sx());
    }
    
    public static InputStream toInputStream(final CharSequence charSequence, final Charset charset) {
        return toInputStream(q.pm(charSequence), charset);
    }
    
    public static InputStream toInputStream(final CharSequence charSequence, final String s) throws IOException {
        return toInputStream(charSequence, Charsets.toCharset(s));
    }
    
    @Deprecated
    public static InputStream toInputStream(final String s) {
        return toInputStream(s, q.sx());
    }
    
    public static InputStream toInputStream(final String s, final Charset charset) {
        return new ByteArrayInputStream(q.yf(s, Charsets.toCharset(charset)));
    }
    
    public static InputStream toInputStream(final String s, final String s2) throws IOException {
        return new ByteArrayInputStream(q.yf(s, Charsets.toCharset(s2)));
    }
    
    public static void write(final byte[] array, final OutputStream outputStream) throws IOException {
        try {
            if (array != null) {
                q.sj(outputStream, array);
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    public static void writeChunked(final byte[] array, final OutputStream outputStream) throws IOException {
        final int b = IOCase.b();
        byte[] array2 = null;
        Label_0031: {
            Label_0020: {
                try {
                    array2 = array;
                    if (b != 0) {
                        break Label_0031;
                    }
                    final int n = b;
                    if (n == 0) {
                        break Label_0020;
                    }
                    break Label_0031;
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                try {
                    final int n = b;
                    if (n != 0) {
                        break Label_0031;
                    }
                    if (array == null) {
                        return;
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            array2 = array;
        }
        int i = array2.length;
        int n2 = 0;
        while (i > 0) {
            final int px = q.px(i, 4096);
            q.sz(outputStream, array, n2, px);
            i -= px;
            n2 += px;
            if (b != 0) {
                break;
            }
        }
    }
    
    @Deprecated
    public static void write(final byte[] array, final Writer writer) throws IOException {
        write(array, writer, q.sx());
    }
    
    public static void write(final byte[] bytes, final Writer writer, final Charset charset) throws IOException {
        try {
            if (bytes != null) {
                q.sa(writer, new String(bytes, Charsets.toCharset(charset)));
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    public static void write(final byte[] array, final Writer writer, final String s) throws IOException {
        write(array, writer, Charsets.toCharset(s));
    }
    
    public static void write(final char[] array, final Writer writer) throws IOException {
        try {
            if (array != null) {
                q.yc(writer, array);
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    public static void writeChunked(final char[] array, final Writer writer) throws IOException {
        final int c = IOCase.c();
        char[] array2 = null;
        Label_0031: {
            Label_0020: {
                try {
                    array2 = array;
                    if (c == 0) {
                        break Label_0031;
                    }
                    final int n = c;
                    if (n != 0) {
                        break Label_0020;
                    }
                    break Label_0031;
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                try {
                    final int n = c;
                    if (n == 0) {
                        break Label_0031;
                    }
                    if (array == null) {
                        return;
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            array2 = array;
        }
        int i = array2.length;
        int n2 = 0;
        while (i > 0) {
            final int px = q.px(i, 4096);
            q.sb(writer, array, n2, px);
            i -= px;
            n2 += px;
            if (c == 0) {
                break;
            }
        }
    }
    
    @Deprecated
    public static void write(final char[] array, final OutputStream outputStream) throws IOException {
        write(array, outputStream, q.sx());
    }
    
    public static void write(final char[] value, final OutputStream outputStream, final Charset charset) throws IOException {
        try {
            if (value != null) {
                q.sj(outputStream, q.yf(new String(value), Charsets.toCharset(charset)));
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    public static void write(final char[] array, final OutputStream outputStream, final String s) throws IOException {
        write(array, outputStream, Charsets.toCharset(s));
    }
    
    public static void write(final CharSequence charSequence, final Writer writer) throws IOException {
        final int b = IOCase.b();
        CharSequence charSequence2 = null;
        Label_0031: {
            Label_0020: {
                try {
                    charSequence2 = charSequence;
                    if (b != 0) {
                        break Label_0031;
                    }
                    final int n = b;
                    if (n == 0) {
                        break Label_0020;
                    }
                    break Label_0031;
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                try {
                    final int n = b;
                    if (n != 0) {
                        break Label_0031;
                    }
                    if (charSequence == null) {
                        return;
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            charSequence2 = charSequence;
        }
        write(q.pm(charSequence2), writer);
    }
    
    @Deprecated
    public static void write(final CharSequence charSequence, final OutputStream outputStream) throws IOException {
        write(charSequence, outputStream, q.sx());
    }
    
    public static void write(final CharSequence charSequence, final OutputStream outputStream, final Charset charset) throws IOException {
        final int c = IOCase.c();
        CharSequence charSequence2 = null;
        Label_0031: {
            Label_0020: {
                try {
                    charSequence2 = charSequence;
                    if (c == 0) {
                        break Label_0031;
                    }
                    final int n = c;
                    if (n != 0) {
                        break Label_0020;
                    }
                    break Label_0031;
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                try {
                    final int n = c;
                    if (n == 0) {
                        break Label_0031;
                    }
                    if (charSequence == null) {
                        return;
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            charSequence2 = charSequence;
        }
        write(q.pm(charSequence2), outputStream, charset);
    }
    
    public static void write(final CharSequence charSequence, final OutputStream outputStream, final String s) throws IOException {
        write(charSequence, outputStream, Charsets.toCharset(s));
    }
    
    public static void write(final String s, final Writer writer) throws IOException {
        try {
            if (s != null) {
                q.sa(writer, s);
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    @Deprecated
    public static void write(final String s, final OutputStream outputStream) throws IOException {
        write(s, outputStream, q.sx());
    }
    
    public static void write(final String s, final OutputStream outputStream, final Charset charset) throws IOException {
        try {
            if (s != null) {
                q.sj(outputStream, q.yf(s, Charsets.toCharset(charset)));
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    public static void write(final String s, final OutputStream outputStream, final String s2) throws IOException {
        write(s, outputStream, Charsets.toCharset(s2));
    }
    
    @Deprecated
    public static void write(final StringBuffer sb, final Writer writer) throws IOException {
        try {
            if (sb != null) {
                q.sa(writer, q.yx(sb));
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    @Deprecated
    public static void write(final StringBuffer sb, final OutputStream outputStream) throws IOException {
        write(sb, outputStream, null);
    }
    
    @Deprecated
    public static void write(final StringBuffer sb, final OutputStream outputStream, final String s) throws IOException {
        try {
            if (sb != null) {
                q.sj(outputStream, q.yf(q.yx(sb), Charsets.toCharset(s)));
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    @Deprecated
    public static void writeLines(final Collection<?> collection, final String s, final OutputStream outputStream) throws IOException {
        writeLines(collection, s, outputStream, q.sx());
    }
    
    public static void writeLines(final Collection<?> collection, String s, final OutputStream outputStream, final Charset charset) throws IOException {
        final int c = IOCase.c();
        try {
            if (collection == null) {
                return;
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
        Label_0046: {
            String s2 = null;
            Label_0045: {
                Label_0032: {
                    try {
                        s2 = s;
                        if (c == 0) {
                            break Label_0045;
                        }
                        final int n = c;
                        if (n != 0) {
                            break Label_0032;
                        }
                        break Label_0045;
                    }
                    catch (IOException ex2) {
                        throw b(ex2);
                    }
                    try {
                        final int n = c;
                        if (n == 0) {
                            break Label_0045;
                        }
                        if (s2 != null) {
                            break Label_0046;
                        }
                    }
                    catch (IOException ex3) {
                        throw b(ex3);
                    }
                }
                final String line_SEPARATOR = IOUtils.LINE_SEPARATOR;
            }
            s = s2;
        }
        final Charset charset2 = Charsets.toCharset(charset);
        final Iterator ed = q.ed(collection);
        while (q.oi(ed)) {
            final Object ou = q.ou(ed);
            Label_0126: {
                byte[] yf = null;
                while (true) {
                    Label_0111: {
                        OutputStream outputStream2 = null;
                        Label_0090: {
                            try {
                                if (c == 0) {
                                    break Label_0126;
                                }
                                final Object o = ou;
                                if (o != null) {
                                    break Label_0090;
                                }
                                break Label_0111;
                            }
                            catch (IOException ex4) {
                                throw b(ex4);
                            }
                            try {
                                final Object o = ou;
                                if (o == null) {
                                    break Label_0111;
                                }
                                outputStream2 = outputStream;
                                q.yf(q.yh(ou), charset2);
                            }
                            catch (IOException ex5) {
                                throw b(ex5);
                            }
                        }
                        q.sj(outputStream2, yf);
                    }
                    OutputStream outputStream2 = outputStream;
                    yf = q.yf(s, charset2);
                    if (c == 0) {
                        continue;
                    }
                    break;
                }
                q.sj(outputStream, yf);
            }
            if (c == 0) {
                break;
            }
        }
    }
    
    public static void writeLines(final Collection<?> collection, final String s, final OutputStream outputStream, final String s2) throws IOException {
        writeLines(collection, s, outputStream, Charsets.toCharset(s2));
    }
    
    public static void writeLines(final Collection<?> collection, String s, final Writer writer) throws IOException {
        final int c = IOCase.c();
        try {
            if (collection == null) {
                return;
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
        Label_0043: {
            String s2 = null;
            Label_0042: {
                Label_0029: {
                    try {
                        s2 = s;
                        if (c == 0) {
                            break Label_0042;
                        }
                        final int n = c;
                        if (n != 0) {
                            break Label_0029;
                        }
                        break Label_0042;
                    }
                    catch (IOException ex2) {
                        throw b(ex2);
                    }
                    try {
                        final int n = c;
                        if (n == 0) {
                            break Label_0042;
                        }
                        if (s2 != null) {
                            break Label_0043;
                        }
                    }
                    catch (IOException ex3) {
                        throw b(ex3);
                    }
                }
                final String line_SEPARATOR = IOUtils.LINE_SEPARATOR;
            }
            s = s2;
        }
        final Iterator ed = q.ed(collection);
        while (q.oi(ed)) {
            final Object ou = q.ou(ed);
            Label_0105: {
                String s3 = null;
                while (true) {
                    Label_0096: {
                        Writer writer2 = null;
                        Label_0080: {
                            try {
                                if (c == 0) {
                                    break Label_0105;
                                }
                                final Object o = ou;
                                if (o != null) {
                                    break Label_0080;
                                }
                                break Label_0096;
                            }
                            catch (IOException ex4) {
                                throw b(ex4);
                            }
                            try {
                                final Object o = ou;
                                if (o == null) {
                                    break Label_0096;
                                }
                                writer2 = writer;
                                q.yh(ou);
                            }
                            catch (IOException ex5) {
                                throw b(ex5);
                            }
                        }
                        q.sa(writer2, s3);
                    }
                    Writer writer2 = writer;
                    s3 = s;
                    if (c == 0) {
                        continue;
                    }
                    break;
                }
                q.sa(writer, s3);
            }
            if (c == 0) {
                break;
            }
        }
    }
    
    public static int copy(final InputStream inputStream, final OutputStream outputStream) throws IOException {
        final long copyLarge = copyLarge(inputStream, outputStream);
        final int c = IOCase.c();
        long n = 0L;
        Label_0031: {
            try {
                n = lcmp(copyLarge, 2147483647L);
                if (c == 0) {
                    return (int)n;
                }
                if (n <= 0) {
                    break Label_0031;
                }
            }
            catch (IOException ex) {
                throw b(ex);
            }
            return -1;
        }
        final int n2 = (int)copyLarge;
        if (c == 0) {
            return n2;
        }
        return (int)n;
    }
    
    public static long copy(final InputStream inputStream, final OutputStream outputStream, final int n) throws IOException {
        return copyLarge(inputStream, outputStream, new byte[n]);
    }
    
    public static long copyLarge(final InputStream inputStream, final OutputStream outputStream) throws IOException {
        return copy(inputStream, outputStream, 4096);
    }
    
    public static long copyLarge(final InputStream inputStream, final OutputStream outputStream, final byte[] array) throws IOException {
        final int c = IOCase.c();
        long n = 0L;
        final int n2 = c;
        int sg;
        long n3 = 0L;
        while (-1 != (sg = q.sg(inputStream, array))) {
            q.sz(outputStream, array, 0, sg);
            n3 = n + sg;
            if (n2 == 0) {
                return n3;
            }
            n = n3;
            if (n2 == 0) {
                break;
            }
        }
        return n3;
    }
    
    public static long copyLarge(final InputStream inputStream, final OutputStream outputStream, final long n, final long n2) throws IOException {
        return copyLarge(inputStream, outputStream, n, n2, new byte[4096]);
    }
    
    public static long copyLarge(final InputStream inputStream, final OutputStream outputStream, final long n, final long n2, final byte[] array) throws IOException {
        final int b = IOCase.b();
        long length = 0L;
        Label_0059: {
            Label_0056: {
                Label_0039: {
                    Label_0023: {
                        long n3;
                        try {
                            final long n4;
                            n3 = (n4 = (length = lcmp(n, 0L)));
                            if (b != 0) {
                                break Label_0039;
                            }
                            if (n3 > 0) {
                                break Label_0023;
                            }
                            break Label_0023;
                        }
                        catch (IOException ex) {
                            throw b(ex);
                        }
                        try {
                            if (n3 > 0) {
                                skipFully(inputStream, n);
                            }
                        }
                        catch (IOException ex2) {
                            throw b(ex2);
                        }
                    }
                    long n4;
                    length = (n4 = lcmp(n2, 0L));
                    try {
                        if (b != 0) {
                            break Label_0059;
                        }
                        if (n4 != 0) {
                            break Label_0056;
                        }
                    }
                    catch (IOException ex3) {
                        throw b(ex3);
                    }
                }
                return 0L;
            }
            length = array.length;
        }
        long n7;
        final int n6 = (int)(n7 = length);
        long n8 = n2;
        final long n5 = n2;
        if (b == 0) {
            Label_0133: {
                while (true) {
                    while (true) {
                        Label_0122: {
                            long n11 = 0L;
                            Label_0089: {
                                try {
                                    if (b != 0) {
                                        break Label_0133;
                                    }
                                    final long n9 = 0L;
                                    final long n10 = lcmp(n2, n9);
                                    if (n10 > 0) {
                                        break Label_0089;
                                    }
                                    break Label_0122;
                                }
                                catch (IOException ex4) {
                                    throw b(ex4);
                                }
                                try {
                                    final long n9 = 0L;
                                    final long n10 = lcmp(n2, n9);
                                    if (n10 <= 0) {
                                        break Label_0122;
                                    }
                                    n8 = n2;
                                    n11 = n2;
                                }
                                catch (IOException ex5) {
                                    throw b(ex5);
                                }
                            }
                            if (b != 0) {
                                break Label_0133;
                            }
                            long n12;
                            try {
                                if (n11 >= n6) {
                                    break Label_0122;
                                }
                                n12 = n2;
                            }
                            catch (IOException ex6) {
                                throw b(ex6);
                            }
                            n7 = (int)n12;
                        }
                        long n11;
                        long n12 = n11 = (n8 = 0L);
                        if (b != 0) {
                            continue;
                        }
                        break;
                    }
                    if (b != 0) {
                        continue;
                    }
                    break;
                }
            }
            long n13 = n8;
        Label_0135:
            while (true) {
                int n14 = (int)n7;
                int yn;
                while (n14 > 0 && -1 != (yn = q.yn(inputStream, array, 0, (int)n7))) {
                    q.sz(outputStream, array, 0, yn);
                    n13 += yn;
                    long n15 = 0L;
                    Label_0209: {
                        try {
                            n15 = lcmp(n2, 0L);
                            if (b != 0) {
                                break Label_0209;
                            }
                            if (n15 <= 0) {
                                continue Label_0135;
                            }
                        }
                        catch (IOException ex7) {
                            throw b(ex7);
                        }
                        n14 = (int)q.nu(n2 - n13, n6);
                        if (b != 0) {
                            continue;
                        }
                    }
                    n7 = n15;
                    if (b != 0) {
                        break;
                    }
                    continue Label_0135;
                }
                break;
            }
            return n13;
        }
        return n5;
    }
    
    @Deprecated
    public static void copy(final InputStream inputStream, final Writer writer) throws IOException {
        copy(inputStream, writer, q.sx());
    }
    
    public static void copy(final InputStream in, final Writer writer, final Charset charset) throws IOException {
        copy(new InputStreamReader(in, Charsets.toCharset(charset)), writer);
    }
    
    public static void copy(final InputStream inputStream, final Writer writer, final String s) throws IOException {
        copy(inputStream, writer, Charsets.toCharset(s));
    }
    
    public static int copy(final Reader reader, final Writer writer) throws IOException {
        final long copyLarge = copyLarge(reader, writer);
        final int c = IOCase.c();
        long n = 0L;
        Label_0031: {
            try {
                n = lcmp(copyLarge, 2147483647L);
                if (c == 0) {
                    return (int)n;
                }
                if (n <= 0) {
                    break Label_0031;
                }
            }
            catch (IOException ex) {
                throw b(ex);
            }
            return -1;
        }
        final int n2 = (int)copyLarge;
        if (c == 0) {
            return n2;
        }
        return (int)n;
    }
    
    public static long copyLarge(final Reader reader, final Writer writer) throws IOException {
        return copyLarge(reader, writer, new char[4096]);
    }
    
    public static long copyLarge(final Reader reader, final Writer writer, final char[] array) throws IOException {
        final int c = IOCase.c();
        long n = 0L;
        final int n2 = c;
        int sd;
        long n3 = 0L;
        while (-1 != (sd = q.sd(reader, array))) {
            q.sb(writer, array, 0, sd);
            n3 = n + sd;
            if (n2 == 0) {
                return n3;
            }
            n = n3;
            if (n2 == 0) {
                break;
            }
        }
        return n3;
    }
    
    public static long copyLarge(final Reader reader, final Writer writer, final long n, final long n2) throws IOException {
        return copyLarge(reader, writer, n, n2, new char[4096]);
    }
    
    public static long copyLarge(final Reader reader, final Writer writer, final long n, final long n2, final char[] array) throws IOException {
        final int b = IOCase.b();
        long length = 0L;
        Label_0059: {
            Label_0056: {
                Label_0039: {
                    Label_0023: {
                        long n3;
                        try {
                            final long n4;
                            n3 = (n4 = (length = lcmp(n, 0L)));
                            if (b != 0) {
                                break Label_0039;
                            }
                            if (n3 > 0) {
                                break Label_0023;
                            }
                            break Label_0023;
                        }
                        catch (IOException ex) {
                            throw b(ex);
                        }
                        try {
                            if (n3 > 0) {
                                skipFully(reader, n);
                            }
                        }
                        catch (IOException ex2) {
                            throw b(ex2);
                        }
                    }
                    long n4;
                    length = (n4 = lcmp(n2, 0L));
                    try {
                        if (b != 0) {
                            break Label_0059;
                        }
                        if (n4 != 0) {
                            break Label_0056;
                        }
                    }
                    catch (IOException ex3) {
                        throw b(ex3);
                    }
                }
                return 0L;
            }
            length = array.length;
        }
        int n6 = (int)length;
        long n7 = n2;
        final long n5 = n2;
        if (b == 0) {
            Label_0130: {
                while (true) {
                    while (true) {
                        Label_0119: {
                            long n10 = 0L;
                            Label_0085: {
                                try {
                                    if (b != 0) {
                                        break Label_0130;
                                    }
                                    final long n8 = 0L;
                                    final long n9 = lcmp(n2, n8);
                                    if (n9 > 0) {
                                        break Label_0085;
                                    }
                                    break Label_0119;
                                }
                                catch (IOException ex4) {
                                    throw b(ex4);
                                }
                                try {
                                    final long n8 = 0L;
                                    final long n9 = lcmp(n2, n8);
                                    if (n9 <= 0) {
                                        break Label_0119;
                                    }
                                    n7 = n2;
                                    n10 = n2;
                                }
                                catch (IOException ex5) {
                                    throw b(ex5);
                                }
                            }
                            if (b != 0) {
                                break Label_0130;
                            }
                            long n11;
                            try {
                                if (n10 >= array.length) {
                                    break Label_0119;
                                }
                                n11 = n2;
                            }
                            catch (IOException ex6) {
                                throw b(ex6);
                            }
                            n6 = (int)n11;
                        }
                        long n10;
                        long n11 = n10 = (n7 = 0L);
                        if (b != 0) {
                            continue;
                        }
                        break;
                    }
                    if (b != 0) {
                        continue;
                    }
                    break;
                }
            }
            long n12 = n7;
        Label_0132:
            while (true) {
                int n13 = n6;
                int yj;
                while (n13 > 0 && -1 != (yj = q.yj(reader, array, 0, n6))) {
                    q.sb(writer, array, 0, yj);
                    n12 += yj;
                    long n14 = 0L;
                    Label_0207: {
                        try {
                            n14 = lcmp(n2, 0L);
                            if (b != 0) {
                                break Label_0207;
                            }
                            if (n14 <= 0) {
                                continue Label_0132;
                            }
                        }
                        catch (IOException ex7) {
                            throw b(ex7);
                        }
                        n13 = (int)q.nu(n2 - n12, array.length);
                        if (b != 0) {
                            continue;
                        }
                    }
                    n6 = (int)n14;
                    if (b != 0) {
                        break;
                    }
                    continue Label_0132;
                }
                break;
            }
            return n12;
        }
        return n5;
    }
    
    @Deprecated
    public static void copy(final Reader reader, final OutputStream outputStream) throws IOException {
        copy(reader, outputStream, q.sx());
    }
    
    public static void copy(final Reader reader, final OutputStream out, final Charset charset) throws IOException {
        final OutputStreamWriter outputStreamWriter = new OutputStreamWriter(out, Charsets.toCharset(charset));
        copy(reader, outputStreamWriter);
        q.sw(outputStreamWriter);
    }
    
    public static void copy(final Reader reader, final OutputStream outputStream, final String s) throws IOException {
        copy(reader, outputStream, Charsets.toCharset(s));
    }
    
    public static boolean contentEquals(InputStream in, InputStream in2) throws IOException {
        final int c = IOCase.c();
        InputStream inputStream2 = null;
        Label_0030: {
            Label_0029: {
                int n = 0;
                Label_0020: {
                    InputStream inputStream;
                    try {
                        inputStream = (inputStream2 = in);
                        if (c == 0) {
                            break Label_0030;
                        }
                        final InputStream inputStream3 = in2;
                        if (inputStream == inputStream3) {
                            break Label_0020;
                        }
                        break Label_0029;
                    }
                    catch (IOException ex) {
                        throw b(ex);
                    }
                    try {
                        final InputStream inputStream3 = in2;
                        if (inputStream != inputStream3) {
                            break Label_0029;
                        }
                        n = 1;
                    }
                    catch (IOException ex2) {
                        throw b(ex2);
                    }
                }
                return n != 0;
            }
            inputStream2 = in;
        }
        int n;
        int kt;
        boolean b2;
        final boolean b = (n = ((b2 = ((kt = ((inputStream2 instanceof BufferedInputStream) ? 1 : 0)) != 0)) ? 1 : 0)) != 0;
        if (c != 0) {
            Label_0091: {
                Label_0087: {
                    Label_0064: {
                        Label_0060: {
                            try {
                                if (c == 0) {
                                    break Label_0064;
                                }
                                if (b) {
                                    break Label_0060;
                                }
                            }
                            catch (IOException ex3) {
                                throw b(ex3);
                            }
                            in = new BufferedInputStream(in);
                        }
                        kt = ((b2 = (in2 instanceof BufferedInputStream)) ? 1 : 0);
                        try {
                            if (c == 0) {
                                break Label_0091;
                            }
                            if (b2) {
                                break Label_0087;
                            }
                        }
                        catch (IOException ex4) {
                            throw b(ex4);
                        }
                    }
                    in2 = new BufferedInputStream(in2);
                }
                kt = q.kt(in);
            }
            int n2 = kt;
        Label_0177:
            while (true) {
                while (-1 != n2) {
                    final int kt2 = q.kt(in2);
                    int n3 = 0;
                    Label_0141: {
                        Label_0133: {
                            Label_0121: {
                                try {
                                    final int n4;
                                    n3 = (n4 = n2);
                                    if (c == 0) {
                                        break Label_0141;
                                    }
                                    final int n6;
                                    final int n5 = n6 = kt2;
                                    final int n7 = c;
                                    if (n7 != 0) {
                                        break Label_0121;
                                    }
                                    break Label_0177;
                                }
                                catch (IOException ex5) {
                                    throw b(ex5);
                                }
                                try {
                                    final int n6;
                                    final int n5 = n6 = kt2;
                                    final int n7 = c;
                                    if (n7 == 0) {
                                        break Label_0177;
                                    }
                                    if (n3 == n6) {
                                        break Label_0133;
                                    }
                                }
                                catch (IOException ex6) {
                                    throw b(ex6);
                                }
                            }
                            return false;
                        }
                        final int kt3 = q.kt(in);
                        if (c == 0) {
                            return kt3 != 0;
                        }
                    }
                    n2 = n3;
                    if (c == 0) {
                        break;
                    }
                    continue;
                    final int kt3 = 0;
                    return kt3 != 0;
                    int n4 = 0;
                    int n5 = 0;
                    int n8;
                    if (n4 == n5) {
                        n8 = 1;
                    }
                    else {
                        n8 = 0;
                    }
                    return n8 != 0;
                }
                final int kt4 = q.kt(in2);
                Label_0169: {
                    int n8;
                    try {
                        final int n4;
                        n8 = (n4 = kt4);
                        if (c == 0) {
                            return n8 != 0;
                        }
                        final int n9 = c;
                        if (n9 != 0) {
                            break Label_0169;
                        }
                        return n8 != 0;
                    }
                    catch (IOException ex7) {
                        throw b(ex7);
                    }
                    try {
                        final int n9 = c;
                        if (n9 == 0) {
                            return n8 != 0;
                        }
                        final int n5 = -1;
                    }
                    catch (IOException ex8) {
                        throw b(ex8);
                    }
                }
                continue Label_0177;
            }
        }
        return n != 0;
    }
    
    public static boolean contentEquals(final Reader reader, final Reader reader2) throws IOException {
        final int b = IOCase.b();
        Reader reader3 = null;
        Label_0030: {
            Label_0029: {
                Label_0020: {
                    try {
                        reader3 = reader;
                        if (b != 0) {
                            break Label_0030;
                        }
                        final Reader reader4 = reader2;
                        if (reader == reader4) {
                            break Label_0020;
                        }
                        break Label_0029;
                    }
                    catch (IOException ex) {
                        throw b(ex);
                    }
                    try {
                        final Reader reader4 = reader2;
                        if (reader != reader4) {
                            break Label_0029;
                        }
                    }
                    catch (IOException ex2) {
                        throw b(ex2);
                    }
                }
                final int yg;
                return yg != 0;
            }
            reader3 = reader;
        }
        final BufferedReader bufferedReader = toBufferedReader(reader3);
        final BufferedReader bufferedReader2 = toBufferedReader(reader2);
        final int yg = q.yg(bufferedReader);
        if (b == 0) {
            int n = yg;
        Label_0133:
            while (true) {
                while (-1 != n) {
                    final int yg2 = q.yg(bufferedReader2);
                    int n2 = 0;
                    Label_0097: {
                        Label_0089: {
                            Label_0077: {
                                try {
                                    final int n3;
                                    n2 = (n3 = n);
                                    if (b != 0) {
                                        break Label_0097;
                                    }
                                    final int n5;
                                    final int n4 = n5 = yg2;
                                    final int n6 = b;
                                    if (n6 == 0) {
                                        break Label_0077;
                                    }
                                    break Label_0133;
                                }
                                catch (IOException ex3) {
                                    throw b(ex3);
                                }
                                try {
                                    final int n5;
                                    final int n4 = n5 = yg2;
                                    final int n6 = b;
                                    if (n6 != 0) {
                                        break Label_0133;
                                    }
                                    if (n2 == n5) {
                                        break Label_0089;
                                    }
                                }
                                catch (IOException ex4) {
                                    throw b(ex4);
                                }
                            }
                            return false;
                        }
                        final int yg3 = q.yg(bufferedReader);
                        if (b != 0) {
                            return yg3 != 0;
                        }
                    }
                    n = n2;
                    if (b != 0) {
                        break;
                    }
                    continue;
                    final int yg3 = false ? 1 : 0;
                    return yg3 != 0;
                    int n3 = 0;
                    int n4 = 0;
                    int n7;
                    if (n3 == n4) {
                        n7 = 1;
                    }
                    else {
                        n7 = 0;
                    }
                    return n7 != 0;
                }
                final int yg4 = q.yg(bufferedReader2);
                Label_0125: {
                    int n7;
                    try {
                        final int n3;
                        n7 = (n3 = yg4);
                        if (b != 0) {
                            return n7 != 0;
                        }
                        final int n8 = b;
                        if (n8 == 0) {
                            break Label_0125;
                        }
                        return n7 != 0;
                    }
                    catch (IOException ex5) {
                        throw b(ex5);
                    }
                    try {
                        final int n8 = b;
                        if (n8 != 0) {
                            return n7 != 0;
                        }
                        final int n4 = -1;
                    }
                    catch (IOException ex6) {
                        throw b(ex6);
                    }
                }
                continue Label_0133;
            }
        }
        return yg != 0;
    }
    
    public static boolean contentEqualsIgnoreEOL(final Reader reader, final Reader reader2) throws IOException {
        final int b = IOCase.b();
        Reader reader3 = null;
        Label_0027: {
            Label_0026: {
                try {
                    reader3 = reader;
                    if (b != 0) {
                        break Label_0027;
                    }
                    final Reader reader4 = reader2;
                    if (reader == reader4) {
                        return true;
                    }
                    break Label_0026;
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                try {
                    final Reader reader4 = reader2;
                    if (reader == reader4) {
                        return true;
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            reader3 = reader;
        }
        final BufferedReader bufferedReader = toBufferedReader(reader3);
        final BufferedReader bufferedReader2 = toBufferedReader(reader2);
        String s = q.o(bufferedReader);
        String o = q.o(bufferedReader2);
        String s4 = null;
        String s3 = null;
        String o2;
        String s2 = null;
        int n;
        String s5;
        Label_0084_Outer:Label_0107_Outer:
        while (true) {
            while (true) {
                while (true) {
                    Label_0115: {
                        Label_0113: {
                            if (s == null) {
                                break Label_0113;
                            }
                            Label_0072: {
                                try {
                                    s2 = (o2 = (s3 = (s4 = o)));
                                    if (b != 0) {
                                        break Label_0115;
                                    }
                                    n = b;
                                    if (n == 0) {
                                        break Label_0072;
                                    }
                                    break;
                                }
                                catch (IOException ex3) {
                                    throw b(ex3);
                                }
                                try {
                                    n = b;
                                    if (n != 0) {
                                        break;
                                    }
                                    if (s2 == null) {
                                        break Label_0113;
                                    }
                                }
                                catch (IOException ex4) {
                                    throw b(ex4);
                                }
                            }
                            s3 = (s5 = (s4 = s));
                            if (b != 0) {
                                break;
                            }
                            if (!q.th(s2, o)) {
                                break Label_0113;
                            }
                            s = q.o(bufferedReader);
                            o2 = q.o(bufferedReader2);
                            o = o2;
                            if (b == 0) {
                                continue Label_0084_Outer;
                            }
                        }
                        o2 = (s5 = (s3 = (s4 = s)));
                    }
                    if (b != 0) {
                        continue Label_0107_Outer;
                    }
                    break;
                }
                if (b == 0) {
                    break;
                }
                continue;
            }
        }
        while (true) {
            Label_0154: {
                try {
                    if (b != 0) {
                        return q.th(s4, o);
                    }
                    if (s3 != null) {
                        break Label_0154;
                    }
                }
                catch (IOException ex5) {
                    throw b(ex5);
                }
                final String s6 = o;
                boolean th;
                if (s6 == null) {
                    th = true;
                }
                else {
                    th = false;
                    if (b == 0) {}
                }
                return th;
            }
            String s6;
            s4 = (s6 = s);
            if (b != 0) {
                continue;
            }
            break;
        }
        return q.th(s4, o);
    }
    
    public static long skip(final InputStream p0, final long p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_3       
        //     4: lload_1        
        //     5: lconst_0       
        //     6: lcmp           
        //     7: ifge            48
        //    10: new             Ljava/lang/IllegalArgumentException;
        //    13: dup            
        //    14: new             Ljava/lang/StringBuilder;
        //    17: dup            
        //    18: invokespecial   java/lang/StringBuilder.<init>:()V
        //    21: sipush          -22680
        //    24: sipush          -3983
        //    27: invokestatic    org/apache/commons/io/IOUtils.a:(II)Ljava/lang/String;
        //    30: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    33: lload_1        
        //    34: invokestatic    q/o/m/s/q.es:(Ljava/lang/StringBuilder;J)Ljava/lang/StringBuilder;
        //    37: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    40: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //    43: athrow         
        //    44: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    47: athrow         
        //    48: getstatic       org/apache/commons/io/IOUtils.SKIP_BYTE_BUFFER:[B
        //    51: iload_3        
        //    52: ifeq            88
        //    55: iload_3        
        //    56: ifeq            88
        //    59: goto            66
        //    62: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    65: athrow         
        //    66: ifnonnull       91
        //    69: goto            76
        //    72: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    75: athrow         
        //    76: sipush          2048
        //    79: newarray        B
        //    81: goto            88
        //    84: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    87: athrow         
        //    88: putstatic       org/apache/commons/io/IOUtils.SKIP_BYTE_BUFFER:[B
        //    91: lload_1        
        //    92: lstore          4
        //    94: lload           4
        //    96: lconst_0       
        //    97: lcmp           
        //    98: ifle            179
        //   101: aload_0        
        //   102: getstatic       org/apache/commons/io/IOUtils.SKIP_BYTE_BUFFER:[B
        //   105: iconst_0       
        //   106: lload           4
        //   108: ldc2_w          2048
        //   111: invokestatic    q/o/m/s/q.nu:(JJ)J
        //   114: l2i            
        //   115: invokestatic    q/o/m/s/q.yn:(Ljava/io/InputStream;[BII)I
        //   118: i2l            
        //   119: lstore          6
        //   121: lload           6
        //   123: lconst_0       
        //   124: iload_3        
        //   125: ifeq            182
        //   128: iload_3        
        //   129: ifeq            172
        //   132: goto            139
        //   135: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   138: athrow         
        //   139: lcmp           
        //   140: ifge            161
        //   143: goto            150
        //   146: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   149: athrow         
        //   150: iload_3        
        //   151: ifne            179
        //   154: goto            161
        //   157: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   160: athrow         
        //   161: lload           4
        //   163: lload           6
        //   165: goto            172
        //   168: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   171: athrow         
        //   172: lsub           
        //   173: lstore          4
        //   175: iload_3        
        //   176: ifne            94
        //   179: lload_1        
        //   180: lload           4
        //   182: lsub           
        //   183: lreturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 14 FF 00 2C 00 03 07 00 90 04 01 00 01 07 00 44 03 4D 07 00 44 43 07 00 C4 45 07 00 44 03 47 07 00 44 43 07 00 C4 02 FC 00 02 04 FF 00 28 00 05 07 00 90 04 01 04 04 00 01 07 00 44 FF 00 03 00 05 07 00 90 04 01 04 04 00 02 04 04 46 07 00 44 03 46 07 00 44 03 46 07 00 44 FF 00 03 00 05 07 00 90 04 01 04 04 00 02 04 04 FA 00 06 FF 00 02 00 04 07 00 90 04 01 04 00 02 04 04
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      44     44     48     Ljava/io/IOException;
        //  48     59     62     66     Ljava/io/IOException;
        //  55     69     72     76     Ljava/io/IOException;
        //  66     81     84     88     Ljava/io/IOException;
        //  121    132    135    139    Ljava/io/IOException;
        //  128    143    146    150    Ljava/io/IOException;
        //  139    154    157    161    Ljava/io/IOException;
        //  150    165    168    172    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0066:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static long skip(final ReadableByteChannel readableByteChannel, final long n) throws IOException {
        final int c = IOCase.c();
        int n3 = 0;
        Label_0067: {
            Label_0021: {
                long n2;
                try {
                    n2 = (n3 = lcmp(n, 0L));
                    if (c == 0) {
                        break Label_0067;
                    }
                    if (n2 < 0) {
                        break Label_0021;
                    }
                    break Label_0021;
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                try {
                    if (n2 < 0) {
                        throw new IllegalArgumentException(q.s(q.es(q.r(new StringBuilder(), a(-22680, -3983)), n)));
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            n3 = (int)q.nu(n, 2048L);
        }
        final ByteBuffer nf = q.nf(n3);
        long n4 = n;
        while (n4 > 0L) {
            q.yz(nf, 0);
            q.yd(nf, (int)q.nu(n4, 2048L));
            final int yb = q.yb(readableByteChannel, nf);
            Label_0148: {
                Label_0129: {
                    try {
                        if (c == 0) {
                            break Label_0148;
                        }
                        final int n5 = yb;
                        final int n6 = -1;
                        if (n5 == n6) {
                            break Label_0129;
                        }
                        break Label_0129;
                    }
                    catch (IOException ex3) {
                        throw b(ex3);
                    }
                    try {
                        final int n5 = yb;
                        final int n6 = -1;
                        if (n5 == n6) {
                            if (c != 0) {
                                break;
                            }
                        }
                    }
                    catch (IOException ex4) {
                        throw b(ex4);
                    }
                }
                n4 -= yb;
            }
            if (c == 0) {
                break;
            }
        }
        return n - n4;
    }
    
    public static long skip(final Reader p0, final long p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_3       
        //     4: lload_1        
        //     5: lconst_0       
        //     6: lcmp           
        //     7: ifge            48
        //    10: new             Ljava/lang/IllegalArgumentException;
        //    13: dup            
        //    14: new             Ljava/lang/StringBuilder;
        //    17: dup            
        //    18: invokespecial   java/lang/StringBuilder.<init>:()V
        //    21: sipush          -22680
        //    24: sipush          -3983
        //    27: invokestatic    org/apache/commons/io/IOUtils.a:(II)Ljava/lang/String;
        //    30: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    33: lload_1        
        //    34: invokestatic    q/o/m/s/q.es:(Ljava/lang/StringBuilder;J)Ljava/lang/StringBuilder;
        //    37: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    40: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //    43: athrow         
        //    44: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    47: athrow         
        //    48: getstatic       org/apache/commons/io/IOUtils.SKIP_CHAR_BUFFER:[C
        //    51: iload_3        
        //    52: ifne            88
        //    55: iload_3        
        //    56: ifne            88
        //    59: goto            66
        //    62: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    65: athrow         
        //    66: ifnonnull       91
        //    69: goto            76
        //    72: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    75: athrow         
        //    76: sipush          2048
        //    79: newarray        C
        //    81: goto            88
        //    84: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    87: athrow         
        //    88: putstatic       org/apache/commons/io/IOUtils.SKIP_CHAR_BUFFER:[C
        //    91: lload_1        
        //    92: lstore          4
        //    94: lload           4
        //    96: lconst_0       
        //    97: lcmp           
        //    98: ifle            179
        //   101: aload_0        
        //   102: getstatic       org/apache/commons/io/IOUtils.SKIP_CHAR_BUFFER:[C
        //   105: iconst_0       
        //   106: lload           4
        //   108: ldc2_w          2048
        //   111: invokestatic    q/o/m/s/q.nu:(JJ)J
        //   114: l2i            
        //   115: invokestatic    q/o/m/s/q.yj:(Ljava/io/Reader;[CII)I
        //   118: i2l            
        //   119: lstore          6
        //   121: lload           6
        //   123: lconst_0       
        //   124: iload_3        
        //   125: ifne            182
        //   128: iload_3        
        //   129: ifne            172
        //   132: goto            139
        //   135: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   138: athrow         
        //   139: lcmp           
        //   140: ifge            161
        //   143: goto            150
        //   146: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   149: athrow         
        //   150: iload_3        
        //   151: ifeq            179
        //   154: goto            161
        //   157: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   160: athrow         
        //   161: lload           4
        //   163: lload           6
        //   165: goto            172
        //   168: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   171: athrow         
        //   172: lsub           
        //   173: lstore          4
        //   175: iload_3        
        //   176: ifeq            94
        //   179: lload_1        
        //   180: lload           4
        //   182: lsub           
        //   183: lreturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 14 FF 00 2C 00 03 07 00 6D 04 01 00 01 07 00 44 03 4D 07 00 44 43 07 01 94 45 07 00 44 03 47 07 00 44 43 07 01 94 02 FC 00 02 04 FF 00 28 00 05 07 00 6D 04 01 04 04 00 01 07 00 44 FF 00 03 00 05 07 00 6D 04 01 04 04 00 02 04 04 46 07 00 44 03 46 07 00 44 03 46 07 00 44 FF 00 03 00 05 07 00 6D 04 01 04 04 00 02 04 04 FA 00 06 FF 00 02 00 04 07 00 6D 04 01 04 00 02 04 04
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      44     44     48     Ljava/io/IOException;
        //  48     59     62     66     Ljava/io/IOException;
        //  55     69     72     76     Ljava/io/IOException;
        //  66     81     84     88     Ljava/io/IOException;
        //  121    132    135    139    Ljava/io/IOException;
        //  128    143    146    150    Ljava/io/IOException;
        //  139    154    157    161    Ljava/io/IOException;
        //  150    165    168    172    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0066:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void skipFully(final InputStream inputStream, final long n) throws IOException {
        final int b = IOCase.b();
        long skip = 0L;
        Label_0064: {
            Label_0021: {
                try {
                    skip = n;
                    if (b != 0) {
                        break Label_0064;
                    }
                    final long n2 = 0L;
                    final long n3 = lcmp(n, n2);
                    if (n3 < 0) {
                        break Label_0021;
                    }
                    break Label_0021;
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                try {
                    final long n2 = 0L;
                    final long n3 = lcmp(n, n2);
                    if (n3 < 0) {
                        throw new IllegalArgumentException(q.s(q.es(q.r(new StringBuilder(), a(-22679, 32574)), n)));
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            skip = skip(inputStream, n);
        }
        final long n4 = skip;
        try {
            if (n4 != n) {
                throw new EOFException(q.s(q.es(q.r(q.es(q.r(new StringBuilder(), a(-22685, -5672)), n), a(-22676, -30820)), n4)));
            }
        }
        catch (IOException ex3) {
            throw b(ex3);
        }
    }
    
    public static void skipFully(final ReadableByteChannel readableByteChannel, final long n) throws IOException {
        final int c = IOCase.c();
        long skip = 0L;
        Label_0064: {
            Label_0021: {
                try {
                    skip = n;
                    if (c == 0) {
                        break Label_0064;
                    }
                    final long n2 = 0L;
                    final long n3 = lcmp(n, n2);
                    if (n3 < 0) {
                        break Label_0021;
                    }
                    break Label_0021;
                }
                catch (IOException ex) {
                    throw b(ex);
                }
                try {
                    final long n2 = 0L;
                    final long n3 = lcmp(n, n2);
                    if (n3 < 0) {
                        throw new IllegalArgumentException(q.s(q.es(q.r(new StringBuilder(), a(-22679, 32574)), n)));
                    }
                }
                catch (IOException ex2) {
                    throw b(ex2);
                }
            }
            skip = skip(readableByteChannel, n);
        }
        final long n4 = skip;
        try {
            if (n4 != n) {
                throw new EOFException(q.s(q.es(q.r(q.es(q.r(new StringBuilder(), a(-22685, -5672)), n), a(-22676, -30820)), n4)));
            }
        }
        catch (IOException ex3) {
            throw b(ex3);
        }
    }
    
    public static void skipFully(final Reader reader, final long n) throws IOException {
        final long skip = skip(reader, n);
        try {
            if (skip != n) {
                throw new EOFException(q.s(q.es(q.r(q.es(q.r(new StringBuilder(), a(-22674, -14409)), n), a(-22676, -30820)), skip)));
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    public static int read(final Reader p0, final char[] p1, final int p2, final int p3) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore          4
        //     5: iload_3        
        //     6: iload           4
        //     8: ifeq            60
        //    11: ifge            59
        //    14: goto            21
        //    17: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    20: athrow         
        //    21: new             Ljava/lang/IllegalArgumentException;
        //    24: dup            
        //    25: new             Ljava/lang/StringBuilder;
        //    28: dup            
        //    29: invokespecial   java/lang/StringBuilder.<init>:()V
        //    32: sipush          -22673
        //    35: sipush          -20395
        //    38: invokestatic    org/apache/commons/io/IOUtils.a:(II)Ljava/lang/String;
        //    41: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    44: iload_3        
        //    45: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //    48: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    51: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //    54: athrow         
        //    55: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    58: athrow         
        //    59: iload_3        
        //    60: istore          5
        //    62: iload           5
        //    64: ifle            147
        //    67: iload_3        
        //    68: iload           5
        //    70: isub           
        //    71: istore          6
        //    73: aload_0        
        //    74: aload_1        
        //    75: iload_2        
        //    76: iload           6
        //    78: iadd           
        //    79: iload           5
        //    81: invokestatic    q/o/m/s/q.yj:(Ljava/io/Reader;[CII)I
        //    84: istore          7
        //    86: iconst_m1      
        //    87: iload           7
        //    89: iload           4
        //    91: ifeq            150
        //    94: iload           4
        //    96: ifeq            139
        //    99: goto            106
        //   102: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   105: athrow         
        //   106: if_icmpne       128
        //   109: goto            116
        //   112: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   115: athrow         
        //   116: iload           4
        //   118: ifne            147
        //   121: goto            128
        //   124: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   127: athrow         
        //   128: iload           5
        //   130: iload           7
        //   132: goto            139
        //   135: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   138: athrow         
        //   139: isub           
        //   140: istore          5
        //   142: iload           4
        //   144: ifne            62
        //   147: iload_3        
        //   148: iload           5
        //   150: isub           
        //   151: ireturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 10 FF 00 11 00 05 07 00 6D 07 01 94 01 01 01 00 01 07 00 44 03 61 07 00 44 03 40 01 FC 00 01 01 FF 00 27 00 08 07 00 6D 07 01 94 01 01 01 01 01 01 00 01 07 00 44 FF 00 03 00 08 07 00 6D 07 01 94 01 01 01 01 01 01 00 02 01 01 45 07 00 44 03 47 07 00 44 03 46 07 00 44 FF 00 03 00 08 07 00 6D 07 01 94 01 01 01 01 01 01 00 02 01 01 F9 00 07 FF 00 02 00 00 00 02 01 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  5      14     17     21     Ljava/io/IOException;
        //  11     55     55     59     Ljava/io/IOException;
        //  86     99     102    106    Ljava/io/IOException;
        //  94     109    112    116    Ljava/io/IOException;
        //  106    121    124    128    Ljava/io/IOException;
        //  116    132    135    139    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0106:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static int read(final Reader reader, final char[] array) throws IOException {
        return read(reader, array, 0, array.length);
    }
    
    public static int read(final InputStream p0, final byte[] p1, final int p2, final int p3) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore          4
        //     5: iload_3        
        //     6: iload           4
        //     8: ifne            60
        //    11: ifge            59
        //    14: goto            21
        //    17: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    20: athrow         
        //    21: new             Ljava/lang/IllegalArgumentException;
        //    24: dup            
        //    25: new             Ljava/lang/StringBuilder;
        //    28: dup            
        //    29: invokespecial   java/lang/StringBuilder.<init>:()V
        //    32: sipush          -22673
        //    35: sipush          -20395
        //    38: invokestatic    org/apache/commons/io/IOUtils.a:(II)Ljava/lang/String;
        //    41: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    44: iload_3        
        //    45: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //    48: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    51: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //    54: athrow         
        //    55: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    58: athrow         
        //    59: iload_3        
        //    60: istore          5
        //    62: iload           5
        //    64: ifle            147
        //    67: iload_3        
        //    68: iload           5
        //    70: isub           
        //    71: istore          6
        //    73: aload_0        
        //    74: aload_1        
        //    75: iload_2        
        //    76: iload           6
        //    78: iadd           
        //    79: iload           5
        //    81: invokestatic    q/o/m/s/q.yn:(Ljava/io/InputStream;[BII)I
        //    84: istore          7
        //    86: iconst_m1      
        //    87: iload           7
        //    89: iload           4
        //    91: ifne            150
        //    94: iload           4
        //    96: ifne            139
        //    99: goto            106
        //   102: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   105: athrow         
        //   106: if_icmpne       128
        //   109: goto            116
        //   112: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   115: athrow         
        //   116: iload           4
        //   118: ifeq            147
        //   121: goto            128
        //   124: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   127: athrow         
        //   128: iload           5
        //   130: iload           7
        //   132: goto            139
        //   135: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   138: athrow         
        //   139: isub           
        //   140: istore          5
        //   142: iload           4
        //   144: ifeq            62
        //   147: iload_3        
        //   148: iload           5
        //   150: isub           
        //   151: ireturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 10 FF 00 11 00 05 07 00 90 07 00 C4 01 01 01 00 01 07 00 44 03 61 07 00 44 03 40 01 FC 00 01 01 FF 00 27 00 08 07 00 90 07 00 C4 01 01 01 01 01 01 00 01 07 00 44 FF 00 03 00 08 07 00 90 07 00 C4 01 01 01 01 01 01 00 02 01 01 45 07 00 44 03 47 07 00 44 03 46 07 00 44 FF 00 03 00 08 07 00 90 07 00 C4 01 01 01 01 01 01 00 02 01 01 F9 00 07 FF 00 02 00 00 00 02 01 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  5      14     17     21     Ljava/io/IOException;
        //  11     55     55     59     Ljava/io/IOException;
        //  86     99     102    106    Ljava/io/IOException;
        //  94     109    112    116    Ljava/io/IOException;
        //  106    121    124    128    Ljava/io/IOException;
        //  116    132    135    139    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0106:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static int read(final InputStream inputStream, final byte[] array) throws IOException {
        return read(inputStream, array, 0, array.length);
    }
    
    public static int read(final ReadableByteChannel p0, final ByteBuffer p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_1        
        //     4: invokestatic    q/o/m/s/q.yw:(Ljava/nio/ByteBuffer;)I
        //     7: istore_3       
        //     8: istore_2       
        //     9: aload_1        
        //    10: invokestatic    q/o/m/s/q.yw:(Ljava/nio/ByteBuffer;)I
        //    13: ifle            62
        //    16: aload_0        
        //    17: aload_1        
        //    18: invokestatic    q/o/m/s/q.yb:(Ljava/nio/channels/ReadableByteChannel;Ljava/nio/ByteBuffer;)I
        //    21: istore          4
        //    23: iconst_m1      
        //    24: iload           4
        //    26: iload_2        
        //    27: ifne            67
        //    30: if_icmpne       51
        //    33: goto            40
        //    36: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    39: athrow         
        //    40: iload_2        
        //    41: ifeq            62
        //    44: goto            51
        //    47: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    50: athrow         
        //    51: iload_2        
        //    52: ifeq            9
        //    55: goto            62
        //    58: invokestatic    org/apache/commons/io/IOUtils.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    61: athrow         
        //    62: iload_3        
        //    63: aload_1        
        //    64: invokestatic    q/o/m/s/q.yw:(Ljava/nio/ByteBuffer;)I
        //    67: isub           
        //    68: ireturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 08 FD 00 09 01 01 FF 00 1A 00 05 07 02 2F 07 02 35 01 01 01 00 01 07 00 44 03 46 07 00 44 03 46 07 00 44 FA 00 03 FF 00 04 00 00 00 02 01 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  23     33     36     40     Ljava/io/IOException;
        //  30     44     47     51     Ljava/io/IOException;
        //  40     55     58     62     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0040:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void readFully(final Reader reader, final char[] array, final int n, final int n2) throws IOException {
        final int read = read(reader, array, n, n2);
        try {
            if (read != n2) {
                throw new EOFException(q.s(q.qg(q.r(q.qg(q.r(new StringBuilder(), a(-22678, 8847)), n2), a(-22676, -30820)), read)));
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    public static void readFully(final Reader reader, final char[] array) throws IOException {
        readFully(reader, array, 0, array.length);
    }
    
    public static void readFully(final InputStream inputStream, final byte[] array, final int n, final int n2) throws IOException {
        final int read = read(inputStream, array, n, n2);
        try {
            if (read != n2) {
                throw new EOFException(q.s(q.qg(q.r(q.qg(q.r(new StringBuilder(), a(-22678, 8847)), n2), a(-22676, -30820)), read)));
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    public static void readFully(final InputStream inputStream, final byte[] array) throws IOException {
        readFully(inputStream, array, 0, array.length);
    }
    
    public static byte[] readFully(final InputStream inputStream, final int n) throws IOException {
        final byte[] array = new byte[n];
        readFully(inputStream, array, 0, array.length);
        return array;
    }
    
    public static void readFully(final ReadableByteChannel readableByteChannel, final ByteBuffer byteBuffer) throws IOException {
        final int yw = q.yw(byteBuffer);
        final int read = read(readableByteChannel, byteBuffer);
        try {
            if (read != yw) {
                throw new EOFException(q.s(q.qg(q.r(q.qg(q.r(new StringBuilder(), a(-22678, 8847)), yw), a(-22676, -30820)), read)));
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    static {
        final String[] a2 = new String[12];
        int n = 0;
        String s;
        int n2 = q.q(s = n.d.a.d.q.vl());
        int n3 = 41;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 84));
                ++n4;
                final String s2 = s;
                final int n9 = n4;
                String s3 = q.h(s2, n9, n9 + n3);
                int n10 = -1;
                while (true) {
                    final char[] g = q.g(s3);
                    final int length = g.length;
                    int n11 = 0;
                    while (true) {
                        Label_0272: {
                            if (length > 1) {
                                break Label_0272;
                            }
                            n7 = (n6 = n11);
                            do {
                                final char c = g[n6];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 35;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 96;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 41;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 14;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 69;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 112;
                                        break;
                                    }
                                    default: {
                                        n12 = 77;
                                        break;
                                    }
                                }
                                g[n7] = (char)(c ^ (n5 ^ n12));
                                ++n11;
                            } while (n8 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.z(new String(g));
                    switch (n10) {
                        default: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                continue Label_0024;
                            }
                            n2 = q.q(s = n.d.a.d.q.vi());
                            n3 = 2;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 84)));
                    ++n4;
                    final String s4 = s;
                    final int n13 = n4;
                    s3 = q.h(s4, n13, n13 + n3);
                    n10 = 0;
                }
            }
            break;
        }
        a = a2;
        b = new String[12];
        LINE_SEPARATOR_WINDOWS = a(-22687, -5249);
        DIR_SEPARATOR = x.dn.g.b.q.n();
        final StringBuilderWriter out = new StringBuilderWriter(4);
        final PrintWriter printWriter = new PrintWriter(out);
        q.ya(printWriter);
        LINE_SEPARATOR = out.toString();
        q.rd(printWriter);
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0xFFFFA76B) & 0xFFFF;
        if (IOUtils.b[n3] == null) {
            final char[] g = q.g(IOUtils.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 235;
                    break;
                }
                case 1: {
                    n4 = 32;
                    break;
                }
                case 2: {
                    n4 = 233;
                    break;
                }
                case 3: {
                    n4 = 178;
                    break;
                }
                case 4: {
                    n4 = 76;
                    break;
                }
                case 5: {
                    n4 = 86;
                    break;
                }
                case 6: {
                    n4 = 22;
                    break;
                }
                case 7: {
                    n4 = 50;
                    break;
                }
                case 8: {
                    n4 = 20;
                    break;
                }
                case 9: {
                    n4 = 103;
                    break;
                }
                case 10: {
                    n4 = 207;
                    break;
                }
                case 11: {
                    n4 = 237;
                    break;
                }
                case 12: {
                    n4 = 111;
                    break;
                }
                case 13: {
                    n4 = 71;
                    break;
                }
                case 14: {
                    n4 = 183;
                    break;
                }
                case 15: {
                    n4 = 201;
                    break;
                }
                case 16: {
                    n4 = 134;
                    break;
                }
                case 17: {
                    n4 = 182;
                    break;
                }
                case 18: {
                    n4 = 49;
                    break;
                }
                case 19: {
                    n4 = 177;
                    break;
                }
                case 20: {
                    n4 = 255;
                    break;
                }
                case 21: {
                    n4 = 133;
                    break;
                }
                case 22: {
                    n4 = 113;
                    break;
                }
                case 23: {
                    n4 = 130;
                    break;
                }
                case 24: {
                    n4 = 126;
                    break;
                }
                case 25: {
                    n4 = 0;
                    break;
                }
                case 26: {
                    n4 = 90;
                    break;
                }
                case 27: {
                    n4 = 188;
                    break;
                }
                case 28: {
                    n4 = 254;
                    break;
                }
                case 29: {
                    n4 = 193;
                    break;
                }
                case 30: {
                    n4 = 39;
                    break;
                }
                case 31: {
                    n4 = 151;
                    break;
                }
                case 32: {
                    n4 = 78;
                    break;
                }
                case 33: {
                    n4 = 121;
                    break;
                }
                case 34: {
                    n4 = 247;
                    break;
                }
                case 35: {
                    n4 = 98;
                    break;
                }
                case 36: {
                    n4 = 67;
                    break;
                }
                case 37: {
                    n4 = 197;
                    break;
                }
                case 38: {
                    n4 = 33;
                    break;
                }
                case 39: {
                    n4 = 99;
                    break;
                }
                case 40: {
                    n4 = 138;
                    break;
                }
                case 41: {
                    n4 = 217;
                    break;
                }
                case 42: {
                    n4 = 160;
                    break;
                }
                case 43: {
                    n4 = 96;
                    break;
                }
                case 44: {
                    n4 = 58;
                    break;
                }
                case 45: {
                    n4 = 27;
                    break;
                }
                case 46: {
                    n4 = 16;
                    break;
                }
                case 47: {
                    n4 = 79;
                    break;
                }
                case 48: {
                    n4 = 155;
                    break;
                }
                case 49: {
                    n4 = 234;
                    break;
                }
                case 50: {
                    n4 = 109;
                    break;
                }
                case 51: {
                    n4 = 11;
                    break;
                }
                case 52: {
                    n4 = 165;
                    break;
                }
                case 53: {
                    n4 = 220;
                    break;
                }
                case 54: {
                    n4 = 175;
                    break;
                }
                case 55: {
                    n4 = 209;
                    break;
                }
                case 56: {
                    n4 = 110;
                    break;
                }
                case 57: {
                    n4 = 141;
                    break;
                }
                case 58: {
                    n4 = 204;
                    break;
                }
                case 59: {
                    n4 = 48;
                    break;
                }
                case 60: {
                    n4 = 146;
                    break;
                }
                case 61: {
                    n4 = 176;
                    break;
                }
                case 62: {
                    n4 = 9;
                    break;
                }
                case 63: {
                    n4 = 55;
                    break;
                }
                case 64: {
                    n4 = 26;
                    break;
                }
                case 65: {
                    n4 = 225;
                    break;
                }
                case 66: {
                    n4 = 3;
                    break;
                }
                case 67: {
                    n4 = 251;
                    break;
                }
                case 68: {
                    n4 = 15;
                    break;
                }
                case 69: {
                    n4 = 196;
                    break;
                }
                case 70: {
                    n4 = 44;
                    break;
                }
                case 71: {
                    n4 = 218;
                    break;
                }
                case 72: {
                    n4 = 52;
                    break;
                }
                case 73: {
                    n4 = 40;
                    break;
                }
                case 74: {
                    n4 = 88;
                    break;
                }
                case 75: {
                    n4 = 56;
                    break;
                }
                case 76: {
                    n4 = 74;
                    break;
                }
                case 77: {
                    n4 = 131;
                    break;
                }
                case 78: {
                    n4 = 38;
                    break;
                }
                case 79: {
                    n4 = 132;
                    break;
                }
                case 80: {
                    n4 = 213;
                    break;
                }
                case 81: {
                    n4 = 232;
                    break;
                }
                case 82: {
                    n4 = 140;
                    break;
                }
                case 83: {
                    n4 = 36;
                    break;
                }
                case 84: {
                    n4 = 230;
                    break;
                }
                case 85: {
                    n4 = 19;
                    break;
                }
                case 86: {
                    n4 = 7;
                    break;
                }
                case 87: {
                    n4 = 172;
                    break;
                }
                case 88: {
                    n4 = 62;
                    break;
                }
                case 89: {
                    n4 = 122;
                    break;
                }
                case 90: {
                    n4 = 63;
                    break;
                }
                case 91: {
                    n4 = 226;
                    break;
                }
                case 92: {
                    n4 = 106;
                    break;
                }
                case 93: {
                    n4 = 250;
                    break;
                }
                case 94: {
                    n4 = 210;
                    break;
                }
                case 95: {
                    n4 = 4;
                    break;
                }
                case 96: {
                    n4 = 148;
                    break;
                }
                case 97: {
                    n4 = 114;
                    break;
                }
                case 98: {
                    n4 = 154;
                    break;
                }
                case 99: {
                    n4 = 228;
                    break;
                }
                case 100: {
                    n4 = 105;
                    break;
                }
                case 101: {
                    n4 = 147;
                    break;
                }
                case 102: {
                    n4 = 41;
                    break;
                }
                case 103: {
                    n4 = 29;
                    break;
                }
                case 104: {
                    n4 = 162;
                    break;
                }
                case 105: {
                    n4 = 200;
                    break;
                }
                case 106: {
                    n4 = 179;
                    break;
                }
                case 107: {
                    n4 = 118;
                    break;
                }
                case 108: {
                    n4 = 219;
                    break;
                }
                case 109: {
                    n4 = 149;
                    break;
                }
                case 110: {
                    n4 = 14;
                    break;
                }
                case 111: {
                    n4 = 202;
                    break;
                }
                case 112: {
                    n4 = 119;
                    break;
                }
                case 113: {
                    n4 = 171;
                    break;
                }
                case 114: {
                    n4 = 35;
                    break;
                }
                case 115: {
                    n4 = 152;
                    break;
                }
                case 116: {
                    n4 = 12;
                    break;
                }
                case 117: {
                    n4 = 127;
                    break;
                }
                case 118: {
                    n4 = 215;
                    break;
                }
                case 119: {
                    n4 = 73;
                    break;
                }
                case 120: {
                    n4 = 30;
                    break;
                }
                case 121: {
                    n4 = 212;
                    break;
                }
                case 122: {
                    n4 = 198;
                    break;
                }
                case 123: {
                    n4 = 180;
                    break;
                }
                case 124: {
                    n4 = 59;
                    break;
                }
                case 125: {
                    n4 = 117;
                    break;
                }
                case 126: {
                    n4 = 240;
                    break;
                }
                case 127: {
                    n4 = 17;
                    break;
                }
                case 128: {
                    n4 = 97;
                    break;
                }
                case 129: {
                    n4 = 194;
                    break;
                }
                case 130: {
                    n4 = 46;
                    break;
                }
                case 131: {
                    n4 = 61;
                    break;
                }
                case 132: {
                    n4 = 195;
                    break;
                }
                case 133: {
                    n4 = 145;
                    break;
                }
                case 134: {
                    n4 = 249;
                    break;
                }
                case 135: {
                    n4 = 166;
                    break;
                }
                case 136: {
                    n4 = 192;
                    break;
                }
                case 137: {
                    n4 = 83;
                    break;
                }
                case 138: {
                    n4 = 248;
                    break;
                }
                case 139: {
                    n4 = 125;
                    break;
                }
                case 140: {
                    n4 = 107;
                    break;
                }
                case 141: {
                    n4 = 69;
                    break;
                }
                case 142: {
                    n4 = 169;
                    break;
                }
                case 143: {
                    n4 = 205;
                    break;
                }
                case 144: {
                    n4 = 208;
                    break;
                }
                case 145: {
                    n4 = 24;
                    break;
                }
                case 146: {
                    n4 = 42;
                    break;
                }
                case 147: {
                    n4 = 13;
                    break;
                }
                case 148: {
                    n4 = 37;
                    break;
                }
                case 149: {
                    n4 = 104;
                    break;
                }
                case 150: {
                    n4 = 53;
                    break;
                }
                case 151: {
                    n4 = 60;
                    break;
                }
                case 152: {
                    n4 = 5;
                    break;
                }
                case 153: {
                    n4 = 6;
                    break;
                }
                case 154: {
                    n4 = 231;
                    break;
                }
                case 155: {
                    n4 = 100;
                    break;
                }
                case 156: {
                    n4 = 173;
                    break;
                }
                case 157: {
                    n4 = 185;
                    break;
                }
                case 158: {
                    n4 = 57;
                    break;
                }
                case 159: {
                    n4 = 239;
                    break;
                }
                case 160: {
                    n4 = 45;
                    break;
                }
                case 161: {
                    n4 = 241;
                    break;
                }
                case 162: {
                    n4 = 89;
                    break;
                }
                case 163: {
                    n4 = 43;
                    break;
                }
                case 164: {
                    n4 = 238;
                    break;
                }
                case 165: {
                    n4 = 116;
                    break;
                }
                case 166: {
                    n4 = 186;
                    break;
                }
                case 167: {
                    n4 = 47;
                    break;
                }
                case 168: {
                    n4 = 243;
                    break;
                }
                case 169: {
                    n4 = 91;
                    break;
                }
                case 170: {
                    n4 = 82;
                    break;
                }
                case 171: {
                    n4 = 31;
                    break;
                }
                case 172: {
                    n4 = 94;
                    break;
                }
                case 173: {
                    n4 = 115;
                    break;
                }
                case 174: {
                    n4 = 123;
                    break;
                }
                case 175: {
                    n4 = 120;
                    break;
                }
                case 176: {
                    n4 = 156;
                    break;
                }
                case 177: {
                    n4 = 95;
                    break;
                }
                case 178: {
                    n4 = 137;
                    break;
                }
                case 179: {
                    n4 = 221;
                    break;
                }
                case 180: {
                    n4 = 18;
                    break;
                }
                case 181: {
                    n4 = 108;
                    break;
                }
                case 182: {
                    n4 = 1;
                    break;
                }
                case 183: {
                    n4 = 75;
                    break;
                }
                case 184: {
                    n4 = 136;
                    break;
                }
                case 185: {
                    n4 = 189;
                    break;
                }
                case 186: {
                    n4 = 167;
                    break;
                }
                case 187: {
                    n4 = 216;
                    break;
                }
                case 188: {
                    n4 = 129;
                    break;
                }
                case 189: {
                    n4 = 245;
                    break;
                }
                case 190: {
                    n4 = 229;
                    break;
                }
                case 191: {
                    n4 = 23;
                    break;
                }
                case 192: {
                    n4 = 135;
                    break;
                }
                case 193: {
                    n4 = 142;
                    break;
                }
                case 194: {
                    n4 = 236;
                    break;
                }
                case 195: {
                    n4 = 224;
                    break;
                }
                case 196: {
                    n4 = 150;
                    break;
                }
                case 197: {
                    n4 = 222;
                    break;
                }
                case 198: {
                    n4 = 64;
                    break;
                }
                case 199: {
                    n4 = 191;
                    break;
                }
                case 200: {
                    n4 = 211;
                    break;
                }
                case 201: {
                    n4 = 81;
                    break;
                }
                case 202: {
                    n4 = 158;
                    break;
                }
                case 203: {
                    n4 = 144;
                    break;
                }
                case 204: {
                    n4 = 242;
                    break;
                }
                case 205: {
                    n4 = 244;
                    break;
                }
                case 206: {
                    n4 = 203;
                    break;
                }
                case 207: {
                    n4 = 80;
                    break;
                }
                case 208: {
                    n4 = 181;
                    break;
                }
                case 209: {
                    n4 = 163;
                    break;
                }
                case 210: {
                    n4 = 157;
                    break;
                }
                case 211: {
                    n4 = 51;
                    break;
                }
                case 212: {
                    n4 = 68;
                    break;
                }
                case 213: {
                    n4 = 70;
                    break;
                }
                case 214: {
                    n4 = 112;
                    break;
                }
                case 215: {
                    n4 = 128;
                    break;
                }
                case 216: {
                    n4 = 223;
                    break;
                }
                case 217: {
                    n4 = 190;
                    break;
                }
                case 218: {
                    n4 = 124;
                    break;
                }
                case 219: {
                    n4 = 168;
                    break;
                }
                case 220: {
                    n4 = 174;
                    break;
                }
                case 221: {
                    n4 = 65;
                    break;
                }
                case 222: {
                    n4 = 246;
                    break;
                }
                case 223: {
                    n4 = 253;
                    break;
                }
                case 224: {
                    n4 = 25;
                    break;
                }
                case 225: {
                    n4 = 227;
                    break;
                }
                case 226: {
                    n4 = 187;
                    break;
                }
                case 227: {
                    n4 = 170;
                    break;
                }
                case 228: {
                    n4 = 54;
                    break;
                }
                case 229: {
                    n4 = 10;
                    break;
                }
                case 230: {
                    n4 = 214;
                    break;
                }
                case 231: {
                    n4 = 84;
                    break;
                }
                case 232: {
                    n4 = 252;
                    break;
                }
                case 233: {
                    n4 = 184;
                    break;
                }
                case 234: {
                    n4 = 164;
                    break;
                }
                case 235: {
                    n4 = 139;
                    break;
                }
                case 236: {
                    n4 = 34;
                    break;
                }
                case 237: {
                    n4 = 8;
                    break;
                }
                case 238: {
                    n4 = 21;
                    break;
                }
                case 239: {
                    n4 = 87;
                    break;
                }
                case 240: {
                    n4 = 206;
                    break;
                }
                case 241: {
                    n4 = 93;
                    break;
                }
                case 242: {
                    n4 = 143;
                    break;
                }
                case 243: {
                    n4 = 199;
                    break;
                }
                case 244: {
                    n4 = 101;
                    break;
                }
                case 245: {
                    n4 = 28;
                    break;
                }
                case 246: {
                    n4 = 159;
                    break;
                }
                case 247: {
                    n4 = 72;
                    break;
                }
                case 248: {
                    n4 = 2;
                    break;
                }
                case 249: {
                    n4 = 92;
                    break;
                }
                case 250: {
                    n4 = 85;
                    break;
                }
                case 251: {
                    n4 = 66;
                    break;
                }
                case 252: {
                    n4 = 153;
                    break;
                }
                case 253: {
                    n4 = 161;
                    break;
                }
                case 254: {
                    n4 = 77;
                    break;
                }
                default: {
                    n4 = 102;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            IOUtils.b[n3] = q.z(new String(g));
        }
        return IOUtils.b[n3];
    }
}
