// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import q.o.m.s.q;
import java.io.IOException;

class ReversedLinesFileReader$FilePart
{
    private final long no;
    private final byte[] data;
    private byte[] leftOver;
    private int currentLastBytePos;
    final ReversedLinesFileReader this$0;
    private static final String[] a;
    private static final String[] b;
    
    private ReversedLinesFileReader$FilePart(final ReversedLinesFileReader p0, final long p1, final int p2, final byte[] p3) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: aload_1        
        //     2: putfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.this$0:Lorg/apache/commons/io/input/ReversedLinesFileReader;
        //     5: invokestatic    org/apache/commons/io/input/ProxyInputStream.b:()Ljava/lang/String;
        //     8: aload_0        
        //     9: invokespecial   java/lang/Object.<init>:()V
        //    12: astore          6
        //    14: aload_0        
        //    15: lload_2        
        //    16: putfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.no:J
        //    19: iload           4
        //    21: aload           5
        //    23: aload           6
        //    25: ifnonnull       52
        //    28: aload           6
        //    30: ifnonnull       52
        //    33: goto            40
        //    36: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    39: athrow         
        //    40: ifnull          56
        //    43: goto            50
        //    46: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    49: athrow         
        //    50: aload           5
        //    52: arraylength    
        //    53: goto            57
        //    56: iconst_0       
        //    57: iadd           
        //    58: istore          7
        //    60: aload_0        
        //    61: iload           7
        //    63: newarray        B
        //    65: putfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.data:[B
        //    68: lload_2        
        //    69: lconst_1       
        //    70: lsub           
        //    71: aload_1        
        //    72: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.access$300:(Lorg/apache/commons/io/input/ReversedLinesFileReader;)I
        //    75: i2l            
        //    76: lmul           
        //    77: lstore          8
        //    79: lload_2        
        //    80: lconst_0       
        //    81: lcmp           
        //    82: aload           6
        //    84: ifnonnull       139
        //    87: aload           6
        //    89: ifnonnull       139
        //    92: goto            99
        //    95: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    98: athrow         
        //    99: ifle            169
        //   102: goto            109
        //   105: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   108: athrow         
        //   109: aload_1        
        //   110: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.access$400:(Lorg/apache/commons/io/input/ReversedLinesFileReader;)Ljava/io/RandomAccessFile;
        //   113: lload           8
        //   115: invokestatic    q/o/m/s/q.cb:(Ljava/io/RandomAccessFile;J)V
        //   118: aload_1        
        //   119: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.access$400:(Lorg/apache/commons/io/input/ReversedLinesFileReader;)Ljava/io/RandomAccessFile;
        //   122: aload_0        
        //   123: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.data:[B
        //   126: iconst_0       
        //   127: iload           4
        //   129: invokestatic    q/o/m/s/q.ha:(Ljava/io/RandomAccessFile;[BII)I
        //   132: goto            139
        //   135: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   138: athrow         
        //   139: istore          10
        //   141: iload           10
        //   143: iload           4
        //   145: if_icmpeq       169
        //   148: new             Ljava/lang/IllegalStateException;
        //   151: dup            
        //   152: sipush          21706
        //   155: sipush          12505
        //   158: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.a:(II)Ljava/lang/String;
        //   161: invokespecial   java/lang/IllegalStateException.<init>:(Ljava/lang/String;)V
        //   164: athrow         
        //   165: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   168: athrow         
        //   169: aload           5
        //   171: aload           6
        //   173: ifnonnull       200
        //   176: aload           6
        //   178: ifnonnull       200
        //   181: goto            188
        //   184: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   187: athrow         
        //   188: ifnull          213
        //   191: goto            198
        //   194: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   197: athrow         
        //   198: aload           5
        //   200: iconst_0       
        //   201: aload_0        
        //   202: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.data:[B
        //   205: iload           4
        //   207: aload           5
        //   209: arraylength    
        //   210: invokestatic    q/o/m/s/q.st:(Ljava/lang/Object;ILjava/lang/Object;II)V
        //   213: aload_0        
        //   214: aload_0        
        //   215: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.data:[B
        //   218: arraylength    
        //   219: iconst_1       
        //   220: isub           
        //   221: putfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.currentLastBytePos:I
        //   224: aload_0        
        //   225: aconst_null    
        //   226: putfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.leftOver:[B
        //   229: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 15 FF 00 24 00 06 07 00 02 07 00 23 04 01 07 00 24 07 00 26 00 01 07 00 15 FF 00 03 00 06 07 00 02 07 00 23 04 01 07 00 24 07 00 26 00 02 01 07 00 24 45 07 00 15 43 01 FF 00 01 00 06 07 00 02 07 00 23 04 01 07 00 24 07 00 26 00 02 01 07 00 24 43 01 FF 00 00 00 06 07 00 02 07 00 23 04 01 07 00 24 07 00 26 00 02 01 01 FF 00 25 00 08 07 00 02 07 00 23 04 01 07 00 24 07 00 26 01 04 00 01 07 00 15 43 01 45 07 00 15 03 59 07 00 15 43 01 FF 00 19 00 09 07 00 02 07 00 23 04 01 07 00 24 07 00 26 01 04 01 00 01 07 00 15 FA 00 03 4E 07 00 15 43 07 00 24 45 07 00 15 03 41 07 00 24 0C
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  14     33     36     40     Ljava/io/IOException;
        //  28     43     46     50     Ljava/io/IOException;
        //  79     92     95     99     Ljava/io/IOException;
        //  87     102    105    109    Ljava/io/IOException;
        //  99     132    135    139    Ljava/io/IOException;
        //  141    165    165    169    Ljava/io/IOException;
        //  169    181    184    188    Ljava/io/IOException;
        //  176    191    194    198    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0099:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private ReversedLinesFileReader$FilePart rollOver() throws IOException {
        final String b = ProxyInputStream.b();
        Label_0125: {
            Label_0120: {
                ReversedLinesFileReader$FilePart reversedLinesFileReader$FilePart2 = null;
                Label_0081: {
                    long currentLastBytePos = 0L;
                    Label_0064: {
                        Label_0023: {
                            int n;
                            try {
                                n = (int)(currentLastBytePos = this.currentLastBytePos);
                                if (b != null) {
                                    break Label_0081;
                                }
                                final int n2 = -1;
                                if (n > n2) {
                                    break Label_0023;
                                }
                                break Label_0064;
                            }
                            catch (IOException ex) {
                                throw b(ex);
                            }
                            try {
                                final int n2 = -1;
                                if (n > n2) {
                                    throw new IllegalStateException(q.s(q.qg(q.r(new StringBuilder(), a(21705, 8886)), this.currentLastBytePos)));
                                }
                            }
                            catch (IOException ex2) {
                                throw b(ex2);
                            }
                        }
                        try {
                            final ReversedLinesFileReader$FilePart reversedLinesFileReader$FilePart = this;
                            if (b != null) {
                                break Label_0125;
                            }
                            currentLastBytePos = lcmp(this.no, 1L);
                        }
                        catch (IOException ex3) {
                            throw b(ex3);
                        }
                    }
                    try {
                        if (currentLastBytePos <= 0) {
                            break Label_0120;
                        }
                        reversedLinesFileReader$FilePart2 = new ReversedLinesFileReader$FilePart(this.this$0, this.no - 1L, ReversedLinesFileReader.access$300(this.this$0), this.leftOver);
                    }
                    catch (IOException ex4) {
                        throw b(ex4);
                    }
                }
                return reversedLinesFileReader$FilePart2;
            }
            final ReversedLinesFileReader$FilePart reversedLinesFileReader$FilePart = this;
            ReversedLinesFileReader$FilePart reversedLinesFileReader$FilePart2 = this;
            if (b != null) {
                return reversedLinesFileReader$FilePart2;
            }
            try {
                if (reversedLinesFileReader$FilePart.leftOver != null) {
                    throw new IllegalStateException(q.s(q.r(q.r(new StringBuilder(), a(21704, -16352)), new String(this.leftOver, ReversedLinesFileReader.access$500(this.this$0)))));
                }
            }
            catch (IOException ex5) {
                throw b(ex5);
            }
        }
        return null;
    }
    
    private String readLine() throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aconst_null    
        //     4: astore_2       
        //     5: astore_1       
        //     6: aload_0        
        //     7: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.no:J
        //    10: lconst_1       
        //    11: lcmp           
        //    12: aload_1        
        //    13: ifnonnull       38
        //    16: aload_1        
        //    17: ifnonnull       38
        //    20: goto            27
        //    23: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    26: athrow         
        //    27: ifne            41
        //    30: goto            37
        //    33: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    36: athrow         
        //    37: iconst_1       
        //    38: goto            42
        //    41: iconst_0       
        //    42: istore          4
        //    44: aload_0        
        //    45: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.currentLastBytePos:I
        //    48: istore          5
        //    50: iload           5
        //    52: iconst_m1      
        //    53: if_icmple       289
        //    56: iload           4
        //    58: aload_1        
        //    59: ifnonnull       110
        //    62: ifne            96
        //    65: goto            72
        //    68: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    71: athrow         
        //    72: iload           5
        //    74: aload_0        
        //    75: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.this$0:Lorg/apache/commons/io/input/ReversedLinesFileReader;
        //    78: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.access$600:(Lorg/apache/commons/io/input/ReversedLinesFileReader;)I
        //    81: aload_1        
        //    82: ifnonnull       111
        //    85: if_icmpge       96
        //    88: aload_0        
        //    89: invokespecial   org/apache/commons/io/input/ReversedLinesFileReader$FilePart.createLeftOver:()V
        //    92: aload_1        
        //    93: ifnull          289
        //    96: aload_0        
        //    97: aload_1        
        //    98: ifnonnull       89
        //   101: aload_0        
        //   102: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.data:[B
        //   105: iload           5
        //   107: invokespecial   org/apache/commons/io/input/ReversedLinesFileReader$FilePart.getNewLineMatchByteCount:([BI)I
        //   110: dup            
        //   111: istore_3       
        //   112: aload_1        
        //   113: ifnonnull       74
        //   116: aload_1        
        //   117: ifnonnull       275
        //   120: ifle            257
        //   123: goto            130
        //   126: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   129: athrow         
        //   130: iload           5
        //   132: iconst_1       
        //   133: iadd           
        //   134: goto            141
        //   137: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   140: athrow         
        //   141: istore          6
        //   143: aload_0        
        //   144: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.currentLastBytePos:I
        //   147: iload           6
        //   149: isub           
        //   150: iconst_1       
        //   151: iadd           
        //   152: istore          7
        //   154: iload           7
        //   156: aload_1        
        //   157: ifnonnull       211
        //   160: ifge            209
        //   163: goto            170
        //   166: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   169: athrow         
        //   170: new             Ljava/lang/IllegalStateException;
        //   173: dup            
        //   174: new             Ljava/lang/StringBuilder;
        //   177: dup            
        //   178: invokespecial   java/lang/StringBuilder.<init>:()V
        //   181: sipush          21707
        //   184: sipush          16658
        //   187: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.a:(II)Ljava/lang/String;
        //   190: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   193: iload           7
        //   195: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   198: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   201: invokespecial   java/lang/IllegalStateException.<init>:(Ljava/lang/String;)V
        //   204: athrow         
        //   205: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   208: athrow         
        //   209: iload           7
        //   211: newarray        B
        //   213: astore          8
        //   215: aload_0        
        //   216: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.data:[B
        //   219: iload           6
        //   221: aload           8
        //   223: iconst_0       
        //   224: iload           7
        //   226: invokestatic    q/o/m/s/q.st:(Ljava/lang/Object;ILjava/lang/Object;II)V
        //   229: new             Ljava/lang/String;
        //   232: dup            
        //   233: aload           8
        //   235: aload_0        
        //   236: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.this$0:Lorg/apache/commons/io/input/ReversedLinesFileReader;
        //   239: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.access$500:(Lorg/apache/commons/io/input/ReversedLinesFileReader;)Ljava/nio/charset/Charset;
        //   242: invokespecial   java/lang/String.<init>:([BLjava/nio/charset/Charset;)V
        //   245: astore_2       
        //   246: aload_0        
        //   247: iload           5
        //   249: iload_3        
        //   250: isub           
        //   251: putfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.currentLastBytePos:I
        //   254: goto            289
        //   257: iload           5
        //   259: aload_0        
        //   260: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.this$0:Lorg/apache/commons/io/input/ReversedLinesFileReader;
        //   263: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.access$700:(Lorg/apache/commons/io/input/ReversedLinesFileReader;)I
        //   266: isub           
        //   267: istore          5
        //   269: iload           5
        //   271: aload_1        
        //   272: ifnonnull       141
        //   275: ifge            50
        //   278: aload_0        
        //   279: invokespecial   org/apache/commons/io/input/ReversedLinesFileReader$FilePart.createLeftOver:()V
        //   282: aload_1        
        //   283: ifnonnull       96
        //   286: goto            289
        //   289: iload           4
        //   291: ifeq            350
        //   294: aload_0        
        //   295: aload_1        
        //   296: ifnonnull       346
        //   299: goto            306
        //   302: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   305: athrow         
        //   306: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.leftOver:[B
        //   309: ifnull          350
        //   312: goto            319
        //   315: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   318: athrow         
        //   319: new             Ljava/lang/String;
        //   322: dup            
        //   323: aload_0        
        //   324: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.leftOver:[B
        //   327: aload_0        
        //   328: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.this$0:Lorg/apache/commons/io/input/ReversedLinesFileReader;
        //   331: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.access$500:(Lorg/apache/commons/io/input/ReversedLinesFileReader;)Ljava/nio/charset/Charset;
        //   334: invokespecial   java/lang/String.<init>:([BLjava/nio/charset/Charset;)V
        //   337: goto            344
        //   340: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   343: athrow         
        //   344: astore_2       
        //   345: aload_0        
        //   346: aconst_null    
        //   347: putfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.leftOver:[B
        //   350: aload_2        
        //   351: aload_1        
        //   352: ifnonnull       344
        //   355: areturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 23 FF 00 17 00 03 07 00 02 07 00 26 05 00 01 07 00 15 43 01 45 07 00 15 03 40 01 02 40 01 FE 00 07 00 01 01 51 07 00 15 03 41 01 4E 07 00 02 06 4D 01 FF 00 00 00 06 07 00 02 07 00 26 05 00 01 01 00 02 01 01 FF 00 0E 00 06 07 00 02 07 00 26 05 01 01 01 00 01 07 00 15 03 46 07 00 15 43 01 FF 00 18 00 08 07 00 02 07 00 26 05 01 01 01 01 01 00 01 07 00 15 03 62 07 00 15 03 41 01 F9 00 2D 51 01 FF 00 0D 00 06 07 00 02 07 00 26 07 00 26 00 01 01 00 00 4C 07 00 15 43 07 00 02 48 07 00 15 03 54 07 00 15 43 07 00 26 41 07 00 02 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  6      20     23     27     Ljava/io/IOException;
        //  16     30     33     37     Ljava/io/IOException;
        //  56     65     68     72     Ljava/io/IOException;
        //  116    123    126    130    Ljava/io/IOException;
        //  120    134    137    141    Ljava/io/IOException;
        //  154    163    166    170    Ljava/io/IOException;
        //  160    205    205    209    Ljava/io/IOException;
        //  289    299    302    306    Ljava/io/IOException;
        //  294    312    315    319    Ljava/io/IOException;
        //  306    337    340    344    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0306:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void createLeftOver() {
        final String b = ProxyInputStream.b();
        final int n = this.currentLastBytePos + 1;
        final String s = b;
        Label_0074: {
            Label_0058: {
                ReversedLinesFileReader$FilePart reversedLinesFileReader$FilePart = null;
                Label_0026: {
                    try {
                        if (s != null) {
                            break Label_0058;
                        }
                        final int n2 = n;
                        if (n2 > 0) {
                            break Label_0026;
                        }
                        break Label_0058;
                    }
                    catch (IllegalStateException ex) {
                        throw b(ex);
                    }
                    try {
                        final int n2 = n;
                        if (n2 <= 0) {
                            break Label_0058;
                        }
                        this.leftOver = new byte[n];
                        reversedLinesFileReader$FilePart = this;
                    }
                    catch (IllegalStateException ex2) {
                        throw b(ex2);
                    }
                }
                while (true) {
                    q.st(reversedLinesFileReader$FilePart.data, 0, this.leftOver, 0, n);
                    try {
                        if (s == null) {
                            break Label_0074;
                        }
                        reversedLinesFileReader$FilePart = this;
                        if (s != null) {
                            continue;
                        }
                    }
                    catch (IllegalStateException ex3) {
                        throw b(ex3);
                    }
                    break;
                }
            }
            this.leftOver = null;
        }
        this.currentLastBytePos = -1;
    }
    
    private int getNewLineMatchByteCount(final byte[] p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        org/apache/commons/io/input/ReversedLinesFileReader$FilePart.this$0:Lorg/apache/commons/io/input/ReversedLinesFileReader;
        //     4: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.access$800:(Lorg/apache/commons/io/input/ReversedLinesFileReader;)[[B
        //     7: astore          4
        //     9: aload           4
        //    11: arraylength    
        //    12: istore          5
        //    14: invokestatic    org/apache/commons/io/input/ProxyInputStream.b:()Ljava/lang/String;
        //    17: iconst_0       
        //    18: istore          6
        //    20: astore_3       
        //    21: iload           6
        //    23: iload           5
        //    25: if_icmpge       207
        //    28: aload           4
        //    30: iload           6
        //    32: aaload         
        //    33: astore          7
        //    35: iconst_1       
        //    36: istore          8
        //    38: aload           7
        //    40: arraylength    
        //    41: iconst_1       
        //    42: isub           
        //    43: aload_3        
        //    44: ifnonnull       208
        //    47: istore          9
        //    49: iload           9
        //    51: iflt            162
        //    54: iload_2        
        //    55: iload           9
        //    57: iadd           
        //    58: aload           7
        //    60: arraylength    
        //    61: iconst_1       
        //    62: isub           
        //    63: isub           
        //    64: istore          10
        //    66: iload           8
        //    68: iload           10
        //    70: aload_3        
        //    71: ifnonnull       25
        //    74: aload_3        
        //    75: ifnonnull       110
        //    78: aload_3        
        //    79: ifnonnull       114
        //    82: goto            89
        //    85: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    88: athrow         
        //    89: iflt            151
        //    92: goto            99
        //    95: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    98: athrow         
        //    99: aload_1        
        //   100: iload           10
        //   102: baload         
        //   103: goto            110
        //   106: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   109: athrow         
        //   110: aload_3        
        //   111: ifnonnull       148
        //   114: aload_3        
        //   115: ifnonnull       148
        //   118: goto            125
        //   121: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   124: athrow         
        //   125: aload           7
        //   127: iload           9
        //   129: baload         
        //   130: if_icmpne       151
        //   133: goto            140
        //   136: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   139: athrow         
        //   140: iconst_1       
        //   141: goto            148
        //   144: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   147: athrow         
        //   148: goto            152
        //   151: iconst_0       
        //   152: iand           
        //   153: istore          8
        //   155: iinc            9, -1
        //   158: aload_3        
        //   159: ifnull          49
        //   162: iload           8
        //   164: aload_3        
        //   165: ifnonnull       199
        //   168: aload_3        
        //   169: ifnonnull       199
        //   172: goto            179
        //   175: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   178: athrow         
        //   179: ifeq            200
        //   182: goto            189
        //   185: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   188: athrow         
        //   189: aload           7
        //   191: arraylength    
        //   192: goto            199
        //   195: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   198: athrow         
        //   199: ireturn        
        //   200: iinc            6, 1
        //   203: aload_3        
        //   204: ifnull          21
        //   207: iconst_0       
        //   208: ireturn        
        //    StackMapTable: 00 1C FF 00 15 00 07 07 00 02 07 00 24 01 07 00 26 07 00 7B 01 01 00 00 FF 00 03 00 07 07 00 02 07 00 24 01 07 00 26 07 00 7B 01 01 00 02 01 01 FE 00 17 07 00 24 01 01 FF 00 23 00 0B 07 00 02 07 00 24 01 07 00 26 07 00 7B 01 01 07 00 24 01 01 01 00 01 07 00 3F FF 00 03 00 0B 07 00 02 07 00 24 01 07 00 26 07 00 7B 01 01 07 00 24 01 01 01 00 02 01 01 45 07 00 3F 43 01 46 07 00 3F FF 00 03 00 0B 07 00 02 07 00 24 01 07 00 26 07 00 7B 01 01 07 00 24 01 01 01 00 02 01 01 FF 00 03 00 0B 07 00 02 07 00 24 01 07 00 26 07 00 7B 01 01 07 00 24 01 01 01 00 02 01 01 46 07 00 3F FF 00 03 00 0B 07 00 02 07 00 24 01 07 00 26 07 00 7B 01 01 07 00 24 01 01 01 00 02 01 01 4A 07 00 3F 43 01 43 07 00 3F FF 00 03 00 0B 07 00 02 07 00 24 01 07 00 26 07 00 7B 01 01 07 00 24 01 01 01 00 02 01 01 42 01 FF 00 00 00 0B 07 00 02 07 00 24 01 07 00 26 07 00 7B 01 01 07 00 24 01 01 01 00 02 01 01 FA 00 09 4C 07 00 3F 43 01 45 07 00 3F 03 45 07 00 3F 43 01 00 F8 00 06 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  74     82     85     89     Ljava/lang/IllegalStateException;
        //  78     92     95     99     Ljava/lang/IllegalStateException;
        //  89     103    106    110    Ljava/lang/IllegalStateException;
        //  110    118    121    125    Ljava/lang/IllegalStateException;
        //  114    133    136    140    Ljava/lang/IllegalStateException;
        //  125    141    144    148    Ljava/lang/IllegalStateException;
        //  162    172    175    179    Ljava/lang/IllegalStateException;
        //  168    182    185    189    Ljava/lang/IllegalStateException;
        //  179    192    195    199    Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0089:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    ReversedLinesFileReader$FilePart(final ReversedLinesFileReader reversedLinesFileReader, final long n, final int n2, final byte[] array, final ReversedLinesFileReader$1 reversedLinesFileReader$1) throws IOException {
        this(reversedLinesFileReader, n, n2, array);
    }
    
    static String access$100(final ReversedLinesFileReader$FilePart reversedLinesFileReader$FilePart) throws IOException {
        return reversedLinesFileReader$FilePart.readLine();
    }
    
    static ReversedLinesFileReader$FilePart access$200(final ReversedLinesFileReader$FilePart reversedLinesFileReader$FilePart) throws IOException {
        return reversedLinesFileReader$FilePart.rollOver();
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    static {
        final String[] a2 = new String[4];
        int n = 0;
        String s;
        int n2 = q.q(s = n.d.a.d.q.qj());
        int n3 = 60;
        int n4 = -1;
    Label_0023:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 120));
                ++n4;
                final String s2 = s;
                final int n9 = n4;
                String s3 = q.h(s2, n9, n9 + n3);
                int n10 = -1;
                while (true) {
                    final char[] g = q.g(s3);
                    final int length = g.length;
                    int n11 = 0;
                    while (true) {
                        Label_0260: {
                            if (length > 1) {
                                break Label_0260;
                            }
                            n7 = (n6 = n11);
                            do {
                                final char c = g[n6];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 48;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 99;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 49;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 44;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 49;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 123;
                                        break;
                                    }
                                    default: {
                                        n12 = 98;
                                        break;
                                    }
                                }
                                g[n7] = (char)(c ^ (n5 ^ n12));
                                ++n11;
                            } while (n8 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.z(new String(g));
                    switch (n10) {
                        default: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                continue Label_0023;
                            }
                            n2 = q.q(s = n.d.a.d.q.qg());
                            n3 = 62;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                break;
                            }
                            break Label_0023;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 84)));
                    ++n4;
                    final String s4 = s;
                    final int n13 = n4;
                    s3 = q.h(s4, n13, n13 + n3);
                    n10 = 0;
                }
            }
            break;
        }
        a = a2;
        b = new String[4];
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0x54CA) & 0xFFFF;
        if (ReversedLinesFileReader$FilePart.b[n3] == null) {
            final char[] g = q.g(ReversedLinesFileReader$FilePart.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 195;
                    break;
                }
                case 1: {
                    n4 = 129;
                    break;
                }
                case 2: {
                    n4 = 122;
                    break;
                }
                case 3: {
                    n4 = 16;
                    break;
                }
                case 4: {
                    n4 = 68;
                    break;
                }
                case 5: {
                    n4 = 97;
                    break;
                }
                case 6: {
                    n4 = 176;
                    break;
                }
                case 7: {
                    n4 = 14;
                    break;
                }
                case 8: {
                    n4 = 229;
                    break;
                }
                case 9: {
                    n4 = 130;
                    break;
                }
                case 10: {
                    n4 = 242;
                    break;
                }
                case 11: {
                    n4 = 219;
                    break;
                }
                case 12: {
                    n4 = 114;
                    break;
                }
                case 13: {
                    n4 = 251;
                    break;
                }
                case 14: {
                    n4 = 73;
                    break;
                }
                case 15: {
                    n4 = 137;
                    break;
                }
                case 16: {
                    n4 = 111;
                    break;
                }
                case 17: {
                    n4 = 40;
                    break;
                }
                case 18: {
                    n4 = 56;
                    break;
                }
                case 19: {
                    n4 = 153;
                    break;
                }
                case 20: {
                    n4 = 171;
                    break;
                }
                case 21: {
                    n4 = 108;
                    break;
                }
                case 22: {
                    n4 = 11;
                    break;
                }
                case 23: {
                    n4 = 203;
                    break;
                }
                case 24: {
                    n4 = 32;
                    break;
                }
                case 25: {
                    n4 = 44;
                    break;
                }
                case 26: {
                    n4 = 79;
                    break;
                }
                case 27: {
                    n4 = 178;
                    break;
                }
                case 28: {
                    n4 = 225;
                    break;
                }
                case 29: {
                    n4 = 152;
                    break;
                }
                case 30: {
                    n4 = 192;
                    break;
                }
                case 31: {
                    n4 = 76;
                    break;
                }
                case 32: {
                    n4 = 34;
                    break;
                }
                case 33: {
                    n4 = 157;
                    break;
                }
                case 34: {
                    n4 = 148;
                    break;
                }
                case 35: {
                    n4 = 164;
                    break;
                }
                case 36: {
                    n4 = 221;
                    break;
                }
                case 37: {
                    n4 = 227;
                    break;
                }
                case 38: {
                    n4 = 123;
                    break;
                }
                case 39: {
                    n4 = 201;
                    break;
                }
                case 40: {
                    n4 = 27;
                    break;
                }
                case 41: {
                    n4 = 254;
                    break;
                }
                case 42: {
                    n4 = 198;
                    break;
                }
                case 43: {
                    n4 = 199;
                    break;
                }
                case 44: {
                    n4 = 113;
                    break;
                }
                case 45: {
                    n4 = 65;
                    break;
                }
                case 46: {
                    n4 = 67;
                    break;
                }
                case 47: {
                    n4 = 166;
                    break;
                }
                case 48: {
                    n4 = 2;
                    break;
                }
                case 49: {
                    n4 = 231;
                    break;
                }
                case 50: {
                    n4 = 234;
                    break;
                }
                case 51: {
                    n4 = 216;
                    break;
                }
                case 52: {
                    n4 = 1;
                    break;
                }
                case 53: {
                    n4 = 142;
                    break;
                }
                case 54: {
                    n4 = 80;
                    break;
                }
                case 55: {
                    n4 = 138;
                    break;
                }
                case 56: {
                    n4 = 107;
                    break;
                }
                case 57: {
                    n4 = 121;
                    break;
                }
                case 58: {
                    n4 = 50;
                    break;
                }
                case 59: {
                    n4 = 59;
                    break;
                }
                case 60: {
                    n4 = 184;
                    break;
                }
                case 61: {
                    n4 = 155;
                    break;
                }
                case 62: {
                    n4 = 88;
                    break;
                }
                case 63: {
                    n4 = 187;
                    break;
                }
                case 64: {
                    n4 = 223;
                    break;
                }
                case 65: {
                    n4 = 69;
                    break;
                }
                case 66: {
                    n4 = 109;
                    break;
                }
                case 67: {
                    n4 = 183;
                    break;
                }
                case 68: {
                    n4 = 213;
                    break;
                }
                case 69: {
                    n4 = 10;
                    break;
                }
                case 70: {
                    n4 = 115;
                    break;
                }
                case 71: {
                    n4 = 208;
                    break;
                }
                case 72: {
                    n4 = 173;
                    break;
                }
                case 73: {
                    n4 = 172;
                    break;
                }
                case 74: {
                    n4 = 193;
                    break;
                }
                case 75: {
                    n4 = 238;
                    break;
                }
                case 76: {
                    n4 = 161;
                    break;
                }
                case 77: {
                    n4 = 3;
                    break;
                }
                case 78: {
                    n4 = 128;
                    break;
                }
                case 79: {
                    n4 = 131;
                    break;
                }
                case 80: {
                    n4 = 226;
                    break;
                }
                case 81: {
                    n4 = 245;
                    break;
                }
                case 82: {
                    n4 = 182;
                    break;
                }
                case 83: {
                    n4 = 9;
                    break;
                }
                case 84: {
                    n4 = 255;
                    break;
                }
                case 85: {
                    n4 = 102;
                    break;
                }
                case 86: {
                    n4 = 90;
                    break;
                }
                case 87: {
                    n4 = 174;
                    break;
                }
                case 88: {
                    n4 = 215;
                    break;
                }
                case 89: {
                    n4 = 103;
                    break;
                }
                case 90: {
                    n4 = 95;
                    break;
                }
                case 91: {
                    n4 = 30;
                    break;
                }
                case 92: {
                    n4 = 177;
                    break;
                }
                case 93: {
                    n4 = 24;
                    break;
                }
                case 94: {
                    n4 = 239;
                    break;
                }
                case 95: {
                    n4 = 140;
                    break;
                }
                case 96: {
                    n4 = 146;
                    break;
                }
                case 97: {
                    n4 = 230;
                    break;
                }
                case 98: {
                    n4 = 17;
                    break;
                }
                case 99: {
                    n4 = 78;
                    break;
                }
                case 100: {
                    n4 = 82;
                    break;
                }
                case 101: {
                    n4 = 233;
                    break;
                }
                case 102: {
                    n4 = 106;
                    break;
                }
                case 103: {
                    n4 = 22;
                    break;
                }
                case 104: {
                    n4 = 85;
                    break;
                }
                case 105: {
                    n4 = 168;
                    break;
                }
                case 106: {
                    n4 = 43;
                    break;
                }
                case 107: {
                    n4 = 117;
                    break;
                }
                case 108: {
                    n4 = 4;
                    break;
                }
                case 109: {
                    n4 = 170;
                    break;
                }
                case 110: {
                    n4 = 240;
                    break;
                }
                case 111: {
                    n4 = 81;
                    break;
                }
                case 112: {
                    n4 = 247;
                    break;
                }
                case 113: {
                    n4 = 96;
                    break;
                }
                case 114: {
                    n4 = 206;
                    break;
                }
                case 115: {
                    n4 = 91;
                    break;
                }
                case 116: {
                    n4 = 112;
                    break;
                }
                case 117: {
                    n4 = 189;
                    break;
                }
                case 118: {
                    n4 = 145;
                    break;
                }
                case 119: {
                    n4 = 8;
                    break;
                }
                case 120: {
                    n4 = 48;
                    break;
                }
                case 121: {
                    n4 = 84;
                    break;
                }
                case 122: {
                    n4 = 248;
                    break;
                }
                case 123: {
                    n4 = 191;
                    break;
                }
                case 124: {
                    n4 = 135;
                    break;
                }
                case 125: {
                    n4 = 147;
                    break;
                }
                case 126: {
                    n4 = 100;
                    break;
                }
                case 127: {
                    n4 = 20;
                    break;
                }
                case 128: {
                    n4 = 13;
                    break;
                }
                case 129: {
                    n4 = 190;
                    break;
                }
                case 130: {
                    n4 = 197;
                    break;
                }
                case 131: {
                    n4 = 151;
                    break;
                }
                case 132: {
                    n4 = 52;
                    break;
                }
                case 133: {
                    n4 = 217;
                    break;
                }
                case 134: {
                    n4 = 204;
                    break;
                }
                case 135: {
                    n4 = 46;
                    break;
                }
                case 136: {
                    n4 = 141;
                    break;
                }
                case 137: {
                    n4 = 124;
                    break;
                }
                case 138: {
                    n4 = 232;
                    break;
                }
                case 139: {
                    n4 = 12;
                    break;
                }
                case 140: {
                    n4 = 194;
                    break;
                }
                case 141: {
                    n4 = 66;
                    break;
                }
                case 142: {
                    n4 = 209;
                    break;
                }
                case 143: {
                    n4 = 45;
                    break;
                }
                case 144: {
                    n4 = 36;
                    break;
                }
                case 145: {
                    n4 = 150;
                    break;
                }
                case 146: {
                    n4 = 33;
                    break;
                }
                case 147: {
                    n4 = 87;
                    break;
                }
                case 148: {
                    n4 = 77;
                    break;
                }
                case 149: {
                    n4 = 42;
                    break;
                }
                case 150: {
                    n4 = 220;
                    break;
                }
                case 151: {
                    n4 = 149;
                    break;
                }
                case 152: {
                    n4 = 235;
                    break;
                }
                case 153: {
                    n4 = 218;
                    break;
                }
                case 154: {
                    n4 = 214;
                    break;
                }
                case 155: {
                    n4 = 5;
                    break;
                }
                case 156: {
                    n4 = 38;
                    break;
                }
                case 157: {
                    n4 = 18;
                    break;
                }
                case 158: {
                    n4 = 244;
                    break;
                }
                case 159: {
                    n4 = 25;
                    break;
                }
                case 160: {
                    n4 = 47;
                    break;
                }
                case 161: {
                    n4 = 158;
                    break;
                }
                case 162: {
                    n4 = 49;
                    break;
                }
                case 163: {
                    n4 = 125;
                    break;
                }
                case 164: {
                    n4 = 98;
                    break;
                }
                case 165: {
                    n4 = 144;
                    break;
                }
                case 166: {
                    n4 = 104;
                    break;
                }
                case 167: {
                    n4 = 35;
                    break;
                }
                case 168: {
                    n4 = 54;
                    break;
                }
                case 169: {
                    n4 = 243;
                    break;
                }
                case 170: {
                    n4 = 0;
                    break;
                }
                case 171: {
                    n4 = 200;
                    break;
                }
                case 172: {
                    n4 = 99;
                    break;
                }
                case 173: {
                    n4 = 118;
                    break;
                }
                case 174: {
                    n4 = 136;
                    break;
                }
                case 175: {
                    n4 = 120;
                    break;
                }
                case 176: {
                    n4 = 134;
                    break;
                }
                case 177: {
                    n4 = 196;
                    break;
                }
                case 178: {
                    n4 = 139;
                    break;
                }
                case 179: {
                    n4 = 64;
                    break;
                }
                case 180: {
                    n4 = 154;
                    break;
                }
                case 181: {
                    n4 = 252;
                    break;
                }
                case 182: {
                    n4 = 23;
                    break;
                }
                case 183: {
                    n4 = 101;
                    break;
                }
                case 184: {
                    n4 = 237;
                    break;
                }
                case 185: {
                    n4 = 31;
                    break;
                }
                case 186: {
                    n4 = 202;
                    break;
                }
                case 187: {
                    n4 = 228;
                    break;
                }
                case 188: {
                    n4 = 89;
                    break;
                }
                case 189: {
                    n4 = 156;
                    break;
                }
                case 190: {
                    n4 = 53;
                    break;
                }
                case 191: {
                    n4 = 181;
                    break;
                }
                case 192: {
                    n4 = 19;
                    break;
                }
                case 193: {
                    n4 = 241;
                    break;
                }
                case 194: {
                    n4 = 119;
                    break;
                }
                case 195: {
                    n4 = 224;
                    break;
                }
                case 196: {
                    n4 = 211;
                    break;
                }
                case 197: {
                    n4 = 51;
                    break;
                }
                case 198: {
                    n4 = 185;
                    break;
                }
                case 199: {
                    n4 = 41;
                    break;
                }
                case 200: {
                    n4 = 169;
                    break;
                }
                case 201: {
                    n4 = 21;
                    break;
                }
                case 202: {
                    n4 = 167;
                    break;
                }
                case 203: {
                    n4 = 116;
                    break;
                }
                case 204: {
                    n4 = 205;
                    break;
                }
                case 205: {
                    n4 = 58;
                    break;
                }
                case 206: {
                    n4 = 63;
                    break;
                }
                case 207: {
                    n4 = 212;
                    break;
                }
                case 208: {
                    n4 = 15;
                    break;
                }
                case 209: {
                    n4 = 186;
                    break;
                }
                case 210: {
                    n4 = 163;
                    break;
                }
                case 211: {
                    n4 = 207;
                    break;
                }
                case 212: {
                    n4 = 110;
                    break;
                }
                case 213: {
                    n4 = 159;
                    break;
                }
                case 214: {
                    n4 = 93;
                    break;
                }
                case 215: {
                    n4 = 28;
                    break;
                }
                case 216: {
                    n4 = 180;
                    break;
                }
                case 217: {
                    n4 = 236;
                    break;
                }
                case 218: {
                    n4 = 132;
                    break;
                }
                case 219: {
                    n4 = 62;
                    break;
                }
                case 220: {
                    n4 = 127;
                    break;
                }
                case 221: {
                    n4 = 105;
                    break;
                }
                case 222: {
                    n4 = 37;
                    break;
                }
                case 223: {
                    n4 = 162;
                    break;
                }
                case 224: {
                    n4 = 143;
                    break;
                }
                case 225: {
                    n4 = 179;
                    break;
                }
                case 226: {
                    n4 = 249;
                    break;
                }
                case 227: {
                    n4 = 57;
                    break;
                }
                case 228: {
                    n4 = 222;
                    break;
                }
                case 229: {
                    n4 = 60;
                    break;
                }
                case 230: {
                    n4 = 94;
                    break;
                }
                case 231: {
                    n4 = 92;
                    break;
                }
                case 232: {
                    n4 = 39;
                    break;
                }
                case 233: {
                    n4 = 75;
                    break;
                }
                case 234: {
                    n4 = 26;
                    break;
                }
                case 235: {
                    n4 = 165;
                    break;
                }
                case 236: {
                    n4 = 7;
                    break;
                }
                case 237: {
                    n4 = 210;
                    break;
                }
                case 238: {
                    n4 = 188;
                    break;
                }
                case 239: {
                    n4 = 29;
                    break;
                }
                case 240: {
                    n4 = 246;
                    break;
                }
                case 241: {
                    n4 = 83;
                    break;
                }
                case 242: {
                    n4 = 126;
                    break;
                }
                case 243: {
                    n4 = 6;
                    break;
                }
                case 244: {
                    n4 = 71;
                    break;
                }
                case 245: {
                    n4 = 253;
                    break;
                }
                case 246: {
                    n4 = 72;
                    break;
                }
                case 247: {
                    n4 = 70;
                    break;
                }
                case 248: {
                    n4 = 160;
                    break;
                }
                case 249: {
                    n4 = 86;
                    break;
                }
                case 250: {
                    n4 = 133;
                    break;
                }
                case 251: {
                    n4 = 175;
                    break;
                }
                case 252: {
                    n4 = 61;
                    break;
                }
                case 253: {
                    n4 = 55;
                    break;
                }
                case 254: {
                    n4 = 74;
                    break;
                }
                default: {
                    n4 = 250;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            ReversedLinesFileReader$FilePart.b[n3] = q.z(new String(g));
        }
        return ReversedLinesFileReader$FilePart.b[n3];
    }
}
