// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import java.io.IOException;
import java.io.RandomAccessFile;
import q.o.m.s.q;
import java.io.File;
import java.nio.charset.Charset;

public class Tailer implements Runnable
{
    private static final int DEFAULT_DELAY_MILLIS = 1000;
    private static final String RAF_MODE = "r";
    private static final int DEFAULT_BUFSIZE = 4096;
    private static final Charset DEFAULT_CHARSET;
    private final byte[] inbuf;
    private final File file;
    private final Charset cset;
    private final long delayMillis;
    private final boolean end;
    private final TailerListener listener;
    private final boolean reOpen;
    private volatile boolean run;
    
    public Tailer(final File file, final TailerListener tailerListener) {
        this(file, tailerListener, 1000L);
    }
    
    public Tailer(final File file, final TailerListener tailerListener, final long n) {
        this(file, tailerListener, n, false);
    }
    
    public Tailer(final File file, final TailerListener tailerListener, final long n, final boolean b) {
        this(file, tailerListener, n, b, 4096);
    }
    
    public Tailer(final File file, final TailerListener tailerListener, final long n, final boolean b, final boolean b2) {
        this(file, tailerListener, n, b, b2, 4096);
    }
    
    public Tailer(final File file, final TailerListener tailerListener, final long n, final boolean b, final int n2) {
        this(file, tailerListener, n, b, false, n2);
    }
    
    public Tailer(final File file, final TailerListener tailerListener, final long n, final boolean b, final boolean b2, final int n2) {
        this(file, Tailer.DEFAULT_CHARSET, tailerListener, n, b, b2, n2);
    }
    
    public Tailer(final File file, final Charset cset, final TailerListener listener, final long delayMillis, final boolean end, final boolean reOpen, final int n) {
        this.run = true;
        this.file = file;
        this.delayMillis = delayMillis;
        this.end = end;
        this.inbuf = new byte[n];
        (this.listener = listener).init(this);
        this.reOpen = reOpen;
        this.cset = cset;
    }
    
    public static Tailer create(final File file, final TailerListener tailerListener, final long n, final boolean b, final int n2) {
        return create(file, tailerListener, n, b, false, n2);
    }
    
    public static Tailer create(final File file, final TailerListener tailerListener, final long n, final boolean b, final boolean b2, final int n2) {
        return create(file, Tailer.DEFAULT_CHARSET, tailerListener, n, b, b2, n2);
    }
    
    public static Tailer create(final File file, final Charset charset, final TailerListener tailerListener, final long n, final boolean b, final boolean b2, final int n2) {
        final Tailer target = new Tailer(file, charset, tailerListener, n, b, b2, n2);
        final Thread thread = new Thread(target);
        q.ct(thread, true);
        q.rn(thread);
        return target;
    }
    
    public static Tailer create(final File file, final TailerListener tailerListener, final long n, final boolean b) {
        return create(file, tailerListener, n, b, 4096);
    }
    
    public static Tailer create(final File file, final TailerListener tailerListener, final long n, final boolean b, final boolean b2) {
        return create(file, tailerListener, n, b, b2, 4096);
    }
    
    public static Tailer create(final File file, final TailerListener tailerListener, final long n) {
        return create(file, tailerListener, n, false);
    }
    
    public static Tailer create(final File file, final TailerListener tailerListener) {
        return create(file, tailerListener, 1000L, false);
    }
    
    public File getFile() {
        return this.file;
    }
    
    protected boolean getRun() {
        return this.run;
    }
    
    public long getDelay() {
        return this.delayMillis;
    }
    
    @Override
    public void run() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aconst_null    
        //     4: astore_2       
        //     5: astore_1       
        //     6: lconst_0       
        //     7: lstore_3       
        //     8: lconst_0       
        //     9: lstore          5
        //    11: aload_0        
        //    12: invokevirtual   org/apache/commons/io/input/Tailer.getRun:()Z
        //    15: ifeq            177
        //    18: aload_2        
        //    19: aload_1        
        //    20: ifnonnull       532
        //    23: aload_1        
        //    24: ifnonnull       69
        //    27: goto            34
        //    30: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    33: athrow         
        //    34: aload_1        
        //    35: ifnonnull       69
        //    38: goto            45
        //    41: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    44: athrow         
        //    45: ifnonnull       177
        //    48: goto            55
        //    51: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    54: athrow         
        //    55: new             Ljava/io/RandomAccessFile;
        //    58: dup            
        //    59: aload_0        
        //    60: getfield        org/apache/commons/io/input/Tailer.file:Ljava/io/File;
        //    63: invokestatic    n/d/a/d/q.oj:()Ljava/lang/String;
        //    66: invokespecial   java/io/RandomAccessFile.<init>:(Ljava/io/File;Ljava/lang/String;)V
        //    69: astore_2       
        //    70: goto            84
        //    73: astore          7
        //    75: aload_0        
        //    76: getfield        org/apache/commons/io/input/Tailer.listener:Lorg/apache/commons/io/input/TailerListener;
        //    79: invokeinterface org/apache/commons/io/input/TailerListener.fileNotFound:()V
        //    84: aload_2        
        //    85: ifnonnull       106
        //    88: aload_0        
        //    89: goto            96
        //    92: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    95: athrow         
        //    96: getfield        org/apache/commons/io/input/Tailer.delayMillis:J
        //    99: invokestatic    q/o/m/s/q.mt:(J)V
        //   102: aload_1        
        //   103: ifnull          11
        //   106: aload_0        
        //   107: aload_1        
        //   108: ifnonnull       96
        //   111: aload_1        
        //   112: ifnonnull       147
        //   115: aload_1        
        //   116: ifnonnull       147
        //   119: goto            126
        //   122: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   125: athrow         
        //   126: getfield        org/apache/commons/io/input/Tailer.end:Z
        //   129: ifeq            156
        //   132: goto            139
        //   135: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   138: athrow         
        //   139: aload_0        
        //   140: goto            147
        //   143: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   146: athrow         
        //   147: getfield        org/apache/commons/io/input/Tailer.file:Ljava/io/File;
        //   150: invokestatic    q/o/m/s/q.eb:(Ljava/io/File;)J
        //   153: goto            157
        //   156: lconst_0       
        //   157: lstore          5
        //   159: aload_0        
        //   160: getfield        org/apache/commons/io/input/Tailer.file:Ljava/io/File;
        //   163: invokestatic    q/o/m/s/q.nj:(Ljava/io/File;)J
        //   166: lstore_3       
        //   167: aload_2        
        //   168: lload           5
        //   170: invokestatic    q/o/m/s/q.cb:(Ljava/io/RandomAccessFile;J)V
        //   173: aload_1        
        //   174: ifnull          11
        //   177: aload_0        
        //   178: invokevirtual   org/apache/commons/io/input/Tailer.getRun:()Z
        //   181: ifeq            531
        //   184: aload_0        
        //   185: getfield        org/apache/commons/io/input/Tailer.file:Ljava/io/File;
        //   188: lload_3        
        //   189: invokestatic    org/apache/commons/io/FileUtils.isFileNewer:(Ljava/io/File;J)Z
        //   192: istore          7
        //   194: aload_0        
        //   195: getfield        org/apache/commons/io/input/Tailer.file:Ljava/io/File;
        //   198: invokestatic    q/o/m/s/q.eb:(Ljava/io/File;)J
        //   201: lstore          8
        //   203: aload_1        
        //   204: ifnonnull       535
        //   207: aload_1        
        //   208: ifnonnull       260
        //   211: goto            218
        //   214: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   217: athrow         
        //   218: lload           8
        //   220: lload           5
        //   222: lcmp           
        //   223: aload_1        
        //   224: ifnonnull       343
        //   227: goto            234
        //   230: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   233: athrow         
        //   234: ifge            327
        //   237: goto            244
        //   240: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   243: athrow         
        //   244: aload_0        
        //   245: getfield        org/apache/commons/io/input/Tailer.listener:Lorg/apache/commons/io/input/TailerListener;
        //   248: invokeinterface org/apache/commons/io/input/TailerListener.fileRotated:()V
        //   253: goto            260
        //   256: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   259: athrow         
        //   260: aload_2        
        //   261: astore          10
        //   263: new             Ljava/io/RandomAccessFile;
        //   266: dup            
        //   267: aload_0        
        //   268: getfield        org/apache/commons/io/input/Tailer.file:Ljava/io/File;
        //   271: invokestatic    n/d/a/d/q.oj:()Ljava/lang/String;
        //   274: invokespecial   java/io/RandomAccessFile.<init>:(Ljava/io/File;Ljava/lang/String;)V
        //   277: astore_2       
        //   278: aload_0        
        //   279: aload           10
        //   281: invokespecial   org/apache/commons/io/input/Tailer.readLines:(Ljava/io/RandomAccessFile;)J
        //   284: pop2           
        //   285: goto            301
        //   288: astore          11
        //   290: aload_0        
        //   291: getfield        org/apache/commons/io/input/Tailer.listener:Lorg/apache/commons/io/input/TailerListener;
        //   294: aload           11
        //   296: invokeinterface org/apache/commons/io/input/TailerListener.handle:(Ljava/lang/Exception;)V
        //   301: lconst_0       
        //   302: lstore          5
        //   304: aload           10
        //   306: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/Closeable;)V
        //   309: goto            177
        //   312: astore          10
        //   314: aload_0        
        //   315: getfield        org/apache/commons/io/input/Tailer.listener:Lorg/apache/commons/io/input/TailerListener;
        //   318: invokeinterface org/apache/commons/io/input/TailerListener.fileNotFound:()V
        //   323: aload_1        
        //   324: ifnull          177
        //   327: lload           8
        //   329: aload_1        
        //   330: ifnonnull       371
        //   333: lload           5
        //   335: lcmp           
        //   336: goto            343
        //   339: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   342: athrow         
        //   343: aload_1        
        //   344: ifnonnull       385
        //   347: ifle            376
        //   350: goto            357
        //   353: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   356: athrow         
        //   357: aload_0        
        //   358: aload_2        
        //   359: invokespecial   org/apache/commons/io/input/Tailer.readLines:(Ljava/io/RandomAccessFile;)J
        //   362: lstore          5
        //   364: aload_0        
        //   365: getfield        org/apache/commons/io/input/Tailer.file:Ljava/io/File;
        //   368: invokestatic    q/o/m/s/q.nj:(Ljava/io/File;)J
        //   371: lstore_3       
        //   372: aload_1        
        //   373: ifnull          423
        //   376: iload           7
        //   378: goto            385
        //   381: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   384: athrow         
        //   385: aload_1        
        //   386: ifnonnull       431
        //   389: ifeq            423
        //   392: goto            399
        //   395: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   398: athrow         
        //   399: lconst_0       
        //   400: lstore          5
        //   402: aload_2        
        //   403: lload           5
        //   405: invokestatic    q/o/m/s/q.cb:(Ljava/io/RandomAccessFile;J)V
        //   408: aload_0        
        //   409: aload_2        
        //   410: invokespecial   org/apache/commons/io/input/Tailer.readLines:(Ljava/io/RandomAccessFile;)J
        //   413: lstore          5
        //   415: aload_0        
        //   416: getfield        org/apache/commons/io/input/Tailer.file:Ljava/io/File;
        //   419: invokestatic    q/o/m/s/q.nj:(Ljava/io/File;)J
        //   422: lstore_3       
        //   423: aload_0        
        //   424: aload_1        
        //   425: ifnonnull       416
        //   428: getfield        org/apache/commons/io/input/Tailer.reOpen:Z
        //   431: aload_1        
        //   432: ifnonnull       471
        //   435: ifeq            456
        //   438: goto            445
        //   441: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   444: athrow         
        //   445: aload_2        
        //   446: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/Closeable;)V
        //   449: goto            456
        //   452: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   455: athrow         
        //   456: aload_0        
        //   457: getfield        org/apache/commons/io/input/Tailer.delayMillis:J
        //   460: invokestatic    q/o/m/s/q.mt:(J)V
        //   463: aload_0        
        //   464: invokevirtual   org/apache/commons/io/input/Tailer.getRun:()Z
        //   467: aload_1        
        //   468: ifnonnull       503
        //   471: aload_1        
        //   472: ifnonnull       503
        //   475: goto            482
        //   478: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   481: athrow         
        //   482: ifeq            527
        //   485: goto            492
        //   488: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   491: athrow         
        //   492: aload_0        
        //   493: getfield        org/apache/commons/io/input/Tailer.reOpen:Z
        //   496: goto            503
        //   499: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   502: athrow         
        //   503: ifeq            527
        //   506: new             Ljava/io/RandomAccessFile;
        //   509: dup            
        //   510: aload_0        
        //   511: getfield        org/apache/commons/io/input/Tailer.file:Ljava/io/File;
        //   514: invokestatic    n/d/a/d/q.oj:()Ljava/lang/String;
        //   517: invokespecial   java/io/RandomAccessFile.<init>:(Ljava/io/File;Ljava/lang/String;)V
        //   520: astore_2       
        //   521: aload_2        
        //   522: lload           5
        //   524: invokestatic    q/o/m/s/q.cb:(Ljava/io/RandomAccessFile;J)V
        //   527: aload_1        
        //   528: ifnull          177
        //   531: aload_2        
        //   532: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/Closeable;)V
        //   535: goto            579
        //   538: astore_3       
        //   539: invokestatic    q/o/m/s/q.ni:()Ljava/lang/Thread;
        //   542: invokestatic    q/o/m/s/q.ky:(Ljava/lang/Thread;)V
        //   545: aload_0        
        //   546: aload_3        
        //   547: invokespecial   org/apache/commons/io/input/Tailer.stop:(Ljava/lang/Exception;)V
        //   550: aload_2        
        //   551: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/Closeable;)V
        //   554: goto            579
        //   557: astore_3       
        //   558: aload_0        
        //   559: aload_3        
        //   560: invokespecial   org/apache/commons/io/input/Tailer.stop:(Ljava/lang/Exception;)V
        //   563: aload_2        
        //   564: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/Closeable;)V
        //   567: goto            579
        //   570: astore          12
        //   572: aload_2        
        //   573: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/Closeable;)V
        //   576: aload           12
        //   578: athrow         
        //   579: return         
        //    StackMapTable: 00 42 FF 00 0B 00 05 07 00 02 07 00 83 07 00 85 04 04 00 00 52 07 00 75 43 07 00 85 46 07 00 75 43 07 00 85 45 07 00 75 03 4D 07 00 85 43 07 00 75 0A 47 07 00 75 43 07 00 02 09 4F 07 00 75 43 07 00 02 48 07 00 75 03 43 07 00 75 43 07 00 02 08 40 04 13 FF 00 24 00 07 07 00 02 07 00 83 07 00 85 04 04 01 04 00 01 07 00 75 03 4B 07 00 75 43 01 45 07 00 75 03 4B 07 00 75 03 FF 00 1B 00 08 07 00 02 07 00 83 07 00 85 04 04 01 04 07 00 85 00 01 07 00 77 0C FF 00 0A 00 07 07 00 02 07 00 83 07 00 85 04 04 01 04 00 01 07 00 75 0E 4B 07 00 75 43 01 49 07 00 75 03 4D 04 04 44 07 00 75 43 01 49 07 00 75 03 50 07 00 02 06 47 01 49 07 00 75 03 46 07 00 75 03 4E 01 46 07 00 75 43 01 45 07 00 75 03 46 07 00 75 43 01 17 F9 00 03 40 07 00 85 02 FF 00 02 00 03 07 00 02 07 00 83 07 00 85 00 01 07 00 79 52 07 00 7B 4C 07 00 C7 08
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  34     48     51     55     Ljava/io/FileNotFoundException;
        //  23     38     41     45     Ljava/io/FileNotFoundException;
        //  18     27     30     34     Ljava/io/FileNotFoundException;
        //  55     70     73     84     Ljava/io/FileNotFoundException;
        //  234    253    256    260    Ljava/io/FileNotFoundException;
        //  218    237    240    244    Ljava/io/FileNotFoundException;
        //  207    227    230    234    Ljava/io/FileNotFoundException;
        //  203    211    214    218    Ljava/io/FileNotFoundException;
        //  126    140    143    147    Ljava/io/FileNotFoundException;
        //  115    132    135    139    Ljava/io/FileNotFoundException;
        //  111    119    122    126    Ljava/io/FileNotFoundException;
        //  84     89     92     96     Ljava/io/FileNotFoundException;
        //  278    285    288    301    Ljava/io/IOException;
        //  260    309    312    327    Ljava/io/FileNotFoundException;
        //  482    496    499    503    Ljava/io/FileNotFoundException;
        //  471    485    488    492    Ljava/io/FileNotFoundException;
        //  456    475    478    482    Ljava/io/FileNotFoundException;
        //  435    449    452    456    Ljava/io/FileNotFoundException;
        //  431    438    441    445    Ljava/io/FileNotFoundException;
        //  385    392    395    399    Ljava/io/FileNotFoundException;
        //  372    378    381    385    Ljava/io/FileNotFoundException;
        //  343    350    353    357    Ljava/io/FileNotFoundException;
        //  327    336    339    343    Ljava/io/FileNotFoundException;
        //  6      531    538    557    Ljava/lang/InterruptedException;
        //  6      531    557    570    Ljava/lang/Exception;
        //  6      531    570    579    Any
        //  538    550    570    579    Any
        //  557    563    570    579    Any
        //  570    572    570    579    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0034:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void stop(final Exception ex) {
        this.listener.handle(ex);
        this.stop();
    }
    
    public void stop() {
        this.run = false;
    }
    
    private long readLines(final RandomAccessFile p0) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: bipush          64
        //     6: invokespecial   java/io/ByteArrayOutputStream.<init>:(I)V
        //     9: astore_3       
        //    10: invokestatic    org/apache/commons/io/input/ProxyInputStream.b:()Ljava/lang/String;
        //    13: aload_1        
        //    14: invokestatic    q/o/m/s/q.jf:(Ljava/io/RandomAccessFile;)J
        //    17: lstore          4
        //    19: lload           4
        //    21: lstore          6
        //    23: astore_2       
        //    24: iconst_0       
        //    25: istore          9
        //    27: aload_0        
        //    28: invokevirtual   org/apache/commons/io/input/Tailer.getRun:()Z
        //    31: ifeq            324
        //    34: aload_1        
        //    35: aload_0        
        //    36: getfield        org/apache/commons/io/input/Tailer.inbuf:[B
        //    39: invokestatic    q/o/m/s/q.cw:(Ljava/io/RandomAccessFile;[B)I
        //    42: dup            
        //    43: istore          8
        //    45: aload_2        
        //    46: ifnonnull       363
        //    49: aload_2        
        //    50: ifnonnull       90
        //    53: goto            60
        //    56: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    59: athrow         
        //    60: aload_2        
        //    61: ifnonnull       363
        //    64: goto            71
        //    67: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    70: athrow         
        //    71: iconst_m1      
        //    72: if_icmpeq       324
        //    75: goto            82
        //    78: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    81: athrow         
        //    82: iconst_0       
        //    83: goto            90
        //    86: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    89: athrow         
        //    90: istore          10
        //    92: iload           10
        //    94: iload           8
        //    96: if_icmpge       314
        //    99: aload_0        
        //   100: getfield        org/apache/commons/io/input/Tailer.inbuf:[B
        //   103: iload           10
        //   105: baload         
        //   106: istore          11
        //   108: iload           11
        //   110: aload_2        
        //   111: ifnonnull       31
        //   114: aload_2        
        //   115: ifnonnull       242
        //   118: lookupswitch {
        //               10: 148
        //               13: 193
        //          default: 229
        //        }
        //   144: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   147: athrow         
        //   148: iconst_0       
        //   149: istore          9
        //   151: aload_0        
        //   152: getfield        org/apache/commons/io/input/Tailer.listener:Lorg/apache/commons/io/input/TailerListener;
        //   155: new             Ljava/lang/String;
        //   158: dup            
        //   159: aload_3        
        //   160: invokestatic    q/o/m/s/q.jm:(Ljava/io/ByteArrayOutputStream;)[B
        //   163: aload_0        
        //   164: getfield        org/apache/commons/io/input/Tailer.cset:Ljava/nio/charset/Charset;
        //   167: invokespecial   java/lang/String.<init>:([BLjava/nio/charset/Charset;)V
        //   170: invokeinterface org/apache/commons/io/input/TailerListener.handle:(Ljava/lang/String;)V
        //   175: aload_3        
        //   176: invokestatic    q/o/m/s/q.jv:(Ljava/io/ByteArrayOutputStream;)V
        //   179: lload           4
        //   181: iload           10
        //   183: i2l            
        //   184: ladd           
        //   185: lconst_1       
        //   186: ladd           
        //   187: lstore          6
        //   189: aload_2        
        //   190: ifnull          307
        //   193: iload           9
        //   195: aload_2        
        //   196: ifnonnull       223
        //   199: ifeq            222
        //   202: goto            209
        //   205: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   208: athrow         
        //   209: aload_3        
        //   210: bipush          13
        //   212: invokestatic    q/o/m/s/q.jo:(Ljava/io/ByteArrayOutputStream;I)V
        //   215: goto            222
        //   218: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   221: athrow         
        //   222: iconst_1       
        //   223: istore          9
        //   225: aload_2        
        //   226: ifnull          307
        //   229: iload           9
        //   231: aload_2        
        //   232: ifnonnull       149
        //   235: goto            242
        //   238: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   241: athrow         
        //   242: aload_2        
        //   243: ifnonnull       257
        //   246: ifeq            297
        //   249: goto            256
        //   252: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   255: athrow         
        //   256: iconst_0       
        //   257: istore          9
        //   259: aload_0        
        //   260: getfield        org/apache/commons/io/input/Tailer.listener:Lorg/apache/commons/io/input/TailerListener;
        //   263: new             Ljava/lang/String;
        //   266: dup            
        //   267: aload_3        
        //   268: invokestatic    q/o/m/s/q.jm:(Ljava/io/ByteArrayOutputStream;)[B
        //   271: aload_0        
        //   272: getfield        org/apache/commons/io/input/Tailer.cset:Ljava/nio/charset/Charset;
        //   275: invokespecial   java/lang/String.<init>:([BLjava/nio/charset/Charset;)V
        //   278: invokeinterface org/apache/commons/io/input/TailerListener.handle:(Ljava/lang/String;)V
        //   283: aload_3        
        //   284: invokestatic    q/o/m/s/q.jv:(Ljava/io/ByteArrayOutputStream;)V
        //   287: lload           4
        //   289: iload           10
        //   291: i2l            
        //   292: ladd           
        //   293: lconst_1       
        //   294: ladd           
        //   295: lstore          6
        //   297: aload_3        
        //   298: aload_2        
        //   299: ifnonnull       284
        //   302: iload           11
        //   304: invokestatic    q/o/m/s/q.jo:(Ljava/io/ByteArrayOutputStream;I)V
        //   307: iinc            10, 1
        //   310: aload_2        
        //   311: ifnull          92
        //   314: aload_1        
        //   315: invokestatic    q/o/m/s/q.jf:(Ljava/io/RandomAccessFile;)J
        //   318: lstore          4
        //   320: aload_2        
        //   321: ifnull          27
        //   324: aload_3        
        //   325: invokestatic    org/apache/commons/io/IOUtils.closeQuietly:(Ljava/io/OutputStream;)V
        //   328: aload_1        
        //   329: lload           6
        //   331: invokestatic    q/o/m/s/q.cb:(Ljava/io/RandomAccessFile;J)V
        //   334: aload_0        
        //   335: getfield        org/apache/commons/io/input/Tailer.listener:Lorg/apache/commons/io/input/TailerListener;
        //   338: aload_2        
        //   339: ifnonnull       377
        //   342: aload_2        
        //   343: ifnonnull       377
        //   346: goto            353
        //   349: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   352: athrow         
        //   353: instanceof      Lorg/apache/commons/io/input/TailerListenerAdapter;
        //   356: goto            363
        //   359: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   362: athrow         
        //   363: ifeq            383
        //   366: aload_0        
        //   367: getfield        org/apache/commons/io/input/Tailer.listener:Lorg/apache/commons/io/input/TailerListener;
        //   370: goto            377
        //   373: invokestatic    org/apache/commons/io/input/Tailer.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   376: athrow         
        //   377: checkcast       Lorg/apache/commons/io/input/TailerListenerAdapter;
        //   380: invokevirtual   org/apache/commons/io/input/TailerListenerAdapter.endOfFileReached:()V
        //   383: lload           6
        //   385: lreturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 26 FF 00 1B 00 08 07 00 02 07 00 85 07 00 83 07 00 CB 04 04 00 01 00 00 43 01 FF 00 18 00 08 07 00 02 07 00 85 07 00 83 07 00 CB 04 04 01 01 00 01 07 00 77 43 01 46 07 00 77 43 01 46 07 00 77 03 43 07 00 77 43 01 FC 00 01 01 FF 00 33 00 0A 07 00 02 07 00 85 07 00 83 07 00 CB 04 04 01 01 01 01 00 01 07 00 77 03 40 01 2B 4B 07 00 77 03 48 07 00 77 03 40 01 05 48 07 00 77 43 01 49 07 00 77 03 40 01 5A 07 00 CB 0C 09 FA 00 06 FF 00 09 00 08 07 00 02 07 00 85 07 00 83 07 00 CB 04 04 00 01 00 00 58 07 00 77 43 07 00 46 45 07 00 77 43 01 49 07 00 77 43 07 00 46 05
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  45     53     56     60     Ljava/io/IOException;
        //  49     64     67     71     Ljava/io/IOException;
        //  60     75     78     82     Ljava/io/IOException;
        //  71     83     86     90     Ljava/io/IOException;
        //  114    144    144    148    Ljava/io/IOException;
        //  193    202    205    209    Ljava/io/IOException;
        //  199    215    218    222    Ljava/io/IOException;
        //  225    235    238    242    Ljava/io/IOException;
        //  242    249    252    256    Ljava/io/IOException;
        //  324    346    349    353    Ljava/io/IOException;
        //  342    356    359    363    Ljava/io/IOException;
        //  363    370    373    377    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0060:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        DEFAULT_CHARSET = q.sx();
    }
    
    private static IOException b(final IOException ex) {
        return ex;
    }
}
