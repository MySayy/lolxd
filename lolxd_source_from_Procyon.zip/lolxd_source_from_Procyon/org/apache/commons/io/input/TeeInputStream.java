// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import q.o.m.s.q;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class TeeInputStream extends ProxyInputStream
{
    private final OutputStream branch;
    private final boolean closeBranch;
    
    public TeeInputStream(final InputStream inputStream, final OutputStream outputStream) {
        this(inputStream, outputStream, false);
    }
    
    public TeeInputStream(final InputStream inputStream, final OutputStream branch, final boolean closeBranch) {
        super(inputStream);
        this.branch = branch;
        this.closeBranch = closeBranch;
    }
    
    @Override
    public void close() throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: aload_0        
        //     5: invokespecial   org/apache/commons/io/input/ProxyInputStream.close:()V
        //     8: aload_0        
        //     9: aload_1        
        //    10: ifnonnull       38
        //    13: aload_1        
        //    14: ifnonnull       38
        //    17: getfield        org/apache/commons/io/input/TeeInputStream.closeBranch:Z
        //    20: ifeq            93
        //    23: goto            30
        //    26: invokestatic    org/apache/commons/io/input/TeeInputStream.c:(Ljava/io/IOException;)Ljava/io/IOException;
        //    29: athrow         
        //    30: aload_0        
        //    31: goto            38
        //    34: invokestatic    org/apache/commons/io/input/TeeInputStream.c:(Ljava/io/IOException;)Ljava/io/IOException;
        //    37: athrow         
        //    38: getfield        org/apache/commons/io/input/TeeInputStream.branch:Ljava/io/OutputStream;
        //    41: invokestatic    q/o/m/s/q.pf:(Ljava/io/OutputStream;)V
        //    44: goto            93
        //    47: astore_2       
        //    48: aload_0        
        //    49: aload_1        
        //    50: ifnonnull       85
        //    53: aload_1        
        //    54: ifnonnull       85
        //    57: goto            64
        //    60: invokestatic    org/apache/commons/io/input/TeeInputStream.c:(Ljava/io/IOException;)Ljava/io/IOException;
        //    63: athrow         
        //    64: getfield        org/apache/commons/io/input/TeeInputStream.closeBranch:Z
        //    67: ifeq            91
        //    70: goto            77
        //    73: invokestatic    org/apache/commons/io/input/TeeInputStream.c:(Ljava/io/IOException;)Ljava/io/IOException;
        //    76: athrow         
        //    77: aload_0        
        //    78: goto            85
        //    81: invokestatic    org/apache/commons/io/input/TeeInputStream.c:(Ljava/io/IOException;)Ljava/io/IOException;
        //    84: athrow         
        //    85: getfield        org/apache/commons/io/input/TeeInputStream.branch:Ljava/io/OutputStream;
        //    88: invokestatic    q/o/m/s/q.pf:(Ljava/io/OutputStream;)V
        //    91: aload_2        
        //    92: athrow         
        //    93: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 0D FF 00 1A 00 02 07 00 02 07 00 21 00 01 07 00 19 03 43 07 00 19 43 07 00 02 48 07 00 2D FF 00 0C 00 03 07 00 02 07 00 21 07 00 2D 00 01 07 00 19 43 07 00 02 48 07 00 19 03 43 07 00 19 43 07 00 02 05 FA 00 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      8      47     93     Any
        //  17     31     34     38     Ljava/io/IOException;
        //  13     23     26     30     Ljava/io/IOException;
        //  47     48     47     93     Any
        //  48     57     60     64     Ljava/io/IOException;
        //  53     70     73     77     Ljava/io/IOException;
        //  64     78     81     85     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0064:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public int read() throws IOException {
        final int read = super.read();
        final String b = ProxyInputStream.b();
        Label_0025: {
            int n;
            try {
                final int n2;
                n = (n2 = read);
                if (b != null) {
                    return n2;
                }
                final int n3 = -1;
                if (n != n3) {
                    break Label_0025;
                }
                return read;
            }
            catch (IOException ex) {
                throw c(ex);
            }
            try {
                final int n3 = -1;
                if (n != n3) {
                    q.kq(this.branch, read);
                }
            }
            catch (IOException ex2) {
                throw c(ex2);
            }
        }
        return read;
    }
    
    @Override
    public int read(final byte[] array, final int n, final int n2) throws IOException {
        final String b = ProxyInputStream.b();
        final int read = super.read(array, n, n2);
        final String s = b;
        Label_0032: {
            int n3;
            try {
                final int n4;
                n3 = (n4 = read);
                if (s != null) {
                    return n4;
                }
                final int n5 = -1;
                if (n3 != n5) {
                    break Label_0032;
                }
                return read;
            }
            catch (IOException ex) {
                throw c(ex);
            }
            try {
                final int n5 = -1;
                if (n3 != n5) {
                    q.sz(this.branch, array, n, read);
                }
            }
            catch (IOException ex2) {
                throw c(ex2);
            }
        }
        return read;
    }
    
    @Override
    public int read(final byte[] array) throws IOException {
        final int read = super.read(array);
        final String b = ProxyInputStream.b();
        Label_0026: {
            int n;
            try {
                final int n2;
                n = (n2 = read);
                if (b != null) {
                    return n2;
                }
                final int n3 = -1;
                if (n != n3) {
                    break Label_0026;
                }
                return read;
            }
            catch (IOException ex) {
                throw c(ex);
            }
            try {
                final int n3 = -1;
                if (n != n3) {
                    q.sz(this.branch, array, 0, read);
                }
            }
            catch (IOException ex2) {
                throw c(ex2);
            }
        }
        return read;
    }
    
    private static IOException c(final IOException ex) {
        return ex;
    }
}
