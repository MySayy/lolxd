// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import q.o.m.s.q;
import java.io.IOException;
import java.io.InputStream;

public class BoundedInputStream extends InputStream
{
    private final InputStream in;
    private final long max;
    private long pos;
    private long mark;
    private boolean propagateClose;
    
    public BoundedInputStream(final InputStream in, final long max) {
        this.pos = 0L;
        this.mark = -1L;
        this.propagateClose = true;
        this.max = max;
        this.in = in;
    }
    
    public BoundedInputStream(final InputStream inputStream) {
        this(inputStream, -1L);
    }
    
    @Override
    public int read() throws IOException {
        final String b = ProxyInputStream.b();
        int n3;
        int n5;
        while (true) {
            long kt = 0L;
            Label_0056: {
                Label_0049: {
                    int n2 = 0;
                    Label_0024: {
                        long n;
                        try {
                            n = (kt = lcmp(this.max, 0L));
                            if (b != null) {
                                break Label_0056;
                            }
                            if (n >= 0) {
                                break Label_0024;
                            }
                            break Label_0049;
                        }
                        catch (IOException ex) {
                            throw b(ex);
                        }
                        try {
                            if (n < 0) {
                                break Label_0049;
                            }
                            kt = (n2 = lcmp(this.pos, this.max));
                        }
                        catch (IOException ex2) {
                            throw b(ex2);
                        }
                    }
                    if (b != null) {
                        break Label_0056;
                    }
                    if (n2 < 0) {
                        break Label_0049;
                    }
                    n3 = -1;
                    return n3;
                }
                kt = q.kt(this.in);
            }
            final long n4 = kt;
            ++this.pos;
            int n2;
            n5 = (n2 = (n3 = (int)(kt = n4)));
            if (b != null) {
                continue;
            }
            break;
        }
        if (b == null) {
            return n5;
        }
        return n3;
    }
    
    @Override
    public int read(final byte[] array) throws IOException {
        return this.read(array, 0, array.length);
    }
    
    @Override
    public int read(final byte[] array, final int n, final int n2) throws IOException {
        final String b = ProxyInputStream.b();
        long nu = 0L;
        Label_0107: {
            int n5 = 0;
            Label_0106: {
                while (true) {
                    Label_0100: {
                        Label_0068: {
                            int n4;
                            int n7;
                            while (true) {
                                Label_0052: {
                                    long n6 = 0L;
                                    Label_0026: {
                                        int n3;
                                        try {
                                            n3 = (n4 = (n5 = lcmp(this.max, 0L)));
                                            if (b != null) {
                                                break Label_0068;
                                            }
                                            if (n3 >= 0) {
                                                break Label_0026;
                                            }
                                            break Label_0052;
                                        }
                                        catch (IOException ex) {
                                            throw b(ex);
                                        }
                                        try {
                                            if (n3 < 0) {
                                                break Label_0052;
                                            }
                                            n4 = (int)(n6 = (n5 = lcmp(this.pos, this.max)));
                                        }
                                        catch (IOException ex2) {
                                            throw b(ex2);
                                        }
                                    }
                                    if (b != null) {
                                        break Label_0068;
                                    }
                                    if (n6 < 0) {
                                        break Label_0052;
                                    }
                                    n7 = -1;
                                    return n7;
                                }
                                long n6;
                                n7 = (int)(n6 = (n4 = (n5 = lcmp(this.max, 0L))));
                                if (b != null) {
                                    continue;
                                }
                                break;
                            }
                            if (b != null) {
                                return n7;
                            }
                            try {
                                if (b != null) {
                                    break Label_0106;
                                }
                                if (n4 < 0) {
                                    break Label_0100;
                                }
                            }
                            catch (IOException ex3) {
                                throw b(ex3);
                            }
                        }
                        final int n8 = n2;
                        nu = q.nu(n8, this.max - this.pos);
                        break Label_0107;
                    }
                    n5 = n2;
                    final int n8 = n2;
                    if (b != null) {
                        continue;
                    }
                    break;
                }
            }
            nu = n5;
        }
        final int yn = q.yn(this.in, array, n, (int)nu);
        Label_0150: {
            int n12 = 0;
            Label_0141: {
                int n9;
                try {
                    final int n10;
                    n9 = (n10 = yn);
                    if (b != null) {
                        return n10;
                    }
                    final int n11 = -1;
                    if (n9 == n11) {
                        break Label_0141;
                    }
                    break Label_0150;
                }
                catch (IOException ex4) {
                    throw b(ex4);
                }
                try {
                    final int n11 = -1;
                    if (n9 != n11) {
                        break Label_0150;
                    }
                    n12 = -1;
                }
                catch (IOException ex5) {
                    throw b(ex5);
                }
            }
            return n12;
        }
        this.pos += yn;
        int n12;
        int n10 = n12 = yn;
        if (b != null) {
            return n12;
        }
        return n10;
    }
    
    @Override
    public long skip(final long p0) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_3       
        //     4: aload_0        
        //     5: getfield        org/apache/commons/io/input/BoundedInputStream.max:J
        //     8: lconst_0       
        //     9: aload_3        
        //    10: ifnonnull       52
        //    13: aload_3        
        //    14: ifnonnull       52
        //    17: goto            24
        //    20: invokestatic    org/apache/commons/io/input/BoundedInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    23: athrow         
        //    24: lcmp           
        //    25: iflt            58
        //    28: goto            35
        //    31: invokestatic    org/apache/commons/io/input/BoundedInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    34: athrow         
        //    35: lload_1        
        //    36: aload_0        
        //    37: getfield        org/apache/commons/io/input/BoundedInputStream.max:J
        //    40: aload_0        
        //    41: getfield        org/apache/commons/io/input/BoundedInputStream.pos:J
        //    44: lsub           
        //    45: goto            52
        //    48: invokestatic    org/apache/commons/io/input/BoundedInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    51: athrow         
        //    52: invokestatic    q/o/m/s/q.nu:(JJ)J
        //    55: goto            59
        //    58: lload_1        
        //    59: lstore          4
        //    61: aload_0        
        //    62: getfield        org/apache/commons/io/input/BoundedInputStream.in:Ljava/io/InputStream;
        //    65: lload           4
        //    67: invokestatic    q/o/m/s/q.xo:(Ljava/io/InputStream;J)J
        //    70: lstore          6
        //    72: aload_0        
        //    73: dup            
        //    74: getfield        org/apache/commons/io/input/BoundedInputStream.pos:J
        //    77: lload           6
        //    79: ladd           
        //    80: putfield        org/apache/commons/io/input/BoundedInputStream.pos:J
        //    83: lload           6
        //    85: lreturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 08 FF 00 14 00 03 07 00 02 04 07 00 2D 00 01 07 00 25 FF 00 03 00 03 07 00 02 04 07 00 2D 00 02 04 04 46 07 00 25 03 4C 07 00 25 FF 00 03 00 03 07 00 02 04 07 00 2D 00 02 04 04 05 40 04
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      17     20     24     Ljava/io/IOException;
        //  13     28     31     35     Ljava/io/IOException;
        //  24     45     48     52     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0024:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public int available() throws IOException {
        final String b = ProxyInputStream.b();
        long xq = 0L;
        long n3;
        while (true) {
            Label_0049: {
                int n2 = 0;
                Label_0024: {
                    long n;
                    try {
                        n = (xq = lcmp(this.max, 0L));
                        if (b != null) {
                            return (int)xq;
                        }
                        if (n >= 0) {
                            break Label_0024;
                        }
                        break Label_0049;
                    }
                    catch (IOException ex) {
                        throw b(ex);
                    }
                    try {
                        if (n < 0) {
                            break Label_0049;
                        }
                        xq = (n2 = lcmp(this.pos, this.max));
                    }
                    catch (IOException ex2) {
                        throw b(ex2);
                    }
                }
                if (b != null) {
                    return (int)xq;
                }
                if (n2 < 0) {
                    break Label_0049;
                }
                n3 = 0;
                return (int)n3;
            }
            int n2;
            n3 = (n2 = (int)(xq = q.xq(this.in)));
            if (b != null) {
                continue;
            }
            break;
        }
        if (b != null) {
            return (int)n3;
        }
        return (int)xq;
    }
    
    @Override
    public String toString() {
        return q.yh(this.in);
    }
    
    @Override
    public void close() throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: aload_0        
        //     5: aload_1        
        //     6: ifnonnull       44
        //     9: aload_1        
        //    10: ifnonnull       44
        //    13: goto            20
        //    16: invokestatic    org/apache/commons/io/input/BoundedInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    19: athrow         
        //    20: getfield        org/apache/commons/io/input/BoundedInputStream.propagateClose:Z
        //    23: ifeq            47
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/input/BoundedInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    32: athrow         
        //    33: aload_0        
        //    34: getfield        org/apache/commons/io/input/BoundedInputStream.in:Ljava/io/InputStream;
        //    37: goto            44
        //    40: invokestatic    org/apache/commons/io/input/BoundedInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    43: athrow         
        //    44: invokestatic    q/o/m/s/q.yp:(Ljava/io/InputStream;)V
        //    47: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 07 50 07 00 25 43 07 00 02 48 07 00 25 03 46 07 00 25 43 07 00 04 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      13     16     20     Ljava/io/IOException;
        //  9      26     29     33     Ljava/io/IOException;
        //  20     37     40     44     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0020:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public synchronized void reset() throws IOException {
        q.xv(this.in);
        this.pos = this.mark;
    }
    
    @Override
    public synchronized void mark(final int n) {
        q.xm(this.in, n);
        this.mark = this.pos;
    }
    
    @Override
    public boolean markSupported() {
        return q.xt(this.in);
    }
    
    public boolean isPropagateClose() {
        return this.propagateClose;
    }
    
    public void setPropagateClose(final boolean propagateClose) {
        this.propagateClose = propagateClose;
    }
    
    private static IOException b(final IOException ex) {
        return ex;
    }
}
