// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import java.io.IOException;
import org.apache.commons.io.TaggedIOException;
import q.o.m.s.q;
import java.io.InputStream;
import java.io.Serializable;

public class TaggedInputStream extends ProxyInputStream
{
    private final Serializable tag;
    
    public TaggedInputStream(final InputStream inputStream) {
        super(inputStream);
        this.tag = q.hu();
    }
    
    public boolean isCauseOf(final Throwable t) {
        return TaggedIOException.isTaggedWith(t, this.tag);
    }
    
    public void throwIfCauseOf(final Throwable t) throws IOException {
        TaggedIOException.throwCauseIfTaggedWith(t, this.tag);
    }
    
    @Override
    protected void handleIOException(final IOException ex) throws IOException {
        throw new TaggedIOException(ex, this.tag);
    }
}
