// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import java.nio.CharBuffer;
import q.o.m.s.q;
import java.io.IOException;
import java.io.Reader;
import java.io.FilterReader;

public abstract class ProxyReader extends FilterReader
{
    public ProxyReader(final Reader in) {
        super(in);
    }
    
    @Override
    public int read() throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: aload_0        
        //     5: iconst_1       
        //     6: invokevirtual   org/apache/commons/io/input/ProxyReader.beforeRead:(I)V
        //     9: aload_0        
        //    10: getfield        org/apache/commons/io/input/ProxyReader.in:Ljava/io/Reader;
        //    13: invokestatic    q/o/m/s/q.yg:(Ljava/io/Reader;)I
        //    16: istore_2       
        //    17: aload_0        
        //    18: iload_2        
        //    19: aload_1        
        //    20: ifnonnull       53
        //    23: aload_1        
        //    24: ifnonnull       53
        //    27: goto            34
        //    30: invokestatic    org/apache/commons/io/input/ProxyReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    33: athrow         
        //    34: iconst_m1      
        //    35: if_icmpeq       56
        //    38: goto            45
        //    41: invokestatic    org/apache/commons/io/input/ProxyReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    44: athrow         
        //    45: iconst_1       
        //    46: goto            53
        //    49: invokestatic    org/apache/commons/io/input/ProxyReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    52: athrow         
        //    53: goto            57
        //    56: iconst_m1      
        //    57: invokevirtual   org/apache/commons/io/input/ProxyReader.afterRead:(I)V
        //    60: iload_2        
        //    61: ireturn        
        //    62: astore_2       
        //    63: aload_0        
        //    64: aload_2        
        //    65: invokevirtual   org/apache/commons/io/input/ProxyReader.handleIOException:(Ljava/io/IOException;)V
        //    68: iconst_m1      
        //    69: ireturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 09 FF 00 1E 00 03 07 00 02 07 00 23 01 00 01 07 00 0D FF 00 03 00 03 07 00 02 07 00 23 01 00 02 07 00 02 01 46 07 00 0D 43 07 00 02 43 07 00 0D FF 00 03 00 03 07 00 02 07 00 23 01 00 02 07 00 02 01 42 07 00 02 FF 00 00 00 03 07 00 02 07 00 23 01 00 02 07 00 02 01 FF 00 04 00 01 07 00 02 00 01 07 00 0D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  34     46     49     53     Ljava/io/IOException;
        //  23     38     41     45     Ljava/io/IOException;
        //  17     27     30     34     Ljava/io/IOException;
        //  4      61     62     70     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0034:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public int read(final char[] array) throws IOException {
        final String b = ProxyInputStream.b();
        try {
            int length = 0;
            Label_0037: {
                Label_0036: {
                    char[] array2 = null;
                    Label_0032: {
                        Label_0021: {
                            try {
                                array2 = array;
                                if (b != null) {
                                    break Label_0032;
                                }
                                final String s = b;
                                if (s == null) {
                                    break Label_0021;
                                }
                                break Label_0032;
                            }
                            catch (IOException ex) {
                                throw b(ex);
                            }
                            try {
                                final String s = b;
                                if (s != null) {
                                    break Label_0032;
                                }
                                if (array == null) {
                                    break Label_0036;
                                }
                            }
                            catch (IOException ex2) {
                                throw b(ex2);
                            }
                        }
                        array2 = array;
                    }
                    length = array2.length;
                    break Label_0037;
                }
                length = 0;
            }
            this.beforeRead(length);
            final int sd = q.sd(this.in, array);
            this.afterRead(sd);
            return sd;
        }
        catch (IOException ex3) {
            this.handleIOException(ex3);
            return -1;
        }
    }
    
    @Override
    public int read(final char[] array, final int n, final int n2) throws IOException {
        try {
            this.beforeRead(n2);
            final int yj = q.yj(this.in, array, n, n2);
            this.afterRead(yj);
            return yj;
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            return -1;
        }
    }
    
    @Override
    public int read(final CharBuffer charBuffer) throws IOException {
        final String b = ProxyInputStream.b();
        try {
            int hp = 0;
            Label_0039: {
                Label_0038: {
                    CharBuffer charBuffer2 = null;
                    Label_0032: {
                        Label_0021: {
                            try {
                                charBuffer2 = charBuffer;
                                if (b != null) {
                                    break Label_0032;
                                }
                                final String s = b;
                                if (s == null) {
                                    break Label_0021;
                                }
                                break Label_0032;
                            }
                            catch (IOException ex) {
                                throw b(ex);
                            }
                            try {
                                final String s = b;
                                if (s != null) {
                                    break Label_0032;
                                }
                                if (charBuffer == null) {
                                    break Label_0038;
                                }
                            }
                            catch (IOException ex2) {
                                throw b(ex2);
                            }
                        }
                        charBuffer2 = charBuffer;
                    }
                    hp = q.hp(charBuffer2);
                    break Label_0039;
                }
                hp = 0;
            }
            this.beforeRead(hp);
            final int hy = q.hy(this.in, charBuffer);
            this.afterRead(hy);
            return hy;
        }
        catch (IOException ex3) {
            this.handleIOException(ex3);
            return -1;
        }
    }
    
    @Override
    public long skip(final long n) throws IOException {
        try {
            return q.hc(this.in, n);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            return 0L;
        }
    }
    
    @Override
    public boolean ready() throws IOException {
        try {
            return q.hx(this.in);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            return false;
        }
    }
    
    @Override
    public void close() throws IOException {
        try {
            q.xr(this.in);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
    }
    
    @Override
    public synchronized void mark(final int n) throws IOException {
        try {
            q.xk(this.in, n);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
    }
    
    @Override
    public synchronized void reset() throws IOException {
        try {
            q.xs(this.in);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
    }
    
    @Override
    public boolean markSupported() {
        return q.hh(this.in);
    }
    
    protected void beforeRead(final int n) throws IOException {
    }
    
    protected void afterRead(final int n) throws IOException {
    }
    
    protected void handleIOException(final IOException ex) throws IOException {
        throw ex;
    }
    
    private static IOException b(final IOException ex) {
        return ex;
    }
}
