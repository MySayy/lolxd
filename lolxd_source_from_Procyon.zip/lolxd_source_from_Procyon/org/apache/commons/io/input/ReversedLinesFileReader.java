// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import org.apache.commons.io.Charsets;
import java.io.IOException;
import q.o.m.s.q;
import java.io.File;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.io.Closeable;

public class ReversedLinesFileReader implements Closeable
{
    private final int blockSize;
    private final Charset encoding;
    private final RandomAccessFile randomAccessFile;
    private final long totalByteLength;
    private final long totalBlockCount;
    private final byte[][] newLineSequences;
    private final int avoidNewlineSplitBufferSize;
    private final int byteDecrement;
    private ReversedLinesFileReader$FilePart currentFilePart;
    private boolean trailingNewlineOfFileSkipped;
    private static final String[] a;
    private static final String[] b;
    
    @Deprecated
    public ReversedLinesFileReader(final File file) throws IOException {
        this(file, 4096, q.sx());
    }
    
    public ReversedLinesFileReader(final File file, final Charset charset) throws IOException {
        this(file, 4096, charset);
    }
    
    public ReversedLinesFileReader(final File p0, final int p1, final Charset p2) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokespecial   java/lang/Object.<init>:()V
        //     4: aload_0        
        //     5: iconst_0       
        //     6: putfield        org/apache/commons/io/input/ReversedLinesFileReader.trailingNewlineOfFileSkipped:Z
        //     9: invokestatic    org/apache/commons/io/input/ProxyInputStream.b:()Ljava/lang/String;
        //    12: aload_0        
        //    13: iload_2        
        //    14: putfield        org/apache/commons/io/input/ReversedLinesFileReader.blockSize:I
        //    17: astore          4
        //    19: aload_0        
        //    20: aload_3        
        //    21: putfield        org/apache/commons/io/input/ReversedLinesFileReader.encoding:Ljava/nio/charset/Charset;
        //    24: aload_3        
        //    25: invokestatic    org/apache/commons/io/Charsets.toCharset:(Ljava/nio/charset/Charset;)Ljava/nio/charset/Charset;
        //    28: astore          6
        //    30: aload           6
        //    32: invokestatic    q/o/m/s/q.xe:(Ljava/nio/charset/Charset;)Ljava/nio/charset/CharsetEncoder;
        //    35: astore          7
        //    37: aload           7
        //    39: invokestatic    q/o/m/s/q.xy:(Ljava/nio/charset/CharsetEncoder;)F
        //    42: fstore          8
        //    44: aload           4
        //    46: ifnonnull       87
        //    49: aload           4
        //    51: ifnonnull       87
        //    54: goto            61
        //    57: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    60: athrow         
        //    61: fload           8
        //    63: fconst_1       
        //    64: fcmpl          
        //    65: ifne            105
        //    68: goto            75
        //    71: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    74: athrow         
        //    75: aload_0        
        //    76: iconst_1       
        //    77: putfield        org/apache/commons/io/input/ReversedLinesFileReader.byteDecrement:I
        //    80: goto            87
        //    83: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    86: athrow         
        //    87: aload           4
        //    89: ifnull          572
        //    92: invokestatic    com/sun/jna/Structure.b:()I
        //    95: istore          5
        //    97: iinc            5, 1
        //   100: iload           5
        //   102: invokestatic    com/sun/jna/Structure.b:(I)V
        //   105: aload           6
        //   107: getstatic       org/apache/commons/io/Charsets.UTF_8:Ljava/nio/charset/Charset;
        //   110: aload           4
        //   112: ifnonnull       168
        //   115: if_acmpne       142
        //   118: goto            125
        //   121: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   124: athrow         
        //   125: aload_0        
        //   126: iconst_1       
        //   127: putfield        org/apache/commons/io/input/ReversedLinesFileReader.byteDecrement:I
        //   130: aload           4
        //   132: ifnull          572
        //   135: goto            142
        //   138: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   141: athrow         
        //   142: aload           6
        //   144: sipush          -6337
        //   147: sipush          -27063
        //   150: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.a:(II)Ljava/lang/String;
        //   153: invokestatic    q/o/m/s/q.sh:(Ljava/lang/String;)Ljava/nio/charset/Charset;
        //   156: aload           4
        //   158: ifnonnull       211
        //   161: goto            168
        //   164: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   167: athrow         
        //   168: aload           4
        //   170: ifnonnull       216
        //   173: goto            180
        //   176: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   179: athrow         
        //   180: if_acmpeq       370
        //   183: goto            190
        //   186: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   189: athrow         
        //   190: aload           6
        //   192: sipush          -6340
        //   195: sipush          -20095
        //   198: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.a:(II)Ljava/lang/String;
        //   201: invokestatic    q/o/m/s/q.sh:(Ljava/lang/String;)Ljava/nio/charset/Charset;
        //   204: goto            211
        //   207: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   210: athrow         
        //   211: aload           4
        //   213: ifnonnull       259
        //   216: aload           4
        //   218: ifnonnull       264
        //   221: goto            228
        //   224: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   227: athrow         
        //   228: if_acmpeq       370
        //   231: goto            238
        //   234: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   237: athrow         
        //   238: aload           6
        //   240: sipush          -6338
        //   243: sipush          -31991
        //   246: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.a:(II)Ljava/lang/String;
        //   249: invokestatic    q/o/m/s/q.sh:(Ljava/lang/String;)Ljava/nio/charset/Charset;
        //   252: goto            259
        //   255: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   258: athrow         
        //   259: aload           4
        //   261: ifnonnull       307
        //   264: aload           4
        //   266: ifnonnull       312
        //   269: goto            276
        //   272: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   275: athrow         
        //   276: if_acmpeq       370
        //   279: goto            286
        //   282: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   285: athrow         
        //   286: aload           6
        //   288: sipush          -6341
        //   291: sipush          5937
        //   294: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.a:(II)Ljava/lang/String;
        //   297: invokestatic    q/o/m/s/q.sh:(Ljava/lang/String;)Ljava/nio/charset/Charset;
        //   300: goto            307
        //   303: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   306: athrow         
        //   307: aload           4
        //   309: ifnonnull       355
        //   312: aload           4
        //   314: ifnonnull       355
        //   317: goto            324
        //   320: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   323: athrow         
        //   324: if_acmpeq       370
        //   327: goto            334
        //   330: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   333: athrow         
        //   334: aload           6
        //   336: sipush          -6344
        //   339: sipush          -20078
        //   342: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.a:(II)Ljava/lang/String;
        //   345: invokestatic    q/o/m/s/q.sh:(Ljava/lang/String;)Ljava/nio/charset/Charset;
        //   348: goto            355
        //   351: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   354: athrow         
        //   355: aload           4
        //   357: ifnonnull       404
        //   360: if_acmpne       387
        //   363: goto            370
        //   366: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   369: athrow         
        //   370: aload_0        
        //   371: iconst_1       
        //   372: putfield        org/apache/commons/io/input/ReversedLinesFileReader.byteDecrement:I
        //   375: aload           4
        //   377: ifnull          572
        //   380: goto            387
        //   383: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   386: athrow         
        //   387: aload           6
        //   389: getstatic       org/apache/commons/io/Charsets.UTF_16BE:Ljava/nio/charset/Charset;
        //   392: aload           4
        //   394: ifnonnull       438
        //   397: goto            404
        //   400: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   403: athrow         
        //   404: aload           4
        //   406: ifnonnull       438
        //   409: goto            416
        //   412: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   415: athrow         
        //   416: if_acmpeq       453
        //   419: goto            426
        //   422: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   425: athrow         
        //   426: aload           6
        //   428: getstatic       org/apache/commons/io/Charsets.UTF_16LE:Ljava/nio/charset/Charset;
        //   431: goto            438
        //   434: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   437: athrow         
        //   438: aload           4
        //   440: ifnonnull       482
        //   443: if_acmpne       470
        //   446: goto            453
        //   449: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   452: athrow         
        //   453: aload_0        
        //   454: iconst_2       
        //   455: putfield        org/apache/commons/io/input/ReversedLinesFileReader.byteDecrement:I
        //   458: aload           4
        //   460: ifnull          572
        //   463: goto            470
        //   466: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   469: athrow         
        //   470: aload           6
        //   472: getstatic       org/apache/commons/io/Charsets.UTF_16:Ljava/nio/charset/Charset;
        //   475: goto            482
        //   478: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   481: athrow         
        //   482: if_acmpne       509
        //   485: new             Ljava/io/UnsupportedEncodingException;
        //   488: dup            
        //   489: sipush          -6339
        //   492: sipush          -22978
        //   495: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.a:(II)Ljava/lang/String;
        //   498: invokespecial   java/io/UnsupportedEncodingException.<init>:(Ljava/lang/String;)V
        //   501: goto            508
        //   504: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   507: athrow         
        //   508: athrow         
        //   509: new             Ljava/io/UnsupportedEncodingException;
        //   512: dup            
        //   513: new             Ljava/lang/StringBuilder;
        //   516: dup            
        //   517: invokespecial   java/lang/StringBuilder.<init>:()V
        //   520: sipush          -6343
        //   523: sipush          20484
        //   526: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.a:(II)Ljava/lang/String;
        //   529: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   532: aload_3        
        //   533: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   536: sipush          -6349
        //   539: sipush          -6592
        //   542: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.a:(II)Ljava/lang/String;
        //   545: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   548: sipush          -6342
        //   551: sipush          -20235
        //   554: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.a:(II)Ljava/lang/String;
        //   557: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   560: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   563: invokespecial   java/io/UnsupportedEncodingException.<init>:(Ljava/lang/String;)V
        //   566: aload           4
        //   568: ifnonnull       508
        //   571: athrow         
        //   572: aload_0        
        //   573: iconst_3       
        //   574: anewarray       [B
        //   577: dup            
        //   578: iconst_0       
        //   579: sipush          -6350
        //   582: sipush          23635
        //   585: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.a:(II)Ljava/lang/String;
        //   588: aload_3        
        //   589: invokestatic    q/o/m/s/q.yf:(Ljava/lang/String;Ljava/nio/charset/Charset;)[B
        //   592: aastore        
        //   593: dup            
        //   594: iconst_1       
        //   595: invokestatic    n/d/a/d/q.my:()Ljava/lang/String;
        //   598: aload_3        
        //   599: invokestatic    q/o/m/s/q.yf:(Ljava/lang/String;Ljava/nio/charset/Charset;)[B
        //   602: aastore        
        //   603: dup            
        //   604: iconst_2       
        //   605: invokestatic    n/d/a/d/q.qz:()Ljava/lang/String;
        //   608: aload_3        
        //   609: invokestatic    q/o/m/s/q.yf:(Ljava/lang/String;Ljava/nio/charset/Charset;)[B
        //   612: aastore        
        //   613: putfield        org/apache/commons/io/input/ReversedLinesFileReader.newLineSequences:[[B
        //   616: aload_0        
        //   617: aload_0        
        //   618: getfield        org/apache/commons/io/input/ReversedLinesFileReader.newLineSequences:[[B
        //   621: iconst_0       
        //   622: aaload         
        //   623: arraylength    
        //   624: putfield        org/apache/commons/io/input/ReversedLinesFileReader.avoidNewlineSplitBufferSize:I
        //   627: aload_0        
        //   628: new             Ljava/io/RandomAccessFile;
        //   631: dup            
        //   632: aload_1        
        //   633: invokestatic    n/d/a/d/q.oj:()Ljava/lang/String;
        //   636: invokespecial   java/io/RandomAccessFile.<init>:(Ljava/io/File;Ljava/lang/String;)V
        //   639: putfield        org/apache/commons/io/input/ReversedLinesFileReader.randomAccessFile:Ljava/io/RandomAccessFile;
        //   642: aload_0        
        //   643: aload_0        
        //   644: getfield        org/apache/commons/io/input/ReversedLinesFileReader.randomAccessFile:Ljava/io/RandomAccessFile;
        //   647: invokestatic    q/o/m/s/q.hl:(Ljava/io/RandomAccessFile;)J
        //   650: putfield        org/apache/commons/io/input/ReversedLinesFileReader.totalByteLength:J
        //   653: aload_0        
        //   654: getfield        org/apache/commons/io/input/ReversedLinesFileReader.totalByteLength:J
        //   657: iload_2        
        //   658: i2l            
        //   659: lrem           
        //   660: l2i            
        //   661: istore          9
        //   663: iload           9
        //   665: aload           4
        //   667: ifnonnull       737
        //   670: ifle            698
        //   673: goto            680
        //   676: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   679: athrow         
        //   680: aload_0        
        //   681: aload_0        
        //   682: getfield        org/apache/commons/io/input/ReversedLinesFileReader.totalByteLength:J
        //   685: iload_2        
        //   686: i2l            
        //   687: ldiv           
        //   688: lconst_1       
        //   689: ladd           
        //   690: putfield        org/apache/commons/io/input/ReversedLinesFileReader.totalBlockCount:J
        //   693: aload           4
        //   695: ifnull          750
        //   698: aload_0        
        //   699: aload_0        
        //   700: getfield        org/apache/commons/io/input/ReversedLinesFileReader.totalByteLength:J
        //   703: iload_2        
        //   704: i2l            
        //   705: ldiv           
        //   706: putfield        org/apache/commons/io/input/ReversedLinesFileReader.totalBlockCount:J
        //   709: aload_0        
        //   710: aload           4
        //   712: ifnonnull       681
        //   715: aload           4
        //   717: ifnonnull       751
        //   720: getfield        org/apache/commons/io/input/ReversedLinesFileReader.totalByteLength:J
        //   723: lconst_0       
        //   724: lcmp           
        //   725: aload           4
        //   727: ifnonnull       748
        //   730: goto            737
        //   733: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   736: athrow         
        //   737: ifle            750
        //   740: goto            747
        //   743: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   746: athrow         
        //   747: iload_2        
        //   748: istore          9
        //   750: aload_0        
        //   751: new             Lorg/apache/commons/io/input/ReversedLinesFileReader$FilePart;
        //   754: dup            
        //   755: aload_0        
        //   756: aload_0        
        //   757: getfield        org/apache/commons/io/input/ReversedLinesFileReader.totalBlockCount:J
        //   760: iload           9
        //   762: aconst_null    
        //   763: aconst_null    
        //   764: invokespecial   org/apache/commons/io/input/ReversedLinesFileReader$FilePart.<init>:(Lorg/apache/commons/io/input/ReversedLinesFileReader;JI[BLorg/apache/commons/io/input/ReversedLinesFileReader$1;)V
        //   767: putfield        org/apache/commons/io/input/ReversedLinesFileReader.currentFilePart:Lorg/apache/commons/io/input/ReversedLinesFileReader$FilePart;
        //   770: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 49 FF 00 39 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 01 07 00 1F 03 49 07 00 1F 03 47 07 00 1F 03 11 4F 07 00 1F 03 4C 07 00 1F 03 55 07 00 1F FF 00 03 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A 47 07 00 1F FF 00 03 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A 45 07 00 1F 03 50 07 00 1F FF 00 03 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A FF 00 04 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A 47 07 00 1F FF 00 03 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A 45 07 00 1F 03 50 07 00 1F FF 00 03 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A FF 00 04 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A 47 07 00 1F FF 00 03 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A 45 07 00 1F 03 50 07 00 1F FF 00 03 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A FF 00 04 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A 47 07 00 1F FF 00 03 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A 45 07 00 1F 03 50 07 00 1F FF 00 03 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A 4A 07 00 1F 03 4C 07 00 1F 03 4C 07 00 1F FF 00 03 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A 47 07 00 1F FF 00 03 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A 45 07 00 1F 03 47 07 00 1F FF 00 03 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A 4A 07 00 1F 03 4C 07 00 1F 03 47 07 00 1F FF 00 03 00 09 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 00 02 07 00 4A 07 00 4A 55 07 00 1F 43 07 00 70 00 3E FF 00 67 00 0A 07 00 02 07 00 48 01 07 00 4A 07 00 4C 00 07 00 4A 07 00 4E 02 01 00 01 07 00 1F 03 40 07 00 02 10 62 07 00 1F 43 01 45 07 00 1F 03 40 01 01 40 07 00 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  44     54     57     61     Ljava/io/IOException;
        //  49     68     71     75     Ljava/io/IOException;
        //  61     80     83     87     Ljava/io/IOException;
        //  105    118    121    125    Ljava/io/IOException;
        //  115    135    138    142    Ljava/io/IOException;
        //  125    161    164    168    Ljava/io/IOException;
        //  142    173    176    180    Ljava/io/IOException;
        //  168    183    186    190    Ljava/io/IOException;
        //  180    204    207    211    Ljava/io/IOException;
        //  211    221    224    228    Ljava/io/IOException;
        //  216    231    234    238    Ljava/io/IOException;
        //  228    252    255    259    Ljava/io/IOException;
        //  259    269    272    276    Ljava/io/IOException;
        //  264    279    282    286    Ljava/io/IOException;
        //  276    300    303    307    Ljava/io/IOException;
        //  307    317    320    324    Ljava/io/IOException;
        //  312    327    330    334    Ljava/io/IOException;
        //  324    348    351    355    Ljava/io/IOException;
        //  355    363    366    370    Ljava/io/IOException;
        //  360    380    383    387    Ljava/io/IOException;
        //  370    397    400    404    Ljava/io/IOException;
        //  387    409    412    416    Ljava/io/IOException;
        //  404    419    422    426    Ljava/io/IOException;
        //  416    431    434    438    Ljava/io/IOException;
        //  438    446    449    453    Ljava/io/IOException;
        //  443    463    466    470    Ljava/io/IOException;
        //  453    475    478    482    Ljava/io/IOException;
        //  482    501    504    508    Ljava/io/IOException;
        //  663    673    676    680    Ljava/io/IOException;
        //  715    730    733    737    Ljava/io/IOException;
        //  720    740    743    747    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0061:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public ReversedLinesFileReader(final File file, final int n, final String s) throws IOException {
        this(file, n, Charsets.toCharset(s));
    }
    
    public String readLine() throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: getfield        org/apache/commons/io/input/ReversedLinesFileReader.currentFilePart:Lorg/apache/commons/io/input/ReversedLinesFileReader$FilePart;
        //     7: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.access$100:(Lorg/apache/commons/io/input/ReversedLinesFileReader$FilePart;)Ljava/lang/String;
        //    10: astore_2       
        //    11: astore_1       
        //    12: aload_2        
        //    13: ifnonnull       75
        //    16: aload_0        
        //    17: aload_0        
        //    18: getfield        org/apache/commons/io/input/ReversedLinesFileReader.currentFilePart:Lorg/apache/commons/io/input/ReversedLinesFileReader$FilePart;
        //    21: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.access$200:(Lorg/apache/commons/io/input/ReversedLinesFileReader$FilePart;)Lorg/apache/commons/io/input/ReversedLinesFileReader$FilePart;
        //    24: putfield        org/apache/commons/io/input/ReversedLinesFileReader.currentFilePart:Lorg/apache/commons/io/input/ReversedLinesFileReader$FilePart;
        //    27: aload_0        
        //    28: aload_1        
        //    29: ifnonnull       112
        //    32: getfield        org/apache/commons/io/input/ReversedLinesFileReader.currentFilePart:Lorg/apache/commons/io/input/ReversedLinesFileReader$FilePart;
        //    35: aload_1        
        //    36: ifnonnull       67
        //    39: goto            46
        //    42: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    45: athrow         
        //    46: ifnull          75
        //    49: goto            56
        //    52: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    55: athrow         
        //    56: aload_0        
        //    57: getfield        org/apache/commons/io/input/ReversedLinesFileReader.currentFilePart:Lorg/apache/commons/io/input/ReversedLinesFileReader$FilePart;
        //    60: goto            67
        //    63: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    66: athrow         
        //    67: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader$FilePart.access$100:(Lorg/apache/commons/io/input/ReversedLinesFileReader$FilePart;)Ljava/lang/String;
        //    70: astore_2       
        //    71: aload_1        
        //    72: ifnull          12
        //    75: invokestatic    n/d/a/d/q.f:()Ljava/lang/String;
        //    78: aload_1        
        //    79: ifnonnull       70
        //    82: aload_1        
        //    83: ifnonnull       151
        //    86: aload_2        
        //    87: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //    90: aload_1        
        //    91: ifnonnull       126
        //    94: goto            101
        //    97: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   100: athrow         
        //   101: ifeq            146
        //   104: goto            111
        //   107: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   110: athrow         
        //   111: aload_0        
        //   112: aload_1        
        //   113: ifnonnull       142
        //   116: getfield        org/apache/commons/io/input/ReversedLinesFileReader.trailingNewlineOfFileSkipped:Z
        //   119: goto            126
        //   122: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   125: athrow         
        //   126: ifne            146
        //   129: aload_0        
        //   130: iconst_1       
        //   131: putfield        org/apache/commons/io/input/ReversedLinesFileReader.trailingNewlineOfFileSkipped:Z
        //   134: aload_0        
        //   135: goto            142
        //   138: invokestatic    org/apache/commons/io/input/ReversedLinesFileReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   141: athrow         
        //   142: invokevirtual   org/apache/commons/io/input/ReversedLinesFileReader.readLine:()Ljava/lang/String;
        //   145: astore_2       
        //   146: aload_2        
        //   147: aload_1        
        //   148: ifnonnull       145
        //   151: areturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 15 FD 00 0C 07 00 4C 07 00 4C 5D 07 00 1F 43 07 00 A8 45 07 00 1F 03 46 07 00 1F 43 07 00 A8 42 07 00 4C 04 55 07 00 1F 43 01 45 07 00 1F 03 40 07 00 02 49 07 00 1F 43 01 4B 07 00 1F 43 07 00 02 42 07 00 4C 00 44 07 00 4C
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  16     39     42     46     Ljava/io/IOException;
        //  32     49     52     56     Ljava/io/IOException;
        //  46     60     63     67     Ljava/io/IOException;
        //  82     94     97     101    Ljava/io/IOException;
        //  86     104    107    111    Ljava/io/IOException;
        //  112    119    122    126    Ljava/io/IOException;
        //  126    135    138    142    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0046:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void close() throws IOException {
        q.hi(this.randomAccessFile);
    }
    
    static int access$300(final ReversedLinesFileReader reversedLinesFileReader) {
        return reversedLinesFileReader.blockSize;
    }
    
    static RandomAccessFile access$400(final ReversedLinesFileReader reversedLinesFileReader) {
        return reversedLinesFileReader.randomAccessFile;
    }
    
    static Charset access$500(final ReversedLinesFileReader reversedLinesFileReader) {
        return reversedLinesFileReader.encoding;
    }
    
    static int access$600(final ReversedLinesFileReader reversedLinesFileReader) {
        return reversedLinesFileReader.avoidNewlineSplitBufferSize;
    }
    
    static int access$700(final ReversedLinesFileReader reversedLinesFileReader) {
        return reversedLinesFileReader.byteDecrement;
    }
    
    static byte[][] access$800(final ReversedLinesFileReader reversedLinesFileReader) {
        return reversedLinesFileReader.newLineSequences;
    }
    
    private static IOException b(final IOException ex) {
        return ex;
    }
    
    static {
        final String[] a2 = new String[10];
        int n = 0;
        String s;
        int n2 = q.q(s = n.d.a.d.q.qd());
        int n3 = 3;
        int n4 = -1;
    Label_0023:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 12));
                ++n4;
                final String s2 = s;
                final int n9 = n4;
                String s3 = q.h(s2, n9, n9 + n3);
                int n10 = -1;
                while (true) {
                    final char[] g = q.g(s3);
                    final int length = g.length;
                    int n11 = 0;
                    while (true) {
                        Label_0260: {
                            if (length > 1) {
                                break Label_0260;
                            }
                            n7 = (n6 = n11);
                            do {
                                final char c = g[n6];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 84;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 105;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 34;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 48;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 11;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 77;
                                        break;
                                    }
                                    default: {
                                        n12 = 45;
                                        break;
                                    }
                                }
                                g[n7] = (char)(c ^ (n5 ^ n12));
                                ++n11;
                            } while (n8 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.z(new String(g));
                    switch (n10) {
                        default: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                continue Label_0023;
                            }
                            n2 = q.q(s = n.d.a.d.q.qb());
                            n3 = 36;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                break;
                            }
                            break Label_0023;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 49)));
                    ++n4;
                    final String s4 = s;
                    final int n13 = n4;
                    s3 = q.h(s4, n13, n13 + n3);
                    n10 = 0;
                }
            }
            break;
        }
        a = a2;
        b = new String[10];
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0xFFFFE73B) & 0xFFFF;
        if (ReversedLinesFileReader.b[n3] == null) {
            final char[] g = q.g(ReversedLinesFileReader.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 171;
                    break;
                }
                case 1: {
                    n4 = 205;
                    break;
                }
                case 2: {
                    n4 = 194;
                    break;
                }
                case 3: {
                    n4 = 247;
                    break;
                }
                case 4: {
                    n4 = 160;
                    break;
                }
                case 5: {
                    n4 = 141;
                    break;
                }
                case 6: {
                    n4 = 21;
                    break;
                }
                case 7: {
                    n4 = 18;
                    break;
                }
                case 8: {
                    n4 = 135;
                    break;
                }
                case 9: {
                    n4 = 162;
                    break;
                }
                case 10: {
                    n4 = 148;
                    break;
                }
                case 11: {
                    n4 = 114;
                    break;
                }
                case 12: {
                    n4 = 217;
                    break;
                }
                case 13: {
                    n4 = 75;
                    break;
                }
                case 14: {
                    n4 = 134;
                    break;
                }
                case 15: {
                    n4 = 80;
                    break;
                }
                case 16: {
                    n4 = 213;
                    break;
                }
                case 17: {
                    n4 = 41;
                    break;
                }
                case 18: {
                    n4 = 156;
                    break;
                }
                case 19: {
                    n4 = 196;
                    break;
                }
                case 20: {
                    n4 = 98;
                    break;
                }
                case 21: {
                    n4 = 228;
                    break;
                }
                case 22: {
                    n4 = 190;
                    break;
                }
                case 23: {
                    n4 = 126;
                    break;
                }
                case 24: {
                    n4 = 172;
                    break;
                }
                case 25: {
                    n4 = 24;
                    break;
                }
                case 26: {
                    n4 = 251;
                    break;
                }
                case 27: {
                    n4 = 179;
                    break;
                }
                case 28: {
                    n4 = 33;
                    break;
                }
                case 29: {
                    n4 = 76;
                    break;
                }
                case 30: {
                    n4 = 176;
                    break;
                }
                case 31: {
                    n4 = 219;
                    break;
                }
                case 32: {
                    n4 = 165;
                    break;
                }
                case 33: {
                    n4 = 100;
                    break;
                }
                case 34: {
                    n4 = 47;
                    break;
                }
                case 35: {
                    n4 = 119;
                    break;
                }
                case 36: {
                    n4 = 153;
                    break;
                }
                case 37: {
                    n4 = 72;
                    break;
                }
                case 38: {
                    n4 = 229;
                    break;
                }
                case 39: {
                    n4 = 23;
                    break;
                }
                case 40: {
                    n4 = 203;
                    break;
                }
                case 41: {
                    n4 = 55;
                    break;
                }
                case 42: {
                    n4 = 242;
                    break;
                }
                case 43: {
                    n4 = 54;
                    break;
                }
                case 44: {
                    n4 = 46;
                    break;
                }
                case 45: {
                    n4 = 151;
                    break;
                }
                case 46: {
                    n4 = 37;
                    break;
                }
                case 47: {
                    n4 = 215;
                    break;
                }
                case 48: {
                    n4 = 192;
                    break;
                }
                case 49: {
                    n4 = 94;
                    break;
                }
                case 50: {
                    n4 = 97;
                    break;
                }
                case 51: {
                    n4 = 122;
                    break;
                }
                case 52: {
                    n4 = 235;
                    break;
                }
                case 53: {
                    n4 = 191;
                    break;
                }
                case 54: {
                    n4 = 92;
                    break;
                }
                case 55: {
                    n4 = 116;
                    break;
                }
                case 56: {
                    n4 = 166;
                    break;
                }
                case 57: {
                    n4 = 56;
                    break;
                }
                case 58: {
                    n4 = 199;
                    break;
                }
                case 59: {
                    n4 = 3;
                    break;
                }
                case 60: {
                    n4 = 227;
                    break;
                }
                case 61: {
                    n4 = 107;
                    break;
                }
                case 62: {
                    n4 = 181;
                    break;
                }
                case 63: {
                    n4 = 147;
                    break;
                }
                case 64: {
                    n4 = 180;
                    break;
                }
                case 65: {
                    n4 = 167;
                    break;
                }
                case 66: {
                    n4 = 109;
                    break;
                }
                case 67: {
                    n4 = 204;
                    break;
                }
                case 68: {
                    n4 = 125;
                    break;
                }
                case 69: {
                    n4 = 86;
                    break;
                }
                case 70: {
                    n4 = 145;
                    break;
                }
                case 71: {
                    n4 = 61;
                    break;
                }
                case 72: {
                    n4 = 22;
                    break;
                }
                case 73: {
                    n4 = 62;
                    break;
                }
                case 74: {
                    n4 = 5;
                    break;
                }
                case 75: {
                    n4 = 193;
                    break;
                }
                case 76: {
                    n4 = 69;
                    break;
                }
                case 77: {
                    n4 = 222;
                    break;
                }
                case 78: {
                    n4 = 81;
                    break;
                }
                case 79: {
                    n4 = 52;
                    break;
                }
                case 80: {
                    n4 = 10;
                    break;
                }
                case 81: {
                    n4 = 169;
                    break;
                }
                case 82: {
                    n4 = 178;
                    break;
                }
                case 83: {
                    n4 = 45;
                    break;
                }
                case 84: {
                    n4 = 64;
                    break;
                }
                case 85: {
                    n4 = 144;
                    break;
                }
                case 86: {
                    n4 = 53;
                    break;
                }
                case 87: {
                    n4 = 234;
                    break;
                }
                case 88: {
                    n4 = 35;
                    break;
                }
                case 89: {
                    n4 = 124;
                    break;
                }
                case 90: {
                    n4 = 139;
                    break;
                }
                case 91: {
                    n4 = 244;
                    break;
                }
                case 92: {
                    n4 = 91;
                    break;
                }
                case 93: {
                    n4 = 28;
                    break;
                }
                case 94: {
                    n4 = 208;
                    break;
                }
                case 95: {
                    n4 = 201;
                    break;
                }
                case 96: {
                    n4 = 223;
                    break;
                }
                case 97: {
                    n4 = 60;
                    break;
                }
                case 98: {
                    n4 = 74;
                    break;
                }
                case 99: {
                    n4 = 36;
                    break;
                }
                case 100: {
                    n4 = 88;
                    break;
                }
                case 101: {
                    n4 = 240;
                    break;
                }
                case 102: {
                    n4 = 29;
                    break;
                }
                case 103: {
                    n4 = 143;
                    break;
                }
                case 104: {
                    n4 = 16;
                    break;
                }
                case 105: {
                    n4 = 103;
                    break;
                }
                case 106: {
                    n4 = 128;
                    break;
                }
                case 107: {
                    n4 = 161;
                    break;
                }
                case 108: {
                    n4 = 59;
                    break;
                }
                case 109: {
                    n4 = 138;
                    break;
                }
                case 110: {
                    n4 = 101;
                    break;
                }
                case 111: {
                    n4 = 142;
                    break;
                }
                case 112: {
                    n4 = 233;
                    break;
                }
                case 113: {
                    n4 = 200;
                    break;
                }
                case 114: {
                    n4 = 83;
                    break;
                }
                case 115: {
                    n4 = 210;
                    break;
                }
                case 116: {
                    n4 = 42;
                    break;
                }
                case 117: {
                    n4 = 236;
                    break;
                }
                case 118: {
                    n4 = 157;
                    break;
                }
                case 119: {
                    n4 = 104;
                    break;
                }
                case 120: {
                    n4 = 77;
                    break;
                }
                case 121: {
                    n4 = 252;
                    break;
                }
                case 122: {
                    n4 = 66;
                    break;
                }
                case 123: {
                    n4 = 174;
                    break;
                }
                case 124: {
                    n4 = 85;
                    break;
                }
                case 125: {
                    n4 = 241;
                    break;
                }
                case 126: {
                    n4 = 78;
                    break;
                }
                case 127: {
                    n4 = 110;
                    break;
                }
                case 128: {
                    n4 = 0;
                    break;
                }
                case 129: {
                    n4 = 26;
                    break;
                }
                case 130: {
                    n4 = 111;
                    break;
                }
                case 131: {
                    n4 = 127;
                    break;
                }
                case 132: {
                    n4 = 182;
                    break;
                }
                case 133: {
                    n4 = 6;
                    break;
                }
                case 134: {
                    n4 = 168;
                    break;
                }
                case 135: {
                    n4 = 123;
                    break;
                }
                case 136: {
                    n4 = 198;
                    break;
                }
                case 137: {
                    n4 = 146;
                    break;
                }
                case 138: {
                    n4 = 177;
                    break;
                }
                case 139: {
                    n4 = 113;
                    break;
                }
                case 140: {
                    n4 = 1;
                    break;
                }
                case 141: {
                    n4 = 129;
                    break;
                }
                case 142: {
                    n4 = 67;
                    break;
                }
                case 143: {
                    n4 = 136;
                    break;
                }
                case 144: {
                    n4 = 197;
                    break;
                }
                case 145: {
                    n4 = 20;
                    break;
                }
                case 146: {
                    n4 = 255;
                    break;
                }
                case 147: {
                    n4 = 243;
                    break;
                }
                case 148: {
                    n4 = 250;
                    break;
                }
                case 149: {
                    n4 = 184;
                    break;
                }
                case 150: {
                    n4 = 90;
                    break;
                }
                case 151: {
                    n4 = 212;
                    break;
                }
                case 152: {
                    n4 = 31;
                    break;
                }
                case 153: {
                    n4 = 17;
                    break;
                }
                case 154: {
                    n4 = 9;
                    break;
                }
                case 155: {
                    n4 = 209;
                    break;
                }
                case 156: {
                    n4 = 99;
                    break;
                }
                case 157: {
                    n4 = 73;
                    break;
                }
                case 158: {
                    n4 = 183;
                    break;
                }
                case 159: {
                    n4 = 70;
                    break;
                }
                case 160: {
                    n4 = 170;
                    break;
                }
                case 161: {
                    n4 = 49;
                    break;
                }
                case 162: {
                    n4 = 63;
                    break;
                }
                case 163: {
                    n4 = 185;
                    break;
                }
                case 164: {
                    n4 = 44;
                    break;
                }
                case 165: {
                    n4 = 154;
                    break;
                }
                case 166: {
                    n4 = 32;
                    break;
                }
                case 167: {
                    n4 = 115;
                    break;
                }
                case 168: {
                    n4 = 58;
                    break;
                }
                case 169: {
                    n4 = 48;
                    break;
                }
                case 170: {
                    n4 = 238;
                    break;
                }
                case 171: {
                    n4 = 149;
                    break;
                }
                case 172: {
                    n4 = 50;
                    break;
                }
                case 173: {
                    n4 = 51;
                    break;
                }
                case 174: {
                    n4 = 225;
                    break;
                }
                case 175: {
                    n4 = 254;
                    break;
                }
                case 176: {
                    n4 = 13;
                    break;
                }
                case 177: {
                    n4 = 218;
                    break;
                }
                case 178: {
                    n4 = 117;
                    break;
                }
                case 179: {
                    n4 = 38;
                    break;
                }
                case 180: {
                    n4 = 89;
                    break;
                }
                case 181: {
                    n4 = 25;
                    break;
                }
                case 182: {
                    n4 = 195;
                    break;
                }
                case 183: {
                    n4 = 230;
                    break;
                }
                case 184: {
                    n4 = 79;
                    break;
                }
                case 185: {
                    n4 = 211;
                    break;
                }
                case 186: {
                    n4 = 57;
                    break;
                }
                case 187: {
                    n4 = 152;
                    break;
                }
                case 188: {
                    n4 = 2;
                    break;
                }
                case 189: {
                    n4 = 245;
                    break;
                }
                case 190: {
                    n4 = 71;
                    break;
                }
                case 191: {
                    n4 = 253;
                    break;
                }
                case 192: {
                    n4 = 187;
                    break;
                }
                case 193: {
                    n4 = 226;
                    break;
                }
                case 194: {
                    n4 = 140;
                    break;
                }
                case 195: {
                    n4 = 207;
                    break;
                }
                case 196: {
                    n4 = 93;
                    break;
                }
                case 197: {
                    n4 = 163;
                    break;
                }
                case 198: {
                    n4 = 173;
                    break;
                }
                case 199: {
                    n4 = 189;
                    break;
                }
                case 200: {
                    n4 = 112;
                    break;
                }
                case 201: {
                    n4 = 118;
                    break;
                }
                case 202: {
                    n4 = 206;
                    break;
                }
                case 203: {
                    n4 = 186;
                    break;
                }
                case 204: {
                    n4 = 40;
                    break;
                }
                case 205: {
                    n4 = 248;
                    break;
                }
                case 206: {
                    n4 = 68;
                    break;
                }
                case 207: {
                    n4 = 220;
                    break;
                }
                case 208: {
                    n4 = 202;
                    break;
                }
                case 209: {
                    n4 = 133;
                    break;
                }
                case 210: {
                    n4 = 231;
                    break;
                }
                case 211: {
                    n4 = 221;
                    break;
                }
                case 212: {
                    n4 = 30;
                    break;
                }
                case 213: {
                    n4 = 214;
                    break;
                }
                case 214: {
                    n4 = 130;
                    break;
                }
                case 215: {
                    n4 = 15;
                    break;
                }
                case 216: {
                    n4 = 27;
                    break;
                }
                case 217: {
                    n4 = 84;
                    break;
                }
                case 218: {
                    n4 = 120;
                    break;
                }
                case 219: {
                    n4 = 102;
                    break;
                }
                case 220: {
                    n4 = 239;
                    break;
                }
                case 221: {
                    n4 = 131;
                    break;
                }
                case 222: {
                    n4 = 105;
                    break;
                }
                case 223: {
                    n4 = 164;
                    break;
                }
                case 224: {
                    n4 = 8;
                    break;
                }
                case 225: {
                    n4 = 12;
                    break;
                }
                case 226: {
                    n4 = 246;
                    break;
                }
                case 227: {
                    n4 = 237;
                    break;
                }
                case 228: {
                    n4 = 14;
                    break;
                }
                case 229: {
                    n4 = 87;
                    break;
                }
                case 230: {
                    n4 = 106;
                    break;
                }
                case 231: {
                    n4 = 39;
                    break;
                }
                case 232: {
                    n4 = 137;
                    break;
                }
                case 233: {
                    n4 = 95;
                    break;
                }
                case 234: {
                    n4 = 249;
                    break;
                }
                case 235: {
                    n4 = 188;
                    break;
                }
                case 236: {
                    n4 = 19;
                    break;
                }
                case 237: {
                    n4 = 43;
                    break;
                }
                case 238: {
                    n4 = 150;
                    break;
                }
                case 239: {
                    n4 = 4;
                    break;
                }
                case 240: {
                    n4 = 224;
                    break;
                }
                case 241: {
                    n4 = 121;
                    break;
                }
                case 242: {
                    n4 = 11;
                    break;
                }
                case 243: {
                    n4 = 155;
                    break;
                }
                case 244: {
                    n4 = 175;
                    break;
                }
                case 245: {
                    n4 = 7;
                    break;
                }
                case 246: {
                    n4 = 34;
                    break;
                }
                case 247: {
                    n4 = 65;
                    break;
                }
                case 248: {
                    n4 = 132;
                    break;
                }
                case 249: {
                    n4 = 82;
                    break;
                }
                case 250: {
                    n4 = 96;
                    break;
                }
                case 251: {
                    n4 = 158;
                    break;
                }
                case 252: {
                    n4 = 108;
                    break;
                }
                case 253: {
                    n4 = 216;
                    break;
                }
                case 254: {
                    n4 = 159;
                    break;
                }
                default: {
                    n4 = 232;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            ReversedLinesFileReader.b[n3] = q.z(new String(g));
        }
        return ReversedLinesFileReader.b[n3];
    }
}
