// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import q.o.m.s.q;
import java.io.IOException;
import java.io.Reader;

public class BoundedReader extends Reader
{
    private static final int INVALID = -1;
    private final Reader target;
    private int charsRead;
    private int markedAt;
    private int readAheadLimit;
    private final int maxCharsFromTargetReader;
    
    public BoundedReader(final Reader target, final int maxCharsFromTargetReader) throws IOException {
        this.charsRead = 0;
        this.markedAt = -1;
        this.target = target;
        this.maxCharsFromTargetReader = maxCharsFromTargetReader;
    }
    
    @Override
    public void close() throws IOException {
        q.xr(this.target);
    }
    
    @Override
    public void reset() throws IOException {
        this.charsRead = this.markedAt;
        q.xs(this.target);
    }
    
    @Override
    public void mark(final int n) throws IOException {
        this.readAheadLimit = n - this.charsRead;
        this.markedAt = this.charsRead;
        q.xk(this.target, n);
    }
    
    @Override
    public int read() throws IOException {
        final String b = ProxyInputStream.b();
        int n3 = 0;
        int n7;
        while (true) {
            Label_0093: {
                int n6 = 0;
                Label_0057: {
                    int n2 = 0;
                    Label_0043: {
                        Label_0035: {
                            int n5 = 0;
                            Label_0026: {
                                int n;
                                try {
                                    n = (n2 = (n3 = this.charsRead));
                                    if (b != null) {
                                        break Label_0043;
                                    }
                                    final BoundedReader boundedReader = this;
                                    final int n4 = boundedReader.maxCharsFromTargetReader;
                                    if (n >= n4) {
                                        break Label_0026;
                                    }
                                    break Label_0035;
                                }
                                catch (IOException ex) {
                                    throw b(ex);
                                }
                                try {
                                    final BoundedReader boundedReader = this;
                                    final int n4 = boundedReader.maxCharsFromTargetReader;
                                    if (n < n4) {
                                        break Label_0035;
                                    }
                                    n5 = -1;
                                }
                                catch (IOException ex2) {
                                    throw b(ex2);
                                }
                            }
                            return n5;
                        }
                        int n5;
                        n2 = (n5 = (n3 = this.markedAt));
                        if (b != null) {
                            return n5;
                        }
                        try {
                            if (b != null) {
                                return n3;
                            }
                            if (n2 >= 0) {
                                break Label_0057;
                            }
                            break Label_0093;
                        }
                        catch (IOException ex3) {
                            throw b(ex3);
                        }
                    }
                    try {
                        if (n2 < 0) {
                            break Label_0093;
                        }
                        n3 = (n6 = this.charsRead - this.markedAt);
                    }
                    catch (IOException ex4) {
                        throw b(ex4);
                    }
                }
                if (b != null) {
                    return n3;
                }
                try {
                    if (n6 < this.readAheadLimit) {
                        break Label_0093;
                    }
                    n7 = -1;
                }
                catch (IOException ex5) {
                    throw b(ex5);
                }
                return n7;
            }
            ++this.charsRead;
            int n6;
            n7 = (n6 = (n3 = q.yg(this.target)));
            if (b != null) {
                continue;
            }
            break;
        }
        if (b != null) {
            return n7;
        }
        return n3;
    }
    
    @Override
    public int read(final char[] p0, final int p1, final int p2) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: iconst_0       
        //     4: istore          6
        //     6: astore          4
        //     8: iload           6
        //    10: iload_3        
        //    11: if_icmpge       89
        //    14: aload_0        
        //    15: invokevirtual   org/apache/commons/io/input/BoundedReader.read:()I
        //    18: istore          5
        //    20: aload           4
        //    22: ifnonnull       84
        //    25: iload           5
        //    27: aload           4
        //    29: ifnonnull       90
        //    32: goto            39
        //    35: invokestatic    org/apache/commons/io/input/BoundedReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    38: athrow         
        //    39: aload           4
        //    41: ifnonnull       71
        //    44: goto            51
        //    47: invokestatic    org/apache/commons/io/input/BoundedReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    50: athrow         
        //    51: iconst_m1      
        //    52: if_icmpne       72
        //    55: goto            62
        //    58: invokestatic    org/apache/commons/io/input/BoundedReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    61: athrow         
        //    62: iload           6
        //    64: goto            71
        //    67: invokestatic    org/apache/commons/io/input/BoundedReader.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    70: athrow         
        //    71: ireturn        
        //    72: aload_1        
        //    73: iload_2        
        //    74: iload           6
        //    76: iadd           
        //    77: iload           5
        //    79: i2c            
        //    80: castore        
        //    81: iinc            6, 1
        //    84: aload           4
        //    86: ifnull          8
        //    89: iload_3        
        //    90: ireturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 0D FE 00 08 07 00 39 00 01 FF 00 1A 00 07 07 00 02 07 00 45 01 01 07 00 39 01 01 00 01 07 00 12 43 01 47 07 00 12 43 01 46 07 00 12 03 44 07 00 12 43 01 00 0B FF 00 04 00 07 07 00 02 07 00 45 01 01 07 00 39 00 01 00 00 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  20     32     35     39     Ljava/io/IOException;
        //  25     44     47     51     Ljava/io/IOException;
        //  39     55     58     62     Ljava/io/IOException;
        //  51     64     67     71     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0039:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static IOException b(final IOException ex) {
        return ex;
    }
}
