// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import java.net.URLConnection;
import q.o.m.s.q;
import java.net.URL;
import java.io.InputStreamReader;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.File;
import java.util.regex.Pattern;
import org.apache.commons.io.ByteOrderMark;
import java.io.Reader;

public class XmlStreamReader extends Reader
{
    private static final int BUFFER_SIZE = 4096;
    private static final String UTF_8;
    private static final String US_ASCII;
    private static final String UTF_16BE;
    private static final String UTF_16LE;
    private static final String UTF_32BE;
    private static final String UTF_32LE;
    private static final String UTF_16;
    private static final String UTF_32;
    private static final String EBCDIC;
    private static final ByteOrderMark[] BOMS;
    private static final ByteOrderMark[] XML_GUESS_BYTES;
    private final Reader reader;
    private final String encoding;
    private final String defaultEncoding;
    private static final Pattern CHARSET_PATTERN;
    public static final Pattern ENCODING_PATTERN;
    private static final String RAW_EX_1;
    private static final String RAW_EX_2;
    private static final String HTTP_EX_1;
    private static final String HTTP_EX_2;
    private static final String HTTP_EX_3;
    private static final String[] a;
    private static final String[] b;
    
    public String getDefaultEncoding() {
        return this.defaultEncoding;
    }
    
    public XmlStreamReader(final File file) throws IOException {
        this(new FileInputStream(file));
    }
    
    public XmlStreamReader(final InputStream inputStream) throws IOException {
        this(inputStream, true);
    }
    
    public XmlStreamReader(final InputStream inputStream, final boolean b) throws IOException {
        this(inputStream, b, null);
    }
    
    public XmlStreamReader(final InputStream in, final boolean b, final String defaultEncoding) throws IOException {
        this.defaultEncoding = defaultEncoding;
        final BOMInputStream bomInputStream = new BOMInputStream(new BufferedInputStream(in, 4096), false, XmlStreamReader.BOMS);
        final BOMInputStream in2 = new BOMInputStream(bomInputStream, true, XmlStreamReader.XML_GUESS_BYTES);
        this.encoding = this.doRawStream(bomInputStream, in2, b);
        this.reader = new InputStreamReader(in2, this.encoding);
    }
    
    public XmlStreamReader(final URL url) throws IOException {
        this(q.nd(url), null);
    }
    
    public XmlStreamReader(final URLConnection p0, final String p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: invokespecial   java/io/Reader.<init>:()V
        //     7: aload_0        
        //     8: aload_2        
        //     9: putfield        org/apache/commons/io/input/XmlStreamReader.defaultEncoding:Ljava/lang/String;
        //    12: iconst_1       
        //    13: istore          4
        //    15: aload_1        
        //    16: invokestatic    q/o/m/s/q.jq:(Ljava/net/URLConnection;)Ljava/lang/String;
        //    19: astore          5
        //    21: aload_1        
        //    22: invokestatic    q/o/m/s/q.na:(Ljava/net/URLConnection;)Ljava/io/InputStream;
        //    25: astore          6
        //    27: new             Lorg/apache/commons/io/input/BOMInputStream;
        //    30: dup            
        //    31: new             Ljava/io/BufferedInputStream;
        //    34: dup            
        //    35: aload           6
        //    37: sipush          4096
        //    40: invokespecial   java/io/BufferedInputStream.<init>:(Ljava/io/InputStream;I)V
        //    43: iconst_0       
        //    44: getstatic       org/apache/commons/io/input/XmlStreamReader.BOMS:[Lorg/apache/commons/io/ByteOrderMark;
        //    47: invokespecial   org/apache/commons/io/input/BOMInputStream.<init>:(Ljava/io/InputStream;Z[Lorg/apache/commons/io/ByteOrderMark;)V
        //    50: astore          7
        //    52: astore_3       
        //    53: new             Lorg/apache/commons/io/input/BOMInputStream;
        //    56: dup            
        //    57: aload           7
        //    59: iconst_1       
        //    60: getstatic       org/apache/commons/io/input/XmlStreamReader.XML_GUESS_BYTES:[Lorg/apache/commons/io/ByteOrderMark;
        //    63: invokespecial   org/apache/commons/io/input/BOMInputStream.<init>:(Ljava/io/InputStream;Z[Lorg/apache/commons/io/ByteOrderMark;)V
        //    66: astore          8
        //    68: aload_3        
        //    69: ifnonnull       120
        //    72: aload_1        
        //    73: instanceof      Ljava/net/HttpURLConnection;
        //    76: ifne            98
        //    79: goto            86
        //    82: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    85: athrow         
        //    86: aload           5
        //    88: ifnull          124
        //    91: goto            98
        //    94: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    97: athrow         
        //    98: aload_0        
        //    99: aload_0        
        //   100: aload           7
        //   102: aload           8
        //   104: aload           5
        //   106: iconst_1       
        //   107: invokespecial   org/apache/commons/io/input/XmlStreamReader.doHttpStream:(Lorg/apache/commons/io/input/BOMInputStream;Lorg/apache/commons/io/input/BOMInputStream;Ljava/lang/String;Z)Ljava/lang/String;
        //   110: goto            117
        //   113: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   116: athrow         
        //   117: putfield        org/apache/commons/io/input/XmlStreamReader.encoding:Ljava/lang/String;
        //   120: aload_3        
        //   121: ifnull          148
        //   124: aload_0        
        //   125: aload_0        
        //   126: aload           7
        //   128: aload           8
        //   130: iconst_1       
        //   131: invokespecial   org/apache/commons/io/input/XmlStreamReader.doRawStream:(Lorg/apache/commons/io/input/BOMInputStream;Lorg/apache/commons/io/input/BOMInputStream;Z)Ljava/lang/String;
        //   134: aload_3        
        //   135: ifnonnull       117
        //   138: goto            145
        //   141: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   144: athrow         
        //   145: putfield        org/apache/commons/io/input/XmlStreamReader.encoding:Ljava/lang/String;
        //   148: aload_0        
        //   149: new             Ljava/io/InputStreamReader;
        //   152: dup            
        //   153: aload           8
        //   155: aload_0        
        //   156: getfield        org/apache/commons/io/input/XmlStreamReader.encoding:Ljava/lang/String;
        //   159: invokespecial   java/io/InputStreamReader.<init>:(Ljava/io/InputStream;Ljava/lang/String;)V
        //   162: putfield        org/apache/commons/io/input/XmlStreamReader.reader:Ljava/io/Reader;
        //   165: invokestatic    com/sun/jna/Structure.b:()I
        //   168: ifeq            190
        //   171: sipush          -27814
        //   174: sipush          -29470
        //   177: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   180: invokestatic    org/apache/commons/io/input/ProxyInputStream.b:(Ljava/lang/String;)V
        //   183: goto            190
        //   186: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   189: athrow         
        //   190: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 0D FF 00 52 00 09 07 00 02 07 00 71 07 00 73 07 00 73 01 07 00 73 07 00 75 07 00 3E 07 00 3E 00 01 07 00 2C 03 47 07 00 2C 03 4E 07 00 2C FF 00 03 00 09 07 00 02 07 00 71 07 00 73 07 00 73 01 07 00 73 07 00 75 07 00 3E 07 00 3E 00 02 07 00 02 07 00 73 02 03 50 07 00 2C FF 00 03 00 09 07 00 02 07 00 71 07 00 73 07 00 73 01 07 00 73 07 00 75 07 00 3E 07 00 3E 00 02 07 00 02 07 00 73 02 65 07 00 2C 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  68     79     82     86     Ljava/io/IOException;
        //  72     91     94     98     Ljava/io/IOException;
        //  86     110    113    117    Ljava/io/IOException;
        //  120    138    141    145    Ljava/io/IOException;
        //  148    183    186    190    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0086:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public XmlStreamReader(final InputStream inputStream, final String s) throws IOException {
        this(inputStream, s, true);
    }
    
    public XmlStreamReader(final InputStream in, final String s, final boolean b, final String defaultEncoding) throws IOException {
        this.defaultEncoding = defaultEncoding;
        final BOMInputStream bomInputStream = new BOMInputStream(new BufferedInputStream(in, 4096), false, XmlStreamReader.BOMS);
        final BOMInputStream in2 = new BOMInputStream(bomInputStream, true, XmlStreamReader.XML_GUESS_BYTES);
        this.encoding = this.doHttpStream(bomInputStream, in2, s, b);
        this.reader = new InputStreamReader(in2, this.encoding);
    }
    
    public XmlStreamReader(final InputStream inputStream, final String s, final boolean b) throws IOException {
        this(inputStream, s, b, null);
    }
    
    public String getEncoding() {
        return this.encoding;
    }
    
    @Override
    public int read(final char[] array, final int n, final int n2) throws IOException {
        return q.yj(this.reader, array, n, n2);
    }
    
    @Override
    public void close() throws IOException {
        q.xr(this.reader);
    }
    
    private String doRawStream(final BOMInputStream bomInputStream, final BOMInputStream bomInputStream2, final boolean b) throws IOException {
        final String bomCharsetName = bomInputStream.getBOMCharsetName();
        final String bomCharsetName2 = bomInputStream2.getBOMCharsetName();
        final String xmlProlog = getXmlProlog(bomInputStream2, bomCharsetName2);
        try {
            return this.calculateRawEncoding(bomCharsetName, bomCharsetName2, xmlProlog);
        }
        catch (XmlStreamReaderException ex) {
            try {
                if (b) {
                    return this.doLenientDetection(null, ex);
                }
            }
            catch (XmlStreamReaderException ex2) {
                throw b(ex2);
            }
            throw ex;
        }
    }
    
    private String doHttpStream(final BOMInputStream bomInputStream, final BOMInputStream bomInputStream2, final String s, final boolean b) throws IOException {
        final String bomCharsetName = bomInputStream.getBOMCharsetName();
        final String bomCharsetName2 = bomInputStream2.getBOMCharsetName();
        final String xmlProlog = getXmlProlog(bomInputStream2, bomCharsetName2);
        try {
            return this.calculateHttpEncoding(s, bomCharsetName, bomCharsetName2, xmlProlog, b);
        }
        catch (XmlStreamReaderException ex) {
            try {
                if (b) {
                    return this.doLenientDetection(s, ex);
                }
            }
            catch (XmlStreamReaderException ex2) {
                throw b(ex2);
            }
            throw ex;
        }
    }
    
    private String doLenientDetection(final String p0, final XmlStreamReaderException p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_3       
        //     4: aload_1        
        //     5: aload_3        
        //     6: ifnonnull       111
        //     9: ifnull          107
        //    12: goto            19
        //    15: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    18: athrow         
        //    19: aload_1        
        //    20: aload_3        
        //    21: ifnonnull       111
        //    24: sipush          -27825
        //    27: sipush          -27182
        //    30: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //    33: invokestatic    q/o/m/s/q.t:(Ljava/lang/String;Ljava/lang/String;)Z
        //    36: ifeq            107
        //    39: aload_1        
        //    40: sipush          -27825
        //    43: sipush          -27182
        //    46: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //    49: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //    52: invokestatic    q/o/m/s/q.pz:(Ljava/lang/String;I)Ljava/lang/String;
        //    55: astore_1       
        //    56: new             Ljava/lang/StringBuilder;
        //    59: dup            
        //    60: invokespecial   java/lang/StringBuilder.<init>:()V
        //    63: sipush          -27815
        //    66: sipush          -26752
        //    69: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //    72: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    75: aload_1        
        //    76: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    79: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    82: astore_1       
        //    83: aload_0        
        //    84: aload_1        
        //    85: aload_2        
        //    86: invokevirtual   org/apache/commons/io/input/XmlStreamReaderException.getBomEncoding:()Ljava/lang/String;
        //    89: aload_2        
        //    90: invokevirtual   org/apache/commons/io/input/XmlStreamReaderException.getXmlGuessEncoding:()Ljava/lang/String;
        //    93: aload_2        
        //    94: invokevirtual   org/apache/commons/io/input/XmlStreamReaderException.getXmlEncoding:()Ljava/lang/String;
        //    97: iconst_1       
        //    98: invokevirtual   org/apache/commons/io/input/XmlStreamReader.calculateHttpEncoding:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;
        //   101: areturn        
        //   102: astore          4
        //   104: aload           4
        //   106: astore_2       
        //   107: aload_2        
        //   108: invokevirtual   org/apache/commons/io/input/XmlStreamReaderException.getXmlEncoding:()Ljava/lang/String;
        //   111: astore          4
        //   113: aload           4
        //   115: aload_3        
        //   116: ifnonnull       20
        //   119: aload_3        
        //   120: ifnonnull       101
        //   123: aload_3        
        //   124: ifnonnull       156
        //   127: ifnonnull       150
        //   130: goto            137
        //   133: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   136: athrow         
        //   137: aload_2        
        //   138: invokevirtual   org/apache/commons/io/input/XmlStreamReaderException.getContentTypeEncoding:()Ljava/lang/String;
        //   141: goto            148
        //   144: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   147: athrow         
        //   148: astore          4
        //   150: aload           4
        //   152: aload_3        
        //   153: ifnonnull       148
        //   156: aload_3        
        //   157: ifnonnull       223
        //   160: ifnonnull       217
        //   163: goto            170
        //   166: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   169: athrow         
        //   170: aload_0        
        //   171: aload_3        
        //   172: ifnonnull       212
        //   175: goto            182
        //   178: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   181: athrow         
        //   182: getfield        org/apache/commons/io/input/XmlStreamReader.defaultEncoding:Ljava/lang/String;
        //   185: goto            192
        //   188: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   191: athrow         
        //   192: aload_3        
        //   193: ifnonnull       208
        //   196: ifnonnull       211
        //   199: sipush          -27779
        //   202: sipush          -31024
        //   205: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   208: goto            215
        //   211: aload_0        
        //   212: getfield        org/apache/commons/io/input/XmlStreamReader.defaultEncoding:Ljava/lang/String;
        //   215: astore          4
        //   217: aload           4
        //   219: aload_3        
        //   220: ifnonnull       192
        //   223: areturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 19 FF 00 0F 00 04 07 00 02 07 00 73 07 00 9B 07 00 73 00 01 07 00 9B 03 40 07 00 73 F7 00 50 07 00 73 40 07 00 9B 04 43 07 00 73 FF 00 15 00 05 07 00 02 07 00 73 07 00 9B 07 00 73 07 00 73 00 01 07 00 9B 03 46 07 00 9B 43 07 00 73 01 45 07 00 73 49 07 00 9B 03 47 07 00 9B 43 07 00 02 45 07 00 9B 43 07 00 73 4F 07 00 73 02 40 07 00 02 42 07 00 73 01 45 07 00 73
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                                  
        //  -----  -----  -----  -----  ------------------------------------------------------
        //  4      12     15     19     Lorg/apache/commons/io/input/XmlStreamReaderException;
        //  83     101    102    107    Lorg/apache/commons/io/input/XmlStreamReaderException;
        //  123    130    133    137    Lorg/apache/commons/io/input/XmlStreamReaderException;
        //  127    141    144    148    Lorg/apache/commons/io/input/XmlStreamReaderException;
        //  156    163    166    170    Lorg/apache/commons/io/input/XmlStreamReaderException;
        //  160    175    178    182    Lorg/apache/commons/io/input/XmlStreamReaderException;
        //  170    185    188    192    Lorg/apache/commons/io/input/XmlStreamReaderException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0170:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    String calculateRawEncoding(final String p0, final String p1, final String p2) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     5: aload_1        
        //     6: aload           4
        //     8: ifnonnull       227
        //    11: ifnonnull       221
        //    14: goto            21
        //    17: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    20: athrow         
        //    21: aload_2        
        //    22: aload           4
        //    24: ifnonnull       79
        //    27: ifnull          46
        //    30: goto            37
        //    33: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    36: athrow         
        //    37: aload_3        
        //    38: aload           4
        //    40: ifnonnull       112
        //    43: ifnonnull       106
        //    46: aload_0        
        //    47: aload           4
        //    49: ifnonnull       102
        //    52: goto            59
        //    55: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    58: athrow         
        //    59: getfield        org/apache/commons/io/input/XmlStreamReader.defaultEncoding:Ljava/lang/String;
        //    62: aload           4
        //    64: ifnonnull       38
        //    67: goto            74
        //    70: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    73: athrow         
        //    74: aload           4
        //    76: ifnonnull       98
        //    79: ifnonnull       101
        //    82: goto            89
        //    85: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    88: athrow         
        //    89: sipush          -27779
        //    92: sipush          -31024
        //    95: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //    98: goto            105
        //   101: aload_0        
        //   102: getfield        org/apache/commons/io/input/XmlStreamReader.defaultEncoding:Ljava/lang/String;
        //   105: areturn        
        //   106: aload_3        
        //   107: aload           4
        //   109: ifnonnull       74
        //   112: aload           4
        //   114: ifnonnull       220
        //   117: sipush          -27810
        //   120: sipush          30261
        //   123: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   126: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   129: ifeq            209
        //   132: goto            139
        //   135: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   138: athrow         
        //   139: aload_2        
        //   140: goto            147
        //   143: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   146: athrow         
        //   147: aload           4
        //   149: ifnonnull       208
        //   152: sipush          -27823
        //   155: sipush          30890
        //   158: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   161: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   164: ifne            195
        //   167: aload_2        
        //   168: goto            175
        //   171: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   174: athrow         
        //   175: aload           4
        //   177: ifnonnull       220
        //   180: sipush          -27791
        //   183: sipush          30746
        //   186: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   189: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   192: ifeq            209
        //   195: aload_2        
        //   196: aload           4
        //   198: ifnonnull       175
        //   201: goto            208
        //   204: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   207: athrow         
        //   208: areturn        
        //   209: aload_3        
        //   210: aload           4
        //   212: ifnonnull       147
        //   215: aload           4
        //   217: ifnonnull       208
        //   220: areturn        
        //   221: aload_1        
        //   222: aload           4
        //   224: ifnonnull       22
        //   227: sipush          -27779
        //   230: sipush          -31024
        //   233: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   236: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   239: aload           4
        //   241: ifnonnull       480
        //   244: ifeq            450
        //   247: goto            254
        //   250: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   253: athrow         
        //   254: aload_2        
        //   255: aload           4
        //   257: ifnonnull       352
        //   260: ifnull          341
        //   263: goto            270
        //   266: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   269: athrow         
        //   270: aload_2        
        //   271: aload           4
        //   273: ifnonnull       352
        //   276: sipush          -27779
        //   279: sipush          -31024
        //   282: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   285: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   288: ifne            341
        //   291: sipush          -27777
        //   294: sipush          11442
        //   297: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   300: iconst_3       
        //   301: anewarray       Ljava/lang/Object;
        //   304: dup            
        //   305: iconst_0       
        //   306: aload_1        
        //   307: aastore        
        //   308: dup            
        //   309: iconst_1       
        //   310: aload_2        
        //   311: aastore        
        //   312: dup            
        //   313: iconst_2       
        //   314: aload_3        
        //   315: aastore        
        //   316: invokestatic    q/o/m/s/q.jt:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //   319: goto            326
        //   322: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   325: athrow         
        //   326: astore          5
        //   328: new             Lorg/apache/commons/io/input/XmlStreamReaderException;
        //   331: dup            
        //   332: aload           5
        //   334: aload_1        
        //   335: aload_2        
        //   336: aload_3        
        //   337: invokespecial   org/apache/commons/io/input/XmlStreamReaderException.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   340: athrow         
        //   341: aload_3        
        //   342: aload           4
        //   344: ifnonnull       271
        //   347: aload           4
        //   349: ifnonnull       326
        //   352: aload           4
        //   354: ifnonnull       449
        //   357: ifnull          438
        //   360: goto            367
        //   363: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   366: athrow         
        //   367: aload_3        
        //   368: aload           4
        //   370: ifnonnull       449
        //   373: sipush          -27779
        //   376: sipush          -31024
        //   379: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   382: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   385: ifne            438
        //   388: sipush          -27777
        //   391: sipush          11442
        //   394: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   397: iconst_3       
        //   398: anewarray       Ljava/lang/Object;
        //   401: dup            
        //   402: iconst_0       
        //   403: aload_1        
        //   404: aastore        
        //   405: dup            
        //   406: iconst_1       
        //   407: aload_2        
        //   408: aastore        
        //   409: dup            
        //   410: iconst_2       
        //   411: aload_3        
        //   412: aastore        
        //   413: invokestatic    q/o/m/s/q.jt:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //   416: goto            423
        //   419: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   422: athrow         
        //   423: astore          5
        //   425: new             Lorg/apache/commons/io/input/XmlStreamReaderException;
        //   428: dup            
        //   429: aload           5
        //   431: aload_1        
        //   432: aload_2        
        //   433: aload_3        
        //   434: invokespecial   org/apache/commons/io/input/XmlStreamReaderException.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   437: athrow         
        //   438: aload_1        
        //   439: aload           4
        //   441: ifnonnull       368
        //   444: aload           4
        //   446: ifnonnull       423
        //   449: areturn        
        //   450: aload_1        
        //   451: aload           4
        //   453: ifnonnull       255
        //   456: aload           4
        //   458: ifnonnull       517
        //   461: sipush          -27823
        //   464: sipush          30890
        //   467: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   470: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   473: goto            480
        //   476: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   479: athrow         
        //   480: ifne            504
        //   483: aload_1        
        //   484: sipush          -27791
        //   487: sipush          30746
        //   490: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   493: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   496: aload           4
        //   498: ifnonnull       759
        //   501: ifeq            729
        //   504: aload_2        
        //   505: aload           4
        //   507: ifnonnull       484
        //   510: goto            517
        //   513: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   516: athrow         
        //   517: aload           4
        //   519: ifnonnull       606
        //   522: ifnull          595
        //   525: goto            532
        //   528: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   531: athrow         
        //   532: aload_2        
        //   533: aload           4
        //   535: ifnonnull       606
        //   538: aload_1        
        //   539: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   542: ifne            595
        //   545: sipush          -27777
        //   548: sipush          11442
        //   551: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   554: iconst_3       
        //   555: anewarray       Ljava/lang/Object;
        //   558: dup            
        //   559: iconst_0       
        //   560: aload_1        
        //   561: aastore        
        //   562: dup            
        //   563: iconst_1       
        //   564: aload_2        
        //   565: aastore        
        //   566: dup            
        //   567: iconst_2       
        //   568: aload_3        
        //   569: aastore        
        //   570: invokestatic    q/o/m/s/q.jt:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //   573: goto            580
        //   576: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   579: athrow         
        //   580: astore          5
        //   582: new             Lorg/apache/commons/io/input/XmlStreamReaderException;
        //   585: dup            
        //   586: aload           5
        //   588: aload_1        
        //   589: aload_2        
        //   590: aload_3        
        //   591: invokespecial   org/apache/commons/io/input/XmlStreamReaderException.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   594: athrow         
        //   595: aload_3        
        //   596: aload           4
        //   598: ifnonnull       533
        //   601: aload           4
        //   603: ifnonnull       580
        //   606: aload           4
        //   608: ifnonnull       728
        //   611: ifnull          712
        //   614: goto            621
        //   617: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   620: athrow         
        //   621: aload_3        
        //   622: aload           4
        //   624: ifnonnull       728
        //   627: sipush          -27810
        //   630: sipush          30261
        //   633: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   636: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   639: ifne            712
        //   642: aload_3        
        //   643: goto            650
        //   646: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   649: athrow         
        //   650: aload           4
        //   652: ifnonnull       728
        //   655: aload_1        
        //   656: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   659: ifne            712
        //   662: sipush          -27777
        //   665: sipush          11442
        //   668: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   671: iconst_3       
        //   672: anewarray       Ljava/lang/Object;
        //   675: dup            
        //   676: iconst_0       
        //   677: aload_1        
        //   678: aastore        
        //   679: dup            
        //   680: iconst_1       
        //   681: aload_2        
        //   682: aastore        
        //   683: dup            
        //   684: iconst_2       
        //   685: aload_3        
        //   686: aastore        
        //   687: invokestatic    q/o/m/s/q.jt:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //   690: goto            697
        //   693: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   696: athrow         
        //   697: astore          5
        //   699: new             Lorg/apache/commons/io/input/XmlStreamReaderException;
        //   702: dup            
        //   703: aload           5
        //   705: aload_1        
        //   706: aload_2        
        //   707: aload_3        
        //   708: invokespecial   org/apache/commons/io/input/XmlStreamReaderException.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   711: athrow         
        //   712: aload_1        
        //   713: aload           4
        //   715: ifnonnull       622
        //   718: aload           4
        //   720: ifnonnull       650
        //   723: aload           4
        //   725: ifnonnull       697
        //   728: areturn        
        //   729: aload_1        
        //   730: aload           4
        //   732: ifnonnull       517
        //   735: aload           4
        //   737: ifnonnull       796
        //   740: sipush          -27786
        //   743: sipush          4686
        //   746: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   749: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   752: goto            759
        //   755: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   758: athrow         
        //   759: ifne            783
        //   762: aload_1        
        //   763: aload           4
        //   765: ifnonnull       1041
        //   768: sipush          -27778
        //   771: sipush          23964
        //   774: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   777: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   780: ifeq            1008
        //   783: aload_2        
        //   784: aload           4
        //   786: ifnonnull       763
        //   789: goto            796
        //   792: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   795: athrow         
        //   796: aload           4
        //   798: ifnonnull       885
        //   801: ifnull          874
        //   804: goto            811
        //   807: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   810: athrow         
        //   811: aload_2        
        //   812: aload           4
        //   814: ifnonnull       885
        //   817: aload_1        
        //   818: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   821: ifne            874
        //   824: sipush          -27777
        //   827: sipush          11442
        //   830: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   833: iconst_3       
        //   834: anewarray       Ljava/lang/Object;
        //   837: dup            
        //   838: iconst_0       
        //   839: aload_1        
        //   840: aastore        
        //   841: dup            
        //   842: iconst_1       
        //   843: aload_2        
        //   844: aastore        
        //   845: dup            
        //   846: iconst_2       
        //   847: aload_3        
        //   848: aastore        
        //   849: invokestatic    q/o/m/s/q.jt:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //   852: goto            859
        //   855: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   858: athrow         
        //   859: astore          5
        //   861: new             Lorg/apache/commons/io/input/XmlStreamReaderException;
        //   864: dup            
        //   865: aload           5
        //   867: aload_1        
        //   868: aload_2        
        //   869: aload_3        
        //   870: invokespecial   org/apache/commons/io/input/XmlStreamReaderException.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   873: athrow         
        //   874: aload_3        
        //   875: aload           4
        //   877: ifnonnull       812
        //   880: aload           4
        //   882: ifnonnull       859
        //   885: aload           4
        //   887: ifnonnull       1007
        //   890: ifnull          991
        //   893: goto            900
        //   896: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   899: athrow         
        //   900: aload_3        
        //   901: aload           4
        //   903: ifnonnull       1007
        //   906: sipush          -27785
        //   909: sipush          3976
        //   912: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   915: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   918: ifne            991
        //   921: aload_3        
        //   922: goto            929
        //   925: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   928: athrow         
        //   929: aload           4
        //   931: ifnonnull       1007
        //   934: aload_1        
        //   935: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   938: ifne            991
        //   941: sipush          -27777
        //   944: sipush          11442
        //   947: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   950: iconst_3       
        //   951: anewarray       Ljava/lang/Object;
        //   954: dup            
        //   955: iconst_0       
        //   956: aload_1        
        //   957: aastore        
        //   958: dup            
        //   959: iconst_1       
        //   960: aload_2        
        //   961: aastore        
        //   962: dup            
        //   963: iconst_2       
        //   964: aload_3        
        //   965: aastore        
        //   966: invokestatic    q/o/m/s/q.jt:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //   969: goto            976
        //   972: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   975: athrow         
        //   976: astore          5
        //   978: new             Lorg/apache/commons/io/input/XmlStreamReaderException;
        //   981: dup            
        //   982: aload           5
        //   984: aload_1        
        //   985: aload_2        
        //   986: aload_3        
        //   987: invokespecial   org/apache/commons/io/input/XmlStreamReaderException.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   990: athrow         
        //   991: aload_1        
        //   992: aload           4
        //   994: ifnonnull       901
        //   997: aload           4
        //   999: ifnonnull       929
        //  1002: aload           4
        //  1004: ifnonnull       976
        //  1007: areturn        
        //  1008: sipush          -27788
        //  1011: sipush          -22843
        //  1014: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //  1017: iconst_3       
        //  1018: anewarray       Ljava/lang/Object;
        //  1021: dup            
        //  1022: iconst_0       
        //  1023: aload_1        
        //  1024: aastore        
        //  1025: dup            
        //  1026: iconst_1       
        //  1027: aload_2        
        //  1028: aastore        
        //  1029: dup            
        //  1030: iconst_2       
        //  1031: aload_3        
        //  1032: aastore        
        //  1033: invokestatic    q/o/m/s/q.jt:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //  1036: aload           4
        //  1038: ifnonnull       796
        //  1041: astore          5
        //  1043: new             Lorg/apache/commons/io/input/XmlStreamReaderException;
        //  1046: dup            
        //  1047: aload           5
        //  1049: aload_1        
        //  1050: aload_2        
        //  1051: aload_3        
        //  1052: invokespecial   org/apache/commons/io/input/XmlStreamReaderException.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //  1055: athrow         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 62 FF 00 11 00 05 07 00 02 07 00 73 07 00 73 07 00 73 07 00 73 00 01 07 00 2C 03 40 07 00 73 4A 07 00 2C 03 40 07 00 73 07 48 07 00 2C 43 07 00 02 4A 07 00 2C 43 07 00 73 44 07 00 73 45 07 00 2C 03 48 07 00 73 02 40 07 00 02 42 07 00 73 00 45 07 00 73 56 07 00 2C 03 43 07 00 2C 43 07 00 73 57 07 00 2C 43 07 00 73 13 48 07 00 2C 43 07 00 73 00 4A 07 00 73 00 45 07 00 73 56 07 00 2C 03 40 07 00 73 4A 07 00 2C 03 40 07 00 73 72 07 00 2C 43 07 00 73 0E 4A 07 00 73 4A 07 00 2C 03 40 07 00 73 72 07 00 2C 43 07 00 73 0E 4A 07 00 73 00 59 07 00 2C 43 01 43 07 00 73 13 48 07 00 2C 43 07 00 73 4A 07 00 2C 03 40 07 00 73 6A 07 00 2C 43 07 00 73 0E 4A 07 00 73 4A 07 00 2C 03 40 07 00 73 57 07 00 2C 43 07 00 73 6A 07 00 2C 43 07 00 73 0E 4F 07 00 73 00 59 07 00 2C 43 01 43 07 00 73 13 48 07 00 2C 43 07 00 73 4A 07 00 2C 03 40 07 00 73 6A 07 00 2C 43 07 00 73 0E 4A 07 00 73 4A 07 00 2C 03 40 07 00 73 57 07 00 2C 43 07 00 73 6A 07 00 2C 43 07 00 73 0E 4F 07 00 73 00 60 07 00 73
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  5      14     17     21     Ljava/io/IOException;
        //  22     30     33     37     Ljava/io/IOException;
        //  43     52     55     59     Ljava/io/IOException;
        //  46     67     70     74     Ljava/io/IOException;
        //  74     82     85     89     Ljava/io/IOException;
        //  112    132    135    139    Ljava/io/IOException;
        //  117    140    143    147    Ljava/io/IOException;
        //  152    168    171    175    Ljava/io/IOException;
        //  180    201    204    208    Ljava/io/IOException;
        //  227    247    250    254    Ljava/io/IOException;
        //  255    263    266    270    Ljava/io/IOException;
        //  276    319    322    326    Ljava/io/IOException;
        //  352    360    363    367    Ljava/io/IOException;
        //  373    416    419    423    Ljava/io/IOException;
        //  456    473    476    480    Ljava/io/IOException;
        //  501    510    513    517    Ljava/io/IOException;
        //  517    525    528    532    Ljava/io/IOException;
        //  538    573    576    580    Ljava/io/IOException;
        //  606    614    617    621    Ljava/io/IOException;
        //  627    643    646    650    Ljava/io/IOException;
        //  655    690    693    697    Ljava/io/IOException;
        //  735    752    755    759    Ljava/io/IOException;
        //  768    789    792    796    Ljava/io/IOException;
        //  796    804    807    811    Ljava/io/IOException;
        //  817    852    855    859    Ljava/io/IOException;
        //  885    893    896    900    Ljava/io/IOException;
        //  906    922    925    929    Ljava/io/IOException;
        //  934    969    972    976    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0046:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    String calculateHttpEncoding(final String s, final String s2, final String s3, final String s4, final boolean b) throws IOException {
        final String b2 = ProxyInputStream.b();
        String s5 = null;
        String s6;
        String s7;
        String contentTypeEncoding;
        boolean appXml;
        while (true) {
            String contentTypeMime = null;
            Label_0034: {
                Label_0030: {
                    try {
                        if (!b) {
                            break Label_0030;
                        }
                        contentTypeMime = s4;
                    }
                    catch (IOException ex) {
                        throw b(ex);
                    }
                    if (b2 != null) {
                        break Label_0034;
                    }
                    if (s5 == null) {
                        break Label_0030;
                    }
                    s6 = s4;
                    return s6;
                }
                contentTypeMime = getContentTypeMime(s);
            }
            s7 = contentTypeMime;
            contentTypeEncoding = getContentTypeEncoding(s);
            appXml = isAppXml(s7);
            s5 = (s6 = (contentTypeMime = s7));
            if (b2 != null) {
                continue;
            }
            break;
        }
        if (b2 != null) {
            return s6;
        }
        final boolean textXml = isTextXml(s5);
        Label_0166: {
            Label_0097: {
                boolean b3 = false;
                Label_0085: {
                    try {
                        b3 = appXml;
                        if (b2 != null) {
                            break Label_0097;
                        }
                        final String s8 = b2;
                        if (s8 == null) {
                            break Label_0085;
                        }
                        break Label_0097;
                    }
                    catch (IOException ex2) {
                        throw b(ex2);
                    }
                    try {
                        final String s8 = b2;
                        if (s8 != null) {
                            break Label_0097;
                        }
                        if (b3) {
                            break Label_0166;
                        }
                    }
                    catch (IOException ex3) {
                        throw b(ex3);
                    }
                }
                try {
                    if (b3) {
                        break Label_0166;
                    }
                    q.jt(a(-27838, 20764), new Object[] { s7, contentTypeEncoding, s2, s3, s4 });
                }
                catch (IOException ex4) {
                    throw b(ex4);
                }
            }
            final String s9;
            throw new XmlStreamReaderException(s9, s7, contentTypeEncoding, s2, s3, s4);
        }
        String s12;
        String s11;
        String s10;
        final String s9 = s10 = (s11 = (s12 = contentTypeEncoding));
        if (b2 == null) {
            Label_0412: {
                String jt4 = null;
                Label_0346: {
                    Label_0331: {
                        boolean th = false;
                        Label_0264: {
                            while (true) {
                                Label_0262: {
                                    try {
                                        if (b2 != null) {
                                            break Label_0264;
                                        }
                                        if (s9 != null) {
                                            break Label_0262;
                                        }
                                    }
                                    catch (IOException ex5) {
                                        throw b(ex5);
                                    }
                                    String s13 = null;
                                    String s14 = null;
                                    Label_0209: {
                                        try {
                                            if (!th) {
                                                break Label_0209;
                                            }
                                            final String calculateRawEncoding = this.calculateRawEncoding(s2, s3, s4);
                                        }
                                        catch (IOException ex6) {
                                            throw b(ex6);
                                        }
                                        return s13;
                                        try {
                                            final XmlStreamReader xmlStreamReader = this;
                                            if (b2 != null) {
                                                return xmlStreamReader.defaultEncoding;
                                            }
                                            s13 = (s14 = this.defaultEncoding);
                                            if (b2 != null) {
                                                return s13;
                                            }
                                        }
                                        catch (IOException ex7) {
                                            throw b(ex7);
                                        }
                                    }
                                    Label_0257: {
                                        try {
                                            if (b2 != null) {
                                                return s14;
                                            }
                                            if (s13 != null) {
                                                break Label_0257;
                                            }
                                        }
                                        catch (IOException ex8) {
                                            throw b(ex8);
                                        }
                                        s14 = a(-27812, -19467);
                                        return s14;
                                    }
                                    final XmlStreamReader xmlStreamReader = this;
                                    s14 = xmlStreamReader.defaultEncoding;
                                    return s14;
                                }
                                s11 = (s10 = (s12 = contentTypeEncoding));
                                try {
                                    if (b2 != null) {
                                        break Label_0331;
                                    }
                                    th = q.th(s10, a(-27823, 30890));
                                    if (b2 != null) {
                                        continue;
                                    }
                                }
                                catch (IOException ex9) {
                                    throw b(ex9);
                                }
                                break;
                            }
                        }
                        Block_16: {
                            Label_0719: {
                                String jt3 = null;
                                Label_0653: {
                                    String s20 = null;
                                    Label_0638: {
                                        boolean b5 = false;
                                        String s21 = null;
                                        Label_0600: {
                                            String s17 = null;
                                        Label_0471_Outer:
                                            while (true) {
                                                Label_0569: {
                                                    Label_0439: {
                                                        Label_0420: {
                                                            Label_0318: {
                                                                if (th) {
                                                                    break Label_0318;
                                                                }
                                                                String s15 = contentTypeEncoding;
                                                                while (true) {
                                                                    final boolean th2;
                                                                    final boolean b4 = th2 = (b5 = q.th(s15, a(-27791, 30746)));
                                                                    if (b2 != null) {
                                                                        break Label_0439;
                                                                    }
                                                                    try {
                                                                        if (!b4) {
                                                                            break Label_0420;
                                                                        }
                                                                        s12 = s2;
                                                                        s11 = s2;
                                                                        s15 = s2;
                                                                        if (b2 != null) {
                                                                            continue Label_0471_Outer;
                                                                        }
                                                                    }
                                                                    catch (IOException ex10) {
                                                                        throw b(ex10);
                                                                    }
                                                                    break;
                                                                }
                                                            }
                                                            break Block_16;
                                                        }
                                                        final String s16 = s11 = (s12 = contentTypeEncoding);
                                                        if (b2 != null) {
                                                            break Label_0331;
                                                        }
                                                        boolean th2;
                                                        b5 = (th2 = q.th(s16, a(-27810, 30261)));
                                                        try {
                                                            if (b2 != null) {
                                                                break Label_0600;
                                                            }
                                                            if (!th2) {
                                                                break Label_0569;
                                                            }
                                                        }
                                                        catch (IOException ex11) {
                                                            throw b(ex11);
                                                        }
                                                    }
                                                    String jt = s2;
                                                    String s19;
                                                    while (true) {
                                                        Label_0500: {
                                                            try {
                                                                if (b2 != null) {
                                                                    throw new XmlStreamReaderException(jt, s7, contentTypeEncoding, s2, s3, s4);
                                                                }
                                                                if (s17 == null) {
                                                                    break Label_0500;
                                                                }
                                                            }
                                                            catch (IOException ex12) {
                                                                throw b(ex12);
                                                            }
                                                            jt = s2;
                                                            final String s18 = s2;
                                                            if (b2 != null) {
                                                                throw new XmlStreamReaderException(jt, s7, contentTypeEncoding, s2, s3, s4);
                                                            }
                                                            try {
                                                                if (!q.t(s18, a(-27810, 30261))) {
                                                                    break Label_0500;
                                                                }
                                                                s19 = s2;
                                                            }
                                                            catch (IOException ex13) {
                                                                throw b(ex13);
                                                            }
                                                            return s19;
                                                        }
                                                        String s18;
                                                        s19 = (s18 = (jt = q.jt(a(-27827, 2385), new Object[] { s7, contentTypeEncoding, s2, s3, s4 })));
                                                        if (b2 != null) {
                                                            continue;
                                                        }
                                                        break;
                                                    }
                                                    if (b2 != null) {
                                                        return s19;
                                                    }
                                                    throw new XmlStreamReaderException(jt, s7, contentTypeEncoding, s2, s3, s4);
                                                }
                                                String jt;
                                                s17 = (jt = (s20 = (s21 = contentTypeEncoding)));
                                                if (b2 != null) {
                                                    continue;
                                                }
                                                break;
                                            }
                                            try {
                                                if (b2 != null) {
                                                    break Label_0638;
                                                }
                                                b5 = q.th(s17, a(-27786, 4686));
                                            }
                                            catch (IOException ex14) {
                                                throw b(ex14);
                                            }
                                        }
                                        Block_26: {
                                            boolean th3 = false;
                                            Label_0758: {
                                                Label_0727: {
                                                    Label_0625: {
                                                        if (b5) {
                                                            break Label_0625;
                                                        }
                                                        String s22 = contentTypeEncoding;
                                                        while (true) {
                                                            th3 = q.th(s22, a(-27778, 23964));
                                                            if (b2 != null) {
                                                                break Label_0758;
                                                            }
                                                            try {
                                                                if (!th3) {
                                                                    break Label_0727;
                                                                }
                                                                s21 = s2;
                                                                s20 = s2;
                                                                s22 = s2;
                                                                if (b2 != null) {
                                                                    continue;
                                                                }
                                                            }
                                                            catch (IOException ex15) {
                                                                throw b(ex15);
                                                            }
                                                            break;
                                                        }
                                                    }
                                                    break Block_26;
                                                }
                                                final String s24;
                                                final String s23 = s20 = (s21 = (s24 = contentTypeEncoding));
                                                if (b2 != null) {
                                                    break Label_0638;
                                                }
                                                try {
                                                    if (b2 != null) {
                                                        return s24;
                                                    }
                                                    q.th(s23, a(-27785, 3976));
                                                }
                                                catch (IOException ex16) {
                                                    throw b(ex16);
                                                }
                                            }
                                            String jt2;
                                            String s25;
                                            if (th3) {
                                                jt2 = s2;
                                                s25 = s2;
                                            }
                                            else {
                                                final String s24;
                                                jt2 = (s25 = (s24 = contentTypeEncoding));
                                                if (b2 == null) {
                                                    return s24;
                                                }
                                            }
                                            String s27;
                                            while (true) {
                                                Label_0807: {
                                                    try {
                                                        if (b2 != null) {
                                                            throw new XmlStreamReaderException(jt2, s7, contentTypeEncoding, s2, s3, s4);
                                                        }
                                                        if (s25 == null) {
                                                            break Label_0807;
                                                        }
                                                    }
                                                    catch (IOException ex17) {
                                                        throw b(ex17);
                                                    }
                                                    jt2 = s2;
                                                    final String s26 = s2;
                                                    if (b2 != null) {
                                                        throw new XmlStreamReaderException(jt2, s7, contentTypeEncoding, s2, s3, s4);
                                                    }
                                                    try {
                                                        if (!q.t(s26, a(-27785, 3976))) {
                                                            break Label_0807;
                                                        }
                                                        s27 = s2;
                                                    }
                                                    catch (IOException ex18) {
                                                        throw b(ex18);
                                                    }
                                                    return s27;
                                                }
                                                String s26;
                                                s27 = (s26 = (jt2 = q.jt(a(-27827, 2385), new Object[] { s7, contentTypeEncoding, s2, s3, s4 })));
                                                if (b2 != null) {
                                                    continue;
                                                }
                                                break;
                                            }
                                            if (b2 != null) {
                                                return s27;
                                            }
                                            throw new XmlStreamReaderException(jt2, s7, contentTypeEncoding, s2, s3, s4);
                                        }
                                        try {
                                            if (b2 != null) {
                                                return s21;
                                            }
                                            if (s20 != null) {
                                                break Label_0653;
                                            }
                                            break Label_0719;
                                        }
                                        catch (IOException ex19) {
                                            throw b(ex19);
                                        }
                                    }
                                    try {
                                        if (s20 == null) {
                                            break Label_0719;
                                        }
                                        jt3 = q.jt(a(-27836, 1479), new Object[] { s7, contentTypeEncoding, s2, s3, s4 });
                                    }
                                    catch (IOException ex20) {
                                        throw b(ex20);
                                    }
                                }
                                throw new XmlStreamReaderException(jt3, s7, contentTypeEncoding, s2, s3, s4);
                            }
                            String jt3;
                            String s21 = jt3 = contentTypeEncoding;
                            if (b2 != null) {
                                throw new XmlStreamReaderException(jt3, s7, contentTypeEncoding, s2, s3, s4);
                            }
                            return s21;
                        }
                        try {
                            if (b2 != null) {
                                return s12;
                            }
                            if (s11 != null) {
                                break Label_0346;
                            }
                            break Label_0412;
                        }
                        catch (IOException ex21) {
                            throw b(ex21);
                        }
                    }
                    try {
                        if (s11 == null) {
                            break Label_0412;
                        }
                        jt4 = q.jt(a(-27836, 1479), new Object[] { s7, contentTypeEncoding, s2, s3, s4 });
                    }
                    catch (IOException ex22) {
                        throw b(ex22);
                    }
                }
                throw new XmlStreamReaderException(jt4, s7, contentTypeEncoding, s2, s3, s4);
            }
            String jt4;
            s12 = (jt4 = contentTypeEncoding);
            if (b2 != null) {
                throw new XmlStreamReaderException(jt4, s7, contentTypeEncoding, s2, s3, s4);
            }
            return s12;
        }
        throw new XmlStreamReaderException(s9, s7, contentTypeEncoding, s2, s3, s4);
    }
    
    static String getContentTypeMime(final String s) {
        final String b = ProxyInputStream.b();
        String qd = null;
        final String s2 = b;
        String s3 = null;
        Label_0033: {
            Label_0022: {
                try {
                    s3 = s;
                    if (s2 != null) {
                        break Label_0033;
                    }
                    final String s4 = s2;
                    if (s4 == null) {
                        break Label_0022;
                    }
                    break Label_0033;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final String s4 = s2;
                    if (s4 != null) {
                        break Label_0033;
                    }
                    if (s == null) {
                        return qd;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            s3 = s;
        }
        final int jr = q.jr(s3, n.d.a.d.q.qi());
        while (true) {
            Label_0061: {
                String h;
                try {
                    if (jr < 0) {
                        break Label_0061;
                    }
                    h = q.h(s, 0, jr);
                }
                catch (RuntimeException ex3) {
                    throw b(ex3);
                }
                final String s5 = h;
                return q.qd(s5);
            }
            String h = s;
            if (s2 != null) {
                continue;
            }
            break;
        }
        final String s5 = s;
        qd = q.qd(s5);
        return qd;
    }
    
    static String getContentTypeEncoding(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aconst_null    
        //     4: astore_2       
        //     5: astore_1       
        //     6: aload_0        
        //     7: aload_1        
        //     8: ifnonnull       33
        //    11: aload_1        
        //    12: ifnonnull       33
        //    15: goto            22
        //    18: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    21: athrow         
        //    22: ifnull          157
        //    25: goto            32
        //    28: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    31: athrow         
        //    32: aload_0        
        //    33: invokestatic    n/d/a/d/q.qi:()Ljava/lang/String;
        //    36: invokestatic    q/o/m/s/q.jr:(Ljava/lang/String;Ljava/lang/String;)I
        //    39: istore_3       
        //    40: iload_3        
        //    41: iconst_m1      
        //    42: if_icmple       157
        //    45: aload_0        
        //    46: iload_3        
        //    47: iconst_1       
        //    48: iadd           
        //    49: invokestatic    q/o/m/s/q.pz:(Ljava/lang/String;I)Ljava/lang/String;
        //    52: astore          4
        //    54: getstatic       org/apache/commons/io/input/XmlStreamReader.CHARSET_PATTERN:Ljava/util/regex/Pattern;
        //    57: aload           4
        //    59: invokestatic    q/o/m/s/q.cu:(Ljava/util/regex/Pattern;Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
        //    62: astore          5
        //    64: aload           5
        //    66: aload_1        
        //    67: ifnonnull       103
        //    70: aload_1        
        //    71: ifnonnull       103
        //    74: goto            81
        //    77: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    80: athrow         
        //    81: invokestatic    q/o/m/s/q.js:(Ljava/util/regex/Matcher;)Z
        //    84: ifeq            110
        //    87: goto            94
        //    90: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    93: athrow         
        //    94: aload           5
        //    96: goto            103
        //    99: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   102: athrow         
        //   103: iconst_1       
        //   104: invokestatic    q/o/m/s/q.jk:(Ljava/util/regex/Matcher;I)Ljava/lang/String;
        //   107: goto            111
        //   110: aconst_null    
        //   111: astore_2       
        //   112: aload_2        
        //   113: aload_1        
        //   114: ifnonnull       152
        //   117: aload_1        
        //   118: ifnonnull       152
        //   121: goto            128
        //   124: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   127: athrow         
        //   128: ifnull          155
        //   131: goto            138
        //   134: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   137: athrow         
        //   138: aload_2        
        //   139: invokestatic    x/dn/g/b/q.c:()Ljava/util/Locale;
        //   142: invokestatic    q/o/m/s/q.je:(Ljava/lang/String;Ljava/util/Locale;)Ljava/lang/String;
        //   145: goto            152
        //   148: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   151: athrow         
        //   152: goto            156
        //   155: aconst_null    
        //   156: astore_2       
        //   157: aload_2        
        //   158: areturn        
        //    StackMapTable: 00 16 FF 00 12 00 03 07 00 73 07 00 73 05 00 01 07 00 F0 43 07 00 73 45 07 00 F0 03 40 07 00 73 FF 00 2B 00 06 07 00 73 07 00 73 05 01 07 00 73 07 01 08 00 01 07 00 F0 43 07 01 08 48 07 00 F0 03 44 07 00 F0 43 07 01 08 06 40 07 00 73 FF 00 0C 00 06 07 00 73 07 00 73 07 00 73 01 07 00 73 07 01 08 00 01 07 00 F0 43 07 00 73 45 07 00 F0 03 49 07 00 F0 43 07 00 73 02 40 07 00 73 F8 00 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  6      15     18     22     Ljava/lang/RuntimeException;
        //  11     25     28     32     Ljava/lang/RuntimeException;
        //  64     74     77     81     Ljava/lang/RuntimeException;
        //  70     87     90     94     Ljava/lang/RuntimeException;
        //  81     96     99     103    Ljava/lang/RuntimeException;
        //  112    121    124    128    Ljava/lang/RuntimeException;
        //  117    131    134    138    Ljava/lang/RuntimeException;
        //  128    145    148    152    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0081:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static String getXmlProlog(final InputStream p0, final String p1) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aconst_null    
        //     4: astore_3       
        //     5: astore_2       
        //     6: aload_1        
        //     7: ifnull          446
        //    10: sipush          4096
        //    13: newarray        B
        //    15: astore          4
        //    17: aload_0        
        //    18: sipush          4096
        //    21: invokestatic    q/o/m/s/q.xm:(Ljava/io/InputStream;I)V
        //    24: iconst_0       
        //    25: istore          5
        //    27: sipush          4096
        //    30: istore          6
        //    32: aload_0        
        //    33: aload           4
        //    35: iload           5
        //    37: iload           6
        //    39: invokestatic    q/o/m/s/q.yn:(Ljava/io/InputStream;[BII)I
        //    42: istore          7
        //    44: iconst_m1      
        //    45: istore          8
        //    47: invokestatic    n/d/a/d/q.f:()Ljava/lang/String;
        //    50: astore          9
        //    52: iload           7
        //    54: iconst_m1      
        //    55: if_icmpeq       159
        //    58: iload           8
        //    60: iconst_m1      
        //    61: aload_2        
        //    62: ifnonnull       173
        //    65: aload_2        
        //    66: ifnonnull       181
        //    69: goto            76
        //    72: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    75: athrow         
        //    76: if_icmpne       159
        //    79: goto            86
        //    82: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    85: athrow         
        //    86: iload           5
        //    88: sipush          4096
        //    91: goto            98
        //    94: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    97: athrow         
        //    98: aload_2        
        //    99: ifnonnull       181
        //   102: if_icmpge       159
        //   105: iload           5
        //   107: iload           7
        //   109: iadd           
        //   110: istore          5
        //   112: iload           6
        //   114: iload           7
        //   116: isub           
        //   117: istore          6
        //   119: aload_0        
        //   120: aload           4
        //   122: iload           5
        //   124: iload           6
        //   126: invokestatic    q/o/m/s/q.yn:(Ljava/io/InputStream;[BII)I
        //   129: istore          7
        //   131: new             Ljava/lang/String;
        //   134: dup            
        //   135: aload           4
        //   137: iconst_0       
        //   138: iload           5
        //   140: aload_1        
        //   141: invokespecial   java/lang/String.<init>:([BIILjava/lang/String;)V
        //   144: astore          9
        //   146: aload           9
        //   148: bipush          62
        //   150: invokestatic    q/o/m/s/q.eu:(Ljava/lang/String;I)I
        //   153: istore          8
        //   155: aload_2        
        //   156: ifnull          52
        //   159: iload           8
        //   161: aload_2        
        //   162: ifnonnull       267
        //   165: iconst_m1      
        //   166: goto            173
        //   169: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   172: athrow         
        //   173: aload_2        
        //   174: ifnonnull       98
        //   177: aload_2        
        //   178: ifnonnull       116
        //   181: if_icmpne       265
        //   184: iload           7
        //   186: iconst_m1      
        //   187: if_icmpne       214
        //   190: new             Ljava/io/IOException;
        //   193: dup            
        //   194: sipush          -27828
        //   197: sipush          3455
        //   200: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   203: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   206: goto            213
        //   209: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   212: athrow         
        //   213: athrow         
        //   214: new             Ljava/io/IOException;
        //   217: dup            
        //   218: new             Ljava/lang/StringBuilder;
        //   221: dup            
        //   222: invokespecial   java/lang/StringBuilder.<init>:()V
        //   225: sipush          -27789
        //   228: sipush          2804
        //   231: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   234: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   237: iload           5
        //   239: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   242: sipush          -27826
        //   245: sipush          1809
        //   248: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   251: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   254: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   257: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   260: aload_2        
        //   261: ifnonnull       213
        //   264: athrow         
        //   265: iload           5
        //   267: istore          10
        //   269: aload_2        
        //   270: ifnonnull       311
        //   273: aload_2        
        //   274: ifnonnull       311
        //   277: goto            284
        //   280: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   283: athrow         
        //   284: iload           10
        //   286: aload_2        
        //   287: ifnonnull       186
        //   290: goto            297
        //   293: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   296: athrow         
        //   297: ifle            446
        //   300: aload_0        
        //   301: invokestatic    q/o/m/s/q.xv:(Ljava/io/InputStream;)V
        //   304: goto            311
        //   307: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   310: athrow         
        //   311: new             Ljava/io/BufferedReader;
        //   314: dup            
        //   315: new             Ljava/io/StringReader;
        //   318: dup            
        //   319: aload           9
        //   321: iconst_0       
        //   322: iload           8
        //   324: iconst_1       
        //   325: iadd           
        //   326: invokestatic    q/o/m/s/q.h:(Ljava/lang/String;II)Ljava/lang/String;
        //   329: invokespecial   java/io/StringReader.<init>:(Ljava/lang/String;)V
        //   332: invokespecial   java/io/BufferedReader.<init>:(Ljava/io/Reader;)V
        //   335: astore          11
        //   337: new             Ljava/lang/StringBuffer;
        //   340: dup            
        //   341: invokespecial   java/lang/StringBuffer.<init>:()V
        //   344: astore          12
        //   346: aload           11
        //   348: invokestatic    q/o/m/s/q.o:(Ljava/io/BufferedReader;)Ljava/lang/String;
        //   351: astore          13
        //   353: aload           13
        //   355: ifnull          377
        //   358: aload           12
        //   360: aload           13
        //   362: invokestatic    q/o/m/s/q.jn:(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/lang/StringBuffer;
        //   365: pop            
        //   366: aload           11
        //   368: invokestatic    q/o/m/s/q.o:(Ljava/io/BufferedReader;)Ljava/lang/String;
        //   371: astore          13
        //   373: aload_2        
        //   374: ifnull          353
        //   377: getstatic       org/apache/commons/io/input/XmlStreamReader.ENCODING_PATTERN:Ljava/util/regex/Pattern;
        //   380: aload           12
        //   382: invokestatic    q/o/m/s/q.cu:(Ljava/util/regex/Pattern;Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
        //   385: astore          14
        //   387: aload           14
        //   389: aload_2        
        //   390: ifnonnull       426
        //   393: aload_2        
        //   394: ifnonnull       426
        //   397: goto            404
        //   400: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   403: athrow         
        //   404: invokestatic    q/o/m/s/q.js:(Ljava/util/regex/Matcher;)Z
        //   407: ifeq            446
        //   410: goto            417
        //   413: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   416: athrow         
        //   417: aload           14
        //   419: goto            426
        //   422: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   425: athrow         
        //   426: iconst_1       
        //   427: invokestatic    q/o/m/s/q.jk:(Ljava/util/regex/Matcher;I)Ljava/lang/String;
        //   430: invokestatic    q/o/m/s/q.sn:(Ljava/lang/String;)Ljava/lang/String;
        //   433: astore_3       
        //   434: aload_3        
        //   435: iconst_1       
        //   436: aload_3        
        //   437: invokestatic    q/o/m/s/q.q:(Ljava/lang/String;)I
        //   440: iconst_1       
        //   441: isub           
        //   442: invokestatic    q/o/m/s/q.h:(Ljava/lang/String;II)Ljava/lang/String;
        //   445: astore_3       
        //   446: aload_3        
        //   447: areturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 21 FF 00 34 00 0A 07 00 75 07 00 73 07 00 73 05 07 01 26 01 01 01 01 07 00 73 00 00 53 07 00 2C FF 00 03 00 0A 07 00 75 07 00 73 07 00 73 05 07 01 26 01 01 01 01 07 00 73 00 02 01 01 45 07 00 2C 03 47 07 00 2C FF 00 03 00 0A 07 00 75 07 00 73 07 00 73 05 07 01 26 01 01 01 01 07 00 73 00 02 01 01 FF 00 11 00 0A 07 00 75 07 00 73 07 00 73 05 07 01 26 01 01 01 01 07 00 73 00 02 01 01 2A 49 07 00 2C FF 00 03 00 0A 07 00 75 07 00 73 07 00 73 05 07 01 26 01 01 01 01 07 00 73 00 02 01 01 FF 00 07 00 0A 07 00 75 07 00 73 07 00 73 05 07 01 26 01 01 01 01 07 00 73 00 02 01 01 44 01 56 07 00 2C 43 07 00 2C 00 32 41 01 FF 00 0C 00 0B 07 00 75 07 00 73 07 00 73 05 07 01 26 01 01 01 01 07 00 73 01 00 01 07 00 2C 03 48 07 00 2C 43 01 49 07 00 2C 03 FE 00 29 07 01 38 07 01 3F 07 00 73 17 FF 00 16 00 0F 07 00 75 07 00 73 07 00 73 05 07 01 26 01 01 01 01 07 00 73 01 07 01 38 07 01 3F 07 00 73 07 01 08 00 01 07 00 2C 43 07 01 08 48 07 00 2C 03 44 07 00 2C 43 07 01 08 FF 00 13 00 04 00 00 00 07 00 73 00 00
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  58     69     72     76     Ljava/io/IOException;
        //  65     79     82     86     Ljava/io/IOException;
        //  76     91     94     98     Ljava/io/IOException;
        //  159    166    169    173    Ljava/io/IOException;
        //  186    206    209    213    Ljava/io/IOException;
        //  269    277    280    284    Ljava/io/IOException;
        //  273    290    293    297    Ljava/io/IOException;
        //  297    304    307    311    Ljava/io/IOException;
        //  387    397    400    404    Ljava/io/IOException;
        //  393    410    413    417    Ljava/io/IOException;
        //  404    419    422    426    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0076:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static boolean isAppXml(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: aload_0        
        //     5: aload_1        
        //     6: ifnonnull       31
        //     9: aload_1        
        //    10: ifnonnull       31
        //    13: goto            20
        //    16: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    19: athrow         
        //    20: ifnull          217
        //    23: goto            30
        //    26: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    29: athrow         
        //    30: aload_0        
        //    31: sipush          -27817
        //    34: sipush          30832
        //    37: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //    40: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //    43: aload_1        
        //    44: ifnonnull       214
        //    47: ifne            194
        //    50: goto            57
        //    53: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    56: athrow         
        //    57: aload_0        
        //    58: sipush          -27839
        //    61: sipush          13976
        //    64: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //    67: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //    70: goto            77
        //    73: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    76: athrow         
        //    77: aload_1        
        //    78: ifnonnull       214
        //    81: ifne            194
        //    84: aload_0        
        //    85: sipush          -27787
        //    88: sipush          -21948
        //    91: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //    94: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //    97: goto            104
        //   100: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   103: athrow         
        //   104: aload_1        
        //   105: ifnonnull       214
        //   108: ifne            194
        //   111: aload_0        
        //   112: sipush          -27830
        //   115: sipush          28193
        //   118: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   121: invokestatic    q/o/m/s/q.t:(Ljava/lang/String;Ljava/lang/String;)Z
        //   124: goto            131
        //   127: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   130: athrow         
        //   131: aload_1        
        //   132: ifnonnull       169
        //   135: aload_1        
        //   136: ifnonnull       173
        //   139: ifeq            217
        //   142: goto            149
        //   145: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   148: athrow         
        //   149: aload_0        
        //   150: sipush          -27792
        //   153: sipush          -5722
        //   156: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   159: invokestatic    q/o/m/s/q.jp:(Ljava/lang/String;Ljava/lang/String;)Z
        //   162: goto            169
        //   165: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   168: athrow         
        //   169: aload_1        
        //   170: ifnonnull       214
        //   173: aload_1        
        //   174: ifnonnull       214
        //   177: goto            184
        //   180: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   183: athrow         
        //   184: ifeq            217
        //   187: goto            194
        //   190: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   193: athrow         
        //   194: iconst_1       
        //   195: aload_1        
        //   196: ifnonnull       77
        //   199: goto            206
        //   202: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   205: athrow         
        //   206: aload_1        
        //   207: ifnonnull       104
        //   210: aload_1        
        //   211: ifnonnull       131
        //   214: goto            218
        //   217: iconst_0       
        //   218: ireturn        
        //    StackMapTable: 00 1B FF 00 10 00 02 07 00 73 07 00 73 00 01 07 00 F0 43 07 00 73 45 07 00 F0 03 40 07 00 73 55 07 00 F0 03 4F 07 00 F0 43 01 56 07 00 F0 43 01 56 07 00 F0 43 01 4D 07 00 F0 03 4F 07 00 F0 43 01 43 01 46 07 00 F0 43 01 45 07 00 F0 03 47 07 00 F0 43 01 47 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      13     16     20     Ljava/lang/RuntimeException;
        //  9      23     26     30     Ljava/lang/RuntimeException;
        //  31     50     53     57     Ljava/lang/RuntimeException;
        //  47     70     73     77     Ljava/lang/RuntimeException;
        //  81     97     100    104    Ljava/lang/RuntimeException;
        //  108    124    127    131    Ljava/lang/RuntimeException;
        //  135    142    145    149    Ljava/lang/RuntimeException;
        //  139    162    165    169    Ljava/lang/RuntimeException;
        //  169    177    180    184    Ljava/lang/RuntimeException;
        //  173    187    190    194    Ljava/lang/RuntimeException;
        //  184    199    202    206    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0173:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static boolean isTextXml(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: aload_0        
        //     5: aload_1        
        //     6: ifnonnull       31
        //     9: aload_1        
        //    10: ifnonnull       31
        //    13: goto            20
        //    16: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    19: athrow         
        //    20: ifnull          186
        //    23: goto            30
        //    26: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    29: athrow         
        //    30: aload_0        
        //    31: sipush          -27815
        //    34: sipush          -26752
        //    37: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //    40: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //    43: aload_1        
        //    44: ifnonnull       183
        //    47: ifne            167
        //    50: goto            57
        //    53: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    56: athrow         
        //    57: aload_0        
        //    58: sipush          -27837
        //    61: sipush          26717
        //    64: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //    67: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //    70: goto            77
        //    73: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    76: athrow         
        //    77: aload_1        
        //    78: ifnonnull       183
        //    81: ifne            167
        //    84: aload_0        
        //    85: sipush          -27790
        //    88: sipush          4343
        //    91: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //    94: invokestatic    q/o/m/s/q.t:(Ljava/lang/String;Ljava/lang/String;)Z
        //    97: goto            104
        //   100: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   103: athrow         
        //   104: aload_1        
        //   105: ifnonnull       142
        //   108: aload_1        
        //   109: ifnonnull       146
        //   112: ifeq            186
        //   115: goto            122
        //   118: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   121: athrow         
        //   122: aload_0        
        //   123: sipush          -27792
        //   126: sipush          -5722
        //   129: invokestatic    org/apache/commons/io/input/XmlStreamReader.a:(II)Ljava/lang/String;
        //   132: invokestatic    q/o/m/s/q.jp:(Ljava/lang/String;Ljava/lang/String;)Z
        //   135: goto            142
        //   138: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   141: athrow         
        //   142: aload_1        
        //   143: ifnonnull       183
        //   146: aload_1        
        //   147: ifnonnull       183
        //   150: goto            157
        //   153: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   156: athrow         
        //   157: ifeq            186
        //   160: goto            167
        //   163: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   166: athrow         
        //   167: iconst_1       
        //   168: aload_1        
        //   169: ifnonnull       77
        //   172: goto            179
        //   175: invokestatic    org/apache/commons/io/input/XmlStreamReader.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   178: athrow         
        //   179: aload_1        
        //   180: ifnonnull       104
        //   183: goto            187
        //   186: iconst_0       
        //   187: ireturn        
        //    StackMapTable: 00 19 FF 00 10 00 02 07 00 73 07 00 73 00 01 07 00 F0 43 07 00 73 45 07 00 F0 03 40 07 00 73 55 07 00 F0 03 4F 07 00 F0 43 01 56 07 00 F0 43 01 4D 07 00 F0 03 4F 07 00 F0 43 01 43 01 46 07 00 F0 43 01 45 07 00 F0 03 47 07 00 F0 43 01 43 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      13     16     20     Ljava/lang/RuntimeException;
        //  9      23     26     30     Ljava/lang/RuntimeException;
        //  31     50     53     57     Ljava/lang/RuntimeException;
        //  47     70     73     77     Ljava/lang/RuntimeException;
        //  81     97     100    104    Ljava/lang/RuntimeException;
        //  108    115    118    122    Ljava/lang/RuntimeException;
        //  112    135    138    142    Ljava/lang/RuntimeException;
        //  142    150    153    157    Ljava/lang/RuntimeException;
        //  146    160    163    167    Ljava/lang/RuntimeException;
        //  157    172    175    179    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0146:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        final String[] a2 = new String[43];
        int n = 0;
        String s;
        int n2 = q.q(s = n.d.a.d.q.qu());
        int n3 = 15;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 92));
                ++n4;
                final String s2 = s;
                final int n9 = n4;
                String s3 = q.h(s2, n9, n9 + n3);
                int n10 = -1;
                while (true) {
                    final char[] g = q.g(s3);
                    final int length = g.length;
                    int n11 = 0;
                    while (true) {
                        Label_0432: {
                            if (length > 1) {
                                break Label_0432;
                            }
                            n7 = (n6 = n11);
                            do {
                                final char c = g[n6];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 13;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 82;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 122;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 15;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 23;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 41;
                                        break;
                                    }
                                    default: {
                                        n12 = 102;
                                        break;
                                    }
                                }
                                g[n7] = (char)(c ^ (n5 ^ n12));
                                ++n11;
                            } while (n8 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.z(new String(g));
                    switch (n10) {
                        default: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                continue Label_0024;
                            }
                            n2 = q.q(s = n.d.a.d.q.tf());
                            n3 = 8;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 12)));
                    ++n4;
                    final String s4 = s;
                    final int n13 = n4;
                    s3 = q.h(s4, n13, n13 + n3);
                    n10 = 0;
                }
            }
            break;
        }
        a = a2;
        b = new String[43];
        UTF_32LE = a(-27778, 23964);
        UTF_16BE = a(-27823, 30890);
        UTF_8 = a(-27840, 19452);
        RAW_EX_1 = a(-27777, 11442);
        UTF_16 = a(-27809, -32171);
        US_ASCII = a(-27812, -19467);
        UTF_32 = a(-27820, 29999);
        HTTP_EX_3 = a(-27821, 1693);
        RAW_EX_2 = a(-27832, 28718);
        HTTP_EX_2 = a(-27827, 2385);
        EBCDIC = a(-27833, 25639);
        UTF_32BE = a(-27786, 4686);
        UTF_16LE = a(-27813, 14705);
        HTTP_EX_1 = a(-27836, 1479);
        BOMS = new ByteOrderMark[] { ByteOrderMark.UTF_8, ByteOrderMark.UTF_16BE, ByteOrderMark.UTF_16LE, ByteOrderMark.UTF_32BE, ByteOrderMark.UTF_32LE };
        XML_GUESS_BYTES = new ByteOrderMark[] { new ByteOrderMark(a(-27779, -31024), new int[] { 60, 63, 120, 109 }), new ByteOrderMark(a(-27823, 30890), new int[] { 0, 60, 0, 63 }), new ByteOrderMark(a(-27791, 30746), new int[] { 60, 0, 63, 0 }), new ByteOrderMark(a(-27786, 4686), new int[] { 0, 0, 0, 60, 0, 0, 0, 63, 0, 0, 0, 120, 0, 0, 0, 109 }), new ByteOrderMark(a(-27778, 23964), new int[] { 60, 0, 0, 0, 63, 0, 0, 0, 120, 0, 0, 0, 109, 0, 0, 0 }), new ByteOrderMark(a(-27835, -3801), new int[] { 76, 111, 167, 148 }) };
        CHARSET_PATTERN = q.cl(a(-27822, -24558));
        ENCODING_PATTERN = q.ci(a(-27819, -1358), 8);
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0xFFFF9357) & 0xFFFF;
        if (XmlStreamReader.b[n3] == null) {
            final char[] g = q.g(XmlStreamReader.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 128;
                    break;
                }
                case 1: {
                    n4 = 249;
                    break;
                }
                case 2: {
                    n4 = 150;
                    break;
                }
                case 3: {
                    n4 = 136;
                    break;
                }
                case 4: {
                    n4 = 103;
                    break;
                }
                case 5: {
                    n4 = 84;
                    break;
                }
                case 6: {
                    n4 = 91;
                    break;
                }
                case 7: {
                    n4 = 95;
                    break;
                }
                case 8: {
                    n4 = 132;
                    break;
                }
                case 9: {
                    n4 = 216;
                    break;
                }
                case 10: {
                    n4 = 23;
                    break;
                }
                case 11: {
                    n4 = 22;
                    break;
                }
                case 12: {
                    n4 = 242;
                    break;
                }
                case 13: {
                    n4 = 250;
                    break;
                }
                case 14: {
                    n4 = 246;
                    break;
                }
                case 15: {
                    n4 = 5;
                    break;
                }
                case 16: {
                    n4 = 101;
                    break;
                }
                case 17: {
                    n4 = 234;
                    break;
                }
                case 18: {
                    n4 = 230;
                    break;
                }
                case 19: {
                    n4 = 77;
                    break;
                }
                case 20: {
                    n4 = 172;
                    break;
                }
                case 21: {
                    n4 = 86;
                    break;
                }
                case 22: {
                    n4 = 56;
                    break;
                }
                case 23: {
                    n4 = 74;
                    break;
                }
                case 24: {
                    n4 = 143;
                    break;
                }
                case 25: {
                    n4 = 70;
                    break;
                }
                case 26: {
                    n4 = 170;
                    break;
                }
                case 27: {
                    n4 = 204;
                    break;
                }
                case 28: {
                    n4 = 158;
                    break;
                }
                case 29: {
                    n4 = 210;
                    break;
                }
                case 30: {
                    n4 = 222;
                    break;
                }
                case 31: {
                    n4 = 119;
                    break;
                }
                case 32: {
                    n4 = 166;
                    break;
                }
                case 33: {
                    n4 = 34;
                    break;
                }
                case 34: {
                    n4 = 120;
                    break;
                }
                case 35: {
                    n4 = 218;
                    break;
                }
                case 36: {
                    n4 = 137;
                    break;
                }
                case 37: {
                    n4 = 61;
                    break;
                }
                case 38: {
                    n4 = 200;
                    break;
                }
                case 39: {
                    n4 = 117;
                    break;
                }
                case 40: {
                    n4 = 65;
                    break;
                }
                case 41: {
                    n4 = 43;
                    break;
                }
                case 42: {
                    n4 = 155;
                    break;
                }
                case 43: {
                    n4 = 112;
                    break;
                }
                case 44: {
                    n4 = 11;
                    break;
                }
                case 45: {
                    n4 = 229;
                    break;
                }
                case 46: {
                    n4 = 198;
                    break;
                }
                case 47: {
                    n4 = 24;
                    break;
                }
                case 48: {
                    n4 = 28;
                    break;
                }
                case 49: {
                    n4 = 183;
                    break;
                }
                case 50: {
                    n4 = 58;
                    break;
                }
                case 51: {
                    n4 = 25;
                    break;
                }
                case 52: {
                    n4 = 225;
                    break;
                }
                case 53: {
                    n4 = 55;
                    break;
                }
                case 54: {
                    n4 = 100;
                    break;
                }
                case 55: {
                    n4 = 171;
                    break;
                }
                case 56: {
                    n4 = 75;
                    break;
                }
                case 57: {
                    n4 = 241;
                    break;
                }
                case 58: {
                    n4 = 165;
                    break;
                }
                case 59: {
                    n4 = 98;
                    break;
                }
                case 60: {
                    n4 = 21;
                    break;
                }
                case 61: {
                    n4 = 167;
                    break;
                }
                case 62: {
                    n4 = 179;
                    break;
                }
                case 63: {
                    n4 = 140;
                    break;
                }
                case 64: {
                    n4 = 26;
                    break;
                }
                case 65: {
                    n4 = 53;
                    break;
                }
                case 66: {
                    n4 = 131;
                    break;
                }
                case 67: {
                    n4 = 33;
                    break;
                }
                case 68: {
                    n4 = 116;
                    break;
                }
                case 69: {
                    n4 = 17;
                    break;
                }
                case 70: {
                    n4 = 0;
                    break;
                }
                case 71: {
                    n4 = 67;
                    break;
                }
                case 72: {
                    n4 = 135;
                    break;
                }
                case 73: {
                    n4 = 189;
                    break;
                }
                case 74: {
                    n4 = 63;
                    break;
                }
                case 75: {
                    n4 = 31;
                    break;
                }
                case 76: {
                    n4 = 2;
                    break;
                }
                case 77: {
                    n4 = 82;
                    break;
                }
                case 78: {
                    n4 = 96;
                    break;
                }
                case 79: {
                    n4 = 191;
                    break;
                }
                case 80: {
                    n4 = 181;
                    break;
                }
                case 81: {
                    n4 = 104;
                    break;
                }
                case 82: {
                    n4 = 133;
                    break;
                }
                case 83: {
                    n4 = 8;
                    break;
                }
                case 84: {
                    n4 = 207;
                    break;
                }
                case 85: {
                    n4 = 185;
                    break;
                }
                case 86: {
                    n4 = 186;
                    break;
                }
                case 87: {
                    n4 = 111;
                    break;
                }
                case 88: {
                    n4 = 30;
                    break;
                }
                case 89: {
                    n4 = 88;
                    break;
                }
                case 90: {
                    n4 = 51;
                    break;
                }
                case 91: {
                    n4 = 253;
                    break;
                }
                case 92: {
                    n4 = 153;
                    break;
                }
                case 93: {
                    n4 = 38;
                    break;
                }
                case 94: {
                    n4 = 64;
                    break;
                }
                case 95: {
                    n4 = 126;
                    break;
                }
                case 96: {
                    n4 = 231;
                    break;
                }
                case 97: {
                    n4 = 107;
                    break;
                }
                case 98: {
                    n4 = 93;
                    break;
                }
                case 99: {
                    n4 = 134;
                    break;
                }
                case 100: {
                    n4 = 76;
                    break;
                }
                case 101: {
                    n4 = 35;
                    break;
                }
                case 102: {
                    n4 = 113;
                    break;
                }
                case 103: {
                    n4 = 3;
                    break;
                }
                case 104: {
                    n4 = 110;
                    break;
                }
                case 105: {
                    n4 = 161;
                    break;
                }
                case 106: {
                    n4 = 41;
                    break;
                }
                case 107: {
                    n4 = 94;
                    break;
                }
                case 108: {
                    n4 = 50;
                    break;
                }
                case 109: {
                    n4 = 42;
                    break;
                }
                case 110: {
                    n4 = 115;
                    break;
                }
                case 111: {
                    n4 = 106;
                    break;
                }
                case 112: {
                    n4 = 4;
                    break;
                }
                case 113: {
                    n4 = 209;
                    break;
                }
                case 114: {
                    n4 = 221;
                    break;
                }
                case 115: {
                    n4 = 236;
                    break;
                }
                case 116: {
                    n4 = 16;
                    break;
                }
                case 117: {
                    n4 = 194;
                    break;
                }
                case 118: {
                    n4 = 238;
                    break;
                }
                case 119: {
                    n4 = 220;
                    break;
                }
                case 120: {
                    n4 = 228;
                    break;
                }
                case 121: {
                    n4 = 202;
                    break;
                }
                case 122: {
                    n4 = 99;
                    break;
                }
                case 123: {
                    n4 = 208;
                    break;
                }
                case 124: {
                    n4 = 69;
                    break;
                }
                case 125: {
                    n4 = 147;
                    break;
                }
                case 126: {
                    n4 = 245;
                    break;
                }
                case 127: {
                    n4 = 40;
                    break;
                }
                case 128: {
                    n4 = 44;
                    break;
                }
                case 129: {
                    n4 = 89;
                    break;
                }
                case 130: {
                    n4 = 182;
                    break;
                }
                case 131: {
                    n4 = 47;
                    break;
                }
                case 132: {
                    n4 = 247;
                    break;
                }
                case 133: {
                    n4 = 122;
                    break;
                }
                case 134: {
                    n4 = 196;
                    break;
                }
                case 135: {
                    n4 = 232;
                    break;
                }
                case 136: {
                    n4 = 227;
                    break;
                }
                case 137: {
                    n4 = 83;
                    break;
                }
                case 138: {
                    n4 = 49;
                    break;
                }
                case 139: {
                    n4 = 175;
                    break;
                }
                case 140: {
                    n4 = 118;
                    break;
                }
                case 141: {
                    n4 = 59;
                    break;
                }
                case 142: {
                    n4 = 79;
                    break;
                }
                case 143: {
                    n4 = 20;
                    break;
                }
                case 144: {
                    n4 = 201;
                    break;
                }
                case 145: {
                    n4 = 18;
                    break;
                }
                case 146: {
                    n4 = 199;
                    break;
                }
                case 147: {
                    n4 = 146;
                    break;
                }
                case 148: {
                    n4 = 81;
                    break;
                }
                case 149: {
                    n4 = 193;
                    break;
                }
                case 150: {
                    n4 = 6;
                    break;
                }
                case 151: {
                    n4 = 145;
                    break;
                }
                case 152: {
                    n4 = 12;
                    break;
                }
                case 153: {
                    n4 = 156;
                    break;
                }
                case 154: {
                    n4 = 223;
                    break;
                }
                case 155: {
                    n4 = 233;
                    break;
                }
                case 156: {
                    n4 = 71;
                    break;
                }
                case 157: {
                    n4 = 13;
                    break;
                }
                case 158: {
                    n4 = 130;
                    break;
                }
                case 159: {
                    n4 = 45;
                    break;
                }
                case 160: {
                    n4 = 124;
                    break;
                }
                case 161: {
                    n4 = 244;
                    break;
                }
                case 162: {
                    n4 = 90;
                    break;
                }
                case 163: {
                    n4 = 174;
                    break;
                }
                case 164: {
                    n4 = 127;
                    break;
                }
                case 165: {
                    n4 = 10;
                    break;
                }
                case 166: {
                    n4 = 87;
                    break;
                }
                case 167: {
                    n4 = 178;
                    break;
                }
                case 168: {
                    n4 = 219;
                    break;
                }
                case 169: {
                    n4 = 215;
                    break;
                }
                case 170: {
                    n4 = 251;
                    break;
                }
                case 171: {
                    n4 = 226;
                    break;
                }
                case 172: {
                    n4 = 224;
                    break;
                }
                case 173: {
                    n4 = 19;
                    break;
                }
                case 174: {
                    n4 = 129;
                    break;
                }
                case 175: {
                    n4 = 32;
                    break;
                }
                case 176: {
                    n4 = 142;
                    break;
                }
                case 177: {
                    n4 = 197;
                    break;
                }
                case 178: {
                    n4 = 78;
                    break;
                }
                case 179: {
                    n4 = 9;
                    break;
                }
                case 180: {
                    n4 = 173;
                    break;
                }
                case 181: {
                    n4 = 138;
                    break;
                }
                case 182: {
                    n4 = 85;
                    break;
                }
                case 183: {
                    n4 = 149;
                    break;
                }
                case 184: {
                    n4 = 151;
                    break;
                }
                case 185: {
                    n4 = 235;
                    break;
                }
                case 186: {
                    n4 = 72;
                    break;
                }
                case 187: {
                    n4 = 54;
                    break;
                }
                case 188: {
                    n4 = 36;
                    break;
                }
                case 189: {
                    n4 = 188;
                    break;
                }
                case 190: {
                    n4 = 37;
                    break;
                }
                case 191: {
                    n4 = 102;
                    break;
                }
                case 192: {
                    n4 = 39;
                    break;
                }
                case 193: {
                    n4 = 168;
                    break;
                }
                case 194: {
                    n4 = 148;
                    break;
                }
                case 195: {
                    n4 = 237;
                    break;
                }
                case 196: {
                    n4 = 1;
                    break;
                }
                case 197: {
                    n4 = 162;
                    break;
                }
                case 198: {
                    n4 = 46;
                    break;
                }
                case 199: {
                    n4 = 144;
                    break;
                }
                case 200: {
                    n4 = 164;
                    break;
                }
                case 201: {
                    n4 = 195;
                    break;
                }
                case 202: {
                    n4 = 121;
                    break;
                }
                case 203: {
                    n4 = 248;
                    break;
                }
                case 204: {
                    n4 = 92;
                    break;
                }
                case 205: {
                    n4 = 109;
                    break;
                }
                case 206: {
                    n4 = 160;
                    break;
                }
                case 207: {
                    n4 = 254;
                    break;
                }
                case 208: {
                    n4 = 255;
                    break;
                }
                case 209: {
                    n4 = 125;
                    break;
                }
                case 210: {
                    n4 = 211;
                    break;
                }
                case 211: {
                    n4 = 206;
                    break;
                }
                case 212: {
                    n4 = 105;
                    break;
                }
                case 213: {
                    n4 = 57;
                    break;
                }
                case 214: {
                    n4 = 176;
                    break;
                }
                case 215: {
                    n4 = 73;
                    break;
                }
                case 216: {
                    n4 = 14;
                    break;
                }
                case 217: {
                    n4 = 203;
                    break;
                }
                case 218: {
                    n4 = 157;
                    break;
                }
                case 219: {
                    n4 = 192;
                    break;
                }
                case 220: {
                    n4 = 213;
                    break;
                }
                case 221: {
                    n4 = 214;
                    break;
                }
                case 222: {
                    n4 = 27;
                    break;
                }
                case 223: {
                    n4 = 114;
                    break;
                }
                case 224: {
                    n4 = 48;
                    break;
                }
                case 225: {
                    n4 = 180;
                    break;
                }
                case 226: {
                    n4 = 240;
                    break;
                }
                case 227: {
                    n4 = 15;
                    break;
                }
                case 228: {
                    n4 = 139;
                    break;
                }
                case 229: {
                    n4 = 205;
                    break;
                }
                case 230: {
                    n4 = 252;
                    break;
                }
                case 231: {
                    n4 = 217;
                    break;
                }
                case 232: {
                    n4 = 159;
                    break;
                }
                case 233: {
                    n4 = 29;
                    break;
                }
                case 234: {
                    n4 = 60;
                    break;
                }
                case 235: {
                    n4 = 62;
                    break;
                }
                case 236: {
                    n4 = 239;
                    break;
                }
                case 237: {
                    n4 = 68;
                    break;
                }
                case 238: {
                    n4 = 141;
                    break;
                }
                case 239: {
                    n4 = 123;
                    break;
                }
                case 240: {
                    n4 = 243;
                    break;
                }
                case 241: {
                    n4 = 66;
                    break;
                }
                case 242: {
                    n4 = 108;
                    break;
                }
                case 243: {
                    n4 = 187;
                    break;
                }
                case 244: {
                    n4 = 169;
                    break;
                }
                case 245: {
                    n4 = 190;
                    break;
                }
                case 246: {
                    n4 = 52;
                    break;
                }
                case 247: {
                    n4 = 154;
                    break;
                }
                case 248: {
                    n4 = 184;
                    break;
                }
                case 249: {
                    n4 = 97;
                    break;
                }
                case 250: {
                    n4 = 80;
                    break;
                }
                case 251: {
                    n4 = 7;
                    break;
                }
                case 252: {
                    n4 = 152;
                    break;
                }
                case 253: {
                    n4 = 163;
                    break;
                }
                case 254: {
                    n4 = 212;
                    break;
                }
                default: {
                    n4 = 177;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            XmlStreamReader.b[n3] = q.z(new String(g));
        }
        return XmlStreamReader.b[n3];
    }
}
