// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import org.apache.commons.io.ByteOrderMark;
import java.util.Comparator;

final class BOMInputStream$1 implements Comparator<ByteOrderMark>
{
    @Override
    public int compare(final ByteOrderMark byteOrderMark, final ByteOrderMark byteOrderMark2) {
        final String b = ProxyInputStream.b();
        final int length = byteOrderMark.length();
        final int length2 = byteOrderMark2.length();
        final String s = b;
        int n = 0;
        int n2 = 0;
        Label_0055: {
            Label_0036: {
                try {
                    n = length;
                    n2 = length2;
                    if (s != null) {
                        break Label_0055;
                    }
                    if (n <= n2) {
                        break Label_0036;
                    }
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                return -1;
            }
            final int n4;
            final int n3 = n4 = length2;
            if (s != null) {
                return n3;
            }
            try {
                if (s != null) {
                    return n4;
                }
            }
            catch (RuntimeException ex2) {
                throw b(ex2);
            }
        }
        int n5;
        if (n > n2) {
            n5 = 1;
        }
        else {
            final int n4 = n5 = 0;
            if (s == null) {
                return n4;
            }
        }
        return n5;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
