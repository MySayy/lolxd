// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import q.o.m.s.q;
import java.io.IOException;
import java.io.InputStream;

public class WindowsLineEndingInputStream extends InputStream
{
    private boolean slashRSeen;
    private boolean slashNSeen;
    private boolean injectSlashN;
    private boolean eofSeen;
    private final InputStream target;
    private final boolean ensureLineFeedAtEndOfFile;
    private static final String a;
    
    public WindowsLineEndingInputStream(final InputStream target, final boolean ensureLineFeedAtEndOfFile) {
        this.slashRSeen = false;
        this.slashNSeen = false;
        this.injectSlashN = false;
        this.eofSeen = false;
        this.target = target;
        this.ensureLineFeedAtEndOfFile = ensureLineFeedAtEndOfFile;
    }
    
    private int readWithUpdate() throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: getfield        org/apache/commons/io/input/WindowsLineEndingInputStream.target:Ljava/io/InputStream;
        //     7: invokestatic    q/o/m/s/q.kt:(Ljava/io/InputStream;)I
        //    10: istore_2       
        //    11: astore_1       
        //    12: aload_0        
        //    13: iload_2        
        //    14: aload_1        
        //    15: ifnonnull       48
        //    18: aload_1        
        //    19: ifnonnull       48
        //    22: goto            29
        //    25: invokestatic    org/apache/commons/io/input/WindowsLineEndingInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    28: athrow         
        //    29: iconst_m1      
        //    30: if_icmpne       51
        //    33: goto            40
        //    36: invokestatic    org/apache/commons/io/input/WindowsLineEndingInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    39: athrow         
        //    40: iconst_1       
        //    41: goto            48
        //    44: invokestatic    org/apache/commons/io/input/WindowsLineEndingInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    47: athrow         
        //    48: goto            52
        //    51: iconst_0       
        //    52: putfield        org/apache/commons/io/input/WindowsLineEndingInputStream.eofSeen:Z
        //    55: aload_0        
        //    56: aload_1        
        //    57: ifnonnull       87
        //    60: getfield        org/apache/commons/io/input/WindowsLineEndingInputStream.eofSeen:Z
        //    63: aload_1        
        //    64: ifnonnull       85
        //    67: goto            74
        //    70: invokestatic    org/apache/commons/io/input/WindowsLineEndingInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    73: athrow         
        //    74: ifeq            86
        //    77: goto            84
        //    80: invokestatic    org/apache/commons/io/input/WindowsLineEndingInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    83: athrow         
        //    84: iload_2        
        //    85: ireturn        
        //    86: aload_0        
        //    87: iload_2        
        //    88: aload_1        
        //    89: ifnonnull       123
        //    92: aload_1        
        //    93: ifnonnull       123
        //    96: goto            103
        //    99: invokestatic    org/apache/commons/io/input/WindowsLineEndingInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   102: athrow         
        //   103: bipush          13
        //   105: if_icmpne       126
        //   108: goto            115
        //   111: invokestatic    org/apache/commons/io/input/WindowsLineEndingInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   114: athrow         
        //   115: iconst_1       
        //   116: goto            123
        //   119: invokestatic    org/apache/commons/io/input/WindowsLineEndingInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   122: athrow         
        //   123: goto            127
        //   126: iconst_0       
        //   127: putfield        org/apache/commons/io/input/WindowsLineEndingInputStream.slashRSeen:Z
        //   130: aload_0        
        //   131: iload_2        
        //   132: aload_1        
        //   133: ifnonnull       167
        //   136: aload_1        
        //   137: ifnonnull       167
        //   140: goto            147
        //   143: invokestatic    org/apache/commons/io/input/WindowsLineEndingInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   146: athrow         
        //   147: bipush          10
        //   149: if_icmpne       170
        //   152: goto            159
        //   155: invokestatic    org/apache/commons/io/input/WindowsLineEndingInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   158: athrow         
        //   159: iconst_1       
        //   160: goto            167
        //   163: invokestatic    org/apache/commons/io/input/WindowsLineEndingInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   166: athrow         
        //   167: goto            171
        //   170: iconst_0       
        //   171: putfield        org/apache/commons/io/input/WindowsLineEndingInputStream.slashNSeen:Z
        //   174: iload_2        
        //   175: ireturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 1F FF 00 19 00 03 07 00 02 07 00 32 01 00 01 07 00 24 FF 00 03 00 03 07 00 02 07 00 32 01 00 02 07 00 02 01 46 07 00 24 43 07 00 02 43 07 00 24 FF 00 03 00 03 07 00 02 07 00 32 01 00 02 07 00 02 01 42 07 00 02 FF 00 00 00 03 07 00 02 07 00 32 01 00 02 07 00 02 01 51 07 00 24 43 01 45 07 00 24 03 40 01 00 40 07 00 02 4B 07 00 24 FF 00 03 00 03 07 00 02 07 00 32 01 00 02 07 00 02 01 47 07 00 24 43 07 00 02 43 07 00 24 FF 00 03 00 03 07 00 02 07 00 32 01 00 02 07 00 02 01 42 07 00 02 FF 00 00 00 03 07 00 02 07 00 32 01 00 02 07 00 02 01 4F 07 00 24 FF 00 03 00 03 07 00 02 07 00 32 01 00 02 07 00 02 01 47 07 00 24 43 07 00 02 43 07 00 24 FF 00 03 00 03 07 00 02 07 00 32 01 00 02 07 00 02 01 42 07 00 02 FF 00 00 00 03 07 00 02 00 01 00 02 07 00 02 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  12     22     25     29     Ljava/io/IOException;
        //  18     33     36     40     Ljava/io/IOException;
        //  29     41     44     48     Ljava/io/IOException;
        //  52     67     70     74     Ljava/io/IOException;
        //  60     77     80     84     Ljava/io/IOException;
        //  87     96     99     103    Ljava/io/IOException;
        //  92     108    111    115    Ljava/io/IOException;
        //  103    116    119    123    Ljava/io/IOException;
        //  127    140    143    147    Ljava/io/IOException;
        //  136    152    155    159    Ljava/io/IOException;
        //  147    160    163    167    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0029:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public int read() throws IOException {
        final String b = ProxyInputStream.b();
        boolean b4 = false;
        Label_0075: {
            Label_0071: {
                int n = 0;
                Label_0056: {
                    boolean b3 = false;
                    Label_0042: {
                        Label_0034: {
                            int eofGame = 0;
                            Label_0022: {
                                boolean b2;
                                try {
                                    b2 = (b3 = (b4 = this.eofSeen));
                                    if (b != null) {
                                        break Label_0042;
                                    }
                                    if (b2) {
                                        break Label_0022;
                                    }
                                    break Label_0034;
                                }
                                catch (IOException ex) {
                                    throw b(ex);
                                }
                                try {
                                    if (!b2) {
                                        break Label_0034;
                                    }
                                    eofGame = this.eofGame();
                                }
                                catch (IOException ex2) {
                                    throw b(ex2);
                                }
                            }
                            return eofGame;
                        }
                        int eofGame;
                        b3 = ((eofGame = ((b4 = this.injectSlashN) ? 1 : 0)) != 0);
                        if (b != null) {
                            return eofGame;
                        }
                        try {
                            if (b != null) {
                                break Label_0075;
                            }
                            if (b3) {
                                break Label_0056;
                            }
                            break Label_0071;
                        }
                        catch (IOException ex3) {
                            throw b(ex3);
                        }
                    }
                    try {
                        if (!b3) {
                            break Label_0071;
                        }
                        this.injectSlashN = false;
                        n = 10;
                    }
                    catch (IOException ex4) {
                        throw b(ex4);
                    }
                }
                return n;
            }
            b4 = this.slashRSeen;
        }
        final boolean b5 = b4;
        final int withUpdate = this.readWithUpdate();
        int n;
        int eofSeen;
        int n3;
        final int n2 = n = (n3 = (eofSeen = (this.eofSeen ? 1 : 0)));
        if (b == null) {
            int n6;
            while (true) {
                Label_0166: {
                    int n5 = 0;
                    Label_0136: {
                        Label_0120: {
                            Label_0115: {
                                int eofGame2 = 0;
                                Label_0103: {
                                    try {
                                        if (b != null) {
                                            break Label_0120;
                                        }
                                        if (n2 != 0) {
                                            break Label_0103;
                                        }
                                        break Label_0115;
                                    }
                                    catch (IOException ex5) {
                                        throw b(ex5);
                                    }
                                    try {
                                        if (n2 == 0) {
                                            break Label_0115;
                                        }
                                        eofGame2 = this.eofGame();
                                    }
                                    catch (IOException ex6) {
                                        throw b(ex6);
                                    }
                                }
                                return eofGame2;
                            }
                            int eofGame2;
                            n3 = (eofGame2 = (eofSeen = withUpdate));
                            if (b != null) {
                                return eofGame2;
                            }
                            try {
                                if (b != null) {
                                    return eofSeen;
                                }
                                final int n4 = 10;
                                if (n3 == n4) {
                                    break Label_0136;
                                }
                                break Label_0166;
                            }
                            catch (IOException ex7) {
                                throw b(ex7);
                            }
                        }
                        try {
                            final int n4 = 10;
                            if (n3 != n4) {
                                break Label_0166;
                            }
                            eofSeen = (n5 = (b5 ? 1 : 0));
                        }
                        catch (IOException ex8) {
                            throw b(ex8);
                        }
                    }
                    if (b != null) {
                        return eofSeen;
                    }
                    try {
                        if (n5 != 0) {
                            break Label_0166;
                        }
                        this.injectSlashN = true;
                        n6 = 13;
                    }
                    catch (IOException ex9) {
                        throw b(ex9);
                    }
                    return n6;
                }
                int n5;
                n6 = (n5 = (eofSeen = withUpdate));
                if (b != null) {
                    continue;
                }
                break;
            }
            if (b != null) {
                return n6;
            }
            return eofSeen;
        }
        return n;
    }
    
    private int eofGame() {
        final String b = ProxyInputStream.b();
        Label_0125: {
            int n8 = 0;
            Label_0105: {
                int n3 = 0;
                Label_0091: {
                    int n4;
                    int n7;
                    while (true) {
                        Label_0079: {
                            int n6 = 0;
                            Label_0046: {
                                int n2 = 0;
                                Label_0032: {
                                    Label_0024: {
                                        try {
                                            final int n = n2 = (n3 = (n4 = (this.ensureLineFeedAtEndOfFile ? 1 : 0)));
                                            if (b != null) {
                                                break Label_0032;
                                            }
                                            if (n != 0) {
                                                break Label_0024;
                                            }
                                        }
                                        catch (UnsupportedOperationException ex) {
                                            throw b(ex);
                                        }
                                        return -1;
                                    }
                                    int n5;
                                    n2 = (n5 = (n3 = (n4 = (this.slashNSeen ? 1 : 0))));
                                    if (b != null) {
                                        return n5;
                                    }
                                    try {
                                        if (b != null) {
                                            break Label_0091;
                                        }
                                        if (n2 == 0) {
                                            break Label_0046;
                                        }
                                        break Label_0079;
                                    }
                                    catch (UnsupportedOperationException ex2) {
                                        throw b(ex2);
                                    }
                                }
                                try {
                                    if (n2 != 0) {
                                        break Label_0079;
                                    }
                                    n3 = (n6 = (n4 = (this.slashRSeen ? 1 : 0)));
                                }
                                catch (UnsupportedOperationException ex3) {
                                    throw b(ex3);
                                }
                            }
                            if (b != null) {
                                break Label_0091;
                            }
                            try {
                                if (n6 != 0) {
                                    break Label_0079;
                                }
                                this.slashRSeen = true;
                                n7 = 13;
                            }
                            catch (UnsupportedOperationException ex4) {
                                throw b(ex4);
                            }
                            return n7;
                        }
                        int n6;
                        n7 = (n6 = (n3 = (n4 = (this.slashNSeen ? 1 : 0))));
                        if (b != null) {
                            continue;
                        }
                        break;
                    }
                    if (b != null) {
                        return n7;
                    }
                    try {
                        if (b != null) {
                            return n4;
                        }
                        if (n3 == 0) {
                            break Label_0105;
                        }
                        break Label_0125;
                    }
                    catch (UnsupportedOperationException ex5) {
                        throw b(ex5);
                    }
                }
                try {
                    if (n3 != 0) {
                        break Label_0125;
                    }
                    this.slashRSeen = false;
                    this.slashNSeen = true;
                    n8 = 10;
                }
                catch (UnsupportedOperationException ex6) {
                    throw b(ex6);
                }
            }
            return n8;
        }
        int n8;
        int n4 = n8 = -1;
        if (b != null) {
            return n8;
        }
        return n4;
    }
    
    @Override
    public void close() throws IOException {
        super.close();
        q.yp(this.target);
    }
    
    @Override
    public synchronized void mark(final int n) {
        throw new UnsupportedOperationException(WindowsLineEndingInputStream.a);
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 76);
        final char[] g = q.g(n.d.a.d.q.ql());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0127: {
                if (length > 1) {
                    break Label_0127;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 89;
                            break;
                        }
                        case 1: {
                            n5 = 36;
                            break;
                        }
                        case 2: {
                            n5 = 90;
                            break;
                        }
                        case 3: {
                            n5 = 49;
                            break;
                        }
                        case 4: {
                            n5 = 117;
                            break;
                        }
                        case 5: {
                            n5 = 32;
                            break;
                        }
                        default: {
                            n5 = 5;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
