// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import java.io.IOException;
import java.nio.charset.CharacterCodingException;
import q.o.m.s.q;
import java.nio.charset.Charset;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharsetEncoder;
import java.io.InputStream;

public class CharSequenceInputStream extends InputStream
{
    private static final int BUFFER_SIZE = 2048;
    private static final int NO_MARK = -1;
    private final CharsetEncoder encoder;
    private final CharBuffer cbuf;
    private final ByteBuffer bbuf;
    private int mark_cbuf;
    private int mark_bbuf;
    private static final String[] a;
    private static final String[] b;
    
    public CharSequenceInputStream(final CharSequence charSequence, final Charset charset, final int n) {
        this.encoder = q.xp(q.xn(q.xe(charset), x.dn.g.b.q.y()), x.dn.g.b.q.y());
        final String b = ProxyInputStream.b();
        final float xy = q.xy(this.encoder);
        final String s = b;
        Label_0058: {
            try {
                if (s != null) {
                    return;
                }
                final int n2 = n;
                final float n3 = (float)n2;
                final float n4 = xy;
                final float n5 = fcmpg(n3, n4);
                if (n5 < 0) {
                    break Label_0058;
                }
                break Label_0058;
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            try {
                final int n2 = n;
                final float n3 = (float)n2;
                final float n4 = xy;
                final float n5 = fcmpg(n3, n4);
                if (n5 < 0) {
                    throw new IllegalArgumentException(q.s(q.xc(q.r(q.qg(q.r(new StringBuilder(), a(-15083, 17742)), n), a(-15085, -32015)), xy)));
                }
            }
            catch (IllegalArgumentException ex2) {
                throw b(ex2);
            }
        }
        q.nq(this.bbuf = q.nf(n));
        this.cbuf = q.xx(charSequence);
        this.mark_cbuf = -1;
        this.mark_bbuf = -1;
    }
    
    public CharSequenceInputStream(final CharSequence charSequence, final String s, final int n) {
        this(charSequence, q.sh(s), n);
    }
    
    public CharSequenceInputStream(final CharSequence charSequence, final Charset charset) {
        this(charSequence, charset, 2048);
    }
    
    public CharSequenceInputStream(final CharSequence charSequence, final String s) {
        this(charSequence, s, 2048);
    }
    
    private void fillBuffer() throws CharacterCodingException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: getfield        org/apache/commons/io/input/CharSequenceInputStream.bbuf:Ljava/nio/ByteBuffer;
        //     7: invokestatic    q/o/m/s/q.xh:(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;
        //    10: pop            
        //    11: astore_1       
        //    12: aload_0        
        //    13: getfield        org/apache/commons/io/input/CharSequenceInputStream.encoder:Ljava/nio/charset/CharsetEncoder;
        //    16: aload_0        
        //    17: getfield        org/apache/commons/io/input/CharSequenceInputStream.cbuf:Ljava/nio/CharBuffer;
        //    20: aload_0        
        //    21: getfield        org/apache/commons/io/input/CharSequenceInputStream.bbuf:Ljava/nio/ByteBuffer;
        //    24: iconst_1       
        //    25: invokestatic    q/o/m/s/q.xj:(Ljava/nio/charset/CharsetEncoder;Ljava/nio/CharBuffer;Ljava/nio/ByteBuffer;Z)Ljava/nio/charset/CoderResult;
        //    28: astore_2       
        //    29: aload_1        
        //    30: ifnonnull       77
        //    33: aload_2        
        //    34: aload_1        
        //    35: ifnonnull       66
        //    38: goto            45
        //    41: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    44: athrow         
        //    45: invokestatic    q/o/m/s/q.xg:(Ljava/nio/charset/CoderResult;)Z
        //    48: ifeq            69
        //    51: goto            58
        //    54: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    57: athrow         
        //    58: aload_2        
        //    59: goto            66
        //    62: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    65: athrow         
        //    66: invokestatic    q/o/m/s/q.xz:(Ljava/nio/charset/CoderResult;)V
        //    69: aload_0        
        //    70: getfield        org/apache/commons/io/input/CharSequenceInputStream.bbuf:Ljava/nio/ByteBuffer;
        //    73: invokestatic    q/o/m/s/q.nq:(Ljava/nio/ByteBuffer;)Ljava/nio/Buffer;
        //    76: pop            
        //    77: return         
        //    Exceptions:
        //  throws java.nio.charset.CharacterCodingException
        //    StackMapTable: 00 08 FF 00 29 00 03 07 00 02 07 00 40 07 00 88 00 01 07 00 7E 43 07 00 88 48 07 00 7E 03 43 07 00 7E 43 07 00 88 02 07
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  29     38     41     45     Ljava/nio/charset/CharacterCodingException;
        //  33     51     54     58     Ljava/nio/charset/CharacterCodingException;
        //  45     59     62     66     Ljava/nio/charset/CharacterCodingException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0045:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public int read(final byte[] p0, final int p1, final int p2) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore          4
        //     5: aload_1        
        //     6: ifnonnull       30
        //     9: new             Ljava/lang/NullPointerException;
        //    12: dup            
        //    13: sipush          -15081
        //    16: sipush          7906
        //    19: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.a:(II)Ljava/lang/String;
        //    22: invokespecial   java/lang/NullPointerException.<init>:(Ljava/lang/String;)V
        //    25: athrow         
        //    26: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    29: athrow         
        //    30: iload_3        
        //    31: aload           4
        //    33: ifnonnull       68
        //    36: aload           4
        //    38: ifnonnull       68
        //    41: goto            48
        //    44: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    47: athrow         
        //    48: iflt            85
        //    51: goto            58
        //    54: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    57: athrow         
        //    58: iload_2        
        //    59: iload_3        
        //    60: iadd           
        //    61: goto            68
        //    64: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    67: athrow         
        //    68: aload           4
        //    70: ifnonnull       157
        //    73: aload_1        
        //    74: arraylength    
        //    75: if_icmple       156
        //    78: goto            85
        //    81: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    84: athrow         
        //    85: new             Ljava/lang/IndexOutOfBoundsException;
        //    88: dup            
        //    89: new             Ljava/lang/StringBuilder;
        //    92: dup            
        //    93: invokespecial   java/lang/StringBuilder.<init>:()V
        //    96: sipush          -15087
        //    99: sipush          -27497
        //   102: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.a:(II)Ljava/lang/String;
        //   105: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   108: aload_1        
        //   109: arraylength    
        //   110: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   113: sipush          -15082
        //   116: sipush          -2152
        //   119: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.a:(II)Ljava/lang/String;
        //   122: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   125: iload_2        
        //   126: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   129: sipush          -15088
        //   132: sipush          -6720
        //   135: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.a:(II)Ljava/lang/String;
        //   138: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   141: iload_3        
        //   142: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   145: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   148: invokespecial   java/lang/IndexOutOfBoundsException.<init>:(Ljava/lang/String;)V
        //   151: athrow         
        //   152: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   155: athrow         
        //   156: iload_3        
        //   157: aload           4
        //   159: ifnonnull       186
        //   162: ifne            174
        //   165: goto            172
        //   168: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   171: athrow         
        //   172: iconst_0       
        //   173: ireturn        
        //   174: aload_0        
        //   175: getfield        org/apache/commons/io/input/CharSequenceInputStream.bbuf:Ljava/nio/ByteBuffer;
        //   178: invokestatic    q/o/m/s/q.xd:(Ljava/nio/ByteBuffer;)Z
        //   181: aload           4
        //   183: ifnonnull       173
        //   186: aload           4
        //   188: ifnonnull       236
        //   191: ifne            225
        //   194: goto            201
        //   197: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   200: athrow         
        //   201: aload_0        
        //   202: getfield        org/apache/commons/io/input/CharSequenceInputStream.cbuf:Ljava/nio/CharBuffer;
        //   205: invokestatic    q/o/m/s/q.xb:(Ljava/nio/CharBuffer;)Z
        //   208: goto            215
        //   211: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   214: athrow         
        //   215: aload           4
        //   217: ifnonnull       236
        //   220: ifne            225
        //   223: iconst_m1      
        //   224: ireturn        
        //   225: iconst_0       
        //   226: aload           4
        //   228: ifnonnull       215
        //   231: aload           4
        //   233: ifnonnull       224
        //   236: istore          5
        //   238: iload_3        
        //   239: ifle            389
        //   242: aload_0        
        //   243: getfield        org/apache/commons/io/input/CharSequenceInputStream.bbuf:Ljava/nio/ByteBuffer;
        //   246: invokestatic    q/o/m/s/q.xd:(Ljava/nio/ByteBuffer;)Z
        //   249: aload           4
        //   251: ifnonnull       391
        //   254: aload           4
        //   256: ifnonnull       346
        //   259: goto            266
        //   262: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   265: athrow         
        //   266: ifeq            330
        //   269: goto            276
        //   272: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   275: athrow         
        //   276: aload_0        
        //   277: getfield        org/apache/commons/io/input/CharSequenceInputStream.bbuf:Ljava/nio/ByteBuffer;
        //   280: invokestatic    q/o/m/s/q.yw:(Ljava/nio/ByteBuffer;)I
        //   283: iload_3        
        //   284: invokestatic    q/o/m/s/q.px:(II)I
        //   287: goto            294
        //   290: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   293: athrow         
        //   294: istore          6
        //   296: aload_0        
        //   297: getfield        org/apache/commons/io/input/CharSequenceInputStream.bbuf:Ljava/nio/ByteBuffer;
        //   300: aload_1        
        //   301: iload_2        
        //   302: iload           6
        //   304: invokestatic    q/o/m/s/q.xw:(Ljava/nio/ByteBuffer;[BII)Ljava/nio/ByteBuffer;
        //   307: pop            
        //   308: iload_2        
        //   309: iload           6
        //   311: iadd           
        //   312: istore_2       
        //   313: iload_3        
        //   314: iload           6
        //   316: isub           
        //   317: istore_3       
        //   318: iload           5
        //   320: iload           6
        //   322: iadd           
        //   323: istore          5
        //   325: aload           4
        //   327: ifnull          238
        //   330: aload_0        
        //   331: invokespecial   org/apache/commons/io/input/CharSequenceInputStream.fillBuffer:()V
        //   334: aload_0        
        //   335: getfield        org/apache/commons/io/input/CharSequenceInputStream.bbuf:Ljava/nio/ByteBuffer;
        //   338: invokestatic    q/o/m/s/q.xd:(Ljava/nio/ByteBuffer;)Z
        //   341: aload           4
        //   343: ifnonnull       294
        //   346: aload           4
        //   348: ifnonnull       378
        //   351: ifne            238
        //   354: goto            361
        //   357: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   360: athrow         
        //   361: aload_0        
        //   362: getfield        org/apache/commons/io/input/CharSequenceInputStream.cbuf:Ljava/nio/CharBuffer;
        //   365: invokestatic    q/o/m/s/q.xb:(Ljava/nio/CharBuffer;)Z
        //   368: aload           4
        //   370: ifnonnull       239
        //   373: aload           4
        //   375: ifnonnull       239
        //   378: aload           4
        //   380: ifnonnull       239
        //   383: ifne            238
        //   386: goto            389
        //   389: iload           5
        //   391: aload           4
        //   393: ifnonnull       432
        //   396: aload           4
        //   398: ifnonnull       437
        //   401: goto            408
        //   404: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   407: athrow         
        //   408: ifne            463
        //   411: goto            418
        //   414: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   417: athrow         
        //   418: aload_0        
        //   419: getfield        org/apache/commons/io/input/CharSequenceInputStream.cbuf:Ljava/nio/CharBuffer;
        //   422: invokestatic    q/o/m/s/q.xb:(Ljava/nio/CharBuffer;)Z
        //   425: goto            432
        //   428: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   431: athrow         
        //   432: aload           4
        //   434: ifnonnull       460
        //   437: aload           4
        //   439: ifnonnull       460
        //   442: goto            449
        //   445: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   448: athrow         
        //   449: ifne            463
        //   452: goto            459
        //   455: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   458: athrow         
        //   459: iconst_m1      
        //   460: goto            465
        //   463: iload           5
        //   465: ireturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 36 FF 00 1A 00 05 07 00 02 07 00 99 01 01 07 00 40 00 01 07 00 94 03 4D 07 00 94 43 01 45 07 00 94 03 45 07 00 94 43 01 4C 07 00 94 03 F7 00 42 07 00 94 03 40 01 4A 07 00 94 03 40 01 00 4B 01 4A 07 00 94 03 49 07 00 94 43 01 48 01 00 4A 01 FC 00 01 01 40 01 56 07 00 94 43 01 45 07 00 94 03 4D 07 00 94 43 01 23 4F 01 4A 07 00 94 03 50 01 0A 41 01 4C 07 00 94 43 01 45 07 00 94 03 49 07 00 94 43 01 44 01 47 07 00 94 43 01 45 07 00 94 03 40 01 02 41 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  5      26     26     30     Ljava/io/IOException;
        //  30     41     44     48     Ljava/io/IOException;
        //  36     51     54     58     Ljava/io/IOException;
        //  48     61     64     68     Ljava/io/IOException;
        //  68     78     81     85     Ljava/io/IOException;
        //  73     152    152    156    Ljava/io/IOException;
        //  157    165    168    172    Ljava/io/IOException;
        //  186    194    197    201    Ljava/io/IOException;
        //  191    208    211    215    Ljava/io/IOException;
        //  242    259    262    266    Ljava/io/IOException;
        //  254    269    272    276    Ljava/io/IOException;
        //  266    287    290    294    Ljava/io/IOException;
        //  346    354    357    361    Ljava/io/IOException;
        //  391    401    404    408    Ljava/io/IOException;
        //  396    411    414    418    Ljava/io/IOException;
        //  408    425    428    432    Ljava/io/IOException;
        //  432    442    445    449    Ljava/io/IOException;
        //  437    452    455    459    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0048:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public int read() throws IOException {
        final String b = ProxyInputStream.b();
        int n = 0;
    Label_0025:
        while (true) {
            final boolean xd = q.xd(this.bbuf);
            boolean xb = false;
            while (!xb) {
                boolean xd2 = false;
                Label_0062: {
                    try {
                        this.fillBuffer();
                        xd2 = q.xd(this.bbuf);
                        if (b != null) {
                            break Label_0062;
                        }
                        if (xd2) {
                            continue Label_0025;
                        }
                    }
                    catch (IOException ex) {
                        throw b(ex);
                    }
                    xb = q.xb(this.cbuf);
                    if (b != null) {
                        continue;
                    }
                }
                if (xd2) {
                    continue Label_0025;
                }
                n = -1;
                if (b == null) {
                    return n;
                }
                break Label_0025;
            }
            final int n2 = q.xa(this.bbuf) & 0xFF;
            break;
        }
        return n;
    }
    
    @Override
    public int read(final byte[] array) throws IOException {
        return this.read(array, 0, array.length);
    }
    
    @Override
    public long skip(long n) throws IOException {
        final String b = ProxyInputStream.b();
        long n2 = 0L;
        final String s = b;
        long n3 = 0L;
    Label_0051_Outer:
        while (true) {
            while (true) {
                Label_0057: {
                    if (n <= 0L) {
                        break Label_0057;
                    }
                    Label_0031: {
                        int available;
                        try {
                            available = this.available();
                            if (s != null) {
                                break Label_0031;
                            }
                            if (available > 0) {
                                break Label_0031;
                            }
                            break Label_0057;
                        }
                        catch (IOException ex) {
                            throw b(ex);
                        }
                        try {
                            if (available <= 0) {
                                break Label_0057;
                            }
                            this.read();
                        }
                        catch (IOException ex2) {
                            throw b(ex2);
                        }
                    }
                    --n;
                    n2 = n3;
                    if (s == null) {
                        continue Label_0051_Outer;
                    }
                }
                n3 = n2;
                if (s == null) {
                    break;
                }
                continue;
            }
        }
        return n3;
    }
    
    @Override
    public int available() throws IOException {
        return q.yw(this.bbuf) + q.xl(this.cbuf);
    }
    
    @Override
    public void close() throws IOException {
    }
    
    @Override
    public synchronized void mark(final int n) {
        this.mark_cbuf = q.xi(this.cbuf);
        this.mark_bbuf = q.no(this.bbuf);
        q.xu(this.cbuf);
        q.hf(this.bbuf);
    }
    
    @Override
    public synchronized void reset() throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: aload_0        
        //     5: getfield        org/apache/commons/io/input/CharSequenceInputStream.mark_cbuf:I
        //     8: aload_1        
        //     9: ifnonnull       48
        //    12: aload_1        
        //    13: ifnonnull       48
        //    16: goto            23
        //    19: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    22: athrow         
        //    23: iconst_m1      
        //    24: if_icmpeq       272
        //    27: goto            34
        //    30: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    33: athrow         
        //    34: aload_0        
        //    35: getfield        org/apache/commons/io/input/CharSequenceInputStream.cbuf:Ljava/nio/CharBuffer;
        //    38: invokestatic    q/o/m/s/q.xi:(Ljava/nio/CharBuffer;)I
        //    41: goto            48
        //    44: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    47: athrow         
        //    48: aload_1        
        //    49: ifnonnull       174
        //    52: ifeq            152
        //    55: goto            62
        //    58: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    61: athrow         
        //    62: aload_0        
        //    63: getfield        org/apache/commons/io/input/CharSequenceInputStream.encoder:Ljava/nio/charset/CharsetEncoder;
        //    66: invokestatic    q/o/m/s/q.hm:(Ljava/nio/charset/CharsetEncoder;)Ljava/nio/charset/CharsetEncoder;
        //    69: pop            
        //    70: aload_0        
        //    71: getfield        org/apache/commons/io/input/CharSequenceInputStream.cbuf:Ljava/nio/CharBuffer;
        //    74: invokestatic    q/o/m/s/q.hv:(Ljava/nio/CharBuffer;)Ljava/nio/Buffer;
        //    77: pop            
        //    78: aload_0        
        //    79: getfield        org/apache/commons/io/input/CharSequenceInputStream.bbuf:Ljava/nio/ByteBuffer;
        //    82: invokestatic    q/o/m/s/q.ho:(Ljava/nio/ByteBuffer;)Ljava/nio/Buffer;
        //    85: pop            
        //    86: aload_0        
        //    87: getfield        org/apache/commons/io/input/CharSequenceInputStream.bbuf:Ljava/nio/ByteBuffer;
        //    90: iconst_0       
        //    91: invokestatic    q/o/m/s/q.yd:(Ljava/nio/ByteBuffer;I)Ljava/nio/Buffer;
        //    94: goto            101
        //    97: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   100: athrow         
        //   101: pop            
        //   102: aload_0        
        //   103: getfield        org/apache/commons/io/input/CharSequenceInputStream.cbuf:Ljava/nio/CharBuffer;
        //   106: invokestatic    q/o/m/s/q.xi:(Ljava/nio/CharBuffer;)I
        //   109: aload_0        
        //   110: getfield        org/apache/commons/io/input/CharSequenceInputStream.mark_cbuf:I
        //   113: if_icmpge       152
        //   116: aload_0        
        //   117: getfield        org/apache/commons/io/input/CharSequenceInputStream.bbuf:Ljava/nio/ByteBuffer;
        //   120: invokestatic    q/o/m/s/q.ho:(Ljava/nio/ByteBuffer;)Ljava/nio/Buffer;
        //   123: pop            
        //   124: aload_0        
        //   125: getfield        org/apache/commons/io/input/CharSequenceInputStream.bbuf:Ljava/nio/ByteBuffer;
        //   128: iconst_0       
        //   129: invokestatic    q/o/m/s/q.yd:(Ljava/nio/ByteBuffer;I)Ljava/nio/Buffer;
        //   132: pop            
        //   133: aload_0        
        //   134: invokespecial   org/apache/commons/io/input/CharSequenceInputStream.fillBuffer:()V
        //   137: aload_1        
        //   138: ifnonnull       267
        //   141: aload_1        
        //   142: ifnull          102
        //   145: goto            152
        //   148: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   151: athrow         
        //   152: aload_0        
        //   153: getfield        org/apache/commons/io/input/CharSequenceInputStream.cbuf:Ljava/nio/CharBuffer;
        //   156: aload_1        
        //   157: ifnonnull       101
        //   160: aload_1        
        //   161: ifnonnull       261
        //   164: invokestatic    q/o/m/s/q.xi:(Ljava/nio/CharBuffer;)I
        //   167: goto            174
        //   170: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   173: athrow         
        //   174: aload_0        
        //   175: getfield        org/apache/commons/io/input/CharSequenceInputStream.mark_cbuf:I
        //   178: if_icmpeq       250
        //   181: new             Ljava/lang/IllegalStateException;
        //   184: dup            
        //   185: new             Ljava/lang/StringBuilder;
        //   188: dup            
        //   189: invokespecial   java/lang/StringBuilder.<init>:()V
        //   192: sipush          -15084
        //   195: sipush          -19698
        //   198: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.a:(II)Ljava/lang/String;
        //   201: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   204: aload_0        
        //   205: getfield        org/apache/commons/io/input/CharSequenceInputStream.cbuf:Ljava/nio/CharBuffer;
        //   208: invokestatic    q/o/m/s/q.xi:(Ljava/nio/CharBuffer;)I
        //   211: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   214: invokestatic    n/d/a/d/q.m:()Ljava/lang/String;
        //   217: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   220: sipush          -15086
        //   223: sipush          -19648
        //   226: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.a:(II)Ljava/lang/String;
        //   229: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   232: aload_0        
        //   233: getfield        org/apache/commons/io/input/CharSequenceInputStream.mark_cbuf:I
        //   236: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   239: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   242: invokespecial   java/lang/IllegalStateException.<init>:(Ljava/lang/String;)V
        //   245: athrow         
        //   246: invokestatic    org/apache/commons/io/input/CharSequenceInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   249: athrow         
        //   250: aload_0        
        //   251: getfield        org/apache/commons/io/input/CharSequenceInputStream.bbuf:Ljava/nio/ByteBuffer;
        //   254: aload_0        
        //   255: getfield        org/apache/commons/io/input/CharSequenceInputStream.mark_bbuf:I
        //   258: invokestatic    q/o/m/s/q.yz:(Ljava/nio/ByteBuffer;I)Ljava/nio/Buffer;
        //   261: pop            
        //   262: aload_0        
        //   263: iconst_m1      
        //   264: putfield        org/apache/commons/io/input/CharSequenceInputStream.mark_cbuf:I
        //   267: aload_0        
        //   268: iconst_m1      
        //   269: putfield        org/apache/commons/io/input/CharSequenceInputStream.mark_bbuf:I
        //   272: return         
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 14 FF 00 13 00 02 07 00 02 07 00 40 00 01 07 00 94 43 01 46 07 00 94 03 49 07 00 94 43 01 49 07 00 94 03 62 07 00 94 43 07 00 E6 00 6D 07 00 94 03 51 07 00 94 43 01 F7 00 47 07 00 94 03 4A 07 00 E6 05 04
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      16     19     23     Ljava/io/IOException;
        //  12     27     30     34     Ljava/io/IOException;
        //  23     41     44     48     Ljava/io/IOException;
        //  48     55     58     62     Ljava/io/IOException;
        //  52     94     97     101    Ljava/io/IOException;
        //  116    145    148    152    Ljava/io/IOException;
        //  160    167    170    174    Ljava/io/IOException;
        //  174    246    246    250    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0023:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public boolean markSupported() {
        return true;
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    static {
        final String[] a2 = new String[8];
        int n = 0;
        String s;
        int n2 = q.q(s = n.d.a.d.q.qq());
        int n3 = 9;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 65));
                ++n4;
                final String s2 = s;
                final int n9 = n4;
                String s3 = q.h(s2, n9, n9 + n3);
                int n10 = -1;
                while (true) {
                    final char[] g = q.g(s3);
                    final int length = g.length;
                    int n11 = 0;
                    while (true) {
                        Label_0264: {
                            if (length > 1) {
                                break Label_0264;
                            }
                            n7 = (n6 = n11);
                            do {
                                final char c = g[n6];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 59;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 18;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 23;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 54;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 54;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 78;
                                        break;
                                    }
                                    default: {
                                        n12 = 7;
                                        break;
                                    }
                                }
                                g[n7] = (char)(c ^ (n5 ^ n12));
                                ++n11;
                            } while (n8 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.z(new String(g));
                    switch (n10) {
                        default: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                continue Label_0024;
                            }
                            n2 = q.q(s = n.d.a.d.q.qt());
                            n3 = 9;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 75)));
                    ++n4;
                    final String s4 = s;
                    final int n13 = n4;
                    s3 = q.h(s4, n13, n13 + n3);
                    n10 = 0;
                }
            }
            break;
        }
        a = a2;
        b = new String[8];
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0xFFFFC516) & 0xFFFF;
        if (CharSequenceInputStream.b[n3] == null) {
            final char[] g = q.g(CharSequenceInputStream.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 34;
                    break;
                }
                case 1: {
                    n4 = 3;
                    break;
                }
                case 2: {
                    n4 = 196;
                    break;
                }
                case 3: {
                    n4 = 252;
                    break;
                }
                case 4: {
                    n4 = 115;
                    break;
                }
                case 5: {
                    n4 = 22;
                    break;
                }
                case 6: {
                    n4 = 200;
                    break;
                }
                case 7: {
                    n4 = 219;
                    break;
                }
                case 8: {
                    n4 = 164;
                    break;
                }
                case 9: {
                    n4 = 14;
                    break;
                }
                case 10: {
                    n4 = 242;
                    break;
                }
                case 11: {
                    n4 = 90;
                    break;
                }
                case 12: {
                    n4 = 190;
                    break;
                }
                case 13: {
                    n4 = 107;
                    break;
                }
                case 14: {
                    n4 = 171;
                    break;
                }
                case 15: {
                    n4 = 104;
                    break;
                }
                case 16: {
                    n4 = 203;
                    break;
                }
                case 17: {
                    n4 = 213;
                    break;
                }
                case 18: {
                    n4 = 119;
                    break;
                }
                case 19: {
                    n4 = 4;
                    break;
                }
                case 20: {
                    n4 = 78;
                    break;
                }
                case 21: {
                    n4 = 102;
                    break;
                }
                case 22: {
                    n4 = 7;
                    break;
                }
                case 23: {
                    n4 = 247;
                    break;
                }
                case 24: {
                    n4 = 186;
                    break;
                }
                case 25: {
                    n4 = 149;
                    break;
                }
                case 26: {
                    n4 = 98;
                    break;
                }
                case 27: {
                    n4 = 129;
                    break;
                }
                case 28: {
                    n4 = 143;
                    break;
                }
                case 29: {
                    n4 = 162;
                    break;
                }
                case 30: {
                    n4 = 63;
                    break;
                }
                case 31: {
                    n4 = 255;
                    break;
                }
                case 32: {
                    n4 = 237;
                    break;
                }
                case 33: {
                    n4 = 50;
                    break;
                }
                case 34: {
                    n4 = 5;
                    break;
                }
                case 35: {
                    n4 = 128;
                    break;
                }
                case 36: {
                    n4 = 67;
                    break;
                }
                case 37: {
                    n4 = 184;
                    break;
                }
                case 38: {
                    n4 = 159;
                    break;
                }
                case 39: {
                    n4 = 166;
                    break;
                }
                case 40: {
                    n4 = 136;
                    break;
                }
                case 41: {
                    n4 = 108;
                    break;
                }
                case 42: {
                    n4 = 31;
                    break;
                }
                case 43: {
                    n4 = 105;
                    break;
                }
                case 44: {
                    n4 = 131;
                    break;
                }
                case 45: {
                    n4 = 83;
                    break;
                }
                case 46: {
                    n4 = 79;
                    break;
                }
                case 47: {
                    n4 = 84;
                    break;
                }
                case 48: {
                    n4 = 228;
                    break;
                }
                case 49: {
                    n4 = 97;
                    break;
                }
                case 50: {
                    n4 = 187;
                    break;
                }
                case 51: {
                    n4 = 192;
                    break;
                }
                case 52: {
                    n4 = 130;
                    break;
                }
                case 53: {
                    n4 = 2;
                    break;
                }
                case 54: {
                    n4 = 199;
                    break;
                }
                case 55: {
                    n4 = 145;
                    break;
                }
                case 56: {
                    n4 = 147;
                    break;
                }
                case 57: {
                    n4 = 18;
                    break;
                }
                case 58: {
                    n4 = 181;
                    break;
                }
                case 59: {
                    n4 = 205;
                    break;
                }
                case 60: {
                    n4 = 201;
                    break;
                }
                case 61: {
                    n4 = 37;
                    break;
                }
                case 62: {
                    n4 = 15;
                    break;
                }
                case 63: {
                    n4 = 176;
                    break;
                }
                case 64: {
                    n4 = 244;
                    break;
                }
                case 65: {
                    n4 = 170;
                    break;
                }
                case 66: {
                    n4 = 38;
                    break;
                }
                case 67: {
                    n4 = 223;
                    break;
                }
                case 68: {
                    n4 = 33;
                    break;
                }
                case 69: {
                    n4 = 87;
                    break;
                }
                case 70: {
                    n4 = 35;
                    break;
                }
                case 71: {
                    n4 = 106;
                    break;
                }
                case 72: {
                    n4 = 116;
                    break;
                }
                case 73: {
                    n4 = 70;
                    break;
                }
                case 74: {
                    n4 = 155;
                    break;
                }
                case 75: {
                    n4 = 49;
                    break;
                }
                case 76: {
                    n4 = 88;
                    break;
                }
                case 77: {
                    n4 = 169;
                    break;
                }
                case 78: {
                    n4 = 179;
                    break;
                }
                case 79: {
                    n4 = 117;
                    break;
                }
                case 80: {
                    n4 = 146;
                    break;
                }
                case 81: {
                    n4 = 138;
                    break;
                }
                case 82: {
                    n4 = 81;
                    break;
                }
                case 83: {
                    n4 = 91;
                    break;
                }
                case 84: {
                    n4 = 152;
                    break;
                }
                case 85: {
                    n4 = 220;
                    break;
                }
                case 86: {
                    n4 = 248;
                    break;
                }
                case 87: {
                    n4 = 197;
                    break;
                }
                case 88: {
                    n4 = 231;
                    break;
                }
                case 89: {
                    n4 = 125;
                    break;
                }
                case 90: {
                    n4 = 194;
                    break;
                }
                case 91: {
                    n4 = 216;
                    break;
                }
                case 92: {
                    n4 = 126;
                    break;
                }
                case 93: {
                    n4 = 191;
                    break;
                }
                case 94: {
                    n4 = 180;
                    break;
                }
                case 95: {
                    n4 = 185;
                    break;
                }
                case 96: {
                    n4 = 249;
                    break;
                }
                case 97: {
                    n4 = 56;
                    break;
                }
                case 98: {
                    n4 = 62;
                    break;
                }
                case 99: {
                    n4 = 82;
                    break;
                }
                case 100: {
                    n4 = 123;
                    break;
                }
                case 101: {
                    n4 = 28;
                    break;
                }
                case 102: {
                    n4 = 60;
                    break;
                }
                case 103: {
                    n4 = 240;
                    break;
                }
                case 104: {
                    n4 = 94;
                    break;
                }
                case 105: {
                    n4 = 210;
                    break;
                }
                case 106: {
                    n4 = 39;
                    break;
                }
                case 107: {
                    n4 = 17;
                    break;
                }
                case 108: {
                    n4 = 110;
                    break;
                }
                case 109: {
                    n4 = 254;
                    break;
                }
                case 110: {
                    n4 = 65;
                    break;
                }
                case 111: {
                    n4 = 12;
                    break;
                }
                case 112: {
                    n4 = 118;
                    break;
                }
                case 113: {
                    n4 = 139;
                    break;
                }
                case 114: {
                    n4 = 148;
                    break;
                }
                case 115: {
                    n4 = 8;
                    break;
                }
                case 116: {
                    n4 = 209;
                    break;
                }
                case 117: {
                    n4 = 189;
                    break;
                }
                case 118: {
                    n4 = 13;
                    break;
                }
                case 119: {
                    n4 = 64;
                    break;
                }
                case 120: {
                    n4 = 193;
                    break;
                }
                case 121: {
                    n4 = 226;
                    break;
                }
                case 122: {
                    n4 = 72;
                    break;
                }
                case 123: {
                    n4 = 10;
                    break;
                }
                case 124: {
                    n4 = 253;
                    break;
                }
                case 125: {
                    n4 = 47;
                    break;
                }
                case 126: {
                    n4 = 239;
                    break;
                }
                case 127: {
                    n4 = 44;
                    break;
                }
                case 128: {
                    n4 = 93;
                    break;
                }
                case 129: {
                    n4 = 1;
                    break;
                }
                case 130: {
                    n4 = 112;
                    break;
                }
                case 131: {
                    n4 = 51;
                    break;
                }
                case 132: {
                    n4 = 211;
                    break;
                }
                case 133: {
                    n4 = 224;
                    break;
                }
                case 134: {
                    n4 = 59;
                    break;
                }
                case 135: {
                    n4 = 161;
                    break;
                }
                case 136: {
                    n4 = 20;
                    break;
                }
                case 137: {
                    n4 = 245;
                    break;
                }
                case 138: {
                    n4 = 41;
                    break;
                }
                case 139: {
                    n4 = 36;
                    break;
                }
                case 140: {
                    n4 = 48;
                    break;
                }
                case 141: {
                    n4 = 132;
                    break;
                }
                case 142: {
                    n4 = 9;
                    break;
                }
                case 143: {
                    n4 = 71;
                    break;
                }
                case 144: {
                    n4 = 230;
                    break;
                }
                case 145: {
                    n4 = 27;
                    break;
                }
                case 146: {
                    n4 = 121;
                    break;
                }
                case 147: {
                    n4 = 55;
                    break;
                }
                case 148: {
                    n4 = 206;
                    break;
                }
                case 149: {
                    n4 = 167;
                    break;
                }
                case 150: {
                    n4 = 16;
                    break;
                }
                case 151: {
                    n4 = 241;
                    break;
                }
                case 152: {
                    n4 = 163;
                    break;
                }
                case 153: {
                    n4 = 92;
                    break;
                }
                case 154: {
                    n4 = 173;
                    break;
                }
                case 155: {
                    n4 = 183;
                    break;
                }
                case 156: {
                    n4 = 89;
                    break;
                }
                case 157: {
                    n4 = 142;
                    break;
                }
                case 158: {
                    n4 = 68;
                    break;
                }
                case 159: {
                    n4 = 32;
                    break;
                }
                case 160: {
                    n4 = 46;
                    break;
                }
                case 161: {
                    n4 = 80;
                    break;
                }
                case 162: {
                    n4 = 178;
                    break;
                }
                case 163: {
                    n4 = 212;
                    break;
                }
                case 164: {
                    n4 = 109;
                    break;
                }
                case 165: {
                    n4 = 58;
                    break;
                }
                case 166: {
                    n4 = 95;
                    break;
                }
                case 167: {
                    n4 = 122;
                    break;
                }
                case 168: {
                    n4 = 158;
                    break;
                }
                case 169: {
                    n4 = 207;
                    break;
                }
                case 170: {
                    n4 = 156;
                    break;
                }
                case 171: {
                    n4 = 45;
                    break;
                }
                case 172: {
                    n4 = 85;
                    break;
                }
                case 173: {
                    n4 = 25;
                    break;
                }
                case 174: {
                    n4 = 238;
                    break;
                }
                case 175: {
                    n4 = 151;
                    break;
                }
                case 176: {
                    n4 = 96;
                    break;
                }
                case 177: {
                    n4 = 160;
                    break;
                }
                case 178: {
                    n4 = 101;
                    break;
                }
                case 179: {
                    n4 = 243;
                    break;
                }
                case 180: {
                    n4 = 66;
                    break;
                }
                case 181: {
                    n4 = 246;
                    break;
                }
                case 182: {
                    n4 = 218;
                    break;
                }
                case 183: {
                    n4 = 114;
                    break;
                }
                case 184: {
                    n4 = 217;
                    break;
                }
                case 185: {
                    n4 = 153;
                    break;
                }
                case 186: {
                    n4 = 42;
                    break;
                }
                case 187: {
                    n4 = 103;
                    break;
                }
                case 188: {
                    n4 = 57;
                    break;
                }
                case 189: {
                    n4 = 111;
                    break;
                }
                case 190: {
                    n4 = 168;
                    break;
                }
                case 191: {
                    n4 = 19;
                    break;
                }
                case 192: {
                    n4 = 53;
                    break;
                }
                case 193: {
                    n4 = 141;
                    break;
                }
                case 194: {
                    n4 = 235;
                    break;
                }
                case 195: {
                    n4 = 234;
                    break;
                }
                case 196: {
                    n4 = 229;
                    break;
                }
                case 197: {
                    n4 = 222;
                    break;
                }
                case 198: {
                    n4 = 76;
                    break;
                }
                case 199: {
                    n4 = 30;
                    break;
                }
                case 200: {
                    n4 = 232;
                    break;
                }
                case 201: {
                    n4 = 172;
                    break;
                }
                case 202: {
                    n4 = 100;
                    break;
                }
                case 203: {
                    n4 = 227;
                    break;
                }
                case 204: {
                    n4 = 208;
                    break;
                }
                case 205: {
                    n4 = 23;
                    break;
                }
                case 206: {
                    n4 = 133;
                    break;
                }
                case 207: {
                    n4 = 74;
                    break;
                }
                case 208: {
                    n4 = 99;
                    break;
                }
                case 209: {
                    n4 = 43;
                    break;
                }
                case 210: {
                    n4 = 135;
                    break;
                }
                case 211: {
                    n4 = 75;
                    break;
                }
                case 212: {
                    n4 = 202;
                    break;
                }
                case 213: {
                    n4 = 251;
                    break;
                }
                case 214: {
                    n4 = 177;
                    break;
                }
                case 215: {
                    n4 = 175;
                    break;
                }
                case 216: {
                    n4 = 250;
                    break;
                }
                case 217: {
                    n4 = 157;
                    break;
                }
                case 218: {
                    n4 = 221;
                    break;
                }
                case 219: {
                    n4 = 73;
                    break;
                }
                case 220: {
                    n4 = 24;
                    break;
                }
                case 221: {
                    n4 = 127;
                    break;
                }
                case 222: {
                    n4 = 26;
                    break;
                }
                case 223: {
                    n4 = 182;
                    break;
                }
                case 224: {
                    n4 = 144;
                    break;
                }
                case 225: {
                    n4 = 233;
                    break;
                }
                case 226: {
                    n4 = 204;
                    break;
                }
                case 227: {
                    n4 = 61;
                    break;
                }
                case 228: {
                    n4 = 215;
                    break;
                }
                case 229: {
                    n4 = 124;
                    break;
                }
                case 230: {
                    n4 = 69;
                    break;
                }
                case 231: {
                    n4 = 11;
                    break;
                }
                case 232: {
                    n4 = 236;
                    break;
                }
                case 233: {
                    n4 = 40;
                    break;
                }
                case 234: {
                    n4 = 120;
                    break;
                }
                case 235: {
                    n4 = 52;
                    break;
                }
                case 236: {
                    n4 = 174;
                    break;
                }
                case 237: {
                    n4 = 86;
                    break;
                }
                case 238: {
                    n4 = 77;
                    break;
                }
                case 239: {
                    n4 = 140;
                    break;
                }
                case 240: {
                    n4 = 214;
                    break;
                }
                case 241: {
                    n4 = 134;
                    break;
                }
                case 242: {
                    n4 = 150;
                    break;
                }
                case 243: {
                    n4 = 0;
                    break;
                }
                case 244: {
                    n4 = 54;
                    break;
                }
                case 245: {
                    n4 = 165;
                    break;
                }
                case 246: {
                    n4 = 154;
                    break;
                }
                case 247: {
                    n4 = 225;
                    break;
                }
                case 248: {
                    n4 = 113;
                    break;
                }
                case 249: {
                    n4 = 198;
                    break;
                }
                case 250: {
                    n4 = 6;
                    break;
                }
                case 251: {
                    n4 = 188;
                    break;
                }
                case 252: {
                    n4 = 21;
                    break;
                }
                case 253: {
                    n4 = 137;
                    break;
                }
                case 254: {
                    n4 = 195;
                    break;
                }
                default: {
                    n4 = 29;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            CharSequenceInputStream.b[n3] = q.z(new String(g));
        }
        return CharSequenceInputStream.b[n3];
    }
}
