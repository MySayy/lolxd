// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import n.d.a.d.q;
import java.io.IOException;
import java.io.InputStream;

public class BrokenInputStream extends InputStream
{
    private final IOException exception;
    private static final String a;
    
    public BrokenInputStream(final IOException exception) {
        this.exception = exception;
    }
    
    public BrokenInputStream() {
        this(new IOException(BrokenInputStream.a));
    }
    
    @Override
    public int read() throws IOException {
        throw this.exception;
    }
    
    @Override
    public int available() throws IOException {
        throw this.exception;
    }
    
    @Override
    public long skip(final long n) throws IOException {
        throw this.exception;
    }
    
    @Override
    public synchronized void reset() throws IOException {
        throw this.exception;
    }
    
    @Override
    public void close() throws IOException {
        throw this.exception;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 118);
        final char[] g = q.o.m.s.q.g(q.qo());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 48;
                            break;
                        }
                        case 1: {
                            n5 = 120;
                            break;
                        }
                        case 2: {
                            n5 = 101;
                            break;
                        }
                        case 3: {
                            n5 = 127;
                            break;
                        }
                        case 4: {
                            n5 = 107;
                            break;
                        }
                        case 5: {
                            n5 = 15;
                            break;
                        }
                        default: {
                            n5 = 95;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.o.m.s.q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
