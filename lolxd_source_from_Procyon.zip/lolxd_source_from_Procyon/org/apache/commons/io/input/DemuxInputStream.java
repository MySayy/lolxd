// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import java.io.IOException;
import q.o.m.s.q;
import java.io.InputStream;

public class DemuxInputStream extends InputStream
{
    private final InheritableThreadLocal<InputStream> m_streams;
    
    public DemuxInputStream() {
        this.m_streams = new InheritableThreadLocal<InputStream>();
    }
    
    public InputStream bindStream(final InputStream inputStream) {
        final InputStream inputStream2 = (InputStream)q.he(this.m_streams);
        q.hn(this.m_streams, inputStream);
        return inputStream2;
    }
    
    @Override
    public void close() throws IOException {
        final InputStream inputStream = (InputStream)q.he(this.m_streams);
        try {
            if (null != inputStream) {
                q.yp(inputStream);
            }
        }
        catch (IOException ex) {
            throw b(ex);
        }
    }
    
    @Override
    public int read() throws IOException {
        final String b = ProxyInputStream.b();
        final InputStream inputStream = (InputStream)q.he(this.m_streams);
        final String s = b;
        Label_0032: {
            try {
                if (null == inputStream) {
                    break Label_0032;
                }
                q.kt(inputStream);
            }
            catch (IOException ex) {
                throw b(ex);
            }
            return;
        }
        final int n = -1;
        if (s == null) {
            return n;
        }
        return n;
    }
    
    private static IOException b(final IOException ex) {
        return ex;
    }
}
