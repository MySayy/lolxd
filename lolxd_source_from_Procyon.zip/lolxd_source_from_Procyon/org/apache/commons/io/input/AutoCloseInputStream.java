// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import java.io.IOException;
import q.o.m.s.q;
import java.io.InputStream;

public class AutoCloseInputStream extends ProxyInputStream
{
    public AutoCloseInputStream(final InputStream inputStream) {
        super(inputStream);
    }
    
    @Override
    public void close() throws IOException {
        q.yp(this.in);
        this.in = new ClosedInputStream();
    }
    
    @Override
    protected void afterRead(final int n) throws IOException {
        try {
            if (n == -1) {
                this.close();
            }
        }
        catch (IOException ex) {
            throw c(ex);
        }
    }
    
    @Override
    protected void finalize() throws Throwable {
        this.close();
        super.finalize();
    }
    
    private static IOException c(final IOException ex) {
        return ex;
    }
}
