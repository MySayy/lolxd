// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import q.o.m.s.q;
import java.io.ObjectStreamClass;
import java.io.StreamCorruptedException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;

public class ClassLoaderObjectInputStream extends ObjectInputStream
{
    private final ClassLoader classLoader;
    
    public ClassLoaderObjectInputStream(final ClassLoader classLoader, final InputStream in) throws IOException, StreamCorruptedException {
        super(in);
        this.classLoader = classLoader;
    }
    
    @Override
    protected Class<?> resolveClass(final ObjectStreamClass desc) throws IOException, ClassNotFoundException {
        try {
            return (Class<?>)q.hs(q.hr(desc), false, this.classLoader);
        }
        catch (ClassNotFoundException ex) {
            return super.resolveClass(desc);
        }
    }
    
    @Override
    protected Class<?> resolveProxyClass(final String[] interfaces) throws IOException, ClassNotFoundException {
        final Class[] array = new Class[interfaces.length];
        final String b = ProxyInputStream.b();
        int i = 0;
        while (i < interfaces.length) {
            array[i] = q.hs(interfaces[i], false, this.classLoader);
            ++i;
            if (b != null) {
                break;
            }
        }
        try {
            return (Class<?>)q.hk(this.classLoader, array);
        }
        catch (IllegalArgumentException ex) {
            return super.resolveProxyClass(interfaces);
        }
    }
}
