// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import java.util.Iterator;
import java.io.IOException;
import q.o.m.s.q;
import java.io.InputStream;
import java.util.Comparator;
import org.apache.commons.io.ByteOrderMark;
import java.util.List;

public class BOMInputStream extends ProxyInputStream
{
    private final boolean include;
    private final List<ByteOrderMark> boms;
    private ByteOrderMark byteOrderMark;
    private int[] firstBytes;
    private int fbLength;
    private int fbIndex;
    private int markFbIndex;
    private boolean markedAtStart;
    private static final Comparator<ByteOrderMark> ByteOrderMarkLengthComparator;
    private static final String[] a;
    private static final String[] c;
    
    public BOMInputStream(final InputStream inputStream) {
        this(inputStream, false, new ByteOrderMark[] { ByteOrderMark.UTF_8 });
    }
    
    public BOMInputStream(final InputStream inputStream, final boolean b) {
        this(inputStream, b, new ByteOrderMark[] { ByteOrderMark.UTF_8 });
    }
    
    public BOMInputStream(final InputStream inputStream, final ByteOrderMark... array) {
        this(inputStream, false, array);
    }
    
    public BOMInputStream(final InputStream inputStream, final boolean include, final ByteOrderMark... array) {
        final String b = ProxyInputStream.b();
        super(inputStream);
        final String s = b;
        ByteOrderMark[] array2 = null;
        Label_0082: {
            Label_0055: {
                ByteOrderMark[] array3 = null;
                Label_0039: {
                    Label_0028: {
                        try {
                            array2 = array;
                            array3 = array;
                            if (s != null) {
                                break Label_0039;
                            }
                            final String s2 = s;
                            if (s2 == null) {
                                break Label_0028;
                            }
                            break Label_0039;
                        }
                        catch (IllegalArgumentException ex) {
                            throw b(ex);
                        }
                        try {
                            final String s2 = s;
                            if (s2 != null) {
                                break Label_0039;
                            }
                            if (array == null) {
                                break Label_0055;
                            }
                        }
                        catch (IllegalArgumentException ex2) {
                            throw b(ex2);
                        }
                    }
                    array2 = array;
                    array3 = array;
                    try {
                        if (s != null) {
                            break Label_0082;
                        }
                        final int n = array3.length;
                        if (n == 0) {
                            break Label_0055;
                        }
                        break Label_0055;
                    }
                    catch (IllegalArgumentException ex3) {
                        throw b(ex3);
                    }
                }
                try {
                    final int n = array3.length;
                    if (n == 0) {
                        throw new IllegalArgumentException(a(-10370, 23795));
                    }
                }
                catch (IllegalArgumentException ex4) {
                    throw b(ex4);
                }
            }
            this.include = include;
            array2 = array;
        }
        q.cr(array2, BOMInputStream.ByteOrderMarkLengthComparator);
        this.boms = (List<ByteOrderMark>)q.et(array);
    }
    
    public boolean hasBOM() throws IOException {
        try {
            if (this.getBOM() != null) {
                return true;
            }
        }
        catch (IOException ex) {
            throw b((Exception)ex);
        }
        return false;
    }
    
    public boolean hasBOM(final ByteOrderMark p0) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_0        
        //     5: aload_2        
        //     6: ifnonnull       65
        //     9: getfield        org/apache/commons/io/input/BOMInputStream.boms:Ljava/util/List;
        //    12: aload_1        
        //    13: invokestatic    q/o/m/s/q.ng:(Ljava/util/List;Ljava/lang/Object;)Z
        //    16: ifne            64
        //    19: goto            26
        //    22: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    25: athrow         
        //    26: new             Ljava/lang/IllegalArgumentException;
        //    29: dup            
        //    30: new             Ljava/lang/StringBuilder;
        //    33: dup            
        //    34: invokespecial   java/lang/StringBuilder.<init>:()V
        //    37: sipush          -10369
        //    40: sipush          -15535
        //    43: invokestatic    org/apache/commons/io/input/BOMInputStream.a:(II)Ljava/lang/String;
        //    46: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    49: aload_1        
        //    50: invokestatic    q/o/m/s/q.kx:(Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //    53: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //    56: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //    59: athrow         
        //    60: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    63: athrow         
        //    64: aload_0        
        //    65: getfield        org/apache/commons/io/input/BOMInputStream.byteOrderMark:Lorg/apache/commons/io/ByteOrderMark;
        //    68: aload_2        
        //    69: ifnonnull       104
        //    72: aload_2        
        //    73: ifnonnull       104
        //    76: goto            83
        //    79: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    82: athrow         
        //    83: ifnull          137
        //    86: goto            93
        //    89: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    92: athrow         
        //    93: aload_0        
        //    94: invokevirtual   org/apache/commons/io/input/BOMInputStream.getBOM:()Lorg/apache/commons/io/ByteOrderMark;
        //    97: goto            104
        //   100: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   103: athrow         
        //   104: aload_1        
        //   105: invokevirtual   org/apache/commons/io/ByteOrderMark.equals:(Ljava/lang/Object;)Z
        //   108: aload_2        
        //   109: ifnonnull       134
        //   112: aload_2        
        //   113: ifnonnull       134
        //   116: goto            123
        //   119: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   122: athrow         
        //   123: ifeq            137
        //   126: goto            133
        //   129: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   132: athrow         
        //   133: iconst_1       
        //   134: goto            138
        //   137: iconst_0       
        //   138: ireturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 12 FF 00 16 00 03 07 00 02 07 00 1D 07 00 33 00 01 07 00 50 03 61 07 00 50 03 40 07 00 02 4D 07 00 50 43 07 00 1D 45 07 00 50 03 46 07 00 50 43 07 00 1D 4E 07 00 50 43 01 45 07 00 50 03 40 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      19     22     26     Ljava/io/IOException;
        //  9      60     60     64     Ljava/io/IOException;
        //  65     76     79     83     Ljava/io/IOException;
        //  72     86     89     93     Ljava/io/IOException;
        //  83     97     100    104    Ljava/io/IOException;
        //  104    116    119    123    Ljava/io/IOException;
        //  112    126    129    133    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0083:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public ByteOrderMark getBOM() throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: aload_0        
        //     5: aload_1        
        //     6: ifnonnull       277
        //     9: getfield        org/apache/commons/io/input/BOMInputStream.firstBytes:[I
        //    12: ifnonnull       276
        //    15: goto            22
        //    18: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    21: athrow         
        //    22: aload_0        
        //    23: iconst_0       
        //    24: putfield        org/apache/commons/io/input/BOMInputStream.fbLength:I
        //    27: aload_0        
        //    28: getfield        org/apache/commons/io/input/BOMInputStream.boms:Ljava/util/List;
        //    31: iconst_0       
        //    32: invokestatic    q/o/m/s/q.kz:(Ljava/util/List;I)Ljava/lang/Object;
        //    35: checkcast       Lorg/apache/commons/io/ByteOrderMark;
        //    38: goto            45
        //    41: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    44: athrow         
        //    45: invokevirtual   org/apache/commons/io/ByteOrderMark.length:()I
        //    48: istore_2       
        //    49: aload_0        
        //    50: iload_2        
        //    51: newarray        I
        //    53: putfield        org/apache/commons/io/input/BOMInputStream.firstBytes:[I
        //    56: iconst_0       
        //    57: istore_3       
        //    58: iload_3        
        //    59: aload_0        
        //    60: getfield        org/apache/commons/io/input/BOMInputStream.firstBytes:[I
        //    63: arraylength    
        //    64: if_icmpge       146
        //    67: aload_0        
        //    68: getfield        org/apache/commons/io/input/BOMInputStream.firstBytes:[I
        //    71: iload_3        
        //    72: aload_0        
        //    73: getfield        org/apache/commons/io/input/BOMInputStream.in:Ljava/io/InputStream;
        //    76: invokestatic    q/o/m/s/q.kt:(Ljava/io/InputStream;)I
        //    79: iastore        
        //    80: aload_0        
        //    81: dup            
        //    82: getfield        org/apache/commons/io/input/BOMInputStream.fbLength:I
        //    85: iconst_1       
        //    86: iadd           
        //    87: putfield        org/apache/commons/io/input/BOMInputStream.fbLength:I
        //    90: aload_1        
        //    91: ifnonnull       142
        //    94: aload_0        
        //    95: getfield        org/apache/commons/io/input/BOMInputStream.firstBytes:[I
        //    98: iload_3        
        //    99: iaload         
        //   100: aload_1        
        //   101: ifnonnull       198
        //   104: goto            111
        //   107: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   110: athrow         
        //   111: ifge            132
        //   114: goto            121
        //   117: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   120: athrow         
        //   121: aload_1        
        //   122: ifnull          146
        //   125: goto            132
        //   128: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   131: athrow         
        //   132: iinc            3, 1
        //   135: goto            142
        //   138: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   141: athrow         
        //   142: aload_1        
        //   143: ifnull          58
        //   146: aload_0        
        //   147: aload_0        
        //   148: invokespecial   org/apache/commons/io/input/BOMInputStream.find:()Lorg/apache/commons/io/ByteOrderMark;
        //   151: putfield        org/apache/commons/io/input/BOMInputStream.byteOrderMark:Lorg/apache/commons/io/ByteOrderMark;
        //   154: aload_0        
        //   155: aload_1        
        //   156: ifnonnull       184
        //   159: getfield        org/apache/commons/io/input/BOMInputStream.byteOrderMark:Lorg/apache/commons/io/ByteOrderMark;
        //   162: aload_1        
        //   163: ifnonnull       284
        //   166: goto            173
        //   169: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   172: athrow         
        //   173: ifnull          276
        //   176: goto            183
        //   179: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   182: athrow         
        //   183: aload_0        
        //   184: aload_1        
        //   185: ifnonnull       277
        //   188: getfield        org/apache/commons/io/input/BOMInputStream.include:Z
        //   191: goto            198
        //   194: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   197: athrow         
        //   198: aload_1        
        //   199: ifnonnull       237
        //   202: ifne            276
        //   205: goto            212
        //   208: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   211: athrow         
        //   212: aload_0        
        //   213: aload_1        
        //   214: ifnonnull       268
        //   217: goto            224
        //   220: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   223: athrow         
        //   224: getfield        org/apache/commons/io/input/BOMInputStream.byteOrderMark:Lorg/apache/commons/io/ByteOrderMark;
        //   227: invokevirtual   org/apache/commons/io/ByteOrderMark.length:()I
        //   230: goto            237
        //   233: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   236: athrow         
        //   237: aload_0        
        //   238: getfield        org/apache/commons/io/input/BOMInputStream.firstBytes:[I
        //   241: arraylength    
        //   242: if_icmpge       267
        //   245: aload_0        
        //   246: aload_0        
        //   247: getfield        org/apache/commons/io/input/BOMInputStream.byteOrderMark:Lorg/apache/commons/io/ByteOrderMark;
        //   250: invokevirtual   org/apache/commons/io/ByteOrderMark.length:()I
        //   253: goto            260
        //   256: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   259: athrow         
        //   260: putfield        org/apache/commons/io/input/BOMInputStream.fbIndex:I
        //   263: aload_1        
        //   264: ifnull          276
        //   267: aload_0        
        //   268: iconst_0       
        //   269: aload_1        
        //   270: ifnonnull       260
        //   273: putfield        org/apache/commons/io/input/BOMInputStream.fbLength:I
        //   276: aload_0        
        //   277: getfield        org/apache/commons/io/input/BOMInputStream.byteOrderMark:Lorg/apache/commons/io/ByteOrderMark;
        //   280: aload_1        
        //   281: ifnonnull       45
        //   284: areturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 22 FF 00 12 00 02 07 00 02 07 00 33 00 01 07 00 50 03 52 07 00 50 43 07 00 1D FD 00 0C 01 01 70 07 00 50 43 01 45 07 00 50 03 46 07 00 50 03 45 07 00 50 03 03 56 07 00 50 43 07 00 1D 45 07 00 50 03 40 07 00 02 49 07 00 50 43 01 49 07 00 50 03 47 07 00 50 43 07 00 02 48 07 00 50 43 01 52 07 00 50 FF 00 03 00 04 07 00 02 07 00 33 01 01 00 02 07 00 02 01 06 40 07 00 02 F9 00 07 40 07 00 02 46 07 00 1D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  4      15     18     22     Ljava/io/IOException;
        //  9      38     41     45     Ljava/io/IOException;
        //  67     104    107    111    Ljava/io/IOException;
        //  94     114    117    121    Ljava/io/IOException;
        //  111    125    128    132    Ljava/io/IOException;
        //  121    135    138    142    Ljava/io/IOException;
        //  146    166    169    173    Ljava/io/IOException;
        //  159    176    179    183    Ljava/io/IOException;
        //  184    191    194    198    Ljava/io/IOException;
        //  198    205    208    212    Ljava/io/IOException;
        //  202    217    220    224    Ljava/io/IOException;
        //  212    230    233    237    Ljava/io/IOException;
        //  237    253    256    260    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0111:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public String getBOMCharsetName() throws IOException {
        final String b = ProxyInputStream.b();
        this.getBOM();
        final String s = b;
        Label_0027: {
            ByteOrderMark byteOrderMark;
            try {
                final ByteOrderMark byteOrderMark2;
                byteOrderMark = (byteOrderMark2 = this.byteOrderMark);
                if (s != null) {
                    return byteOrderMark2.getCharsetName();
                }
                if (byteOrderMark == null) {
                    break Label_0027;
                }
                break Label_0027;
            }
            catch (IOException ex) {
                throw b((Exception)ex);
            }
            try {
                if (byteOrderMark == null) {
                    return null;
                }
            }
            catch (IOException ex2) {
                throw b((Exception)ex2);
            }
        }
        ByteOrderMark byteOrderMark2 = this.byteOrderMark;
        return byteOrderMark2.getCharsetName();
    }
    
    private int readFirstBytes() throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: invokevirtual   org/apache/commons/io/input/BOMInputStream.getBOM:()Lorg/apache/commons/io/ByteOrderMark;
        //     7: pop            
        //     8: astore_1       
        //     9: aload_0        
        //    10: getfield        org/apache/commons/io/input/BOMInputStream.fbIndex:I
        //    13: aload_1        
        //    14: ifnonnull       65
        //    17: aload_1        
        //    18: ifnonnull       65
        //    21: goto            28
        //    24: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    27: athrow         
        //    28: aload_0        
        //    29: getfield        org/apache/commons/io/input/BOMInputStream.fbLength:I
        //    32: if_icmpge       68
        //    35: goto            42
        //    38: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    41: athrow         
        //    42: aload_0        
        //    43: getfield        org/apache/commons/io/input/BOMInputStream.firstBytes:[I
        //    46: aload_0        
        //    47: dup            
        //    48: getfield        org/apache/commons/io/input/BOMInputStream.fbIndex:I
        //    51: dup_x1         
        //    52: iconst_1       
        //    53: iadd           
        //    54: putfield        org/apache/commons/io/input/BOMInputStream.fbIndex:I
        //    57: iaload         
        //    58: goto            65
        //    61: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    64: athrow         
        //    65: goto            69
        //    68: iconst_m1      
        //    69: ireturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 08 58 07 00 50 43 01 49 07 00 50 03 52 07 00 50 43 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  9      21     24     28     Ljava/io/IOException;
        //  17     35     38     42     Ljava/io/IOException;
        //  28     58     61     65     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0028:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private ByteOrderMark find() {
        final String b = ProxyInputStream.b();
        final Iterator rs = q.rs(this.boms);
        final String s = b;
        while (q.oi(rs)) {
            final ByteOrderMark byteOrderMark = (ByteOrderMark)q.ou(rs);
            try {
                if (this.matches(byteOrderMark)) {
                    return byteOrderMark;
                }
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            if (s != null) {
                break;
            }
        }
        return null;
    }
    
    private boolean matches(final ByteOrderMark p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: iconst_0       
        //     4: istore_3       
        //     5: astore_2       
        //     6: iload_3        
        //     7: aload_1        
        //     8: invokevirtual   org/apache/commons/io/ByteOrderMark.length:()I
        //    11: if_icmpge       77
        //    14: aload_1        
        //    15: iload_3        
        //    16: invokevirtual   org/apache/commons/io/ByteOrderMark.get:(I)I
        //    19: aload_2        
        //    20: ifnonnull       78
        //    23: aload_2        
        //    24: ifnonnull       69
        //    27: goto            34
        //    30: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    33: athrow         
        //    34: aload_2        
        //    35: ifnonnull       69
        //    38: goto            45
        //    41: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    44: athrow         
        //    45: aload_0        
        //    46: getfield        org/apache/commons/io/input/BOMInputStream.firstBytes:[I
        //    49: iload_3        
        //    50: iaload         
        //    51: if_icmpeq       70
        //    54: goto            61
        //    57: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    60: athrow         
        //    61: iconst_0       
        //    62: goto            69
        //    65: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    68: athrow         
        //    69: ireturn        
        //    70: iinc            3, 1
        //    73: aload_2        
        //    74: ifnull          6
        //    77: iconst_1       
        //    78: ireturn        
        //    StackMapTable: 00 0C FD 00 06 07 00 33 01 57 07 00 27 43 01 46 07 00 27 43 01 4B 07 00 27 03 43 07 00 27 43 01 00 06 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  14     27     30     34     Ljava/lang/IllegalArgumentException;
        //  23     38     41     45     Ljava/lang/IllegalArgumentException;
        //  34     54     57     61     Ljava/lang/IllegalArgumentException;
        //  45     62     65     69     Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0034:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public int read() throws IOException {
        final String b = ProxyInputStream.b();
        final int firstBytes = this.readFirstBytes();
        final String s = b;
        int n = 0;
        Label_0039: {
            Label_0025: {
                try {
                    n = firstBytes;
                    if (s != null) {
                        return n;
                    }
                    final String s2 = s;
                    if (s2 == null) {
                        break Label_0025;
                    }
                    return n;
                }
                catch (IOException ex) {
                    throw b((Exception)ex);
                }
                try {
                    final String s2 = s;
                    if (s2 != null) {
                        return n;
                    }
                    if (n < 0) {
                        break Label_0039;
                    }
                }
                catch (IOException ex2) {
                    throw b((Exception)ex2);
                }
            }
            return n;
        }
        q.kt(this.in);
        return n;
    }
    
    @Override
    public int read(final byte[] array, int n, int n2) throws IOException {
        final String b = ProxyInputStream.b();
        int n3 = 0;
        final String s = b;
        int firstBytes = 0;
        goto Label_0011;
        // iftrue(Label_0012:, s != null || n4 < 0)
        // iftrue(Label_0132:, s != null)
        // iftrue(Label_0011:, s == null)
        // iftrue(Label_0096:, n9 <= 0)
        // iftrue(Label_0064:, s != null)
    Label_0152:
        while (true) {
            Label_0130: {
                int n5 = 0;
                int n8 = 0;
            Block_1_Outer:
                while (true) {
                    int n10 = 0;
                    Label_0106: {
                        int n7;
                        int n6;
                        while (true) {
                        Label_0091:
                            while (true) {
                                int n4;
                                final int n9;
                                String s2;
                                Block_5:Label_0096_Outer:
                                while (true) {
                                    break Block_5;
                                Label_0161_Outer:
                                    while (true) {
                                        q.yn(this.in, array, n, n2);
                                        break Label_0106;
                                        while (true) {
                                            n5 = (n6 = (n7 = n3));
                                            return n5 + n8;
                                            continue Label_0161_Outer;
                                            try {
                                                if (s != null) {
                                                    return n5 + n8;
                                                }
                                                if (n9 >= 0) {
                                                    continue Block_1_Outer;
                                                }
                                            }
                                            catch (IOException ex) {
                                                throw b((Exception)ex);
                                            }
                                            break;
                                        }
                                        break Label_0130;
                                        Label_0034: {
                                            try {
                                                n10 = firstBytes;
                                                if (s != null) {
                                                    break Label_0106;
                                                }
                                                s2 = s;
                                                if (s2 == null) {
                                                    break Label_0034;
                                                }
                                                break Label_0106;
                                            }
                                            catch (IOException ex2) {
                                                throw b((Exception)ex2);
                                            }
                                            try {
                                                s2 = s;
                                                if (s2 != null) {
                                                    break Label_0106;
                                                }
                                                if (n10 < 0) {
                                                    continue Label_0161_Outer;
                                                }
                                            }
                                            catch (IOException ex3) {
                                                throw b((Exception)ex3);
                                            }
                                        }
                                        break;
                                    }
                                    firstBytes = this.readFirstBytes();
                                    try {
                                        if (s != null) {
                                            continue Label_0091;
                                        }
                                        n4 = firstBytes;
                                    }
                                    catch (IOException ex4) {
                                        throw b((Exception)ex4);
                                    }
                                    continue Label_0096_Outer;
                                }
                                array[n++] = (byte)(firstBytes & 0xFF);
                                --n2;
                                ++n3;
                                continue Label_0091;
                            }
                            Label_0012: {
                                continue;
                            }
                        }
                        try {
                            Label_0132: {
                                if (s != null) {
                                    return n7;
                                }
                            }
                            if (n6 <= 0) {
                                break Label_0152;
                            }
                        }
                        catch (IOException ex5) {
                            throw b((Exception)ex5);
                        }
                        return n3;
                    }
                    n8 = n10;
                    final int n11;
                    final int n9 = n11 = (n5 = n8);
                    continue;
                }
                int n7 = n3;
                Label_0149: {
                    return n7;
                }
                n7 = n5 + n8;
                return n7;
            }
            int n6;
            int n7 = n6 = n3;
            continue;
        }
        // iftrue(Label_0149:, s != null)
        return -1;
    }
    
    @Override
    public int read(final byte[] array) throws IOException {
        return this.read(array, 0, array.length);
    }
    
    @Override
    public synchronized void mark(final int p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_0        
        //     5: aload_0        
        //     6: getfield        org/apache/commons/io/input/BOMInputStream.fbIndex:I
        //     9: aload_2        
        //    10: ifnonnull       50
        //    13: aload_2        
        //    14: ifnonnull       50
        //    17: goto            24
        //    20: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    23: athrow         
        //    24: putfield        org/apache/commons/io/input/BOMInputStream.markFbIndex:I
        //    27: aload_0        
        //    28: aload_0        
        //    29: getfield        org/apache/commons/io/input/BOMInputStream.firstBytes:[I
        //    32: ifnonnull       53
        //    35: goto            42
        //    38: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    41: athrow         
        //    42: iconst_1       
        //    43: goto            50
        //    46: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    49: athrow         
        //    50: goto            54
        //    53: iconst_0       
        //    54: putfield        org/apache/commons/io/input/BOMInputStream.markedAtStart:Z
        //    57: aload_0        
        //    58: getfield        org/apache/commons/io/input/BOMInputStream.in:Ljava/io/InputStream;
        //    61: iload_1        
        //    62: invokestatic    q/o/m/s/q.xm:(Ljava/io/InputStream;I)V
        //    65: return         
        //    StackMapTable: 00 08 FF 00 14 00 03 07 00 02 01 07 00 33 00 01 07 00 27 FF 00 03 00 03 07 00 02 01 07 00 33 00 02 07 00 02 01 4D 07 00 27 43 07 00 02 43 07 00 27 FF 00 03 00 03 07 00 02 01 07 00 33 00 02 07 00 02 01 42 07 00 02 FF 00 00 00 02 07 00 02 01 00 02 07 00 02 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  4      17     20     24     Ljava/lang/IllegalArgumentException;
        //  13     35     38     42     Ljava/lang/IllegalArgumentException;
        //  24     43     46     50     Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0024:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public synchronized void reset() throws IOException {
        this.fbIndex = this.markFbIndex;
        final String b = ProxyInputStream.b();
        InputStream in = null;
        Label_0050: {
            while (true) {
                Label_0042: {
                    BOMInputStream bomInputStream = null;
                    Label_0030: {
                        try {
                            in = this;
                            if (b != null) {
                                break Label_0050;
                            }
                            final boolean b2 = this.markedAtStart;
                            if (b2) {
                                break Label_0030;
                            }
                            break Label_0042;
                        }
                        catch (IOException ex) {
                            throw b((Exception)ex);
                        }
                        try {
                            final boolean b2 = this.markedAtStart;
                            if (!b2) {
                                break Label_0042;
                            }
                            bomInputStream = this;
                        }
                        catch (IOException ex2) {
                            throw b((Exception)ex2);
                        }
                    }
                    bomInputStream.firstBytes = null;
                }
                BOMInputStream bomInputStream = this;
                if (b != null) {
                    continue;
                }
                break;
            }
            in = this.in;
        }
        q.xv(in);
    }
    
    @Override
    public long skip(final long p0) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: iconst_0       
        //     4: istore          4
        //     6: astore_3       
        //     7: lload_1        
        //     8: iload           4
        //    10: i2l            
        //    11: lcmp           
        //    12: ifle            58
        //    15: aload_0        
        //    16: aload_3        
        //    17: ifnonnull       62
        //    20: aload_3        
        //    21: ifnonnull       62
        //    24: goto            31
        //    27: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    30: athrow         
        //    31: invokespecial   org/apache/commons/io/input/BOMInputStream.readFirstBytes:()I
        //    34: iflt            58
        //    37: goto            44
        //    40: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    43: athrow         
        //    44: iinc            4, 1
        //    47: aload_3        
        //    48: ifnull          7
        //    51: goto            58
        //    54: invokestatic    org/apache/commons/io/input/BOMInputStream.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    57: athrow         
        //    58: aload_0        
        //    59: getfield        org/apache/commons/io/input/BOMInputStream.in:Ljava/io/InputStream;
        //    62: lload_1        
        //    63: iload           4
        //    65: i2l            
        //    66: lsub           
        //    67: invokestatic    q/o/m/s/q.xo:(Ljava/io/InputStream;J)J
        //    70: iload           4
        //    72: i2l            
        //    73: ladd           
        //    74: lreturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 08 FD 00 07 07 00 33 01 53 07 00 50 43 07 00 02 48 07 00 50 03 49 07 00 50 03 43 07 00 2F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  15     24     27     31     Ljava/io/IOException;
        //  20     37     40     44     Ljava/io/IOException;
        //  31     51     54     58     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0031:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        final String[] a2 = new String[2];
        int n = 0;
        final String qv;
        final int q = q.o.m.s.q.q(qv = n.d.a.d.q.qv());
        int j = 17;
        int n2 = -1;
        Label_0023: {
            break Label_0023;
            do {
                j = q.o.m.s.q.j(qv, n2);
                int n5;
                int n4;
                final int n3 = n4 = (n5 = 95);
                ++n2;
                final String s = qv;
                final int n6 = n2;
                final char[] g = q.o.m.s.q.g(q.o.m.s.q.h(s, n6, n6 + j));
                final int length = g.length;
                int n7 = 0;
                while (true) {
                    Label_0200: {
                        if (length > 1) {
                            break Label_0200;
                        }
                        n5 = (n4 = n7);
                        do {
                            final char c2 = g[n4];
                            int n8 = 0;
                            switch (n7 % 7) {
                                case 0: {
                                    n8 = 122;
                                    break;
                                }
                                case 1: {
                                    n8 = 71;
                                    break;
                                }
                                case 2: {
                                    n8 = 56;
                                    break;
                                }
                                case 3: {
                                    n8 = 50;
                                    break;
                                }
                                case 4: {
                                    n8 = 46;
                                    break;
                                }
                                case 5: {
                                    n8 = 104;
                                    break;
                                }
                                default: {
                                    n8 = 29;
                                    break;
                                }
                            }
                            g[n5] = (char)(c2 ^ (n3 ^ n8));
                            ++n7;
                        } while (n3 == 0);
                    }
                    if (length > n7) {
                        continue;
                    }
                    break;
                }
                a2[n++] = q.o.m.s.q.z(new String(g));
            } while ((n2 += j) < q);
        }
        a = a2;
        c = new String[2];
        ByteOrderMarkLengthComparator = new BOMInputStream$1();
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0xFFFFD77E) & 0xFFFF;
        if (BOMInputStream.c[n3] == null) {
            final char[] g = q.g(BOMInputStream.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 178;
                    break;
                }
                case 1: {
                    n4 = 15;
                    break;
                }
                case 2: {
                    n4 = 160;
                    break;
                }
                case 3: {
                    n4 = 53;
                    break;
                }
                case 4: {
                    n4 = 228;
                    break;
                }
                case 5: {
                    n4 = 94;
                    break;
                }
                case 6: {
                    n4 = 86;
                    break;
                }
                case 7: {
                    n4 = 157;
                    break;
                }
                case 8: {
                    n4 = 21;
                    break;
                }
                case 9: {
                    n4 = 166;
                    break;
                }
                case 10: {
                    n4 = 82;
                    break;
                }
                case 11: {
                    n4 = 17;
                    break;
                }
                case 12: {
                    n4 = 232;
                    break;
                }
                case 13: {
                    n4 = 196;
                    break;
                }
                case 14: {
                    n4 = 90;
                    break;
                }
                case 15: {
                    n4 = 85;
                    break;
                }
                case 16: {
                    n4 = 203;
                    break;
                }
                case 17: {
                    n4 = 46;
                    break;
                }
                case 18: {
                    n4 = 87;
                    break;
                }
                case 19: {
                    n4 = 236;
                    break;
                }
                case 20: {
                    n4 = 251;
                    break;
                }
                case 21: {
                    n4 = 38;
                    break;
                }
                case 22: {
                    n4 = 205;
                    break;
                }
                case 23: {
                    n4 = 126;
                    break;
                }
                case 24: {
                    n4 = 123;
                    break;
                }
                case 25: {
                    n4 = 137;
                    break;
                }
                case 26: {
                    n4 = 26;
                    break;
                }
                case 27: {
                    n4 = 36;
                    break;
                }
                case 28: {
                    n4 = 70;
                    break;
                }
                case 29: {
                    n4 = 10;
                    break;
                }
                case 30: {
                    n4 = 109;
                    break;
                }
                case 31: {
                    n4 = 249;
                    break;
                }
                case 32: {
                    n4 = 154;
                    break;
                }
                case 33: {
                    n4 = 3;
                    break;
                }
                case 34: {
                    n4 = 75;
                    break;
                }
                case 35: {
                    n4 = 177;
                    break;
                }
                case 36: {
                    n4 = 35;
                    break;
                }
                case 37: {
                    n4 = 213;
                    break;
                }
                case 38: {
                    n4 = 208;
                    break;
                }
                case 39: {
                    n4 = 239;
                    break;
                }
                case 40: {
                    n4 = 8;
                    break;
                }
                case 41: {
                    n4 = 209;
                    break;
                }
                case 42: {
                    n4 = 115;
                    break;
                }
                case 43: {
                    n4 = 116;
                    break;
                }
                case 44: {
                    n4 = 188;
                    break;
                }
                case 45: {
                    n4 = 199;
                    break;
                }
                case 46: {
                    n4 = 149;
                    break;
                }
                case 47: {
                    n4 = 146;
                    break;
                }
                case 48: {
                    n4 = 14;
                    break;
                }
                case 49: {
                    n4 = 74;
                    break;
                }
                case 50: {
                    n4 = 113;
                    break;
                }
                case 51: {
                    n4 = 133;
                    break;
                }
                case 52: {
                    n4 = 187;
                    break;
                }
                case 53: {
                    n4 = 79;
                    break;
                }
                case 54: {
                    n4 = 0;
                    break;
                }
                case 55: {
                    n4 = 7;
                    break;
                }
                case 56: {
                    n4 = 142;
                    break;
                }
                case 57: {
                    n4 = 237;
                    break;
                }
                case 58: {
                    n4 = 73;
                    break;
                }
                case 59: {
                    n4 = 78;
                    break;
                }
                case 60: {
                    n4 = 165;
                    break;
                }
                case 61: {
                    n4 = 235;
                    break;
                }
                case 62: {
                    n4 = 233;
                    break;
                }
                case 63: {
                    n4 = 40;
                    break;
                }
                case 64: {
                    n4 = 153;
                    break;
                }
                case 65: {
                    n4 = 186;
                    break;
                }
                case 66: {
                    n4 = 132;
                    break;
                }
                case 67: {
                    n4 = 77;
                    break;
                }
                case 68: {
                    n4 = 6;
                    break;
                }
                case 69: {
                    n4 = 80;
                    break;
                }
                case 70: {
                    n4 = 201;
                    break;
                }
                case 71: {
                    n4 = 104;
                    break;
                }
                case 72: {
                    n4 = 59;
                    break;
                }
                case 73: {
                    n4 = 2;
                    break;
                }
                case 74: {
                    n4 = 24;
                    break;
                }
                case 75: {
                    n4 = 147;
                    break;
                }
                case 76: {
                    n4 = 171;
                    break;
                }
                case 77: {
                    n4 = 119;
                    break;
                }
                case 78: {
                    n4 = 244;
                    break;
                }
                case 79: {
                    n4 = 211;
                    break;
                }
                case 80: {
                    n4 = 210;
                    break;
                }
                case 81: {
                    n4 = 252;
                    break;
                }
                case 82: {
                    n4 = 204;
                    break;
                }
                case 83: {
                    n4 = 124;
                    break;
                }
                case 84: {
                    n4 = 61;
                    break;
                }
                case 85: {
                    n4 = 223;
                    break;
                }
                case 86: {
                    n4 = 218;
                    break;
                }
                case 87: {
                    n4 = 134;
                    break;
                }
                case 88: {
                    n4 = 100;
                    break;
                }
                case 89: {
                    n4 = 48;
                    break;
                }
                case 90: {
                    n4 = 248;
                    break;
                }
                case 91: {
                    n4 = 45;
                    break;
                }
                case 92: {
                    n4 = 162;
                    break;
                }
                case 93: {
                    n4 = 207;
                    break;
                }
                case 94: {
                    n4 = 226;
                    break;
                }
                case 95: {
                    n4 = 9;
                    break;
                }
                case 96: {
                    n4 = 13;
                    break;
                }
                case 97: {
                    n4 = 76;
                    break;
                }
                case 98: {
                    n4 = 49;
                    break;
                }
                case 99: {
                    n4 = 229;
                    break;
                }
                case 100: {
                    n4 = 202;
                    break;
                }
                case 101: {
                    n4 = 122;
                    break;
                }
                case 102: {
                    n4 = 121;
                    break;
                }
                case 103: {
                    n4 = 65;
                    break;
                }
                case 104: {
                    n4 = 158;
                    break;
                }
                case 105: {
                    n4 = 102;
                    break;
                }
                case 106: {
                    n4 = 30;
                    break;
                }
                case 107: {
                    n4 = 163;
                    break;
                }
                case 108: {
                    n4 = 62;
                    break;
                }
                case 109: {
                    n4 = 192;
                    break;
                }
                case 110: {
                    n4 = 255;
                    break;
                }
                case 111: {
                    n4 = 238;
                    break;
                }
                case 112: {
                    n4 = 41;
                    break;
                }
                case 113: {
                    n4 = 27;
                    break;
                }
                case 114: {
                    n4 = 193;
                    break;
                }
                case 115: {
                    n4 = 69;
                    break;
                }
                case 116: {
                    n4 = 50;
                    break;
                }
                case 117: {
                    n4 = 12;
                    break;
                }
                case 118: {
                    n4 = 250;
                    break;
                }
                case 119: {
                    n4 = 169;
                    break;
                }
                case 120: {
                    n4 = 68;
                    break;
                }
                case 121: {
                    n4 = 175;
                    break;
                }
                case 122: {
                    n4 = 67;
                    break;
                }
                case 123: {
                    n4 = 33;
                    break;
                }
                case 124: {
                    n4 = 127;
                    break;
                }
                case 125: {
                    n4 = 18;
                    break;
                }
                case 126: {
                    n4 = 227;
                    break;
                }
                case 127: {
                    n4 = 240;
                    break;
                }
                case 128: {
                    n4 = 200;
                    break;
                }
                case 129: {
                    n4 = 168;
                    break;
                }
                case 130: {
                    n4 = 140;
                    break;
                }
                case 131: {
                    n4 = 129;
                    break;
                }
                case 132: {
                    n4 = 103;
                    break;
                }
                case 133: {
                    n4 = 31;
                    break;
                }
                case 134: {
                    n4 = 63;
                    break;
                }
                case 135: {
                    n4 = 136;
                    break;
                }
                case 136: {
                    n4 = 66;
                    break;
                }
                case 137: {
                    n4 = 101;
                    break;
                }
                case 138: {
                    n4 = 16;
                    break;
                }
                case 139: {
                    n4 = 118;
                    break;
                }
                case 140: {
                    n4 = 60;
                    break;
                }
                case 141: {
                    n4 = 29;
                    break;
                }
                case 142: {
                    n4 = 148;
                    break;
                }
                case 143: {
                    n4 = 117;
                    break;
                }
                case 144: {
                    n4 = 190;
                    break;
                }
                case 145: {
                    n4 = 159;
                    break;
                }
                case 146: {
                    n4 = 151;
                    break;
                }
                case 147: {
                    n4 = 125;
                    break;
                }
                case 148: {
                    n4 = 219;
                    break;
                }
                case 149: {
                    n4 = 161;
                    break;
                }
                case 150: {
                    n4 = 89;
                    break;
                }
                case 151: {
                    n4 = 42;
                    break;
                }
                case 152: {
                    n4 = 164;
                    break;
                }
                case 153: {
                    n4 = 64;
                    break;
                }
                case 154: {
                    n4 = 217;
                    break;
                }
                case 155: {
                    n4 = 131;
                    break;
                }
                case 156: {
                    n4 = 220;
                    break;
                }
                case 157: {
                    n4 = 212;
                    break;
                }
                case 158: {
                    n4 = 55;
                    break;
                }
                case 159: {
                    n4 = 58;
                    break;
                }
                case 160: {
                    n4 = 83;
                    break;
                }
                case 161: {
                    n4 = 11;
                    break;
                }
                case 162: {
                    n4 = 52;
                    break;
                }
                case 163: {
                    n4 = 128;
                    break;
                }
                case 164: {
                    n4 = 215;
                    break;
                }
                case 165: {
                    n4 = 180;
                    break;
                }
                case 166: {
                    n4 = 37;
                    break;
                }
                case 167: {
                    n4 = 56;
                    break;
                }
                case 168: {
                    n4 = 222;
                    break;
                }
                case 169: {
                    n4 = 231;
                    break;
                }
                case 170: {
                    n4 = 195;
                    break;
                }
                case 171: {
                    n4 = 20;
                    break;
                }
                case 172: {
                    n4 = 22;
                    break;
                }
                case 173: {
                    n4 = 214;
                    break;
                }
                case 174: {
                    n4 = 106;
                    break;
                }
                case 175: {
                    n4 = 57;
                    break;
                }
                case 176: {
                    n4 = 138;
                    break;
                }
                case 177: {
                    n4 = 253;
                    break;
                }
                case 178: {
                    n4 = 43;
                    break;
                }
                case 179: {
                    n4 = 95;
                    break;
                }
                case 180: {
                    n4 = 179;
                    break;
                }
                case 181: {
                    n4 = 32;
                    break;
                }
                case 182: {
                    n4 = 185;
                    break;
                }
                case 183: {
                    n4 = 172;
                    break;
                }
                case 184: {
                    n4 = 194;
                    break;
                }
                case 185: {
                    n4 = 28;
                    break;
                }
                case 186: {
                    n4 = 225;
                    break;
                }
                case 187: {
                    n4 = 234;
                    break;
                }
                case 188: {
                    n4 = 141;
                    break;
                }
                case 189: {
                    n4 = 216;
                    break;
                }
                case 190: {
                    n4 = 84;
                    break;
                }
                case 191: {
                    n4 = 81;
                    break;
                }
                case 192: {
                    n4 = 139;
                    break;
                }
                case 193: {
                    n4 = 44;
                    break;
                }
                case 194: {
                    n4 = 34;
                    break;
                }
                case 195: {
                    n4 = 246;
                    break;
                }
                case 196: {
                    n4 = 156;
                    break;
                }
                case 197: {
                    n4 = 181;
                    break;
                }
                case 198: {
                    n4 = 96;
                    break;
                }
                case 199: {
                    n4 = 5;
                    break;
                }
                case 200: {
                    n4 = 173;
                    break;
                }
                case 201: {
                    n4 = 110;
                    break;
                }
                case 202: {
                    n4 = 145;
                    break;
                }
                case 203: {
                    n4 = 4;
                    break;
                }
                case 204: {
                    n4 = 120;
                    break;
                }
                case 205: {
                    n4 = 242;
                    break;
                }
                case 206: {
                    n4 = 99;
                    break;
                }
                case 207: {
                    n4 = 51;
                    break;
                }
                case 208: {
                    n4 = 54;
                    break;
                }
                case 209: {
                    n4 = 93;
                    break;
                }
                case 210: {
                    n4 = 47;
                    break;
                }
                case 211: {
                    n4 = 230;
                    break;
                }
                case 212: {
                    n4 = 130;
                    break;
                }
                case 213: {
                    n4 = 144;
                    break;
                }
                case 214: {
                    n4 = 247;
                    break;
                }
                case 215: {
                    n4 = 19;
                    break;
                }
                case 216: {
                    n4 = 243;
                    break;
                }
                case 217: {
                    n4 = 98;
                    break;
                }
                case 218: {
                    n4 = 105;
                    break;
                }
                case 219: {
                    n4 = 183;
                    break;
                }
                case 220: {
                    n4 = 143;
                    break;
                }
                case 221: {
                    n4 = 135;
                    break;
                }
                case 222: {
                    n4 = 72;
                    break;
                }
                case 223: {
                    n4 = 206;
                    break;
                }
                case 224: {
                    n4 = 91;
                    break;
                }
                case 225: {
                    n4 = 97;
                    break;
                }
                case 226: {
                    n4 = 197;
                    break;
                }
                case 227: {
                    n4 = 221;
                    break;
                }
                case 228: {
                    n4 = 254;
                    break;
                }
                case 229: {
                    n4 = 191;
                    break;
                }
                case 230: {
                    n4 = 184;
                    break;
                }
                case 231: {
                    n4 = 174;
                    break;
                }
                case 232: {
                    n4 = 23;
                    break;
                }
                case 233: {
                    n4 = 170;
                    break;
                }
                case 234: {
                    n4 = 224;
                    break;
                }
                case 235: {
                    n4 = 112;
                    break;
                }
                case 236: {
                    n4 = 25;
                    break;
                }
                case 237: {
                    n4 = 92;
                    break;
                }
                case 238: {
                    n4 = 114;
                    break;
                }
                case 239: {
                    n4 = 1;
                    break;
                }
                case 240: {
                    n4 = 152;
                    break;
                }
                case 241: {
                    n4 = 107;
                    break;
                }
                case 242: {
                    n4 = 111;
                    break;
                }
                case 243: {
                    n4 = 150;
                    break;
                }
                case 244: {
                    n4 = 198;
                    break;
                }
                case 245: {
                    n4 = 176;
                    break;
                }
                case 246: {
                    n4 = 88;
                    break;
                }
                case 247: {
                    n4 = 189;
                    break;
                }
                case 248: {
                    n4 = 39;
                    break;
                }
                case 249: {
                    n4 = 245;
                    break;
                }
                case 250: {
                    n4 = 108;
                    break;
                }
                case 251: {
                    n4 = 241;
                    break;
                }
                case 252: {
                    n4 = 182;
                    break;
                }
                case 253: {
                    n4 = 71;
                    break;
                }
                case 254: {
                    n4 = 155;
                    break;
                }
                default: {
                    n4 = 167;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            BOMInputStream.c[n3] = q.z(new String(g));
        }
        return BOMInputStream.c[n3];
    }
}
