// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import java.io.IOException;
import java.nio.charset.Charset;
import q.o.m.s.q;
import java.nio.charset.CoderResult;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharsetEncoder;
import java.io.Reader;
import java.io.InputStream;

public class ReaderInputStream extends InputStream
{
    private static final int DEFAULT_BUFFER_SIZE = 1024;
    private final Reader reader;
    private final CharsetEncoder encoder;
    private final CharBuffer encoderIn;
    private final ByteBuffer encoderOut;
    private CoderResult lastCoderResult;
    private boolean endOfInput;
    private static final String[] a;
    private static final String[] b;
    
    public ReaderInputStream(final Reader reader, final CharsetEncoder charsetEncoder) {
        this(reader, charsetEncoder, 1024);
    }
    
    public ReaderInputStream(final Reader reader, final CharsetEncoder encoder, final int n) {
        this.reader = reader;
        this.encoder = encoder;
        q.hg(this.encoderIn = q.hj(n));
        q.nq(this.encoderOut = q.nf(128));
    }
    
    public ReaderInputStream(final Reader reader, final Charset charset, final int n) {
        this(reader, q.xp(q.xn(q.xe(charset), x.dn.g.b.q.y()), x.dn.g.b.q.y()), n);
    }
    
    public ReaderInputStream(final Reader reader, final Charset charset) {
        this(reader, charset, 1024);
    }
    
    public ReaderInputStream(final Reader reader, final String s, final int n) {
        this(reader, q.sh(s), n);
    }
    
    public ReaderInputStream(final Reader reader, final String s) {
        this(reader, s, 1024);
    }
    
    @Deprecated
    public ReaderInputStream(final Reader reader) {
        this(reader, q.sx());
    }
    
    private void fillBuffer() throws IOException {
        final String b = ProxyInputStream.b();
        while (true) {
            ReaderInputStream readerInputStream = null;
            Label_0209: {
                while (true) {
                    Label_0173: {
                        ReaderInputStream readerInputStream2 = null;
                        ReaderInputStream readerInputStream3 = null;
                        Label_0022: {
                            try {
                                readerInputStream = this;
                                if (b != null) {
                                    break Label_0209;
                                }
                                final boolean b2 = this.endOfInput;
                                if (!b2) {
                                    break Label_0022;
                                }
                                break Label_0173;
                            }
                            catch (IOException ex) {
                                throw b(ex);
                            }
                            try {
                                final boolean b2 = this.endOfInput;
                                if (b2) {
                                    break Label_0173;
                                }
                                readerInputStream2 = this;
                                readerInputStream3 = this;
                            }
                            catch (IOException ex2) {
                                throw b(ex2);
                            }
                        }
                        Label_0165: {
                            int xi = 0;
                            int yj = 0;
                            Label_0139: {
                                int n = 0;
                                while (true) {
                                    Label_0077: {
                                        if (b != null) {
                                            break Label_0077;
                                        }
                                        Label_0068: {
                                            Label_0052: {
                                                try {
                                                    if (readerInputStream3.lastCoderResult == null) {
                                                        break Label_0068;
                                                    }
                                                    readerInputStream = this;
                                                    final ReaderInputStream readerInputStream4 = this;
                                                    final String s = b;
                                                    if (s == null) {
                                                        break Label_0052;
                                                    }
                                                    break Label_0209;
                                                }
                                                catch (IOException ex3) {
                                                    throw b(ex3);
                                                }
                                                try {
                                                    readerInputStream = this;
                                                    final ReaderInputStream readerInputStream4 = this;
                                                    final String s = b;
                                                    if (s != null) {
                                                        break Label_0209;
                                                    }
                                                    final boolean hz = q.hz(readerInputStream4.lastCoderResult);
                                                }
                                                catch (IOException ex4) {
                                                    throw b(ex4);
                                                }
                                            }
                                            if (n == 0) {
                                                break Label_0173;
                                            }
                                        }
                                        q.hd(this.encoderIn);
                                        readerInputStream2 = this;
                                    }
                                    xi = q.xi(readerInputStream2.encoderIn);
                                    yj = q.yj(this.reader, q.hb(this.encoderIn), xi, q.xl(this.encoderIn));
                                    try {
                                        if (b != null) {
                                            break Label_0139;
                                        }
                                        n = yj;
                                        if (b != null) {
                                            continue;
                                        }
                                    }
                                    catch (IOException ex5) {
                                        throw b(ex5);
                                    }
                                    break;
                                }
                                Label_0143: {
                                    ReaderInputStream readerInputStream5;
                                    try {
                                        if (n != -1) {
                                            break Label_0143;
                                        }
                                        readerInputStream5 = this;
                                    }
                                    catch (IOException ex6) {
                                        throw b(ex6);
                                    }
                                    while (true) {
                                        readerInputStream5.endOfInput = true;
                                        try {
                                            if (b == null) {
                                                break Label_0165;
                                            }
                                            readerInputStream5 = this;
                                            if (b != null) {
                                                continue;
                                            }
                                        }
                                        catch (IOException ex7) {
                                            throw b(ex7);
                                        }
                                        break;
                                    }
                                }
                            }
                            q.hw(this.encoderIn, xi + yj);
                        }
                        q.hg(this.encoderIn);
                    }
                    q.xh(this.encoderOut);
                    this.lastCoderResult = q.xj(this.encoder, this.encoderIn, this.encoderOut, this.endOfInput);
                    readerInputStream = this;
                    ReaderInputStream readerInputStream2 = this;
                    ReaderInputStream readerInputStream3 = this;
                    if (b != null) {
                        continue;
                    }
                    break;
                }
            }
            q.nq(readerInputStream.encoderOut);
            if (b == null) {
                return;
            }
            continue;
        }
    }
    
    @Override
    public int read(final byte[] p0, final int p1, final int p2) throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore          4
        //     5: aload_1        
        //     6: ifnonnull       30
        //     9: new             Ljava/lang/NullPointerException;
        //    12: dup            
        //    13: sipush          17107
        //    16: sipush          -4451
        //    19: invokestatic    org/apache/commons/io/input/ReaderInputStream.a:(II)Ljava/lang/String;
        //    22: invokespecial   java/lang/NullPointerException.<init>:(Ljava/lang/String;)V
        //    25: athrow         
        //    26: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    29: athrow         
        //    30: iload_3        
        //    31: aload           4
        //    33: ifnonnull       59
        //    36: aload           4
        //    38: ifnonnull       64
        //    41: goto            48
        //    44: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    47: athrow         
        //    48: iflt            113
        //    51: goto            58
        //    54: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    57: athrow         
        //    58: iload_2        
        //    59: aload           4
        //    61: ifnonnull       96
        //    64: aload           4
        //    66: ifnonnull       96
        //    69: goto            76
        //    72: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    75: athrow         
        //    76: iflt            113
        //    79: goto            86
        //    82: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    85: athrow         
        //    86: iload_2        
        //    87: iload_3        
        //    88: iadd           
        //    89: goto            96
        //    92: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    95: athrow         
        //    96: aload           4
        //    98: ifnonnull       185
        //   101: aload_1        
        //   102: arraylength    
        //   103: if_icmple       184
        //   106: goto            113
        //   109: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   112: athrow         
        //   113: new             Ljava/lang/IndexOutOfBoundsException;
        //   116: dup            
        //   117: new             Ljava/lang/StringBuilder;
        //   120: dup            
        //   121: invokespecial   java/lang/StringBuilder.<init>:()V
        //   124: sipush          17106
        //   127: sipush          27349
        //   130: invokestatic    org/apache/commons/io/input/ReaderInputStream.a:(II)Ljava/lang/String;
        //   133: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   136: aload_1        
        //   137: arraylength    
        //   138: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   141: sipush          17104
        //   144: sipush          -26209
        //   147: invokestatic    org/apache/commons/io/input/ReaderInputStream.a:(II)Ljava/lang/String;
        //   150: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   153: iload_2        
        //   154: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   157: sipush          17105
        //   160: sipush          28108
        //   163: invokestatic    org/apache/commons/io/input/ReaderInputStream.a:(II)Ljava/lang/String;
        //   166: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   169: iload_3        
        //   170: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   173: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   176: invokespecial   java/lang/IndexOutOfBoundsException.<init>:(Ljava/lang/String;)V
        //   179: athrow         
        //   180: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   183: athrow         
        //   184: iconst_0       
        //   185: istore          5
        //   187: iload_3        
        //   188: aload           4
        //   190: ifnonnull       211
        //   193: ifne            205
        //   196: goto            203
        //   199: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   202: athrow         
        //   203: iconst_0       
        //   204: ireturn        
        //   205: iload_3        
        //   206: aload           4
        //   208: ifnonnull       204
        //   211: ifle            358
        //   214: aload_0        
        //   215: getfield        org/apache/commons/io/input/ReaderInputStream.encoderOut:Ljava/nio/ByteBuffer;
        //   218: invokestatic    q/o/m/s/q.xd:(Ljava/nio/ByteBuffer;)Z
        //   221: aload           4
        //   223: ifnonnull       360
        //   226: aload           4
        //   228: ifnonnull       315
        //   231: goto            238
        //   234: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   237: athrow         
        //   238: ifeq            302
        //   241: goto            248
        //   244: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   247: athrow         
        //   248: aload_0        
        //   249: getfield        org/apache/commons/io/input/ReaderInputStream.encoderOut:Ljava/nio/ByteBuffer;
        //   252: invokestatic    q/o/m/s/q.yw:(Ljava/nio/ByteBuffer;)I
        //   255: iload_3        
        //   256: invokestatic    q/o/m/s/q.px:(II)I
        //   259: goto            266
        //   262: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   265: athrow         
        //   266: istore          6
        //   268: aload_0        
        //   269: getfield        org/apache/commons/io/input/ReaderInputStream.encoderOut:Ljava/nio/ByteBuffer;
        //   272: aload_1        
        //   273: iload_2        
        //   274: iload           6
        //   276: invokestatic    q/o/m/s/q.xw:(Ljava/nio/ByteBuffer;[BII)Ljava/nio/ByteBuffer;
        //   279: pop            
        //   280: iload_2        
        //   281: iload           6
        //   283: iadd           
        //   284: istore_2       
        //   285: iload_3        
        //   286: iload           6
        //   288: isub           
        //   289: istore_3       
        //   290: iload           5
        //   292: iload           6
        //   294: iadd           
        //   295: istore          5
        //   297: aload           4
        //   299: ifnull          205
        //   302: aload_0        
        //   303: invokespecial   org/apache/commons/io/input/ReaderInputStream.fillBuffer:()V
        //   306: aload_0        
        //   307: getfield        org/apache/commons/io/input/ReaderInputStream.endOfInput:Z
        //   310: aload           4
        //   312: ifnonnull       266
        //   315: aload           4
        //   317: ifnonnull       347
        //   320: ifeq            205
        //   323: goto            330
        //   326: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   329: athrow         
        //   330: aload_0        
        //   331: getfield        org/apache/commons/io/input/ReaderInputStream.encoderOut:Ljava/nio/ByteBuffer;
        //   334: invokestatic    q/o/m/s/q.xd:(Ljava/nio/ByteBuffer;)Z
        //   337: aload           4
        //   339: ifnonnull       211
        //   342: aload           4
        //   344: ifnonnull       211
        //   347: aload           4
        //   349: ifnonnull       211
        //   352: ifne            205
        //   355: goto            358
        //   358: iload           5
        //   360: aload           4
        //   362: ifnonnull       398
        //   365: aload           4
        //   367: ifnonnull       403
        //   370: goto            377
        //   373: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   376: athrow         
        //   377: ifne            429
        //   380: goto            387
        //   383: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   386: athrow         
        //   387: aload_0        
        //   388: getfield        org/apache/commons/io/input/ReaderInputStream.endOfInput:Z
        //   391: goto            398
        //   394: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   397: athrow         
        //   398: aload           4
        //   400: ifnonnull       426
        //   403: aload           4
        //   405: ifnonnull       426
        //   408: goto            415
        //   411: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   414: athrow         
        //   415: ifeq            429
        //   418: goto            425
        //   421: invokestatic    org/apache/commons/io/input/ReaderInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //   424: athrow         
        //   425: iconst_m1      
        //   426: goto            431
        //   429: iload           5
        //   431: ireturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 33 FF 00 1A 00 05 07 00 02 07 00 9E 01 01 07 00 6A 00 01 07 00 61 03 4D 07 00 61 43 01 45 07 00 61 03 40 01 44 01 47 07 00 61 43 01 45 07 00 61 03 45 07 00 61 43 01 4C 07 00 61 03 F7 00 42 07 00 61 03 40 01 FF 00 0D 00 06 07 00 02 07 00 9E 01 01 07 00 6A 01 00 01 07 00 61 03 40 01 00 45 01 56 07 00 61 43 01 45 07 00 61 03 4D 07 00 61 43 01 23 4C 01 4A 07 00 61 03 50 01 0A 41 01 4C 07 00 61 43 01 45 07 00 61 03 46 07 00 61 43 01 44 01 47 07 00 61 43 01 45 07 00 61 03 40 01 02 41 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  5      26     26     30     Ljava/io/IOException;
        //  30     41     44     48     Ljava/io/IOException;
        //  36     51     54     58     Ljava/io/IOException;
        //  59     69     72     76     Ljava/io/IOException;
        //  64     79     82     86     Ljava/io/IOException;
        //  76     89     92     96     Ljava/io/IOException;
        //  96     106    109    113    Ljava/io/IOException;
        //  101    180    180    184    Ljava/io/IOException;
        //  187    196    199    203    Ljava/io/IOException;
        //  214    231    234    238    Ljava/io/IOException;
        //  226    241    244    248    Ljava/io/IOException;
        //  238    259    262    266    Ljava/io/IOException;
        //  315    323    326    330    Ljava/io/IOException;
        //  360    370    373    377    Ljava/io/IOException;
        //  365    380    383    387    Ljava/io/IOException;
        //  377    391    394    398    Ljava/io/IOException;
        //  398    408    411    415    Ljava/io/IOException;
        //  403    418    421    425    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0064:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public int read(final byte[] array) throws IOException {
        return this.read(array, 0, array.length);
    }
    
    @Override
    public int read() throws IOException {
        final String b = ProxyInputStream.b();
        int n = 0;
    Label_0025:
        while (true) {
            final boolean xd = q.xd(this.encoderOut);
            boolean xd2 = false;
            while (!xd2) {
                boolean endOfInput = false;
                Label_0059: {
                    try {
                        this.fillBuffer();
                        endOfInput = this.endOfInput;
                        if (b != null) {
                            break Label_0059;
                        }
                        if (!endOfInput) {
                            continue Label_0025;
                        }
                    }
                    catch (IOException ex) {
                        throw b(ex);
                    }
                    xd2 = q.xd(this.encoderOut);
                    if (b != null) {
                        continue;
                    }
                }
                if (endOfInput) {
                    continue Label_0025;
                }
                n = -1;
                if (b == null) {
                    return n;
                }
                break Label_0025;
            }
            final int n2 = q.xa(this.encoderOut) & 0xFF;
            break;
        }
        return n;
    }
    
    @Override
    public void close() throws IOException {
        q.xr(this.reader);
    }
    
    private static IOException b(final IOException ex) {
        return ex;
    }
    
    static {
        final String[] a2 = new String[4];
        int n = 0;
        String s;
        int n2 = q.q(s = n.d.a.d.q.qx());
        int n3 = 11;
        int n4 = -1;
    Label_0023:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 3));
                ++n4;
                final String s2 = s;
                final int n9 = n4;
                String s3 = q.h(s2, n9, n9 + n3);
                int n10 = -1;
                while (true) {
                    final char[] g = q.g(s3);
                    final int length = g.length;
                    int n11 = 0;
                    while (true) {
                        Label_0260: {
                            if (length > 1) {
                                break Label_0260;
                            }
                            n7 = (n6 = n11);
                            do {
                                final char c = g[n6];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 14;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 42;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 36;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 109;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 79;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 9;
                                        break;
                                    }
                                    default: {
                                        n12 = 32;
                                        break;
                                    }
                                }
                                g[n7] = (char)(c ^ (n5 ^ n12));
                                ++n11;
                            } while (n8 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.z(new String(g));
                    switch (n10) {
                        default: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                continue Label_0023;
                            }
                            n2 = q.q(s = n.d.a.d.q.qh());
                            n3 = 9;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                break;
                            }
                            break Label_0023;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 32)));
                    ++n4;
                    final String s4 = s;
                    final int n13 = n4;
                    s3 = q.h(s4, n13, n13 + n3);
                    n10 = 0;
                }
            }
            break;
        }
        a = a2;
        b = new String[4];
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0x42D2) & 0xFFFF;
        if (ReaderInputStream.b[n3] == null) {
            final char[] g = q.g(ReaderInputStream.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 228;
                    break;
                }
                case 1: {
                    n4 = 233;
                    break;
                }
                case 2: {
                    n4 = 26;
                    break;
                }
                case 3: {
                    n4 = 253;
                    break;
                }
                case 4: {
                    n4 = 54;
                    break;
                }
                case 5: {
                    n4 = 103;
                    break;
                }
                case 6: {
                    n4 = 42;
                    break;
                }
                case 7: {
                    n4 = 83;
                    break;
                }
                case 8: {
                    n4 = 49;
                    break;
                }
                case 9: {
                    n4 = 188;
                    break;
                }
                case 10: {
                    n4 = 8;
                    break;
                }
                case 11: {
                    n4 = 247;
                    break;
                }
                case 12: {
                    n4 = 222;
                    break;
                }
                case 13: {
                    n4 = 74;
                    break;
                }
                case 14: {
                    n4 = 117;
                    break;
                }
                case 15: {
                    n4 = 25;
                    break;
                }
                case 16: {
                    n4 = 2;
                    break;
                }
                case 17: {
                    n4 = 215;
                    break;
                }
                case 18: {
                    n4 = 109;
                    break;
                }
                case 19: {
                    n4 = 204;
                    break;
                }
                case 20: {
                    n4 = 174;
                    break;
                }
                case 21: {
                    n4 = 82;
                    break;
                }
                case 22: {
                    n4 = 12;
                    break;
                }
                case 23: {
                    n4 = 72;
                    break;
                }
                case 24: {
                    n4 = 248;
                    break;
                }
                case 25: {
                    n4 = 34;
                    break;
                }
                case 26: {
                    n4 = 210;
                    break;
                }
                case 27: {
                    n4 = 201;
                    break;
                }
                case 28: {
                    n4 = 196;
                    break;
                }
                case 29: {
                    n4 = 159;
                    break;
                }
                case 30: {
                    n4 = 55;
                    break;
                }
                case 31: {
                    n4 = 113;
                    break;
                }
                case 32: {
                    n4 = 124;
                    break;
                }
                case 33: {
                    n4 = 110;
                    break;
                }
                case 34: {
                    n4 = 58;
                    break;
                }
                case 35: {
                    n4 = 180;
                    break;
                }
                case 36: {
                    n4 = 47;
                    break;
                }
                case 37: {
                    n4 = 194;
                    break;
                }
                case 38: {
                    n4 = 6;
                    break;
                }
                case 39: {
                    n4 = 218;
                    break;
                }
                case 40: {
                    n4 = 246;
                    break;
                }
                case 41: {
                    n4 = 89;
                    break;
                }
                case 42: {
                    n4 = 35;
                    break;
                }
                case 43: {
                    n4 = 149;
                    break;
                }
                case 44: {
                    n4 = 136;
                    break;
                }
                case 45: {
                    n4 = 45;
                    break;
                }
                case 46: {
                    n4 = 250;
                    break;
                }
                case 47: {
                    n4 = 171;
                    break;
                }
                case 48: {
                    n4 = 27;
                    break;
                }
                case 49: {
                    n4 = 61;
                    break;
                }
                case 50: {
                    n4 = 51;
                    break;
                }
                case 51: {
                    n4 = 145;
                    break;
                }
                case 52: {
                    n4 = 190;
                    break;
                }
                case 53: {
                    n4 = 142;
                    break;
                }
                case 54: {
                    n4 = 192;
                    break;
                }
                case 55: {
                    n4 = 212;
                    break;
                }
                case 56: {
                    n4 = 152;
                    break;
                }
                case 57: {
                    n4 = 91;
                    break;
                }
                case 58: {
                    n4 = 161;
                    break;
                }
                case 59: {
                    n4 = 178;
                    break;
                }
                case 60: {
                    n4 = 67;
                    break;
                }
                case 61: {
                    n4 = 203;
                    break;
                }
                case 62: {
                    n4 = 92;
                    break;
                }
                case 63: {
                    n4 = 162;
                    break;
                }
                case 64: {
                    n4 = 13;
                    break;
                }
                case 65: {
                    n4 = 104;
                    break;
                }
                case 66: {
                    n4 = 207;
                    break;
                }
                case 67: {
                    n4 = 127;
                    break;
                }
                case 68: {
                    n4 = 84;
                    break;
                }
                case 69: {
                    n4 = 106;
                    break;
                }
                case 70: {
                    n4 = 217;
                    break;
                }
                case 71: {
                    n4 = 157;
                    break;
                }
                case 72: {
                    n4 = 80;
                    break;
                }
                case 73: {
                    n4 = 221;
                    break;
                }
                case 74: {
                    n4 = 0;
                    break;
                }
                case 75: {
                    n4 = 131;
                    break;
                }
                case 76: {
                    n4 = 52;
                    break;
                }
                case 77: {
                    n4 = 182;
                    break;
                }
                case 78: {
                    n4 = 121;
                    break;
                }
                case 79: {
                    n4 = 108;
                    break;
                }
                case 80: {
                    n4 = 249;
                    break;
                }
                case 81: {
                    n4 = 244;
                    break;
                }
                case 82: {
                    n4 = 135;
                    break;
                }
                case 83: {
                    n4 = 32;
                    break;
                }
                case 84: {
                    n4 = 214;
                    break;
                }
                case 85: {
                    n4 = 38;
                    break;
                }
                case 86: {
                    n4 = 179;
                    break;
                }
                case 87: {
                    n4 = 9;
                    break;
                }
                case 88: {
                    n4 = 10;
                    break;
                }
                case 89: {
                    n4 = 88;
                    break;
                }
                case 90: {
                    n4 = 183;
                    break;
                }
                case 91: {
                    n4 = 107;
                    break;
                }
                case 92: {
                    n4 = 241;
                    break;
                }
                case 93: {
                    n4 = 40;
                    break;
                }
                case 94: {
                    n4 = 132;
                    break;
                }
                case 95: {
                    n4 = 65;
                    break;
                }
                case 96: {
                    n4 = 87;
                    break;
                }
                case 97: {
                    n4 = 181;
                    break;
                }
                case 98: {
                    n4 = 133;
                    break;
                }
                case 99: {
                    n4 = 5;
                    break;
                }
                case 100: {
                    n4 = 138;
                    break;
                }
                case 101: {
                    n4 = 254;
                    break;
                }
                case 102: {
                    n4 = 29;
                    break;
                }
                case 103: {
                    n4 = 176;
                    break;
                }
                case 104: {
                    n4 = 64;
                    break;
                }
                case 105: {
                    n4 = 191;
                    break;
                }
                case 106: {
                    n4 = 242;
                    break;
                }
                case 107: {
                    n4 = 175;
                    break;
                }
                case 108: {
                    n4 = 198;
                    break;
                }
                case 109: {
                    n4 = 18;
                    break;
                }
                case 110: {
                    n4 = 30;
                    break;
                }
                case 111: {
                    n4 = 16;
                    break;
                }
                case 112: {
                    n4 = 140;
                    break;
                }
                case 113: {
                    n4 = 111;
                    break;
                }
                case 114: {
                    n4 = 31;
                    break;
                }
                case 115: {
                    n4 = 123;
                    break;
                }
                case 116: {
                    n4 = 120;
                    break;
                }
                case 117: {
                    n4 = 229;
                    break;
                }
                case 118: {
                    n4 = 90;
                    break;
                }
                case 119: {
                    n4 = 206;
                    break;
                }
                case 120: {
                    n4 = 153;
                    break;
                }
                case 121: {
                    n4 = 100;
                    break;
                }
                case 122: {
                    n4 = 98;
                    break;
                }
                case 123: {
                    n4 = 213;
                    break;
                }
                case 124: {
                    n4 = 24;
                    break;
                }
                case 125: {
                    n4 = 44;
                    break;
                }
                case 126: {
                    n4 = 79;
                    break;
                }
                case 127: {
                    n4 = 60;
                    break;
                }
                case 128: {
                    n4 = 163;
                    break;
                }
                case 129: {
                    n4 = 15;
                    break;
                }
                case 130: {
                    n4 = 39;
                    break;
                }
                case 131: {
                    n4 = 146;
                    break;
                }
                case 132: {
                    n4 = 226;
                    break;
                }
                case 133: {
                    n4 = 184;
                    break;
                }
                case 134: {
                    n4 = 7;
                    break;
                }
                case 135: {
                    n4 = 147;
                    break;
                }
                case 136: {
                    n4 = 122;
                    break;
                }
                case 137: {
                    n4 = 114;
                    break;
                }
                case 138: {
                    n4 = 144;
                    break;
                }
                case 139: {
                    n4 = 56;
                    break;
                }
                case 140: {
                    n4 = 232;
                    break;
                }
                case 141: {
                    n4 = 223;
                    break;
                }
                case 142: {
                    n4 = 237;
                    break;
                }
                case 143: {
                    n4 = 172;
                    break;
                }
                case 144: {
                    n4 = 139;
                    break;
                }
                case 145: {
                    n4 = 19;
                    break;
                }
                case 146: {
                    n4 = 205;
                    break;
                }
                case 147: {
                    n4 = 22;
                    break;
                }
                case 148: {
                    n4 = 81;
                    break;
                }
                case 149: {
                    n4 = 239;
                    break;
                }
                case 150: {
                    n4 = 186;
                    break;
                }
                case 151: {
                    n4 = 211;
                    break;
                }
                case 152: {
                    n4 = 167;
                    break;
                }
                case 153: {
                    n4 = 125;
                    break;
                }
                case 154: {
                    n4 = 231;
                    break;
                }
                case 155: {
                    n4 = 227;
                    break;
                }
                case 156: {
                    n4 = 75;
                    break;
                }
                case 157: {
                    n4 = 17;
                    break;
                }
                case 158: {
                    n4 = 99;
                    break;
                }
                case 159: {
                    n4 = 166;
                    break;
                }
                case 160: {
                    n4 = 219;
                    break;
                }
                case 161: {
                    n4 = 234;
                    break;
                }
                case 162: {
                    n4 = 220;
                    break;
                }
                case 163: {
                    n4 = 134;
                    break;
                }
                case 164: {
                    n4 = 164;
                    break;
                }
                case 165: {
                    n4 = 57;
                    break;
                }
                case 166: {
                    n4 = 169;
                    break;
                }
                case 167: {
                    n4 = 251;
                    break;
                }
                case 168: {
                    n4 = 245;
                    break;
                }
                case 169: {
                    n4 = 154;
                    break;
                }
                case 170: {
                    n4 = 4;
                    break;
                }
                case 171: {
                    n4 = 63;
                    break;
                }
                case 172: {
                    n4 = 21;
                    break;
                }
                case 173: {
                    n4 = 115;
                    break;
                }
                case 174: {
                    n4 = 197;
                    break;
                }
                case 175: {
                    n4 = 102;
                    break;
                }
                case 176: {
                    n4 = 156;
                    break;
                }
                case 177: {
                    n4 = 236;
                    break;
                }
                case 178: {
                    n4 = 235;
                    break;
                }
                case 179: {
                    n4 = 11;
                    break;
                }
                case 180: {
                    n4 = 94;
                    break;
                }
                case 181: {
                    n4 = 209;
                    break;
                }
                case 182: {
                    n4 = 193;
                    break;
                }
                case 183: {
                    n4 = 189;
                    break;
                }
                case 184: {
                    n4 = 224;
                    break;
                }
                case 185: {
                    n4 = 137;
                    break;
                }
                case 186: {
                    n4 = 105;
                    break;
                }
                case 187: {
                    n4 = 187;
                    break;
                }
                case 188: {
                    n4 = 28;
                    break;
                }
                case 189: {
                    n4 = 85;
                    break;
                }
                case 190: {
                    n4 = 76;
                    break;
                }
                case 191: {
                    n4 = 96;
                    break;
                }
                case 192: {
                    n4 = 86;
                    break;
                }
                case 193: {
                    n4 = 150;
                    break;
                }
                case 194: {
                    n4 = 158;
                    break;
                }
                case 195: {
                    n4 = 185;
                    break;
                }
                case 196: {
                    n4 = 70;
                    break;
                }
                case 197: {
                    n4 = 69;
                    break;
                }
                case 198: {
                    n4 = 59;
                    break;
                }
                case 199: {
                    n4 = 225;
                    break;
                }
                case 200: {
                    n4 = 3;
                    break;
                }
                case 201: {
                    n4 = 33;
                    break;
                }
                case 202: {
                    n4 = 141;
                    break;
                }
                case 203: {
                    n4 = 151;
                    break;
                }
                case 204: {
                    n4 = 199;
                    break;
                }
                case 205: {
                    n4 = 243;
                    break;
                }
                case 206: {
                    n4 = 101;
                    break;
                }
                case 207: {
                    n4 = 128;
                    break;
                }
                case 208: {
                    n4 = 36;
                    break;
                }
                case 209: {
                    n4 = 255;
                    break;
                }
                case 210: {
                    n4 = 48;
                    break;
                }
                case 211: {
                    n4 = 23;
                    break;
                }
                case 212: {
                    n4 = 173;
                    break;
                }
                case 213: {
                    n4 = 77;
                    break;
                }
                case 214: {
                    n4 = 112;
                    break;
                }
                case 215: {
                    n4 = 50;
                    break;
                }
                case 216: {
                    n4 = 46;
                    break;
                }
                case 217: {
                    n4 = 53;
                    break;
                }
                case 218: {
                    n4 = 148;
                    break;
                }
                case 219: {
                    n4 = 119;
                    break;
                }
                case 220: {
                    n4 = 43;
                    break;
                }
                case 221: {
                    n4 = 116;
                    break;
                }
                case 222: {
                    n4 = 62;
                    break;
                }
                case 223: {
                    n4 = 93;
                    break;
                }
                case 224: {
                    n4 = 118;
                    break;
                }
                case 225: {
                    n4 = 252;
                    break;
                }
                case 226: {
                    n4 = 130;
                    break;
                }
                case 227: {
                    n4 = 202;
                    break;
                }
                case 228: {
                    n4 = 129;
                    break;
                }
                case 229: {
                    n4 = 165;
                    break;
                }
                case 230: {
                    n4 = 240;
                    break;
                }
                case 231: {
                    n4 = 216;
                    break;
                }
                case 232: {
                    n4 = 14;
                    break;
                }
                case 233: {
                    n4 = 95;
                    break;
                }
                case 234: {
                    n4 = 208;
                    break;
                }
                case 235: {
                    n4 = 195;
                    break;
                }
                case 236: {
                    n4 = 168;
                    break;
                }
                case 237: {
                    n4 = 66;
                    break;
                }
                case 238: {
                    n4 = 143;
                    break;
                }
                case 239: {
                    n4 = 126;
                    break;
                }
                case 240: {
                    n4 = 68;
                    break;
                }
                case 241: {
                    n4 = 37;
                    break;
                }
                case 242: {
                    n4 = 238;
                    break;
                }
                case 243: {
                    n4 = 155;
                    break;
                }
                case 244: {
                    n4 = 20;
                    break;
                }
                case 245: {
                    n4 = 200;
                    break;
                }
                case 246: {
                    n4 = 177;
                    break;
                }
                case 247: {
                    n4 = 170;
                    break;
                }
                case 248: {
                    n4 = 1;
                    break;
                }
                case 249: {
                    n4 = 78;
                    break;
                }
                case 250: {
                    n4 = 230;
                    break;
                }
                case 251: {
                    n4 = 71;
                    break;
                }
                case 252: {
                    n4 = 73;
                    break;
                }
                case 253: {
                    n4 = 41;
                    break;
                }
                case 254: {
                    n4 = 97;
                    break;
                }
                default: {
                    n4 = 160;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            ReaderInputStream.b[n3] = q.z(new String(g));
        }
        return ReaderInputStream.b[n3];
    }
}
