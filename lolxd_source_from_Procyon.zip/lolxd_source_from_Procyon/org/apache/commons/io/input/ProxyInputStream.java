// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.input;

import q.o.m.s.q;
import java.io.IOException;
import java.io.InputStream;
import java.io.FilterInputStream;

public abstract class ProxyInputStream extends FilterInputStream
{
    private static String b;
    
    public ProxyInputStream(final InputStream in) {
        super(in);
    }
    
    @Override
    public int read() throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: aload_0        
        //     5: iconst_1       
        //     6: invokevirtual   org/apache/commons/io/input/ProxyInputStream.beforeRead:(I)V
        //     9: aload_0        
        //    10: getfield        org/apache/commons/io/input/ProxyInputStream.in:Ljava/io/InputStream;
        //    13: invokestatic    q/o/m/s/q.kt:(Ljava/io/InputStream;)I
        //    16: istore_2       
        //    17: aload_0        
        //    18: iload_2        
        //    19: aload_1        
        //    20: ifnonnull       53
        //    23: aload_1        
        //    24: ifnonnull       53
        //    27: goto            34
        //    30: invokestatic    org/apache/commons/io/input/ProxyInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    33: athrow         
        //    34: iconst_m1      
        //    35: if_icmpeq       56
        //    38: goto            45
        //    41: invokestatic    org/apache/commons/io/input/ProxyInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    44: athrow         
        //    45: iconst_1       
        //    46: goto            53
        //    49: invokestatic    org/apache/commons/io/input/ProxyInputStream.b:(Ljava/io/IOException;)Ljava/io/IOException;
        //    52: athrow         
        //    53: goto            57
        //    56: iconst_m1      
        //    57: invokevirtual   org/apache/commons/io/input/ProxyInputStream.afterRead:(I)V
        //    60: iload_2        
        //    61: ireturn        
        //    62: astore_2       
        //    63: aload_0        
        //    64: aload_2        
        //    65: invokevirtual   org/apache/commons/io/input/ProxyInputStream.handleIOException:(Ljava/io/IOException;)V
        //    68: iconst_m1      
        //    69: ireturn        
        //    Exceptions:
        //  throws java.io.IOException
        //    StackMapTable: 00 09 FF 00 1E 00 03 07 00 02 07 00 22 01 00 01 07 00 0F FF 00 03 00 03 07 00 02 07 00 22 01 00 02 07 00 02 01 46 07 00 0F 43 07 00 02 43 07 00 0F FF 00 03 00 03 07 00 02 07 00 22 01 00 02 07 00 02 01 42 07 00 02 FF 00 00 00 03 07 00 02 07 00 22 01 00 02 07 00 02 01 FF 00 04 00 01 07 00 02 00 01 07 00 0F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  34     46     49     53     Ljava/io/IOException;
        //  23     38     41     45     Ljava/io/IOException;
        //  17     27     30     34     Ljava/io/IOException;
        //  4      61     62     70     Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0034:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public int read(final byte[] array) throws IOException {
        final String b = b();
        try {
            int length = 0;
            Label_0037: {
                Label_0036: {
                    byte[] array2 = null;
                    Label_0032: {
                        Label_0021: {
                            try {
                                array2 = array;
                                if (b != null) {
                                    break Label_0032;
                                }
                                final String s = b;
                                if (s == null) {
                                    break Label_0021;
                                }
                                break Label_0032;
                            }
                            catch (IOException ex) {
                                throw b(ex);
                            }
                            try {
                                final String s = b;
                                if (s != null) {
                                    break Label_0032;
                                }
                                if (array == null) {
                                    break Label_0036;
                                }
                            }
                            catch (IOException ex2) {
                                throw b(ex2);
                            }
                        }
                        array2 = array;
                    }
                    length = array2.length;
                    break Label_0037;
                }
                length = 0;
            }
            this.beforeRead(length);
            final int sg = q.sg(this.in, array);
            this.afterRead(sg);
            return sg;
        }
        catch (IOException ex3) {
            this.handleIOException(ex3);
            return -1;
        }
    }
    
    @Override
    public int read(final byte[] array, final int n, final int n2) throws IOException {
        try {
            this.beforeRead(n2);
            final int yn = q.yn(this.in, array, n, n2);
            this.afterRead(yn);
            return yn;
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            return -1;
        }
    }
    
    @Override
    public long skip(final long n) throws IOException {
        try {
            return q.xo(this.in, n);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            return 0L;
        }
    }
    
    @Override
    public int available() throws IOException {
        try {
            return super.available();
        }
        catch (IOException ex) {
            this.handleIOException(ex);
            return 0;
        }
    }
    
    @Override
    public void close() throws IOException {
        try {
            q.yp(this.in);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
    }
    
    @Override
    public synchronized void mark(final int n) {
        q.xm(this.in, n);
    }
    
    @Override
    public synchronized void reset() throws IOException {
        try {
            q.xv(this.in);
        }
        catch (IOException ex) {
            this.handleIOException(ex);
        }
    }
    
    @Override
    public boolean markSupported() {
        return q.xt(this.in);
    }
    
    protected void beforeRead(final int n) throws IOException {
    }
    
    protected void afterRead(final int n) throws IOException {
    }
    
    protected void handleIOException(final IOException ex) throws IOException {
        throw ex;
    }
    
    public static void b(final String b) {
        ProxyInputStream.b = b;
    }
    
    public static String b() {
        return ProxyInputStream.b;
    }
    
    private static IOException b(final IOException ex) {
        return ex;
    }
    
    static {
        if (b() != null) {
            b(n.d.a.d.q.qc());
        }
    }
}
