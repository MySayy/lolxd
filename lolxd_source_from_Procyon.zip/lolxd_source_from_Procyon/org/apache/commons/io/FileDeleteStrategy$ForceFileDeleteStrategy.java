// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io;

import n.d.a.d.q;
import java.io.IOException;
import java.io.File;

class FileDeleteStrategy$ForceFileDeleteStrategy extends FileDeleteStrategy
{
    private static final String c;
    
    FileDeleteStrategy$ForceFileDeleteStrategy() {
        super(FileDeleteStrategy$ForceFileDeleteStrategy.c);
    }
    
    @Override
    protected boolean doDelete(final File file) throws IOException {
        FileUtils.forceDelete(file);
        return true;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 51);
        final char[] g = q.o.m.s.q.g(q.vo());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c2 = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 85;
                            break;
                        }
                        case 1: {
                            n5 = 47;
                            break;
                        }
                        case 2: {
                            n5 = 90;
                            break;
                        }
                        case 3: {
                            n5 = 76;
                            break;
                        }
                        case 4: {
                            n5 = 118;
                            break;
                        }
                        case 5: {
                            n5 = 114;
                            break;
                        }
                        default: {
                            n5 = 58;
                            break;
                        }
                    }
                    g[n3] = (char)(c2 ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                c = q.o.m.s.q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
