// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.comparator;

import java.util.List;
import org.apache.commons.io.FilenameUtils;
import q.o.m.s.q;
import org.apache.commons.io.IOCase;
import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

public class ExtensionFileComparator extends AbstractFileComparator implements Serializable
{
    private static final long serialVersionUID = 1928235200184222815L;
    public static final Comparator<File> EXTENSION_COMPARATOR;
    public static final Comparator<File> EXTENSION_REVERSE;
    public static final Comparator<File> EXTENSION_INSENSITIVE_COMPARATOR;
    public static final Comparator<File> EXTENSION_INSENSITIVE_REVERSE;
    public static final Comparator<File> EXTENSION_SYSTEM_COMPARATOR;
    public static final Comparator<File> EXTENSION_SYSTEM_REVERSE;
    private final IOCase caseSensitivity;
    private static final String a;
    
    public ExtensionFileComparator() {
        this.caseSensitivity = IOCase.SENSITIVE;
    }
    
    public ExtensionFileComparator(final IOCase ioCase) {
        this.caseSensitivity = ((ioCase == null) ? IOCase.SENSITIVE : ioCase);
    }
    
    @Override
    public int compare(final File file, final File file2) {
        return this.caseSensitivity.checkCompareTo(FilenameUtils.getExtension(q.mh(file)), FilenameUtils.getExtension(q.mh(file2)));
    }
    
    @Override
    public String toString() {
        return q.s(q.r(q.kx(q.r(q.r(new StringBuilder(), super.toString()), ExtensionFileComparator.a), this.caseSensitivity), n.d.a.d.q.vq()));
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 88);
        final char[] g = q.g(n.d.a.d.q.ov());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 70;
                            break;
                        }
                        case 1: {
                            n5 = 90;
                            break;
                        }
                        case 2: {
                            n5 = 18;
                            break;
                        }
                        case 3: {
                            n5 = 25;
                            break;
                        }
                        case 4: {
                            n5 = 45;
                            break;
                        }
                        case 5: {
                            n5 = 127;
                            break;
                        }
                        default: {
                            n5 = 86;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.z(new String(g));
                EXTENSION_COMPARATOR = new ExtensionFileComparator();
                EXTENSION_REVERSE = new ReverseComparator(ExtensionFileComparator.EXTENSION_COMPARATOR);
                EXTENSION_INSENSITIVE_COMPARATOR = new ExtensionFileComparator(IOCase.INSENSITIVE);
                EXTENSION_INSENSITIVE_REVERSE = new ReverseComparator(ExtensionFileComparator.EXTENSION_INSENSITIVE_COMPARATOR);
                EXTENSION_SYSTEM_COMPARATOR = new ExtensionFileComparator(IOCase.SYSTEM);
                EXTENSION_SYSTEM_REVERSE = new ReverseComparator(ExtensionFileComparator.EXTENSION_SYSTEM_COMPARATOR);
                return;
            }
            continue;
        }
    }
}
