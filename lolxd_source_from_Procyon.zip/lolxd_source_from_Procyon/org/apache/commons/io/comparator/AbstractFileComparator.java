// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.comparator;

import java.util.List;
import q.o.m.s.q;
import java.io.File;
import java.util.Comparator;

abstract class AbstractFileComparator implements Comparator<File>
{
    public File[] sort(final File... array) {
        final int[] b = NameFileComparator.b();
        File[] array2;
        while (true) {
            Label_0024: {
                try {
                    array2 = array;
                    if (b != null) {
                        return array2;
                    }
                    if (array == null) {
                        break Label_0024;
                    }
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                final File[] array3 = array;
                q.cr(array3, this);
            }
            array2 = array;
            final File[] array3 = array;
            if (b != null) {
                continue;
            }
            break;
        }
        return array2;
    }
    
    public List<File> sort(final List<File> list) {
        final int[] b = NameFileComparator.b();
        List<File> list2;
        while (true) {
            Label_0024: {
                try {
                    list2 = list;
                    if (b != null) {
                        return list2;
                    }
                    if (list == null) {
                        break Label_0024;
                    }
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                final List<File> list3 = list;
                q.cs(list3, this);
            }
            list2 = list;
            final List<File> list3 = list;
            if (b != null) {
                continue;
            }
            break;
        }
        return list2;
    }
    
    @Override
    public String toString() {
        return q.ss(q.qi(this));
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
