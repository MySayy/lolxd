// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.comparator;

import java.util.List;
import q.o.m.s.q;
import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

public class SizeFileComparator extends AbstractFileComparator implements Serializable
{
    private static final long serialVersionUID = -1201561106411416190L;
    public static final Comparator<File> SIZE_COMPARATOR;
    public static final Comparator<File> SIZE_REVERSE;
    public static final Comparator<File> SIZE_SUMDIR_COMPARATOR;
    public static final Comparator<File> SIZE_SUMDIR_REVERSE;
    private final boolean sumDirectoryContents;
    private static final String a;
    
    public SizeFileComparator() {
        this.sumDirectoryContents = false;
    }
    
    public SizeFileComparator(final boolean sumDirectoryContents) {
        this.sumDirectoryContents = sumDirectoryContents;
    }
    
    @Override
    public int compare(final File p0, final File p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: lstore          5
        //     3: invokestatic    org/apache/commons/io/comparator/NameFileComparator.b:()[I
        //     6: astore_3       
        //     7: aload_1        
        //     8: aload_3        
        //     9: ifnonnull       136
        //    12: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //    15: aload_3        
        //    16: ifnonnull       47
        //    19: goto            26
        //    22: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    25: athrow         
        //    26: ifeq            135
        //    29: goto            36
        //    32: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    35: athrow         
        //    36: aload_0        
        //    37: getfield        org/apache/commons/io/comparator/SizeFileComparator.sumDirectoryContents:Z
        //    40: goto            47
        //    43: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    46: athrow         
        //    47: aload_3        
        //    48: ifnonnull       105
        //    51: aload_3        
        //    52: ifnonnull       105
        //    55: goto            62
        //    58: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    61: athrow         
        //    62: ifeq            115
        //    65: goto            72
        //    68: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    71: athrow         
        //    72: aload_1        
        //    73: aload_3        
        //    74: ifnonnull       109
        //    77: goto            84
        //    80: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    83: athrow         
        //    84: aload_3        
        //    85: ifnonnull       109
        //    88: goto            95
        //    91: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    94: athrow         
        //    95: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //    98: goto            105
        //   101: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   104: athrow         
        //   105: ifeq            115
        //   108: aload_1        
        //   109: invokestatic    org/apache/commons/io/FileUtils.sizeOfDirectory:(Ljava/io/File;)J
        //   112: goto            116
        //   115: lconst_0       
        //   116: lstore          5
        //   118: aload_3        
        //   119: ifnull          141
        //   122: invokestatic    com/sun/jna/Structure.b:()I
        //   125: istore          4
        //   127: iinc            4, 1
        //   130: iload           4
        //   132: invokestatic    com/sun/jna/Structure.b:(I)V
        //   135: aload_1        
        //   136: invokestatic    q/o/m/s/q.eb:(Ljava/io/File;)J
        //   139: lstore          5
        //   141: lconst_0       
        //   142: lstore          7
        //   144: aload_2        
        //   145: aload_3        
        //   146: ifnonnull       267
        //   149: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //   152: aload_3        
        //   153: ifnonnull       184
        //   156: goto            163
        //   159: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   162: athrow         
        //   163: ifeq            259
        //   166: goto            173
        //   169: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   172: athrow         
        //   173: aload_0        
        //   174: getfield        org/apache/commons/io/comparator/SizeFileComparator.sumDirectoryContents:Z
        //   177: goto            184
        //   180: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   183: athrow         
        //   184: aload_3        
        //   185: ifnonnull       242
        //   188: aload_3        
        //   189: ifnonnull       242
        //   192: goto            199
        //   195: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   198: athrow         
        //   199: ifeq            252
        //   202: goto            209
        //   205: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   208: athrow         
        //   209: aload_2        
        //   210: aload_3        
        //   211: ifnonnull       246
        //   214: goto            221
        //   217: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   220: athrow         
        //   221: aload_3        
        //   222: ifnonnull       246
        //   225: goto            232
        //   228: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   231: athrow         
        //   232: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //   235: goto            242
        //   238: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   241: athrow         
        //   242: ifeq            252
        //   245: aload_2        
        //   246: invokestatic    org/apache/commons/io/FileUtils.sizeOfDirectory:(Ljava/io/File;)J
        //   249: goto            253
        //   252: lconst_0       
        //   253: lstore          7
        //   255: aload_3        
        //   256: ifnull          272
        //   259: aload_2        
        //   260: goto            267
        //   263: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   266: athrow         
        //   267: invokestatic    q/o/m/s/q.eb:(Ljava/io/File;)J
        //   270: lstore          7
        //   272: lload           5
        //   274: lload           7
        //   276: lsub           
        //   277: lstore          9
        //   279: lload           9
        //   281: lconst_0       
        //   282: lcmp           
        //   283: aload_3        
        //   284: ifnonnull       307
        //   287: ifge            299
        //   290: goto            297
        //   293: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   296: athrow         
        //   297: iconst_m1      
        //   298: ireturn        
        //   299: lload           9
        //   301: lconst_0       
        //   302: lcmp           
        //   303: aload_3        
        //   304: ifnonnull       298
        //   307: aload_3        
        //   308: ifnonnull       328
        //   311: ifle            323
        //   314: goto            321
        //   317: invokestatic    org/apache/commons/io/comparator/SizeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   320: athrow         
        //   321: iconst_1       
        //   322: ireturn        
        //   323: iconst_0       
        //   324: aload_3        
        //   325: ifnonnull       322
        //   328: ireturn        
        //    StackMapTable: 00 37 FF 00 16 00 06 07 00 02 07 00 2E 07 00 2E 07 00 30 00 04 00 01 07 00 20 43 01 45 07 00 20 03 46 07 00 20 43 01 4A 07 00 20 43 01 45 07 00 20 03 47 07 00 20 43 07 00 2E 46 07 00 20 43 07 00 2E 45 07 00 20 43 01 43 07 00 2E 05 40 04 12 40 07 00 2E 04 FF 00 11 00 07 07 00 02 07 00 2E 07 00 2E 07 00 30 00 04 04 00 01 07 00 20 43 01 45 07 00 20 03 46 07 00 20 43 01 4A 07 00 20 43 01 45 07 00 20 03 47 07 00 20 43 07 00 2E 46 07 00 20 43 07 00 2E 45 07 00 20 43 01 43 07 00 2E 05 40 04 05 43 07 00 20 43 07 00 2E 04 FF 00 14 00 08 07 00 02 07 00 2E 07 00 2E 07 00 30 00 04 04 04 00 01 07 00 20 03 40 01 00 47 01 49 07 00 20 03 40 01 00 44 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  7      19     22     26     Ljava/lang/RuntimeException;
        //  12     29     32     36     Ljava/lang/RuntimeException;
        //  26     40     43     47     Ljava/lang/RuntimeException;
        //  47     55     58     62     Ljava/lang/RuntimeException;
        //  51     65     68     72     Ljava/lang/RuntimeException;
        //  62     77     80     84     Ljava/lang/RuntimeException;
        //  72     88     91     95     Ljava/lang/RuntimeException;
        //  84     98     101    105    Ljava/lang/RuntimeException;
        //  144    156    159    163    Ljava/lang/RuntimeException;
        //  149    166    169    173    Ljava/lang/RuntimeException;
        //  163    177    180    184    Ljava/lang/RuntimeException;
        //  184    192    195    199    Ljava/lang/RuntimeException;
        //  188    202    205    209    Ljava/lang/RuntimeException;
        //  199    214    217    221    Ljava/lang/RuntimeException;
        //  209    225    228    232    Ljava/lang/RuntimeException;
        //  221    235    238    242    Ljava/lang/RuntimeException;
        //  255    260    263    267    Ljava/lang/RuntimeException;
        //  279    290    293    297    Ljava/lang/RuntimeException;
        //  307    314    317    321    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0026:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public String toString() {
        return q.s(q.r(q.pk(q.r(q.r(new StringBuilder(), super.toString()), SizeFileComparator.a), this.sumDirectoryContents), n.d.a.d.q.vq()));
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 73);
        final char[] g = q.g(n.d.a.d.q.os());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 70;
                            break;
                        }
                        case 1: {
                            n5 = 89;
                            break;
                        }
                        case 2: {
                            n5 = 105;
                            break;
                        }
                        case 3: {
                            n5 = 68;
                            break;
                        }
                        case 4: {
                            n5 = 118;
                            break;
                        }
                        case 5: {
                            n5 = 61;
                            break;
                        }
                        default: {
                            n5 = 89;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.z(new String(g));
                SIZE_COMPARATOR = new SizeFileComparator();
                SIZE_REVERSE = new ReverseComparator(SizeFileComparator.SIZE_COMPARATOR);
                SIZE_SUMDIR_COMPARATOR = new SizeFileComparator(true);
                SIZE_SUMDIR_REVERSE = new ReverseComparator(SizeFileComparator.SIZE_SUMDIR_COMPARATOR);
                return;
            }
            continue;
        }
    }
    
    private static RuntimeException c(final RuntimeException ex) {
        return ex;
    }
}
