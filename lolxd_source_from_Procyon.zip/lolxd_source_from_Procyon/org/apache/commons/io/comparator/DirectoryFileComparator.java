// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.comparator;

import java.util.List;
import q.o.m.s.q;
import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

public class DirectoryFileComparator extends AbstractFileComparator implements Serializable
{
    private static final long serialVersionUID = 296132640160964395L;
    public static final Comparator<File> DIRECTORY_COMPARATOR;
    public static final Comparator<File> DIRECTORY_REVERSE;
    
    @Override
    public int compare(final File file, final File file2) {
        return this.getType(file) - this.getType(file2);
    }
    
    private int getType(final File file) {
        final int[] b = NameFileComparator.b();
        Label_0024: {
            try {
                final int su;
                final boolean b2 = (su = (q.su(file) ? 1 : 0)) != 0;
                if (b != null) {
                    return su;
                }
                if (!b2) {
                    break Label_0024;
                }
            }
            catch (RuntimeException ex) {
                throw c(ex);
            }
            return 1;
        }
        int n;
        int su = n = 2;
        if (b != null) {
            return n;
        }
        return su;
    }
    
    static {
        DIRECTORY_COMPARATOR = new DirectoryFileComparator();
        DIRECTORY_REVERSE = new ReverseComparator(DirectoryFileComparator.DIRECTORY_COMPARATOR);
    }
    
    private static RuntimeException c(final RuntimeException ex) {
        return ex;
    }
}
