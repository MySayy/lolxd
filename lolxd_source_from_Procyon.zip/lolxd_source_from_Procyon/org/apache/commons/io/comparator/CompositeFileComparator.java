// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.comparator;

import com.sun.jna.Structure;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import q.o.m.s.q;
import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

public class CompositeFileComparator extends AbstractFileComparator implements Serializable
{
    private static final long serialVersionUID = -2224170307287243428L;
    private static final Comparator<?>[] NO_COMPARATORS;
    private final Comparator<File>[] delegates;
    
    public CompositeFileComparator(final Comparator<File>... array) {
        final int[] b = NameFileComparator.b();
        final int[] array2 = b;
        Comparator<File>[] array3 = null;
        Label_0061: {
            while (true) {
                Label_0044: {
                    Label_0023: {
                        try {
                            array3 = array;
                            if (array2 != null) {
                                break Label_0061;
                            }
                            if (array == null) {
                                break Label_0023;
                            }
                            break Label_0044;
                        }
                        catch (RuntimeException ex) {
                            throw c(ex);
                        }
                        try {
                            if (array != null) {
                                break Label_0044;
                            }
                            this.delegates = (Comparator<File>[])CompositeFileComparator.NO_COMPARATORS;
                        }
                        catch (RuntimeException ex2) {
                            throw c(ex2);
                        }
                    }
                    if (array2 == null) {
                        return;
                    }
                }
                this.delegates = (Comparator<File>[])new Comparator[array.length];
                if (array2 != null) {
                    continue;
                }
                break;
            }
            array3 = array;
        }
        q.st(array3, 0, this.delegates, 0, array.length);
    }
    
    public CompositeFileComparator(final Iterable<Comparator<File>> iterable) {
        final int[] b = NameFileComparator.b();
        final int[] array = b;
        ArrayList list;
        while (true) {
            Label_0044: {
                Label_0023: {
                    try {
                        if (array != null) {
                            break Label_0040;
                        }
                        final Iterable<Comparator<File>> iterable2 = iterable;
                        if (iterable2 == null) {
                            break Label_0023;
                        }
                        break Label_0044;
                    }
                    catch (RuntimeException ex) {
                        throw c(ex);
                    }
                    try {
                        final Iterable<Comparator<File>> iterable2 = iterable;
                        if (iterable2 != null) {
                            break Label_0044;
                        }
                        this.delegates = (Comparator<File>[])CompositeFileComparator.NO_COMPARATORS;
                    }
                    catch (RuntimeException ex2) {
                        throw c(ex2);
                    }
                }
                if (array == null) {
                    return;
                }
            }
            list = new ArrayList();
            if (array != null) {
                continue;
            }
            break;
        }
        final Iterator ck = q.ck(iterable);
        while (q.oi(ck)) {
            final Comparator comparator = (Comparator)q.ou(ck);
            try {
                q.qw(list, comparator);
                if (array != null) {
                    return;
                }
                if (array == null) {
                    continue;
                }
            }
            catch (RuntimeException ex3) {
                throw c(ex3);
            }
            break;
        }
        this.delegates = (Comparator<File>[])q.ce(list, new Comparator[q.kg(list)]);
    }
    
    @Override
    public int compare(final File p0, final File p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: istore          4
        //     3: invokestatic    org/apache/commons/io/comparator/NameFileComparator.b:()[I
        //     6: aload_0        
        //     7: getfield        org/apache/commons/io/comparator/CompositeFileComparator.delegates:[Ljava/util/Comparator;
        //    10: astore          5
        //    12: aload           5
        //    14: arraylength    
        //    15: istore          6
        //    17: astore_3       
        //    18: iconst_0       
        //    19: istore          7
        //    21: iload           7
        //    23: iload           6
        //    25: if_icmpge       96
        //    28: aload           5
        //    30: iload           7
        //    32: aaload         
        //    33: astore          8
        //    35: aload           8
        //    37: aload_1        
        //    38: aload_2        
        //    39: invokestatic    q/o/m/s/q.cn:(Ljava/util/Comparator;Ljava/lang/Object;Ljava/lang/Object;)I
        //    42: istore          4
        //    44: aload_3        
        //    45: ifnonnull       92
        //    48: iload           4
        //    50: aload_3        
        //    51: ifnonnull       98
        //    54: goto            61
        //    57: invokestatic    org/apache/commons/io/comparator/CompositeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    60: athrow         
        //    61: ifeq            82
        //    64: goto            71
        //    67: invokestatic    org/apache/commons/io/comparator/CompositeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    70: athrow         
        //    71: aload_3        
        //    72: ifnull          96
        //    75: goto            82
        //    78: invokestatic    org/apache/commons/io/comparator/CompositeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    81: athrow         
        //    82: iinc            7, 1
        //    85: goto            92
        //    88: invokestatic    org/apache/commons/io/comparator/CompositeFileComparator.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    91: athrow         
        //    92: aload_3        
        //    93: ifnull          21
        //    96: iload           4
        //    98: ireturn        
        //    StackMapTable: 00 0B FF 00 15 00 08 07 00 02 07 00 56 07 00 56 07 00 21 01 07 00 1F 01 01 00 00 FF 00 23 00 09 07 00 02 07 00 56 07 00 56 07 00 21 01 07 00 1F 01 01 07 00 2B 00 01 07 00 15 43 01 45 07 00 15 03 46 07 00 15 03 45 07 00 15 03 FA 00 03 41 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  44     54     57     61     Ljava/lang/RuntimeException;
        //  48     64     67     71     Ljava/lang/RuntimeException;
        //  61     75     78     82     Ljava/lang/RuntimeException;
        //  71     85     88     92     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0061:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public String toString() {
        final int[] b = NameFileComparator.b();
        final StringBuilder sb = new StringBuilder();
        final int[] array = b;
        q.r(sb, super.toString());
        q.sk(sb, '{');
        int i = 0;
        while (true) {
        Label_0067_Outer:
            while (i < this.delegates.length) {
                String s = null;
                Label_0097: {
                    while (true) {
                        Label_0054: {
                            try {
                                if (array != null) {
                                    break Label_0097;
                                }
                                final int n = i;
                                if (n > 0) {
                                    break Label_0054;
                                }
                                break Label_0067;
                            }
                            catch (RuntimeException ex) {
                                throw c(ex);
                            }
                            try {
                                final int n = i;
                                if (n > 0) {
                                    q.sk(sb, ',');
                                }
                            }
                            catch (RuntimeException ex2) {
                                throw c(ex2);
                            }
                        }
                        q.kx(sb, this.delegates[i]);
                        if (array != null) {
                            continue;
                        }
                        break;
                    }
                    ++i;
                    if (array != null) {
                        break;
                    }
                    continue Label_0067_Outer;
                    try {
                        s = q.s(sb);
                        if (Structure.a() == 0) {
                            NameFileComparator.b(new int[4]);
                        }
                    }
                    catch (RuntimeException ex3) {
                        throw c(ex3);
                    }
                }
                return s;
            }
            q.sk(sb, '}');
            continue;
        }
    }
    
    static {
        NO_COMPARATORS = new Comparator[0];
    }
    
    private static RuntimeException c(final RuntimeException ex) {
        return ex;
    }
}
