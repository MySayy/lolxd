// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.comparator;

import java.util.List;
import q.o.m.s.q;
import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

public class LastModifiedFileComparator extends AbstractFileComparator implements Serializable
{
    private static final long serialVersionUID = 7372168004395734046L;
    public static final Comparator<File> LASTMODIFIED_COMPARATOR;
    public static final Comparator<File> LASTMODIFIED_REVERSE;
    
    @Override
    public int compare(final File file, final File file2) {
        final int[] b = NameFileComparator.b();
        final long n = q.nj(file) - q.nj(file2);
        final int[] array = b;
        Label_0059: {
            Label_0043: {
                long n2 = 0L;
                Label_0035: {
                    try {
                        final long n3;
                        n2 = (n3 = lcmp(n, 0L));
                        if (array != null) {
                            break Label_0043;
                        }
                        if (n2 >= 0) {
                            break Label_0035;
                        }
                    }
                    catch (RuntimeException ex) {
                        throw c(ex);
                    }
                    final long n4 = -1;
                    return (int)n4;
                }
                long n3;
                final long n4 = n3 = lcmp(n, 0L);
                if (array != null) {
                    return (int)n4;
                }
                try {
                    if (array != null) {
                        return (int)n3;
                    }
                    if (n2 <= 0) {
                        break Label_0059;
                    }
                }
                catch (RuntimeException ex2) {
                    throw c(ex2);
                }
            }
            final boolean b2 = true;
            return b2 ? 1 : 0;
        }
        boolean b2;
        long n3 = (b2 = false) ? 1 : 0;
        if (array != null) {
            return b2 ? 1 : 0;
        }
        return (int)n3;
    }
    
    static {
        LASTMODIFIED_COMPARATOR = new LastModifiedFileComparator();
        LASTMODIFIED_REVERSE = new ReverseComparator(LastModifiedFileComparator.LASTMODIFIED_COMPARATOR);
    }
    
    private static RuntimeException c(final RuntimeException ex) {
        return ex;
    }
}
