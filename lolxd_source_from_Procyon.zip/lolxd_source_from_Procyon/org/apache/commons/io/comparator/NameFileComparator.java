// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.comparator;

import java.util.List;
import q.o.m.s.q;
import org.apache.commons.io.IOCase;
import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

public class NameFileComparator extends AbstractFileComparator implements Serializable
{
    private static final long serialVersionUID = 8397947749814525798L;
    public static final Comparator<File> NAME_COMPARATOR;
    public static final Comparator<File> NAME_REVERSE;
    public static final Comparator<File> NAME_INSENSITIVE_COMPARATOR;
    public static final Comparator<File> NAME_INSENSITIVE_REVERSE;
    public static final Comparator<File> NAME_SYSTEM_COMPARATOR;
    public static final Comparator<File> NAME_SYSTEM_REVERSE;
    private final IOCase caseSensitivity;
    private static int[] b;
    private static final String a;
    
    public NameFileComparator() {
        this.caseSensitivity = IOCase.SENSITIVE;
    }
    
    public NameFileComparator(final IOCase ioCase) {
        this.caseSensitivity = ((ioCase == null) ? IOCase.SENSITIVE : ioCase);
    }
    
    @Override
    public int compare(final File file, final File file2) {
        return this.caseSensitivity.checkCompareTo(q.mh(file), q.mh(file2));
    }
    
    @Override
    public String toString() {
        return q.s(q.r(q.kx(q.r(q.r(new StringBuilder(), super.toString()), NameFileComparator.a), this.caseSensitivity), n.d.a.d.q.vq()));
    }
    
    static {
        b((int[])null);
        int n3;
        int n2;
        final int n = n2 = (n3 = 51);
        final char[] g = q.g(n.d.a.d.q.oo());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0132: {
                if (length > 1) {
                    break Label_0132;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 13;
                            break;
                        }
                        case 1: {
                            n5 = 18;
                            break;
                        }
                        case 2: {
                            n5 = 15;
                            break;
                        }
                        case 3: {
                            n5 = 125;
                            break;
                        }
                        case 4: {
                            n5 = 14;
                            break;
                        }
                        case 5: {
                            n5 = 113;
                            break;
                        }
                        default: {
                            n5 = 113;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.z(new String(g));
                NAME_COMPARATOR = new NameFileComparator();
                NAME_REVERSE = new ReverseComparator(NameFileComparator.NAME_COMPARATOR);
                NAME_INSENSITIVE_COMPARATOR = new NameFileComparator(IOCase.INSENSITIVE);
                NAME_INSENSITIVE_REVERSE = new ReverseComparator(NameFileComparator.NAME_INSENSITIVE_COMPARATOR);
                NAME_SYSTEM_COMPARATOR = new NameFileComparator(IOCase.SYSTEM);
                NAME_SYSTEM_REVERSE = new ReverseComparator(NameFileComparator.NAME_SYSTEM_COMPARATOR);
                return;
            }
            continue;
        }
    }
    
    public static void b(final int[] b) {
        NameFileComparator.b = b;
    }
    
    public static int[] b() {
        return NameFileComparator.b;
    }
}
