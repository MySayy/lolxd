// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.monitor;

import com.sun.jna.Structure;
import java.util.Iterator;
import org.apache.commons.io.FileUtils;
import q.o.m.s.q;
import org.apache.commons.io.comparator.NameFileComparator;
import java.util.concurrent.CopyOnWriteArrayList;
import org.apache.commons.io.IOCase;
import java.io.File;
import java.util.Comparator;
import java.io.FileFilter;
import java.util.List;
import java.io.Serializable;

public class FileAlterationObserver implements Serializable
{
    private static final long serialVersionUID = 1185122225658782848L;
    private final List<FileAlterationListener> listeners;
    private final FileEntry rootEntry;
    private final FileFilter fileFilter;
    private final Comparator<File> comparator;
    private static final String[] a;
    private static final String[] b;
    
    public FileAlterationObserver(final String pathname) {
        this(new File(pathname));
    }
    
    public FileAlterationObserver(final String pathname, final FileFilter fileFilter) {
        this(new File(pathname), fileFilter);
    }
    
    public FileAlterationObserver(final String pathname, final FileFilter fileFilter, final IOCase ioCase) {
        this(new File(pathname), fileFilter, ioCase);
    }
    
    public FileAlterationObserver(final File file) {
        this(file, null);
    }
    
    public FileAlterationObserver(final File file, final FileFilter fileFilter) {
        this(file, fileFilter, null);
    }
    
    public FileAlterationObserver(final File file, final FileFilter fileFilter, final IOCase ioCase) {
        this(new FileEntry(file), fileFilter, ioCase);
    }
    
    protected FileAlterationObserver(final FileEntry rootEntry, final FileFilter fileFilter, final IOCase ioCase) {
        final String b = FileEntry.b();
        final String s = b;
        Label_0058: {
            Label_0036: {
                try {
                    this.listeners = new CopyOnWriteArrayList<FileAlterationListener>();
                    final FileEntry fileEntry = rootEntry;
                    if (s != null) {
                        break Label_0058;
                    }
                    if (rootEntry == null) {
                        break Label_0036;
                    }
                    break Label_0036;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    if (rootEntry == null) {
                        throw new IllegalArgumentException(a(3687, 12905));
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            final FileEntry fileEntry = rootEntry;
            try {
                if (fileEntry.getFile() == null) {
                    throw new IllegalArgumentException(a(3685, 24883));
                }
            }
            catch (IllegalArgumentException ex3) {
                throw b(ex3);
            }
        }
        Comparator<File> name_COMPARATOR = null;
        while (true) {
            Label_0200: {
                FileAlterationObserver fileAlterationObserver = null;
                Label_0178: {
                    boolean b3 = false;
                    Label_0164: {
                        Label_0145: {
                            boolean b2 = false;
                            Label_0124: {
                                Label_0113: {
                                    try {
                                        this.rootEntry = rootEntry;
                                        this.fileFilter = fileFilter;
                                        if (s != null) {
                                            break Label_0164;
                                        }
                                        final IOCase ioCase2 = ioCase;
                                        final IOCase ioCase3 = ioCase;
                                        final String s2 = s;
                                        if (s2 == null) {
                                            break Label_0113;
                                        }
                                        break Label_0124;
                                    }
                                    catch (IllegalArgumentException ex4) {
                                        throw b(ex4);
                                    }
                                    try {
                                        final IOCase ioCase2 = ioCase;
                                        final IOCase ioCase3 = ioCase;
                                        final String s2 = s;
                                        if (s2 != null) {
                                            break Label_0124;
                                        }
                                        if (ioCase3 == null) {
                                            break Label_0145;
                                        }
                                    }
                                    catch (IllegalArgumentException ex5) {
                                        throw b(ex5);
                                    }
                                }
                                final IOCase ioCase2 = ioCase;
                                try {
                                    b2 = (b3 = ioCase2.equals(IOCase.SYSTEM));
                                    if (s != null) {
                                        break Label_0178;
                                    }
                                    if (b2) {
                                        break Label_0145;
                                    }
                                    break Label_0164;
                                }
                                catch (IllegalArgumentException ex6) {
                                    throw b(ex6);
                                }
                            }
                            try {
                                if (!b2) {
                                    break Label_0164;
                                }
                                this.comparator = NameFileComparator.NAME_SYSTEM_COMPARATOR;
                            }
                            catch (IllegalArgumentException ex7) {
                                throw b(ex7);
                            }
                        }
                        try {
                            if (s == null) {
                                return;
                            }
                            b3 = ioCase.equals(IOCase.INSENSITIVE);
                        }
                        catch (IllegalArgumentException ex8) {
                            throw b(ex8);
                        }
                    }
                    try {
                        if (!b3) {
                            break Label_0200;
                        }
                        fileAlterationObserver = this;
                        final Comparator<File> name_INSENSITIVE_COMPARATOR = NameFileComparator.NAME_INSENSITIVE_COMPARATOR;
                    }
                    catch (IllegalArgumentException ex9) {
                        throw b(ex9);
                    }
                }
                fileAlterationObserver.comparator = name_COMPARATOR;
                if (s == null) {
                    return;
                }
            }
            FileAlterationObserver fileAlterationObserver = this;
            name_COMPARATOR = NameFileComparator.NAME_COMPARATOR;
            if (s != null) {
                continue;
            }
            break;
        }
        this.comparator = name_COMPARATOR;
    }
    
    public File getDirectory() {
        return this.rootEntry.getFile();
    }
    
    public FileFilter getFileFilter() {
        return this.fileFilter;
    }
    
    public void addListener(final FileAlterationListener fileAlterationListener) {
        try {
            if (fileAlterationListener != null) {
                q.qw(this.listeners, fileAlterationListener);
            }
        }
        catch (IllegalArgumentException ex) {
            throw b(ex);
        }
    }
    
    public void removeListener(final FileAlterationListener p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ifnull          29
        //     4: aload_0        
        //     5: getfield        org/apache/commons/io/monitor/FileAlterationObserver.listeners:Ljava/util/List;
        //     8: aload_1        
        //     9: invokestatic    q/o/m/s/q.cc:(Ljava/util/List;Ljava/lang/Object;)Z
        //    12: ifeq            29
        //    15: goto            22
        //    18: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    21: athrow         
        //    22: goto            4
        //    25: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    28: athrow         
        //    29: return         
        //    StackMapTable: 00 05 04 4D 07 00 31 03 42 07 00 31 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  0      15     18     22     Ljava/lang/IllegalArgumentException;
        //  4      25     25     29     Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0004:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public Iterable<FileAlterationListener> getListeners() {
        return this.listeners;
    }
    
    public void initialize() throws Exception {
        this.rootEntry.refresh(this.rootEntry.getFile());
        this.rootEntry.setChildren(this.doListFiles(this.rootEntry.getFile(), this.rootEntry));
    }
    
    public void destroy() throws Exception {
    }
    
    public void checkAndNotify() {
        final String b = FileEntry.b();
        final Iterator rs = q.rs(this.listeners);
        final String s = b;
        while (q.oi(rs)) {
            ((FileAlterationListener)q.ou(rs)).onStart(this);
            if (s != null) {
                break;
            }
        }
        final File file = this.rootEntry.getFile();
        FileAlterationObserver fileAlterationObserver2 = null;
        Label_0136: {
            while (true) {
                Label_0131: {
                    boolean kc = false;
                    Label_0110: {
                        while (true) {
                            Label_0088: {
                                try {
                                    kc = q.kc(file);
                                    if (s != null) {
                                        break Label_0110;
                                    }
                                    if (!kc) {
                                        break Label_0088;
                                    }
                                }
                                catch (IllegalArgumentException ex) {
                                    throw b(ex);
                                }
                                final FileAlterationObserver fileAlterationObserver = this;
                                fileAlterationObserver.checkAndNotify(this.rootEntry, this.rootEntry.getChildren(), this.listFiles(file));
                                if (s == null) {
                                    break Label_0131;
                                }
                            }
                            fileAlterationObserver2 = this;
                            final FileAlterationObserver fileAlterationObserver = this;
                            if (s != null) {
                                continue;
                            }
                            break;
                        }
                        try {
                            if (s != null) {
                                break Label_0136;
                            }
                            this.rootEntry.isExists();
                        }
                        catch (IllegalArgumentException ex2) {
                            throw b(ex2);
                        }
                    }
                    if (!kc) {
                        break Label_0131;
                    }
                    final FileAlterationObserver fileAlterationObserver3 = this;
                    fileAlterationObserver3.checkAndNotify(this.rootEntry, this.rootEntry.getChildren(), FileUtils.EMPTY_FILE_ARRAY);
                }
                fileAlterationObserver2 = this;
                final FileAlterationObserver fileAlterationObserver3 = this;
                if (s != null) {
                    continue;
                }
                break;
            }
        }
        final Iterator rs2 = q.rs(fileAlterationObserver2.listeners);
        while (q.oi(rs2)) {
            ((FileAlterationListener)q.ou(rs2)).onStop(this);
            if (s != null) {
                break;
            }
        }
    }
    
    private void checkAndNotify(final FileEntry p0, final FileEntry[] p1, final File[] p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: iconst_0       
        //     4: istore          5
        //     6: astore          4
        //     8: aload_3        
        //     9: arraylength    
        //    10: aload           4
        //    12: ifnonnull       46
        //    15: aload           4
        //    17: ifnonnull       46
        //    20: goto            27
        //    23: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    26: athrow         
        //    27: ifle            52
        //    30: goto            37
        //    33: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    36: athrow         
        //    37: aload_3        
        //    38: arraylength    
        //    39: goto            46
        //    42: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    45: athrow         
        //    46: anewarray       Lorg/apache/commons/io/monitor/FileEntry;
        //    49: goto            55
        //    52: getstatic       org/apache/commons/io/monitor/FileEntry.EMPTY_ENTRIES:[Lorg/apache/commons/io/monitor/FileEntry;
        //    55: astore          6
        //    57: aload_2        
        //    58: astore          7
        //    60: aload           7
        //    62: arraylength    
        //    63: istore          8
        //    65: iconst_0       
        //    66: istore          9
        //    68: iload           9
        //    70: iload           8
        //    72: if_icmpge       326
        //    75: aload           7
        //    77: iload           9
        //    79: aaload         
        //    80: aload           4
        //    82: ifnonnull       377
        //    85: astore          10
        //    87: iload           5
        //    89: aload_3        
        //    90: arraylength    
        //    91: if_icmpge       187
        //    94: aload_0        
        //    95: aload           4
        //    97: ifnonnull       171
        //   100: getfield        org/apache/commons/io/monitor/FileAlterationObserver.comparator:Ljava/util/Comparator;
        //   103: aload           10
        //   105: invokevirtual   org/apache/commons/io/monitor/FileEntry.getFile:()Ljava/io/File;
        //   108: aload_3        
        //   109: iload           5
        //   111: aaload         
        //   112: invokestatic    q/o/m/s/q.cn:(Ljava/util/Comparator;Ljava/lang/Object;Ljava/lang/Object;)I
        //   115: aload           4
        //   117: ifnonnull       189
        //   120: goto            127
        //   123: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   126: athrow         
        //   127: aload           4
        //   129: ifnonnull       189
        //   132: goto            139
        //   135: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   138: athrow         
        //   139: ifle            187
        //   142: goto            149
        //   145: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   148: athrow         
        //   149: aload           6
        //   151: iload           5
        //   153: aload_0        
        //   154: aload_1        
        //   155: aload_3        
        //   156: iload           5
        //   158: aaload         
        //   159: invokespecial   org/apache/commons/io/monitor/FileAlterationObserver.createFileEntry:(Lorg/apache/commons/io/monitor/FileEntry;Ljava/io/File;)Lorg/apache/commons/io/monitor/FileEntry;
        //   162: aastore        
        //   163: aload_0        
        //   164: goto            171
        //   167: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   170: athrow         
        //   171: aload           6
        //   173: iload           5
        //   175: aaload         
        //   176: invokespecial   org/apache/commons/io/monitor/FileAlterationObserver.doCreate:(Lorg/apache/commons/io/monitor/FileEntry;)V
        //   179: iinc            5, 1
        //   182: aload           4
        //   184: ifnull          87
        //   187: iload           5
        //   189: aload           4
        //   191: ifnonnull       234
        //   194: aload_3        
        //   195: arraylength    
        //   196: if_icmpge       288
        //   199: goto            206
        //   202: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   205: athrow         
        //   206: aload_0        
        //   207: goto            214
        //   210: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   213: athrow         
        //   214: aload           4
        //   216: ifnonnull       308
        //   219: getfield        org/apache/commons/io/monitor/FileAlterationObserver.comparator:Ljava/util/Comparator;
        //   222: aload           10
        //   224: invokevirtual   org/apache/commons/io/monitor/FileEntry.getFile:()Ljava/io/File;
        //   227: aload_3        
        //   228: iload           5
        //   230: aaload         
        //   231: invokestatic    q/o/m/s/q.cn:(Ljava/util/Comparator;Ljava/lang/Object;Ljava/lang/Object;)I
        //   234: ifne            288
        //   237: aload_0        
        //   238: aload           10
        //   240: aload_3        
        //   241: iload           5
        //   243: aaload         
        //   244: invokespecial   org/apache/commons/io/monitor/FileAlterationObserver.doMatch:(Lorg/apache/commons/io/monitor/FileEntry;Ljava/io/File;)V
        //   247: aload_0        
        //   248: aload           10
        //   250: goto            257
        //   253: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   256: athrow         
        //   257: aload           10
        //   259: invokevirtual   org/apache/commons/io/monitor/FileEntry.getChildren:()[Lorg/apache/commons/io/monitor/FileEntry;
        //   262: aload_0        
        //   263: aload_3        
        //   264: iload           5
        //   266: aaload         
        //   267: invokespecial   org/apache/commons/io/monitor/FileAlterationObserver.listFiles:(Ljava/io/File;)[Ljava/io/File;
        //   270: invokespecial   org/apache/commons/io/monitor/FileAlterationObserver.checkAndNotify:(Lorg/apache/commons/io/monitor/FileEntry;[Lorg/apache/commons/io/monitor/FileEntry;[Ljava/io/File;)V
        //   273: aload           6
        //   275: iload           5
        //   277: aload           10
        //   279: aastore        
        //   280: iinc            5, 1
        //   283: aload           4
        //   285: ifnull          318
        //   288: aload_0        
        //   289: aload           10
        //   291: aload           10
        //   293: invokevirtual   org/apache/commons/io/monitor/FileEntry.getChildren:()[Lorg/apache/commons/io/monitor/FileEntry;
        //   296: getstatic       org/apache/commons/io/FileUtils.EMPTY_FILE_ARRAY:[Ljava/io/File;
        //   299: invokespecial   org/apache/commons/io/monitor/FileAlterationObserver.checkAndNotify:(Lorg/apache/commons/io/monitor/FileEntry;[Lorg/apache/commons/io/monitor/FileEntry;[Ljava/io/File;)V
        //   302: aload_0        
        //   303: aload           4
        //   305: ifnonnull       214
        //   308: aload           10
        //   310: aload           4
        //   312: ifnonnull       257
        //   315: invokespecial   org/apache/commons/io/monitor/FileAlterationObserver.doDelete:(Lorg/apache/commons/io/monitor/FileEntry;)V
        //   318: iinc            9, 1
        //   321: aload           4
        //   323: ifnull          68
        //   326: iload           5
        //   328: aload_3        
        //   329: arraylength    
        //   330: if_icmpge       376
        //   333: aload           6
        //   335: iload           5
        //   337: aload_0        
        //   338: aload_1        
        //   339: aload_3        
        //   340: iload           5
        //   342: aaload         
        //   343: invokespecial   org/apache/commons/io/monitor/FileAlterationObserver.createFileEntry:(Lorg/apache/commons/io/monitor/FileEntry;Ljava/io/File;)Lorg/apache/commons/io/monitor/FileEntry;
        //   346: aastore        
        //   347: aload_0        
        //   348: aload           6
        //   350: iload           5
        //   352: aaload         
        //   353: invokespecial   org/apache/commons/io/monitor/FileAlterationObserver.doCreate:(Lorg/apache/commons/io/monitor/FileEntry;)V
        //   356: iinc            5, 1
        //   359: aload           4
        //   361: ifnonnull       382
        //   364: aload           4
        //   366: ifnull          326
        //   369: goto            376
        //   372: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   375: athrow         
        //   376: aload_1        
        //   377: aload           6
        //   379: invokevirtual   org/apache/commons/io/monitor/FileEntry.setChildren:([Lorg/apache/commons/io/monitor/FileEntry;)V
        //   382: return         
        //    StackMapTable: 00 23 FF 00 17 00 06 07 00 02 07 00 2B 07 00 BF 07 00 C0 07 00 42 01 00 01 07 00 31 43 01 45 07 00 31 03 44 07 00 31 43 01 05 42 07 00 BF FF 00 0C 00 0A 07 00 02 07 00 2B 07 00 BF 07 00 C0 07 00 42 01 07 00 BF 07 00 BF 01 01 00 00 FC 00 12 07 00 2B 63 07 00 31 43 01 47 07 00 31 43 01 45 07 00 31 03 51 07 00 31 43 07 00 02 0F 41 01 4C 07 00 31 03 43 07 00 31 43 07 00 02 53 01 52 07 00 31 FF 00 03 00 0B 07 00 02 07 00 2B 07 00 BF 07 00 C0 07 00 42 01 07 00 BF 07 00 BF 01 01 07 00 2B 00 02 07 00 02 07 00 2B 1E 53 07 00 02 09 FA 00 07 6D 07 00 31 03 40 07 00 2B 04
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  8      20     23     27     Ljava/lang/IllegalArgumentException;
        //  15     30     33     37     Ljava/lang/IllegalArgumentException;
        //  27     39     42     46     Ljava/lang/IllegalArgumentException;
        //  94     120    123    127    Ljava/lang/IllegalArgumentException;
        //  100    132    135    139    Ljava/lang/IllegalArgumentException;
        //  127    142    145    149    Ljava/lang/IllegalArgumentException;
        //  139    164    167    171    Ljava/lang/IllegalArgumentException;
        //  189    199    202    206    Ljava/lang/IllegalArgumentException;
        //  194    207    210    214    Ljava/lang/IllegalArgumentException;
        //  234    250    253    257    Ljava/lang/IllegalArgumentException;
        //  333    369    372    376    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0027:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private FileEntry createFileEntry(final FileEntry fileEntry, final File file) {
        final FileEntry childInstance = fileEntry.newChildInstance(file);
        childInstance.refresh(file);
        childInstance.setChildren(this.doListFiles(file, childInstance));
        return childInstance;
    }
    
    private FileEntry[] doListFiles(final File p0, final FileEntry p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: aload_1        
        //     2: invokespecial   org/apache/commons/io/monitor/FileAlterationObserver.listFiles:(Ljava/io/File;)[Ljava/io/File;
        //     5: astore          4
        //     7: invokestatic    org/apache/commons/io/monitor/FileEntry.b:()Ljava/lang/String;
        //    10: astore_3       
        //    11: aload           4
        //    13: arraylength    
        //    14: aload_3        
        //    15: ifnonnull       49
        //    18: aload_3        
        //    19: ifnonnull       49
        //    22: goto            29
        //    25: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    28: athrow         
        //    29: ifle            55
        //    32: goto            39
        //    35: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    38: athrow         
        //    39: aload           4
        //    41: arraylength    
        //    42: goto            49
        //    45: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    48: athrow         
        //    49: anewarray       Lorg/apache/commons/io/monitor/FileEntry;
        //    52: goto            58
        //    55: getstatic       org/apache/commons/io/monitor/FileEntry.EMPTY_ENTRIES:[Lorg/apache/commons/io/monitor/FileEntry;
        //    58: astore          5
        //    60: iconst_0       
        //    61: istore          6
        //    63: iload           6
        //    65: aload           4
        //    67: arraylength    
        //    68: if_icmpge       104
        //    71: aload           5
        //    73: aload_3        
        //    74: ifnonnull       106
        //    77: iload           6
        //    79: aload_0        
        //    80: aload_2        
        //    81: aload           4
        //    83: iload           6
        //    85: aaload         
        //    86: invokespecial   org/apache/commons/io/monitor/FileAlterationObserver.createFileEntry:(Lorg/apache/commons/io/monitor/FileEntry;Ljava/io/File;)Lorg/apache/commons/io/monitor/FileEntry;
        //    89: aastore        
        //    90: iinc            6, 1
        //    93: aload_3        
        //    94: ifnull          63
        //    97: goto            104
        //   100: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   103: athrow         
        //   104: aload           5
        //   106: areturn        
        //    StackMapTable: 00 0C FF 00 19 00 05 07 00 02 07 00 1C 07 00 2B 07 00 42 07 00 C0 00 01 07 00 31 43 01 45 07 00 31 03 45 07 00 31 43 01 05 42 07 00 BF FD 00 04 07 00 BF 01 64 07 00 31 03 41 07 00 BF
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  11     22     25     29     Ljava/lang/IllegalArgumentException;
        //  18     32     35     39     Ljava/lang/IllegalArgumentException;
        //  29     42     45     49     Ljava/lang/IllegalArgumentException;
        //  71     97     100    104    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0029:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void doCreate(final FileEntry p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: getfield        org/apache/commons/io/monitor/FileAlterationObserver.listeners:Ljava/util/List;
        //     7: invokestatic    q/o/m/s/q.rs:(Ljava/util/List;)Ljava/util/Iterator;
        //    10: astore_3       
        //    11: astore_2       
        //    12: aload_3        
        //    13: invokestatic    q/o/m/s/q.oi:(Ljava/util/Iterator;)Z
        //    16: ifeq            105
        //    19: aload_3        
        //    20: invokestatic    q/o/m/s/q.ou:(Ljava/util/Iterator;)Ljava/lang/Object;
        //    23: checkcast       Lorg/apache/commons/io/monitor/FileAlterationListener;
        //    26: astore          4
        //    28: aload_2        
        //    29: ifnonnull       75
        //    32: aload_1        
        //    33: aload_2        
        //    34: ifnonnull       106
        //    37: goto            44
        //    40: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    43: athrow         
        //    44: invokevirtual   org/apache/commons/io/monitor/FileEntry.isDirectory:()Z
        //    47: ifeq            79
        //    50: goto            57
        //    53: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    56: athrow         
        //    57: aload           4
        //    59: aload_1        
        //    60: invokevirtual   org/apache/commons/io/monitor/FileEntry.getFile:()Ljava/io/File;
        //    63: goto            70
        //    66: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    69: athrow         
        //    70: invokeinterface org/apache/commons/io/monitor/FileAlterationListener.onDirectoryCreate:(Ljava/io/File;)V
        //    75: aload_2        
        //    76: ifnull          101
        //    79: aload           4
        //    81: aload_1        
        //    82: invokevirtual   org/apache/commons/io/monitor/FileEntry.getFile:()Ljava/io/File;
        //    85: aload_2        
        //    86: ifnonnull       70
        //    89: goto            96
        //    92: invokestatic    org/apache/commons/io/monitor/FileAlterationObserver.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    95: athrow         
        //    96: invokeinterface org/apache/commons/io/monitor/FileAlterationListener.onFileCreate:(Ljava/io/File;)V
        //   101: aload_2        
        //   102: ifnull          12
        //   105: aload_1        
        //   106: invokevirtual   org/apache/commons/io/monitor/FileEntry.getChildren:()[Lorg/apache/commons/io/monitor/FileEntry;
        //   109: astore_3       
        //   110: aload_3        
        //   111: astore          4
        //   113: aload           4
        //   115: arraylength    
        //   116: istore          5
        //   118: iconst_0       
        //   119: istore          6
        //   121: iload           6
        //   123: iload           5
        //   125: if_icmpge       148
        //   128: aload           4
        //   130: iload           6
        //   132: aaload         
        //   133: astore          7
        //   135: aload_0        
        //   136: aload           7
        //   138: invokespecial   org/apache/commons/io/monitor/FileAlterationObserver.doCreate:(Lorg/apache/commons/io/monitor/FileEntry;)V
        //   141: iinc            6, 1
        //   144: aload_2        
        //   145: ifnull          121
        //   148: return         
        //    StackMapTable: 00 10 FD 00 0C 07 00 42 07 00 94 FF 00 1B 00 05 07 00 02 07 00 2B 07 00 42 07 00 94 07 00 9E 00 01 07 00 31 43 07 00 2B 48 07 00 31 03 48 07 00 31 FF 00 03 00 05 07 00 02 07 00 2B 07 00 42 07 00 94 07 00 9E 00 02 07 00 9E 07 00 1C 04 03 4C 07 00 31 FF 00 03 00 05 07 00 02 07 00 2B 07 00 42 07 00 94 07 00 9E 00 02 07 00 9E 07 00 1C 04 FA 00 03 40 07 00 2B FF 00 0E 00 07 07 00 02 07 00 2B 07 00 42 07 00 BF 07 00 BF 01 01 00 00 1A
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  28     37     40     44     Ljava/lang/IllegalArgumentException;
        //  32     50     53     57     Ljava/lang/IllegalArgumentException;
        //  44     63     66     70     Ljava/lang/IllegalArgumentException;
        //  75     89     92     96     Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0044:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void doMatch(final FileEntry fileEntry, final File file) {
        final String b = FileEntry.b();
        if (fileEntry.refresh(file)) {
            final Iterator rs = q.rs(this.listeners);
            while (q.oi(rs)) {
                final FileAlterationListener fileAlterationListener = (FileAlterationListener)q.ou(rs);
                Label_0095: {
                    FileAlterationListener fileAlterationListener2 = null;
                    Label_0076: {
                        File file2 = null;
                        Label_0057: {
                            try {
                                if (b != null) {
                                    break Label_0076;
                                }
                                final FileEntry fileEntry2 = fileEntry;
                                final boolean b2 = fileEntry2.isDirectory();
                                if (b2) {
                                    break Label_0057;
                                }
                                break Label_0076;
                            }
                            catch (IllegalArgumentException ex) {
                                throw b(ex);
                            }
                            try {
                                final FileEntry fileEntry2 = fileEntry;
                                final boolean b2 = fileEntry2.isDirectory();
                                if (!b2) {
                                    break Label_0076;
                                }
                                file2 = file;
                            }
                            catch (IllegalArgumentException ex2) {
                                throw b(ex2);
                            }
                        }
                        while (true) {
                            fileAlterationListener2.onDirectoryChange(file2);
                            try {
                                if (b == null) {
                                    break Label_0095;
                                }
                                fileAlterationListener2 = fileAlterationListener;
                                file2 = file;
                                if (b != null) {
                                    continue;
                                }
                            }
                            catch (IllegalArgumentException ex3) {
                                throw b(ex3);
                            }
                            break;
                        }
                    }
                    fileAlterationListener2.onFileChange(file);
                }
                if (b != null) {
                    break;
                }
            }
        }
    }
    
    private void doDelete(final FileEntry fileEntry) {
        final String b = FileEntry.b();
        final Iterator rs = q.rs(this.listeners);
        final String s = b;
        while (q.oi(rs)) {
            final FileAlterationListener fileAlterationListener = (FileAlterationListener)q.ou(rs);
            Label_0090: {
                FileAlterationListener fileAlterationListener2 = null;
                File file2 = null;
                Label_0068: {
                    Label_0046: {
                        try {
                            if (s != null) {
                                break Label_0068;
                            }
                            final FileEntry fileEntry2 = fileEntry;
                            final boolean b2 = fileEntry2.isDirectory();
                            if (b2) {
                                break Label_0046;
                            }
                            break Label_0068;
                        }
                        catch (IllegalArgumentException ex) {
                            throw b(ex);
                        }
                        try {
                            final FileEntry fileEntry2 = fileEntry;
                            final boolean b2 = fileEntry2.isDirectory();
                            if (!b2) {
                                break Label_0068;
                            }
                            final File file = fileEntry.getFile();
                        }
                        catch (IllegalArgumentException ex2) {
                            throw b(ex2);
                        }
                    }
                    while (true) {
                        fileAlterationListener2.onDirectoryDelete(file2);
                        try {
                            if (s == null) {
                                break Label_0090;
                            }
                            fileAlterationListener2 = fileAlterationListener;
                            file2 = fileEntry.getFile();
                            if (s != null) {
                                continue;
                            }
                        }
                        catch (IllegalArgumentException ex3) {
                            throw b(ex3);
                        }
                        break;
                    }
                }
                fileAlterationListener2.onFileDelete(file2);
            }
            if (s != null) {
                break;
            }
        }
    }
    
    private File[] listFiles(final File file) {
        final String b = FileEntry.b();
        File[] array = null;
        final String s = b;
        File[] array4 = null;
        while (true) {
            while (true) {
                Label_0123: {
                    File[] array5 = null;
                    Label_0084: {
                        File[] array3 = null;
                        Label_0083: {
                            Label_0070: {
                                Label_0054: {
                                    File[] array2 = null;
                                    Label_0053: {
                                        while (true) {
                                            Label_0041: {
                                                File file2 = null;
                                                Label_0027: {
                                                    try {
                                                        if (!q.su(file)) {
                                                            break Label_0054;
                                                        }
                                                        final FileAlterationObserver fileAlterationObserver = this;
                                                        final FileFilter fileFilter = fileAlterationObserver.fileFilter;
                                                        if (fileFilter == null) {
                                                            break Label_0027;
                                                        }
                                                        break Label_0041;
                                                    }
                                                    catch (IllegalArgumentException ex) {
                                                        throw b(ex);
                                                    }
                                                    try {
                                                        final FileAlterationObserver fileAlterationObserver = this;
                                                        final FileFilter fileFilter = fileAlterationObserver.fileFilter;
                                                        if (fileFilter != null) {
                                                            break Label_0041;
                                                        }
                                                        file2 = file;
                                                    }
                                                    catch (IllegalArgumentException ex2) {
                                                        throw b(ex2);
                                                    }
                                                }
                                                array2 = q.sl(file2);
                                                break Label_0053;
                                            }
                                            File file2 = file;
                                            if (s != null) {
                                                continue;
                                            }
                                            break;
                                        }
                                        array2 = q.si(file, this.fileFilter);
                                    }
                                    array = array2;
                                    try {
                                        array3 = array;
                                        if (s != null) {
                                            break Label_0083;
                                        }
                                        final String s2 = s;
                                        if (s2 == null) {
                                            break Label_0070;
                                        }
                                        break Label_0083;
                                    }
                                    catch (IllegalArgumentException ex3) {
                                        throw b(ex3);
                                    }
                                }
                                try {
                                    final String s2 = s;
                                    if (s2 != null) {
                                        break Label_0083;
                                    }
                                    if (array3 != null) {
                                        break Label_0084;
                                    }
                                }
                                catch (IllegalArgumentException ex4) {
                                    throw b(ex4);
                                }
                            }
                            final File[] empty_FILE_ARRAY = FileUtils.EMPTY_FILE_ARRAY;
                        }
                        array = array3;
                        try {
                            if (this.comparator == null) {
                                break Label_0123;
                            }
                            array4 = (array5 = array);
                        }
                        catch (IllegalArgumentException ex5) {
                            throw b(ex5);
                        }
                    }
                    if (s != null) {
                        return array4;
                    }
                    File[] array6;
                    try {
                        if (array5.length <= 1) {
                            break Label_0123;
                        }
                        array6 = array;
                    }
                    catch (IllegalArgumentException ex6) {
                        throw b(ex6);
                    }
                    q.cr(array6, this.comparator);
                }
                File[] array5;
                File[] array6 = array5 = (array4 = array);
                if (s != null) {
                    continue;
                }
                break;
            }
            if (s != null) {
                continue;
            }
            break;
        }
        return array4;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        q.r(sb, q.ss(q.qi(this)));
        q.r(sb, a(3683, 21832));
        final String b = FileEntry.b();
        q.r(sb, q.rb(this.getDirectory()));
        q.sk(sb, '\'');
        final String s = b;
        while (true) {
            Label_0142: {
                Label_0075: {
                    try {
                        if (s != null) {
                            break Label_0142;
                        }
                        final FileAlterationObserver fileAlterationObserver = this;
                        final FileFilter fileFilter = fileAlterationObserver.fileFilter;
                        if (fileFilter != null) {
                            break Label_0075;
                        }
                        break Label_0107;
                    }
                    catch (IllegalArgumentException ex) {
                        throw b(ex);
                    }
                    try {
                        final FileAlterationObserver fileAlterationObserver = this;
                        final FileFilter fileFilter = fileAlterationObserver.fileFilter;
                        if (fileFilter != null) {
                            q.r(sb, a(3686, -4702));
                            q.r(sb, q.yh(this.fileFilter));
                        }
                    }
                    catch (IllegalArgumentException ex2) {
                        throw b(ex2);
                    }
                }
                q.r(sb, a(3684, 12994));
                q.qg(sb, q.kg(this.listeners));
                q.r(sb, n.d.a.d.q.vq());
            }
            final StringBuilder sb2 = sb;
            if (s == null) {
                String s2;
                try {
                    s2 = q.s(sb2);
                    if (Structure.b() != 0) {
                        FileEntry.b(a(3682, -22358));
                    }
                }
                catch (IllegalArgumentException ex3) {
                    throw b(ex3);
                }
                return s2;
            }
            continue;
        }
    }
    
    private static IllegalArgumentException b(final IllegalArgumentException ex) {
        return ex;
    }
    
    static {
        final String[] a2 = new String[6];
        int n = 0;
        String s;
        int n2 = q.q(s = n.d.a.d.q.tv());
        int n3 = 21;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 125));
                ++n4;
                final String s2 = s;
                final int n9 = n4;
                String s3 = q.h(s2, n9, n9 + n3);
                int n10 = -1;
                while (true) {
                    final char[] g = q.g(s3);
                    final int length = g.length;
                    int n11 = 0;
                    while (true) {
                        Label_0264: {
                            if (length > 1) {
                                break Label_0264;
                            }
                            n7 = (n6 = n11);
                            do {
                                final char c = g[n6];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 81;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 60;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 98;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 50;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 30;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 29;
                                        break;
                                    }
                                    default: {
                                        n12 = 14;
                                        break;
                                    }
                                }
                                g[n7] = (char)(c ^ (n5 ^ n12));
                                ++n11;
                            } while (n8 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.z(new String(g));
                    switch (n10) {
                        default: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                continue Label_0024;
                            }
                            n2 = q.q(s = n.d.a.d.q.to());
                            n3 = 7;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            a2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.j(s, n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 32)));
                    ++n4;
                    final String s4 = s;
                    final int n13 = n4;
                    s3 = q.h(s4, n13, n13 + n3);
                    n10 = 0;
                }
            }
            break;
        }
        a = a2;
        b = new String[6];
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0xE67) & 0xFFFF;
        if (FileAlterationObserver.b[n3] == null) {
            final char[] g = q.g(FileAlterationObserver.a[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 156;
                    break;
                }
                case 1: {
                    n4 = 65;
                    break;
                }
                case 2: {
                    n4 = 89;
                    break;
                }
                case 3: {
                    n4 = 86;
                    break;
                }
                case 4: {
                    n4 = 127;
                    break;
                }
                case 5: {
                    n4 = 12;
                    break;
                }
                case 6: {
                    n4 = 164;
                    break;
                }
                case 7: {
                    n4 = 138;
                    break;
                }
                case 8: {
                    n4 = 212;
                    break;
                }
                case 9: {
                    n4 = 93;
                    break;
                }
                case 10: {
                    n4 = 28;
                    break;
                }
                case 11: {
                    n4 = 240;
                    break;
                }
                case 12: {
                    n4 = 100;
                    break;
                }
                case 13: {
                    n4 = 205;
                    break;
                }
                case 14: {
                    n4 = 60;
                    break;
                }
                case 15: {
                    n4 = 218;
                    break;
                }
                case 16: {
                    n4 = 198;
                    break;
                }
                case 17: {
                    n4 = 101;
                    break;
                }
                case 18: {
                    n4 = 227;
                    break;
                }
                case 19: {
                    n4 = 130;
                    break;
                }
                case 20: {
                    n4 = 53;
                    break;
                }
                case 21: {
                    n4 = 88;
                    break;
                }
                case 22: {
                    n4 = 26;
                    break;
                }
                case 23: {
                    n4 = 3;
                    break;
                }
                case 24: {
                    n4 = 45;
                    break;
                }
                case 25: {
                    n4 = 150;
                    break;
                }
                case 26: {
                    n4 = 253;
                    break;
                }
                case 27: {
                    n4 = 22;
                    break;
                }
                case 28: {
                    n4 = 110;
                    break;
                }
                case 29: {
                    n4 = 35;
                    break;
                }
                case 30: {
                    n4 = 76;
                    break;
                }
                case 31: {
                    n4 = 14;
                    break;
                }
                case 32: {
                    n4 = 245;
                    break;
                }
                case 33: {
                    n4 = 67;
                    break;
                }
                case 34: {
                    n4 = 196;
                    break;
                }
                case 35: {
                    n4 = 229;
                    break;
                }
                case 36: {
                    n4 = 148;
                    break;
                }
                case 37: {
                    n4 = 188;
                    break;
                }
                case 38: {
                    n4 = 85;
                    break;
                }
                case 39: {
                    n4 = 216;
                    break;
                }
                case 40: {
                    n4 = 108;
                    break;
                }
                case 41: {
                    n4 = 99;
                    break;
                }
                case 42: {
                    n4 = 140;
                    break;
                }
                case 43: {
                    n4 = 220;
                    break;
                }
                case 44: {
                    n4 = 181;
                    break;
                }
                case 45: {
                    n4 = 175;
                    break;
                }
                case 46: {
                    n4 = 252;
                    break;
                }
                case 47: {
                    n4 = 91;
                    break;
                }
                case 48: {
                    n4 = 21;
                    break;
                }
                case 49: {
                    n4 = 136;
                    break;
                }
                case 50: {
                    n4 = 63;
                    break;
                }
                case 51: {
                    n4 = 19;
                    break;
                }
                case 52: {
                    n4 = 72;
                    break;
                }
                case 53: {
                    n4 = 187;
                    break;
                }
                case 54: {
                    n4 = 6;
                    break;
                }
                case 55: {
                    n4 = 183;
                    break;
                }
                case 56: {
                    n4 = 36;
                    break;
                }
                case 57: {
                    n4 = 62;
                    break;
                }
                case 58: {
                    n4 = 199;
                    break;
                }
                case 59: {
                    n4 = 40;
                    break;
                }
                case 60: {
                    n4 = 208;
                    break;
                }
                case 61: {
                    n4 = 80;
                    break;
                }
                case 62: {
                    n4 = 114;
                    break;
                }
                case 63: {
                    n4 = 112;
                    break;
                }
                case 64: {
                    n4 = 149;
                    break;
                }
                case 65: {
                    n4 = 10;
                    break;
                }
                case 66: {
                    n4 = 66;
                    break;
                }
                case 67: {
                    n4 = 160;
                    break;
                }
                case 68: {
                    n4 = 167;
                    break;
                }
                case 69: {
                    n4 = 84;
                    break;
                }
                case 70: {
                    n4 = 97;
                    break;
                }
                case 71: {
                    n4 = 151;
                    break;
                }
                case 72: {
                    n4 = 173;
                    break;
                }
                case 73: {
                    n4 = 75;
                    break;
                }
                case 74: {
                    n4 = 178;
                    break;
                }
                case 75: {
                    n4 = 38;
                    break;
                }
                case 76: {
                    n4 = 4;
                    break;
                }
                case 77: {
                    n4 = 41;
                    break;
                }
                case 78: {
                    n4 = 15;
                    break;
                }
                case 79: {
                    n4 = 217;
                    break;
                }
                case 80: {
                    n4 = 122;
                    break;
                }
                case 81: {
                    n4 = 166;
                    break;
                }
                case 82: {
                    n4 = 8;
                    break;
                }
                case 83: {
                    n4 = 2;
                    break;
                }
                case 84: {
                    n4 = 57;
                    break;
                }
                case 85: {
                    n4 = 214;
                    break;
                }
                case 86: {
                    n4 = 250;
                    break;
                }
                case 87: {
                    n4 = 107;
                    break;
                }
                case 88: {
                    n4 = 78;
                    break;
                }
                case 89: {
                    n4 = 115;
                    break;
                }
                case 90: {
                    n4 = 139;
                    break;
                }
                case 91: {
                    n4 = 168;
                    break;
                }
                case 92: {
                    n4 = 5;
                    break;
                }
                case 93: {
                    n4 = 118;
                    break;
                }
                case 94: {
                    n4 = 195;
                    break;
                }
                case 95: {
                    n4 = 170;
                    break;
                }
                case 96: {
                    n4 = 50;
                    break;
                }
                case 97: {
                    n4 = 64;
                    break;
                }
                case 98: {
                    n4 = 96;
                    break;
                }
                case 99: {
                    n4 = 210;
                    break;
                }
                case 100: {
                    n4 = 131;
                    break;
                }
                case 101: {
                    n4 = 98;
                    break;
                }
                case 102: {
                    n4 = 221;
                    break;
                }
                case 103: {
                    n4 = 235;
                    break;
                }
                case 104: {
                    n4 = 74;
                    break;
                }
                case 105: {
                    n4 = 111;
                    break;
                }
                case 106: {
                    n4 = 61;
                    break;
                }
                case 107: {
                    n4 = 129;
                    break;
                }
                case 108: {
                    n4 = 81;
                    break;
                }
                case 109: {
                    n4 = 204;
                    break;
                }
                case 110: {
                    n4 = 237;
                    break;
                }
                case 111: {
                    n4 = 201;
                    break;
                }
                case 112: {
                    n4 = 165;
                    break;
                }
                case 113: {
                    n4 = 70;
                    break;
                }
                case 114: {
                    n4 = 153;
                    break;
                }
                case 115: {
                    n4 = 230;
                    break;
                }
                case 116: {
                    n4 = 119;
                    break;
                }
                case 117: {
                    n4 = 58;
                    break;
                }
                case 118: {
                    n4 = 117;
                    break;
                }
                case 119: {
                    n4 = 113;
                    break;
                }
                case 120: {
                    n4 = 9;
                    break;
                }
                case 121: {
                    n4 = 207;
                    break;
                }
                case 122: {
                    n4 = 31;
                    break;
                }
                case 123: {
                    n4 = 18;
                    break;
                }
                case 124: {
                    n4 = 189;
                    break;
                }
                case 125: {
                    n4 = 104;
                    break;
                }
                case 126: {
                    n4 = 106;
                    break;
                }
                case 127: {
                    n4 = 23;
                    break;
                }
                case 128: {
                    n4 = 172;
                    break;
                }
                case 129: {
                    n4 = 29;
                    break;
                }
                case 130: {
                    n4 = 11;
                    break;
                }
                case 131: {
                    n4 = 179;
                    break;
                }
                case 132: {
                    n4 = 79;
                    break;
                }
                case 133: {
                    n4 = 206;
                    break;
                }
                case 134: {
                    n4 = 147;
                    break;
                }
                case 135: {
                    n4 = 109;
                    break;
                }
                case 136: {
                    n4 = 30;
                    break;
                }
                case 137: {
                    n4 = 0;
                    break;
                }
                case 138: {
                    n4 = 176;
                    break;
                }
                case 139: {
                    n4 = 234;
                    break;
                }
                case 140: {
                    n4 = 133;
                    break;
                }
                case 141: {
                    n4 = 190;
                    break;
                }
                case 142: {
                    n4 = 155;
                    break;
                }
                case 143: {
                    n4 = 197;
                    break;
                }
                case 144: {
                    n4 = 224;
                    break;
                }
                case 145: {
                    n4 = 71;
                    break;
                }
                case 146: {
                    n4 = 202;
                    break;
                }
                case 147: {
                    n4 = 254;
                    break;
                }
                case 148: {
                    n4 = 191;
                    break;
                }
                case 149: {
                    n4 = 182;
                    break;
                }
                case 150: {
                    n4 = 247;
                    break;
                }
                case 151: {
                    n4 = 192;
                    break;
                }
                case 152: {
                    n4 = 194;
                    break;
                }
                case 153: {
                    n4 = 141;
                    break;
                }
                case 154: {
                    n4 = 1;
                    break;
                }
                case 155: {
                    n4 = 241;
                    break;
                }
                case 156: {
                    n4 = 73;
                    break;
                }
                case 157: {
                    n4 = 161;
                    break;
                }
                case 158: {
                    n4 = 174;
                    break;
                }
                case 159: {
                    n4 = 159;
                    break;
                }
                case 160: {
                    n4 = 215;
                    break;
                }
                case 161: {
                    n4 = 7;
                    break;
                }
                case 162: {
                    n4 = 180;
                    break;
                }
                case 163: {
                    n4 = 146;
                    break;
                }
                case 164: {
                    n4 = 125;
                    break;
                }
                case 165: {
                    n4 = 48;
                    break;
                }
                case 166: {
                    n4 = 142;
                    break;
                }
                case 167: {
                    n4 = 105;
                    break;
                }
                case 168: {
                    n4 = 193;
                    break;
                }
                case 169: {
                    n4 = 145;
                    break;
                }
                case 170: {
                    n4 = 39;
                    break;
                }
                case 171: {
                    n4 = 25;
                    break;
                }
                case 172: {
                    n4 = 184;
                    break;
                }
                case 173: {
                    n4 = 158;
                    break;
                }
                case 174: {
                    n4 = 157;
                    break;
                }
                case 175: {
                    n4 = 154;
                    break;
                }
                case 176: {
                    n4 = 54;
                    break;
                }
                case 177: {
                    n4 = 128;
                    break;
                }
                case 178: {
                    n4 = 120;
                    break;
                }
                case 179: {
                    n4 = 34;
                    break;
                }
                case 180: {
                    n4 = 200;
                    break;
                }
                case 181: {
                    n4 = 27;
                    break;
                }
                case 182: {
                    n4 = 203;
                    break;
                }
                case 183: {
                    n4 = 144;
                    break;
                }
                case 184: {
                    n4 = 77;
                    break;
                }
                case 185: {
                    n4 = 152;
                    break;
                }
                case 186: {
                    n4 = 46;
                    break;
                }
                case 187: {
                    n4 = 132;
                    break;
                }
                case 188: {
                    n4 = 163;
                    break;
                }
                case 189: {
                    n4 = 228;
                    break;
                }
                case 190: {
                    n4 = 169;
                    break;
                }
                case 191: {
                    n4 = 134;
                    break;
                }
                case 192: {
                    n4 = 20;
                    break;
                }
                case 193: {
                    n4 = 116;
                    break;
                }
                case 194: {
                    n4 = 123;
                    break;
                }
                case 195: {
                    n4 = 219;
                    break;
                }
                case 196: {
                    n4 = 59;
                    break;
                }
                case 197: {
                    n4 = 213;
                    break;
                }
                case 198: {
                    n4 = 249;
                    break;
                }
                case 199: {
                    n4 = 92;
                    break;
                }
                case 200: {
                    n4 = 239;
                    break;
                }
                case 201: {
                    n4 = 103;
                    break;
                }
                case 202: {
                    n4 = 238;
                    break;
                }
                case 203: {
                    n4 = 226;
                    break;
                }
                case 204: {
                    n4 = 242;
                    break;
                }
                case 205: {
                    n4 = 47;
                    break;
                }
                case 206: {
                    n4 = 211;
                    break;
                }
                case 207: {
                    n4 = 52;
                    break;
                }
                case 208: {
                    n4 = 51;
                    break;
                }
                case 209: {
                    n4 = 177;
                    break;
                }
                case 210: {
                    n4 = 82;
                    break;
                }
                case 211: {
                    n4 = 56;
                    break;
                }
                case 212: {
                    n4 = 13;
                    break;
                }
                case 213: {
                    n4 = 16;
                    break;
                }
                case 214: {
                    n4 = 83;
                    break;
                }
                case 215: {
                    n4 = 185;
                    break;
                }
                case 216: {
                    n4 = 95;
                    break;
                }
                case 217: {
                    n4 = 236;
                    break;
                }
                case 218: {
                    n4 = 32;
                    break;
                }
                case 219: {
                    n4 = 90;
                    break;
                }
                case 220: {
                    n4 = 55;
                    break;
                }
                case 221: {
                    n4 = 243;
                    break;
                }
                case 222: {
                    n4 = 49;
                    break;
                }
                case 223: {
                    n4 = 121;
                    break;
                }
                case 224: {
                    n4 = 248;
                    break;
                }
                case 225: {
                    n4 = 37;
                    break;
                }
                case 226: {
                    n4 = 186;
                    break;
                }
                case 227: {
                    n4 = 255;
                    break;
                }
                case 228: {
                    n4 = 87;
                    break;
                }
                case 229: {
                    n4 = 222;
                    break;
                }
                case 230: {
                    n4 = 42;
                    break;
                }
                case 231: {
                    n4 = 171;
                    break;
                }
                case 232: {
                    n4 = 24;
                    break;
                }
                case 233: {
                    n4 = 223;
                    break;
                }
                case 234: {
                    n4 = 251;
                    break;
                }
                case 235: {
                    n4 = 209;
                    break;
                }
                case 236: {
                    n4 = 225;
                    break;
                }
                case 237: {
                    n4 = 17;
                    break;
                }
                case 238: {
                    n4 = 246;
                    break;
                }
                case 239: {
                    n4 = 232;
                    break;
                }
                case 240: {
                    n4 = 44;
                    break;
                }
                case 241: {
                    n4 = 126;
                    break;
                }
                case 242: {
                    n4 = 233;
                    break;
                }
                case 243: {
                    n4 = 244;
                    break;
                }
                case 244: {
                    n4 = 33;
                    break;
                }
                case 245: {
                    n4 = 102;
                    break;
                }
                case 246: {
                    n4 = 69;
                    break;
                }
                case 247: {
                    n4 = 124;
                    break;
                }
                case 248: {
                    n4 = 68;
                    break;
                }
                case 249: {
                    n4 = 137;
                    break;
                }
                case 250: {
                    n4 = 94;
                    break;
                }
                case 251: {
                    n4 = 162;
                    break;
                }
                case 252: {
                    n4 = 43;
                    break;
                }
                case 253: {
                    n4 = 143;
                    break;
                }
                case 254: {
                    n4 = 231;
                    break;
                }
                default: {
                    n4 = 135;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            FileAlterationObserver.b[n3] = q.z(new String(g));
        }
        return FileAlterationObserver.b[n3];
    }
}
