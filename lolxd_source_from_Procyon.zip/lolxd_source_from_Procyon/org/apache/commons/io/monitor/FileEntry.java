// 
// Decompiled by Procyon v0.5.36
// 

package org.apache.commons.io.monitor;

import q.o.m.s.q;
import java.io.File;
import java.io.Serializable;

public class FileEntry implements Serializable
{
    private static final long serialVersionUID = -2505664948818681153L;
    static final FileEntry[] EMPTY_ENTRIES;
    private final FileEntry parent;
    private FileEntry[] children;
    private final File file;
    private String name;
    private boolean exists;
    private boolean directory;
    private long lastModified;
    private long length;
    private static String b;
    private static final String c;
    
    public FileEntry(final File file) {
        this(null, file);
    }
    
    public FileEntry(final FileEntry parent, final File file) {
        final String b = b();
        final String s = b;
        Label_0023: {
            try {
                if (s != null) {
                    return;
                }
                final File file2 = file;
                if (file2 == null) {
                    break Label_0023;
                }
                break Label_0023;
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            try {
                final File file2 = file;
                if (file2 == null) {
                    throw new IllegalArgumentException(FileEntry.c);
                }
            }
            catch (IllegalArgumentException ex2) {
                throw b(ex2);
            }
        }
        this.file = file;
        this.parent = parent;
        this.name = q.mh(file);
    }
    
    public boolean refresh(final File p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        org/apache/commons/io/monitor/FileEntry.exists:Z
        //     4: istore          4
        //     6: aload_0        
        //     7: getfield        org/apache/commons/io/monitor/FileEntry.lastModified:J
        //    10: lstore          5
        //    12: invokestatic    org/apache/commons/io/monitor/FileEntry.b:()Ljava/lang/String;
        //    15: aload_0        
        //    16: getfield        org/apache/commons/io/monitor/FileEntry.directory:Z
        //    19: istore          7
        //    21: aload_0        
        //    22: getfield        org/apache/commons/io/monitor/FileEntry.length:J
        //    25: lstore          8
        //    27: aload_0        
        //    28: aload_1        
        //    29: invokestatic    q/o/m/s/q.mh:(Ljava/io/File;)Ljava/lang/String;
        //    32: putfield        org/apache/commons/io/monitor/FileEntry.name:Ljava/lang/String;
        //    35: astore_2       
        //    36: aload_0        
        //    37: aload_1        
        //    38: invokestatic    q/o/m/s/q.kc:(Ljava/io/File;)Z
        //    41: putfield        org/apache/commons/io/monitor/FileEntry.exists:Z
        //    44: aload_0        
        //    45: aload_0        
        //    46: getfield        org/apache/commons/io/monitor/FileEntry.exists:Z
        //    49: aload_2        
        //    50: ifnonnull       85
        //    53: aload_2        
        //    54: ifnonnull       89
        //    57: goto            64
        //    60: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    63: athrow         
        //    64: ifeq            114
        //    67: goto            74
        //    70: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    73: athrow         
        //    74: aload_1        
        //    75: invokestatic    q/o/m/s/q.su:(Ljava/io/File;)Z
        //    78: goto            85
        //    81: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    84: athrow         
        //    85: aload_2        
        //    86: ifnonnull       111
        //    89: aload_2        
        //    90: ifnonnull       111
        //    93: goto            100
        //    96: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    99: athrow         
        //   100: ifeq            114
        //   103: goto            110
        //   106: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   109: athrow         
        //   110: iconst_1       
        //   111: goto            115
        //   114: iconst_0       
        //   115: putfield        org/apache/commons/io/monitor/FileEntry.directory:Z
        //   118: aload_0        
        //   119: aload_0        
        //   120: getfield        org/apache/commons/io/monitor/FileEntry.exists:Z
        //   123: ifeq            137
        //   126: aload_1        
        //   127: invokestatic    q/o/m/s/q.nj:(Ljava/io/File;)J
        //   130: goto            138
        //   133: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   136: athrow         
        //   137: lconst_0       
        //   138: putfield        org/apache/commons/io/monitor/FileEntry.lastModified:J
        //   141: aload_0        
        //   142: aload_0        
        //   143: getfield        org/apache/commons/io/monitor/FileEntry.exists:Z
        //   146: aload_2        
        //   147: ifnonnull       182
        //   150: aload_2        
        //   151: ifnonnull       182
        //   154: goto            161
        //   157: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   160: athrow         
        //   161: ifeq            196
        //   164: goto            171
        //   167: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   170: athrow         
        //   171: aload_0        
        //   172: getfield        org/apache/commons/io/monitor/FileEntry.directory:Z
        //   175: goto            182
        //   178: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   181: athrow         
        //   182: ifne            196
        //   185: aload_1        
        //   186: invokestatic    q/o/m/s/q.eb:(Ljava/io/File;)J
        //   189: goto            197
        //   192: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   195: athrow         
        //   196: lconst_0       
        //   197: putfield        org/apache/commons/io/monitor/FileEntry.length:J
        //   200: aload_0        
        //   201: getfield        org/apache/commons/io/monitor/FileEntry.exists:Z
        //   204: aload_2        
        //   205: ifnonnull       313
        //   208: iload           4
        //   210: if_icmpne       293
        //   213: goto            220
        //   216: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   219: athrow         
        //   220: aload_0        
        //   221: getfield        org/apache/commons/io/monitor/FileEntry.lastModified:J
        //   224: lload           5
        //   226: lcmp           
        //   227: goto            234
        //   230: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   233: athrow         
        //   234: aload_2        
        //   235: ifnonnull       313
        //   238: ifne            293
        //   241: aload_0        
        //   242: getfield        org/apache/commons/io/monitor/FileEntry.directory:Z
        //   245: goto            252
        //   248: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   251: athrow         
        //   252: aload_2        
        //   253: ifnonnull       313
        //   256: iload           7
        //   258: if_icmpne       293
        //   261: aload_0        
        //   262: getfield        org/apache/commons/io/monitor/FileEntry.length:J
        //   265: lload           8
        //   267: lcmp           
        //   268: goto            275
        //   271: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   274: athrow         
        //   275: aload_2        
        //   276: ifnonnull       313
        //   279: aload_2        
        //   280: ifnonnull       313
        //   283: ifeq            316
        //   286: goto            293
        //   289: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   292: athrow         
        //   293: iconst_1       
        //   294: aload_2        
        //   295: ifnonnull       234
        //   298: goto            305
        //   301: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   304: athrow         
        //   305: aload_2        
        //   306: ifnonnull       252
        //   309: aload_2        
        //   310: ifnonnull       275
        //   313: goto            317
        //   316: iconst_0       
        //   317: aload_2        
        //   318: ifnull          332
        //   321: invokestatic    com/sun/jna/Structure.b:()I
        //   324: istore_3       
        //   325: iinc            3, 1
        //   328: iload_3        
        //   329: invokestatic    com/sun/jna/Structure.b:(I)V
        //   332: ireturn        
        //    StackMapTable: 00 2A FF 00 3C 00 08 07 00 02 07 00 2A 07 00 2C 00 01 04 01 04 00 01 07 00 22 FF 00 03 00 08 07 00 02 07 00 2A 07 00 2C 00 01 04 01 04 00 02 07 00 02 01 45 07 00 22 43 07 00 02 46 07 00 22 FF 00 03 00 08 07 00 02 07 00 2A 07 00 2C 00 01 04 01 04 00 02 07 00 02 01 FF 00 03 00 08 07 00 02 07 00 2A 07 00 2C 00 01 04 01 04 00 02 07 00 02 01 46 07 00 22 FF 00 03 00 08 07 00 02 07 00 2A 07 00 2C 00 01 04 01 04 00 02 07 00 02 01 45 07 00 22 43 07 00 02 FF 00 00 00 08 07 00 02 07 00 2A 07 00 2C 00 01 04 01 04 00 02 07 00 02 01 42 07 00 02 FF 00 00 00 08 07 00 02 07 00 2A 07 00 2C 00 01 04 01 04 00 02 07 00 02 01 51 07 00 22 43 07 00 02 FF 00 00 00 08 07 00 02 07 00 2A 07 00 2C 00 01 04 01 04 00 02 07 00 02 04 52 07 00 22 FF 00 03 00 08 07 00 02 07 00 2A 07 00 2C 00 01 04 01 04 00 02 07 00 02 01 45 07 00 22 43 07 00 02 46 07 00 22 FF 00 03 00 08 07 00 02 07 00 2A 07 00 2C 00 01 04 01 04 00 02 07 00 02 01 49 07 00 22 43 07 00 02 FF 00 00 00 08 07 00 02 07 00 2A 07 00 2C 00 01 04 01 04 00 02 07 00 02 04 52 07 00 22 03 49 07 00 22 43 01 4D 07 00 22 43 01 52 07 00 22 43 01 4D 07 00 22 03 47 07 00 22 43 01 47 01 02 40 01 4E 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  36     57     60     64     Ljava/lang/IllegalArgumentException;
        //  53     67     70     74     Ljava/lang/IllegalArgumentException;
        //  64     78     81     85     Ljava/lang/IllegalArgumentException;
        //  85     93     96     100    Ljava/lang/IllegalArgumentException;
        //  89     103    106    110    Ljava/lang/IllegalArgumentException;
        //  115    133    133    137    Ljava/lang/IllegalArgumentException;
        //  138    154    157    161    Ljava/lang/IllegalArgumentException;
        //  150    164    167    171    Ljava/lang/IllegalArgumentException;
        //  161    175    178    182    Ljava/lang/IllegalArgumentException;
        //  182    192    192    196    Ljava/lang/IllegalArgumentException;
        //  197    213    216    220    Ljava/lang/IllegalArgumentException;
        //  208    227    230    234    Ljava/lang/IllegalArgumentException;
        //  238    245    248    252    Ljava/lang/IllegalArgumentException;
        //  256    268    271    275    Ljava/lang/IllegalArgumentException;
        //  279    286    289    293    Ljava/lang/IllegalArgumentException;
        //  283    298    301    305    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0064:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public FileEntry newChildInstance(final File file) {
        return new FileEntry(this, file);
    }
    
    public FileEntry getParent() {
        return this.parent;
    }
    
    public int getLevel() {
        final String b = b();
        FileEntry parent = null;
        Label_0030: {
            Label_0026: {
                try {
                    parent = this.parent;
                    if (b != null) {
                        break Label_0030;
                    }
                    if (parent != null) {
                        break Label_0026;
                    }
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                return;
            }
            final FileEntry parent2 = this.parent;
        }
        final int level = parent.getLevel();
        if (b != null) {
            return level;
        }
        return level;
    }
    
    public FileEntry[] getChildren() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: aload_0        
        //     5: getfield        org/apache/commons/io/monitor/FileEntry.children:[Lorg/apache/commons/io/monitor/FileEntry;
        //     8: aload_1        
        //     9: ifnonnull       44
        //    12: aload_1        
        //    13: ifnonnull       44
        //    16: goto            23
        //    19: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    22: athrow         
        //    23: ifnull          47
        //    26: goto            33
        //    29: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    32: athrow         
        //    33: aload_0        
        //    34: getfield        org/apache/commons/io/monitor/FileEntry.children:[Lorg/apache/commons/io/monitor/FileEntry;
        //    37: goto            44
        //    40: invokestatic    org/apache/commons/io/monitor/FileEntry.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    43: athrow         
        //    44: goto            50
        //    47: getstatic       org/apache/commons/io/monitor/FileEntry.EMPTY_ENTRIES:[Lorg/apache/commons/io/monitor/FileEntry;
        //    50: areturn        
        //    StackMapTable: 00 08 53 07 00 22 43 07 00 6B 45 07 00 22 03 46 07 00 22 43 07 00 6B 02 42 07 00 6B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  4      16     19     23     Ljava/lang/IllegalArgumentException;
        //  12     26     29     33     Ljava/lang/IllegalArgumentException;
        //  23     37     40     44     Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0023:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void setChildren(final FileEntry[] children) {
        this.children = children;
    }
    
    public File getFile() {
        return this.file;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public long getLastModified() {
        return this.lastModified;
    }
    
    public void setLastModified(final long lastModified) {
        this.lastModified = lastModified;
    }
    
    public long getLength() {
        return this.length;
    }
    
    public void setLength(final long length) {
        this.length = length;
    }
    
    public boolean isExists() {
        return this.exists;
    }
    
    public void setExists(final boolean exists) {
        this.exists = exists;
    }
    
    public boolean isDirectory() {
        return this.directory;
    }
    
    public void setDirectory(final boolean directory) {
        this.directory = directory;
    }
    
    static {
        b((String)null);
        int n3;
        int n2;
        final int n = n2 = (n3 = 77);
        final char[] g = q.g(n.d.a.d.q.tq());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0132: {
                if (length > 1) {
                    break Label_0132;
                }
                n3 = (n2 = n4);
                do {
                    final char c2 = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 96;
                            break;
                        }
                        case 1: {
                            n5 = 23;
                            break;
                        }
                        case 2: {
                            n5 = 95;
                            break;
                        }
                        case 3: {
                            n5 = 54;
                            break;
                        }
                        case 4: {
                            n5 = 9;
                            break;
                        }
                        case 5: {
                            n5 = 34;
                            break;
                        }
                        default: {
                            n5 = 91;
                            break;
                        }
                    }
                    g[n3] = (char)(c2 ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                c = q.z(new String(g));
                EMPTY_ENTRIES = new FileEntry[0];
                return;
            }
            continue;
        }
    }
    
    public static void b(final String b) {
        FileEntry.b = b;
    }
    
    public static String b() {
        return FileEntry.b;
    }
    
    private static IllegalArgumentException b(final IllegalArgumentException ex) {
        return ex;
    }
}
