// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook;

import org.jnativehook.mouse.NativeMouseWheelListener;
import org.jnativehook.mouse.NativeMouseMotionListener;
import org.jnativehook.mouse.NativeMouseListener;
import org.jnativehook.keyboard.NativeKeyListener;
import javax.swing.event.EventListenerList;
import java.util.concurrent.ExecutorService;
import java.util.logging.Logger;

public class GlobalScreen
{
    protected static Logger log;
    protected static GlobalScreen$NativeHookThread hookThread;
    protected static ExecutorService eventExecutor;
    protected static EventListenerList eventListeners;
    
    protected GlobalScreen() {
    }
    
    public static void addNativeKeyListener(final NativeKeyListener l) {
        try {
            if (l != null) {
                GlobalScreen.eventListeners.add(NativeKeyListener.class, l);
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
    }
    
    public static void removeNativeKeyListener(final NativeKeyListener l) {
        try {
            if (l != null) {
                GlobalScreen.eventListeners.remove(NativeKeyListener.class, l);
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
    }
    
    public static void addNativeMouseListener(final NativeMouseListener l) {
        try {
            if (l != null) {
                GlobalScreen.eventListeners.add(NativeMouseListener.class, l);
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
    }
    
    public static void removeNativeMouseListener(final NativeMouseListener l) {
        try {
            if (l != null) {
                GlobalScreen.eventListeners.remove(NativeMouseListener.class, l);
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
    }
    
    public static void addNativeMouseMotionListener(final NativeMouseMotionListener l) {
        try {
            if (l != null) {
                GlobalScreen.eventListeners.add(NativeMouseMotionListener.class, l);
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
    }
    
    public static void removeNativeMouseMotionListener(final NativeMouseMotionListener l) {
        try {
            if (l != null) {
                GlobalScreen.eventListeners.remove(NativeMouseMotionListener.class, l);
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
    }
    
    public static void addNativeMouseWheelListener(final NativeMouseWheelListener l) {
        try {
            if (l != null) {
                GlobalScreen.eventListeners.add(NativeMouseWheelListener.class, l);
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
    }
    
    public static void removeNativeMouseWheelListener(final NativeMouseWheelListener l) {
        try {
            if (l != null) {
                GlobalScreen.eventListeners.remove(NativeMouseWheelListener.class, l);
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
    }
    
    public static native NativeMonitorInfo[] getNativeMonitors();
    
    public static native Integer getAutoRepeatRate();
    
    public static native Integer getAutoRepeatDelay();
    
    public static native Integer getPointerAccelerationMultiplier();
    
    public static native Integer getPointerAccelerationThreshold();
    
    public static native Integer getPointerSensitivity();
    
    public static native Integer getMultiClickIterval();
    
    public static void registerNativeHook() throws NativeHookException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_0       
        //     4: getstatic       org/jnativehook/GlobalScreen.hookThread:Lorg/jnativehook/GlobalScreen$NativeHookThread;
        //     7: aload_0        
        //     8: ifnull          65
        //    11: ifnull          45
        //    14: goto            21
        //    17: invokestatic    org/jnativehook/GlobalScreen.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    20: athrow         
        //    21: getstatic       org/jnativehook/GlobalScreen.hookThread:Lorg/jnativehook/GlobalScreen$NativeHookThread;
        //    24: aload_0        
        //    25: ifnull          65
        //    28: aload_0        
        //    29: ifnull          65
        //    32: invokevirtual   org/jnativehook/GlobalScreen$NativeHookThread.isAlive:()Z
        //    35: ifne            142
        //    38: goto            45
        //    41: invokestatic    org/jnativehook/GlobalScreen.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    44: athrow         
        //    45: new             Lorg/jnativehook/GlobalScreen$NativeHookThread;
        //    48: dup            
        //    49: invokespecial   org/jnativehook/GlobalScreen$NativeHookThread.<init>:()V
        //    52: putstatic       org/jnativehook/GlobalScreen.hookThread:Lorg/jnativehook/GlobalScreen$NativeHookThread;
        //    55: getstatic       org/jnativehook/GlobalScreen.hookThread:Lorg/jnativehook/GlobalScreen$NativeHookThread;
        //    58: goto            65
        //    61: invokestatic    org/jnativehook/GlobalScreen.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //    64: athrow         
        //    65: dup            
        //    66: astore_1       
        //    67: monitorenter   
        //    68: getstatic       org/jnativehook/GlobalScreen.hookThread:Lorg/jnativehook/GlobalScreen$NativeHookThread;
        //    71: invokevirtual   org/jnativehook/GlobalScreen$NativeHookThread.start:()V
        //    74: getstatic       org/jnativehook/GlobalScreen.hookThread:Lorg/jnativehook/GlobalScreen$NativeHookThread;
        //    77: aload_0        
        //    78: ifnull          24
        //    81: invokevirtual   java/lang/Object.wait:()V
        //    84: goto            97
        //    87: astore_2       
        //    88: new             Lorg/jnativehook/NativeHookException;
        //    91: dup            
        //    92: aload_2        
        //    93: invokespecial   org/jnativehook/NativeHookException.<init>:(Ljava/lang/Throwable;)V
        //    96: athrow         
        //    97: getstatic       org/jnativehook/GlobalScreen.hookThread:Lorg/jnativehook/GlobalScreen$NativeHookThread;
        //   100: invokevirtual   org/jnativehook/GlobalScreen$NativeHookThread.getException:()Lorg/jnativehook/NativeHookException;
        //   103: astore_2       
        //   104: aload_0        
        //   105: ifnull          134
        //   108: aload_2        
        //   109: aload_0        
        //   110: ifnull          131
        //   113: goto            120
        //   116: invokestatic    org/jnativehook/GlobalScreen.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   119: athrow         
        //   120: ifnull          132
        //   123: goto            130
        //   126: invokestatic    org/jnativehook/GlobalScreen.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   129: athrow         
        //   130: aload_2        
        //   131: athrow         
        //   132: aload_1        
        //   133: monitorexit    
        //   134: goto            142
        //   137: astore_3       
        //   138: aload_1        
        //   139: monitorexit    
        //   140: aload_3        
        //   141: athrow         
        //   142: return         
        //    Exceptions:
        //  throws org.jnativehook.NativeHookException
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  32     58     61     65     Ljava/lang/InterruptedException;
        //  28     38     41     45     Ljava/lang/InterruptedException;
        //  4      14     17     21     Ljava/lang/InterruptedException;
        //  74     84     87     97     Ljava/lang/InterruptedException;
        //  108    123    126    130    Ljava/lang/InterruptedException;
        //  104    113    116    120    Ljava/lang/InterruptedException;
        //  68     134    137    142    Any
        //  137    140    137    142    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0024 (coming from #0141).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void unregisterNativeHook() throws NativeHookException {
        if (isNativeHookRegistered()) {
            synchronized (GlobalScreen.hookThread) {
                GlobalScreen.hookThread.disable();
                try {
                    GlobalScreen.hookThread.join();
                }
                catch (InterruptedException ex) {
                    throw new NativeHookException(ex.getCause());
                }
            }
        }
    }
    
    public static boolean isNativeHookRegistered() {
        final int[] b = NativeInputEvent.b();
        boolean alive = false;
        Label_0067: {
            Label_0053: {
                Label_0035: {
                    GlobalScreen$NativeHookThread hookThread = null;
                    Label_0022: {
                        try {
                            hookThread = GlobalScreen.hookThread;
                            if (b == null) {
                                break Label_0035;
                            }
                            final int[] array = b;
                            if (array != null) {
                                break Label_0022;
                            }
                            break Label_0035;
                        }
                        catch (RuntimeException ex) {
                            throw b(ex);
                        }
                        try {
                            final int[] array = b;
                            if (array == null) {
                                break Label_0035;
                            }
                            if (hookThread == null) {
                                break Label_0067;
                            }
                        }
                        catch (RuntimeException ex2) {
                            throw b(ex2);
                        }
                    }
                    final GlobalScreen$NativeHookThread hookThread2 = GlobalScreen.hookThread;
                    try {
                        alive = hookThread.isAlive();
                        if (b == null) {
                            return alive;
                        }
                        final int[] array2 = b;
                        if (array2 != null) {
                            break Label_0053;
                        }
                        return alive;
                    }
                    catch (RuntimeException ex3) {
                        throw b(ex3);
                    }
                }
                try {
                    final int[] array2 = b;
                    if (array2 == null) {
                        return alive;
                    }
                    if (!alive) {
                        break Label_0067;
                    }
                }
                catch (RuntimeException ex4) {
                    throw b(ex4);
                }
            }
            return alive;
        }
        return alive;
    }
    
    public static native void postNativeEvent(final NativeInputEvent p0);
    
    public static void setEventDispatcher(final ExecutorService executorService) {
        final int[] b = NativeInputEvent.b();
        ExecutorService eventExecutor = null;
        Label_0034: {
            while (true) {
                Label_0029: {
                    try {
                        eventExecutor = GlobalScreen.eventExecutor;
                        if (b == null) {
                            break Label_0034;
                        }
                        if (eventExecutor == null) {
                            break Label_0029;
                        }
                    }
                    catch (RuntimeException ex) {
                        throw b(ex);
                    }
                    final ExecutorService eventExecutor2 = GlobalScreen.eventExecutor;
                    eventExecutor2.shutdown();
                }
                final ExecutorService eventExecutor2 = executorService;
                if (b == null) {
                    continue;
                }
                break;
            }
        }
        GlobalScreen.eventExecutor = eventExecutor;
    }
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     2: anewarray       Ljava/lang/String;
        //     5: astore          6
        //     7: iconst_0       
        //     8: istore          4
        //    10: ldc             "hm[tL!ujlUk\u000b'\u007fkmNeWyqa`_l@%qvjUn\u000b:enwSpI>up\u0014hm[tL!ujlUk\u000b;y`-TaH2\u001chm[tL!ujlUk\u000b<u{-HeU2qv-^eI6i*hm[tL!ujlUk\u000b'\u007fkmNeWyqa`_l@%qvjUn\u000b#xpfIhJ;t\u0017hm[tL!ujlUk\u000b;y`-VoF6dmq\u001bhm[tL!ujlUk\u000b<u{-HeU2qv-HaQ2%hm[tL!ujlUk\u000b5evwUn\u000b:enwScI>si-St@%fco\u001fhm[tL!ujlUk\u000b'\u007fkmNeWycgmIiQ>fkwC"
        //    12: dup            
        //    13: astore_3       
        //    14: invokevirtual   java/lang/String.length:()I
        //    17: istore          5
        //    19: bipush          43
        //    21: istore_2       
        //    22: iconst_m1      
        //    23: istore_1       
        //    24: bipush          68
        //    26: iinc            1, 1
        //    29: aload_3        
        //    30: iload_1        
        //    31: dup            
        //    32: iload_2        
        //    33: iadd           
        //    34: invokevirtual   java/lang/String.substring:(II)Ljava/lang/String;
        //    37: jsr             134
        //    40: aload           6
        //    42: swap           
        //    43: iload           4
        //    45: iinc            4, 1
        //    48: swap           
        //    49: aastore        
        //    50: iload_1        
        //    51: iload_2        
        //    52: iadd           
        //    53: dup            
        //    54: istore_1       
        //    55: iload           5
        //    57: if_icmpge       69
        //    60: aload_3        
        //    61: iload_1        
        //    62: invokevirtual   java/lang/String.charAt:(I)C
        //    65: istore_2       
        //    66: goto            24
        //    69: ldc             "\u001f\u0003/\\=K\u0003\u0004\u0018>\u0017?J\r\u001b_\f\u00171D\u0017\u001c\u0005\u0004\u001b5W\u0003\u0002\b\u0004\u001d4D\u0016\u001f\u0003\u000b:?)\u0006>S\u00078\u001e'\u0019"
        //    71: dup            
        //    72: astore_3       
        //    73: invokevirtual   java/lang/String.length:()I
        //    76: istore          5
        //    78: bipush          37
        //    80: istore_2       
        //    81: iconst_m1      
        //    82: istore_1       
        //    83: bipush          54
        //    85: iinc            1, 1
        //    88: aload_3        
        //    89: iload_1        
        //    90: dup            
        //    91: iload_2        
        //    92: iadd           
        //    93: invokevirtual   java/lang/String.substring:(II)Ljava/lang/String;
        //    96: jsr             134
        //    99: aload           6
        //   101: swap           
        //   102: iload           4
        //   104: iinc            4, 1
        //   107: swap           
        //   108: aastore        
        //   109: iload_1        
        //   110: iload_2        
        //   111: iadd           
        //   112: dup            
        //   113: istore_1       
        //   114: iload           5
        //   116: if_icmpge       128
        //   119: aload_3        
        //   120: iload_1        
        //   121: invokevirtual   java/lang/String.charAt:(I)C
        //   124: istore_2       
        //   125: goto            83
        //   128: aload           6
        //   130: astore_0       
        //   131: goto            276
        //   134: astore          7
        //   136: invokevirtual   java/lang/String.toCharArray:()[C
        //   139: dup_x1         
        //   140: arraylength    
        //   141: dup_x2         
        //   142: pop            
        //   143: iconst_0       
        //   144: istore          8
        //   146: dup2_x1        
        //   147: pop2           
        //   148: dup_x2         
        //   149: iconst_1       
        //   150: if_icmpgt       252
        //   153: dup2           
        //   154: swap           
        //   155: iload           8
        //   157: dup2_x1        
        //   158: caload         
        //   159: swap           
        //   160: iload           8
        //   162: bipush          7
        //   164: irem           
        //   165: tableswitch {
        //                0: 204
        //                1: 209
        //                2: 214
        //                3: 219
        //                4: 224
        //                5: 229
        //          default: 234
        //        }
        //   204: bipush          70
        //   206: goto            236
        //   209: bipush          71
        //   211: goto            236
        //   214: bipush          126
        //   216: goto            236
        //   219: bipush          68
        //   221: goto            236
        //   224: bipush          97
        //   226: goto            236
        //   229: bipush          19
        //   231: goto            236
        //   234: bipush          84
        //   236: ixor           
        //   237: ixor           
        //   238: i2c            
        //   239: castore        
        //   240: iinc            8, 1
        //   243: dup            
        //   244: ifne            252
        //   247: dup2           
        //   248: dup_x1         
        //   249: goto            157
        //   252: dup2_x1        
        //   253: pop2           
        //   254: dup_x2         
        //   255: iload           8
        //   257: if_icmpgt       153
        //   260: pop            
        //   261: new             Ljava/lang/String;
        //   264: dup_x1         
        //   265: swap           
        //   266: invokespecial   java/lang/String.<init>:([C)V
        //   269: invokevirtual   java/lang/String.intern:()Ljava/lang/String;
        //   272: swap           
        //   273: pop            
        //   274: ret             7
        //   276: ldc             Lorg/jnativehook/GlobalScreen;.class
        //   278: invokevirtual   java/lang/Class.getPackage:()Ljava/lang/Package;
        //   281: invokevirtual   java/lang/Package.getName:()Ljava/lang/String;
        //   284: invokestatic    java/util/logging/Logger.getLogger:(Ljava/lang/String;)Ljava/util/logging/Logger;
        //   287: putstatic       org/jnativehook/GlobalScreen.log:Ljava/util/logging/Logger;
        //   290: new             Lorg/jnativehook/dispatcher/DefaultDispatchService;
        //   293: dup            
        //   294: invokespecial   org/jnativehook/dispatcher/DefaultDispatchService.<init>:()V
        //   297: putstatic       org/jnativehook/GlobalScreen.eventExecutor:Ljava/util/concurrent/ExecutorService;
        //   300: new             Ljavax/swing/event/EventListenerList;
        //   303: dup            
        //   304: invokespecial   javax/swing/event/EventListenerList.<init>:()V
        //   307: putstatic       org/jnativehook/GlobalScreen.eventListeners:Ljavax/swing/event/EventListenerList;
        //   310: aload_0        
        //   311: iconst_1       
        //   312: aaload         
        //   313: aload_0        
        //   314: bipush          9
        //   316: aaload         
        //   317: invokestatic    java/lang/System.getProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   320: astore          9
        //   322: aload           9
        //   324: invokestatic    java/lang/System.loadLibrary:(Ljava/lang/String;)V
        //   327: goto            478
        //   330: astore          10
        //   332: aload_0        
        //   333: iconst_4       
        //   334: aaload         
        //   335: aload_0        
        //   336: bipush          8
        //   338: aaload         
        //   339: invokestatic    java/lang/System.getProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   342: astore          11
        //   344: aload           11
        //   346: invokestatic    java/lang/Class.forName:(Ljava/lang/String;)Ljava/lang/Class;
        //   349: ldc             Lorg/jnativehook/NativeLibraryLocator;.class
        //   351: invokevirtual   java/lang/Class.asSubclass:(Ljava/lang/Class;)Ljava/lang/Class;
        //   354: invokevirtual   java/lang/Class.newInstance:()Ljava/lang/Object;
        //   357: checkcast       Lorg/jnativehook/NativeLibraryLocator;
        //   360: astore          12
        //   362: aload           12
        //   364: invokeinterface org/jnativehook/NativeLibraryLocator.getLibraries:()Ljava/util/Iterator;
        //   369: astore          13
        //   371: aload           13
        //   373: invokeinterface java/util/Iterator.hasNext:()Z
        //   378: ifeq            449
        //   381: aload           13
        //   383: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   388: checkcast       Ljava/io/File;
        //   391: astore          14
        //   393: aload           14
        //   395: invokevirtual   java/io/File.exists:()Z
        //   398: ifeq            446
        //   401: aload           14
        //   403: invokevirtual   java/io/File.isFile:()Z
        //   406: ifeq            446
        //   409: goto            416
        //   412: invokestatic    org/jnativehook/GlobalScreen.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   415: athrow         
        //   416: aload           14
        //   418: invokevirtual   java/io/File.canRead:()Z
        //   421: ifeq            446
        //   424: goto            431
        //   427: invokestatic    org/jnativehook/GlobalScreen.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   430: athrow         
        //   431: aload           14
        //   433: invokevirtual   java/io/File.getPath:()Ljava/lang/String;
        //   436: invokestatic    java/lang/System.load:(Ljava/lang/String;)V
        //   439: goto            446
        //   442: invokestatic    org/jnativehook/GlobalScreen.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   445: athrow         
        //   446: goto            371
        //   449: goto            478
        //   452: astore          12
        //   454: getstatic       org/jnativehook/GlobalScreen.log:Ljava/util/logging/Logger;
        //   457: aload           12
        //   459: invokevirtual   java/lang/Exception.getMessage:()Ljava/lang/String;
        //   462: invokevirtual   java/util/logging/Logger.severe:(Ljava/lang/String;)V
        //   465: new             Ljava/lang/UnsatisfiedLinkError;
        //   468: dup            
        //   469: aload           12
        //   471: invokevirtual   java/lang/Exception.getMessage:()Ljava/lang/String;
        //   474: invokespecial   java/lang/UnsatisfiedLinkError.<init>:(Ljava/lang/String;)V
        //   477: athrow         
        //   478: invokestatic    org/jnativehook/GlobalScreen.getAutoRepeatRate:()Ljava/lang/Integer;
        //   481: astore          10
        //   483: aload           10
        //   485: ifnull          507
        //   488: aload_0        
        //   489: iconst_5       
        //   490: aaload         
        //   491: aload           10
        //   493: invokevirtual   java/lang/Integer.toString:()Ljava/lang/String;
        //   496: invokestatic    java/lang/System.setProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   499: pop            
        //   500: goto            507
        //   503: invokestatic    org/jnativehook/GlobalScreen.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   506: athrow         
        //   507: invokestatic    org/jnativehook/GlobalScreen.getAutoRepeatDelay:()Ljava/lang/Integer;
        //   510: astore          11
        //   512: aload           11
        //   514: ifnull          536
        //   517: aload_0        
        //   518: iconst_2       
        //   519: aaload         
        //   520: aload           11
        //   522: invokevirtual   java/lang/Integer.toString:()Ljava/lang/String;
        //   525: invokestatic    java/lang/System.setProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   528: pop            
        //   529: goto            536
        //   532: invokestatic    org/jnativehook/GlobalScreen.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   535: athrow         
        //   536: invokestatic    org/jnativehook/GlobalScreen.getMultiClickIterval:()Ljava/lang/Integer;
        //   539: astore          12
        //   541: aload           12
        //   543: ifnull          566
        //   546: aload_0        
        //   547: bipush          6
        //   549: aaload         
        //   550: aload           12
        //   552: invokevirtual   java/lang/Integer.toString:()Ljava/lang/String;
        //   555: invokestatic    java/lang/System.setProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   558: pop            
        //   559: goto            566
        //   562: invokestatic    org/jnativehook/GlobalScreen.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   565: athrow         
        //   566: invokestatic    org/jnativehook/GlobalScreen.getPointerSensitivity:()Ljava/lang/Integer;
        //   569: astore          13
        //   571: aload           13
        //   573: ifnull          596
        //   576: aload_0        
        //   577: bipush          7
        //   579: aaload         
        //   580: aload           13
        //   582: invokevirtual   java/lang/Integer.toString:()Ljava/lang/String;
        //   585: invokestatic    java/lang/System.setProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   588: pop            
        //   589: goto            596
        //   592: invokestatic    org/jnativehook/GlobalScreen.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   595: athrow         
        //   596: invokestatic    org/jnativehook/GlobalScreen.getPointerAccelerationMultiplier:()Ljava/lang/Integer;
        //   599: astore          14
        //   601: aload           14
        //   603: ifnull          625
        //   606: aload_0        
        //   607: iconst_0       
        //   608: aaload         
        //   609: aload           14
        //   611: invokevirtual   java/lang/Integer.toString:()Ljava/lang/String;
        //   614: invokestatic    java/lang/System.setProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   617: pop            
        //   618: goto            625
        //   621: invokestatic    org/jnativehook/GlobalScreen.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   624: athrow         
        //   625: invokestatic    org/jnativehook/GlobalScreen.getPointerAccelerationThreshold:()Ljava/lang/Integer;
        //   628: astore          15
        //   630: aload           15
        //   632: ifnull          654
        //   635: aload_0        
        //   636: iconst_3       
        //   637: aaload         
        //   638: aload           15
        //   640: invokevirtual   java/lang/Integer.toString:()Ljava/lang/String;
        //   643: invokestatic    java/lang/System.setProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   646: pop            
        //   647: goto            654
        //   650: invokestatic    org/jnativehook/GlobalScreen.b:(Ljava/lang/Throwable;)Ljava/lang/Throwable;
        //   653: athrow         
        //   654: return         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  322    327    330    478    Ljava/lang/UnsatisfiedLinkError;
        //  416    439    442    446    Ljava/lang/UnsatisfiedLinkError;
        //  401    424    427    431    Ljava/lang/UnsatisfiedLinkError;
        //  393    409    412    416    Ljava/lang/UnsatisfiedLinkError;
        //  344    449    452    478    Ljava/lang/Exception;
        //  483    500    503    507    Ljava/lang/UnsatisfiedLinkError;
        //  512    529    532    536    Ljava/lang/UnsatisfiedLinkError;
        //  541    559    562    566    Ljava/lang/UnsatisfiedLinkError;
        //  571    589    592    596    Ljava/lang/UnsatisfiedLinkError;
        //  601    618    621    625    Ljava/lang/UnsatisfiedLinkError;
        //  630    647    650    654    Ljava/lang/UnsatisfiedLinkError;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0688:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static Throwable b(final Throwable t) {
        return t;
    }
}
