// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook;

import org.jnativehook.mouse.NativeMouseWheelListener;
import org.jnativehook.mouse.NativeMouseWheelEvent;
import org.jnativehook.mouse.NativeMouseMotionListener;
import org.jnativehook.mouse.NativeMouseListener;
import org.jnativehook.mouse.NativeMouseEvent;
import org.jnativehook.keyboard.NativeKeyListener;
import org.jnativehook.keyboard.NativeKeyEvent;

class GlobalScreen$EventDispatchTask implements Runnable
{
    private NativeInputEvent event;
    
    public GlobalScreen$EventDispatchTask(final NativeInputEvent event) {
        this.event = event;
    }
    
    public void run() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: aload_0        
        //     5: getfield        org/jnativehook/GlobalScreen$EventDispatchTask.event:Lorg/jnativehook/NativeInputEvent;
        //     8: instanceof      Lorg/jnativehook/keyboard/NativeKeyEvent;
        //    11: aload_1        
        //    12: ifnull          51
        //    15: ifeq            40
        //    18: goto            25
        //    21: invokestatic    org/jnativehook/GlobalScreen$EventDispatchTask.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    24: athrow         
        //    25: aload_0        
        //    26: aload_0        
        //    27: getfield        org/jnativehook/GlobalScreen$EventDispatchTask.event:Lorg/jnativehook/NativeInputEvent;
        //    30: checkcast       Lorg/jnativehook/keyboard/NativeKeyEvent;
        //    33: invokespecial   org/jnativehook/GlobalScreen$EventDispatchTask.processKeyEvent:(Lorg/jnativehook/keyboard/NativeKeyEvent;)V
        //    36: aload_1        
        //    37: ifnonnull       267
        //    40: aload_0        
        //    41: aload_1        
        //    42: ifnull          26
        //    45: getfield        org/jnativehook/GlobalScreen$EventDispatchTask.event:Lorg/jnativehook/NativeInputEvent;
        //    48: instanceof      Lorg/jnativehook/mouse/NativeMouseWheelEvent;
        //    51: aload_1        
        //    52: ifnull          91
        //    55: ifeq            80
        //    58: goto            65
        //    61: invokestatic    org/jnativehook/GlobalScreen$EventDispatchTask.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    64: athrow         
        //    65: aload_0        
        //    66: aload_0        
        //    67: getfield        org/jnativehook/GlobalScreen$EventDispatchTask.event:Lorg/jnativehook/NativeInputEvent;
        //    70: checkcast       Lorg/jnativehook/mouse/NativeMouseWheelEvent;
        //    73: invokespecial   org/jnativehook/GlobalScreen$EventDispatchTask.processMouseWheelEvent:(Lorg/jnativehook/mouse/NativeMouseWheelEvent;)V
        //    76: aload_1        
        //    77: ifnonnull       267
        //    80: aload_0        
        //    81: aload_1        
        //    82: ifnull          66
        //    85: getfield        org/jnativehook/GlobalScreen$EventDispatchTask.event:Lorg/jnativehook/NativeInputEvent;
        //    88: instanceof      Lorg/jnativehook/mouse/NativeMouseEvent;
        //    91: aload_1        
        //    92: ifnull          253
        //    95: ifeq            213
        //    98: goto            105
        //   101: invokestatic    org/jnativehook/GlobalScreen$EventDispatchTask.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   104: athrow         
        //   105: aload_0        
        //   106: aload_1        
        //   107: ifnull          177
        //   110: goto            117
        //   113: invokestatic    org/jnativehook/GlobalScreen$EventDispatchTask.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   116: athrow         
        //   117: aload_1        
        //   118: ifnull          177
        //   121: goto            128
        //   124: invokestatic    org/jnativehook/GlobalScreen$EventDispatchTask.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   127: athrow         
        //   128: getfield        org/jnativehook/GlobalScreen$EventDispatchTask.event:Lorg/jnativehook/NativeInputEvent;
        //   131: invokevirtual   org/jnativehook/NativeInputEvent.getID:()I
        //   134: goto            141
        //   137: invokestatic    org/jnativehook/GlobalScreen$EventDispatchTask.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   140: athrow         
        //   141: tableswitch {
        //             5000: 176
        //             5001: 176
        //             5002: 176
        //             5003: 191
        //             5004: 191
        //          default: 209
        //        }
        //   176: aload_0        
        //   177: aload_0        
        //   178: getfield        org/jnativehook/GlobalScreen$EventDispatchTask.event:Lorg/jnativehook/NativeInputEvent;
        //   181: checkcast       Lorg/jnativehook/mouse/NativeMouseEvent;
        //   184: invokespecial   org/jnativehook/GlobalScreen$EventDispatchTask.processButtonEvent:(Lorg/jnativehook/mouse/NativeMouseEvent;)V
        //   187: aload_1        
        //   188: ifnonnull       209
        //   191: aload_0        
        //   192: aload_0        
        //   193: getfield        org/jnativehook/GlobalScreen$EventDispatchTask.event:Lorg/jnativehook/NativeInputEvent;
        //   196: checkcast       Lorg/jnativehook/mouse/NativeMouseEvent;
        //   199: invokespecial   org/jnativehook/GlobalScreen$EventDispatchTask.processMouseEvent:(Lorg/jnativehook/mouse/NativeMouseEvent;)V
        //   202: goto            209
        //   205: invokestatic    org/jnativehook/GlobalScreen$EventDispatchTask.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   208: athrow         
        //   209: aload_1        
        //   210: ifnonnull       267
        //   213: aload_0        
        //   214: aload_1        
        //   215: ifnull          257
        //   218: goto            225
        //   221: invokestatic    org/jnativehook/GlobalScreen$EventDispatchTask.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   224: athrow         
        //   225: aload_1        
        //   226: ifnull          257
        //   229: goto            236
        //   232: invokestatic    org/jnativehook/GlobalScreen$EventDispatchTask.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   235: athrow         
        //   236: getfield        org/jnativehook/GlobalScreen$EventDispatchTask.event:Lorg/jnativehook/NativeInputEvent;
        //   239: instanceof      Lorg/jnativehook/mouse/NativeMouseWheelEvent;
        //   242: aload_1        
        //   243: ifnull          141
        //   246: goto            253
        //   249: invokestatic    org/jnativehook/GlobalScreen$EventDispatchTask.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   252: athrow         
        //   253: ifeq            267
        //   256: aload_0        
        //   257: aload_0        
        //   258: getfield        org/jnativehook/GlobalScreen$EventDispatchTask.event:Lorg/jnativehook/NativeInputEvent;
        //   261: checkcast       Lorg/jnativehook/mouse/NativeMouseWheelEvent;
        //   264: invokespecial   org/jnativehook/GlobalScreen$EventDispatchTask.processMouseWheelEvent:(Lorg/jnativehook/mouse/NativeMouseWheelEvent;)V
        //   267: return         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      18     21     25     Ljava/lang/RuntimeException;
        //  51     58     61     65     Ljava/lang/RuntimeException;
        //  91     98     101    105    Ljava/lang/RuntimeException;
        //  95     110    113    117    Ljava/lang/RuntimeException;
        //  105    121    124    128    Ljava/lang/RuntimeException;
        //  117    134    137    141    Ljava/lang/RuntimeException;
        //  177    202    205    209    Ljava/lang/RuntimeException;
        //  209    218    221    225    Ljava/lang/RuntimeException;
        //  213    229    232    236    Ljava/lang/RuntimeException;
        //  225    246    249    253    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0105:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void processKeyEvent(final NativeKeyEvent nativeKeyEvent) {
        final NativeKeyListener[] array = GlobalScreen.eventListeners.getListeners(NativeKeyListener.class);
        final int[] b = NativeInputEvent.b();
        int i = 0;
        final int[] array2 = b;
        while (i < array.length) {
            while (true) {
                Label_0091: {
                    try {
                        switch (nativeKeyEvent.getID()) {
                            case 2401: {
                                array[i].nativeKeyPressed(nativeKeyEvent);
                                break;
                            }
                            case 2400: {
                                break Label_0091;
                            }
                            case 2402: {
                                break Label_0091;
                                break Label_0091;
                            }
                            default: {
                                break Label_0091;
                            }
                        }
                    }
                    catch (RuntimeException ex) {
                        throw b(ex);
                    }
                    if (array2 != null) {
                        break Label_0091;
                    }
                    try {
                        array[i].nativeKeyTyped(nativeKeyEvent);
                        if (array2 == null) {
                            array[i].nativeKeyReleased(nativeKeyEvent);
                        }
                    }
                    catch (RuntimeException ex2) {
                        throw b(ex2);
                    }
                }
                ++i;
                if (array2 == null) {
                    continue;
                }
                break;
            }
            if (array2 == null) {
                break;
            }
        }
    }
    
    private void processButtonEvent(final NativeMouseEvent nativeMouseEvent) {
        final NativeMouseListener[] array = GlobalScreen.eventListeners.getListeners(NativeMouseListener.class);
        final int[] b = NativeInputEvent.b();
        int i = 0;
        final int[] array2 = b;
        while (i < array.length) {
            while (true) {
                Label_0091: {
                    try {
                        switch (nativeMouseEvent.getID()) {
                            case 2500: {
                                array[i].nativeMouseClicked(nativeMouseEvent);
                                break;
                            }
                            case 2501: {
                                break Label_0091;
                            }
                            case 2502: {
                                break Label_0091;
                                break Label_0091;
                            }
                            default: {
                                break Label_0091;
                            }
                        }
                    }
                    catch (RuntimeException ex) {
                        throw b(ex);
                    }
                    if (array2 != null) {
                        break Label_0091;
                    }
                    try {
                        array[i].nativeMousePressed(nativeMouseEvent);
                        if (array2 == null) {
                            array[i].nativeMouseReleased(nativeMouseEvent);
                        }
                    }
                    catch (RuntimeException ex2) {
                        throw b(ex2);
                    }
                }
                ++i;
                if (array2 == null) {
                    continue;
                }
                break;
            }
            if (array2 == null) {
                break;
            }
        }
    }
    
    private void processMouseEvent(final NativeMouseEvent nativeMouseEvent) {
        final NativeMouseMotionListener[] array = GlobalScreen.eventListeners.getListeners(NativeMouseMotionListener.class);
        final int[] b = NativeInputEvent.b();
        int i = 0;
        final int[] array2 = b;
        while (i < array.length) {
            while (true) {
                Label_0087: {
                    Label_0077: {
                        try {
                            switch (nativeMouseEvent.getID()) {
                                case 2503: {
                                    array[i].nativeMouseMoved(nativeMouseEvent);
                                    break;
                                }
                                case 2504: {
                                    break Label_0077;
                                }
                                default: {
                                    break Label_0087;
                                }
                            }
                        }
                        catch (RuntimeException ex) {
                            throw b(ex);
                        }
                        if (array2 != null) {
                            break Label_0087;
                        }
                    }
                    array[i].nativeMouseDragged(nativeMouseEvent);
                }
                ++i;
                if (array2 == null) {
                    continue;
                }
                break;
            }
            if (array2 == null) {
                break;
            }
        }
    }
    
    private void processMouseWheelEvent(final NativeMouseWheelEvent nativeMouseWheelEvent) {
        final NativeMouseWheelListener[] array = GlobalScreen.eventListeners.getListeners(NativeMouseWheelListener.class);
        final int[] b = NativeInputEvent.b();
        int i = 0;
        final int[] array2 = b;
        while (i < array.length) {
            array[i].nativeMouseWheelMoved(nativeMouseWheelEvent);
            ++i;
            if (array2 == null) {
                break;
            }
        }
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
