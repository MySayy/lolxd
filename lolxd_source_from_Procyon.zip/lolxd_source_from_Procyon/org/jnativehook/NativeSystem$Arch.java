// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook;

public enum NativeSystem$Arch
{
    ARM, 
    SPARC, 
    SPARC64, 
    PPC, 
    PPC64, 
    x86, 
    x86_64, 
    UNSUPPORTED;
    
    private static final NativeSystem$Arch[] $VALUES;
    
    @Override
    public String toString() {
        return super.toString().toLowerCase(NativeSystem.ROOT_LOCALE);
    }
    
    static {
        final String[] array = new String[8];
        int n = 0;
        final String s;
        final int length = (s = "\u0016;Y\u001f7z\u0003\u0016;Y\u000b;M<\u0015Q\u001e <W*\u0004\u0005>S,v5\u0003/Q\"\u0007=S.\u0012Bx[").length();
        int char1 = 6;
        int index = -1;
        while (true) {
            int n4;
            int n3;
            final int n2 = n3 = (n4 = 34);
            ++index;
            final String s2 = s;
            final int beginIndex = index;
            final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
            final int length2 = charArray.length;
            int n5 = 0;
            while (true) {
                Label_0152: {
                    if (length2 > 1) {
                        break Label_0152;
                    }
                    n4 = (n3 = n5);
                    do {
                        final char c = charArray[n3];
                        int n6 = 0;
                        switch (n5 % 7) {
                            case 0: {
                                n6 = 76;
                                break;
                            }
                            case 1: {
                                n6 = 33;
                                break;
                            }
                            case 2: {
                                n6 = 77;
                                break;
                            }
                            case 3: {
                                n6 = 98;
                                break;
                            }
                            case 4: {
                                n6 = 35;
                                break;
                            }
                            case 5: {
                                n6 = 108;
                                break;
                            }
                            default: {
                                n6 = 77;
                                break;
                            }
                        }
                        charArray[n4] = (char)(c ^ (n2 ^ n6));
                        ++n5;
                    } while (n2 == 0);
                }
                if (length2 > n5) {
                    continue;
                }
                break;
            }
            array[n++] = new String(charArray).intern();
            if ((index += char1) >= length) {
                break;
            }
            char1 = s.charAt(index);
        }
        final String s3;
        final int length3 = (s3 = ")D;\u0005*D9\u0005U").length();
        int char2 = 3;
        int index2 = -1;
        while (true) {
            int n9;
            int n8;
            final int n7 = n8 = (n9 = 53);
            ++index2;
            final String s4 = s3;
            final int beginIndex2 = index2;
            final char[] charArray2 = s4.substring(beginIndex2, beginIndex2 + char2).toCharArray();
            final int length4 = charArray2.length;
            int n10 = 0;
            while (true) {
                Label_0348: {
                    if (length4 > 1) {
                        break Label_0348;
                    }
                    n9 = (n8 = n10);
                    do {
                        final char c2 = charArray2[n8];
                        int n11 = 0;
                        switch (n10 % 7) {
                            case 0: {
                                n11 = 76;
                                break;
                            }
                            case 1: {
                                n11 = 33;
                                break;
                            }
                            case 2: {
                                n11 = 77;
                                break;
                            }
                            case 3: {
                                n11 = 98;
                                break;
                            }
                            case 4: {
                                n11 = 35;
                                break;
                            }
                            case 5: {
                                n11 = 108;
                                break;
                            }
                            default: {
                                n11 = 77;
                                break;
                            }
                        }
                        charArray2[n9] = (char)(c2 ^ (n7 ^ n11));
                        ++n10;
                    } while (n7 == 0);
                }
                if (length4 > n10) {
                    continue;
                }
                break;
            }
            array[n++] = new String(charArray2).intern();
            if ((index2 += char2) >= length3) {
                break;
            }
            char2 = s3.charAt(index2);
        }
        final String[] array2 = array;
        $VALUES = new NativeSystem$Arch[] { NativeSystem$Arch.ARM, NativeSystem$Arch.SPARC, NativeSystem$Arch.SPARC64, NativeSystem$Arch.PPC, NativeSystem$Arch.PPC64, NativeSystem$Arch.x86, NativeSystem$Arch.x86_64, NativeSystem$Arch.UNSUPPORTED };
    }
}
