// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook;

public enum NativeSystem$Family
{
    FREEBSD, 
    OPENBSD, 
    DARWIN, 
    SOLARIS, 
    LINUX, 
    WINDOWS, 
    UNSUPPORTED;
    
    private static final NativeSystem$Family[] $VALUES;
    
    @Override
    public String toString() {
        return super.toString().toLowerCase(NativeSystem.ROOT_LOCALE);
    }
    
    static {
        final String[] array = new String[7];
        int n = 0;
        final String s;
        final int length = (s = "\b\r'[M+Q\u0007\f\u000b%^P5Q\u0005\u0017\u000b%OG\u0006\u001f\u00039MV,\u000b\u000e\f8OO2M\t\u0016.^").length();
        int char1 = 7;
        int index = -1;
        while (true) {
            int n4;
            int n3;
            final int n2 = n3 = (n4 = 35);
            ++index;
            final String s2 = s;
            final int beginIndex = index;
            final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
            final int length2 = charArray.length;
            int n5 = 0;
            while (true) {
                Label_0152: {
                    if (length2 > 1) {
                        break Label_0152;
                    }
                    n4 = (n3 = n5);
                    do {
                        final char c = charArray[n3];
                        int n6 = 0;
                        switch (n5 % 7) {
                            case 0: {
                                n6 = 120;
                                break;
                            }
                            case 1: {
                                n6 = 97;
                                break;
                            }
                            case 2: {
                                n6 = 72;
                                break;
                            }
                            case 3: {
                                n6 = 57;
                                break;
                            }
                            case 4: {
                                n6 = 60;
                                break;
                            }
                            case 5: {
                                n6 = 65;
                                break;
                            }
                            default: {
                                n6 = 33;
                                break;
                            }
                        }
                        charArray[n4] = (char)(c ^ (n2 ^ n6));
                        ++n5;
                    } while (n2 == 0);
                }
                if (length2 > n5) {
                    continue;
                }
                break;
            }
            array[n++] = new String(charArray).intern();
            if ((index += char1) >= length) {
                break;
            }
            char1 = s.charAt(index);
        }
        final String s3;
        final int length3 = (s3 = "\r\u000b7MD(_\u0007\u0004\t7FD(_").length();
        int char2 = 7;
        int index2 = -1;
        while (true) {
            int n9;
            int n8;
            final int n7 = n8 = (n9 = 58);
            ++index2;
            final String s4 = s3;
            final int beginIndex2 = index2;
            final char[] charArray2 = s4.substring(beginIndex2, beginIndex2 + char2).toCharArray();
            final int length4 = charArray2.length;
            int n10 = 0;
            while (true) {
                Label_0348: {
                    if (length4 > 1) {
                        break Label_0348;
                    }
                    n9 = (n8 = n10);
                    do {
                        final char c2 = charArray2[n8];
                        int n11 = 0;
                        switch (n10 % 7) {
                            case 0: {
                                n11 = 120;
                                break;
                            }
                            case 1: {
                                n11 = 97;
                                break;
                            }
                            case 2: {
                                n11 = 72;
                                break;
                            }
                            case 3: {
                                n11 = 57;
                                break;
                            }
                            case 4: {
                                n11 = 60;
                                break;
                            }
                            case 5: {
                                n11 = 65;
                                break;
                            }
                            default: {
                                n11 = 33;
                                break;
                            }
                        }
                        charArray2[n9] = (char)(c2 ^ (n7 ^ n11));
                        ++n10;
                    } while (n7 == 0);
                }
                if (length4 > n10) {
                    continue;
                }
                break;
            }
            array[n++] = new String(charArray2).intern();
            if ((index2 += char2) >= length3) {
                break;
            }
            char2 = s3.charAt(index2);
        }
        final String[] array2 = array;
        $VALUES = new NativeSystem$Family[] { NativeSystem$Family.FREEBSD, NativeSystem$Family.OPENBSD, NativeSystem$Family.DARWIN, NativeSystem$Family.SOLARIS, NativeSystem$Family.LINUX, NativeSystem$Family.WINDOWS, NativeSystem$Family.UNSUPPORTED };
    }
}
