// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook;

import java.io.File;
import java.util.Iterator;

public interface NativeLibraryLocator
{
    Iterator<File> getLibraries();
}
