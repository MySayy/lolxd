// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook;

import java.util.Locale;

public class NativeSystem
{
    protected static final Locale ROOT_LOCALE;
    private static final String[] a;
    private static final String[] b;
    
    public static NativeSystem$Family getFamily() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_0       
        //     4: sipush          20604
        //     7: bipush          84
        //     9: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //    12: invokestatic    java/lang/System.getProperty:(Ljava/lang/String;)Ljava/lang/String;
        //    15: astore_1       
        //    16: aload_1        
        //    17: sipush          20607
        //    20: sipush          -29530
        //    23: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //    26: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //    29: aload_0        
        //    30: ifnull          71
        //    33: ifeq            51
        //    36: goto            43
        //    39: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    42: athrow         
        //    43: getstatic       org/jnativehook/NativeSystem$Family.FREEBSD:Lorg/jnativehook/NativeSystem$Family;
        //    46: astore_2       
        //    47: aload_0        
        //    48: ifnonnull       309
        //    51: aload_1        
        //    52: sipush          20576
        //    55: sipush          -21902
        //    58: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //    61: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //    64: goto            71
        //    67: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    70: athrow         
        //    71: aload_0        
        //    72: ifnull          113
        //    75: ifeq            93
        //    78: goto            85
        //    81: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    84: athrow         
        //    85: getstatic       org/jnativehook/NativeSystem$Family.OPENBSD:Lorg/jnativehook/NativeSystem$Family;
        //    88: astore_2       
        //    89: aload_0        
        //    90: ifnonnull       309
        //    93: aload_1        
        //    94: sipush          20582
        //    97: sipush          30806
        //   100: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   103: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   106: goto            113
        //   109: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   112: athrow         
        //   113: aload_0        
        //   114: ifnull          159
        //   117: ifeq            135
        //   120: goto            127
        //   123: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   126: athrow         
        //   127: getstatic       org/jnativehook/NativeSystem$Family.DARWIN:Lorg/jnativehook/NativeSystem$Family;
        //   130: astore_2       
        //   131: aload_0        
        //   132: ifnonnull       309
        //   135: aload_1        
        //   136: sipush          20591
        //   139: sipush          -16174
        //   142: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   145: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   148: aload_0        
        //   149: ifnull          200
        //   152: goto            159
        //   155: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   158: athrow         
        //   159: aload_0        
        //   160: ifnull          200
        //   163: goto            170
        //   166: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   169: athrow         
        //   170: ifne            214
        //   173: goto            180
        //   176: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   179: athrow         
        //   180: aload_1        
        //   181: sipush          20577
        //   184: sipush          -24918
        //   187: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   190: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   193: goto            200
        //   196: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   199: athrow         
        //   200: aload_0        
        //   201: ifnull          242
        //   204: ifeq            222
        //   207: goto            214
        //   210: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   213: athrow         
        //   214: getstatic       org/jnativehook/NativeSystem$Family.SOLARIS:Lorg/jnativehook/NativeSystem$Family;
        //   217: astore_2       
        //   218: aload_0        
        //   219: ifnonnull       309
        //   222: aload_1        
        //   223: sipush          20586
        //   226: sipush          22870
        //   229: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   232: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   235: goto            242
        //   238: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   241: athrow         
        //   242: aload_0        
        //   243: ifnull          290
        //   246: ifeq            264
        //   249: goto            256
        //   252: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   255: athrow         
        //   256: getstatic       org/jnativehook/NativeSystem$Family.LINUX:Lorg/jnativehook/NativeSystem$Family;
        //   259: astore_2       
        //   260: aload_0        
        //   261: ifnonnull       309
        //   264: aload_1        
        //   265: getstatic       org/jnativehook/NativeSystem.ROOT_LOCALE:Ljava/util/Locale;
        //   268: invokevirtual   java/lang/String.toLowerCase:(Ljava/util/Locale;)Ljava/lang/String;
        //   271: sipush          20578
        //   274: sipush          -6072
        //   277: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   280: invokevirtual   java/lang/String.startsWith:(Ljava/lang/String;)Z
        //   283: goto            290
        //   286: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   289: athrow         
        //   290: ifeq            301
        //   293: getstatic       org/jnativehook/NativeSystem$Family.WINDOWS:Lorg/jnativehook/NativeSystem$Family;
        //   296: astore_2       
        //   297: aload_0        
        //   298: ifnonnull       309
        //   301: getstatic       org/jnativehook/NativeSystem$Family.UNSUPPORTED:Lorg/jnativehook/NativeSystem$Family;
        //   304: aload_0        
        //   305: ifnull          296
        //   308: astore_2       
        //   309: aload_2        
        //   310: areturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  16     36     39     43     Ljava/lang/RuntimeException;
        //  47     64     67     71     Ljava/lang/RuntimeException;
        //  71     78     81     85     Ljava/lang/RuntimeException;
        //  89     106    109    113    Ljava/lang/RuntimeException;
        //  113    120    123    127    Ljava/lang/RuntimeException;
        //  131    152    155    159    Ljava/lang/RuntimeException;
        //  135    163    166    170    Ljava/lang/RuntimeException;
        //  159    173    176    180    Ljava/lang/RuntimeException;
        //  170    193    196    200    Ljava/lang/RuntimeException;
        //  200    207    210    214    Ljava/lang/RuntimeException;
        //  218    235    238    242    Ljava/lang/RuntimeException;
        //  242    249    252    256    Ljava/lang/RuntimeException;
        //  260    283    286    290    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0135:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static NativeSystem$Arch getArchitecture() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_0       
        //     4: sipush          20605
        //     7: sipush          29045
        //    10: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //    13: invokestatic    java/lang/System.getProperty:(Ljava/lang/String;)Ljava/lang/String;
        //    16: astore_1       
        //    17: aload_1        
        //    18: sipush          20587
        //    21: sipush          14454
        //    24: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //    27: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //    30: aload_0        
        //    31: ifnull          72
        //    34: ifeq            52
        //    37: goto            44
        //    40: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    43: athrow         
        //    44: getstatic       org/jnativehook/NativeSystem$Arch.ARM:Lorg/jnativehook/NativeSystem$Arch;
        //    47: astore_2       
        //    48: aload_0        
        //    49: ifnonnull       661
        //    52: aload_1        
        //    53: sipush          20584
        //    56: sipush          -15975
        //    59: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //    62: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //    65: goto            72
        //    68: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    71: athrow         
        //    72: aload_0        
        //    73: ifnull          114
        //    76: ifeq            94
        //    79: goto            86
        //    82: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    85: athrow         
        //    86: getstatic       org/jnativehook/NativeSystem$Arch.SPARC:Lorg/jnativehook/NativeSystem$Arch;
        //    89: astore_2       
        //    90: aload_0        
        //    91: ifnonnull       661
        //    94: aload_1        
        //    95: sipush          20581
        //    98: sipush          -25622
        //   101: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   104: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   107: goto            114
        //   110: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   113: athrow         
        //   114: aload_0        
        //   115: ifnull          160
        //   118: ifeq            136
        //   121: goto            128
        //   124: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   127: athrow         
        //   128: getstatic       org/jnativehook/NativeSystem$Arch.SPARC64:Lorg/jnativehook/NativeSystem$Arch;
        //   131: astore_2       
        //   132: aload_0        
        //   133: ifnonnull       661
        //   136: aload_1        
        //   137: sipush          20600
        //   140: sipush          19056
        //   143: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   146: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   149: aload_0        
        //   150: ifnull          201
        //   153: goto            160
        //   156: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   159: athrow         
        //   160: aload_0        
        //   161: ifnull          201
        //   164: goto            171
        //   167: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   170: athrow         
        //   171: ifne            215
        //   174: goto            181
        //   177: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   180: athrow         
        //   181: aload_1        
        //   182: sipush          20602
        //   185: sipush          28363
        //   188: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   191: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   194: goto            201
        //   197: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   200: athrow         
        //   201: aload_0        
        //   202: ifnull          247
        //   205: ifeq            223
        //   208: goto            215
        //   211: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   214: athrow         
        //   215: getstatic       org/jnativehook/NativeSystem$Arch.PPC:Lorg/jnativehook/NativeSystem$Arch;
        //   218: astore_2       
        //   219: aload_0        
        //   220: ifnonnull       661
        //   223: aload_1        
        //   224: sipush          20585
        //   227: sipush          -31537
        //   230: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   233: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   236: aload_0        
        //   237: ifnull          288
        //   240: goto            247
        //   243: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   246: athrow         
        //   247: aload_0        
        //   248: ifnull          288
        //   251: goto            258
        //   254: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   257: athrow         
        //   258: ifne            302
        //   261: goto            268
        //   264: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   267: athrow         
        //   268: aload_1        
        //   269: sipush          20606
        //   272: sipush          3535
        //   275: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   278: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   281: goto            288
        //   284: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   287: athrow         
        //   288: aload_0        
        //   289: ifnull          334
        //   292: ifeq            310
        //   295: goto            302
        //   298: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   301: athrow         
        //   302: getstatic       org/jnativehook/NativeSystem$Arch.PPC64:Lorg/jnativehook/NativeSystem$Arch;
        //   305: astore_2       
        //   306: aload_0        
        //   307: ifnonnull       661
        //   310: aload_1        
        //   311: sipush          20589
        //   314: sipush          -24187
        //   317: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   320: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   323: aload_0        
        //   324: ifnull          375
        //   327: goto            334
        //   330: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   333: athrow         
        //   334: aload_0        
        //   335: ifnull          379
        //   338: goto            345
        //   341: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   344: athrow         
        //   345: ifne            524
        //   348: goto            355
        //   351: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   354: athrow         
        //   355: aload_1        
        //   356: sipush          20603
        //   359: sipush          -25092
        //   362: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   365: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   368: goto            375
        //   371: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   374: athrow         
        //   375: aload_0        
        //   376: ifnull          420
        //   379: aload_0        
        //   380: ifnull          424
        //   383: goto            390
        //   386: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   389: athrow         
        //   390: ifne            524
        //   393: goto            400
        //   396: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   399: athrow         
        //   400: aload_1        
        //   401: sipush          20590
        //   404: sipush          26147
        //   407: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   410: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   413: goto            420
        //   416: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   419: athrow         
        //   420: aload_0        
        //   421: ifnull          465
        //   424: aload_0        
        //   425: ifnull          469
        //   428: goto            435
        //   431: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   434: athrow         
        //   435: ifne            524
        //   438: goto            445
        //   441: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   444: athrow         
        //   445: aload_1        
        //   446: sipush          20588
        //   449: sipush          -18740
        //   452: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   455: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   458: goto            465
        //   461: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   464: athrow         
        //   465: aload_0        
        //   466: ifnull          510
        //   469: aload_0        
        //   470: ifnull          510
        //   473: goto            480
        //   476: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   479: athrow         
        //   480: ifne            524
        //   483: goto            490
        //   486: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   489: athrow         
        //   490: aload_1        
        //   491: sipush          20580
        //   494: sipush          -16101
        //   497: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   500: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   503: goto            510
        //   506: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   509: athrow         
        //   510: aload_0        
        //   511: ifnull          556
        //   514: ifeq            532
        //   517: goto            524
        //   520: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   523: athrow         
        //   524: getstatic       org/jnativehook/NativeSystem$Arch.x86:Lorg/jnativehook/NativeSystem$Arch;
        //   527: astore_2       
        //   528: aload_0        
        //   529: ifnonnull       661
        //   532: aload_1        
        //   533: sipush          20583
        //   536: sipush          -21739
        //   539: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   542: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   545: aload_0        
        //   546: ifnull          597
        //   549: goto            556
        //   552: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   555: athrow         
        //   556: aload_0        
        //   557: ifnull          601
        //   560: goto            567
        //   563: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   566: athrow         
        //   567: ifne            645
        //   570: goto            577
        //   573: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   576: athrow         
        //   577: aload_1        
        //   578: sipush          20601
        //   581: sipush          14444
        //   584: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   587: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   590: goto            597
        //   593: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   596: athrow         
        //   597: aload_0        
        //   598: ifnull          642
        //   601: aload_0        
        //   602: ifnull          642
        //   605: goto            612
        //   608: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   611: athrow         
        //   612: ifne            645
        //   615: goto            622
        //   618: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   621: athrow         
        //   622: aload_1        
        //   623: sipush          20579
        //   626: sipush          -22355
        //   629: invokestatic    org/jnativehook/NativeSystem.a:(II)Ljava/lang/String;
        //   632: invokevirtual   java/lang/String.equalsIgnoreCase:(Ljava/lang/String;)Z
        //   635: goto            642
        //   638: invokestatic    org/jnativehook/NativeSystem.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   641: athrow         
        //   642: ifeq            653
        //   645: getstatic       org/jnativehook/NativeSystem$Arch.x86_64:Lorg/jnativehook/NativeSystem$Arch;
        //   648: astore_2       
        //   649: aload_0        
        //   650: ifnonnull       661
        //   653: getstatic       org/jnativehook/NativeSystem$Arch.UNSUPPORTED:Lorg/jnativehook/NativeSystem$Arch;
        //   656: aload_0        
        //   657: ifnull          648
        //   660: astore_2       
        //   661: aload_2        
        //   662: areturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  17     37     40     44     Ljava/lang/RuntimeException;
        //  48     65     68     72     Ljava/lang/RuntimeException;
        //  72     79     82     86     Ljava/lang/RuntimeException;
        //  90     107    110    114    Ljava/lang/RuntimeException;
        //  114    121    124    128    Ljava/lang/RuntimeException;
        //  132    153    156    160    Ljava/lang/RuntimeException;
        //  136    164    167    171    Ljava/lang/RuntimeException;
        //  160    174    177    181    Ljava/lang/RuntimeException;
        //  171    194    197    201    Ljava/lang/RuntimeException;
        //  201    208    211    215    Ljava/lang/RuntimeException;
        //  219    240    243    247    Ljava/lang/RuntimeException;
        //  223    251    254    258    Ljava/lang/RuntimeException;
        //  247    261    264    268    Ljava/lang/RuntimeException;
        //  258    281    284    288    Ljava/lang/RuntimeException;
        //  288    295    298    302    Ljava/lang/RuntimeException;
        //  306    327    330    334    Ljava/lang/RuntimeException;
        //  310    338    341    345    Ljava/lang/RuntimeException;
        //  334    348    351    355    Ljava/lang/RuntimeException;
        //  345    368    371    375    Ljava/lang/RuntimeException;
        //  375    383    386    390    Ljava/lang/RuntimeException;
        //  379    393    396    400    Ljava/lang/RuntimeException;
        //  390    413    416    420    Ljava/lang/RuntimeException;
        //  420    428    431    435    Ljava/lang/RuntimeException;
        //  424    438    441    445    Ljava/lang/RuntimeException;
        //  435    458    461    465    Ljava/lang/RuntimeException;
        //  465    473    476    480    Ljava/lang/RuntimeException;
        //  469    483    486    490    Ljava/lang/RuntimeException;
        //  480    503    506    510    Ljava/lang/RuntimeException;
        //  510    517    520    524    Ljava/lang/RuntimeException;
        //  528    549    552    556    Ljava/lang/RuntimeException;
        //  532    560    563    567    Ljava/lang/RuntimeException;
        //  556    570    573    577    Ljava/lang/RuntimeException;
        //  567    590    593    597    Ljava/lang/RuntimeException;
        //  597    605    608    612    Ljava/lang/RuntimeException;
        //  601    615    618    622    Ljava/lang/RuntimeException;
        //  612    635    638    642    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0136:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        final String[] a2 = new String[24];
        int n = 0;
        final String s;
        final int length = (s = "\u007f\u0092~^$m\u0080\u0004~cS\u0007\u0003\u008b,\u00d0\u0004\u00e4E\u0000\u00e2\u0003Yw\u00eb\u0005LG\u00e66\u007f\u0005z¶²q\u0015\u0005¿\u0087k\u0013;\u0006*\u00d7\u00e4u\"¬\b\u0088aR®R\u0000£\u008f\u0007\u0006W\\\t\u00dd©\u00cb\u0004\u00d5S&C\u0002u(\u0007\u00ffB\u00e8\u0087©\u00ed\u008f\u0005\u0005\u00143\u00d9\u00ce\u0007\u00e6²\u00db©¨g\u0014\u0007\u00c2\u00ffwI=\u0011¦\t\u007f-\u0006\u00adS\u008e~sx\u0007\u0099\u009a\u007f\u00c0\u000e´\u00de\u0007\u009f\u00d4¿\u0006\u0005\u008c\u00c3\u0004\u000e6]J\u0007 \u0011\u00fd*,~\u0091").length();
        int char1 = 7;
        int index = -1;
        while (true) {
            int n4;
            int n3;
            final int n2 = n3 = (n4 = 49);
            ++index;
            final String s2 = s;
            final int beginIndex = index;
            final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
            final int length2 = charArray.length;
            int n5 = 0;
            while (true) {
                Label_0152: {
                    if (length2 > 1) {
                        break Label_0152;
                    }
                    n4 = (n3 = n5);
                    do {
                        final char c = charArray[n3];
                        int n6 = 0;
                        switch (n5 % 7) {
                            case 0: {
                                n6 = 54;
                                break;
                            }
                            case 1: {
                                n6 = 53;
                                break;
                            }
                            case 2: {
                                n6 = 49;
                                break;
                            }
                            case 3: {
                                n6 = 94;
                                break;
                            }
                            case 4: {
                                n6 = 73;
                                break;
                            }
                            case 5: {
                                n6 = 94;
                                break;
                            }
                            default: {
                                n6 = 117;
                                break;
                            }
                        }
                        charArray[n4] = (char)(c ^ (n2 ^ n6));
                        ++n5;
                    } while (n2 == 0);
                }
                if (length2 > n5) {
                    continue;
                }
                break;
            }
            a2[n++] = new String(charArray).intern();
            if ((index += char1) >= length) {
                break;
            }
            char1 = s.charAt(index);
        }
        final String s3;
        final int length3 = (s3 = "g<\u008a1Z\u0003\u00ca\u00e7\u000b").length();
        int char2 = 5;
        int index2 = -1;
        while (true) {
            int n9;
            int n8;
            final int n7 = n8 = (n9 = 118);
            ++index2;
            final String s4 = s3;
            final int beginIndex2 = index2;
            final char[] charArray2 = s4.substring(beginIndex2, beginIndex2 + char2).toCharArray();
            final int length4 = charArray2.length;
            int n10 = 0;
            while (true) {
                Label_0348: {
                    if (length4 > 1) {
                        break Label_0348;
                    }
                    n9 = (n8 = n10);
                    do {
                        final char c2 = charArray2[n8];
                        int n11 = 0;
                        switch (n10 % 7) {
                            case 0: {
                                n11 = 54;
                                break;
                            }
                            case 1: {
                                n11 = 53;
                                break;
                            }
                            case 2: {
                                n11 = 49;
                                break;
                            }
                            case 3: {
                                n11 = 94;
                                break;
                            }
                            case 4: {
                                n11 = 73;
                                break;
                            }
                            case 5: {
                                n11 = 94;
                                break;
                            }
                            default: {
                                n11 = 117;
                                break;
                            }
                        }
                        charArray2[n9] = (char)(c2 ^ (n7 ^ n11));
                        ++n10;
                    } while (n7 == 0);
                }
                if (length4 > n10) {
                    continue;
                }
                break;
            }
            a2[n++] = new String(charArray2).intern();
            if ((index2 += char2) >= length3) {
                break;
            }
            char2 = s3.charAt(index2);
        }
        a = a2;
        b = new String[24];
        ROOT_LOCALE = new Locale("", "", "");
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0x506F) & 0xFFFF;
        if (NativeSystem.b[n3] == null) {
            final char[] charArray = NativeSystem.a[n3].toCharArray();
            int n4 = 0;
            switch (charArray[0] & '\u00ff') {
                case 0: {
                    n4 = 69;
                    break;
                }
                case 1: {
                    n4 = 120;
                    break;
                }
                case 2: {
                    n4 = 57;
                    break;
                }
                case 3: {
                    n4 = 28;
                    break;
                }
                case 4: {
                    n4 = 179;
                    break;
                }
                case 5: {
                    n4 = 119;
                    break;
                }
                case 6: {
                    n4 = 114;
                    break;
                }
                case 7: {
                    n4 = 20;
                    break;
                }
                case 8: {
                    n4 = 9;
                    break;
                }
                case 9: {
                    n4 = 156;
                    break;
                }
                case 10: {
                    n4 = 189;
                    break;
                }
                case 11: {
                    n4 = 80;
                    break;
                }
                case 12: {
                    n4 = 158;
                    break;
                }
                case 13: {
                    n4 = 243;
                    break;
                }
                case 14: {
                    n4 = 254;
                    break;
                }
                case 15: {
                    n4 = 29;
                    break;
                }
                case 16: {
                    n4 = 230;
                    break;
                }
                case 17: {
                    n4 = 61;
                    break;
                }
                case 18: {
                    n4 = 155;
                    break;
                }
                case 19: {
                    n4 = 151;
                    break;
                }
                case 20: {
                    n4 = 160;
                    break;
                }
                case 21: {
                    n4 = 90;
                    break;
                }
                case 22: {
                    n4 = 159;
                    break;
                }
                case 23: {
                    n4 = 211;
                    break;
                }
                case 24: {
                    n4 = 250;
                    break;
                }
                case 25: {
                    n4 = 34;
                    break;
                }
                case 26: {
                    n4 = 177;
                    break;
                }
                case 27: {
                    n4 = 39;
                    break;
                }
                case 28: {
                    n4 = 249;
                    break;
                }
                case 29: {
                    n4 = 67;
                    break;
                }
                case 30: {
                    n4 = 59;
                    break;
                }
                case 31: {
                    n4 = 111;
                    break;
                }
                case 32: {
                    n4 = 62;
                    break;
                }
                case 33: {
                    n4 = 236;
                    break;
                }
                case 34: {
                    n4 = 125;
                    break;
                }
                case 35: {
                    n4 = 227;
                    break;
                }
                case 36: {
                    n4 = 117;
                    break;
                }
                case 37: {
                    n4 = 130;
                    break;
                }
                case 38: {
                    n4 = 105;
                    break;
                }
                case 39: {
                    n4 = 38;
                    break;
                }
                case 40: {
                    n4 = 89;
                    break;
                }
                case 41: {
                    n4 = 109;
                    break;
                }
                case 42: {
                    n4 = 74;
                    break;
                }
                case 43: {
                    n4 = 216;
                    break;
                }
                case 44: {
                    n4 = 168;
                    break;
                }
                case 45: {
                    n4 = 192;
                    break;
                }
                case 46: {
                    n4 = 16;
                    break;
                }
                case 47: {
                    n4 = 52;
                    break;
                }
                case 48: {
                    n4 = 33;
                    break;
                }
                case 49: {
                    n4 = 209;
                    break;
                }
                case 50: {
                    n4 = 100;
                    break;
                }
                case 51: {
                    n4 = 134;
                    break;
                }
                case 52: {
                    n4 = 92;
                    break;
                }
                case 53: {
                    n4 = 135;
                    break;
                }
                case 54: {
                    n4 = 5;
                    break;
                }
                case 55: {
                    n4 = 25;
                    break;
                }
                case 56: {
                    n4 = 27;
                    break;
                }
                case 57: {
                    n4 = 133;
                    break;
                }
                case 58: {
                    n4 = 77;
                    break;
                }
                case 59: {
                    n4 = 195;
                    break;
                }
                case 60: {
                    n4 = 1;
                    break;
                }
                case 61: {
                    n4 = 84;
                    break;
                }
                case 62: {
                    n4 = 245;
                    break;
                }
                case 63: {
                    n4 = 122;
                    break;
                }
                case 64: {
                    n4 = 142;
                    break;
                }
                case 65: {
                    n4 = 128;
                    break;
                }
                case 66: {
                    n4 = 219;
                    break;
                }
                case 67: {
                    n4 = 98;
                    break;
                }
                case 68: {
                    n4 = 207;
                    break;
                }
                case 69: {
                    n4 = 237;
                    break;
                }
                case 70: {
                    n4 = 191;
                    break;
                }
                case 71: {
                    n4 = 86;
                    break;
                }
                case 72: {
                    n4 = 11;
                    break;
                }
                case 73: {
                    n4 = 198;
                    break;
                }
                case 74: {
                    n4 = 153;
                    break;
                }
                case 75: {
                    n4 = 47;
                    break;
                }
                case 76: {
                    n4 = 214;
                    break;
                }
                case 77: {
                    n4 = 231;
                    break;
                }
                case 78: {
                    n4 = 87;
                    break;
                }
                case 79: {
                    n4 = 247;
                    break;
                }
                case 80: {
                    n4 = 203;
                    break;
                }
                case 81: {
                    n4 = 18;
                    break;
                }
                case 82: {
                    n4 = 147;
                    break;
                }
                case 83: {
                    n4 = 235;
                    break;
                }
                case 84: {
                    n4 = 241;
                    break;
                }
                case 85: {
                    n4 = 251;
                    break;
                }
                case 86: {
                    n4 = 14;
                    break;
                }
                case 87: {
                    n4 = 187;
                    break;
                }
                case 88: {
                    n4 = 8;
                    break;
                }
                case 89: {
                    n4 = 246;
                    break;
                }
                case 90: {
                    n4 = 76;
                    break;
                }
                case 91: {
                    n4 = 45;
                    break;
                }
                case 92: {
                    n4 = 242;
                    break;
                }
                case 93: {
                    n4 = 21;
                    break;
                }
                case 94: {
                    n4 = 55;
                    break;
                }
                case 95: {
                    n4 = 221;
                    break;
                }
                case 96: {
                    n4 = 40;
                    break;
                }
                case 97: {
                    n4 = 208;
                    break;
                }
                case 98: {
                    n4 = 165;
                    break;
                }
                case 99: {
                    n4 = 200;
                    break;
                }
                case 100: {
                    n4 = 42;
                    break;
                }
                case 101: {
                    n4 = 103;
                    break;
                }
                case 102: {
                    n4 = 108;
                    break;
                }
                case 103: {
                    n4 = 75;
                    break;
                }
                case 104: {
                    n4 = 217;
                    break;
                }
                case 105: {
                    n4 = 127;
                    break;
                }
                case 106: {
                    n4 = 232;
                    break;
                }
                case 107: {
                    n4 = 213;
                    break;
                }
                case 108: {
                    n4 = 51;
                    break;
                }
                case 109: {
                    n4 = 239;
                    break;
                }
                case 110: {
                    n4 = 223;
                    break;
                }
                case 111: {
                    n4 = 188;
                    break;
                }
                case 112: {
                    n4 = 181;
                    break;
                }
                case 113: {
                    n4 = 197;
                    break;
                }
                case 114: {
                    n4 = 148;
                    break;
                }
                case 115: {
                    n4 = 144;
                    break;
                }
                case 116: {
                    n4 = 60;
                    break;
                }
                case 117: {
                    n4 = 37;
                    break;
                }
                case 118: {
                    n4 = 2;
                    break;
                }
                case 119: {
                    n4 = 15;
                    break;
                }
                case 120: {
                    n4 = 199;
                    break;
                }
                case 121: {
                    n4 = 19;
                    break;
                }
                case 122: {
                    n4 = 123;
                    break;
                }
                case 123: {
                    n4 = 49;
                    break;
                }
                case 124: {
                    n4 = 252;
                    break;
                }
                case 125: {
                    n4 = 194;
                    break;
                }
                case 126: {
                    n4 = 248;
                    break;
                }
                case 127: {
                    n4 = 7;
                    break;
                }
                case 128: {
                    n4 = 13;
                    break;
                }
                case 129: {
                    n4 = 71;
                    break;
                }
                case 130: {
                    n4 = 65;
                    break;
                }
                case 131: {
                    n4 = 226;
                    break;
                }
                case 132: {
                    n4 = 220;
                    break;
                }
                case 133: {
                    n4 = 72;
                    break;
                }
                case 134: {
                    n4 = 170;
                    break;
                }
                case 135: {
                    n4 = 115;
                    break;
                }
                case 136: {
                    n4 = 79;
                    break;
                }
                case 137: {
                    n4 = 35;
                    break;
                }
                case 138: {
                    n4 = 118;
                    break;
                }
                case 139: {
                    n4 = 141;
                    break;
                }
                case 140: {
                    n4 = 145;
                    break;
                }
                case 141: {
                    n4 = 106;
                    break;
                }
                case 142: {
                    n4 = 64;
                    break;
                }
                case 143: {
                    n4 = 116;
                    break;
                }
                case 144: {
                    n4 = 97;
                    break;
                }
                case 145: {
                    n4 = 196;
                    break;
                }
                case 146: {
                    n4 = 169;
                    break;
                }
                case 147: {
                    n4 = 102;
                    break;
                }
                case 148: {
                    n4 = 70;
                    break;
                }
                case 149: {
                    n4 = 78;
                    break;
                }
                case 150: {
                    n4 = 140;
                    break;
                }
                case 151: {
                    n4 = 129;
                    break;
                }
                case 152: {
                    n4 = 93;
                    break;
                }
                case 153: {
                    n4 = 157;
                    break;
                }
                case 154: {
                    n4 = 166;
                    break;
                }
                case 155: {
                    n4 = 83;
                    break;
                }
                case 156: {
                    n4 = 136;
                    break;
                }
                case 157: {
                    n4 = 24;
                    break;
                }
                case 158: {
                    n4 = 132;
                    break;
                }
                case 159: {
                    n4 = 36;
                    break;
                }
                case 160: {
                    n4 = 68;
                    break;
                }
                case 161: {
                    n4 = 178;
                    break;
                }
                case 162: {
                    n4 = 10;
                    break;
                }
                case 163: {
                    n4 = 22;
                    break;
                }
                case 164: {
                    n4 = 154;
                    break;
                }
                case 165: {
                    n4 = 176;
                    break;
                }
                case 166: {
                    n4 = 32;
                    break;
                }
                case 167: {
                    n4 = 244;
                    break;
                }
                case 168: {
                    n4 = 31;
                    break;
                }
                case 169: {
                    n4 = 0;
                    break;
                }
                case 170: {
                    n4 = 101;
                    break;
                }
                case 171: {
                    n4 = 58;
                    break;
                }
                case 172: {
                    n4 = 172;
                    break;
                }
                case 173: {
                    n4 = 88;
                    break;
                }
                case 174: {
                    n4 = 81;
                    break;
                }
                case 175: {
                    n4 = 56;
                    break;
                }
                case 176: {
                    n4 = 205;
                    break;
                }
                case 177: {
                    n4 = 131;
                    break;
                }
                case 178: {
                    n4 = 240;
                    break;
                }
                case 179: {
                    n4 = 233;
                    break;
                }
                case 180: {
                    n4 = 204;
                    break;
                }
                case 181: {
                    n4 = 201;
                    break;
                }
                case 182: {
                    n4 = 44;
                    break;
                }
                case 183: {
                    n4 = 143;
                    break;
                }
                case 184: {
                    n4 = 206;
                    break;
                }
                case 185: {
                    n4 = 73;
                    break;
                }
                case 186: {
                    n4 = 99;
                    break;
                }
                case 187: {
                    n4 = 30;
                    break;
                }
                case 188: {
                    n4 = 190;
                    break;
                }
                case 189: {
                    n4 = 229;
                    break;
                }
                case 190: {
                    n4 = 139;
                    break;
                }
                case 191: {
                    n4 = 121;
                    break;
                }
                case 192: {
                    n4 = 48;
                    break;
                }
                case 193: {
                    n4 = 150;
                    break;
                }
                case 194: {
                    n4 = 234;
                    break;
                }
                case 195: {
                    n4 = 82;
                    break;
                }
                case 196: {
                    n4 = 6;
                    break;
                }
                case 197: {
                    n4 = 3;
                    break;
                }
                case 198: {
                    n4 = 167;
                    break;
                }
                case 199: {
                    n4 = 162;
                    break;
                }
                case 200: {
                    n4 = 163;
                    break;
                }
                case 201: {
                    n4 = 180;
                    break;
                }
                case 202: {
                    n4 = 85;
                    break;
                }
                case 203: {
                    n4 = 91;
                    break;
                }
                case 204: {
                    n4 = 225;
                    break;
                }
                case 205: {
                    n4 = 164;
                    break;
                }
                case 206: {
                    n4 = 182;
                    break;
                }
                case 207: {
                    n4 = 112;
                    break;
                }
                case 208: {
                    n4 = 110;
                    break;
                }
                case 209: {
                    n4 = 53;
                    break;
                }
                case 210: {
                    n4 = 96;
                    break;
                }
                case 211: {
                    n4 = 12;
                    break;
                }
                case 212: {
                    n4 = 94;
                    break;
                }
                case 213: {
                    n4 = 218;
                    break;
                }
                case 214: {
                    n4 = 253;
                    break;
                }
                case 215: {
                    n4 = 173;
                    break;
                }
                case 216: {
                    n4 = 63;
                    break;
                }
                case 217: {
                    n4 = 149;
                    break;
                }
                case 218: {
                    n4 = 146;
                    break;
                }
                case 219: {
                    n4 = 175;
                    break;
                }
                case 220: {
                    n4 = 174;
                    break;
                }
                case 221: {
                    n4 = 183;
                    break;
                }
                case 222: {
                    n4 = 46;
                    break;
                }
                case 223: {
                    n4 = 41;
                    break;
                }
                case 224: {
                    n4 = 215;
                    break;
                }
                case 225: {
                    n4 = 228;
                    break;
                }
                case 226: {
                    n4 = 104;
                    break;
                }
                case 227: {
                    n4 = 66;
                    break;
                }
                case 228: {
                    n4 = 4;
                    break;
                }
                case 229: {
                    n4 = 124;
                    break;
                }
                case 230: {
                    n4 = 138;
                    break;
                }
                case 231: {
                    n4 = 152;
                    break;
                }
                case 232: {
                    n4 = 113;
                    break;
                }
                case 233: {
                    n4 = 26;
                    break;
                }
                case 234: {
                    n4 = 222;
                    break;
                }
                case 235: {
                    n4 = 23;
                    break;
                }
                case 236: {
                    n4 = 210;
                    break;
                }
                case 237: {
                    n4 = 50;
                    break;
                }
                case 238: {
                    n4 = 212;
                    break;
                }
                case 239: {
                    n4 = 186;
                    break;
                }
                case 240: {
                    n4 = 137;
                    break;
                }
                case 241: {
                    n4 = 224;
                    break;
                }
                case 242: {
                    n4 = 107;
                    break;
                }
                case 243: {
                    n4 = 17;
                    break;
                }
                case 244: {
                    n4 = 171;
                    break;
                }
                case 245: {
                    n4 = 202;
                    break;
                }
                case 246: {
                    n4 = 184;
                    break;
                }
                case 247: {
                    n4 = 95;
                    break;
                }
                case 248: {
                    n4 = 185;
                    break;
                }
                case 249: {
                    n4 = 126;
                    break;
                }
                case 250: {
                    n4 = 43;
                    break;
                }
                case 251: {
                    n4 = 193;
                    break;
                }
                case 252: {
                    n4 = 238;
                    break;
                }
                case 253: {
                    n4 = 255;
                    break;
                }
                case 254: {
                    n4 = 54;
                    break;
                }
                default: {
                    n4 = 161;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < charArray.length; ++i) {
                final int n8 = i % 2;
                final char[] array = charArray;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ charArray[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ charArray[i]) & 0xFF);
                }
            }
            NativeSystem.b[n3] = new String(charArray).intern();
        }
        return NativeSystem.b[n3];
    }
}
