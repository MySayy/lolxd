// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.keyboard;

public class NativeKeyAdapter implements NativeKeyListener
{
    public void nativeKeyTyped(final NativeKeyEvent nativeKeyEvent) {
    }
    
    public void nativeKeyPressed(final NativeKeyEvent nativeKeyEvent) {
    }
    
    public void nativeKeyReleased(final NativeKeyEvent nativeKeyEvent) {
    }
}
