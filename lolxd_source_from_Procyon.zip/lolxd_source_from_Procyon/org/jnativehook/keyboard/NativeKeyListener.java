// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.keyboard;

import java.util.EventListener;

public interface NativeKeyListener extends EventListener
{
    void nativeKeyTyped(final NativeKeyEvent p0);
    
    void nativeKeyPressed(final NativeKeyEvent p0);
    
    void nativeKeyReleased(final NativeKeyEvent p0);
}
