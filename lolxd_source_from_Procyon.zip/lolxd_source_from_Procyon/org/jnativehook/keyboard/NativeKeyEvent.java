// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.keyboard;

import java.awt.Toolkit;
import org.jnativehook.NativeInputEvent;

public class NativeKeyEvent extends NativeInputEvent
{
    private static final long serialVersionUID = 8608981443834617646L;
    private int rawCode;
    private int keyCode;
    private char keyChar;
    private int keyLocation;
    public static final int NATIVE_KEY_FIRST = 2400;
    public static final int NATIVE_KEY_LAST = 2402;
    public static final int NATIVE_KEY_TYPED = 2400;
    public static final int NATIVE_KEY_PRESSED = 2401;
    public static final int NATIVE_KEY_RELEASED = 2402;
    public static final int KEY_LOCATION_UNKNOWN = 0;
    public static final int KEY_LOCATION_STANDARD = 1;
    public static final int KEY_LOCATION_LEFT = 2;
    public static final int KEY_LOCATION_RIGHT = 3;
    public static final int KEY_LOCATION_NUMPAD = 4;
    public static final int VC_ESCAPE = 1;
    public static final int VC_F1 = 59;
    public static final int VC_F2 = 60;
    public static final int VC_F3 = 61;
    public static final int VC_F4 = 62;
    public static final int VC_F5 = 63;
    public static final int VC_F6 = 64;
    public static final int VC_F7 = 65;
    public static final int VC_F8 = 66;
    public static final int VC_F9 = 67;
    public static final int VC_F10 = 68;
    public static final int VC_F11 = 87;
    public static final int VC_F12 = 88;
    public static final int VC_F13 = 91;
    public static final int VC_F14 = 92;
    public static final int VC_F15 = 93;
    public static final int VC_F16 = 99;
    public static final int VC_F17 = 100;
    public static final int VC_F18 = 101;
    public static final int VC_F19 = 102;
    public static final int VC_F20 = 103;
    public static final int VC_F21 = 104;
    public static final int VC_F22 = 105;
    public static final int VC_F23 = 106;
    public static final int VC_F24 = 107;
    public static final int VC_BACKQUOTE = 41;
    public static final int VC_1 = 2;
    public static final int VC_2 = 3;
    public static final int VC_3 = 4;
    public static final int VC_4 = 5;
    public static final int VC_5 = 6;
    public static final int VC_6 = 7;
    public static final int VC_7 = 8;
    public static final int VC_8 = 9;
    public static final int VC_9 = 10;
    public static final int VC_0 = 11;
    public static final int VC_MINUS = 12;
    public static final int VC_EQUALS = 13;
    public static final int VC_BACKSPACE = 14;
    public static final int VC_TAB = 15;
    public static final int VC_CAPS_LOCK = 58;
    public static final int VC_A = 30;
    public static final int VC_B = 48;
    public static final int VC_C = 46;
    public static final int VC_D = 32;
    public static final int VC_E = 18;
    public static final int VC_F = 33;
    public static final int VC_G = 34;
    public static final int VC_H = 35;
    public static final int VC_I = 23;
    public static final int VC_J = 36;
    public static final int VC_K = 37;
    public static final int VC_L = 38;
    public static final int VC_M = 50;
    public static final int VC_N = 49;
    public static final int VC_O = 24;
    public static final int VC_P = 25;
    public static final int VC_Q = 16;
    public static final int VC_R = 19;
    public static final int VC_S = 31;
    public static final int VC_T = 20;
    public static final int VC_U = 22;
    public static final int VC_V = 47;
    public static final int VC_W = 17;
    public static final int VC_X = 45;
    public static final int VC_Y = 21;
    public static final int VC_Z = 44;
    public static final int VC_OPEN_BRACKET = 26;
    public static final int VC_CLOSE_BRACKET = 27;
    public static final int VC_BACK_SLASH = 43;
    public static final int VC_SEMICOLON = 39;
    public static final int VC_QUOTE = 40;
    public static final int VC_ENTER = 28;
    public static final int VC_COMMA = 51;
    public static final int VC_PERIOD = 52;
    public static final int VC_SLASH = 53;
    public static final int VC_SPACE = 57;
    public static final int VC_PRINTSCREEN = 3639;
    public static final int VC_SCROLL_LOCK = 70;
    public static final int VC_PAUSE = 3653;
    public static final int VC_INSERT = 3666;
    public static final int VC_DELETE = 3667;
    public static final int VC_HOME = 3655;
    public static final int VC_END = 3663;
    public static final int VC_PAGE_UP = 3657;
    public static final int VC_PAGE_DOWN = 3665;
    public static final int VC_UP = 57416;
    public static final int VC_LEFT = 57419;
    public static final int VC_CLEAR = 57420;
    public static final int VC_RIGHT = 57421;
    public static final int VC_DOWN = 57424;
    public static final int VC_NUM_LOCK = 69;
    public static final int VC_SEPARATOR = 83;
    public static final int VC_SHIFT = 42;
    public static final int VC_CONTROL = 29;
    public static final int VC_ALT = 56;
    public static final int VC_META = 3675;
    public static final int VC_CONTEXT_MENU = 3677;
    public static final int VC_POWER = 57438;
    public static final int VC_SLEEP = 57439;
    public static final int VC_WAKE = 57443;
    public static final int VC_MEDIA_PLAY = 57378;
    public static final int VC_MEDIA_STOP = 57380;
    public static final int VC_MEDIA_PREVIOUS = 57360;
    public static final int VC_MEDIA_NEXT = 57369;
    public static final int VC_MEDIA_SELECT = 57453;
    public static final int VC_MEDIA_EJECT = 57388;
    public static final int VC_VOLUME_MUTE = 57376;
    public static final int VC_VOLUME_UP = 57392;
    public static final int VC_VOLUME_DOWN = 57390;
    public static final int VC_APP_MAIL = 57452;
    public static final int VC_APP_CALCULATOR = 57377;
    public static final int VC_APP_MUSIC = 57404;
    public static final int VC_APP_PICTURES = 57444;
    public static final int VC_BROWSER_SEARCH = 57445;
    public static final int VC_BROWSER_HOME = 57394;
    public static final int VC_BROWSER_BACK = 57450;
    public static final int VC_BROWSER_FORWARD = 57449;
    public static final int VC_BROWSER_STOP = 57448;
    public static final int VC_BROWSER_REFRESH = 57447;
    public static final int VC_BROWSER_FAVORITES = 57446;
    public static final int VC_KATAKANA = 112;
    public static final int VC_UNDERSCORE = 115;
    public static final int VC_FURIGANA = 119;
    public static final int VC_KANJI = 121;
    public static final int VC_HIRAGANA = 123;
    public static final int VC_YEN = 125;
    public static final int VC_SUN_HELP = 65397;
    public static final int VC_SUN_STOP = 65400;
    public static final int VC_SUN_PROPS = 65398;
    public static final int VC_SUN_FRONT = 65399;
    public static final int VC_SUN_OPEN = 65396;
    public static final int VC_SUN_FIND = 65406;
    public static final int VC_SUN_AGAIN = 65401;
    public static final int VC_SUN_UNDO = 65402;
    public static final int VC_SUN_COPY = 65404;
    public static final int VC_SUN_INSERT = 65405;
    public static final int VC_SUN_CUT = 65403;
    public static final int VC_UNDEFINED = 0;
    public static final char CHAR_UNDEFINED = '\uffff';
    private static boolean a;
    private static final String[] d;
    private static final String[] e;
    
    public NativeKeyEvent(final int p0, final int p1, final int p2, final int p3, final char p4, final int p5) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc             Lorg/jnativehook/GlobalScreen;.class
        //     3: iload_1        
        //     4: iload_2        
        //     5: invokespecial   org/jnativehook/NativeInputEvent.<init>:(Ljava/lang/Class;II)V
        //     8: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.c:()Z
        //    11: aload_0        
        //    12: iload_3        
        //    13: putfield        org/jnativehook/keyboard/NativeKeyEvent.rawCode:I
        //    16: aload_0        
        //    17: iload           4
        //    19: putfield        org/jnativehook/keyboard/NativeKeyEvent.keyCode:I
        //    22: istore          7
        //    24: aload_0        
        //    25: iload           5
        //    27: putfield        org/jnativehook/keyboard/NativeKeyEvent.keyChar:C
        //    30: aload_0        
        //    31: iload           6
        //    33: putfield        org/jnativehook/keyboard/NativeKeyEvent.keyLocation:I
        //    36: iload_1        
        //    37: sipush          2400
        //    40: iload           7
        //    42: ifeq            102
        //    45: iload           7
        //    47: ifeq            102
        //    50: goto            57
        //    53: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    56: athrow         
        //    57: if_icmpne       122
        //    60: goto            67
        //    63: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    66: athrow         
        //    67: iload           5
        //    69: iload           7
        //    71: ifeq            107
        //    74: goto            81
        //    77: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    80: athrow         
        //    81: iload           7
        //    83: ifeq            107
        //    86: goto            93
        //    89: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    92: athrow         
        //    93: ldc             65535
        //    95: goto            102
        //    98: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   101: athrow         
        //   102: if_icmpeq       110
        //   105: iload           4
        //   107: ifeq            122
        //   110: new             Ljava/lang/IllegalArgumentException;
        //   113: dup            
        //   114: invokespecial   java/lang/IllegalArgumentException.<init>:()V
        //   117: athrow         
        //   118: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   121: athrow         
        //   122: return         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  24     50     53     57     Ljava/lang/IllegalArgumentException;
        //  45     60     63     67     Ljava/lang/IllegalArgumentException;
        //  57     74     77     81     Ljava/lang/IllegalArgumentException;
        //  67     86     89     93     Ljava/lang/IllegalArgumentException;
        //  81     95     98     102    Ljava/lang/IllegalArgumentException;
        //  107    118    118    122    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0057:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public NativeKeyEvent(final int n, final int n2, final int n3, final int n4, final char c) {
        this(n, n2, n3, n4, c, 0);
    }
    
    public int getRawCode() {
        return this.rawCode;
    }
    
    public void setRawCode(final int rawCode) {
        this.rawCode = rawCode;
    }
    
    public int getKeyCode() {
        return this.keyCode;
    }
    
    public void setKeyCode(final int keyCode) {
        this.keyCode = keyCode;
    }
    
    public char getKeyChar() {
        return this.keyChar;
    }
    
    public void setKeyChar(final char keyChar) {
        this.keyChar = keyChar;
    }
    
    public int getKeyLocation() {
        return this.keyLocation;
    }
    
    public static String getKeyText(final int i) {
        final boolean d = d();
        Label_3474: {
            try {
                switch (i) {
                    case 1: {
                        Toolkit.getProperty(b(-13219, 941), b(-13264, 8912));
                        break;
                    }
                    case 59: {
                        return Toolkit.getProperty(b(-13290, 22474), b(-13284, 18945));
                    }
                    case 60: {
                        return Toolkit.getProperty(b(-13271, -232), b(-13181, -13352));
                    }
                    case 61: {
                        return Toolkit.getProperty(b(-13154, -11026), b(-13177, -1239));
                    }
                    case 62: {
                        return Toolkit.getProperty(b(-13156, -24826), b(-13276, 19545));
                    }
                    case 63: {
                        return Toolkit.getProperty(b(-13071, -10996), b(-13228, 28477));
                    }
                    case 64: {
                        return Toolkit.getProperty(b(-13292, -1286), b(-13197, 16464));
                    }
                    case 65: {
                        return Toolkit.getProperty(b(-13141, 2466), b(-13277, -19580));
                    }
                    case 66: {
                        return Toolkit.getProperty(b(-13243, 31951), b(-13263, -10381));
                    }
                    case 67: {
                        return Toolkit.getProperty(b(-13191, 6368), b(-13246, -19621));
                    }
                    case 68: {
                        return Toolkit.getProperty(b(-13075, -2006), b(-13077, 8265));
                    }
                    case 87: {
                        return Toolkit.getProperty(b(-13305, 26084), b(-13147, -12598));
                    }
                    case 88: {
                        return Toolkit.getProperty(b(-13227, 1223), b(-13066, -5763));
                    }
                    case 91: {
                        return Toolkit.getProperty(b(-13244, 7825), b(-13198, 16277));
                    }
                    case 92: {
                        return Toolkit.getProperty(b(-13190, -22338), b(-13270, 37));
                    }
                    case 93: {
                        return Toolkit.getProperty(b(-13289, 9672), b(-13192, -9526));
                    }
                    case 99: {
                        return Toolkit.getProperty(b(-13280, -29338), b(-13199, 10225));
                    }
                    case 100: {
                        return Toolkit.getProperty(b(-13258, -31763), b(-13184, 6829));
                    }
                    case 101: {
                        return Toolkit.getProperty(b(-13080, 11714), b(-13125, 10344));
                    }
                    case 102: {
                        return Toolkit.getProperty(b(-13259, 6246), b(-13301, -25524));
                    }
                    case 103: {
                        return Toolkit.getProperty(b(-13064, -23017), b(-13302, 13047));
                    }
                    case 104: {
                        return Toolkit.getProperty(b(-13134, 26373), b(-13131, -3916));
                    }
                    case 105: {
                        return Toolkit.getProperty(b(-13288, -3559), b(-13274, -10384));
                    }
                    case 106: {
                        return Toolkit.getProperty(b(-13065, -3474), b(-13241, -777));
                    }
                    case 107: {
                        return Toolkit.getProperty(b(-13265, 16523), b(-13268, -25037));
                    }
                    case 41: {
                        return Toolkit.getProperty(b(-13308, 21823), b(-13060, -27401));
                    }
                    case 2: {
                        return "1";
                    }
                    case 3: {
                        return "2";
                    }
                    case 4: {
                        return "3";
                    }
                    case 5: {
                        return "4";
                    }
                    case 6: {
                        return "5";
                    }
                    case 7: {
                        return "6";
                    }
                    case 8: {
                        return "7";
                    }
                    case 9: {
                        return "8";
                    }
                    case 10: {
                        return "9";
                    }
                    case 11: {
                        return "0";
                    }
                    case 12: {
                        return Toolkit.getProperty(b(-13132, -9142), b(-13253, 19380));
                    }
                    case 13: {
                        return Toolkit.getProperty(b(-13201, -19633), b(-13214, 26471));
                    }
                    case 14: {
                        return Toolkit.getProperty(b(-13162, 7879), b(-13213, 1065));
                    }
                    case 15: {
                        return Toolkit.getProperty(b(-13149, 26929), b(-13209, 6896));
                    }
                    case 58: {
                        return Toolkit.getProperty(b(-13293, 28226), b(-13236, 29093));
                    }
                    case 30: {
                        return "A";
                    }
                    case 48: {
                        return "B";
                    }
                    case 46: {
                        return "C";
                    }
                    case 32: {
                        return "D";
                    }
                    case 18: {
                        return "E";
                    }
                    case 33: {
                        return "F";
                    }
                    case 34: {
                        return "G";
                    }
                    case 35: {
                        return "H";
                    }
                    case 23: {
                        return "I";
                    }
                    case 36: {
                        return "J";
                    }
                    case 37: {
                        return "K";
                    }
                    case 38: {
                        return "L";
                    }
                    case 50: {
                        return "M";
                    }
                    case 49: {
                        return "N";
                    }
                    case 24: {
                        return "O";
                    }
                    case 25: {
                        return "P";
                    }
                    case 16: {
                        return "Q";
                    }
                    case 19: {
                        return "R";
                    }
                    case 31: {
                        return "S";
                    }
                    case 20: {
                        return "T";
                    }
                    case 22: {
                        return "U";
                    }
                    case 47: {
                        return "V";
                    }
                    case 17: {
                        return "W";
                    }
                    case 45: {
                        return "X";
                    }
                    case 21: {
                        return "Y";
                    }
                    case 44: {
                        return "Z";
                    }
                    case 26: {
                        return Toolkit.getProperty(b(-13151, 11677), b(-13160, -28481));
                    }
                    case 27: {
                        return Toolkit.getProperty(b(-13230, -8842), b(-13200, 11304));
                    }
                    case 43: {
                        return Toolkit.getProperty(b(-13255, -2406), b(-13166, -30426));
                    }
                    case 39: {
                        return Toolkit.getProperty(b(-13249, 24837), b(-13150, 3384));
                    }
                    case 40: {
                        return Toolkit.getProperty(b(-13123, -26591), b(-13144, -27312));
                    }
                    case 28: {
                        return Toolkit.getProperty(b(-13152, -8526), b(-13170, -29463));
                    }
                    case 51: {
                        return Toolkit.getProperty(b(-13124, -18834), b(-13180, 29506));
                    }
                    case 52: {
                        return Toolkit.getProperty(b(-13296, -25328), b(-13281, -25042));
                    }
                    case 53: {
                        return Toolkit.getProperty(b(-13298, 16541), b(-13126, -4448));
                    }
                    case 57: {
                        return Toolkit.getProperty(b(-13232, -17802), b(-13061, 23902));
                    }
                    case 3639: {
                        return Toolkit.getProperty(b(-13069, 17093), b(-13278, 10578));
                    }
                    case 70: {
                        return Toolkit.getProperty(b(-13163, -22670), b(-13225, -26795));
                    }
                    case 3653: {
                        return Toolkit.getProperty(b(-13135, -29578), b(-13204, -11209));
                    }
                    case 3666: {
                        return Toolkit.getProperty(b(-13176, 30409), b(-13221, -26584));
                    }
                    case 3667: {
                        return Toolkit.getProperty(b(-13239, -505), b(-13311, -25983));
                    }
                    case 3655: {
                        return Toolkit.getProperty(b(-13133, -19677), b(-13140, 26242));
                    }
                    case 3663: {
                        return Toolkit.getProperty(b(-13205, 12305), b(-13129, 3561));
                    }
                    case 3657: {
                        return Toolkit.getProperty(b(-13257, 28540), b(-13128, -6604));
                    }
                    case 3665: {
                        return Toolkit.getProperty(b(-13062, 26595), b(-13211, 16205));
                    }
                    case 57416: {
                        return Toolkit.getProperty(b(-13231, -5514), b(-13235, 31909));
                    }
                    case 57419: {
                        return Toolkit.getProperty(b(-13252, -5637), b(-13223, 30745));
                    }
                    case 57420: {
                        return Toolkit.getProperty(b(-13297, 30242), b(-13267, 12814));
                    }
                    case 57421: {
                        return Toolkit.getProperty(b(-13286, 5967), b(-13070, -3865));
                    }
                    case 57424: {
                        return Toolkit.getProperty(b(-13272, 976), b(-13250, -19700));
                    }
                    case 69: {
                        return Toolkit.getProperty(b(-13146, -24170), b(-13273, 22756));
                    }
                    case 83: {
                        return Toolkit.getProperty(b(-13283, 4644), b(-13242, 11580));
                    }
                    case 42: {
                        return Toolkit.getProperty(b(-13238, 22426), b(-13266, -6809));
                    }
                    case 29: {
                        return Toolkit.getProperty(b(-13057, -22321), b(-13173, -32516));
                    }
                    case 56: {
                        return Toolkit.getProperty(b(-13303, -8475), b(-13058, 6185));
                    }
                    case 3675: {
                        return Toolkit.getProperty(b(-13079, 17026), b(-13275, -18172));
                    }
                    case 3677: {
                        return Toolkit.getProperty(b(-13183, -12030), b(-13248, 561));
                    }
                    case 57438: {
                        return Toolkit.getProperty(b(-13083, -28330), b(-13148, -10396));
                    }
                    case 57439: {
                        return Toolkit.getProperty(b(-13078, -22407), b(-13217, 7124));
                    }
                    case 57443: {
                        return Toolkit.getProperty(b(-13073, -25994), b(-13262, 18869));
                    }
                    case 57378: {
                        return Toolkit.getProperty(b(-13169, -28487), b(-13312, 28527));
                    }
                    case 57380: {
                        return Toolkit.getProperty(b(-13304, -31390), b(-13309, 2336));
                    }
                    case 57360: {
                        return Toolkit.getProperty(b(-13295, -31153), b(-13229, 32079));
                    }
                    case 57369: {
                        return Toolkit.getProperty(b(-13300, -16945), b(-13137, 18515));
                    }
                    case 57453: {
                        return Toolkit.getProperty(b(-13153, 11114), b(-13168, -16936));
                    }
                    case 57388: {
                        return Toolkit.getProperty(b(-13206, 3793), b(-13285, 30618));
                    }
                    case 57376: {
                        return Toolkit.getProperty(b(-13164, 16374), b(-13210, 22587));
                    }
                    case 57392: {
                        return Toolkit.getProperty(b(-13260, -32150), b(-13072, 22406));
                    }
                    case 57390: {
                        return Toolkit.getProperty(b(-13193, -30684), b(-13287, 6301));
                    }
                    case 57452: {
                        return Toolkit.getProperty(b(-13130, 7008), b(-13082, -21873));
                    }
                    case 57377: {
                        return Toolkit.getProperty(b(-13175, 20931), b(-13138, -20534));
                    }
                    case 57404: {
                        return Toolkit.getProperty(b(-13294, -17944), b(-13234, 10905));
                    }
                    case 57444: {
                        return Toolkit.getProperty(b(-13059, 4653), b(-13076, 28581));
                    }
                    case 57445: {
                        return Toolkit.getProperty(b(-13310, -12942), b(-13067, 29722));
                    }
                    case 57394: {
                        return Toolkit.getProperty(b(-13155, 29109), b(-13157, 10298));
                    }
                    case 57450: {
                        return Toolkit.getProperty(b(-13220, -23103), b(-13224, 21365));
                    }
                    case 57449: {
                        return Toolkit.getProperty(b(-13215, 31760), b(-13143, -7819));
                    }
                    case 57448: {
                        return Toolkit.getProperty(b(-13304, -31390), b(-13179, -15502));
                    }
                    case 57447: {
                        return Toolkit.getProperty(b(-13216, 24286), b(-13187, 4879));
                    }
                    case 57446: {
                        return Toolkit.getProperty(b(-13279, -6984), b(-13218, -12259));
                    }
                    case 112: {
                        return Toolkit.getProperty(b(-13222, 54), b(-13306, -6616));
                    }
                    case 115: {
                        return Toolkit.getProperty(b(-13254, -13371), b(-13068, 15125));
                    }
                    case 119: {
                        return Toolkit.getProperty(b(-13182, -27678), b(-13207, -6966));
                    }
                    case 121: {
                        return Toolkit.getProperty(b(-13203, 3710), b(-13189, -13615));
                    }
                    case 123: {
                        return Toolkit.getProperty(b(-13237, 6977), b(-13195, -3333));
                    }
                    case 125: {
                        return Toolkit.getProperty(b(-13196, -14064), Character.toString('¥'));
                    }
                    case 65397: {
                        return Toolkit.getProperty(b(-13251, 18098), b(-13063, -3282));
                    }
                    case 65400: {
                        return Toolkit.getProperty(b(-13121, 19158), b(-13233, -27680));
                    }
                    case 65398: {
                        return Toolkit.getProperty(b(-13172, -8534), b(-13299, -23398));
                    }
                    case 65399: {
                        return Toolkit.getProperty(b(-13174, 27673), b(-13145, 5417));
                    }
                    case 65396: {
                        return Toolkit.getProperty(b(-13202, -24628), b(-13081, 10895));
                    }
                    case 65406: {
                        return Toolkit.getProperty(b(-13178, -6356), b(-13194, -14150));
                    }
                    case 65401: {
                        return Toolkit.getProperty(b(-13226, 25258), b(-13127, 11305));
                    }
                    case 65404: {
                        return Toolkit.getProperty(b(-13185, -12144), b(-13158, -2975));
                    }
                    case 65405: {
                        return Toolkit.getProperty(b(-13142, -16476), b(-13171, -1831));
                    }
                    case 65403: {
                        return Toolkit.getProperty(b(-13247, 30385), b(-13188, 11146));
                    }
                    case 0: {
                        return Toolkit.getProperty(b(-13282, -5881), b(-13186, 1721));
                    }
                    default: {
                        break Label_3474;
                    }
                }
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            return;
        }
        final String string = Toolkit.getProperty(b(-13084, 20938), b(-13074, -27684)) + b(-13291, -8139) + Integer.toString(i, 16);
        if (!d) {
            return string;
        }
        return string;
    }
    
    public boolean isActionKey() {
        final boolean d = d();
        int keyCode = 0;
        Label_0678: {
            try {
                keyCode = this.keyCode;
                if (d) {
                    return keyCode != 0;
                }
                switch (keyCode) {
                    case 29:
                    case 42:
                    case 56:
                    case 58:
                    case 59:
                    case 60:
                    case 61:
                    case 62:
                    case 63:
                    case 64:
                    case 65:
                    case 66:
                    case 67:
                    case 68:
                    case 69:
                    case 70:
                    case 87:
                    case 88:
                    case 91:
                    case 92:
                    case 93:
                    case 99:
                    case 100:
                    case 101:
                    case 102:
                    case 103:
                    case 104:
                    case 105:
                    case 106:
                    case 107:
                    case 112:
                    case 119:
                    case 121:
                    case 123:
                    case 3639:
                    case 3655:
                    case 3657:
                    case 3663:
                    case 3665:
                    case 3666:
                    case 3675:
                    case 3677:
                    case 57360:
                    case 57369:
                    case 57376:
                    case 57377:
                    case 57378:
                    case 57380:
                    case 57388:
                    case 57390:
                    case 57392:
                    case 57394:
                    case 57404:
                    case 57416:
                    case 57419:
                    case 57420:
                    case 57421:
                    case 57424:
                    case 57438:
                    case 57439:
                    case 57443:
                    case 57444:
                    case 57445:
                    case 57446:
                    case 57447:
                    case 57448:
                    case 57449:
                    case 57450:
                    case 57452:
                    case 57453:
                    case 65396:
                    case 65397:
                    case 65398:
                    case 65399:
                    case 65400:
                    case 65401:
                    case 65402:
                    case 65403:
                    case 65404:
                    case 65405:
                    case 65406: {
                        break;
                    }
                    default: {
                        break Label_0678;
                    }
                }
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            return true;
        }
        final boolean b = false;
        if (d) {
            return b;
        }
        return keyCode != 0;
    }
    
    @Override
    public String paramString() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_1       
        //     4: new             Ljava/lang/StringBuilder;
        //     7: dup            
        //     8: sipush          255
        //    11: invokespecial   java/lang/StringBuilder.<init>:(I)V
        //    14: astore_3       
        //    15: iload_1        
        //    16: ifne            73
        //    19: aload_0        
        //    20: invokevirtual   org/jnativehook/keyboard/NativeKeyEvent.getID:()I
        //    23: tableswitch {
        //             4800: 106
        //             4801: 52
        //             4802: 88
        //          default: 131
        //        }
        //    48: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    51: athrow         
        //    52: aload_3        
        //    53: sipush          -13307
        //    56: sipush          -20513
        //    59: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //    62: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    65: goto            72
        //    68: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    71: athrow         
        //    72: pop            
        //    73: iload_1        
        //    74: ifeq            156
        //    77: invokestatic    com/sun/jna/Structure.b:()I
        //    80: istore_2       
        //    81: iinc            2, 1
        //    84: iload_2        
        //    85: invokestatic    com/sun/jna/Structure.b:(I)V
        //    88: aload_3        
        //    89: sipush          -13165
        //    92: sipush          -184
        //    95: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //    98: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   101: pop            
        //   102: iload_1        
        //   103: ifeq            156
        //   106: aload_3        
        //   107: sipush          -13240
        //   110: sipush          15783
        //   113: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //   116: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   119: pop            
        //   120: iload_1        
        //   121: ifeq            156
        //   124: goto            131
        //   127: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   130: athrow         
        //   131: aload_3        
        //   132: sipush          -13161
        //   135: sipush          -27373
        //   138: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //   141: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   144: iload_1        
        //   145: ifne            72
        //   148: goto            155
        //   151: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   154: athrow         
        //   155: pop            
        //   156: aload_3        
        //   157: bipush          44
        //   159: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   162: pop            
        //   163: aload_3        
        //   164: sipush          -13136
        //   167: sipush          -14746
        //   170: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //   173: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   176: pop            
        //   177: aload_3        
        //   178: aload_0        
        //   179: getfield        org/jnativehook/keyboard/NativeKeyEvent.keyCode:I
        //   182: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //   185: pop            
        //   186: aload_3        
        //   187: bipush          44
        //   189: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   192: pop            
        //   193: aload_3        
        //   194: sipush          -13167
        //   197: sipush          21711
        //   200: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //   203: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   206: pop            
        //   207: aload_3        
        //   208: aload_0        
        //   209: getfield        org/jnativehook/keyboard/NativeKeyEvent.keyCode:I
        //   212: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.getKeyText:(I)Ljava/lang/String;
        //   215: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   218: pop            
        //   219: aload_3        
        //   220: bipush          44
        //   222: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   225: pop            
        //   226: aload_3        
        //   227: sipush          -13256
        //   230: sipush          20455
        //   233: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //   236: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   239: pop            
        //   240: iload_1        
        //   241: ifne            371
        //   244: aload_0        
        //   245: getfield        org/jnativehook/keyboard/NativeKeyEvent.keyChar:C
        //   248: lookupswitch {
        //                1: 312
        //               14: 312
        //               15: 312
        //               28: 312
        //             3667: 312
        //            65535: 335
        //          default: 348
        //        }
        //   308: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   311: athrow         
        //   312: aload_3        
        //   313: aload_0        
        //   314: getfield        org/jnativehook/keyboard/NativeKeyEvent.keyChar:C
        //   317: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.getKeyText:(I)Ljava/lang/String;
        //   320: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   323: goto            330
        //   326: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   329: athrow         
        //   330: pop            
        //   331: iload_1        
        //   332: ifeq            382
        //   335: aload_3        
        //   336: iconst_0       
        //   337: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.getKeyText:(I)Ljava/lang/String;
        //   340: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   343: pop            
        //   344: iload_1        
        //   345: ifeq            382
        //   348: aload_3        
        //   349: bipush          39
        //   351: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   354: pop            
        //   355: aload_3        
        //   356: aload_0        
        //   357: getfield        org/jnativehook/keyboard/NativeKeyEvent.keyChar:C
        //   360: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   363: pop            
        //   364: goto            371
        //   367: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   370: athrow         
        //   371: aload_3        
        //   372: bipush          39
        //   374: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   377: iload_1        
        //   378: ifne            330
        //   381: pop            
        //   382: aload_3        
        //   383: bipush          44
        //   385: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   388: pop            
        //   389: aload_0        
        //   390: invokevirtual   org/jnativehook/keyboard/NativeKeyEvent.getModifiers:()I
        //   393: iload_1        
        //   394: ifne            480
        //   397: ifeq            447
        //   400: goto            407
        //   403: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   406: athrow         
        //   407: aload_3        
        //   408: sipush          -13208
        //   411: sipush          23953
        //   414: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //   417: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   420: pop            
        //   421: aload_3        
        //   422: aload_0        
        //   423: invokevirtual   org/jnativehook/keyboard/NativeKeyEvent.getModifiers:()I
        //   426: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.getModifiersText:(I)Ljava/lang/String;
        //   429: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   432: pop            
        //   433: goto            440
        //   436: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   439: athrow         
        //   440: aload_3        
        //   441: bipush          44
        //   443: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   446: pop            
        //   447: aload_3        
        //   448: sipush          -13269
        //   451: sipush          26626
        //   454: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //   457: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   460: iload_1        
        //   461: ifne            658
        //   464: pop            
        //   465: iload_1        
        //   466: ifne            440
        //   469: goto            476
        //   472: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   475: athrow         
        //   476: aload_0        
        //   477: getfield        org/jnativehook/keyboard/NativeKeyEvent.keyLocation:I
        //   480: tableswitch {
        //                0: 516
        //                1: 541
        //                2: 559
        //                3: 584
        //                4: 609
        //          default: 634
        //        }
        //   516: aload_3        
        //   517: sipush          -13212
        //   520: sipush          -17178
        //   523: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //   526: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   529: goto            536
        //   532: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   535: athrow         
        //   536: pop            
        //   537: iload_1        
        //   538: ifeq            659
        //   541: aload_3        
        //   542: sipush          -13245
        //   545: sipush          -20459
        //   548: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //   551: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   554: pop            
        //   555: iload_1        
        //   556: ifeq            659
        //   559: aload_3        
        //   560: sipush          -13159
        //   563: sipush          -12349
        //   566: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //   569: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   572: pop            
        //   573: iload_1        
        //   574: ifeq            659
        //   577: goto            584
        //   580: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   583: athrow         
        //   584: aload_3        
        //   585: sipush          -13139
        //   588: sipush          5252
        //   591: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //   594: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   597: pop            
        //   598: iload_1        
        //   599: ifeq            659
        //   602: goto            609
        //   605: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   608: athrow         
        //   609: aload_3        
        //   610: sipush          -13122
        //   613: sipush          28689
        //   616: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //   619: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   622: pop            
        //   623: iload_1        
        //   624: ifeq            659
        //   627: goto            634
        //   630: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   633: athrow         
        //   634: aload_3        
        //   635: sipush          -13212
        //   638: sipush          -17178
        //   641: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //   644: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   647: iload_1        
        //   648: ifne            536
        //   651: goto            658
        //   654: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   657: athrow         
        //   658: pop            
        //   659: aload_3        
        //   660: bipush          44
        //   662: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   665: pop            
        //   666: aload_3        
        //   667: sipush          -13261
        //   670: sipush          -16177
        //   673: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.b:(II)Ljava/lang/String;
        //   676: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   679: pop            
        //   680: aload_3        
        //   681: aload_0        
        //   682: getfield        org/jnativehook/keyboard/NativeKeyEvent.rawCode:I
        //   685: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //   688: pop            
        //   689: aload_3        
        //   690: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   693: areturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  15     48     48     52     Ljava/lang/IllegalArgumentException;
        //  19     65     68     72     Ljava/lang/IllegalArgumentException;
        //  88     124    127    131    Ljava/lang/IllegalArgumentException;
        //  106    148    151    155    Ljava/lang/IllegalArgumentException;
        //  156    308    308    312    Ljava/lang/IllegalArgumentException;
        //  244    323    326    330    Ljava/lang/IllegalArgumentException;
        //  335    364    367    371    Ljava/lang/IllegalArgumentException;
        //  382    400    403    407    Ljava/lang/IllegalArgumentException;
        //  397    433    436    440    Ljava/lang/IllegalArgumentException;
        //  447    469    472    476    Ljava/lang/IllegalArgumentException;
        //  480    529    532    536    Ljava/lang/IllegalArgumentException;
        //  541    577    580    584    Ljava/lang/IllegalArgumentException;
        //  559    602    605    609    Ljava/lang/IllegalArgumentException;
        //  584    627    630    634    Ljava/lang/IllegalArgumentException;
        //  609    651    654    658    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0106:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void b(final boolean a) {
        NativeKeyEvent.a = a;
    }
    
    public static boolean c() {
        return NativeKeyEvent.a;
    }
    
    public static boolean d() {
        final boolean c = c();
        try {
            if (!c) {
                return true;
            }
        }
        catch (IllegalArgumentException ex) {
            throw b(ex);
        }
        return false;
    }
    
    private static IllegalArgumentException b(final IllegalArgumentException ex) {
        return ex;
    }
    
    static {
        final String[] d2 = new String[220];
        int n = 0;
        final String s;
        final int length = (s = "\u00f2\u00d94(\u0019\u00f1\u00e3\u00e4\f\u00cek³~\u00f6+\u00ea\u0086\u00f5V7^\u0004\u00f0-\u00f2\u00c9\rz?%\u00f4$j³\u008a¶-5eS\b0¹.=\u00d6\u0097\u008a\u00e5\r\u0016\u008b¨b\u0084¼\u009a\u00d6l\u00e7UC\u00f5\u000epOd\u00fa\n ¹µ\u00ce[\u00064\u00c7&\u0005\u00c5We[Q\t\u00d4\u0085\u00f0£\u009b\u008a\u00e0\u00c1\u00ee\u0007#¬\u000e\u0086Tp^\u0007\u00f8wu\u00fd;\u001f½\bl¦\u00e7\u00c7\u007f\u000e£]\u0006\u00ee¡\u0004\u00c8\u00d2K\u0002]¨\u0004r\u00c7\u00cfP\b\u00cc\u00ef\u0085sk[\u00cd\u00d9\u0003\u0005\u00e1M\u0005oC\u00f4h\b\u0005ª R\u0087W\u0007?]\u008d¸$´]\b\u0087s\u009a}\u00c4Q@¡\u0006y©E&=g\u0003m\u00ea@\f\u00dcg³\u00e9b\u00e1\u00e8 Z\u00c6\u00e1J\u0002\u007f1\u0004\u0002x\u0087'\u00036\u00f4-\b{\u00e3\u00d2\u0007\u00fb\u00d1\u009e´\u0007\u00f9\u00e9U.?e<\r %n·X\u0006\u0090\u0085»\f¿\u008d\u0004\f»\u00ed\u0013o\u007f\u0014\u0001¢\bi\u00d8§\u0002?N\u0002\u0098w\r\u00e9>W\u00d4jng\u0002\u0083;¸h\u00e5\r\u00f0+tv\b1\u00f9\u0087\u00d2\u0007\u001e\u00ec~\u0006Q\u00fbU_\u00d4±\u0007\u0014\u0004\u00e8\u0093\u0088\u00d1\u00ce\u000bS\u00ce\u00cd®\u0018\u0011¤\u00c8¼\u00f5\u00fb\t¨\u00d9\u007f(n\u00fd\u00d1\u00f4¦\u0005¦\u00cb\u000b½\u00f1\u0006\u001b\"\tW´M\f\u0089F'7C¥`4½8zv\u0006V\u009a @\u0081¨\u0007\u00c8¬s\u0086\u00fbp§\no\u00c5\u0087«s\u0081%\u00f7\u0094\u0089\f¨¦\u007f\u00c7l\u001b\u00d1N\u00f9I\u008e\u00f5\r\u001c\u0014\u00e9\u0091¯\u00d3\u008f<\u0081\u0011\u0003½d\f\u00c7\u008a\u0092B\u00c2¸`N]\u00ec\u008dY\b¾\u0095½¡*\u00c0\u00d9\u00c2\tF5\u00c8\u00dd\u00c7\u0097\u008a\u00d9\u00c3\tO\u009b\u0083`\u00f0\u00f1%\u00cb\u00e2\t\u00fd¸\u00d5\u0004*}hH\u00d5\b\u00cd\u0099\u00d3 \u00fa\u00e1j\u00d1\u0007\u00d8\u00f8q\f¼|\u00e9\u0003CS\u0081\u0003\u0095}R\rQ\u001e@\u00d0\u0099\u00ea9\u001c\u001a§\u00d7vg\u0012n\u009eIs\u008c1\u0015\u00e70\u00d04\u0015\u001a\u00fao\u0082\u00c6\u00ad\b¬\u00eb\u0094\u00d1.l\u00ea\u00c6\u0007\u001f©\u0089&¤dH\u0004\u00ff\u00ec\u0093\u0085\u0006\u00e2\u00cb«U\u00cd|\n:\u00fc-\u008c%e\u009fp¾\r\u0004DU\u0089 \u0007\u00e2J\\2Fm\u00d0\u000fZAy\u00e3\u00f3\u00faV\u00d1\u00c7,\u0006\u0013ujh\tp1\u00c2`\u00fb\u00d6\u00fc\u009c;\f£Z\u001eXC\u00ef\\\u001e(O\u00fa?\u0003¾\u00d6;\u0006\u0001\u00f0J\r\u00dc\t\u0007\u00f1\u00d2TI\u001f\u0089:\u0005}\u007f´Hq\u0007º\u00da=H-\u00fd\u00da\b\u00ca\u00cd=\u001c\u00d1\u00d5\u0098\u00f1\b\u0082uP\u00d5\u00c2\u008d\u00ff\u00f6\t\u00e9´W\u0085oN~H#\r\u008a\u008eB\u00c3\u0082?\u009c\u00d6\u009b\u00d2\u00d5\u001d²\u0003\u0080\u0012\u00ff\u0003\u0016\u0014(\u0002P\u001f\u0005\u0004}\u00f8\u0011\u008c\tK\u00e2\u0003O\u00f8\u00190c¯\f;w\r\u00fd![\u0010\u0088\u00ad\u0082\u00d2m\n¨u\u007f½yW\u00d4³N\u001f\n³ª\u0085>\u0013\u0090\u00eaC\u0084>\b¾\u0098|!\u00f9{\u009d$\t\u0097m\u0098¾\u0085,[¦µ\u0007·¯\u009c\u00e6\u0005#J\u0014\u00cc\u00c7µ\u00ca¥\u00d8u\u009b²\u0004G\u0083k\u00e5\u00f0k\u0080\u0080\u00ed\u0082\t)%O\fov\u00e1\u0012³\u0004\u00d1¡\u00fd\n\u0003uUE\u000bU\u00ec\u00c0\u008e\u0099%.xi\u0017\f\u000bo\"\u0087We\u00143\u0010X¾¢\u0006\u0086\u009d\u001f\ry\u00e5\t\u008a\u00dbo\u00dd¼·¬\u008c\u00de\bwR\u0084Y\u0001\u00db*:\n*\u00c9/*s§\u0083\u00efl\u0082\u0011\u0007k\u00d2¦\u0086R\u00f8\u00c4\u0006\u008a¸^§g\u00db®¥\u0005|'\u0084\u00e0\u0004\f\u009bºA\u009c\u00f4\u0015¶,\u00cb\u0097\u0090\u00f9\u0004H\u00ef\u00fd\u00c0\f\u0005f\u00ca\u00df\u00c1\u000b\r*S>\u0082\u00c6\u0006\u009e\u0006\u0097\u0086°\u0017\u0002=·\u0007}\u0003\u00c5s-\u00cez\r¸\u00d9}(/\u00e1\u00d1\u00df\u009b\u007f\u00df ¢\u000b\u00fb¦c4\u0011\u0012¤\u0088¼\u00e0\u00fe\t](\u00c1\u0016¸#,\u001e\u00ce\u0006M\u00c8\u00c3\n\u00fe \u0010]\u00cd\u00c1ª¨¨2\u00e0\u00c2\u0014c\u00c4I\u00f9$.\b'\u00f8\u008c\u00d5\u001c\u0017\u00f5t\t\u00f7\u000e\u00f2\u007f-\u00c4©Y¿\u0002X\u008d\t\u0000\u008fN/\u00d7\u00ce*\fX\b_«\u00eb\u000e \u00eb\u0005\u0090\u0010\u0082<\u00d4'?»c¶\u00fe\u00fa\u00edT*C\u0015\u0015\n\u00f0\u00det\u00c8\u0019\u00ed\u00e0v\u00ea5\t\u0016j¨^\u00952\u0081\"c\f½\u00fe\u00dd\u00cc aTn²¶3\u00d7\u0007R\u0096 \u00c1\u0091\u0098\u00ec\u0006¾\u00d2½I\"\u0080\bQT\u0097\u0081~t\u00e5-\u0003C\u0005\u0082\fWg\u00f8\u009a\u00f4«dEX¾\u0001F\u000bX¤a\u0087¬\u0014¡a\u0097º\t\u0002!\u0099\u0015\u00e6\\\u00f0¹\r¶`V\u0010½\u0013´\u00e1\u0005»»°\u00da\u00fd¿\u00d5\t¡@^\u001b[\u009dN;\u000b\t\u001e¼©\u0084·t\u0081F´\u0013\u0099\u0019\u001f\u0011\u00f0£\u00df\u00f4\u00e7\u00e9\u00ed>>IA\u0080\u00d05)\f~\u00db¥h4\u00e9²\u00de\u00e5LN.\u0007$h\u00ee¥[Rx\t\b\u0006\u0001»\u00efN²L\u0016\u0005L\u00ee\u0086\u00cf\u00d8\u0003\u00fbc\u009e\t\u0083,\u001a\u0096\u00dd*R\u0013\u00f9\u0003\u00d3\u00cc\u0092\f&X®\u0018G\u00e2\u0092\u001a\"\u00c1m4\u0003\u0093K¬\b®/\u00fd\u00ef«\u00c8\u00d5«\t\u00d0\u009fp\u00e0\u008d\u00ec\u00fd\u00c4b\u0007z%%·1U\u00fa\b$\u008d\u00ee¢Fª\u0087\u00d5\u0004«\u00c7\u000e\u009f\u0012c\u00d2@h\u001b\u008c¢\u0011HU\u0018©\u0080§\u008a\u00c8.b\u000e§\u00c2º\u0086G\u00ef\u00e8´\u00ea¢g\u00ec´R\u0004!X\u008c6\u0005'\u00d7§\u00d5>\u000f\u00c0c*§\u0099r\u001b\u00c0z\u00043XA§f\u000e ²~EOL\u00ddj\u0012\u00c0\u00f5\u00f3«\u0084\u0006\u00d5u\u00d0½\u008f\u0011\u0005³T\f\u00edG\u0003-qM\u000b\u0089½[¤\u00f6pW\u00fe&.\u00ad\t\b-\u0001\u00de\u00e8\u00f7»\u00cb\u00e2\t\u00ce\u0083³c\u00e0\u0093\u00e6\u00d37\u000fO\u00e6\u0083\u00cf\u00ec\u0018=tO\b\u0002s\u001cC\u0096\t\u008a¦R\u00f4\u00c4\u00cf¼s{\u0007¤U\u00fe¹X\u00c7\u00d4\u0006\u00d2\u00020S\u0093\u00cf\f\nO+\u00fa\u00fe¡\u0090´\u00c1i¡(\u0006\u00cb\u00d8\u0013\b\u00f7£\n\u00d4,\u00f0\u0096\u009e&\u00e5\u000f]\u000b\f\"c\u00d0\u00fc\u00de\u0004\u00ca\u008ce\u00e0FC\u0011\u00e1\u00cc\u0010«\u0011\u00f4\u00e3\u001e`´\u001d\u0095 >\u0092'¼\b¨\u0016\u0015¹o\u0006\u00f1\\\f.G\u00f7#\"\u00e2l\u00d2\u009aF\u00ff\u0002\bC%\u0002·\u00de\u0012(\u009b\u000e:\u00d6-\u00c9%\u00cb\u008c~¢vym\u00f3\u0003\r}=\u00c5´)f/\u008d\u00da\u0090\u0083\"\"\f\u00d1g\u00dd¡\u00ff\u009aT\u008d>»\u00cdi\u0006eg®\u00c0z\u00df\b\u00d8|3\u0092x\u008e\u00f5\u00fc\n$\u00d5º\u001cU¬¥ªE'\u0013P©\u008e\u0095t\u00ed\n|\u00d3£Hy\u0082<\u009f`\u001a \u0013\r¸U}¹/\u00d3\u00d1\u0099\u008a¢\u00c05\u0093\nbDL\u00f3NN\u009dh¿\u00e7\u0005\u00d8?\u00d5¡\u001f\b¢\u00f0>\rD\\\u00d0t\n\u00e1gV\u00ffP\u0000z¡C\u00de\u0012r\u00f9$,\u0016d¸\u00cai\u00db\u00cex7+;\u0093\u0012z\r\u0014\u009e\u00e8\u00c0\u009d\u00fc\u0087|V\u001e\u008f¼}\u0007\u0098\u001f\u0001\u0095\u00dc]\u008c\u0005t&\u009f«\u007f\f³]D`T\u008a¢\u00dfX\u00fc\u00dd8\f\u008d\u00f1\u00db-\u00fbAK\u00cb\u00cf\u00f3½s\u0002\u008d\u0081\u0003S\u009e\u0084\u000b\u0088\u00fe{\u00cc\u00ffg\u00d9}\u009ez\u00ee\f|\u0094\u00e5\u0081)\u00d4ºOo\u009b\u0088r\u0002[\u0013\n\u001bj]\u00eb©P#y¨\u009f\u0010%c\u00ce\u007fK\u000e\u0013\u0087\u000fz|R\u008f\u0085(\u009c\u0003\u0094\u0081\u00d8\u000b¾\u00fe½\u00cc'g\u00c2}\u00eam\u008d\u0007\b¾k\u00c4\u00f8;\u00c2\b\u00071\u00e0]\u00da\u00901\u00cc\b`\u00ddf¨O\u00e3´\u00fe\u0005\u000b\u0006n]\u00c8\n\u0006\u00c8\f_6+\u00dep\u00c5¾\u000e\b\u00c93\u00f2º\u00d8\u007f\u0095\u00e3¤¤\u0002\u00c0S\u0003\u00d0\u001c\u00f1\u0007¡\u001c^\u0090^±\u0015\t\u00ad\u00ca\u0012.\u00e3\u0001\u00db\u00dbL\u0006H¸c\u0004\u00f9$\u0005©´\u001d:q\u000f\"\u0096.\u00c1F\u00db\u0098N@n\u0011«2k\u0086\f¥\u00e1\u00fa\u00e2\\k\u00f5:§\u0098\u00caq\u0007\u008a\u00e1;/\u00f2E\u0083\u0007\u00c8\u0003\u00da-\u001f\u000bH\b\u00d0\u008dp¢\u008a¤\u00e4\u00db\u0007(\u00faoLx)\u00da\b\u00eb\u0012\u0017Q|\u00de|\u0014\t8.m\u00d6-'\u009a\u0007\u0089\u0003\u00f6G7\u000b\u00c3c\u0012\u007f\u00c4\u0010o¨\u00e7\u0096\u0090\t!\u00d5N©J\u00cb\u0007\u00f9h").length();
        final boolean b = true;
        int char1 = 8;
        int index = -1;
        b(b);
        while (true) {
            int n4;
            int n3;
            final int n2 = n3 = (n4 = 119);
            ++index;
            final String s2 = s;
            final int beginIndex = index;
            final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
            final int length2 = charArray.length;
            int n5 = 0;
            while (true) {
                Label_0154: {
                    if (length2 > 1) {
                        break Label_0154;
                    }
                    n4 = (n3 = n5);
                    do {
                        final char c = charArray[n3];
                        int n6 = 0;
                        switch (n5 % 7) {
                            case 0: {
                                n6 = 94;
                                break;
                            }
                            case 1: {
                                n6 = 113;
                                break;
                            }
                            case 2: {
                                n6 = 5;
                                break;
                            }
                            case 3: {
                                n6 = 55;
                                break;
                            }
                            case 4: {
                                n6 = 20;
                                break;
                            }
                            case 5: {
                                n6 = 5;
                                break;
                            }
                            default: {
                                n6 = 92;
                                break;
                            }
                        }
                        charArray[n4] = (char)(c ^ (n2 ^ n6));
                        ++n5;
                    } while (n2 == 0);
                }
                if (length2 > n5) {
                    continue;
                }
                break;
            }
            d2[n++] = new String(charArray).intern();
            if ((index += char1) >= length) {
                break;
            }
            char1 = s.charAt(index);
        }
        final String s3;
        final int length3 = (s3 = "rq\u0014\u00e4\u0088·\u00cf¤\b'\u00c9\u00f0V\u00cb\u00f0\u00e9}").length();
        int char2 = 8;
        int index2 = -1;
        while (true) {
            int n9;
            int n8;
            final int n7 = n8 = (n9 = 12);
            ++index2;
            final String s4 = s3;
            final int beginIndex2 = index2;
            final char[] charArray2 = s4.substring(beginIndex2, beginIndex2 + char2).toCharArray();
            final int length4 = charArray2.length;
            int n10 = 0;
            while (true) {
                Label_0350: {
                    if (length4 > 1) {
                        break Label_0350;
                    }
                    n9 = (n8 = n10);
                    do {
                        final char c2 = charArray2[n8];
                        int n11 = 0;
                        switch (n10 % 7) {
                            case 0: {
                                n11 = 94;
                                break;
                            }
                            case 1: {
                                n11 = 113;
                                break;
                            }
                            case 2: {
                                n11 = 5;
                                break;
                            }
                            case 3: {
                                n11 = 55;
                                break;
                            }
                            case 4: {
                                n11 = 20;
                                break;
                            }
                            case 5: {
                                n11 = 5;
                                break;
                            }
                            default: {
                                n11 = 92;
                                break;
                            }
                        }
                        charArray2[n9] = (char)(c2 ^ (n7 ^ n11));
                        ++n10;
                    } while (n7 == 0);
                }
                if (length4 > n10) {
                    continue;
                }
                break;
            }
            d2[n++] = new String(charArray2).intern();
            if ((index2 += char2) >= length3) {
                break;
            }
            char2 = s3.charAt(index2);
        }
        d = d2;
        e = new String[220];
    }
    
    private static String b(final int n, final int n2) {
        final int n3 = (n ^ 0xFFFFCC3C) & 0xFFFF;
        if (NativeKeyEvent.e[n3] == null) {
            final char[] charArray = NativeKeyEvent.d[n3].toCharArray();
            int n4 = 0;
            switch (charArray[0] & '\u00ff') {
                case 0: {
                    n4 = 253;
                    break;
                }
                case 1: {
                    n4 = 130;
                    break;
                }
                case 2: {
                    n4 = 182;
                    break;
                }
                case 3: {
                    n4 = 107;
                    break;
                }
                case 4: {
                    n4 = 136;
                    break;
                }
                case 5: {
                    n4 = 54;
                    break;
                }
                case 6: {
                    n4 = 85;
                    break;
                }
                case 7: {
                    n4 = 245;
                    break;
                }
                case 8: {
                    n4 = 13;
                    break;
                }
                case 9: {
                    n4 = 112;
                    break;
                }
                case 10: {
                    n4 = 27;
                    break;
                }
                case 11: {
                    n4 = 123;
                    break;
                }
                case 12: {
                    n4 = 224;
                    break;
                }
                case 13: {
                    n4 = 215;
                    break;
                }
                case 14: {
                    n4 = 241;
                    break;
                }
                case 15: {
                    n4 = 18;
                    break;
                }
                case 16: {
                    n4 = 160;
                    break;
                }
                case 17: {
                    n4 = 41;
                    break;
                }
                case 18: {
                    n4 = 121;
                    break;
                }
                case 19: {
                    n4 = 32;
                    break;
                }
                case 20: {
                    n4 = 235;
                    break;
                }
                case 21: {
                    n4 = 238;
                    break;
                }
                case 22: {
                    n4 = 52;
                    break;
                }
                case 23: {
                    n4 = 48;
                    break;
                }
                case 24: {
                    n4 = 14;
                    break;
                }
                case 25: {
                    n4 = 117;
                    break;
                }
                case 26: {
                    n4 = 159;
                    break;
                }
                case 27: {
                    n4 = 99;
                    break;
                }
                case 28: {
                    n4 = 166;
                    break;
                }
                case 29: {
                    n4 = 66;
                    break;
                }
                case 30: {
                    n4 = 5;
                    break;
                }
                case 31: {
                    n4 = 23;
                    break;
                }
                case 32: {
                    n4 = 46;
                    break;
                }
                case 33: {
                    n4 = 183;
                    break;
                }
                case 34: {
                    n4 = 237;
                    break;
                }
                case 35: {
                    n4 = 83;
                    break;
                }
                case 36: {
                    n4 = 115;
                    break;
                }
                case 37: {
                    n4 = 4;
                    break;
                }
                case 38: {
                    n4 = 142;
                    break;
                }
                case 39: {
                    n4 = 252;
                    break;
                }
                case 40: {
                    n4 = 119;
                    break;
                }
                case 41: {
                    n4 = 49;
                    break;
                }
                case 42: {
                    n4 = 227;
                    break;
                }
                case 43: {
                    n4 = 158;
                    break;
                }
                case 44: {
                    n4 = 201;
                    break;
                }
                case 45: {
                    n4 = 186;
                    break;
                }
                case 46: {
                    n4 = 177;
                    break;
                }
                case 47: {
                    n4 = 155;
                    break;
                }
                case 48: {
                    n4 = 3;
                    break;
                }
                case 49: {
                    n4 = 153;
                    break;
                }
                case 50: {
                    n4 = 135;
                    break;
                }
                case 51: {
                    n4 = 16;
                    break;
                }
                case 52: {
                    n4 = 128;
                    break;
                }
                case 53: {
                    n4 = 116;
                    break;
                }
                case 54: {
                    n4 = 109;
                    break;
                }
                case 55: {
                    n4 = 171;
                    break;
                }
                case 56: {
                    n4 = 44;
                    break;
                }
                case 57: {
                    n4 = 103;
                    break;
                }
                case 58: {
                    n4 = 188;
                    break;
                }
                case 59: {
                    n4 = 33;
                    break;
                }
                case 60: {
                    n4 = 86;
                    break;
                }
                case 61: {
                    n4 = 157;
                    break;
                }
                case 62: {
                    n4 = 38;
                    break;
                }
                case 63: {
                    n4 = 28;
                    break;
                }
                case 64: {
                    n4 = 92;
                    break;
                }
                case 65: {
                    n4 = 88;
                    break;
                }
                case 66: {
                    n4 = 254;
                    break;
                }
                case 67: {
                    n4 = 47;
                    break;
                }
                case 68: {
                    n4 = 35;
                    break;
                }
                case 69: {
                    n4 = 120;
                    break;
                }
                case 70: {
                    n4 = 9;
                    break;
                }
                case 71: {
                    n4 = 214;
                    break;
                }
                case 72: {
                    n4 = 60;
                    break;
                }
                case 73: {
                    n4 = 219;
                    break;
                }
                case 74: {
                    n4 = 131;
                    break;
                }
                case 75: {
                    n4 = 193;
                    break;
                }
                case 76: {
                    n4 = 185;
                    break;
                }
                case 77: {
                    n4 = 57;
                    break;
                }
                case 78: {
                    n4 = 211;
                    break;
                }
                case 79: {
                    n4 = 196;
                    break;
                }
                case 80: {
                    n4 = 7;
                    break;
                }
                case 81: {
                    n4 = 172;
                    break;
                }
                case 82: {
                    n4 = 200;
                    break;
                }
                case 83: {
                    n4 = 243;
                    break;
                }
                case 84: {
                    n4 = 178;
                    break;
                }
                case 85: {
                    n4 = 206;
                    break;
                }
                case 86: {
                    n4 = 73;
                    break;
                }
                case 87: {
                    n4 = 192;
                    break;
                }
                case 88: {
                    n4 = 199;
                    break;
                }
                case 89: {
                    n4 = 173;
                    break;
                }
                case 90: {
                    n4 = 102;
                    break;
                }
                case 91: {
                    n4 = 169;
                    break;
                }
                case 92: {
                    n4 = 232;
                    break;
                }
                case 93: {
                    n4 = 36;
                    break;
                }
                case 94: {
                    n4 = 162;
                    break;
                }
                case 95: {
                    n4 = 167;
                    break;
                }
                case 96: {
                    n4 = 70;
                    break;
                }
                case 97: {
                    n4 = 236;
                    break;
                }
                case 98: {
                    n4 = 91;
                    break;
                }
                case 99: {
                    n4 = 74;
                    break;
                }
                case 100: {
                    n4 = 81;
                    break;
                }
                case 101: {
                    n4 = 106;
                    break;
                }
                case 102: {
                    n4 = 118;
                    break;
                }
                case 103: {
                    n4 = 209;
                    break;
                }
                case 104: {
                    n4 = 96;
                    break;
                }
                case 105: {
                    n4 = 221;
                    break;
                }
                case 106: {
                    n4 = 203;
                    break;
                }
                case 107: {
                    n4 = 156;
                    break;
                }
                case 108: {
                    n4 = 84;
                    break;
                }
                case 109: {
                    n4 = 226;
                    break;
                }
                case 110: {
                    n4 = 138;
                    break;
                }
                case 111: {
                    n4 = 94;
                    break;
                }
                case 112: {
                    n4 = 207;
                    break;
                }
                case 113: {
                    n4 = 129;
                    break;
                }
                case 114: {
                    n4 = 164;
                    break;
                }
                case 115: {
                    n4 = 222;
                    break;
                }
                case 116: {
                    n4 = 65;
                    break;
                }
                case 117: {
                    n4 = 105;
                    break;
                }
                case 118: {
                    n4 = 187;
                    break;
                }
                case 119: {
                    n4 = 89;
                    break;
                }
                case 120: {
                    n4 = 6;
                    break;
                }
                case 121: {
                    n4 = 17;
                    break;
                }
                case 122: {
                    n4 = 113;
                    break;
                }
                case 123: {
                    n4 = 87;
                    break;
                }
                case 124: {
                    n4 = 161;
                    break;
                }
                case 125: {
                    n4 = 63;
                    break;
                }
                case 126: {
                    n4 = 244;
                    break;
                }
                case 127: {
                    n4 = 140;
                    break;
                }
                case 128: {
                    n4 = 21;
                    break;
                }
                case 129: {
                    n4 = 143;
                    break;
                }
                case 130: {
                    n4 = 184;
                    break;
                }
                case 131: {
                    n4 = 151;
                    break;
                }
                case 132: {
                    n4 = 180;
                    break;
                }
                case 133: {
                    n4 = 90;
                    break;
                }
                case 134: {
                    n4 = 55;
                    break;
                }
                case 135: {
                    n4 = 122;
                    break;
                }
                case 136: {
                    n4 = 165;
                    break;
                }
                case 137: {
                    n4 = 220;
                    break;
                }
                case 138: {
                    n4 = 197;
                    break;
                }
                case 139: {
                    n4 = 239;
                    break;
                }
                case 140: {
                    n4 = 216;
                    break;
                }
                case 141: {
                    n4 = 101;
                    break;
                }
                case 142: {
                    n4 = 251;
                    break;
                }
                case 143: {
                    n4 = 208;
                    break;
                }
                case 144: {
                    n4 = 58;
                    break;
                }
                case 145: {
                    n4 = 218;
                    break;
                }
                case 146: {
                    n4 = 144;
                    break;
                }
                case 147: {
                    n4 = 62;
                    break;
                }
                case 148: {
                    n4 = 108;
                    break;
                }
                case 149: {
                    n4 = 217;
                    break;
                }
                case 150: {
                    n4 = 168;
                    break;
                }
                case 151: {
                    n4 = 249;
                    break;
                }
                case 152: {
                    n4 = 11;
                    break;
                }
                case 153: {
                    n4 = 124;
                    break;
                }
                case 154: {
                    n4 = 154;
                    break;
                }
                case 155: {
                    n4 = 126;
                    break;
                }
                case 156: {
                    n4 = 132;
                    break;
                }
                case 157: {
                    n4 = 230;
                    break;
                }
                case 158: {
                    n4 = 50;
                    break;
                }
                case 159: {
                    n4 = 15;
                    break;
                }
                case 160: {
                    n4 = 181;
                    break;
                }
                case 161: {
                    n4 = 34;
                    break;
                }
                case 162: {
                    n4 = 150;
                    break;
                }
                case 163: {
                    n4 = 72;
                    break;
                }
                case 164: {
                    n4 = 71;
                    break;
                }
                case 165: {
                    n4 = 20;
                    break;
                }
                case 166: {
                    n4 = 205;
                    break;
                }
                case 167: {
                    n4 = 25;
                    break;
                }
                case 168: {
                    n4 = 39;
                    break;
                }
                case 169: {
                    n4 = 2;
                    break;
                }
                case 170: {
                    n4 = 95;
                    break;
                }
                case 171: {
                    n4 = 194;
                    break;
                }
                case 172: {
                    n4 = 61;
                    break;
                }
                case 173: {
                    n4 = 26;
                    break;
                }
                case 174: {
                    n4 = 225;
                    break;
                }
                case 175: {
                    n4 = 125;
                    break;
                }
                case 176: {
                    n4 = 22;
                    break;
                }
                case 177: {
                    n4 = 10;
                    break;
                }
                case 178: {
                    n4 = 133;
                    break;
                }
                case 179: {
                    n4 = 247;
                    break;
                }
                case 180: {
                    n4 = 246;
                    break;
                }
                case 181: {
                    n4 = 104;
                    break;
                }
                case 182: {
                    n4 = 198;
                    break;
                }
                case 183: {
                    n4 = 42;
                    break;
                }
                case 184: {
                    n4 = 79;
                    break;
                }
                case 185: {
                    n4 = 77;
                    break;
                }
                case 186: {
                    n4 = 234;
                    break;
                }
                case 187: {
                    n4 = 51;
                    break;
                }
                case 188: {
                    n4 = 82;
                    break;
                }
                case 189: {
                    n4 = 45;
                    break;
                }
                case 190: {
                    n4 = 210;
                    break;
                }
                case 191: {
                    n4 = 68;
                    break;
                }
                case 192: {
                    n4 = 163;
                    break;
                }
                case 193: {
                    n4 = 250;
                    break;
                }
                case 194: {
                    n4 = 255;
                    break;
                }
                case 195: {
                    n4 = 240;
                    break;
                }
                case 196: {
                    n4 = 179;
                    break;
                }
                case 197: {
                    n4 = 114;
                    break;
                }
                case 198: {
                    n4 = 30;
                    break;
                }
                case 199: {
                    n4 = 78;
                    break;
                }
                case 200: {
                    n4 = 64;
                    break;
                }
                case 201: {
                    n4 = 148;
                    break;
                }
                case 202: {
                    n4 = 223;
                    break;
                }
                case 203: {
                    n4 = 242;
                    break;
                }
                case 204: {
                    n4 = 67;
                    break;
                }
                case 205: {
                    n4 = 69;
                    break;
                }
                case 206: {
                    n4 = 127;
                    break;
                }
                case 207: {
                    n4 = 145;
                    break;
                }
                case 208: {
                    n4 = 213;
                    break;
                }
                case 209: {
                    n4 = 93;
                    break;
                }
                case 210: {
                    n4 = 212;
                    break;
                }
                case 211: {
                    n4 = 0;
                    break;
                }
                case 212: {
                    n4 = 141;
                    break;
                }
                case 213: {
                    n4 = 152;
                    break;
                }
                case 214: {
                    n4 = 233;
                    break;
                }
                case 215: {
                    n4 = 146;
                    break;
                }
                case 216: {
                    n4 = 37;
                    break;
                }
                case 217: {
                    n4 = 111;
                    break;
                }
                case 218: {
                    n4 = 137;
                    break;
                }
                case 219: {
                    n4 = 97;
                    break;
                }
                case 220: {
                    n4 = 175;
                    break;
                }
                case 221: {
                    n4 = 204;
                    break;
                }
                case 222: {
                    n4 = 8;
                    break;
                }
                case 223: {
                    n4 = 176;
                    break;
                }
                case 224: {
                    n4 = 195;
                    break;
                }
                case 225: {
                    n4 = 40;
                    break;
                }
                case 226: {
                    n4 = 75;
                    break;
                }
                case 227: {
                    n4 = 80;
                    break;
                }
                case 228: {
                    n4 = 189;
                    break;
                }
                case 229: {
                    n4 = 56;
                    break;
                }
                case 230: {
                    n4 = 110;
                    break;
                }
                case 231: {
                    n4 = 12;
                    break;
                }
                case 232: {
                    n4 = 59;
                    break;
                }
                case 233: {
                    n4 = 202;
                    break;
                }
                case 234: {
                    n4 = 31;
                    break;
                }
                case 235: {
                    n4 = 139;
                    break;
                }
                case 236: {
                    n4 = 19;
                    break;
                }
                case 237: {
                    n4 = 149;
                    break;
                }
                case 238: {
                    n4 = 147;
                    break;
                }
                case 239: {
                    n4 = 1;
                    break;
                }
                case 240: {
                    n4 = 231;
                    break;
                }
                case 241: {
                    n4 = 53;
                    break;
                }
                case 242: {
                    n4 = 228;
                    break;
                }
                case 243: {
                    n4 = 29;
                    break;
                }
                case 244: {
                    n4 = 98;
                    break;
                }
                case 245: {
                    n4 = 100;
                    break;
                }
                case 246: {
                    n4 = 43;
                    break;
                }
                case 247: {
                    n4 = 170;
                    break;
                }
                case 248: {
                    n4 = 134;
                    break;
                }
                case 249: {
                    n4 = 190;
                    break;
                }
                case 250: {
                    n4 = 248;
                    break;
                }
                case 251: {
                    n4 = 76;
                    break;
                }
                case 252: {
                    n4 = 229;
                    break;
                }
                case 253: {
                    n4 = 174;
                    break;
                }
                case 254: {
                    n4 = 191;
                    break;
                }
                default: {
                    n4 = 24;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < charArray.length; ++i) {
                final int n8 = i % 2;
                final char[] array = charArray;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ charArray[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ charArray[i]) & 0xFF);
                }
            }
            NativeKeyEvent.e[n3] = new String(charArray).intern();
        }
        return NativeKeyEvent.e[n3];
    }
}
