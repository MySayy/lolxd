// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook;

public class NativeMonitorInfo
{
    private short number;
    private int x;
    private int y;
    private short width;
    private short height;
    
    public NativeMonitorInfo(final short number, final int x, final int y, final short width, final short height) {
        this.number = number;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    
    public short getNumber() {
        return this.number;
    }
    
    public void setNumber(final short number) {
        this.number = number;
    }
    
    public int getX() {
        return this.x;
    }
    
    public void setX(final int x) {
        this.x = x;
    }
    
    public int getY() {
        return this.y;
    }
    
    public void setY(final int y) {
        this.y = y;
    }
    
    public short getWidth() {
        return this.width;
    }
    
    public void setWidth(final short width) {
        this.width = width;
    }
    
    public short getHeight() {
        return this.height;
    }
    
    public void setHeight(final short height) {
        this.height = height;
    }
}
