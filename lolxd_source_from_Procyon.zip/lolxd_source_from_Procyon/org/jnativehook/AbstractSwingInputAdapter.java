// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook;

import java.awt.Component;

public abstract class AbstractSwingInputAdapter extends Component
{
    protected int getJavaModifiers(final int n) {
        final int[] b = NativeInputEvent.b();
        int n2 = 0;
        int n9;
        while (true) {
            Label_0232: {
                Label_0208: {
                    int n8;
                    while (true) {
                        Label_0199: {
                            Label_0174: {
                                int n7;
                                while (true) {
                                    Label_0165: {
                                        Label_0140: {
                                            int n6;
                                            while (true) {
                                                Label_0131: {
                                                    Label_0106: {
                                                        int n5;
                                                        while (true) {
                                                            Label_0097: {
                                                                Label_0073: {
                                                                    int n11 = 0;
                                                                    while (true) {
                                                                        Label_0065: {
                                                                            Label_0041: {
                                                                                int n3 = 0;
                                                                                while (true) {
                                                                                    Label_0033: {
                                                                                        try {
                                                                                            final int n4;
                                                                                            n3 = (n4 = (n5 = (n6 = (n7 = (n8 = (n9 = (n & 0x11)))))));
                                                                                            if (b == null) {
                                                                                                break Label_0041;
                                                                                            }
                                                                                            if (n3 == 0) {
                                                                                                break Label_0033;
                                                                                            }
                                                                                        }
                                                                                        catch (RuntimeException ex) {
                                                                                            throw b(ex);
                                                                                        }
                                                                                        final int n10 = n2 | 0x1 | 0x40;
                                                                                        n2 = n11;
                                                                                    }
                                                                                    n11 = (n5 = (n6 = (n7 = (n8 = (n9 = (n & 0x44))))));
                                                                                    if (b == null) {
                                                                                        continue;
                                                                                    }
                                                                                    break;
                                                                                }
                                                                                try {
                                                                                    if (b == null) {
                                                                                        break Label_0073;
                                                                                    }
                                                                                    if (n3 == 0) {
                                                                                        break Label_0065;
                                                                                    }
                                                                                }
                                                                                catch (RuntimeException ex2) {
                                                                                    throw b(ex2);
                                                                                }
                                                                            }
                                                                            final int n12 = n2 | 0x4 | 0x100;
                                                                            n2 = n12;
                                                                        }
                                                                        int n12;
                                                                        int n4 = n12 = (n5 = (n6 = (n7 = (n8 = (n9 = (n & 0x44))))));
                                                                        if (b == null) {
                                                                            continue;
                                                                        }
                                                                        break;
                                                                    }
                                                                    try {
                                                                        if (b == null) {
                                                                            break Label_0106;
                                                                        }
                                                                        if (n11 == 0) {
                                                                            break Label_0097;
                                                                        }
                                                                    }
                                                                    catch (RuntimeException ex3) {
                                                                        throw b(ex3);
                                                                    }
                                                                }
                                                                final int n13 = n2 | 0x2 | 0x80;
                                                                n2 = n13;
                                                            }
                                                            int n13;
                                                            n5 = (n13 = (n6 = (n7 = (n8 = (n9 = (n & 0x88))))));
                                                            if (b == null) {
                                                                continue;
                                                            }
                                                            break;
                                                        }
                                                        try {
                                                            if (b == null) {
                                                                break Label_0140;
                                                            }
                                                            if (n5 == 0) {
                                                                break Label_0131;
                                                            }
                                                        }
                                                        catch (RuntimeException ex4) {
                                                            throw b(ex4);
                                                        }
                                                    }
                                                    final int n14 = n2 | 0x8 | 0x200;
                                                    n2 = n14;
                                                }
                                                int n14;
                                                n6 = (n14 = (n7 = (n8 = (n9 = (n & 0x100)))));
                                                if (b == null) {
                                                    continue;
                                                }
                                                break;
                                            }
                                            try {
                                                if (b == null) {
                                                    break Label_0174;
                                                }
                                                if (n6 == 0) {
                                                    break Label_0165;
                                                }
                                            }
                                            catch (RuntimeException ex5) {
                                                throw b(ex5);
                                            }
                                        }
                                        final int n15 = n2 | 0x10 | 0x400;
                                        n2 = n15;
                                    }
                                    int n15;
                                    n7 = (n15 = (n8 = (n9 = (n & 0x200))));
                                    if (b == null) {
                                        continue;
                                    }
                                    break;
                                }
                                try {
                                    if (b == null) {
                                        break Label_0208;
                                    }
                                    if (n7 == 0) {
                                        break Label_0199;
                                    }
                                }
                                catch (RuntimeException ex6) {
                                    throw b(ex6);
                                }
                            }
                            final int n16 = n2 | 0x8 | 0x800;
                            n2 = n16;
                        }
                        int n16;
                        n8 = (n16 = (n9 = (n & 0x400)));
                        if (b == null) {
                            continue;
                        }
                        break;
                    }
                    try {
                        if (b == null) {
                            return n9;
                        }
                        if (n8 == 0) {
                            break Label_0232;
                        }
                    }
                    catch (RuntimeException ex7) {
                        throw b(ex7);
                    }
                }
                final int n17 = n2 | 0x4 | 0x1000;
                n2 = n17;
            }
            int n17;
            n9 = (n17 = n2);
            if (b == null) {
                continue;
            }
            break;
        }
        return n9;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
