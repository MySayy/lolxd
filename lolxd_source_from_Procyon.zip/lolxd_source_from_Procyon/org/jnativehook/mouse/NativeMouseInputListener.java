// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.mouse;

public interface NativeMouseInputListener extends NativeMouseListener, NativeMouseMotionListener
{
}
