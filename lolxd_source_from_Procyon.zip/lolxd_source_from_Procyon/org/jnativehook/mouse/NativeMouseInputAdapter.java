// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.mouse;

public class NativeMouseInputAdapter implements NativeMouseInputListener
{
    public void nativeMouseClicked(final NativeMouseEvent nativeMouseEvent) {
    }
    
    public void nativeMousePressed(final NativeMouseEvent nativeMouseEvent) {
    }
    
    public void nativeMouseReleased(final NativeMouseEvent nativeMouseEvent) {
    }
    
    public void nativeMouseDragged(final NativeMouseEvent nativeMouseEvent) {
    }
    
    public void nativeMouseMoved(final NativeMouseEvent nativeMouseEvent) {
    }
}
