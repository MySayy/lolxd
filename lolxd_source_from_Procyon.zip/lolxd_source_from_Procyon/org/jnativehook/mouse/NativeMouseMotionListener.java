// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.mouse;

import java.util.EventListener;

public interface NativeMouseMotionListener extends EventListener
{
    void nativeMouseMoved(final NativeMouseEvent p0);
    
    void nativeMouseDragged(final NativeMouseEvent p0);
}
