// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.mouse;

import java.util.EventListener;

public interface NativeMouseWheelListener extends EventListener
{
    void nativeMouseWheelMoved(final NativeMouseWheelEvent p0);
}
