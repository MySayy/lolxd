// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.mouse;

import java.util.EventListener;

public interface NativeMouseListener extends EventListener
{
    void nativeMouseClicked(final NativeMouseEvent p0);
    
    void nativeMousePressed(final NativeMouseEvent p0);
    
    void nativeMouseReleased(final NativeMouseEvent p0);
}
