// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.mouse;

import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

public class SwingMouseWheelAdapter extends SwingMouseAdapter implements NativeMouseWheelListener, MouseWheelListener
{
    public void nativeMouseWheelMoved(final NativeMouseWheelEvent nativeMouseWheelEvent) {
        this.mouseWheelMoved(this.getJavaMouseWheelEvent(nativeMouseWheelEvent));
    }
    
    public void mouseWheelMoved(final MouseWheelEvent mouseWheelEvent) {
    }
    
    protected MouseWheelEvent getJavaMouseWheelEvent(final NativeMouseWheelEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: iconst_0       
        //     5: istore_3       
        //     6: aload_1        
        //     7: invokevirtual   org/jnativehook/mouse/NativeMouseWheelEvent.getScrollType:()I
        //    10: iload_2        
        //    11: ifeq            44
        //    14: iload_2        
        //    15: ifeq            44
        //    18: goto            25
        //    21: invokestatic    org/jnativehook/mouse/SwingMouseWheelAdapter.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    24: athrow         
        //    25: iconst_2       
        //    26: if_icmpne       45
        //    29: goto            36
        //    32: invokestatic    org/jnativehook/mouse/SwingMouseWheelAdapter.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    35: athrow         
        //    36: iconst_1       
        //    37: goto            44
        //    40: invokestatic    org/jnativehook/mouse/SwingMouseWheelAdapter.c:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    43: athrow         
        //    44: istore_3       
        //    45: new             Ljava/awt/event/MouseWheelEvent;
        //    48: dup            
        //    49: aload_0        
        //    50: aload_1        
        //    51: invokevirtual   org/jnativehook/mouse/NativeMouseWheelEvent.getID:()I
        //    54: iconst_0       
        //    55: isub           
        //    56: invokestatic    java/lang/System.currentTimeMillis:()J
        //    59: aload_0        
        //    60: aload_1        
        //    61: invokevirtual   org/jnativehook/mouse/NativeMouseWheelEvent.getModifiers:()I
        //    64: invokevirtual   org/jnativehook/mouse/SwingMouseWheelAdapter.getJavaModifiers:(I)I
        //    67: aload_1        
        //    68: invokevirtual   org/jnativehook/mouse/NativeMouseWheelEvent.getX:()I
        //    71: aload_1        
        //    72: invokevirtual   org/jnativehook/mouse/NativeMouseWheelEvent.getY:()I
        //    75: aload_1        
        //    76: invokevirtual   org/jnativehook/mouse/NativeMouseWheelEvent.getClickCount:()I
        //    79: iconst_0       
        //    80: iload_3        
        //    81: aload_1        
        //    82: invokevirtual   org/jnativehook/mouse/NativeMouseWheelEvent.getScrollAmount:()I
        //    85: aload_1        
        //    86: invokevirtual   org/jnativehook/mouse/NativeMouseWheelEvent.getWheelRotation:()I
        //    89: invokespecial   java/awt/event/MouseWheelEvent.<init>:(Ljava/awt/Component;IJIIIIZIII)V
        //    92: areturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  6      18     21     25     Ljava/lang/RuntimeException;
        //  14     29     32     36     Ljava/lang/RuntimeException;
        //  25     37     40     44     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0025:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static RuntimeException c(final RuntimeException ex) {
        return ex;
    }
}
