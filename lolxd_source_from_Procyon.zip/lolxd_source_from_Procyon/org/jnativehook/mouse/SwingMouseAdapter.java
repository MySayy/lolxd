// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.mouse;

import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import org.jnativehook.AbstractSwingInputAdapter;

public class SwingMouseAdapter extends AbstractSwingInputAdapter implements NativeMouseListener, MouseListener
{
    public void nativeMouseClicked(final NativeMouseEvent nativeMouseEvent) {
        this.mouseClicked(this.getJavaKeyEvent(nativeMouseEvent));
    }
    
    public void nativeMousePressed(final NativeMouseEvent nativeMouseEvent) {
        this.mousePressed(this.getJavaKeyEvent(nativeMouseEvent));
    }
    
    public void nativeMouseReleased(final NativeMouseEvent nativeMouseEvent) {
        this.mousePressed(this.getJavaKeyEvent(nativeMouseEvent));
    }
    
    public void mouseClicked(final MouseEvent mouseEvent) {
    }
    
    public void mousePressed(final MouseEvent mouseEvent) {
    }
    
    public void mouseReleased(final MouseEvent mouseEvent) {
    }
    
    public void mouseEntered(final MouseEvent mouseEvent) {
    }
    
    public void mouseExited(final MouseEvent mouseEvent) {
    }
    
    protected MouseEvent getJavaKeyEvent(final NativeMouseEvent nativeMouseEvent) {
        return new MouseEvent(this, nativeMouseEvent.getID() - 0, System.currentTimeMillis(), this.getJavaModifiers(nativeMouseEvent.getModifiers()), nativeMouseEvent.getX(), nativeMouseEvent.getY(), nativeMouseEvent.getClickCount(), false, nativeMouseEvent.getButton());
    }
}
