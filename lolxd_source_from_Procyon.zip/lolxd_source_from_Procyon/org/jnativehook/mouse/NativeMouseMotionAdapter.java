// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.mouse;

public class NativeMouseMotionAdapter implements NativeMouseMotionListener
{
    public void nativeMouseDragged(final NativeMouseEvent nativeMouseEvent) {
    }
    
    public void nativeMouseMoved(final NativeMouseEvent nativeMouseEvent) {
    }
}
