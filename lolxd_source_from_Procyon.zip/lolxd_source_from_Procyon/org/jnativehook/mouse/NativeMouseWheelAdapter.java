// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.mouse;

public class NativeMouseWheelAdapter implements NativeMouseWheelListener
{
    public void nativeMouseWheelMoved(final NativeMouseWheelEvent nativeMouseWheelEvent) {
    }
}
