// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.mouse;

public class NativeMouseAdapter implements NativeMouseListener
{
    public void nativeMouseClicked(final NativeMouseEvent nativeMouseEvent) {
    }
    
    public void nativeMousePressed(final NativeMouseEvent nativeMouseEvent) {
    }
    
    public void nativeMouseReleased(final NativeMouseEvent nativeMouseEvent) {
    }
}
