// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.example;

import javax.swing.SwingUtilities;
import org.jnativehook.NativeHookException;
import java.awt.event.WindowEvent;
import javax.swing.text.BadLocationException;
import org.jnativehook.mouse.NativeMouseWheelEvent;
import org.jnativehook.mouse.NativeMouseEvent;
import org.jnativehook.NativeInputEvent;
import org.jnativehook.keyboard.NativeKeyEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ActionEvent;
import com.sun.jna.Structure;
import java.util.concurrent.ExecutorService;
import org.jnativehook.GlobalScreen;
import org.jnativehook.dispatcher.SwingDispatchService;
import java.util.logging.Handler;
import java.util.logging.Formatter;
import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.awt.Dimension;
import java.awt.Component;
import javax.swing.JScrollPane;
import java.awt.Color;
import javax.swing.KeyStroke;
import javax.swing.JMenuBar;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import java.util.logging.Logger;
import javax.swing.JTextArea;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import java.awt.event.WindowListener;
import org.jnativehook.mouse.NativeMouseWheelListener;
import org.jnativehook.mouse.NativeMouseInputListener;
import org.jnativehook.keyboard.NativeKeyListener;
import java.awt.event.ItemListener;
import java.awt.event.ActionListener;
import javax.swing.JFrame;

public class NativeHookDemo extends JFrame implements ActionListener, ItemListener, NativeKeyListener, NativeMouseInputListener, NativeMouseWheelListener, WindowListener
{
    private static final long serialVersionUID = 1541183202160543102L;
    private JMenu menuSubListeners;
    private JMenuItem menuItemQuit;
    private JMenuItem menuItemClear;
    private JCheckBoxMenuItem menuItemEnable;
    private JCheckBoxMenuItem menuItemKeyboardEvents;
    private JCheckBoxMenuItem menuItemButtonEvents;
    private JCheckBoxMenuItem menuItemMotionEvents;
    private JCheckBoxMenuItem menuItemWheelEvents;
    private JTextArea txtEventInfo;
    private static final Logger logger;
    private static boolean b;
    private static final String[] a;
    private static final String[] c;
    
    public NativeHookDemo() {
        this.setTitle(a(-25172, 28633));
        this.setLayout(new BorderLayout());
        this.setDefaultCloseOperation(2);
        this.setSize(600, 300);
        this.addWindowListener(this);
        final JMenuBar jMenuBar = new JMenuBar();
        final JMenu c = new JMenu(a(-25171, -14601));
        c.setMnemonic(70);
        jMenuBar.add(c);
        (this.menuItemQuit = new JMenuItem(a(-25205, -22725), 81)).addActionListener(this);
        this.menuItemQuit.setAccelerator(KeyStroke.getKeyStroke(115, 8));
        this.menuItemQuit.getAccessibleContext().setAccessibleDescription(a(-25193, 20385));
        c.add(this.menuItemQuit);
        final JMenu c2 = new JMenu(a(-25195, 3593));
        c2.setMnemonic(86);
        jMenuBar.add(c2);
        (this.menuItemClear = new JMenuItem(a(-25182, -3514), 67)).addActionListener(this);
        this.menuItemClear.setAccelerator(KeyStroke.getKeyStroke(67, 3));
        this.menuItemClear.getAccessibleContext().setAccessibleDescription(a(-25183, -26094));
        c2.add(this.menuItemClear);
        c2.addSeparator();
        final boolean b = b();
        (this.menuItemEnable = new JCheckBoxMenuItem(a(-25189, -4049))).addItemListener(this);
        this.menuItemEnable.setMnemonic(72);
        this.menuItemEnable.setAccelerator(KeyStroke.getKeyStroke(72, 3));
        c2.add(this.menuItemEnable);
        final boolean b2 = b;
        (this.menuSubListeners = new JMenu(a(-25185, 20852))).setMnemonic(76);
        c2.add(this.menuSubListeners);
        (this.menuItemKeyboardEvents = new JCheckBoxMenuItem(a(-25197, 12939))).addItemListener(this);
        this.menuItemKeyboardEvents.setMnemonic(75);
        this.menuItemKeyboardEvents.setAccelerator(KeyStroke.getKeyStroke(75, 3));
        this.menuSubListeners.add(this.menuItemKeyboardEvents);
        (this.menuItemButtonEvents = new JCheckBoxMenuItem(a(-25207, 9313))).addItemListener(this);
        this.menuItemButtonEvents.setMnemonic(66);
        this.menuItemButtonEvents.setAccelerator(KeyStroke.getKeyStroke(66, 3));
        this.menuSubListeners.add(this.menuItemButtonEvents);
        (this.menuItemMotionEvents = new JCheckBoxMenuItem(a(-25206, -26048))).addItemListener(this);
        this.menuItemMotionEvents.setMnemonic(77);
        this.menuItemMotionEvents.setAccelerator(KeyStroke.getKeyStroke(77, 3));
        this.menuSubListeners.add(this.menuItemMotionEvents);
        (this.menuItemWheelEvents = new JCheckBoxMenuItem(a(-25211, 8302))).addItemListener(this);
        this.menuItemWheelEvents.setMnemonic(87);
        this.menuItemWheelEvents.setAccelerator(KeyStroke.getKeyStroke(87, 3));
        this.menuSubListeners.add(this.menuItemWheelEvents);
        this.setJMenuBar(jMenuBar);
        (this.txtEventInfo = new JTextArea()).setEditable(false);
        this.txtEventInfo.setBackground(new Color(255, 255, 255));
        this.txtEventInfo.setForeground(new Color(0, 0, 0));
        this.txtEventInfo.setText("");
        final JScrollPane comp = new JScrollPane(this.txtEventInfo);
        comp.setPreferredSize(new Dimension(375, 125));
        this.add(comp, a(-25209, 4209));
        NativeHookDemo.logger.setUseParentHandlers(false);
        NativeHookDemo.logger.setLevel(Level.ALL);
        final ConsoleHandler handler = new ConsoleHandler();
        handler.setFormatter(new NativeHookDemo$LogFormatter(this, null));
        handler.setLevel(Level.WARNING);
        NativeHookDemo.logger.addHandler(handler);
        GlobalScreen.setEventDispatcher(new SwingDispatchService());
        this.setVisible(true);
        if (b2) {
            int b3 = Structure.b();
            Structure.b(++b3);
        }
    }
    
    public void actionPerformed(final ActionEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_1        
        //     5: invokevirtual   java/awt/event/ActionEvent.getSource:()Ljava/lang/Object;
        //     8: aload_0        
        //     9: getfield        org/jnativehook/example/NativeHookDemo.menuItemQuit:Ljavax/swing/JMenuItem;
        //    12: iload_2        
        //    13: ifne            56
        //    16: if_acmpne       41
        //    19: goto            26
        //    22: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    25: athrow         
        //    26: aload_0        
        //    27: invokevirtual   org/jnativehook/example/NativeHookDemo.dispose:()V
        //    30: iload_2        
        //    31: ifeq            75
        //    34: goto            41
        //    37: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    40: athrow         
        //    41: aload_1        
        //    42: invokevirtual   java/awt/event/ActionEvent.getSource:()Ljava/lang/Object;
        //    45: aload_0        
        //    46: getfield        org/jnativehook/example/NativeHookDemo.menuItemClear:Ljavax/swing/JMenuItem;
        //    49: goto            56
        //    52: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    55: athrow         
        //    56: if_acmpne       75
        //    59: aload_0        
        //    60: getfield        org/jnativehook/example/NativeHookDemo.txtEventInfo:Ljavax/swing/JTextArea;
        //    63: ldc             ""
        //    65: invokevirtual   javax/swing/JTextArea.setText:(Ljava/lang/String;)V
        //    68: goto            75
        //    71: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    74: athrow         
        //    75: return         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      19     22     26     Ljava/lang/RuntimeException;
        //  16     34     37     41     Ljava/lang/RuntimeException;
        //  26     49     52     56     Ljava/lang/RuntimeException;
        //  56     68     71     75     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0026:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void itemStateChanged(final ItemEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: istore_2       
        //     4: aload_1        
        //     5: invokevirtual   java/awt/event/ItemEvent.getItemSelectable:()Ljava/awt/ItemSelectable;
        //     8: astore_3       
        //     9: aload_3        
        //    10: aload_0        
        //    11: getfield        org/jnativehook/example/NativeHookDemo.menuItemEnable:Ljavax/swing/JCheckBoxMenuItem;
        //    14: iload_2        
        //    15: ifeq            147
        //    18: if_acmpne       135
        //    21: goto            28
        //    24: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    27: athrow         
        //    28: aload_1        
        //    29: invokevirtual   java/awt/event/ItemEvent.getStateChange:()I
        //    32: iconst_1       
        //    33: if_icmpne       50
        //    36: invokestatic    org/jnativehook/GlobalScreen.registerNativeHook:()V
        //    39: iload_2        
        //    40: ifne            60
        //    43: goto            50
        //    46: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    49: athrow         
        //    50: invokestatic    org/jnativehook/GlobalScreen.unregisterNativeHook:()V
        //    53: goto            60
        //    56: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    59: athrow         
        //    60: goto            107
        //    63: astore          4
        //    65: aload_0        
        //    66: getfield        org/jnativehook/example/NativeHookDemo.txtEventInfo:Ljavax/swing/JTextArea;
        //    69: new             Ljava/lang/StringBuilder;
        //    72: dup            
        //    73: invokespecial   java/lang/StringBuilder.<init>:()V
        //    76: sipush          -25214
        //    79: sipush          7905
        //    82: invokestatic    org/jnativehook/example/NativeHookDemo.a:(II)Ljava/lang/String;
        //    85: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    88: aload           4
        //    90: invokevirtual   org/jnativehook/NativeHookException.getMessage:()Ljava/lang/String;
        //    93: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    96: ldc             "\n"
        //    98: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   101: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   104: invokevirtual   javax/swing/JTextArea.append:(Ljava/lang/String;)V
        //   107: aload_0        
        //   108: getfield        org/jnativehook/example/NativeHookDemo.menuItemEnable:Ljavax/swing/JCheckBoxMenuItem;
        //   111: invokestatic    org/jnativehook/GlobalScreen.isNativeHookRegistered:()Z
        //   114: invokevirtual   javax/swing/JCheckBoxMenuItem.setState:(Z)V
        //   117: aload_0        
        //   118: getfield        org/jnativehook/example/NativeHookDemo.menuSubListeners:Ljavax/swing/JMenu;
        //   121: aload_0        
        //   122: getfield        org/jnativehook/example/NativeHookDemo.menuItemEnable:Ljavax/swing/JCheckBoxMenuItem;
        //   125: invokevirtual   javax/swing/JCheckBoxMenuItem.getState:()Z
        //   128: invokevirtual   javax/swing/JMenu.setEnabled:(Z)V
        //   131: iload_2        
        //   132: ifne            392
        //   135: aload_3        
        //   136: aload_0        
        //   137: getfield        org/jnativehook/example/NativeHookDemo.menuItemKeyboardEvents:Ljavax/swing/JCheckBoxMenuItem;
        //   140: goto            147
        //   143: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   146: athrow         
        //   147: iload_2        
        //   148: ifeq            215
        //   151: if_acmpne       203
        //   154: goto            161
        //   157: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   160: athrow         
        //   161: aload_1        
        //   162: invokevirtual   java/awt/event/ItemEvent.getStateChange:()I
        //   165: iconst_1       
        //   166: if_icmpne       191
        //   169: goto            176
        //   172: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   175: athrow         
        //   176: aload_0        
        //   177: invokestatic    org/jnativehook/GlobalScreen.addNativeKeyListener:(Lorg/jnativehook/keyboard/NativeKeyListener;)V
        //   180: goto            187
        //   183: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   186: athrow         
        //   187: iload_2        
        //   188: ifne            392
        //   191: aload_0        
        //   192: invokestatic    org/jnativehook/GlobalScreen.removeNativeKeyListener:(Lorg/jnativehook/keyboard/NativeKeyListener;)V
        //   195: iload_2        
        //   196: ifeq            187
        //   199: iload_2        
        //   200: ifne            392
        //   203: aload_3        
        //   204: aload_0        
        //   205: getfield        org/jnativehook/example/NativeHookDemo.menuItemButtonEvents:Ljavax/swing/JCheckBoxMenuItem;
        //   208: goto            215
        //   211: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   214: athrow         
        //   215: iload_2        
        //   216: ifeq            283
        //   219: if_acmpne       271
        //   222: goto            229
        //   225: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   228: athrow         
        //   229: aload_1        
        //   230: invokevirtual   java/awt/event/ItemEvent.getStateChange:()I
        //   233: iconst_1       
        //   234: if_icmpne       259
        //   237: goto            244
        //   240: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   243: athrow         
        //   244: aload_0        
        //   245: invokestatic    org/jnativehook/GlobalScreen.addNativeMouseListener:(Lorg/jnativehook/mouse/NativeMouseListener;)V
        //   248: goto            255
        //   251: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   254: athrow         
        //   255: iload_2        
        //   256: ifne            392
        //   259: aload_0        
        //   260: invokestatic    org/jnativehook/GlobalScreen.removeNativeMouseListener:(Lorg/jnativehook/mouse/NativeMouseListener;)V
        //   263: iload_2        
        //   264: ifeq            255
        //   267: iload_2        
        //   268: ifne            392
        //   271: aload_3        
        //   272: aload_0        
        //   273: getfield        org/jnativehook/example/NativeHookDemo.menuItemMotionEvents:Ljavax/swing/JCheckBoxMenuItem;
        //   276: goto            283
        //   279: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   282: athrow         
        //   283: iload_2        
        //   284: ifeq            351
        //   287: if_acmpne       339
        //   290: goto            297
        //   293: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   296: athrow         
        //   297: aload_1        
        //   298: invokevirtual   java/awt/event/ItemEvent.getStateChange:()I
        //   301: iconst_1       
        //   302: if_icmpne       327
        //   305: goto            312
        //   308: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   311: athrow         
        //   312: aload_0        
        //   313: invokestatic    org/jnativehook/GlobalScreen.addNativeMouseMotionListener:(Lorg/jnativehook/mouse/NativeMouseMotionListener;)V
        //   316: goto            323
        //   319: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   322: athrow         
        //   323: iload_2        
        //   324: ifne            392
        //   327: aload_0        
        //   328: invokestatic    org/jnativehook/GlobalScreen.removeNativeMouseMotionListener:(Lorg/jnativehook/mouse/NativeMouseMotionListener;)V
        //   331: iload_2        
        //   332: ifeq            323
        //   335: iload_2        
        //   336: ifne            392
        //   339: aload_3        
        //   340: aload_0        
        //   341: getfield        org/jnativehook/example/NativeHookDemo.menuItemWheelEvents:Ljavax/swing/JCheckBoxMenuItem;
        //   344: goto            351
        //   347: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   350: athrow         
        //   351: if_acmpne       392
        //   354: aload_1        
        //   355: invokevirtual   java/awt/event/ItemEvent.getStateChange:()I
        //   358: iconst_1       
        //   359: if_icmpne       384
        //   362: goto            369
        //   365: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   368: athrow         
        //   369: aload_0        
        //   370: goto            377
        //   373: invokestatic    org/jnativehook/example/NativeHookDemo.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   376: athrow         
        //   377: invokestatic    org/jnativehook/GlobalScreen.addNativeMouseWheelListener:(Lorg/jnativehook/mouse/NativeMouseWheelListener;)V
        //   380: iload_2        
        //   381: ifne            392
        //   384: aload_0        
        //   385: iload_2        
        //   386: ifeq            377
        //   389: invokestatic    org/jnativehook/GlobalScreen.removeNativeMouseWheelListener:(Lorg/jnativehook/mouse/NativeMouseWheelListener;)V
        //   392: return         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                 
        //  -----  -----  -----  -----  -------------------------------------
        //  36     53     56     60     Lorg/jnativehook/NativeHookException;
        //  28     43     46     50     Lorg/jnativehook/NativeHookException;
        //  9      21     24     28     Lorg/jnativehook/NativeHookException;
        //  28     60     63     107    Lorg/jnativehook/NativeHookException;
        //  107    140    143    147    Lorg/jnativehook/NativeHookException;
        //  147    154    157    161    Lorg/jnativehook/NativeHookException;
        //  151    169    172    176    Lorg/jnativehook/NativeHookException;
        //  161    180    183    187    Lorg/jnativehook/NativeHookException;
        //  199    208    211    215    Lorg/jnativehook/NativeHookException;
        //  215    222    225    229    Lorg/jnativehook/NativeHookException;
        //  219    237    240    244    Lorg/jnativehook/NativeHookException;
        //  229    248    251    255    Lorg/jnativehook/NativeHookException;
        //  267    276    279    283    Lorg/jnativehook/NativeHookException;
        //  283    290    293    297    Lorg/jnativehook/NativeHookException;
        //  287    305    308    312    Lorg/jnativehook/NativeHookException;
        //  297    316    319    323    Lorg/jnativehook/NativeHookException;
        //  335    344    347    351    Lorg/jnativehook/NativeHookException;
        //  351    362    365    369    Lorg/jnativehook/NativeHookException;
        //  354    370    373    377    Lorg/jnativehook/NativeHookException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0161:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void nativeKeyPressed(final NativeKeyEvent nativeKeyEvent) {
        this.displayEventInfo(nativeKeyEvent);
    }
    
    public void nativeKeyReleased(final NativeKeyEvent nativeKeyEvent) {
        this.displayEventInfo(nativeKeyEvent);
    }
    
    public void nativeKeyTyped(final NativeKeyEvent nativeKeyEvent) {
        this.displayEventInfo(nativeKeyEvent);
    }
    
    public void nativeMouseClicked(final NativeMouseEvent nativeMouseEvent) {
        this.displayEventInfo(nativeMouseEvent);
    }
    
    public void nativeMousePressed(final NativeMouseEvent nativeMouseEvent) {
        this.displayEventInfo(nativeMouseEvent);
    }
    
    public void nativeMouseReleased(final NativeMouseEvent nativeMouseEvent) {
        this.displayEventInfo(nativeMouseEvent);
    }
    
    public void nativeMouseMoved(final NativeMouseEvent nativeMouseEvent) {
        this.displayEventInfo(nativeMouseEvent);
    }
    
    public void nativeMouseDragged(final NativeMouseEvent nativeMouseEvent) {
        this.displayEventInfo(nativeMouseEvent);
    }
    
    public void nativeMouseWheelMoved(final NativeMouseWheelEvent nativeMouseWheelEvent) {
        this.displayEventInfo(nativeMouseWheelEvent);
    }
    
    private void displayEventInfo(final NativeInputEvent nativeInputEvent) {
        final boolean a = a();
        this.txtEventInfo.append("\n" + nativeInputEvent.paramString());
        try {
            final JTextArea txtEventInfo = this.txtEventInfo;
            if (a) {
                while (true) {
                    Label_0085: {
                        try {
                            if (txtEventInfo.getLineCount() <= 100) {
                                break Label_0085;
                            }
                            final JTextArea txtEventInfo2 = this.txtEventInfo;
                        }
                        catch (BadLocationException ex) {
                            throw b(ex);
                        }
                        final JTextArea txtEventInfo3;
                        txtEventInfo3.replaceRange("", 0, this.txtEventInfo.getLineEndOffset(this.txtEventInfo.getLineCount() - 1 - 100));
                    }
                    final JTextArea txtEventInfo3 = this.txtEventInfo;
                    if (!a) {
                        continue;
                    }
                    break;
                }
            }
            txtEventInfo.setCaretPosition(this.txtEventInfo.getLineStartOffset(this.txtEventInfo.getLineCount() - 1));
        }
        catch (BadLocationException ex2) {
            this.txtEventInfo.setCaretPosition(this.txtEventInfo.getDocument().getLength());
        }
    }
    
    public void windowActivated(final WindowEvent windowEvent) {
    }
    
    public void windowClosing(final WindowEvent windowEvent) {
    }
    
    public void windowDeactivated(final WindowEvent windowEvent) {
    }
    
    public void windowDeiconified(final WindowEvent windowEvent) {
    }
    
    public void windowIconified(final WindowEvent windowEvent) {
    }
    
    public void windowOpened(final WindowEvent windowEvent) {
        this.requestFocusInWindow();
        this.menuItemEnable.setSelected(true);
        this.txtEventInfo.append(a(-25188, -17310) + System.getProperty(a(-25216, 22693)));
        this.txtEventInfo.append(a(-25198, -16714) + System.getProperty(a(-25194, 19005)));
        this.txtEventInfo.append(a(-25199, 27433) + System.getProperty(a(-25212, 26769)));
        this.txtEventInfo.append(a(-25179, -22045) + System.getProperty(a(-25200, 4220)));
        this.txtEventInfo.append(a(-25186, -29534) + System.getProperty(a(-25177, -19922)));
        this.txtEventInfo.append(a(-25201, 11500) + System.getProperty(a(-25210, 8552)));
        this.txtEventInfo.append(a(-25178, 31375) + System.getProperty(a(-25204, 18703)));
        try {
            this.txtEventInfo.setCaretPosition(this.txtEventInfo.getLineStartOffset(this.txtEventInfo.getLineCount() - 1));
        }
        catch (BadLocationException ex) {
            this.txtEventInfo.setCaretPosition(this.txtEventInfo.getDocument().getLength());
        }
        this.menuItemKeyboardEvents.setSelected(true);
        this.menuItemButtonEvents.setSelected(true);
        this.menuItemMotionEvents.setSelected(true);
        this.menuItemWheelEvents.setSelected(true);
    }
    
    public void windowClosed(final WindowEvent windowEvent) {
        try {
            GlobalScreen.unregisterNativeHook();
        }
        catch (NativeHookException ex) {
            ex.printStackTrace();
        }
        System.runFinalization();
        System.exit(0);
    }
    
    public static void main(final String[] array) {
        final StringBuffer append = new StringBuffer("\n").append(a(-25203, -23513)).append(a(-25181, 16396)).append(a(-25187, 27653)).append("\n").append(a(-25215, -24870)).append(a(-25192, -16309)).append(a(-25202, -24727)).append(a(-25213, 5716)).append("\n").append(a(-25191, -26501)).append(a(-25184, 10166)).append(a(-25208, 31359)).append(a(-25190, 31211)).append("\n").append(a(-25196, -20558)).append(a(-25180, 19229));
        final boolean b = b();
        System.out.println(append);
        final boolean b2 = b;
        SwingUtilities.invokeLater(new NativeHookDemo$1());
        if (Structure.b() != 0) {
            boolean b3 = false;
            Label_0221: {
                try {
                    if (b2) {
                        b3 = false;
                        break Label_0221;
                    }
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                b3 = true;
            }
            b(b3);
        }
    }
    
    static {
        final String[] a2 = new String[42];
        final boolean b = false;
        int n = 0;
        final String s;
        final int length = (s = "\u00d0\rJE\u00feG\u0098m½\u00f3\u00ee¼\u001c\u0012\u000f\u008c\u00d2§\u00d06\u001dF!\u00c5\u009a\u00d3>\u00d2\u0006\u00f6ª\u0080\u00ff\u00ec\u0095\u00d8¤q\u0002\u0080;\u0006\u00c1v\u00f5\u0097j|+/B+{S\u00e5¨»\u0095\u00f5¿\u0000\u0087g0&¾\u00e6M=\u0017\u00f8\u00ea\u00fd\u00da\u0001\u00cekFo\u00d5#\u0004¬\u00fd\u00ee6\u00dd¨\u0081\u0004WaD\u001bc\u0089{\u0007\u00e5\"\u009b\u00c4\u00d5\u0095\n\u00db\u00f5\u00c8\u00e3\u00c7W³\u0005/<¸\u00f9.¶(\u001d\u00d4l\u0016\"\u00f3\u00e0%\u008e\u00e34I\u00d5w\u00f9¢)³R:}\u00fe\u00c6#\u00f0\u00d0h\u0087¤\u000e>\u00ce\u009bi$\u0085\u00f7}\u00f8v\u00ad\u0017S¨¤&¢N\u0096\u00ceR[G\u00d5\u0084\u00db\u00c47H\u008c\u00d1-\u008c\u0000\u009d$\u00de\u00e5\n5\u00d0\u00eb\u00daZ\u0086\u0090`\u00f6\u001d¨^\u0098\u00c0\u009a@ah\u00c1n%\u0001>\u00cfno!\u00df\u0095\u009b\u009e<\u00ad\u0007q59\u0011{\u009c\u00909\u00fbJ\u0095^\u0084AR\u000f\u00caGTBª\u0091\u00ca\u00d4R\u009d\u001a\u00d8*\u008d\u001c\u0092^\u000f=+l\u00caO\u0094x\u0011§@#>½t\u00faga!\u00cc\u00e3\b\u0097©\u00fd±A\u0097O\u00d8\u009c\u008b*\n\u00f8\u008f,\u00c7\u000f:\u00e6\u00c7^\u00f5u\u00ce\u00c9\u0019\u00f3\u009b\\\u00e9j\u0083\u0012x \u0088ª\u0084\u001e\u000f\u00c1\u00fc\u00f6!\u000fD¾®\u0010\u0090b\u001dI\"V\u00fcfH2?c¸£\u00e2\u00d7D\u0096\b©´\u0015:\u0094\u00d4[\u00ef£$\u00189\u008dNN\u00f8\u00c5\u00cdY£E\u00d4\u0089\u001c\u00f7\u00ddg\u001d´\u00d3\u00f5\u00c7Ed\u0000\u0004\u00d0\u00d5eC\u0082\u0097\b\u009fr\u00fb\u00e3»\u0003\u0084\u00d320\u00d7\u00ccT\u00f3\u0080i\u00e3\u00d60x\u001b\u0093¾\u00e4\u00ef8\u008e\u00d4\u00cdP\u00ff\u00c6µ¤$7A¤\u001b\u00f3:oP\u008c(\u00d5\u008b\r\u00cb3\u008f-v7\u008f\u00d7\u0085\u00fa\u0082\u00f0\u0086>\u000e-\u00ff\u00ef½\u0091[\u00d8\u008b\u000fµµ\u0099\u00c4\u00dd@.ºu+ h\f\u001e±o)q\u0099\u00d4='±\u00db°¤\rM\u00d8\u008ez\u008c\u000f\u00fe!J>\u00e0s\u00c2«\u00c7\\!\u00fa\u0086\u00d4\u001f¯Kx\u0000\u00046\u008e\\\u009a\r\u00c0¼\u0000\u0098\u0087?±\u00d6B\u00daz\u00f4\u0099\u0004¿M\u0086~I[Z\u00e4\r&\u00ebUºb`i\u009en#2\u00dau\u00fe\u00e3u\u00f9\u00c68\u008c\n\nC\u008c\u00f4\u00c8\u00ed£\u00960\u0093\u000f\u0018\u00f6¢B8Qw¿'¥L\u00ca\u0005g\u00fd%\u009a\u001a\u0084\b\u0017J\u00db\u00fcQ.\u008e\u0090\u0093\u00d9\u00db\u008f\\s\u00e6\u008eC\u0010\u0085\u00da¼¼\u00e1\u001f\u0093«\u0011D\u0090\u008bOb\u00d4;\u001b1\u0010\u00e81+¬§\u0092t\u00d0\u0083¤\u001b\u00f9\u00cb\u00fe\u00d5µ\u00e4\u001c`\u00e9I=G\u00fd\u00c6\u0014+\u001e\u00d3:\u00dc\u009b¨\u00e5[\u0098\u0090¼y\u00ca¹\u00df\u0017\u0087\u0087\u0080%\tA\u00ef\u001b\u00cb\u00e9»:\u00f7\u00c5\u00f3\u0006\u001c½\u000e>\u00dc·%>\u00d9¼²\u0097+\u00c8\u0005xX\b\u00ecz®\u00c1\u0089²\u00c3\u000f\u00e4\u001dO\u00ec\u00c2\u00d4KdS©\u00dc¯K«n\u00138K±\u0090\u0090\u00ce!Oj\u00cd¶\u0016½\u0089%{\u0004K{&\u00fb¸\u00e6yGm9(¬.\u008e\u00fbX\u009b)\u0018)\u0085\u009a\u001d\r\u001a\u007f\u00dai\u00d9\u008f\u009e\u00f1\u00d1:\u00ff\u0085_Y\u00d5 >\u0014\u007f\u0015\u0005µ\u0096<\u0010 \u0082²]\u00e6\u00fd~\u0086S\r\u00fc\u0099;\t(\u001e;\u0017\rp\u00ee\bA\u0016\u00dd\u00dd\u0017l\u001c»¦(\u001b\u00e2\u00c6\u0019d\n2JB\u0080\u0096+\u00f1\u00c4?\u00d3\u00c2\u0090O$cFKH\u00cf\u0004I\u00e9\u009d\u008e\u00ec\u0014\u00e2 5d/\u009b7)j\u00ca/\u00c4§\u00c7\\u\u00c8\u00ec\u0085®\u00dfoT§\u00f22\u0015]\u0016\u00ddI\u0015\u000b¬(\u00f2VV\u0095J*º\u001d\u0083RxI}+C\u000e0x#B«\u0088\u00dd\u009c\u00f8\u00cd\u0089\u0017\u001dIQ]\u008b\u00de\u0089\u001fJ´\u00c1\u001f\u0015b\u0099\u00e9\u0097\u0081i\u0088\u00e2\u00e2\u00f9\u008f\u0095\u00c3\u00cd\u000e\\\u0094\u00c8¬M\u0005\rL\u0006\u00d6`\u0018º\u009f\u0019*\u0099\u0014½8\u00c0\u0093K'\u00fd+\u0010BI\u00126l\u00c2¨kXO[\u008a\u0010\u0091\u009c\u0015\u00e8\u00f4p8\u0003-\u00e2).fo\u008b\u00cf\n\u000eauS\u0019\u00d8\u00cc\u008aV7¼£9\u0005 IZ\u00fdp\u00f3\u0092\u0080x¥V\u0000\u00ce\u00cbR°2¬\u00d3W\u009a\u0003\u00cc\u0014[o\u00c7°\n§\u00e9\u00e2\u0091\u009c\u0094\u0003»¬\u00f2\u00fee\u001aD¬FA.\u0082®§P\u00eb\u0090¶¶\u00e8\u00d5W\u00ca+\u001b\u0080\u00d1\u0013gq\u00d1Y\u00d1/\u00e3\u008e\u00ddFY\u000b\u0018\u00dd\u00df\u0082m\u000e\u00cc\u00d0\u00c7\u00d3\n'§=B\b\u00f3\f\u001eY\u00ce1F\u0094² c{+\u00ffB}%OB\u00eby\u009f?\u001f\u0095%|\u0097¹x\u00f5\b>\u0083\u00ca\u00ce)¾\u00e5\u001d\u0004\u0081\u001a\u00d1\u00efc¨^;°Lys\u00c5\u00db!u$\u0002S¾\\\u00f2\u00d4\u0091o\u0091\u00f5^>°r6\u00e2\u00f0\u00cf\u00d7\u008c+U-¸\u00ecU8\u0085i\u008f\u00f7\u0010o\u0088+u\u00cc\u00c52#\u00ff©¡`]\u0085%1?®\u001e\u0007\u00dc_\u00f0\u00e1\u00e1\u008b g\u00d9u²I\u00d7\u0084{mR\u0017\u00cb\u00f9/>¥\u00ea\u001agI\u00f1\u00dd\u00daF'Mn\u00f7\u00c0;R\u001b\u00d8\u00e5\u00dal\u00e5\u009c\u00dbd´\u009b7\u008a\u00df\u00ef~\u00e2\u009db\u0098\bx@N\u0006\u001a\u00df]\u00c2\u0013£»¹AB* ¬&Y \"\u00c0\u001f\u008a\u00c5\u00ee\u00ed\u0087·\u008a\u0089n\u0090\u00ef\u009a\u0012\u00ce\u00d0\u0087´M\u00f0H\u00e1\u0015\u007fb\u000e\u009ft]&¡³\u00c6¾\u0091u\u009e$=\u00df\u0094!\u0096\u0011\u0005\u0017¤$\u00f0-").length();
        b(b);
        int char1 = 12;
        int index = -1;
        while (true) {
            int n4;
            int n3;
            final int n2 = n3 = (n4 = 97);
            ++index;
            final String s2 = s;
            final int beginIndex = index;
            final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
            final int length2 = charArray.length;
            int n5 = 0;
            while (true) {
                Label_0156: {
                    if (length2 > 1) {
                        break Label_0156;
                    }
                    n4 = (n3 = n5);
                    do {
                        final char c2 = charArray[n3];
                        int n6 = 0;
                        switch (n5 % 7) {
                            case 0: {
                                n6 = 118;
                                break;
                            }
                            case 1: {
                                n6 = 70;
                                break;
                            }
                            case 2: {
                                n6 = 11;
                                break;
                            }
                            case 3: {
                                n6 = 97;
                                break;
                            }
                            case 4: {
                                n6 = 62;
                                break;
                            }
                            case 5: {
                                n6 = 103;
                                break;
                            }
                            default: {
                                n6 = 105;
                                break;
                            }
                        }
                        charArray[n4] = (char)(c2 ^ (n2 ^ n6));
                        ++n5;
                    } while (n2 == 0);
                }
                if (length2 > n5) {
                    continue;
                }
                break;
            }
            a2[n++] = new String(charArray).intern();
            if ((index += char1) >= length) {
                break;
            }
            char1 = s.charAt(index);
        }
        final String s3;
        final int length3 = (s3 = "\u00f7»\u00f1\u00d7\u00101\u009b©\u0001f\u00cfk»\u0088´yC\u000e¯\u00d2\u0010").length();
        int char2 = 4;
        int index2 = -1;
        while (true) {
            int n9;
            int n8;
            final int n7 = n8 = (n9 = 9);
            ++index2;
            final String s4 = s3;
            final int beginIndex2 = index2;
            final char[] charArray2 = s4.substring(beginIndex2, beginIndex2 + char2).toCharArray();
            final int length4 = charArray2.length;
            int n10 = 0;
            while (true) {
                Label_0352: {
                    if (length4 > 1) {
                        break Label_0352;
                    }
                    n9 = (n8 = n10);
                    do {
                        final char c3 = charArray2[n8];
                        int n11 = 0;
                        switch (n10 % 7) {
                            case 0: {
                                n11 = 118;
                                break;
                            }
                            case 1: {
                                n11 = 70;
                                break;
                            }
                            case 2: {
                                n11 = 11;
                                break;
                            }
                            case 3: {
                                n11 = 97;
                                break;
                            }
                            case 4: {
                                n11 = 62;
                                break;
                            }
                            case 5: {
                                n11 = 103;
                                break;
                            }
                            default: {
                                n11 = 105;
                                break;
                            }
                        }
                        charArray2[n9] = (char)(c3 ^ (n7 ^ n11));
                        ++n10;
                    } while (n7 == 0);
                }
                if (length4 > n10) {
                    continue;
                }
                break;
            }
            a2[n++] = new String(charArray2).intern();
            if ((index2 += char2) >= length3) {
                break;
            }
            char2 = s3.charAt(index2);
        }
        a = a2;
        c = new String[42];
        logger = Logger.getLogger(GlobalScreen.class.getPackage().getName());
    }
    
    public static void b(final boolean b) {
        NativeHookDemo.b = b;
    }
    
    public static boolean b() {
        return NativeHookDemo.b;
    }
    
    public static boolean a() {
        final boolean b = b();
        try {
            if (!b) {
                return true;
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
        return false;
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0xFFFF9D85) & 0xFFFF;
        if (NativeHookDemo.c[n3] == null) {
            final char[] charArray = NativeHookDemo.a[n3].toCharArray();
            int n4 = 0;
            switch (charArray[0] & '\u00ff') {
                case 0: {
                    n4 = 3;
                    break;
                }
                case 1: {
                    n4 = 168;
                    break;
                }
                case 2: {
                    n4 = 0;
                    break;
                }
                case 3: {
                    n4 = 158;
                    break;
                }
                case 4: {
                    n4 = 225;
                    break;
                }
                case 5: {
                    n4 = 34;
                    break;
                }
                case 6: {
                    n4 = 227;
                    break;
                }
                case 7: {
                    n4 = 30;
                    break;
                }
                case 8: {
                    n4 = 66;
                    break;
                }
                case 9: {
                    n4 = 140;
                    break;
                }
                case 10: {
                    n4 = 122;
                    break;
                }
                case 11: {
                    n4 = 23;
                    break;
                }
                case 12: {
                    n4 = 148;
                    break;
                }
                case 13: {
                    n4 = 165;
                    break;
                }
                case 14: {
                    n4 = 33;
                    break;
                }
                case 15: {
                    n4 = 95;
                    break;
                }
                case 16: {
                    n4 = 177;
                    break;
                }
                case 17: {
                    n4 = 133;
                    break;
                }
                case 18: {
                    n4 = 187;
                    break;
                }
                case 19: {
                    n4 = 15;
                    break;
                }
                case 20: {
                    n4 = 38;
                    break;
                }
                case 21: {
                    n4 = 253;
                    break;
                }
                case 22: {
                    n4 = 17;
                    break;
                }
                case 23: {
                    n4 = 206;
                    break;
                }
                case 24: {
                    n4 = 110;
                    break;
                }
                case 25: {
                    n4 = 43;
                    break;
                }
                case 26: {
                    n4 = 147;
                    break;
                }
                case 27: {
                    n4 = 6;
                    break;
                }
                case 28: {
                    n4 = 52;
                    break;
                }
                case 29: {
                    n4 = 152;
                    break;
                }
                case 30: {
                    n4 = 8;
                    break;
                }
                case 31: {
                    n4 = 254;
                    break;
                }
                case 32: {
                    n4 = 65;
                    break;
                }
                case 33: {
                    n4 = 203;
                    break;
                }
                case 34: {
                    n4 = 249;
                    break;
                }
                case 35: {
                    n4 = 59;
                    break;
                }
                case 36: {
                    n4 = 76;
                    break;
                }
                case 37: {
                    n4 = 84;
                    break;
                }
                case 38: {
                    n4 = 241;
                    break;
                }
                case 39: {
                    n4 = 25;
                    break;
                }
                case 40: {
                    n4 = 144;
                    break;
                }
                case 41: {
                    n4 = 4;
                    break;
                }
                case 42: {
                    n4 = 234;
                    break;
                }
                case 43: {
                    n4 = 80;
                    break;
                }
                case 44: {
                    n4 = 151;
                    break;
                }
                case 45: {
                    n4 = 75;
                    break;
                }
                case 46: {
                    n4 = 32;
                    break;
                }
                case 47: {
                    n4 = 145;
                    break;
                }
                case 48: {
                    n4 = 246;
                    break;
                }
                case 49: {
                    n4 = 49;
                    break;
                }
                case 50: {
                    n4 = 181;
                    break;
                }
                case 51: {
                    n4 = 16;
                    break;
                }
                case 52: {
                    n4 = 231;
                    break;
                }
                case 53: {
                    n4 = 248;
                    break;
                }
                case 54: {
                    n4 = 5;
                    break;
                }
                case 55: {
                    n4 = 137;
                    break;
                }
                case 56: {
                    n4 = 22;
                    break;
                }
                case 57: {
                    n4 = 174;
                    break;
                }
                case 58: {
                    n4 = 127;
                    break;
                }
                case 59: {
                    n4 = 63;
                    break;
                }
                case 60: {
                    n4 = 243;
                    break;
                }
                case 61: {
                    n4 = 130;
                    break;
                }
                case 62: {
                    n4 = 170;
                    break;
                }
                case 63: {
                    n4 = 1;
                    break;
                }
                case 64: {
                    n4 = 92;
                    break;
                }
                case 65: {
                    n4 = 161;
                    break;
                }
                case 66: {
                    n4 = 82;
                    break;
                }
                case 67: {
                    n4 = 71;
                    break;
                }
                case 68: {
                    n4 = 119;
                    break;
                }
                case 69: {
                    n4 = 229;
                    break;
                }
                case 70: {
                    n4 = 113;
                    break;
                }
                case 71: {
                    n4 = 78;
                    break;
                }
                case 72: {
                    n4 = 141;
                    break;
                }
                case 73: {
                    n4 = 143;
                    break;
                }
                case 74: {
                    n4 = 48;
                    break;
                }
                case 75: {
                    n4 = 135;
                    break;
                }
                case 76: {
                    n4 = 157;
                    break;
                }
                case 77: {
                    n4 = 132;
                    break;
                }
                case 78: {
                    n4 = 213;
                    break;
                }
                case 79: {
                    n4 = 223;
                    break;
                }
                case 80: {
                    n4 = 14;
                    break;
                }
                case 81: {
                    n4 = 74;
                    break;
                }
                case 82: {
                    n4 = 112;
                    break;
                }
                case 83: {
                    n4 = 105;
                    break;
                }
                case 84: {
                    n4 = 93;
                    break;
                }
                case 85: {
                    n4 = 160;
                    break;
                }
                case 86: {
                    n4 = 230;
                    break;
                }
                case 87: {
                    n4 = 81;
                    break;
                }
                case 88: {
                    n4 = 2;
                    break;
                }
                case 89: {
                    n4 = 242;
                    break;
                }
                case 90: {
                    n4 = 255;
                    break;
                }
                case 91: {
                    n4 = 176;
                    break;
                }
                case 92: {
                    n4 = 154;
                    break;
                }
                case 93: {
                    n4 = 20;
                    break;
                }
                case 94: {
                    n4 = 102;
                    break;
                }
                case 95: {
                    n4 = 149;
                    break;
                }
                case 96: {
                    n4 = 134;
                    break;
                }
                case 97: {
                    n4 = 238;
                    break;
                }
                case 98: {
                    n4 = 39;
                    break;
                }
                case 99: {
                    n4 = 180;
                    break;
                }
                case 100: {
                    n4 = 216;
                    break;
                }
                case 101: {
                    n4 = 156;
                    break;
                }
                case 102: {
                    n4 = 190;
                    break;
                }
                case 103: {
                    n4 = 117;
                    break;
                }
                case 104: {
                    n4 = 64;
                    break;
                }
                case 105: {
                    n4 = 182;
                    break;
                }
                case 106: {
                    n4 = 72;
                    break;
                }
                case 107: {
                    n4 = 116;
                    break;
                }
                case 108: {
                    n4 = 245;
                    break;
                }
                case 109: {
                    n4 = 126;
                    break;
                }
                case 110: {
                    n4 = 88;
                    break;
                }
                case 111: {
                    n4 = 103;
                    break;
                }
                case 112: {
                    n4 = 51;
                    break;
                }
                case 113: {
                    n4 = 10;
                    break;
                }
                case 114: {
                    n4 = 142;
                    break;
                }
                case 115: {
                    n4 = 217;
                    break;
                }
                case 116: {
                    n4 = 56;
                    break;
                }
                case 117: {
                    n4 = 210;
                    break;
                }
                case 118: {
                    n4 = 244;
                    break;
                }
                case 119: {
                    n4 = 189;
                    break;
                }
                case 120: {
                    n4 = 215;
                    break;
                }
                case 121: {
                    n4 = 77;
                    break;
                }
                case 122: {
                    n4 = 91;
                    break;
                }
                case 123: {
                    n4 = 125;
                    break;
                }
                case 124: {
                    n4 = 198;
                    break;
                }
                case 125: {
                    n4 = 50;
                    break;
                }
                case 126: {
                    n4 = 19;
                    break;
                }
                case 127: {
                    n4 = 139;
                    break;
                }
                case 128: {
                    n4 = 44;
                    break;
                }
                case 129: {
                    n4 = 208;
                    break;
                }
                case 130: {
                    n4 = 70;
                    break;
                }
                case 131: {
                    n4 = 68;
                    break;
                }
                case 132: {
                    n4 = 62;
                    break;
                }
                case 133: {
                    n4 = 236;
                    break;
                }
                case 134: {
                    n4 = 199;
                    break;
                }
                case 135: {
                    n4 = 193;
                    break;
                }
                case 136: {
                    n4 = 41;
                    break;
                }
                case 137: {
                    n4 = 54;
                    break;
                }
                case 138: {
                    n4 = 128;
                    break;
                }
                case 139: {
                    n4 = 138;
                    break;
                }
                case 140: {
                    n4 = 136;
                    break;
                }
                case 141: {
                    n4 = 205;
                    break;
                }
                case 142: {
                    n4 = 28;
                    break;
                }
                case 143: {
                    n4 = 153;
                    break;
                }
                case 144: {
                    n4 = 97;
                    break;
                }
                case 145: {
                    n4 = 214;
                    break;
                }
                case 146: {
                    n4 = 202;
                    break;
                }
                case 147: {
                    n4 = 209;
                    break;
                }
                case 148: {
                    n4 = 188;
                    break;
                }
                case 149: {
                    n4 = 61;
                    break;
                }
                case 150: {
                    n4 = 69;
                    break;
                }
                case 151: {
                    n4 = 123;
                    break;
                }
                case 152: {
                    n4 = 29;
                    break;
                }
                case 153: {
                    n4 = 250;
                    break;
                }
                case 154: {
                    n4 = 87;
                    break;
                }
                case 155: {
                    n4 = 247;
                    break;
                }
                case 156: {
                    n4 = 98;
                    break;
                }
                case 157: {
                    n4 = 83;
                    break;
                }
                case 158: {
                    n4 = 183;
                    break;
                }
                case 159: {
                    n4 = 235;
                    break;
                }
                case 160: {
                    n4 = 73;
                    break;
                }
                case 161: {
                    n4 = 224;
                    break;
                }
                case 162: {
                    n4 = 13;
                    break;
                }
                case 163: {
                    n4 = 186;
                    break;
                }
                case 164: {
                    n4 = 196;
                    break;
                }
                case 165: {
                    n4 = 191;
                    break;
                }
                case 166: {
                    n4 = 192;
                    break;
                }
                case 167: {
                    n4 = 252;
                    break;
                }
                case 168: {
                    n4 = 11;
                    break;
                }
                case 169: {
                    n4 = 171;
                    break;
                }
                case 170: {
                    n4 = 155;
                    break;
                }
                case 171: {
                    n4 = 40;
                    break;
                }
                case 172: {
                    n4 = 47;
                    break;
                }
                case 173: {
                    n4 = 104;
                    break;
                }
                case 174: {
                    n4 = 228;
                    break;
                }
                case 175: {
                    n4 = 218;
                    break;
                }
                case 176: {
                    n4 = 31;
                    break;
                }
                case 177: {
                    n4 = 232;
                    break;
                }
                case 178: {
                    n4 = 45;
                    break;
                }
                case 179: {
                    n4 = 35;
                    break;
                }
                case 180: {
                    n4 = 79;
                    break;
                }
                case 181: {
                    n4 = 85;
                    break;
                }
                case 182: {
                    n4 = 167;
                    break;
                }
                case 183: {
                    n4 = 27;
                    break;
                }
                case 184: {
                    n4 = 89;
                    break;
                }
                case 185: {
                    n4 = 219;
                    break;
                }
                case 186: {
                    n4 = 96;
                    break;
                }
                case 187: {
                    n4 = 60;
                    break;
                }
                case 188: {
                    n4 = 109;
                    break;
                }
                case 189: {
                    n4 = 120;
                    break;
                }
                case 190: {
                    n4 = 150;
                    break;
                }
                case 191: {
                    n4 = 197;
                    break;
                }
                case 192: {
                    n4 = 185;
                    break;
                }
                case 193: {
                    n4 = 184;
                    break;
                }
                case 194: {
                    n4 = 179;
                    break;
                }
                case 195: {
                    n4 = 200;
                    break;
                }
                case 196: {
                    n4 = 237;
                    break;
                }
                case 197: {
                    n4 = 194;
                    break;
                }
                case 198: {
                    n4 = 175;
                    break;
                }
                case 199: {
                    n4 = 222;
                    break;
                }
                case 200: {
                    n4 = 86;
                    break;
                }
                case 201: {
                    n4 = 115;
                    break;
                }
                case 202: {
                    n4 = 226;
                    break;
                }
                case 203: {
                    n4 = 21;
                    break;
                }
                case 204: {
                    n4 = 111;
                    break;
                }
                case 205: {
                    n4 = 7;
                    break;
                }
                case 206: {
                    n4 = 114;
                    break;
                }
                case 207: {
                    n4 = 106;
                    break;
                }
                case 208: {
                    n4 = 18;
                    break;
                }
                case 209: {
                    n4 = 173;
                    break;
                }
                case 210: {
                    n4 = 26;
                    break;
                }
                case 211: {
                    n4 = 90;
                    break;
                }
                case 212: {
                    n4 = 121;
                    break;
                }
                case 213: {
                    n4 = 107;
                    break;
                }
                case 214: {
                    n4 = 220;
                    break;
                }
                case 215: {
                    n4 = 166;
                    break;
                }
                case 216: {
                    n4 = 67;
                    break;
                }
                case 217: {
                    n4 = 124;
                    break;
                }
                case 218: {
                    n4 = 118;
                    break;
                }
                case 219: {
                    n4 = 108;
                    break;
                }
                case 220: {
                    n4 = 195;
                    break;
                }
                case 221: {
                    n4 = 99;
                    break;
                }
                case 222: {
                    n4 = 201;
                    break;
                }
                case 223: {
                    n4 = 100;
                    break;
                }
                case 224: {
                    n4 = 37;
                    break;
                }
                case 225: {
                    n4 = 55;
                    break;
                }
                case 226: {
                    n4 = 162;
                    break;
                }
                case 227: {
                    n4 = 12;
                    break;
                }
                case 228: {
                    n4 = 164;
                    break;
                }
                case 229: {
                    n4 = 94;
                    break;
                }
                case 230: {
                    n4 = 212;
                    break;
                }
                case 231: {
                    n4 = 53;
                    break;
                }
                case 232: {
                    n4 = 172;
                    break;
                }
                case 233: {
                    n4 = 131;
                    break;
                }
                case 234: {
                    n4 = 9;
                    break;
                }
                case 235: {
                    n4 = 207;
                    break;
                }
                case 236: {
                    n4 = 129;
                    break;
                }
                case 237: {
                    n4 = 221;
                    break;
                }
                case 238: {
                    n4 = 169;
                    break;
                }
                case 239: {
                    n4 = 42;
                    break;
                }
                case 240: {
                    n4 = 163;
                    break;
                }
                case 241: {
                    n4 = 46;
                    break;
                }
                case 242: {
                    n4 = 146;
                    break;
                }
                case 243: {
                    n4 = 211;
                    break;
                }
                case 244: {
                    n4 = 204;
                    break;
                }
                case 245: {
                    n4 = 57;
                    break;
                }
                case 246: {
                    n4 = 101;
                    break;
                }
                case 247: {
                    n4 = 58;
                    break;
                }
                case 248: {
                    n4 = 159;
                    break;
                }
                case 249: {
                    n4 = 24;
                    break;
                }
                case 250: {
                    n4 = 36;
                    break;
                }
                case 251: {
                    n4 = 178;
                    break;
                }
                case 252: {
                    n4 = 233;
                    break;
                }
                case 253: {
                    n4 = 251;
                    break;
                }
                case 254: {
                    n4 = 240;
                    break;
                }
                default: {
                    n4 = 239;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < charArray.length; ++i) {
                final int n8 = i % 2;
                final char[] array = charArray;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ charArray[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ charArray[i]) & 0xFF);
                }
            }
            NativeHookDemo.c[n3] = new String(charArray).intern();
        }
        return NativeHookDemo.c[n3];
    }
}
