// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.example;

final class NativeHookDemo$1 implements Runnable
{
    public void run() {
        new NativeHookDemo();
    }
}
