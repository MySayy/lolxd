// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.example;

import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;
import java.util.logging.LogRecord;
import java.util.logging.Formatter;

final class NativeHookDemo$LogFormatter extends Formatter
{
    final NativeHookDemo this$0;
    private static final String a;
    
    private NativeHookDemo$LogFormatter(final NativeHookDemo this$0) {
        this.this$0 = this$0;
    }
    
    @Override
    public String format(final LogRecord record) {
        final boolean b = NativeHookDemo.b();
        final StringBuilder sb = new StringBuilder();
        Label_0129: {
            try {
                final StringBuilder append = sb.append(new Date(record.getMillis())).append(" ").append(record.getLevel().getLocalizedName()).append(NativeHookDemo$LogFormatter.a).append(this.formatMessage(record));
                if (b) {
                    return append.toString();
                }
                if (record.getThrown() == null) {
                    break Label_0129;
                }
            }
            catch (Exception ex) {
                throw b(ex);
            }
            try {
                final StringWriter out = new StringWriter();
                final PrintWriter s = new PrintWriter(out);
                record.getThrown().printStackTrace(s);
                s.close();
                sb.append(out.toString());
                out.close();
            }
            catch (Exception ex2) {}
        }
        final StringBuilder append = sb;
        return append.toString();
    }
    
    NativeHookDemo$LogFormatter(final NativeHookDemo nativeHookDemo, final NativeHookDemo$1 nativeHookDemo$1) {
        this(nativeHookDemo);
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 41);
        final char[] charArray = "Q+".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0116: {
                if (length > 1) {
                    break Label_0116;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 66;
                            break;
                        }
                        case 1: {
                            n5 = 11;
                            break;
                        }
                        case 2: {
                            n5 = 21;
                            break;
                        }
                        case 3: {
                            n5 = 101;
                            break;
                        }
                        case 4: {
                            n5 = 52;
                            break;
                        }
                        case 5: {
                            n5 = 14;
                            break;
                        }
                        default: {
                            n5 = 44;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
