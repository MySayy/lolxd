// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.dispatcher;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadPoolExecutor;

public class DefaultDispatchService extends ThreadPoolExecutor
{
    private static int b;
    
    public DefaultDispatchService() {
        super(1, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(), new DefaultDispatchService$1());
    }
    
    public static void b(final int b) {
        DefaultDispatchService.b = b;
    }
    
    public static int b() {
        return DefaultDispatchService.b;
    }
    
    public static int c() {
        final int b = b();
        try {
            if (b == 0) {
                return 28;
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
        return 0;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
    
    static {
        if (c() != 0) {
            b(118);
        }
    }
}
