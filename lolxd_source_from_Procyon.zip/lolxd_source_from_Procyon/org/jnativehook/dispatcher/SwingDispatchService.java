// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.dispatcher;

import javax.swing.SwingUtilities;
import java.util.concurrent.TimeUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.AbstractExecutorService;

public class SwingDispatchService extends AbstractExecutorService
{
    private boolean running;
    
    public SwingDispatchService() {
        this.running = false;
        this.running = true;
    }
    
    public void shutdown() {
        this.running = false;
    }
    
    public List<Runnable> shutdownNow() {
        this.running = false;
        return new ArrayList<Runnable>(0);
    }
    
    public boolean isShutdown() {
        final int b = DefaultDispatchService.b();
        boolean running = false;
        Label_0037: {
            Label_0023: {
                try {
                    running = this.running;
                    if (b == 0) {
                        return running;
                    }
                    final int n = b;
                    if (n != 0) {
                        break Label_0023;
                    }
                    return running;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final int n = b;
                    if (n == 0) {
                        return running;
                    }
                    if (running) {
                        break Label_0037;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            return running;
        }
        return running;
    }
    
    public boolean isTerminated() {
        final int b = DefaultDispatchService.b();
        boolean running = false;
        Label_0037: {
            Label_0023: {
                try {
                    running = this.running;
                    if (b == 0) {
                        return running;
                    }
                    final int n = b;
                    if (n != 0) {
                        break Label_0023;
                    }
                    return running;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final int n = b;
                    if (n == 0) {
                        return running;
                    }
                    if (running) {
                        break Label_0037;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            return running;
        }
        return running;
    }
    
    public boolean awaitTermination(final long n, final TimeUnit timeUnit) throws InterruptedException {
        return true;
    }
    
    public void execute(final Runnable doRun) {
        SwingUtilities.invokeLater(doRun);
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
