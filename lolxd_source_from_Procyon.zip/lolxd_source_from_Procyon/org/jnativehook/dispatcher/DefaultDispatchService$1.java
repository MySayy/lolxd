// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook.dispatcher;

import com.sun.jna.Structure;
import java.util.concurrent.ThreadFactory;

class DefaultDispatchService$1 implements ThreadFactory
{
    private static final String a;
    
    public Thread newThread(final Runnable target) {
        final Thread thread = new Thread(target);
        thread.setName(DefaultDispatchService$1.a);
        final int b = DefaultDispatchService.b();
        thread.setDaemon(true);
        final int n = b;
        final Thread thread2 = thread;
        if (n == 0) {
            int a = Structure.a();
            Structure.b(++a);
        }
        return thread2;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 1);
        final char[] charArray = "S+u\u0012\u0016\u000b.Q\n{\r_9\"j\u0015u\u0012\u001c\u0015kM\rf\u0003\u001e\u0019".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0116: {
                if (length > 1) {
                    break Label_0116;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 24;
                            break;
                        }
                        case 1: {
                            n5 = 100;
                            break;
                        }
                        case 2: {
                            n5 = 21;
                            break;
                        }
                        case 3: {
                            n5 = 103;
                            break;
                        }
                        case 4: {
                            n5 = 126;
                            break;
                        }
                        case 5: {
                            n5 = 124;
                            break;
                        }
                        default: {
                            n5 = 74;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
