// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook;

import java.util.concurrent.ExecutorService;

public class GlobalScreen$NativeHookThread extends Thread
{
    protected NativeHookException exception;
    private static final String a;
    
    public GlobalScreen$NativeHookThread() {
        this.setName(GlobalScreen$NativeHookThread.a);
        this.setDaemon(false);
        this.setPriority(10);
    }
    
    @Override
    public void run() {
        this.exception = null;
        try {
            this.enable();
        }
        catch (NativeHookException exception) {
            this.exception = exception;
        }
        synchronized (this) {
            this.notifyAll();
        }
    }
    
    public NativeHookException getException() {
        return this.exception;
    }
    
    protected native void enable() throws NativeHookException;
    
    public native void disable() throws NativeHookException;
    
    protected static void dispatchEvent(final NativeInputEvent nativeInputEvent) {
        final int[] b = NativeInputEvent.b();
        ExecutorService eventExecutor = null;
        Label_0035: {
            Label_0022: {
                try {
                    eventExecutor = GlobalScreen.eventExecutor;
                    if (b == null) {
                        break Label_0035;
                    }
                    final int[] array = b;
                    if (array != null) {
                        break Label_0022;
                    }
                    break Label_0035;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final int[] array = b;
                    if (array == null) {
                        break Label_0035;
                    }
                    if (eventExecutor == null) {
                        return;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            final ExecutorService eventExecutor2 = GlobalScreen.eventExecutor;
        }
        eventExecutor.execute(new GlobalScreen$EventDispatchTask(nativeInputEvent));
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 99);
        final char[] charArray = "! ;\u0005(m\u0001#\u00015\u001aaS\u000b\u0004\u0005z%)i\u0001\n\n".toCharArray();
        final int length = charArray.length;
        int n4 = 0;
        while (true) {
            Label_0116: {
                if (length > 1) {
                    break Label_0116;
                }
                n3 = (n2 = n4);
                do {
                    final char c = charArray[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 8;
                            break;
                        }
                        case 1: {
                            n5 = 13;
                            break;
                        }
                        case 2: {
                            n5 = 57;
                            break;
                        }
                        case 3: {
                            n5 = 18;
                            break;
                        }
                        case 4: {
                            n5 = 34;
                            break;
                        }
                        case 5: {
                            n5 = 120;
                            break;
                        }
                        default: {
                            n5 = 7;
                            break;
                        }
                    }
                    charArray[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = new String(charArray).intern();
                return;
            }
            continue;
        }
    }
}
