// 
// Decompiled by Procyon v0.5.36
// 

package org.jnativehook;

import com.sun.jna.Structure;
import java.util.EventObject;

public class NativeInputEvent extends EventObject
{
    private static final long serialVersionUID = 2306729722565226621L;
    private int id;
    private long when;
    private int modifiers;
    private short reserved;
    public static final int SHIFT_L_MASK = 1;
    public static final int CTRL_L_MASK = 2;
    public static final int META_L_MASK = 4;
    public static final int ALT_L_MASK = 8;
    public static final int SHIFT_R_MASK = 16;
    public static final int CTRL_R_MASK = 32;
    public static final int META_R_MASK = 64;
    public static final int ALT_R_MASK = 128;
    public static final int SHIFT_MASK = 17;
    public static final int CTRL_MASK = 34;
    public static final int META_MASK = 68;
    public static final int ALT_MASK = 136;
    public static final int BUTTON1_MASK = 256;
    public static final int BUTTON2_MASK = 512;
    public static final int BUTTON3_MASK = 1024;
    public static final int BUTTON4_MASK = 2048;
    public static final int BUTTON5_MASK = 4096;
    public static final int NUM_LOCK_MASK = 8192;
    public static final int CAPS_LOCK_MASK = 16384;
    public static final int SCROLL_LOCK_MASK = 32768;
    private static int[] b;
    private static final String[] a;
    private static final String[] c;
    
    public NativeInputEvent(final Class<GlobalScreen> source, final int id, final int modifiers) {
        super(source);
        this.id = id;
        this.when = 0L;
        this.modifiers = modifiers;
        this.reserved = 0;
    }
    
    public int getID() {
        return this.id;
    }
    
    public long getWhen() {
        return this.when;
    }
    
    public int getModifiers() {
        return this.modifiers;
    }
    
    public void setModifiers(final int modifiers) {
        this.modifiers = modifiers;
    }
    
    private void setReserved(final short reserved) {
        this.reserved = reserved;
    }
    
    public static String getModifiersText(final int p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: new             Ljava/lang/StringBuilder;
        //     7: dup            
        //     8: sipush          255
        //    11: invokespecial   java/lang/StringBuilder.<init>:(I)V
        //    14: astore_3       
        //    15: aload_1        
        //    16: ifnull          77
        //    19: iload_0        
        //    20: bipush          17
        //    22: iand           
        //    23: aload_1        
        //    24: ifnull          88
        //    27: goto            34
        //    30: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    33: athrow         
        //    34: ifeq            84
        //    37: goto            44
        //    40: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    43: athrow         
        //    44: aload_3        
        //    45: sipush          -28616
        //    48: sipush          -21689
        //    51: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //    54: sipush          -28612
        //    57: sipush          30178
        //    60: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //    63: invokestatic    java/awt/Toolkit.getProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //    66: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    69: pop            
        //    70: goto            77
        //    73: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    76: athrow         
        //    77: aload_3        
        //    78: bipush          43
        //    80: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //    83: pop            
        //    84: iload_0        
        //    85: bipush          34
        //    87: iand           
        //    88: aload_1        
        //    89: ifnull          146
        //    92: ifeq            142
        //    95: goto            102
        //    98: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   101: athrow         
        //   102: aload_3        
        //   103: sipush          -28617
        //   106: sipush          18001
        //   109: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   112: sipush          -28622
        //   115: sipush          8246
        //   118: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   121: invokestatic    java/awt/Toolkit.getProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   124: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   127: pop            
        //   128: aload_3        
        //   129: bipush          43
        //   131: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   134: pop            
        //   135: goto            142
        //   138: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   141: athrow         
        //   142: iload_0        
        //   143: bipush          68
        //   145: iand           
        //   146: aload_1        
        //   147: ifnull          205
        //   150: ifeq            200
        //   153: goto            160
        //   156: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   159: athrow         
        //   160: aload_3        
        //   161: sipush          -28613
        //   164: sipush          -15718
        //   167: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   170: sipush          -28618
        //   173: sipush          32491
        //   176: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   179: invokestatic    java/awt/Toolkit.getProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   182: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   185: pop            
        //   186: aload_3        
        //   187: bipush          43
        //   189: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   192: pop            
        //   193: goto            200
        //   196: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   199: athrow         
        //   200: iload_0        
        //   201: sipush          136
        //   204: iand           
        //   205: aload_1        
        //   206: ifnull          264
        //   209: ifeq            259
        //   212: goto            219
        //   215: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   218: athrow         
        //   219: aload_3        
        //   220: sipush          -28633
        //   223: sipush          12285
        //   226: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   229: sipush          -28614
        //   232: sipush          -8090
        //   235: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   238: invokestatic    java/awt/Toolkit.getProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   241: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   244: pop            
        //   245: aload_3        
        //   246: bipush          43
        //   248: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   251: pop            
        //   252: goto            259
        //   255: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   258: athrow         
        //   259: iload_0        
        //   260: sipush          256
        //   263: iand           
        //   264: aload_1        
        //   265: ifnull          323
        //   268: ifeq            318
        //   271: goto            278
        //   274: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   277: athrow         
        //   278: aload_3        
        //   279: sipush          -28635
        //   282: sipush          16359
        //   285: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   288: sipush          -28636
        //   291: sipush          9376
        //   294: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   297: invokestatic    java/awt/Toolkit.getProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   300: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   303: pop            
        //   304: aload_3        
        //   305: bipush          43
        //   307: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   310: pop            
        //   311: goto            318
        //   314: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   317: athrow         
        //   318: iload_0        
        //   319: sipush          512
        //   322: iand           
        //   323: aload_1        
        //   324: ifnull          382
        //   327: ifeq            377
        //   330: goto            337
        //   333: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   336: athrow         
        //   337: aload_3        
        //   338: sipush          -28627
        //   341: sipush          -8541
        //   344: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   347: sipush          -28632
        //   350: sipush          -1322
        //   353: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   356: invokestatic    java/awt/Toolkit.getProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   359: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   362: pop            
        //   363: aload_3        
        //   364: bipush          43
        //   366: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   369: pop            
        //   370: goto            377
        //   373: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   376: athrow         
        //   377: iload_0        
        //   378: sipush          1024
        //   381: iand           
        //   382: aload_1        
        //   383: ifnull          441
        //   386: ifeq            436
        //   389: goto            396
        //   392: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   395: athrow         
        //   396: aload_3        
        //   397: sipush          -28629
        //   400: sipush          -5486
        //   403: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   406: sipush          -28621
        //   409: sipush          -17858
        //   412: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   415: invokestatic    java/awt/Toolkit.getProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   418: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   421: pop            
        //   422: aload_3        
        //   423: bipush          43
        //   425: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   428: pop            
        //   429: goto            436
        //   432: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   435: athrow         
        //   436: iload_0        
        //   437: sipush          2048
        //   440: iand           
        //   441: aload_1        
        //   442: ifnull          500
        //   445: ifeq            495
        //   448: goto            455
        //   451: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   454: athrow         
        //   455: aload_3        
        //   456: sipush          -28611
        //   459: sipush          -7366
        //   462: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   465: sipush          -28623
        //   468: sipush          31026
        //   471: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   474: invokestatic    java/awt/Toolkit.getProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   477: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   480: pop            
        //   481: aload_3        
        //   482: bipush          43
        //   484: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   487: pop            
        //   488: goto            495
        //   491: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   494: athrow         
        //   495: iload_0        
        //   496: sipush          4096
        //   499: iand           
        //   500: aload_1        
        //   501: ifnull          559
        //   504: ifeq            554
        //   507: goto            514
        //   510: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   513: athrow         
        //   514: aload_3        
        //   515: sipush          -28609
        //   518: sipush          -11152
        //   521: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   524: sipush          -28624
        //   527: sipush          13971
        //   530: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   533: invokestatic    java/awt/Toolkit.getProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   536: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   539: pop            
        //   540: aload_3        
        //   541: bipush          43
        //   543: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   546: pop            
        //   547: goto            554
        //   550: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   553: athrow         
        //   554: iload_0        
        //   555: sipush          8192
        //   558: iand           
        //   559: aload_1        
        //   560: ifnull          618
        //   563: ifeq            613
        //   566: goto            573
        //   569: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   572: athrow         
        //   573: aload_3        
        //   574: sipush          -28620
        //   577: sipush          4968
        //   580: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   583: sipush          -28630
        //   586: sipush          -17065
        //   589: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   592: invokestatic    java/awt/Toolkit.getProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   595: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   598: pop            
        //   599: aload_3        
        //   600: bipush          43
        //   602: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   605: pop            
        //   606: goto            613
        //   609: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   612: athrow         
        //   613: iload_0        
        //   614: sipush          16384
        //   617: iand           
        //   618: aload_1        
        //   619: ifnull          676
        //   622: ifeq            672
        //   625: goto            632
        //   628: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   631: athrow         
        //   632: aload_3        
        //   633: sipush          -28631
        //   636: sipush          30473
        //   639: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   642: sipush          -28634
        //   645: sipush          29262
        //   648: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   651: invokestatic    java/awt/Toolkit.getProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   654: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   657: pop            
        //   658: aload_3        
        //   659: bipush          43
        //   661: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   664: pop            
        //   665: goto            672
        //   668: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   671: athrow         
        //   672: iload_0        
        //   673: ldc             32768
        //   675: iand           
        //   676: aload_1        
        //   677: ifnull          749
        //   680: ifeq            730
        //   683: goto            690
        //   686: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   689: athrow         
        //   690: aload_3        
        //   691: sipush          -28610
        //   694: sipush          -9179
        //   697: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   700: sipush          -28615
        //   703: sipush          27648
        //   706: invokestatic    org/jnativehook/NativeInputEvent.a:(II)Ljava/lang/String;
        //   709: invokestatic    java/awt/Toolkit.getProperty:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //   712: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   715: pop            
        //   716: aload_3        
        //   717: bipush          43
        //   719: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   722: goto            729
        //   725: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   728: athrow         
        //   729: pop            
        //   730: aload_3        
        //   731: aload_1        
        //   732: ifnull          729
        //   735: aload_1        
        //   736: ifnull          775
        //   739: invokevirtual   java/lang/StringBuilder.length:()I
        //   742: goto            749
        //   745: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   748: athrow         
        //   749: ifle            770
        //   752: aload_3        
        //   753: aload_3        
        //   754: invokevirtual   java/lang/StringBuilder.length:()I
        //   757: iconst_1       
        //   758: isub           
        //   759: invokevirtual   java/lang/StringBuilder.deleteCharAt:(I)Ljava/lang/StringBuilder;
        //   762: goto            769
        //   765: invokestatic    org/jnativehook/NativeInputEvent.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   768: athrow         
        //   769: pop            
        //   770: aload_3        
        //   771: aload_1        
        //   772: ifnull          769
        //   775: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   778: aload_1        
        //   779: ifnonnull       793
        //   782: invokestatic    com/sun/jna/Structure.b:()I
        //   785: istore_2       
        //   786: iinc            2, 1
        //   789: iload_2        
        //   790: invokestatic    com/sun/jna/Structure.b:(I)V
        //   793: areturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  15     27     30     34     Ljava/lang/RuntimeException;
        //  19     37     40     44     Ljava/lang/RuntimeException;
        //  34     70     73     77     Ljava/lang/RuntimeException;
        //  88     95     98     102    Ljava/lang/RuntimeException;
        //  92     135    138    142    Ljava/lang/RuntimeException;
        //  146    153    156    160    Ljava/lang/RuntimeException;
        //  150    193    196    200    Ljava/lang/RuntimeException;
        //  205    212    215    219    Ljava/lang/RuntimeException;
        //  209    252    255    259    Ljava/lang/RuntimeException;
        //  264    271    274    278    Ljava/lang/RuntimeException;
        //  268    311    314    318    Ljava/lang/RuntimeException;
        //  323    330    333    337    Ljava/lang/RuntimeException;
        //  327    370    373    377    Ljava/lang/RuntimeException;
        //  382    389    392    396    Ljava/lang/RuntimeException;
        //  386    429    432    436    Ljava/lang/RuntimeException;
        //  441    448    451    455    Ljava/lang/RuntimeException;
        //  445    488    491    495    Ljava/lang/RuntimeException;
        //  500    507    510    514    Ljava/lang/RuntimeException;
        //  504    547    550    554    Ljava/lang/RuntimeException;
        //  559    566    569    573    Ljava/lang/RuntimeException;
        //  563    606    609    613    Ljava/lang/RuntimeException;
        //  618    625    628    632    Ljava/lang/RuntimeException;
        //  622    665    668    672    Ljava/lang/RuntimeException;
        //  676    683    686    690    Ljava/lang/RuntimeException;
        //  680    722    725    729    Ljava/lang/RuntimeException;
        //  735    742    745    749    Ljava/lang/RuntimeException;
        //  749    762    765    769    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0034:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public String paramString() {
        final StringBuilder sb = new StringBuilder(255);
        sb.append(a(-28625, 19857));
        b();
        sb.append(this.getID());
        sb.append(',');
        sb.append(a(-28626, -27886));
        sb.append(this.getWhen());
        sb.append(',');
        sb.append(a(-28619, -22102));
        sb.append(Integer.toBinaryString(this.getModifiers()));
        sb.append(',');
        sb.append(a(-28628, 7865));
        String string;
        try {
            sb.append(getModifiersText(this.getModifiers()));
            string = sb.toString();
            if (Structure.b() != 0) {
                b(new int[2]);
            }
        }
        catch (RuntimeException ex) {
            throw b(ex);
        }
        return string;
    }
    
    public static void b(final int[] b) {
        NativeInputEvent.b = b;
    }
    
    public static int[] b() {
        return NativeInputEvent.b;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
    
    static {
        final String[] a2 = new String[28];
        int n = 0;
        final int[] array = new int[3];
        final String s;
        final int length = (s = "\t²j\u00c6\u00ec´\u00d6\u00c8²\u00fb\u00e2\u000e¾\u0018\u009c\u0093#\b\u001a\u0090\u00ee\u008as\u00c2: \u000b\u008e\u00fa\u009a\u00cf\u00f2\u0095\u0015\u00ec\u00ca\u007f\u00ec\u0005\u0093\u00d6T\u00da§\b\u008dz\u00fa\u00df\u00f1\u0087\u009b©\u0003\u00daD0\u000b&\u00eb\u00f9\u001er\u00df\u009e§e$F\t¿L¼\u0019'R\u0081¸\u00fd\u000b`tG\u001eHµy±\u0003\u00d53\u0004\u00ecx{¤\u0005IO\u00ec\u00cc \u000b\u00faH\u0014\u0099/_:\u008d\u0015aH\u0007M\u00f7¡R¼,7\u0004\u0094\u0090½\u0087\u0007b'DH\u0000o§\u0007\u0099\u00c2;\u00f4\u00ef\u00f8[\u0003»\u00f3x\u0005*³\u00cf~\u0010\u000b²`\u001d\u009c\u0002\u00ff\u000b¡\t\u00d6\u0092\n§\t&\u00c9W\u00e64\u001b\u00c1\u0014\u000b\u00e8\u008fVak@&V¬('\bD\u00d0\u0014\u00e2\u0013\u00e5\u00d5¤\f}\u0010\u00e4\u0092<*\u00e9\u008a\u00f2U\u00fb^\u0007\u001d\u00cf«U\u00fd\u00cc\u001e\u0007$\u00f5\u00cf.[°C\t\u0017\u00c0\u00cf%º\u0007\r·µ").length();
        b(array);
        int char1 = 11;
        int index = -1;
        while (true) {
            int n4;
            int n3;
            final int n2 = n3 = (n4 = 17);
            ++index;
            final String s2 = s;
            final int beginIndex = index;
            final char[] charArray = s2.substring(beginIndex, beginIndex + char1).toCharArray();
            final int length2 = charArray.length;
            int n5 = 0;
            while (true) {
                Label_0160: {
                    if (length2 > 1) {
                        break Label_0160;
                    }
                    n4 = (n3 = n5);
                    do {
                        final char c2 = charArray[n3];
                        int n6 = 0;
                        switch (n5 % 7) {
                            case 0: {
                                n6 = 43;
                                break;
                            }
                            case 1: {
                                n6 = 34;
                                break;
                            }
                            case 2: {
                                n6 = 32;
                                break;
                            }
                            case 3: {
                                n6 = 116;
                                break;
                            }
                            case 4: {
                                n6 = 42;
                                break;
                            }
                            case 5: {
                                n6 = 79;
                                break;
                            }
                            default: {
                                n6 = 103;
                                break;
                            }
                        }
                        charArray[n4] = (char)(c2 ^ (n2 ^ n6));
                        ++n5;
                    } while (n2 == 0);
                }
                if (length2 > n5) {
                    continue;
                }
                break;
            }
            a2[n++] = new String(charArray).intern();
            if ((index += char1) >= length) {
                break;
            }
            char1 = s.charAt(index);
        }
        final String s3;
        final int length3 = (s3 = "\u00df\u0018\u009b¸\u00f9P_\u007f¨&\u008e\u0007\u008822\u00c1\u00e5u5").length();
        int char2 = 11;
        int index2 = -1;
        while (true) {
            int n9;
            int n8;
            final int n7 = n8 = (n9 = 82);
            ++index2;
            final String s4 = s3;
            final int beginIndex2 = index2;
            final char[] charArray2 = s4.substring(beginIndex2, beginIndex2 + char2).toCharArray();
            final int length4 = charArray2.length;
            int n10 = 0;
            while (true) {
                Label_0356: {
                    if (length4 > 1) {
                        break Label_0356;
                    }
                    n9 = (n8 = n10);
                    do {
                        final char c3 = charArray2[n8];
                        int n11 = 0;
                        switch (n10 % 7) {
                            case 0: {
                                n11 = 43;
                                break;
                            }
                            case 1: {
                                n11 = 34;
                                break;
                            }
                            case 2: {
                                n11 = 32;
                                break;
                            }
                            case 3: {
                                n11 = 116;
                                break;
                            }
                            case 4: {
                                n11 = 42;
                                break;
                            }
                            case 5: {
                                n11 = 79;
                                break;
                            }
                            default: {
                                n11 = 103;
                                break;
                            }
                        }
                        charArray2[n9] = (char)(c3 ^ (n7 ^ n11));
                        ++n10;
                    } while (n7 == 0);
                }
                if (length4 > n10) {
                    continue;
                }
                break;
            }
            a2[n++] = new String(charArray2).intern();
            if ((index2 += char2) >= length3) {
                break;
            }
            char2 = s3.charAt(index2);
        }
        a = a2;
        c = new String[28];
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0xFFFF903F) & 0xFFFF;
        if (NativeInputEvent.c[n3] == null) {
            final char[] charArray = NativeInputEvent.a[n3].toCharArray();
            int n4 = 0;
            switch (charArray[0] & '\u00ff') {
                case 0: {
                    n4 = 132;
                    break;
                }
                case 1: {
                    n4 = 25;
                    break;
                }
                case 2: {
                    n4 = 170;
                    break;
                }
                case 3: {
                    n4 = 55;
                    break;
                }
                case 4: {
                    n4 = 62;
                    break;
                }
                case 5: {
                    n4 = 4;
                    break;
                }
                case 6: {
                    n4 = 36;
                    break;
                }
                case 7: {
                    n4 = 207;
                    break;
                }
                case 8: {
                    n4 = 151;
                    break;
                }
                case 9: {
                    n4 = 15;
                    break;
                }
                case 10: {
                    n4 = 199;
                    break;
                }
                case 11: {
                    n4 = 37;
                    break;
                }
                case 12: {
                    n4 = 198;
                    break;
                }
                case 13: {
                    n4 = 126;
                    break;
                }
                case 14: {
                    n4 = 98;
                    break;
                }
                case 15: {
                    n4 = 60;
                    break;
                }
                case 16: {
                    n4 = 171;
                    break;
                }
                case 17: {
                    n4 = 183;
                    break;
                }
                case 18: {
                    n4 = 47;
                    break;
                }
                case 19: {
                    n4 = 223;
                    break;
                }
                case 20: {
                    n4 = 86;
                    break;
                }
                case 21: {
                    n4 = 66;
                    break;
                }
                case 22: {
                    n4 = 43;
                    break;
                }
                case 23: {
                    n4 = 152;
                    break;
                }
                case 24: {
                    n4 = 12;
                    break;
                }
                case 25: {
                    n4 = 110;
                    break;
                }
                case 26: {
                    n4 = 157;
                    break;
                }
                case 27: {
                    n4 = 148;
                    break;
                }
                case 28: {
                    n4 = 177;
                    break;
                }
                case 29: {
                    n4 = 240;
                    break;
                }
                case 30: {
                    n4 = 158;
                    break;
                }
                case 31: {
                    n4 = 200;
                    break;
                }
                case 32: {
                    n4 = 92;
                    break;
                }
                case 33: {
                    n4 = 78;
                    break;
                }
                case 34: {
                    n4 = 161;
                    break;
                }
                case 35: {
                    n4 = 95;
                    break;
                }
                case 36: {
                    n4 = 17;
                    break;
                }
                case 37: {
                    n4 = 217;
                    break;
                }
                case 38: {
                    n4 = 10;
                    break;
                }
                case 39: {
                    n4 = 113;
                    break;
                }
                case 40: {
                    n4 = 50;
                    break;
                }
                case 41: {
                    n4 = 116;
                    break;
                }
                case 42: {
                    n4 = 226;
                    break;
                }
                case 43: {
                    n4 = 220;
                    break;
                }
                case 44: {
                    n4 = 202;
                    break;
                }
                case 45: {
                    n4 = 224;
                    break;
                }
                case 46: {
                    n4 = 192;
                    break;
                }
                case 47: {
                    n4 = 252;
                    break;
                }
                case 48: {
                    n4 = 26;
                    break;
                }
                case 49: {
                    n4 = 230;
                    break;
                }
                case 50: {
                    n4 = 142;
                    break;
                }
                case 51: {
                    n4 = 254;
                    break;
                }
                case 52: {
                    n4 = 175;
                    break;
                }
                case 53: {
                    n4 = 214;
                    break;
                }
                case 54: {
                    n4 = 244;
                    break;
                }
                case 55: {
                    n4 = 176;
                    break;
                }
                case 56: {
                    n4 = 166;
                    break;
                }
                case 57: {
                    n4 = 185;
                    break;
                }
                case 58: {
                    n4 = 213;
                    break;
                }
                case 59: {
                    n4 = 35;
                    break;
                }
                case 60: {
                    n4 = 18;
                    break;
                }
                case 61: {
                    n4 = 1;
                    break;
                }
                case 62: {
                    n4 = 191;
                    break;
                }
                case 63: {
                    n4 = 5;
                    break;
                }
                case 64: {
                    n4 = 41;
                    break;
                }
                case 65: {
                    n4 = 48;
                    break;
                }
                case 66: {
                    n4 = 29;
                    break;
                }
                case 67: {
                    n4 = 51;
                    break;
                }
                case 68: {
                    n4 = 187;
                    break;
                }
                case 69: {
                    n4 = 21;
                    break;
                }
                case 70: {
                    n4 = 134;
                    break;
                }
                case 71: {
                    n4 = 3;
                    break;
                }
                case 72: {
                    n4 = 163;
                    break;
                }
                case 73: {
                    n4 = 222;
                    break;
                }
                case 74: {
                    n4 = 40;
                    break;
                }
                case 75: {
                    n4 = 121;
                    break;
                }
                case 76: {
                    n4 = 239;
                    break;
                }
                case 77: {
                    n4 = 236;
                    break;
                }
                case 78: {
                    n4 = 38;
                    break;
                }
                case 79: {
                    n4 = 174;
                    break;
                }
                case 80: {
                    n4 = 210;
                    break;
                }
                case 81: {
                    n4 = 250;
                    break;
                }
                case 82: {
                    n4 = 150;
                    break;
                }
                case 83: {
                    n4 = 63;
                    break;
                }
                case 84: {
                    n4 = 186;
                    break;
                }
                case 85: {
                    n4 = 249;
                    break;
                }
                case 86: {
                    n4 = 7;
                    break;
                }
                case 87: {
                    n4 = 251;
                    break;
                }
                case 88: {
                    n4 = 24;
                    break;
                }
                case 89: {
                    n4 = 194;
                    break;
                }
                case 90: {
                    n4 = 54;
                    break;
                }
                case 91: {
                    n4 = 168;
                    break;
                }
                case 92: {
                    n4 = 221;
                    break;
                }
                case 93: {
                    n4 = 156;
                    break;
                }
                case 94: {
                    n4 = 120;
                    break;
                }
                case 95: {
                    n4 = 81;
                    break;
                }
                case 96: {
                    n4 = 119;
                    break;
                }
                case 97: {
                    n4 = 141;
                    break;
                }
                case 98: {
                    n4 = 112;
                    break;
                }
                case 99: {
                    n4 = 28;
                    break;
                }
                case 100: {
                    n4 = 13;
                    break;
                }
                case 101: {
                    n4 = 196;
                    break;
                }
                case 102: {
                    n4 = 172;
                    break;
                }
                case 103: {
                    n4 = 165;
                    break;
                }
                case 104: {
                    n4 = 155;
                    break;
                }
                case 105: {
                    n4 = 160;
                    break;
                }
                case 106: {
                    n4 = 8;
                    break;
                }
                case 107: {
                    n4 = 147;
                    break;
                }
                case 108: {
                    n4 = 215;
                    break;
                }
                case 109: {
                    n4 = 182;
                    break;
                }
                case 110: {
                    n4 = 6;
                    break;
                }
                case 111: {
                    n4 = 27;
                    break;
                }
                case 112: {
                    n4 = 235;
                    break;
                }
                case 113: {
                    n4 = 242;
                    break;
                }
                case 114: {
                    n4 = 72;
                    break;
                }
                case 115: {
                    n4 = 140;
                    break;
                }
                case 116: {
                    n4 = 53;
                    break;
                }
                case 117: {
                    n4 = 79;
                    break;
                }
                case 118: {
                    n4 = 154;
                    break;
                }
                case 119: {
                    n4 = 9;
                    break;
                }
                case 120: {
                    n4 = 93;
                    break;
                }
                case 121: {
                    n4 = 23;
                    break;
                }
                case 122: {
                    n4 = 22;
                    break;
                }
                case 123: {
                    n4 = 59;
                    break;
                }
                case 124: {
                    n4 = 129;
                    break;
                }
                case 125: {
                    n4 = 89;
                    break;
                }
                case 126: {
                    n4 = 39;
                    break;
                }
                case 127: {
                    n4 = 114;
                    break;
                }
                case 128: {
                    n4 = 144;
                    break;
                }
                case 129: {
                    n4 = 169;
                    break;
                }
                case 130: {
                    n4 = 248;
                    break;
                }
                case 131: {
                    n4 = 238;
                    break;
                }
                case 132: {
                    n4 = 96;
                    break;
                }
                case 133: {
                    n4 = 131;
                    break;
                }
                case 134: {
                    n4 = 122;
                    break;
                }
                case 135: {
                    n4 = 94;
                    break;
                }
                case 136: {
                    n4 = 218;
                    break;
                }
                case 137: {
                    n4 = 46;
                    break;
                }
                case 138: {
                    n4 = 118;
                    break;
                }
                case 139: {
                    n4 = 32;
                    break;
                }
                case 140: {
                    n4 = 225;
                    break;
                }
                case 141: {
                    n4 = 234;
                    break;
                }
                case 142: {
                    n4 = 67;
                    break;
                }
                case 143: {
                    n4 = 145;
                    break;
                }
                case 144: {
                    n4 = 85;
                    break;
                }
                case 145: {
                    n4 = 211;
                    break;
                }
                case 146: {
                    n4 = 195;
                    break;
                }
                case 147: {
                    n4 = 100;
                    break;
                }
                case 148: {
                    n4 = 181;
                    break;
                }
                case 149: {
                    n4 = 229;
                    break;
                }
                case 150: {
                    n4 = 102;
                    break;
                }
                case 151: {
                    n4 = 133;
                    break;
                }
                case 152: {
                    n4 = 173;
                    break;
                }
                case 153: {
                    n4 = 246;
                    break;
                }
                case 154: {
                    n4 = 153;
                    break;
                }
                case 155: {
                    n4 = 71;
                    break;
                }
                case 156: {
                    n4 = 243;
                    break;
                }
                case 157: {
                    n4 = 201;
                    break;
                }
                case 158: {
                    n4 = 128;
                    break;
                }
                case 159: {
                    n4 = 241;
                    break;
                }
                case 160: {
                    n4 = 115;
                    break;
                }
                case 161: {
                    n4 = 105;
                    break;
                }
                case 162: {
                    n4 = 247;
                    break;
                }
                case 163: {
                    n4 = 178;
                    break;
                }
                case 164: {
                    n4 = 31;
                    break;
                }
                case 165: {
                    n4 = 107;
                    break;
                }
                case 166: {
                    n4 = 0;
                    break;
                }
                case 167: {
                    n4 = 30;
                    break;
                }
                case 168: {
                    n4 = 57;
                    break;
                }
                case 169: {
                    n4 = 232;
                    break;
                }
                case 170: {
                    n4 = 108;
                    break;
                }
                case 171: {
                    n4 = 83;
                    break;
                }
                case 172: {
                    n4 = 138;
                    break;
                }
                case 173: {
                    n4 = 245;
                    break;
                }
                case 174: {
                    n4 = 73;
                    break;
                }
                case 175: {
                    n4 = 97;
                    break;
                }
                case 176: {
                    n4 = 82;
                    break;
                }
                case 177: {
                    n4 = 74;
                    break;
                }
                case 178: {
                    n4 = 162;
                    break;
                }
                case 179: {
                    n4 = 190;
                    break;
                }
                case 180: {
                    n4 = 69;
                    break;
                }
                case 181: {
                    n4 = 68;
                    break;
                }
                case 182: {
                    n4 = 137;
                    break;
                }
                case 183: {
                    n4 = 164;
                    break;
                }
                case 184: {
                    n4 = 91;
                    break;
                }
                case 185: {
                    n4 = 117;
                    break;
                }
                case 186: {
                    n4 = 253;
                    break;
                }
                case 187: {
                    n4 = 33;
                    break;
                }
                case 188: {
                    n4 = 19;
                    break;
                }
                case 189: {
                    n4 = 16;
                    break;
                }
                case 190: {
                    n4 = 130;
                    break;
                }
                case 191: {
                    n4 = 58;
                    break;
                }
                case 192: {
                    n4 = 231;
                    break;
                }
                case 193: {
                    n4 = 143;
                    break;
                }
                case 194: {
                    n4 = 70;
                    break;
                }
                case 195: {
                    n4 = 209;
                    break;
                }
                case 196: {
                    n4 = 159;
                    break;
                }
                case 197: {
                    n4 = 193;
                    break;
                }
                case 198: {
                    n4 = 61;
                    break;
                }
                case 199: {
                    n4 = 184;
                    break;
                }
                case 200: {
                    n4 = 212;
                    break;
                }
                case 201: {
                    n4 = 64;
                    break;
                }
                case 202: {
                    n4 = 20;
                    break;
                }
                case 203: {
                    n4 = 149;
                    break;
                }
                case 204: {
                    n4 = 2;
                    break;
                }
                case 205: {
                    n4 = 188;
                    break;
                }
                case 206: {
                    n4 = 77;
                    break;
                }
                case 207: {
                    n4 = 125;
                    break;
                }
                case 208: {
                    n4 = 45;
                    break;
                }
                case 209: {
                    n4 = 104;
                    break;
                }
                case 210: {
                    n4 = 255;
                    break;
                }
                case 211: {
                    n4 = 42;
                    break;
                }
                case 212: {
                    n4 = 189;
                    break;
                }
                case 213: {
                    n4 = 124;
                    break;
                }
                case 214: {
                    n4 = 80;
                    break;
                }
                case 215: {
                    n4 = 123;
                    break;
                }
                case 216: {
                    n4 = 44;
                    break;
                }
                case 217: {
                    n4 = 227;
                    break;
                }
                case 218: {
                    n4 = 34;
                    break;
                }
                case 219: {
                    n4 = 103;
                    break;
                }
                case 220: {
                    n4 = 204;
                    break;
                }
                case 221: {
                    n4 = 180;
                    break;
                }
                case 222: {
                    n4 = 219;
                    break;
                }
                case 223: {
                    n4 = 205;
                    break;
                }
                case 224: {
                    n4 = 197;
                    break;
                }
                case 225: {
                    n4 = 101;
                    break;
                }
                case 226: {
                    n4 = 167;
                    break;
                }
                case 227: {
                    n4 = 228;
                    break;
                }
                case 228: {
                    n4 = 49;
                    break;
                }
                case 229: {
                    n4 = 109;
                    break;
                }
                case 230: {
                    n4 = 139;
                    break;
                }
                case 231: {
                    n4 = 111;
                    break;
                }
                case 232: {
                    n4 = 216;
                    break;
                }
                case 233: {
                    n4 = 233;
                    break;
                }
                case 234: {
                    n4 = 65;
                    break;
                }
                case 235: {
                    n4 = 11;
                    break;
                }
                case 236: {
                    n4 = 87;
                    break;
                }
                case 237: {
                    n4 = 146;
                    break;
                }
                case 238: {
                    n4 = 208;
                    break;
                }
                case 239: {
                    n4 = 90;
                    break;
                }
                case 240: {
                    n4 = 127;
                    break;
                }
                case 241: {
                    n4 = 237;
                    break;
                }
                case 242: {
                    n4 = 84;
                    break;
                }
                case 243: {
                    n4 = 88;
                    break;
                }
                case 244: {
                    n4 = 56;
                    break;
                }
                case 245: {
                    n4 = 179;
                    break;
                }
                case 246: {
                    n4 = 52;
                    break;
                }
                case 247: {
                    n4 = 14;
                    break;
                }
                case 248: {
                    n4 = 99;
                    break;
                }
                case 249: {
                    n4 = 136;
                    break;
                }
                case 250: {
                    n4 = 75;
                    break;
                }
                case 251: {
                    n4 = 206;
                    break;
                }
                case 252: {
                    n4 = 106;
                    break;
                }
                case 253: {
                    n4 = 76;
                    break;
                }
                case 254: {
                    n4 = 135;
                    break;
                }
                default: {
                    n4 = 203;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < charArray.length; ++i) {
                final int n8 = i % 2;
                final char[] array = charArray;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ charArray[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ charArray[i]) & 0xFF);
                }
            }
            NativeInputEvent.c[n3] = new String(charArray).intern();
        }
        return NativeInputEvent.c[n3];
    }
}
