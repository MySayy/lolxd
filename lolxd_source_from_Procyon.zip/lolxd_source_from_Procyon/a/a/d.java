// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import java.util.concurrent.ThreadLocalRandom;
import q.o.m.s.q;
import java.awt.Robot;
import java.awt.AWTException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class d implements ActionListener
{
    private int c;
    private int a;
    private long b;
    
    public d() {
        this.c = 0;
        this.a = p.k;
        this.b = -1L;
    }
    
    public boolean b() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: getstatic       a/a/ac.H:Z
        //     7: aload_1        
        //     8: ifnull          35
        //    11: aload_1        
        //    12: ifnull          39
        //    15: goto            22
        //    18: invokestatic    a/a/d.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    21: athrow         
        //    22: ifne            64
        //    25: goto            32
        //    28: invokestatic    a/a/d.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    31: athrow         
        //    32: getstatic       a/a/p.f:Z
        //    35: aload_1        
        //    36: ifnull          61
        //    39: aload_1        
        //    40: ifnull          61
        //    43: goto            50
        //    46: invokestatic    a/a/d.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    49: athrow         
        //    50: ifeq            64
        //    53: goto            60
        //    56: invokestatic    a/a/d.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    59: athrow         
        //    60: iconst_1       
        //    61: goto            65
        //    64: iconst_0       
        //    65: ireturn        
        //    StackMapTable: 00 0D FF 00 12 00 02 07 00 02 07 00 2C 00 01 07 00 20 43 01 45 07 00 20 03 42 01 43 01 46 07 00 20 43 01 45 07 00 20 03 40 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      15     18     22     Ljava/lang/RuntimeException;
        //  11     25     28     32     Ljava/lang/RuntimeException;
        //  35     43     46     50     Ljava/lang/RuntimeException;
        //  39     53     56     60     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0039:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void actionPerformed(final ActionEvent actionEvent) {
        final String[] i = ac.i();
        try {
            int n2 = 0;
            Label_0036: {
                Label_0023: {
                    int n;
                    try {
                        n = (n2 = (this.b() ? 1 : 0));
                        if (i == null) {
                            break Label_0036;
                        }
                        final String[] array = i;
                        if (array != null) {
                            break Label_0023;
                        }
                        break Label_0036;
                    }
                    catch (AWTException ex) {
                        throw b(ex);
                    }
                    try {
                        final String[] array = i;
                        if (array == null) {
                            break Label_0036;
                        }
                        if (n == 0) {
                            return;
                        }
                    }
                    catch (AWTException ex2) {
                        throw b(ex2);
                    }
                }
                n2 = p.J;
            }
            final int n3 = n2;
            final int l = p.l;
            Robot robot;
            boolean b2;
            boolean b;
            while (true) {
                Label_0066: {
                    boolean n4;
                    try {
                        n4 = p.n;
                        if (i == null) {
                            break Label_0062;
                        }
                        if (!n4) {
                            break Label_0066;
                        }
                    }
                    catch (AWTException ex3) {
                        throw b(ex3);
                    }
                    final boolean a = p.A;
                    if (!n4) {
                        return;
                    }
                }
                robot = new Robot();
                boolean a;
                b = (a = (b2 = p.q));
                if (i == null) {
                    continue;
                }
                break;
            }
            Label_0348: {
                while (true) {
                    Label_0301: {
                        boolean c = false;
                        int n5 = 0;
                        Label_0096: {
                            try {
                                if (i == null) {
                                    break Label_0348;
                                }
                                if (b) {
                                    break Label_0096;
                                }
                                break Label_0301;
                            }
                            catch (AWTException ex4) {
                                throw b(ex4);
                            }
                            try {
                                if (!b) {
                                    break Label_0301;
                                }
                                n5 = ((c = (this.c != 0)) ? 1 : 0);
                            }
                            catch (AWTException ex5) {
                                throw b(ex5);
                            }
                        }
                        int to = 0;
                        int n18 = 0;
                    Label_0212_Outer:
                        while (true) {
                            Label_0237: {
                                if (i == null) {
                                    break Label_0237;
                                }
                                int c3 = 0;
                                int a2 = 0;
                                Label_0236: {
                                    int n16 = 0;
                                    while (true) {
                                        Label_0215: {
                                            d d5 = null;
                                            Label_0203: {
                                                int n14 = 0;
                                                int n15 = 0;
                                                Label_0183: {
                                                    d d2 = null;
                                                    int n13 = 0;
                                                    while (true) {
                                                        Label_0175: {
                                                            Label_0141: {
                                                                try {
                                                                    if (c) {
                                                                        break Label_0215;
                                                                    }
                                                                    final d d = this;
                                                                    final ThreadLocalRandom threadLocalRandom = q.tv();
                                                                    final int n6 = n3;
                                                                    final int n7 = l;
                                                                    final int n8 = 1;
                                                                    final int n9 = n7 + n8;
                                                                    final int n10 = q.to(threadLocalRandom, n6, n9);
                                                                    d.a = n10;
                                                                    d2 = this;
                                                                    final d d3 = this;
                                                                    final d d4 = this;
                                                                    final String[] array2 = i;
                                                                    if (array2 != null) {
                                                                        break Label_0141;
                                                                    }
                                                                    break Label_0175;
                                                                }
                                                                catch (AWTException ex6) {
                                                                    throw b(ex6);
                                                                }
                                                                try {
                                                                    final d d = this;
                                                                    final ThreadLocalRandom threadLocalRandom = q.tv();
                                                                    final int n6 = n3;
                                                                    final int n7 = l;
                                                                    final int n8 = 1;
                                                                    final int n9 = n7 + n8;
                                                                    final int n10 = q.to(threadLocalRandom, n6, n9);
                                                                    d.a = n10;
                                                                    d2 = this;
                                                                    final d d3 = this;
                                                                    final d d4 = this;
                                                                    final String[] array2 = i;
                                                                    if (array2 == null) {
                                                                        break Label_0175;
                                                                    }
                                                                    final int c2 = d4.c;
                                                                }
                                                                catch (AWTException ex7) {
                                                                    throw b(ex7);
                                                                }
                                                            }
                                                            Label_0174: {
                                                                final int n11;
                                                                if (n11 >= 25) {
                                                                    break Label_0174;
                                                                }
                                                                final d d3 = this;
                                                                final int n12 = 1600 / q.tw(p.p);
                                                                d3.c = n13;
                                                                if (i != null) {
                                                                    break Label_0183;
                                                                }
                                                            }
                                                            d2 = this;
                                                            final d d3 = this;
                                                        }
                                                        n13 = 1;
                                                        if (i == null) {
                                                            continue Label_0212_Outer;
                                                        }
                                                        break;
                                                    }
                                                    d2.c = n13;
                                                    try {
                                                        n14 = (c3 = this.c);
                                                        n15 = (a2 = 25);
                                                        if (i == null) {
                                                            break Label_0236;
                                                        }
                                                        if (n14 >= n15) {
                                                            break Label_0203;
                                                        }
                                                        break Label_0215;
                                                    }
                                                    catch (AWTException ex8) {
                                                        throw b(ex8);
                                                    }
                                                }
                                                try {
                                                    if (n14 < n15) {
                                                        break Label_0215;
                                                    }
                                                    d5 = this;
                                                }
                                                catch (AWTException ex9) {
                                                    throw b(ex9);
                                                }
                                            }
                                            d5.c = n16;
                                        }
                                        d d5 = this;
                                        n16 = this.c - 1;
                                        if (i == null) {
                                            continue;
                                        }
                                        break;
                                    }
                                    this.c = n16;
                                    c3 = 1000;
                                    a2 = this.a;
                                }
                                n5 = c3 / a2;
                            }
                            final int n17 = n5;
                            to = q.to(q.tv(), n17 - 23, n17 + 23 + 1);
                            final int n11 = n18 = to;
                            if (i == null) {
                                continue;
                            }
                            break;
                        }
                        Label_0293: {
                            Label_0291: {
                                Label_0280: {
                                    try {
                                        if (i == null) {
                                            break Label_0291;
                                        }
                                        final String[] array3 = i;
                                        if (array3 != null) {
                                            break Label_0280;
                                        }
                                        break Label_0291;
                                    }
                                    catch (AWTException ex10) {
                                        throw b(ex10);
                                    }
                                    try {
                                        final String[] array3 = i;
                                        if (array3 == null) {
                                            break Label_0291;
                                        }
                                        final int n11;
                                        if (n11 > 0) {
                                            break Label_0293;
                                        }
                                    }
                                    catch (AWTException ex11) {
                                        throw b(ex11);
                                    }
                                }
                                n18 = 1;
                            }
                            to = n18;
                        }
                        q.ta(p.p, to);
                    }
                    p.F = true;
                    q.tq(robot, 16);
                    q.mt(q.to(q.tv(), 30, 56));
                    this.a();
                    this.c();
                    q.tt(robot, 16);
                    boolean c;
                    int n5 = (c = (b2 = p.h)) ? 1 : 0;
                    if (i == null) {
                        continue;
                    }
                    break;
                }
            }
            if (b2) {
                s.a();
            }
        }
        catch (AWTException ex12) {
            q.qj(ex12);
        }
        catch (InterruptedException ex13) {
            q.mr(ex13);
        }
    }
    
    public void a() {
        new ah(this).start();
    }
    
    public void c() {
        new aw(this).start();
    }
    
    static long a(final d d) {
        return d.b;
    }
    
    static long a(final d d, final long b) {
        return d.b = b;
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
}
