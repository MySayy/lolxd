// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import javax.swing.JSlider;
import q.o.m.s.q;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

class k implements ChangeListener
{
    final ac a;
    
    k(final ac a) {
        this.a = a;
    }
    
    @Override
    public void stateChanged(final ChangeEvent changeEvent) {
        final String[] i = ac.i();
        int l = 0;
        Label_0061: {
            JSlider e = null;
            while (true) {
                Label_0051: {
                    Label_0030: {
                        int n;
                        try {
                            n = (l = q.mv(ac.e()));
                            if (i == null) {
                                break Label_0061;
                            }
                            final JSlider slider = ac.b();
                            final int n2 = q.mv(slider);
                            if (n < n2) {
                                break Label_0030;
                            }
                            break Label_0051;
                        }
                        catch (RuntimeException ex) {
                            throw b(ex);
                        }
                        try {
                            final JSlider slider = ac.b();
                            final int n2 = q.mv(slider);
                            if (n >= n2) {
                                break Label_0051;
                            }
                            ac.e();
                        }
                        catch (RuntimeException ex2) {
                            throw b(ex2);
                        }
                    }
                    q.mo(e, q.mv(ac.e()) + 1);
                }
                e = ac.e();
                if (i == null) {
                    continue;
                }
                break;
            }
            l = q.mv(e);
        }
        p.l = l;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
