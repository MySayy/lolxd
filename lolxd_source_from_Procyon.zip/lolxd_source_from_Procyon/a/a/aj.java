// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import q.o.m.s.q;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

class aj implements ChangeListener
{
    final ac a;
    
    aj(final ac a) {
        this.a = a;
    }
    
    @Override
    public void stateChanged(final ChangeEvent changeEvent) {
        p.a.c = q.mm((Integer)q.mf(ac.s(this.a)));
    }
}
