// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import q.o.m.s.q;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class n implements ActionListener
{
    final ac a;
    
    n(final ac a) {
        this.a = a;
    }
    
    @Override
    public void actionPerformed(final ActionEvent actionEvent) {
        final String[] i = ac.i();
        boolean u = false;
        Label_0037: {
            while (true) {
                Label_0032: {
                    try {
                        u = q.u(ac.h());
                        if (i == null) {
                            break Label_0037;
                        }
                        if (!u) {
                            break Label_0032;
                        }
                    }
                    catch (RuntimeException ex) {
                        throw b(ex);
                    }
                    final boolean b = true;
                    final boolean q;
                    p.q = q;
                    if (i != null) {
                        return;
                    }
                }
                final boolean q = false;
                if (i == null) {
                    continue;
                }
                break;
            }
        }
        p.q = u;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
