// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import java.awt.AWTException;
import java.awt.Robot;
import q.o.m.s.q;

class ah extends Thread
{
    final d a;
    
    ah(final d a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        final String[] i = ac.i();
        try {
            boolean n = false;
            Label_0193: {
                try {
                    final boolean b = n = p.n;
                    if (i == null) {
                        break Label_0193;
                    }
                    if (!b) {
                        break Label_0193;
                    }
                }
                catch (InterruptedException ex) {
                    throw b(ex);
                }
                boolean a;
                int to = (a = p.A) ? 1 : 0;
            Label_0116_Outer:
                while (true) {
                    Label_0061: {
                        if (i != null) {
                            Label_0042: {
                                try {
                                    if (i == null) {
                                        break Label_0061;
                                    }
                                    if (a) {
                                        break Label_0042;
                                    }
                                    return;
                                }
                                catch (InterruptedException ex2) {
                                    throw b(ex2);
                                }
                                try {
                                    if (!a) {
                                        return;
                                    }
                                    to = q.to(q.tv(), 1, p.H + 1);
                                }
                                catch (InterruptedException ex3) {
                                    throw b(ex3);
                                }
                            }
                        }
                    }
                    int n2 = to;
                    while (true) {
                        int n5 = 0;
                        int h2 = 0;
                        Label_0181: {
                            Label_0177: {
                                Label_0105: {
                                    int n4 = 0;
                                    int n6 = 0;
                                    Label_0088: {
                                        while (true) {
                                            Label_0083: {
                                                try {
                                                    final int n3 = n4 = (n5 = p.B);
                                                    if (i == null) {
                                                        break Label_0088;
                                                    }
                                                    if (n3 != 0) {
                                                        break Label_0083;
                                                    }
                                                }
                                                catch (InterruptedException ex4) {
                                                    throw b(ex4);
                                                }
                                                final int h = p.H;
                                                n2 = h;
                                            }
                                            int h;
                                            n4 = (h = (n5 = n2));
                                            if (i == null) {
                                                continue Label_0116_Outer;
                                            }
                                            break;
                                        }
                                        try {
                                            n6 = (h2 = p.H);
                                            if (i == null) {
                                                break Label_0181;
                                            }
                                            if (n4 == n6) {
                                                break Label_0105;
                                            }
                                            break Label_0177;
                                        }
                                        catch (InterruptedException ex5) {
                                            throw b(ex5);
                                        }
                                    }
                                    try {
                                        if (n4 != n6) {
                                            break Label_0177;
                                        }
                                        p.r = true;
                                    }
                                    catch (InterruptedException ex6) {
                                        throw b(ex6);
                                    }
                                }
                                final Robot robot = new Robot();
                                int n7;
                                final boolean b2 = (n7 = (p.w ? 1 : 0)) != 0;
                                if (i != null) {
                                    if (b2) {
                                        return;
                                    }
                                    q.mt(q.to(q.tv(), 25, 36));
                                    q.tq(robot, 4096);
                                    n7 = q.to(q.tv(), 15, 26);
                                }
                                q.mt(n7);
                                q.tt(robot, 4096);
                            }
                            n5 = p.B;
                            h2 = 1;
                        }
                        p.B = n5 + h2;
                        if (i == null) {
                            continue;
                        }
                        break;
                    }
                    try {
                        if (i != null) {
                            return;
                        }
                        to = ((a = (n = false)) ? 1 : 0);
                        if (i == null) {
                            continue Label_0116_Outer;
                        }
                    }
                    catch (InterruptedException ex7) {
                        throw b(ex7);
                    }
                    break;
                }
            }
            p.B = (n ? 1 : 0);
        }
        catch (InterruptedException ex8) {
            q.mr(ex8);
        }
        catch (AWTException ex9) {
            q.qj(ex9);
        }
    }
    
    private static InterruptedException b(final InterruptedException ex) {
        return ex;
    }
}
