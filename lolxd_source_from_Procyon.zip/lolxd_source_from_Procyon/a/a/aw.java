// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import java.awt.AWTException;
import java.awt.Robot;
import q.o.m.s.q;

class aw extends Thread
{
    final d a;
    
    aw(final d a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        final String[] i = ac.i();
        try {
            Label_0141: {
                long n3 = 0L;
                while (true) {
                    Label_0075: {
                        int n2 = 0;
                        Label_0061: {
                            Label_0050: {
                                Label_0035: {
                                    int n = 0;
                                    Label_0022: {
                                        try {
                                            n = (n2 = (int)(n3 = (p.x ? 1 : 0)));
                                            if (i == null) {
                                                break Label_0035;
                                            }
                                            final String[] array = i;
                                            if (array != null) {
                                                break Label_0022;
                                            }
                                            break Label_0035;
                                        }
                                        catch (InterruptedException ex) {
                                            throw b(ex);
                                        }
                                        try {
                                            final String[] array = i;
                                            if (array == null) {
                                                break Label_0035;
                                            }
                                            if (n == 0) {
                                                return;
                                            }
                                        }
                                        catch (InterruptedException ex2) {
                                            throw b(ex2);
                                        }
                                    }
                                    final int n4;
                                    n2 = (n4 = (int)(n3 = (p.t ? 1 : 0)));
                                    try {
                                        if (i == null) {
                                            break Label_0061;
                                        }
                                        if (n != 0) {
                                            break Label_0050;
                                        }
                                    }
                                    catch (InterruptedException ex3) {
                                        throw b(ex3);
                                    }
                                }
                                return;
                            }
                            n3 = (n2 = lcmp(d.a(this.a), -1L));
                            try {
                                if (i == null) {
                                    break Label_0141;
                                }
                                if (n2 == 0) {
                                    break Label_0075;
                                }
                                break Label_0092;
                            }
                            catch (InterruptedException ex4) {
                                throw b(ex4);
                            }
                        }
                        try {
                            if (n2 == 0) {
                                d.a(this.a, q.tj());
                            }
                        }
                        catch (InterruptedException ex5) {
                            throw b(ex5);
                        }
                    }
                    final long tg = q.tg(q.tj() - d.a(this.a));
                    if (i == null) {
                        continue;
                    }
                    break;
                }
                Label_0126: {
                    try {
                        if (i == null) {
                            break Label_0141;
                        }
                        final String[] array2 = i;
                        if (array2 != null) {
                            break Label_0126;
                        }
                        break Label_0141;
                    }
                    catch (InterruptedException ex6) {
                        throw b(ex6);
                    }
                    try {
                        final String[] array2 = i;
                        if (array2 == null) {
                            break Label_0141;
                        }
                        final long tg;
                        n3 = lcmp(tg, (long)(p.E * 50));
                    }
                    catch (InterruptedException ex7) {
                        throw b(ex7);
                    }
                }
                try {
                    if (n3 < 0) {
                        return;
                    }
                    d.a(this.a, q.tj());
                }
                catch (InterruptedException ex8) {
                    throw b(ex8);
                }
            }
            final Robot robot = new Robot();
            int n5 = 0;
            Label_0218: {
                Label_0188: {
                    try {
                        final boolean b = (n5 = (p.w ? 1 : 0)) != 0;
                        if (i == null) {
                            break Label_0218;
                        }
                        if (!b) {
                            break Label_0188;
                        }
                    }
                    catch (InterruptedException ex9) {
                        throw b(ex9);
                    }
                    return;
                }
                q.mt(q.to(q.tv(), 25, 41));
                q.ts(robot, 87);
                n5 = q.to(q.tv(), 55, 81);
            }
            q.mt(n5);
            q.tr(robot, 87);
        }
        catch (InterruptedException ex10) {
            q.mr(ex10);
        }
        catch (AWTException ex11) {
            q.qj(ex11);
        }
    }
    
    private static InterruptedException b(final InterruptedException ex) {
        return ex;
    }
}
