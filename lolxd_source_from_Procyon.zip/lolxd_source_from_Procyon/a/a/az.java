// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import java.awt.AWTException;
import q.o.m.s.q;
import java.awt.Robot;

class az extends Thread
{
    final ap a;
    
    az(final ap a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        final String[] i = ac.i();
        try {
            boolean w = false;
            Label_0025: {
                Label_0022: {
                    try {
                        w = p.w;
                        if (i == null) {
                            break Label_0025;
                        }
                        if (!w) {
                            break Label_0022;
                        }
                    }
                    catch (RuntimeException ex) {
                        throw b(ex);
                    }
                    return;
                }
                final boolean g = p.g;
            }
            if (w) {
                return;
            }
            final Robot robot = new Robot();
            q.tq(robot, 4096);
            q.mt(p.y + q.to(q.tv(), -8, 9));
            q.tt(robot, 4096);
            int n = 49;
            while (true) {
                Label_0365: {
                    int n9 = 0;
                    int n17 = 0;
                    Label_0359: {
                        while (true) {
                            Label_0335: {
                                Label_0314: {
                                    int n8;
                                    while (true) {
                                        Label_0301: {
                                            Label_0280: {
                                                int n7;
                                                while (true) {
                                                    Label_0267: {
                                                        Label_0246: {
                                                            int n6;
                                                            while (true) {
                                                                Label_0233: {
                                                                    Label_0212: {
                                                                        int n5;
                                                                        while (true) {
                                                                            Label_0200: {
                                                                                Label_0179: {
                                                                                    int n4;
                                                                                    while (true) {
                                                                                        Label_0167: {
                                                                                            Label_0146: {
                                                                                                int n19 = 0;
                                                                                                while (true) {
                                                                                                    Label_0134: {
                                                                                                        Label_0113: {
                                                                                                            int n2 = 0;
                                                                                                            int n10 = 0;
                                                                                                            while (true) {
                                                                                                                Label_0101: {
                                                                                                                    try {
                                                                                                                        final int n3;
                                                                                                                        n2 = (n3 = (n4 = (n5 = (n6 = (n7 = (n8 = (n9 = this.a.f)))))));
                                                                                                                        final int n16;
                                                                                                                        final int n15;
                                                                                                                        final int n14;
                                                                                                                        final int n13;
                                                                                                                        final int n12;
                                                                                                                        final int n11;
                                                                                                                        n10 = (n11 = (n12 = (n13 = (n14 = (n15 = (n16 = (n17 = 1)))))));
                                                                                                                        if (i == null) {
                                                                                                                            break Label_0113;
                                                                                                                        }
                                                                                                                        if (n2 != n10) {
                                                                                                                            break Label_0101;
                                                                                                                        }
                                                                                                                    }
                                                                                                                    catch (InterruptedException ex2) {
                                                                                                                        throw b(ex2);
                                                                                                                    }
                                                                                                                    final int n18 = 49;
                                                                                                                    n = n19;
                                                                                                                    if (i != null) {
                                                                                                                        break Label_0365;
                                                                                                                    }
                                                                                                                }
                                                                                                                n19 = (n4 = (n5 = (n6 = (n7 = (n8 = (n9 = this.a.f))))));
                                                                                                                if (i == null) {
                                                                                                                    continue;
                                                                                                                }
                                                                                                                break;
                                                                                                            }
                                                                                                            int n16;
                                                                                                            int n15;
                                                                                                            int n14;
                                                                                                            int n13;
                                                                                                            int n12;
                                                                                                            final int n20;
                                                                                                            int n11 = n20 = (n12 = (n13 = (n14 = (n15 = (n16 = (n17 = 2))))));
                                                                                                            try {
                                                                                                                if (i == null) {
                                                                                                                    break Label_0146;
                                                                                                                }
                                                                                                                if (n2 != n10) {
                                                                                                                    break Label_0134;
                                                                                                                }
                                                                                                            }
                                                                                                            catch (InterruptedException ex3) {
                                                                                                                throw b(ex3);
                                                                                                            }
                                                                                                        }
                                                                                                        final int n21 = 50;
                                                                                                        n = n21;
                                                                                                        if (i != null) {
                                                                                                            break Label_0365;
                                                                                                        }
                                                                                                    }
                                                                                                    int n21;
                                                                                                    int n3 = n21 = (n4 = (n5 = (n6 = (n7 = (n8 = (n9 = this.a.f))))));
                                                                                                    if (i == null) {
                                                                                                        continue;
                                                                                                    }
                                                                                                    break;
                                                                                                }
                                                                                                int n16;
                                                                                                int n15;
                                                                                                int n14;
                                                                                                int n13;
                                                                                                int n11;
                                                                                                int n12 = n11 = (n13 = (n14 = (n15 = (n16 = (n17 = 3)))));
                                                                                                try {
                                                                                                    if (i == null) {
                                                                                                        break Label_0179;
                                                                                                    }
                                                                                                    if (n19 != n11) {
                                                                                                        break Label_0167;
                                                                                                    }
                                                                                                }
                                                                                                catch (InterruptedException ex4) {
                                                                                                    throw b(ex4);
                                                                                                }
                                                                                            }
                                                                                            final int n22 = 51;
                                                                                            n = n22;
                                                                                            if (i != null) {
                                                                                                break Label_0365;
                                                                                            }
                                                                                        }
                                                                                        int n22;
                                                                                        n4 = (n22 = (n5 = (n6 = (n7 = (n8 = (n9 = this.a.f))))));
                                                                                        if (i == null) {
                                                                                            continue;
                                                                                        }
                                                                                        break;
                                                                                    }
                                                                                    int n16;
                                                                                    int n15;
                                                                                    int n14;
                                                                                    int n12;
                                                                                    int n13 = n12 = (n14 = (n15 = (n16 = (n17 = 4))));
                                                                                    try {
                                                                                        if (i == null) {
                                                                                            break Label_0212;
                                                                                        }
                                                                                        if (n4 != n12) {
                                                                                            break Label_0200;
                                                                                        }
                                                                                    }
                                                                                    catch (InterruptedException ex5) {
                                                                                        throw b(ex5);
                                                                                    }
                                                                                }
                                                                                final int n23 = 52;
                                                                                n = n23;
                                                                                if (i != null) {
                                                                                    break Label_0365;
                                                                                }
                                                                            }
                                                                            int n23;
                                                                            n5 = (n23 = (n6 = (n7 = (n8 = (n9 = this.a.f)))));
                                                                            if (i == null) {
                                                                                continue;
                                                                            }
                                                                            break;
                                                                        }
                                                                        int n16;
                                                                        int n15;
                                                                        int n13;
                                                                        int n14 = n13 = (n15 = (n16 = (n17 = 5)));
                                                                        try {
                                                                            if (i == null) {
                                                                                break Label_0246;
                                                                            }
                                                                            if (n5 != n13) {
                                                                                break Label_0233;
                                                                            }
                                                                        }
                                                                        catch (InterruptedException ex6) {
                                                                            throw b(ex6);
                                                                        }
                                                                    }
                                                                    final int n24 = 53;
                                                                    n = n24;
                                                                    if (i != null) {
                                                                        break Label_0365;
                                                                    }
                                                                }
                                                                int n24;
                                                                n6 = (n24 = (n7 = (n8 = (n9 = this.a.f))));
                                                                if (i == null) {
                                                                    continue;
                                                                }
                                                                break;
                                                            }
                                                            int n16;
                                                            int n14;
                                                            int n15 = n14 = (n16 = (n17 = 6));
                                                            try {
                                                                if (i == null) {
                                                                    break Label_0280;
                                                                }
                                                                if (n6 != n14) {
                                                                    break Label_0267;
                                                                }
                                                            }
                                                            catch (InterruptedException ex7) {
                                                                throw b(ex7);
                                                            }
                                                        }
                                                        final int n25 = 54;
                                                        n = n25;
                                                        if (i != null) {
                                                            break Label_0365;
                                                        }
                                                    }
                                                    int n25;
                                                    n7 = (n25 = (n8 = (n9 = this.a.f)));
                                                    if (i == null) {
                                                        continue;
                                                    }
                                                    break;
                                                }
                                                int n15;
                                                int n16 = n15 = (n17 = 7);
                                                try {
                                                    if (i == null) {
                                                        break Label_0314;
                                                    }
                                                    if (n7 != n15) {
                                                        break Label_0301;
                                                    }
                                                }
                                                catch (InterruptedException ex8) {
                                                    throw b(ex8);
                                                }
                                            }
                                            final int n26 = 55;
                                            n = n26;
                                            if (i != null) {
                                                break Label_0365;
                                            }
                                        }
                                        int n26;
                                        n8 = (n26 = (n9 = this.a.f));
                                        if (i == null) {
                                            continue;
                                        }
                                        break;
                                    }
                                    int n16;
                                    n17 = (n16 = 8);
                                    try {
                                        if (i == null) {
                                            break Label_0359;
                                        }
                                        if (n8 != n16) {
                                            break Label_0335;
                                        }
                                    }
                                    catch (InterruptedException ex9) {
                                        throw b(ex9);
                                    }
                                }
                                final int f = 56;
                                n = f;
                                if (i != null) {
                                    break Label_0365;
                                }
                            }
                            int f;
                            n9 = (f = this.a.f);
                            if (i == null) {
                                continue;
                            }
                            break;
                        }
                        try {
                            if (i == null) {
                                return;
                            }
                            n17 = 9;
                        }
                        catch (InterruptedException ex10) {
                            throw b(ex10);
                        }
                    }
                    if (n9 != n17) {
                        break Label_0365;
                    }
                    final int a = 57;
                    n = a;
                }
                q.mt(p.y + q.to(q.tv(), 0, 11));
                ap.a(this.a, true);
                q.tr(robot, n);
                ap.a(this.a, false);
                q.mt(p.y + q.to(q.tv(), -15, -7));
                ap.a(this.a, true);
                q.ts(robot, n);
                final int a = ap.a(this.a, false) ? 1 : 0;
                if (i == null) {
                    continue;
                }
                break;
            }
        }
        catch (InterruptedException ex11) {
            q.mr(ex11);
        }
        catch (AWTException ex12) {
            q.qj(ex12);
        }
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
}
