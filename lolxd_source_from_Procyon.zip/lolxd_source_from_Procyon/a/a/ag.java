// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.reflect.InvocationTargetException;
import q.o.m.s.q;
import java.lang.reflect.Method;
import java.util.prefs.Preferences;

public class ag
{
    public static final int a = -2147483647;
    public static final int u = -2147483646;
    public static final int k = 0;
    public static final int h = 2;
    public static final int m = 5;
    public static final int v = 512;
    public static final int n = 256;
    private static final int r = 983103;
    private static final int b = 131097;
    private static Preferences j;
    private static Preferences q;
    private static Class<? extends Preferences> o;
    private static Method e;
    private static Method l;
    private static Method d;
    private static Method p;
    private static Method c;
    private static Method g;
    private static Method f;
    private static Method t;
    private static Method i;
    private static Method s;
    private static final String[] w;
    private static final String[] x;
    
    private ag() {
    }
    
    public static String a(final int n, final String s, final String s2, final int n2) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        final String[] i = ac.i();
        Label_0041: {
            Label_0023: {
                int n4;
                try {
                    final int n3 = n;
                    final int n5;
                    n4 = (n5 = -2147483646);
                    if (i == null) {
                        break Label_0041;
                    }
                    if (n == n4) {
                        break Label_0023;
                    }
                    break Label_0023;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    if (n == n4) {
                        return b(ag.q, n, s, s2, n2);
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            final int n3 = n;
            int n5 = -2147483647;
            try {
                if (n3 == n5) {
                    return b(ag.j, n, s, s2, n2);
                }
            }
            catch (IllegalArgumentException ex3) {
                throw b(ex3);
            }
        }
        throw new IllegalArgumentException(q.o.m.s.q.s(q.o.m.s.q.qg(q.o.m.s.q.r(new StringBuilder(), a(27894, 6718)), n)));
    }
    
    public static Map<String, String> b(final int n, final String s, final int n2) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        final String[] i = ac.i();
        Label_0038: {
            Label_0021: {
                int n4;
                try {
                    final int n3 = n;
                    final int n5;
                    n4 = (n5 = -2147483646);
                    if (i == null) {
                        break Label_0038;
                    }
                    if (n == n4) {
                        break Label_0021;
                    }
                    break Label_0021;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    if (n == n4) {
                        return b(ag.q, n, s, n2);
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            final int n3 = n;
            int n5 = -2147483647;
            try {
                if (n3 == n5) {
                    return b(ag.j, n, s, n2);
                }
            }
            catch (IllegalArgumentException ex3) {
                throw b(ex3);
            }
        }
        throw new IllegalArgumentException(q.o.m.s.q.s(q.o.m.s.q.qg(q.o.m.s.q.r(new StringBuilder(), a(27894, 6718)), n)));
    }
    
    public static List<String> a(final int n, final String s, final int n2) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        final String[] i = ac.i();
        Label_0038: {
            Label_0021: {
                int n4;
                try {
                    final int n3 = n;
                    final int n5;
                    n4 = (n5 = -2147483646);
                    if (i == null) {
                        break Label_0038;
                    }
                    if (n == n4) {
                        break Label_0021;
                    }
                    break Label_0021;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    if (n == n4) {
                        return a(ag.q, n, s, n2);
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            final int n3 = n;
            int n5 = -2147483647;
            try {
                if (n3 == n5) {
                    return a(ag.j, n, s, n2);
                }
            }
            catch (IllegalArgumentException ex3) {
                throw b(ex3);
            }
        }
        throw new IllegalArgumentException(q.o.m.s.q.s(q.o.m.s.q.qg(q.o.m.s.q.r(new StringBuilder(), a(27894, 6718)), n)));
    }
    
    public static void a(final int n, final String s) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        final String[] i = ac.i();
        Label_0152: {
            int n2 = 0;
            int n3 = 0;
            int[] array = null;
            Label_0061: {
                try {
                    n2 = n;
                    n3 = -2147483646;
                    if (i == null) {
                        break Label_0061;
                    }
                    if (n != n3) {
                        break Label_0061;
                    }
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                array = a(ag.q, n, s);
                try {
                    q.o.m.s.q.qz(ag.l, ag.q, new Object[] { new Integer(array[0]) });
                    if (i != null) {
                        break Label_0152;
                    }
                    n2 = n;
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            Label_0114: {
                if (n2 != n3) {
                    break Label_0114;
                }
                array = a(ag.j, n, s);
                try {
                    q.o.m.s.q.qz(ag.l, ag.j, new Object[] { new Integer(array[0]) });
                    if (i == null) {
                        throw new IllegalArgumentException(q.o.m.s.q.s(q.o.m.s.q.qg(q.o.m.s.q.r(new StringBuilder(), a(27894, 6718)), n)));
                    }
                }
                catch (IllegalArgumentException ex3) {
                    throw b(ex3);
                }
            }
            try {
                if (array[1] != 0) {
                    throw new IllegalArgumentException(q.o.m.s.q.s(q.o.m.s.q.r(q.o.m.s.q.r(q.o.m.s.q.qg(q.o.m.s.q.r(new StringBuilder(), a(27890, -25740)), array[1]), a(27896, -7926)), s)));
                }
            }
            catch (IllegalArgumentException ex4) {
                throw b(ex4);
            }
        }
    }
    
    public static void a(final int p0, final String p1, final String p2, final String p3, final int p4) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore          5
        //     5: aload           5
        //     7: ifnull          54
        //    10: iload_0        
        //    11: ldc             -2147483646
        //    13: aload           5
        //    15: ifnull          69
        //    18: goto            25
        //    21: invokestatic    a/a/ag.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    24: athrow         
        //    25: if_icmpne       59
        //    28: goto            35
        //    31: invokestatic    a/a/ag.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    34: athrow         
        //    35: getstatic       a/a/ag.q:Ljava/util/prefs/Preferences;
        //    38: iload_0        
        //    39: aload_1        
        //    40: aload_2        
        //    41: aload_3        
        //    42: iload           4
        //    44: invokestatic    a/a/ag.a:(Ljava/util/prefs/Preferences;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
        //    47: goto            54
        //    50: invokestatic    a/a/ag.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    53: athrow         
        //    54: aload           5
        //    56: ifnonnull       134
        //    59: iload_0        
        //    60: ldc             -2147483647
        //    62: goto            69
        //    65: invokestatic    a/a/ag.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    68: athrow         
        //    69: if_icmpne       96
        //    72: getstatic       a/a/ag.j:Ljava/util/prefs/Preferences;
        //    75: iload_0        
        //    76: aload_1        
        //    77: aload_2        
        //    78: aload_3        
        //    79: iload           4
        //    81: invokestatic    a/a/ag.a:(Ljava/util/prefs/Preferences;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
        //    84: aload           5
        //    86: ifnonnull       134
        //    89: goto            96
        //    92: invokestatic    a/a/ag.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //    95: athrow         
        //    96: new             Ljava/lang/IllegalArgumentException;
        //    99: dup            
        //   100: new             Ljava/lang/StringBuilder;
        //   103: dup            
        //   104: invokespecial   java/lang/StringBuilder.<init>:()V
        //   107: sipush          27894
        //   110: sipush          6718
        //   113: invokestatic    a/a/ag.a:(II)Ljava/lang/String;
        //   116: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   119: iload_0        
        //   120: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   123: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   126: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //   129: athrow         
        //   130: invokestatic    a/a/ag.b:(Ljava/lang/IllegalArgumentException;)Ljava/lang/IllegalArgumentException;
        //   133: athrow         
        //   134: return         
        //    Exceptions:
        //  throws java.lang.IllegalArgumentException
        //  throws java.lang.IllegalAccessException
        //  throws java.lang.reflect.InvocationTargetException
        //    StackMapTable: 00 0D FF 00 15 00 06 01 07 00 3E 07 00 3E 07 00 3E 01 07 00 3F 00 01 07 00 33 FF 00 03 00 06 01 07 00 3E 07 00 3E 07 00 3E 01 07 00 3F 00 02 01 01 45 07 00 33 03 4E 07 00 33 03 04 45 07 00 33 FF 00 03 00 06 01 07 00 3E 07 00 3E 07 00 3E 01 07 00 3F 00 02 01 01 56 07 00 33 03 61 07 00 33 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  5      18     21     25     Ljava/lang/IllegalArgumentException;
        //  10     28     31     35     Ljava/lang/IllegalArgumentException;
        //  25     47     50     54     Ljava/lang/IllegalArgumentException;
        //  54     62     65     69     Ljava/lang/IllegalArgumentException;
        //  69     89     92     96     Ljava/lang/IllegalArgumentException;
        //  72     130    130    134    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0025:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void b(final int n, final String s) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        final String[] i = ac.i();
        int n2 = -1;
        final String[] array = i;
        Label_0085: {
            int n6;
            while (true) {
                Label_0080: {
                    int b2 = 0;
                    Label_0061: {
                        int n3;
                        while (true) {
                            Label_0043: {
                                int b = 0;
                                Label_0023: {
                                    int n4;
                                    try {
                                        n3 = n;
                                        final int n5;
                                        n4 = (n5 = -2147483646);
                                        if (array == null) {
                                            break Label_0061;
                                        }
                                        if (n == n4) {
                                            break Label_0023;
                                        }
                                        break Label_0043;
                                    }
                                    catch (IllegalArgumentException ex) {
                                        throw b(ex);
                                    }
                                    try {
                                        if (n != n4) {
                                            break Label_0043;
                                        }
                                        b = b(ag.q, n, s);
                                    }
                                    catch (IllegalArgumentException ex2) {
                                        throw b(ex2);
                                    }
                                }
                                n2 = b;
                                if (array != null) {
                                    break Label_0080;
                                }
                            }
                            n6 = n;
                            n3 = n;
                            int b = n;
                            if (array == null) {
                                continue;
                            }
                            break;
                        }
                        int n5;
                        try {
                            if (array == null) {
                                break Label_0085;
                            }
                            n5 = -2147483647;
                        }
                        catch (IllegalArgumentException ex3) {
                            throw b(ex3);
                        }
                        try {
                            if (n3 != n5) {
                                break Label_0080;
                            }
                            b2 = b(ag.j, n, s);
                        }
                        catch (IllegalArgumentException ex4) {
                            throw b(ex4);
                        }
                    }
                    n2 = b2;
                }
                int b2;
                n6 = (b2 = n2);
                if (array == null) {
                    continue;
                }
                break;
            }
            try {
                if (n6 != 0) {
                    throw new IllegalArgumentException(q.o.m.s.q.s(q.o.m.s.q.r(q.o.m.s.q.r(q.o.m.s.q.qg(q.o.m.s.q.r(new StringBuilder(), a(27890, -25740)), n2), a(27896, -7926)), s)));
                }
            }
            catch (IllegalArgumentException ex5) {
                throw b(ex5);
            }
        }
    }
    
    public static void b(final int n, final String s, final String s2, final int n2) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        final String[] i = ac.i();
        int n3 = -1;
        final String[] array = i;
        Label_0099: {
            int n7;
            while (true) {
                Label_0092: {
                    int a2 = 0;
                    Label_0070: {
                        int n4;
                        while (true) {
                            Label_0050: {
                                int a = 0;
                                Label_0026: {
                                    int n5;
                                    try {
                                        n4 = n;
                                        final int n6;
                                        n5 = (n6 = -2147483646);
                                        if (array == null) {
                                            break Label_0070;
                                        }
                                        if (n == n5) {
                                            break Label_0026;
                                        }
                                        break Label_0050;
                                    }
                                    catch (IllegalArgumentException ex) {
                                        throw b(ex);
                                    }
                                    try {
                                        if (n != n5) {
                                            break Label_0050;
                                        }
                                        a = a(ag.q, n, s, s2, n2);
                                    }
                                    catch (IllegalArgumentException ex2) {
                                        throw b(ex2);
                                    }
                                }
                                n3 = a;
                                if (array != null) {
                                    break Label_0092;
                                }
                            }
                            n7 = n;
                            n4 = n;
                            int a = n;
                            if (array == null) {
                                continue;
                            }
                            break;
                        }
                        int n6;
                        try {
                            if (array == null) {
                                break Label_0099;
                            }
                            n6 = -2147483647;
                        }
                        catch (IllegalArgumentException ex3) {
                            throw b(ex3);
                        }
                        try {
                            if (n4 != n6) {
                                break Label_0092;
                            }
                            a2 = a(ag.j, n, s, s2, n2);
                        }
                        catch (IllegalArgumentException ex4) {
                            throw b(ex4);
                        }
                    }
                    n3 = a2;
                }
                int a2;
                n7 = (a2 = n3);
                if (array == null) {
                    continue;
                }
                break;
            }
            try {
                if (n7 != 0) {
                    throw new IllegalArgumentException(q.o.m.s.q.s(q.o.m.s.q.r(q.o.m.s.q.r(q.o.m.s.q.r(q.o.m.s.q.r(q.o.m.s.q.qg(q.o.m.s.q.r(new StringBuilder(), a(27890, -25740)), n3), a(27896, -7926)), s), a(27897, 16998)), s2)));
                }
            }
            catch (IllegalArgumentException ex5) {
                throw b(ex5);
            }
        }
    }
    
    private static int a(final Preferences preferences, final int value, final String s, final String s2, final int n) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        final int[] array = (int[])q.o.m.s.q.qz(ag.e, preferences, new Object[] { new Integer(value), a(s), new Integer(0xF003F | n) });
        final String[] i = ac.i();
        int mm = 0;
        Label_0126: {
            Label_0088: {
                Label_0076: {
                    int n2;
                    try {
                        n2 = (mm = array[1]);
                        if (i == null) {
                            break Label_0126;
                        }
                        if (n2 != 0) {
                            break Label_0076;
                        }
                        break Label_0088;
                    }
                    catch (IllegalArgumentException ex) {
                        throw b(ex);
                    }
                    try {
                        if (n2 == 0) {
                            break Label_0088;
                        }
                        final int n3 = array[1];
                    }
                    catch (IllegalArgumentException ex2) {
                        throw b(ex2);
                    }
                }
                return;
            }
            mm = q.o.m.s.q.mm((Integer)q.o.m.s.q.qz(ag.s, preferences, new Object[] { new Integer(array[0]), a(s2) }));
        }
        final int n5 = mm;
        q.o.m.s.q.qz(ag.l, preferences, new Object[] { new Integer(array[0]) });
        final int n4 = n5;
        if (i != null) {
            return n4;
        }
        return n4;
    }
    
    private static int b(final Preferences preferences, final int value, final String s) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        return q.o.m.s.q.mm((Integer)q.o.m.s.q.qz(ag.i, preferences, new Object[] { new Integer(value), a(s) }));
    }
    
    private static String b(final Preferences preferences, final int value, final String s, final String s2, final int n) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        final String[] i = ac.i();
        final int[] array = (int[])q.o.m.s.q.qz(ag.e, preferences, new Object[] { new Integer(value), a(s), new Integer(0x20019 | n) });
        final String[] array2 = i;
        Object qz = null;
        Label_0114: {
            Label_0076: {
                int[] array3;
                try {
                    array3 = (int[])(qz = array);
                    if (array2 == null) {
                        break Label_0114;
                    }
                    final int n2 = 1;
                    final int n3 = array3[n2];
                    if (n3 != 0) {
                        break Label_0076;
                    }
                    break Label_0076;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    final int n2 = 1;
                    final int n3 = array3[n2];
                    if (n3 != 0) {
                        return null;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            qz = q.o.m.s.q.qz(ag.d, preferences, new Object[] { new Integer(array[0]), a(s2) });
        }
        final byte[] bytes = (byte[])qz;
        try {
            q.o.m.s.q.qz(ag.l, preferences, new Object[] { new Integer(array[0]) });
            if (bytes != null) {
                return q.o.m.s.q.qd(new String(bytes));
            }
        }
        catch (IllegalArgumentException ex3) {
            throw b(ex3);
        }
        return null;
    }
    
    private static Map<String, String> b(final Preferences preferences, final int value, final String s, final int n) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        final String[] i = ac.i();
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        final String[] array = i;
        final int[] array2 = (int[])q.o.m.s.q.qz(ag.e, preferences, new Object[] { new Integer(value), a(s), new Integer(0x20019 | n) });
        int[] array4 = null;
        Label_0121: {
            Label_0084: {
                int[] array3;
                try {
                    array3 = (array4 = array2);
                    if (array == null) {
                        break Label_0121;
                    }
                    final int n2 = 1;
                    final int n3 = array3[n2];
                    if (n3 != 0) {
                        break Label_0084;
                    }
                    break Label_0084;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    final int n2 = 1;
                    final int n3 = array3[n2];
                    if (n3 != 0) {
                        return null;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            array4 = (int[])q.o.m.s.q.qz(ag.c, preferences, new Object[] { new Integer(array2[0]) });
        }
        final int[] array5 = array4;
        final int n4 = array5[2];
        final int n5 = array5[3];
        int j = 0;
        while (j < n4) {
            final byte[] array6 = (byte[])q.o.m.s.q.qz(ag.p, preferences, new Object[] { new Integer(array2[0]), new Integer(j), new Integer(n5 + 1) });
            final String a = a(value, s, new String(array6), n);
            try {
                q.o.m.s.q.qb(hashMap, q.o.m.s.q.qd(new String(array6)), a);
                ++j;
                if (array == null) {
                    return hashMap;
                }
                if (array != null) {
                    continue;
                }
            }
            catch (IllegalArgumentException ex3) {
                throw b(ex3);
            }
            break;
        }
        q.o.m.s.q.qz(ag.l, preferences, new Object[] { new Integer(array2[0]) });
        return hashMap;
    }
    
    private static List<String> a(final Preferences preferences, final int value, final String s, final int n) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        final ArrayList<String> list = new ArrayList<String>();
        final String[] i = ac.i();
        final int[] array = (int[])q.o.m.s.q.qz(ag.e, preferences, new Object[] { new Integer(value), a(s), new Integer(0x20019 | n) });
        final String[] array2 = i;
        int[] array4 = null;
        Label_0121: {
            Label_0084: {
                int[] array3;
                try {
                    array3 = (array4 = array);
                    if (array2 == null) {
                        break Label_0121;
                    }
                    final int n2 = 1;
                    final int n3 = array3[n2];
                    if (n3 != 0) {
                        break Label_0084;
                    }
                    break Label_0084;
                }
                catch (IllegalArgumentException ex) {
                    throw b(ex);
                }
                try {
                    final int n2 = 1;
                    final int n3 = array3[n2];
                    if (n3 != 0) {
                        return null;
                    }
                }
                catch (IllegalArgumentException ex2) {
                    throw b(ex2);
                }
            }
            array4 = (int[])q.o.m.s.q.qz(ag.c, preferences, new Object[] { new Integer(array[0]) });
        }
        final int[] array5 = array4;
        final int n4 = array5[0];
        final int n5 = array5[3];
        int j = 0;
        while (j < n4) {
            final byte[] bytes = (byte[])q.o.m.s.q.qz(ag.g, preferences, new Object[] { new Integer(array[0]), new Integer(j), new Integer(n5 + 1) });
            try {
                q.o.m.s.q.qw(list, q.o.m.s.q.qd(new String(bytes)));
                ++j;
                if (array2 == null) {
                    return list;
                }
                if (array2 != null) {
                    continue;
                }
            }
            catch (IllegalArgumentException ex3) {
                throw b(ex3);
            }
            break;
        }
        q.o.m.s.q.qz(ag.l, preferences, new Object[] { new Integer(array[0]) });
        return list;
    }
    
    private static int[] a(final Preferences preferences, final int value, final String s) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        return (int[])q.o.m.s.q.qz(ag.f, preferences, new Object[] { new Integer(value), a(s) });
    }
    
    private static void a(final Preferences preferences, final int value, final String s, final String s2, final String s3, final int n) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        final int[] array = (int[])q.o.m.s.q.qz(ag.e, preferences, new Object[] { new Integer(value), a(s), new Integer(0xF003F | n) });
        q.o.m.s.q.qz(ag.t, preferences, new Object[] { new Integer(array[0]), a(s2), a(s3) });
        q.o.m.s.q.qz(ag.l, preferences, new Object[] { new Integer(array[0]) });
    }
    
    private static byte[] a(final String s) {
        final String[] i = ac.i();
        final byte[] array = new byte[q.o.m.s.q.q(s) + 1];
        final String[] array2 = i;
        int j = 0;
        while (j < q.o.m.s.q.q(s)) {
            try {
                array[j] = (byte)q.o.m.s.q.j(s, j);
                ++j;
                if (array2 == null) {
                    return array;
                }
                if (array2 != null) {
                    continue;
                }
            }
            catch (IllegalArgumentException ex) {
                throw b(ex);
            }
            break;
        }
        array[q.o.m.s.q.q(s)] = 0;
        return array;
    }
    
    static {
        final String[] w2 = new String[14];
        int n = 0;
        String s;
        int n2 = q.o.m.s.q.q(s = n.d.a.d.q.b());
        int n3 = 17;
        int n4 = -1;
    Label_0024:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 95));
                ++n4;
                final String s2 = s;
                final int n9 = n4;
                String s3 = q.o.m.s.q.h(s2, n9, n9 + n3);
                int n10 = -1;
                while (true) {
                    final char[] g = q.o.m.s.q.g(s3);
                    final int length = g.length;
                    int n11 = 0;
                    while (true) {
                        Label_0259: {
                            if (length > 1) {
                                break Label_0259;
                            }
                            n7 = (n6 = n11);
                            do {
                                final char c = g[n6];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 2;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 90;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 34;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 122;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 23;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 83;
                                        break;
                                    }
                                    default: {
                                        n12 = 20;
                                        break;
                                    }
                                }
                                g[n7] = (char)(c ^ (n5 ^ n12));
                                ++n11;
                            } while (n8 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.o.m.s.q.z(new String(g));
                    switch (n10) {
                        default: {
                            w2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.o.m.s.q.j(s, n4);
                                continue Label_0024;
                            }
                            n2 = q.o.m.s.q.q(s = n.d.a.d.q.w());
                            n3 = 3;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            w2[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.o.m.s.q.j(s, n4);
                                break;
                            }
                            break Label_0024;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 117)));
                    ++n4;
                    final String s4 = s;
                    final int n13 = n4;
                    s3 = q.o.m.s.q.h(s4, n13, n13 + n3);
                    n10 = 0;
                }
            }
            break;
        }
        w = w2;
        x = new String[14];
        ag.j = q.o.m.s.q.qa();
        ag.q = q.o.m.s.q.ql();
        ag.o = (Class<? extends Preferences>)q.o.m.s.q.qi(ag.j);
        ag.e = null;
        ag.l = null;
        ag.d = null;
        ag.p = null;
        ag.c = null;
        ag.g = null;
        ag.f = null;
        ag.t = null;
        ag.i = null;
        ag.s = null;
        try {
            q.o.m.s.q.tf(ag.e = q.o.m.s.q.qu(ag.o, a(27902, -27625), new Class[] { x.dn.g.b.q.v(), byte[].class, x.dn.g.b.q.v() }), true);
            q.o.m.s.q.tf(ag.l = q.o.m.s.q.qu(ag.o, a(27899, -7557), new Class[] { x.dn.g.b.q.v() }), true);
            q.o.m.s.q.tf(ag.d = q.o.m.s.q.qu(ag.o, a(27900, -16572), new Class[] { x.dn.g.b.q.v(), byte[].class }), true);
            q.o.m.s.q.tf(ag.p = q.o.m.s.q.qu(ag.o, a(27898, -27361), new Class[] { x.dn.g.b.q.v(), x.dn.g.b.q.v(), x.dn.g.b.q.v() }), true);
            q.o.m.s.q.tf(ag.c = q.o.m.s.q.qu(ag.o, a(27903, 23209), new Class[] { x.dn.g.b.q.v() }), true);
            q.o.m.s.q.tf(ag.g = q.o.m.s.q.qu(ag.o, a(27893, -6694), new Class[] { x.dn.g.b.q.v(), x.dn.g.b.q.v(), x.dn.g.b.q.v() }), true);
            q.o.m.s.q.tf(ag.f = q.o.m.s.q.qu(ag.o, a(27891, 22038), new Class[] { x.dn.g.b.q.v(), byte[].class }), true);
            q.o.m.s.q.tf(ag.t = q.o.m.s.q.qu(ag.o, a(27901, -10146), new Class[] { x.dn.g.b.q.v(), byte[].class, byte[].class }), true);
            q.o.m.s.q.tf(ag.s = q.o.m.s.q.qu(ag.o, a(27892, -25561), new Class[] { x.dn.g.b.q.v(), byte[].class }), true);
            q.o.m.s.q.tf(ag.i = q.o.m.s.q.qu(ag.o, a(27895, 29278), new Class[] { x.dn.g.b.q.v(), byte[].class }), true);
        }
        catch (Exception ex) {
            q.o.m.s.q.tm(ex);
        }
    }
    
    private static IllegalArgumentException b(final IllegalArgumentException ex) {
        return ex;
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0x6CFE) & 0xFFFF;
        if (ag.x[n3] == null) {
            final char[] g = q.o.m.s.q.g(ag.w[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 70;
                    break;
                }
                case 1: {
                    n4 = 86;
                    break;
                }
                case 2: {
                    n4 = 245;
                    break;
                }
                case 3: {
                    n4 = 152;
                    break;
                }
                case 4: {
                    n4 = 53;
                    break;
                }
                case 5: {
                    n4 = 28;
                    break;
                }
                case 6: {
                    n4 = 158;
                    break;
                }
                case 7: {
                    n4 = 204;
                    break;
                }
                case 8: {
                    n4 = 184;
                    break;
                }
                case 9: {
                    n4 = 21;
                    break;
                }
                case 10: {
                    n4 = 177;
                    break;
                }
                case 11: {
                    n4 = 111;
                    break;
                }
                case 12: {
                    n4 = 151;
                    break;
                }
                case 13: {
                    n4 = 33;
                    break;
                }
                case 14: {
                    n4 = 54;
                    break;
                }
                case 15: {
                    n4 = 190;
                    break;
                }
                case 16: {
                    n4 = 25;
                    break;
                }
                case 17: {
                    n4 = 8;
                    break;
                }
                case 18: {
                    n4 = 10;
                    break;
                }
                case 19: {
                    n4 = 4;
                    break;
                }
                case 20: {
                    n4 = 220;
                    break;
                }
                case 21: {
                    n4 = 95;
                    break;
                }
                case 22: {
                    n4 = 255;
                    break;
                }
                case 23: {
                    n4 = 232;
                    break;
                }
                case 24: {
                    n4 = 165;
                    break;
                }
                case 25: {
                    n4 = 109;
                    break;
                }
                case 26: {
                    n4 = 225;
                    break;
                }
                case 27: {
                    n4 = 229;
                    break;
                }
                case 28: {
                    n4 = 181;
                    break;
                }
                case 29: {
                    n4 = 195;
                    break;
                }
                case 30: {
                    n4 = 66;
                    break;
                }
                case 31: {
                    n4 = 167;
                    break;
                }
                case 32: {
                    n4 = 118;
                    break;
                }
                case 33: {
                    n4 = 7;
                    break;
                }
                case 34: {
                    n4 = 104;
                    break;
                }
                case 35: {
                    n4 = 162;
                    break;
                }
                case 36: {
                    n4 = 197;
                    break;
                }
                case 37: {
                    n4 = 29;
                    break;
                }
                case 38: {
                    n4 = 15;
                    break;
                }
                case 39: {
                    n4 = 144;
                    break;
                }
                case 40: {
                    n4 = 117;
                    break;
                }
                case 41: {
                    n4 = 214;
                    break;
                }
                case 42: {
                    n4 = 58;
                    break;
                }
                case 43: {
                    n4 = 217;
                    break;
                }
                case 44: {
                    n4 = 150;
                    break;
                }
                case 45: {
                    n4 = 213;
                    break;
                }
                case 46: {
                    n4 = 170;
                    break;
                }
                case 47: {
                    n4 = 22;
                    break;
                }
                case 48: {
                    n4 = 248;
                    break;
                }
                case 49: {
                    n4 = 44;
                    break;
                }
                case 50: {
                    n4 = 168;
                    break;
                }
                case 51: {
                    n4 = 80;
                    break;
                }
                case 52: {
                    n4 = 135;
                    break;
                }
                case 53: {
                    n4 = 123;
                    break;
                }
                case 54: {
                    n4 = 210;
                    break;
                }
                case 55: {
                    n4 = 237;
                    break;
                }
                case 56: {
                    n4 = 72;
                    break;
                }
                case 57: {
                    n4 = 46;
                    break;
                }
                case 58: {
                    n4 = 122;
                    break;
                }
                case 59: {
                    n4 = 252;
                    break;
                }
                case 60: {
                    n4 = 92;
                    break;
                }
                case 61: {
                    n4 = 132;
                    break;
                }
                case 62: {
                    n4 = 189;
                    break;
                }
                case 63: {
                    n4 = 65;
                    break;
                }
                case 64: {
                    n4 = 12;
                    break;
                }
                case 65: {
                    n4 = 149;
                    break;
                }
                case 66: {
                    n4 = 56;
                    break;
                }
                case 67: {
                    n4 = 211;
                    break;
                }
                case 68: {
                    n4 = 159;
                    break;
                }
                case 69: {
                    n4 = 191;
                    break;
                }
                case 70: {
                    n4 = 102;
                    break;
                }
                case 71: {
                    n4 = 74;
                    break;
                }
                case 72: {
                    n4 = 163;
                    break;
                }
                case 73: {
                    n4 = 140;
                    break;
                }
                case 74: {
                    n4 = 233;
                    break;
                }
                case 75: {
                    n4 = 11;
                    break;
                }
                case 76: {
                    n4 = 235;
                    break;
                }
                case 77: {
                    n4 = 103;
                    break;
                }
                case 78: {
                    n4 = 200;
                    break;
                }
                case 79: {
                    n4 = 219;
                    break;
                }
                case 80: {
                    n4 = 63;
                    break;
                }
                case 81: {
                    n4 = 0;
                    break;
                }
                case 82: {
                    n4 = 218;
                    break;
                }
                case 83: {
                    n4 = 119;
                    break;
                }
                case 84: {
                    n4 = 157;
                    break;
                }
                case 85: {
                    n4 = 32;
                    break;
                }
                case 86: {
                    n4 = 155;
                    break;
                }
                case 87: {
                    n4 = 84;
                    break;
                }
                case 88: {
                    n4 = 145;
                    break;
                }
                case 89: {
                    n4 = 49;
                    break;
                }
                case 90: {
                    n4 = 62;
                    break;
                }
                case 91: {
                    n4 = 43;
                    break;
                }
                case 92: {
                    n4 = 201;
                    break;
                }
                case 93: {
                    n4 = 24;
                    break;
                }
                case 94: {
                    n4 = 78;
                    break;
                }
                case 95: {
                    n4 = 52;
                    break;
                }
                case 96: {
                    n4 = 97;
                    break;
                }
                case 97: {
                    n4 = 183;
                    break;
                }
                case 98: {
                    n4 = 112;
                    break;
                }
                case 99: {
                    n4 = 130;
                    break;
                }
                case 100: {
                    n4 = 50;
                    break;
                }
                case 101: {
                    n4 = 3;
                    break;
                }
                case 102: {
                    n4 = 137;
                    break;
                }
                case 103: {
                    n4 = 23;
                    break;
                }
                case 104: {
                    n4 = 247;
                    break;
                }
                case 105: {
                    n4 = 253;
                    break;
                }
                case 106: {
                    n4 = 224;
                    break;
                }
                case 107: {
                    n4 = 6;
                    break;
                }
                case 108: {
                    n4 = 64;
                    break;
                }
                case 109: {
                    n4 = 83;
                    break;
                }
                case 110: {
                    n4 = 57;
                    break;
                }
                case 111: {
                    n4 = 164;
                    break;
                }
                case 112: {
                    n4 = 107;
                    break;
                }
                case 113: {
                    n4 = 2;
                    break;
                }
                case 114: {
                    n4 = 209;
                    break;
                }
                case 115: {
                    n4 = 61;
                    break;
                }
                case 116: {
                    n4 = 35;
                    break;
                }
                case 117: {
                    n4 = 38;
                    break;
                }
                case 118: {
                    n4 = 41;
                    break;
                }
                case 119: {
                    n4 = 234;
                    break;
                }
                case 120: {
                    n4 = 250;
                    break;
                }
                case 121: {
                    n4 = 239;
                    break;
                }
                case 122: {
                    n4 = 18;
                    break;
                }
                case 123: {
                    n4 = 179;
                    break;
                }
                case 124: {
                    n4 = 156;
                    break;
                }
                case 125: {
                    n4 = 142;
                    break;
                }
                case 126: {
                    n4 = 115;
                    break;
                }
                case 127: {
                    n4 = 14;
                    break;
                }
                case 128: {
                    n4 = 126;
                    break;
                }
                case 129: {
                    n4 = 98;
                    break;
                }
                case 130: {
                    n4 = 124;
                    break;
                }
                case 131: {
                    n4 = 59;
                    break;
                }
                case 132: {
                    n4 = 136;
                    break;
                }
                case 133: {
                    n4 = 172;
                    break;
                }
                case 134: {
                    n4 = 69;
                    break;
                }
                case 135: {
                    n4 = 88;
                    break;
                }
                case 136: {
                    n4 = 180;
                    break;
                }
                case 137: {
                    n4 = 243;
                    break;
                }
                case 138: {
                    n4 = 100;
                    break;
                }
                case 139: {
                    n4 = 161;
                    break;
                }
                case 140: {
                    n4 = 85;
                    break;
                }
                case 141: {
                    n4 = 17;
                    break;
                }
                case 142: {
                    n4 = 121;
                    break;
                }
                case 143: {
                    n4 = 108;
                    break;
                }
                case 144: {
                    n4 = 166;
                    break;
                }
                case 145: {
                    n4 = 215;
                    break;
                }
                case 146: {
                    n4 = 153;
                    break;
                }
                case 147: {
                    n4 = 173;
                    break;
                }
                case 148: {
                    n4 = 45;
                    break;
                }
                case 149: {
                    n4 = 67;
                    break;
                }
                case 150: {
                    n4 = 223;
                    break;
                }
                case 151: {
                    n4 = 101;
                    break;
                }
                case 152: {
                    n4 = 87;
                    break;
                }
                case 153: {
                    n4 = 26;
                    break;
                }
                case 154: {
                    n4 = 81;
                    break;
                }
                case 155: {
                    n4 = 199;
                    break;
                }
                case 156: {
                    n4 = 194;
                    break;
                }
                case 157: {
                    n4 = 147;
                    break;
                }
                case 158: {
                    n4 = 185;
                    break;
                }
                case 159: {
                    n4 = 228;
                    break;
                }
                case 160: {
                    n4 = 240;
                    break;
                }
                case 161: {
                    n4 = 42;
                    break;
                }
                case 162: {
                    n4 = 174;
                    break;
                }
                case 163: {
                    n4 = 160;
                    break;
                }
                case 164: {
                    n4 = 128;
                    break;
                }
                case 165: {
                    n4 = 116;
                    break;
                }
                case 166: {
                    n4 = 129;
                    break;
                }
                case 167: {
                    n4 = 138;
                    break;
                }
                case 168: {
                    n4 = 5;
                    break;
                }
                case 169: {
                    n4 = 96;
                    break;
                }
                case 170: {
                    n4 = 205;
                    break;
                }
                case 171: {
                    n4 = 141;
                    break;
                }
                case 172: {
                    n4 = 208;
                    break;
                }
                case 173: {
                    n4 = 125;
                    break;
                }
                case 174: {
                    n4 = 110;
                    break;
                }
                case 175: {
                    n4 = 226;
                    break;
                }
                case 176: {
                    n4 = 175;
                    break;
                }
                case 177: {
                    n4 = 227;
                    break;
                }
                case 178: {
                    n4 = 19;
                    break;
                }
                case 179: {
                    n4 = 93;
                    break;
                }
                case 180: {
                    n4 = 79;
                    break;
                }
                case 181: {
                    n4 = 30;
                    break;
                }
                case 182: {
                    n4 = 171;
                    break;
                }
                case 183: {
                    n4 = 146;
                    break;
                }
                case 184: {
                    n4 = 242;
                    break;
                }
                case 185: {
                    n4 = 27;
                    break;
                }
                case 186: {
                    n4 = 13;
                    break;
                }
                case 187: {
                    n4 = 188;
                    break;
                }
                case 188: {
                    n4 = 75;
                    break;
                }
                case 189: {
                    n4 = 202;
                    break;
                }
                case 190: {
                    n4 = 91;
                    break;
                }
                case 191: {
                    n4 = 192;
                    break;
                }
                case 192: {
                    n4 = 193;
                    break;
                }
                case 193: {
                    n4 = 77;
                    break;
                }
                case 194: {
                    n4 = 187;
                    break;
                }
                case 195: {
                    n4 = 154;
                    break;
                }
                case 196: {
                    n4 = 131;
                    break;
                }
                case 197: {
                    n4 = 133;
                    break;
                }
                case 198: {
                    n4 = 55;
                    break;
                }
                case 199: {
                    n4 = 113;
                    break;
                }
                case 200: {
                    n4 = 40;
                    break;
                }
                case 201: {
                    n4 = 94;
                    break;
                }
                case 202: {
                    n4 = 230;
                    break;
                }
                case 203: {
                    n4 = 169;
                    break;
                }
                case 204: {
                    n4 = 16;
                    break;
                }
                case 205: {
                    n4 = 244;
                    break;
                }
                case 206: {
                    n4 = 134;
                    break;
                }
                case 207: {
                    n4 = 236;
                    break;
                }
                case 208: {
                    n4 = 238;
                    break;
                }
                case 209: {
                    n4 = 47;
                    break;
                }
                case 210: {
                    n4 = 82;
                    break;
                }
                case 211: {
                    n4 = 20;
                    break;
                }
                case 212: {
                    n4 = 31;
                    break;
                }
                case 213: {
                    n4 = 246;
                    break;
                }
                case 214: {
                    n4 = 105;
                    break;
                }
                case 215: {
                    n4 = 1;
                    break;
                }
                case 216: {
                    n4 = 254;
                    break;
                }
                case 217: {
                    n4 = 207;
                    break;
                }
                case 218: {
                    n4 = 9;
                    break;
                }
                case 219: {
                    n4 = 203;
                    break;
                }
                case 220: {
                    n4 = 34;
                    break;
                }
                case 221: {
                    n4 = 212;
                    break;
                }
                case 222: {
                    n4 = 178;
                    break;
                }
                case 223: {
                    n4 = 51;
                    break;
                }
                case 224: {
                    n4 = 106;
                    break;
                }
                case 225: {
                    n4 = 73;
                    break;
                }
                case 226: {
                    n4 = 114;
                    break;
                }
                case 227: {
                    n4 = 176;
                    break;
                }
                case 228: {
                    n4 = 120;
                    break;
                }
                case 229: {
                    n4 = 196;
                    break;
                }
                case 230: {
                    n4 = 222;
                    break;
                }
                case 231: {
                    n4 = 48;
                    break;
                }
                case 232: {
                    n4 = 89;
                    break;
                }
                case 233: {
                    n4 = 139;
                    break;
                }
                case 234: {
                    n4 = 71;
                    break;
                }
                case 235: {
                    n4 = 216;
                    break;
                }
                case 236: {
                    n4 = 60;
                    break;
                }
                case 237: {
                    n4 = 249;
                    break;
                }
                case 238: {
                    n4 = 127;
                    break;
                }
                case 239: {
                    n4 = 182;
                    break;
                }
                case 240: {
                    n4 = 37;
                    break;
                }
                case 241: {
                    n4 = 198;
                    break;
                }
                case 242: {
                    n4 = 36;
                    break;
                }
                case 243: {
                    n4 = 186;
                    break;
                }
                case 244: {
                    n4 = 99;
                    break;
                }
                case 245: {
                    n4 = 68;
                    break;
                }
                case 246: {
                    n4 = 206;
                    break;
                }
                case 247: {
                    n4 = 231;
                    break;
                }
                case 248: {
                    n4 = 143;
                    break;
                }
                case 249: {
                    n4 = 251;
                    break;
                }
                case 250: {
                    n4 = 76;
                    break;
                }
                case 251: {
                    n4 = 221;
                    break;
                }
                case 252: {
                    n4 = 241;
                    break;
                }
                case 253: {
                    n4 = 90;
                    break;
                }
                case 254: {
                    n4 = 39;
                    break;
                }
                default: {
                    n4 = 148;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            ag.x[n3] = q.o.m.s.q.z(new String(g));
        }
        return ag.x[n3];
    }
}
