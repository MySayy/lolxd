// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import q.o.m.s.q;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ao implements ActionListener
{
    final ac a;
    
    ao(final ac a) {
        this.a = a;
    }
    
    @Override
    public void actionPerformed(final ActionEvent actionEvent) {
        final String[] i = ac.i();
        boolean u = false;
        Label_0037: {
            while (true) {
                Label_0032: {
                    try {
                        u = q.u(ac.j());
                        if (i == null) {
                            break Label_0037;
                        }
                        if (!u) {
                            break Label_0032;
                        }
                    }
                    catch (RuntimeException ex) {
                        throw b(ex);
                    }
                    final boolean b = true;
                    final boolean ac;
                    a.a.ac.aC = ac;
                    if (i != null) {
                        return;
                    }
                }
                final boolean ac = false;
                if (i == null) {
                    continue;
                }
                break;
            }
        }
        ac.aC = u;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
