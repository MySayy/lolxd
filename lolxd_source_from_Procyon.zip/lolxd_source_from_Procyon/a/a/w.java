// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import q.o.m.s.q;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class w implements ActionListener
{
    final ac a;
    
    w(final ac a) {
        this.a = a;
    }
    
    @Override
    public void actionPerformed(final ActionEvent actionEvent) {
        final String[] i = ac.i();
        boolean u = false;
        Label_0037: {
            while (true) {
                Label_0032: {
                    try {
                        u = q.u(ac.I);
                        if (i == null) {
                            break Label_0037;
                        }
                        if (!u) {
                            break Label_0032;
                        }
                    }
                    catch (RuntimeException ex) {
                        throw b(ex);
                    }
                    final boolean b = true;
                    final boolean j;
                    p.I = j;
                    if (i != null) {
                        return;
                    }
                }
                final boolean j = false;
                if (i == null) {
                    continue;
                }
                break;
            }
        }
        p.I = u;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
