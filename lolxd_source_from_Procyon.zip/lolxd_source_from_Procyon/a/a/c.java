// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import org.jnativehook.mouse.NativeMouseEvent;
import java.net.Socket;
import org.jnativehook.mouse.NativeMouseListener;

public class c implements NativeMouseListener
{
    private Socket b;
    private boolean a;
    
    public c() {
        this.a = false;
    }
    
    @Override
    public void nativeMousePressed(final NativeMouseEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_1        
        //     5: invokevirtual   org/jnativehook/mouse/NativeMouseEvent.getButton:()I
        //     8: iconst_1       
        //     9: aload_2        
        //    10: ifnull          224
        //    13: if_icmpne       184
        //    16: goto            23
        //    19: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    22: athrow         
        //    23: getstatic       a/a/p.D:Z
        //    26: aload_2        
        //    27: ifnull          212
        //    30: ifeq            184
        //    33: getstatic       a/a/p.F:Z
        //    36: aload_2        
        //    37: ifnull          212
        //    40: ifne            184
        //    43: aload_0        
        //    44: aload_2        
        //    45: ifnull          73
        //    48: goto            55
        //    51: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    54: athrow         
        //    55: getfield        a/a/c.a:Z
        //    58: goto            65
        //    61: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    64: athrow         
        //    65: aload_2        
        //    66: ifnull          80
        //    69: ifne            77
        //    72: aload_0        
        //    73: iconst_1       
        //    74: putfield        a/a/c.a:Z
        //    77: getstatic       a/a/ac.aC:Z
        //    80: aload_2        
        //    81: ifnull          157
        //    84: ifeq            143
        //    87: goto            94
        //    90: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    93: athrow         
        //    94: invokestatic    a/a/p.c:()Z
        //    97: aload_2        
        //    98: ifnull          212
        //   101: ifeq            184
        //   104: getstatic       a/a/p.f:Z
        //   107: aload_2        
        //   108: ifnull          212
        //   111: ifne            184
        //   114: getstatic       a/a/p.v:Z
        //   117: aload_2        
        //   118: ifnull          125
        //   121: ifeq            129
        //   124: iconst_0       
        //   125: invokestatic    q/o/m/s/q.ms:(I)V
        //   128: return         
        //   129: invokestatic    a/a/p.a:()V
        //   132: invokestatic    a/a/s.a:()V
        //   135: aload_2        
        //   136: ifnull          128
        //   139: aload_2        
        //   140: ifnonnull       184
        //   143: getstatic       a/a/p.f:Z
        //   146: aload_2        
        //   147: ifnull          97
        //   150: goto            157
        //   153: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   156: athrow         
        //   157: aload_2        
        //   158: ifnull          212
        //   161: ifne            184
        //   164: goto            171
        //   167: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   170: athrow         
        //   171: invokestatic    a/a/p.a:()V
        //   174: invokestatic    a/a/s.a:()V
        //   177: goto            184
        //   180: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   183: athrow         
        //   184: aload_1        
        //   185: invokevirtual   org/jnativehook/mouse/NativeMouseEvent.getButton:()I
        //   188: aload_2        
        //   189: ifnull          26
        //   192: aload_2        
        //   193: ifnull          36
        //   196: aload_2        
        //   197: ifnull          65
        //   200: aload_2        
        //   201: ifnull          107
        //   204: aload_2        
        //   205: ifnull          117
        //   208: aload_2        
        //   209: ifnull          230
        //   212: aload_2        
        //   213: ifnull          234
        //   216: iconst_2       
        //   217: goto            224
        //   220: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   223: athrow         
        //   224: if_icmpne       259
        //   227: getstatic       a/a/p.r:Z
        //   230: aload_2        
        //   231: ifnull          256
        //   234: aload_2        
        //   235: ifnull          256
        //   238: goto            245
        //   241: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   244: athrow         
        //   245: ifne            259
        //   248: goto            255
        //   251: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   254: athrow         
        //   255: iconst_1       
        //   256: putstatic       a/a/p.n:Z
        //   259: return         
        //    StackMapTable: 00 25 FF 00 13 00 03 07 00 02 07 00 1D 07 00 23 00 01 07 00 15 03 42 01 49 01 4E 07 00 15 43 07 00 02 45 07 00 15 43 01 47 07 00 02 03 42 01 49 07 00 15 03 42 01 49 01 49 01 47 01 02 00 0D 49 07 00 15 43 01 49 07 00 15 03 48 07 00 15 03 5B 01 47 07 00 15 FF 00 03 00 03 07 00 02 07 00 1D 07 00 23 00 02 01 01 45 01 43 01 46 07 00 15 43 01 45 07 00 15 03 40 01 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      16     19     23     Ljava/lang/RuntimeException;
        //  40     48     51     55     Ljava/lang/RuntimeException;
        //  43     58     61     65     Ljava/lang/RuntimeException;
        //  80     87     90     94     Ljava/lang/RuntimeException;
        //  139    150    153    157    Ljava/lang/RuntimeException;
        //  157    164    167    171    Ljava/lang/RuntimeException;
        //  161    177    180    184    Ljava/lang/RuntimeException;
        //  212    217    220    224    Ljava/lang/RuntimeException;
        //  230    238    241    245    Ljava/lang/RuntimeException;
        //  234    248    251    255    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0234:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void nativeMouseReleased(final NativeMouseEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_1        
        //     5: invokevirtual   org/jnativehook/mouse/NativeMouseEvent.getButton:()I
        //     8: iconst_1       
        //     9: aload_2        
        //    10: ifnull          103
        //    13: if_icmpne       68
        //    16: goto            23
        //    19: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    22: athrow         
        //    23: getstatic       a/a/p.D:Z
        //    26: aload_2        
        //    27: ifnull          84
        //    30: ifeq            68
        //    33: getstatic       a/a/p.F:Z
        //    36: aload_2        
        //    37: ifnull          65
        //    40: ifne            57
        //    43: invokestatic    a/a/p.b:()V
        //    46: aload_2        
        //    47: ifnonnull       68
        //    50: goto            57
        //    53: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    56: athrow         
        //    57: iconst_0       
        //    58: goto            65
        //    61: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    64: athrow         
        //    65: putstatic       a/a/p.F:Z
        //    68: aload_1        
        //    69: invokevirtual   org/jnativehook/mouse/NativeMouseEvent.getButton:()I
        //    72: aload_2        
        //    73: ifnull          26
        //    76: aload_2        
        //    77: ifnull          36
        //    80: aload_2        
        //    81: ifnull          109
        //    84: aload_2        
        //    85: ifnull          109
        //    88: goto            95
        //    91: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    94: athrow         
        //    95: iconst_2       
        //    96: goto            103
        //    99: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   102: athrow         
        //   103: if_icmpne       139
        //   106: getstatic       a/a/p.r:Z
        //   109: aload_2        
        //   110: ifnull          136
        //   113: ifne            131
        //   116: goto            123
        //   119: invokestatic    a/a/c.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   122: athrow         
        //   123: iconst_0       
        //   124: putstatic       a/a/p.n:Z
        //   127: aload_2        
        //   128: ifnonnull       139
        //   131: iconst_0       
        //   132: aload_2        
        //   133: ifnull          124
        //   136: putstatic       a/a/p.r:Z
        //   139: return         
        //    StackMapTable: 00 15 FF 00 13 00 03 07 00 02 07 00 1D 07 00 23 00 01 07 00 15 03 42 01 49 01 50 07 00 15 03 43 07 00 15 43 01 02 4F 01 46 07 00 15 43 01 43 07 00 15 FF 00 03 00 03 07 00 02 07 00 1D 07 00 23 00 02 01 01 45 01 49 07 00 15 03 40 01 06 44 01 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      16     19     23     Ljava/lang/RuntimeException;
        //  40     50     53     57     Ljava/lang/RuntimeException;
        //  43     58     61     65     Ljava/lang/RuntimeException;
        //  80     88     91     95     Ljava/lang/RuntimeException;
        //  84     96     99     103    Ljava/lang/RuntimeException;
        //  109    116    119    123    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0084:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void nativeMouseClicked(final NativeMouseEvent nativeMouseEvent) {
    }
    
    static Socket a(final c c, final Socket b) {
        return c.b = b;
    }
    
    static Socket a(final c c) {
        return c.b;
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
