// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import javax.sound.sampled.AudioInputStream;
import q.o.m.s.q;

public class s
{
    public static void a() {
        q.rn(new Thread(new x()));
    }
    
    private static AudioInputStream a(final AudioInputStream p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: invokestatic    q/o/m/s/q.rp:(Ljavax/sound/sampled/AudioInputStream;)Ljavax/sound/sampled/AudioFormat;
        //     7: astore_2       
        //     8: astore_1       
        //     9: aload_2        
        //    10: invokestatic    q/o/m/s/q.ry:(Ljavax/sound/sampled/AudioFormat;)Ljavax/sound/sampled/AudioFormat$Encoding;
        //    13: invokestatic    x/dn/g/b/q.q:()Ljavax/sound/sampled/AudioFormat$Encoding;
        //    16: aload_1        
        //    17: ifnull          77
        //    20: aload_1        
        //    21: ifnull          77
        //    24: goto            31
        //    27: invokestatic    a/a/s.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    30: athrow         
        //    31: if_acmpeq       128
        //    34: goto            41
        //    37: invokestatic    a/a/s.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    40: athrow         
        //    41: aload_2        
        //    42: aload_1        
        //    43: ifnull          121
        //    46: goto            53
        //    49: invokestatic    a/a/s.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    52: athrow         
        //    53: aload_1        
        //    54: ifnull          121
        //    57: goto            64
        //    60: invokestatic    a/a/s.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    63: athrow         
        //    64: invokestatic    q/o/m/s/q.ry:(Ljavax/sound/sampled/AudioFormat;)Ljavax/sound/sampled/AudioFormat$Encoding;
        //    67: invokestatic    x/dn/g/b/q.t:()Ljavax/sound/sampled/AudioFormat$Encoding;
        //    70: goto            77
        //    73: invokestatic    a/a/s.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    76: athrow         
        //    77: if_acmpeq       128
        //    80: new             Ljavax/sound/sampled/AudioFormat;
        //    83: dup            
        //    84: invokestatic    x/dn/g/b/q.q:()Ljavax/sound/sampled/AudioFormat$Encoding;
        //    87: aload_2        
        //    88: invokestatic    q/o/m/s/q.rc:(Ljavax/sound/sampled/AudioFormat;)F
        //    91: bipush          16
        //    93: aload_2        
        //    94: invokestatic    q/o/m/s/q.rx:(Ljavax/sound/sampled/AudioFormat;)I
        //    97: aload_2        
        //    98: invokestatic    q/o/m/s/q.rx:(Ljavax/sound/sampled/AudioFormat;)I
        //   101: iconst_2       
        //   102: imul           
        //   103: aload_2        
        //   104: invokestatic    q/o/m/s/q.rc:(Ljavax/sound/sampled/AudioFormat;)F
        //   107: aload_2        
        //   108: invokestatic    q/o/m/s/q.rh:(Ljavax/sound/sampled/AudioFormat;)Z
        //   111: invokespecial   javax/sound/sampled/AudioFormat.<init>:(Ljavax/sound/sampled/AudioFormat$Encoding;FIIIFZ)V
        //   114: goto            121
        //   117: invokestatic    a/a/s.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   120: athrow         
        //   121: astore_3       
        //   122: aload_3        
        //   123: aload_0        
        //   124: invokestatic    q/o/m/s/q.rj:(Ljavax/sound/sampled/AudioFormat;Ljavax/sound/sampled/AudioInputStream;)Ljavax/sound/sampled/AudioInputStream;
        //   127: astore_0       
        //   128: aload_0        
        //   129: areturn        
        //    StackMapTable: 00 0D FF 00 1B 00 03 07 00 31 07 00 33 07 00 35 00 01 07 00 1B FF 00 03 00 03 07 00 31 07 00 33 07 00 35 00 02 07 00 3B 07 00 3B 45 07 00 1B 03 47 07 00 1B 43 07 00 35 46 07 00 1B 43 07 00 35 48 07 00 1B FF 00 03 00 03 07 00 31 07 00 33 07 00 35 00 02 07 00 3B 07 00 3B 67 07 00 1B 43 07 00 35 06
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  9      24     27     31     Ljava/lang/RuntimeException;
        //  20     34     37     41     Ljava/lang/RuntimeException;
        //  31     46     49     53     Ljava/lang/RuntimeException;
        //  41     57     60     64     Ljava/lang/RuntimeException;
        //  53     70     73     77     Ljava/lang/RuntimeException;
        //  77     114    117    121    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0031:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static AudioInputStream b(final AudioInputStream audioInputStream) {
        return a(audioInputStream);
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
