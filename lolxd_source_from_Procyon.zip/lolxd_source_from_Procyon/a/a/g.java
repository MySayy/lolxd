// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import q.o.m.s.q;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

class g implements ChangeListener
{
    final ac a;
    
    g(final ac a) {
        this.a = a;
    }
    
    @Override
    public void stateChanged(final ChangeEvent changeEvent) {
        p.b = q.mv(ac.q(this.a));
    }
}
