// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import q.o.m.s.q;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

class a2 implements ChangeListener
{
    final ac a;
    
    a2(final ac a) {
        this.a = a;
    }
    
    @Override
    public void stateChanged(final ChangeEvent changeEvent) {
        p.a.a = q.mm((Integer)q.mf(ac.m(this.a)));
    }
}
