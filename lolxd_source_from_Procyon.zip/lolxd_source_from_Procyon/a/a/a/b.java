// 
// Decompiled by Procyon v0.5.36
// 

package a.a.a;

import java.awt.Component;
import q.o.m.s.q;

public class b
{
    private static String[] b;
    private static final String a;
    
    public static void a(final String s, final String s2) {
        q.d(null, s, q.s(q.r(q.r(new StringBuilder(), a.a.a.b.a), s2)), 1);
    }
    
    public static void b(final String[] b) {
        b.b = b;
    }
    
    public static String[] b() {
        return a.a.a.b.b;
    }
    
    static {
        b(null);
        int n3;
        int n2;
        final int n = n2 = (n3 = 52);
        final char[] g = q.g(n.d.a.d.q.q());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0132: {
                if (length > 1) {
                    break Label_0132;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 56;
                            break;
                        }
                        case 1: {
                            n5 = 124;
                            break;
                        }
                        case 2: {
                            n5 = 53;
                            break;
                        }
                        case 3: {
                            n5 = 107;
                            break;
                        }
                        case 4: {
                            n5 = 71;
                            break;
                        }
                        case 5: {
                            n5 = 88;
                            break;
                        }
                        default: {
                            n5 = 39;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                a = q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
