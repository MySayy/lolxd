// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import q.o.m.s.q;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import java.awt.event.WindowListener;
import java.awt.event.WindowFocusListener;
import javax.swing.JFrame;

public class av extends JFrame
{
    private ac a;
    
    public av(final ac a) {
        this.a = a;
    }
    
    public void b() {
        this.addWindowFocusListener(new bb(this));
        this.addWindowListener(new a0(this));
        final Color am = this.a.am;
        final Color d = this.a.D;
        this.setLayout(new BorderLayout());
        q.od(this.getContentPane(), am);
        this.setPreferredSize(new Dimension(270, 170));
        this.setResizable(false);
        this.a();
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }
    
    public void a() {
    }
    
    static ac a(final av av) {
        return av.a;
    }
}
