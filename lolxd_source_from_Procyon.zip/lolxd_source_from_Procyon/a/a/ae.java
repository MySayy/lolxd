// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ae implements ActionListener
{
    public boolean a() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: getstatic       a/a/ac.H:Z
        //     7: aload_1        
        //     8: ifnull          35
        //    11: aload_1        
        //    12: ifnull          39
        //    15: goto            22
        //    18: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    21: athrow         
        //    22: ifne            64
        //    25: goto            32
        //    28: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    31: athrow         
        //    32: getstatic       a/a/p.f:Z
        //    35: aload_1        
        //    36: ifnull          61
        //    39: aload_1        
        //    40: ifnull          61
        //    43: goto            50
        //    46: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    49: athrow         
        //    50: ifeq            64
        //    53: goto            60
        //    56: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    59: athrow         
        //    60: iconst_1       
        //    61: goto            65
        //    64: iconst_0       
        //    65: ireturn        
        //    StackMapTable: 00 0D FF 00 12 00 02 07 00 02 07 00 1B 00 01 07 00 0F 43 01 45 07 00 0F 03 42 01 43 01 46 07 00 0F 43 01 45 07 00 0F 03 40 01 02 40 01
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      15     18     22     Ljava/lang/RuntimeException;
        //  11     25     28     32     Ljava/lang/RuntimeException;
        //  35     43     46     50     Ljava/lang/RuntimeException;
        //  39     53     56     60     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0039:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void actionPerformed(final ActionEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_0        
        //     5: invokevirtual   a/a/ae.a:()Z
        //     8: aload_2        
        //     9: ifnull          30
        //    12: ifne            23
        //    15: goto            22
        //    18: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    21: athrow         
        //    22: return         
        //    23: getstatic       a/a/p.o:Z
        //    26: aload_2        
        //    27: ifnull          69
        //    30: aload_2        
        //    31: ifnull          69
        //    34: goto            41
        //    37: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    40: athrow         
        //    41: ifeq            474
        //    44: goto            51
        //    47: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    50: athrow         
        //    51: invokestatic    q/o/m/s/q.qn:()D
        //    54: getstatic       a/a/p.c:I
        //    57: i2d            
        //    58: dmul           
        //    59: d2i            
        //    60: iconst_1       
        //    61: iadd           
        //    62: goto            69
        //    65: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    68: athrow         
        //    69: istore_3       
        //    70: invokestatic    q/o/m/s/q.qn:()D
        //    73: getstatic       a/a/p.c:I
        //    76: i2d            
        //    77: dmul           
        //    78: d2i            
        //    79: iconst_1       
        //    80: iadd           
        //    81: istore          4
        //    83: invokestatic    q/o/m/s/q.qn:()D
        //    86: ldc2_w          2.0
        //    89: dmul           
        //    90: d2i            
        //    91: iconst_1       
        //    92: iadd           
        //    93: istore          5
        //    95: invokestatic    q/o/m/s/q.qn:()D
        //    98: ldc2_w          2.0
        //   101: dmul           
        //   102: d2i            
        //   103: iconst_1       
        //   104: iadd           
        //   105: istore          6
        //   107: iload           5
        //   109: iconst_1       
        //   110: aload_2        
        //   111: ifnull          142
        //   114: if_icmpne       135
        //   117: goto            124
        //   120: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   123: athrow         
        //   124: iload_3        
        //   125: iconst_m1      
        //   126: goto            133
        //   129: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   132: athrow         
        //   133: imul           
        //   134: istore_3       
        //   135: iload           6
        //   137: iconst_1       
        //   138: aload_2        
        //   139: ifnull          133
        //   142: aload_2        
        //   143: ifnull          166
        //   146: if_icmpne       169
        //   149: goto            156
        //   152: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   155: athrow         
        //   156: iload           4
        //   158: iconst_m1      
        //   159: goto            166
        //   162: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   165: athrow         
        //   166: imul           
        //   167: istore          4
        //   169: invokestatic    q/o/m/s/q.qp:()Ljava/awt/PointerInfo;
        //   172: invokestatic    q/o/m/s/q.qy:(Ljava/awt/PointerInfo;)Ljava/awt/Point;
        //   175: astore          7
        //   177: new             Ljava/awt/Point;
        //   180: dup            
        //   181: aload           7
        //   183: invokestatic    q/o/m/s/q.qc:(Ljava/awt/Point;)D
        //   186: d2i            
        //   187: iload_3        
        //   188: iadd           
        //   189: aload           7
        //   191: invokestatic    q/o/m/s/q.qx:(Ljava/awt/Point;)D
        //   194: d2i            
        //   195: iload           4
        //   197: iadd           
        //   198: invokespecial   java/awt/Point.<init>:(II)V
        //   201: astore          8
        //   203: new             Ljava/awt/Robot;
        //   206: dup            
        //   207: invokespecial   java/awt/Robot.<init>:()V
        //   210: astore          9
        //   212: iload_3        
        //   213: aload_2        
        //   214: ifnull          167
        //   217: aload_2        
        //   218: ifnull          352
        //   221: ifle            336
        //   224: goto            231
        //   227: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   230: athrow         
        //   231: iconst_0       
        //   232: istore          10
        //   234: iload           10
        //   236: iload_3        
        //   237: if_icmpge       332
        //   240: aload           9
        //   242: aload           8
        //   244: invokestatic    q/o/m/s/q.qc:(Ljava/awt/Point;)D
        //   247: d2i            
        //   248: iload           10
        //   250: isub           
        //   251: aload           8
        //   253: invokestatic    q/o/m/s/q.qx:(Ljava/awt/Point;)D
        //   256: d2i            
        //   257: iload           10
        //   259: isub           
        //   260: invokestatic    q/o/m/s/q.qh:(Ljava/awt/Robot;II)V
        //   263: aload_2        
        //   264: ifnull          474
        //   267: aload_2        
        //   268: ifnull          328
        //   271: goto            278
        //   274: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   277: athrow         
        //   278: getstatic       a/a/p.G:Ljava/lang/Integer;
        //   281: ifnull          314
        //   284: goto            291
        //   287: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   290: athrow         
        //   291: getstatic       a/a/q.INSTANCE2:La/a/q;
        //   294: bipush          113
        //   296: iconst_0       
        //   297: getstatic       a/a/p.G:Ljava/lang/Integer;
        //   300: iconst_2       
        //   301: invokeinterface a/a/q.SystemParametersInfo:(IILjava/lang/Object;I)Z
        //   306: goto            313
        //   309: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   312: athrow         
        //   313: pop            
        //   314: getstatic       a/a/p.z:I
        //   317: aload_2        
        //   318: ifnull          313
        //   321: i2l            
        //   322: invokestatic    q/o/m/s/q.mt:(J)V
        //   325: iinc            10, 1
        //   328: aload_2        
        //   329: ifnonnull       234
        //   332: aload_2        
        //   333: ifnonnull       474
        //   336: iload_3        
        //   337: aload_2        
        //   338: ifnull          232
        //   341: goto            348
        //   344: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   347: athrow         
        //   348: aload_2        
        //   349: ifnull          374
        //   352: aload_2        
        //   353: ifnull          374
        //   356: goto            363
        //   359: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   362: athrow         
        //   363: ifge            474
        //   366: goto            373
        //   369: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   372: athrow         
        //   373: iconst_0       
        //   374: istore          10
        //   376: iload           10
        //   378: iload_3        
        //   379: if_icmple       474
        //   382: aload           9
        //   384: aload           8
        //   386: invokestatic    q/o/m/s/q.qc:(Ljava/awt/Point;)D
        //   389: d2i            
        //   390: iload           10
        //   392: isub           
        //   393: aload           8
        //   395: invokestatic    q/o/m/s/q.qx:(Ljava/awt/Point;)D
        //   398: d2i            
        //   399: iload           10
        //   401: isub           
        //   402: invokestatic    q/o/m/s/q.qh:(Ljava/awt/Robot;II)V
        //   405: aload_2        
        //   406: ifnull          490
        //   409: aload_2        
        //   410: ifnull          470
        //   413: goto            420
        //   416: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   419: athrow         
        //   420: getstatic       a/a/p.G:Ljava/lang/Integer;
        //   423: ifnull          456
        //   426: goto            433
        //   429: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   432: athrow         
        //   433: getstatic       a/a/q.INSTANCE2:La/a/q;
        //   436: bipush          113
        //   438: iconst_0       
        //   439: getstatic       a/a/p.G:Ljava/lang/Integer;
        //   442: iconst_2       
        //   443: invokeinterface a/a/q.SystemParametersInfo:(IILjava/lang/Object;I)Z
        //   448: goto            455
        //   451: invokestatic    a/a/ae.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   454: athrow         
        //   455: pop            
        //   456: getstatic       a/a/p.z:I
        //   459: aload_2        
        //   460: ifnull          455
        //   463: i2l            
        //   464: invokestatic    q/o/m/s/q.mt:(J)V
        //   467: iinc            10, -1
        //   470: aload_2        
        //   471: ifnonnull       376
        //   474: goto            490
        //   477: astore_3       
        //   478: aload_3        
        //   479: invokestatic    q/o/m/s/q.mr:(Ljava/lang/InterruptedException;)V
        //   482: goto            490
        //   485: astore_3       
        //   486: aload_3        
        //   487: invokestatic    q/o/m/s/q.qj:(Ljava/awt/AWTException;)V
        //   490: return         
        //    StackMapTable: 00 39 FF 00 12 00 03 07 00 02 07 00 2E 07 00 1B 00 01 07 00 0F 03 00 46 01 46 07 00 28 43 01 45 07 00 28 03 4D 07 00 28 43 01 FF 00 32 00 07 07 00 02 07 00 2E 07 00 1B 01 01 01 01 00 01 07 00 28 03 44 07 00 28 FF 00 03 00 07 07 00 02 07 00 2E 07 00 1B 01 01 01 01 00 02 01 01 01 FF 00 06 00 07 07 00 02 07 00 2E 07 00 1B 01 01 01 01 00 02 01 01 49 07 00 28 03 45 07 00 28 FF 00 03 00 07 07 00 02 07 00 2E 07 00 1B 01 01 01 01 00 02 01 01 40 01 01 FF 00 39 00 0A 07 00 02 07 00 2E 07 00 1B 01 01 01 01 07 00 47 07 00 47 07 00 53 00 01 07 00 28 03 40 01 FC 00 01 01 67 07 00 28 03 48 07 00 28 03 51 07 00 28 43 01 00 0D 03 FA 00 03 47 07 00 28 43 01 43 01 46 07 00 28 43 01 45 07 00 28 03 40 01 FC 00 01 01 67 07 00 28 03 48 07 00 28 03 51 07 00 28 43 01 00 0D FF 00 03 00 03 07 00 02 07 00 2E 07 00 1B 00 00 42 07 00 28 47 07 00 2A 04
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  4      15     18     22     Ljava/lang/RuntimeException;
        //  4      22     477    485    Ljava/lang/InterruptedException;
        //  420    448    451    455    Ljava/lang/InterruptedException;
        //  409    426    429    433    Ljava/lang/InterruptedException;
        //  382    413    416    420    Ljava/lang/InterruptedException;
        //  352    366    369    373    Ljava/lang/InterruptedException;
        //  348    356    359    363    Ljava/lang/InterruptedException;
        //  332    341    344    348    Ljava/lang/InterruptedException;
        //  278    306    309    313    Ljava/lang/InterruptedException;
        //  267    284    287    291    Ljava/lang/InterruptedException;
        //  240    271    274    278    Ljava/lang/InterruptedException;
        //  217    224    227    231    Ljava/lang/InterruptedException;
        //  146    159    162    166    Ljava/lang/InterruptedException;
        //  142    149    152    156    Ljava/lang/InterruptedException;
        //  114    126    129    133    Ljava/lang/InterruptedException;
        //  107    117    120    124    Ljava/lang/InterruptedException;
        //  41     62     65     69     Ljava/lang/InterruptedException;
        //  30     44     47     51     Ljava/lang/InterruptedException;
        //  23     34     37     41     Ljava/lang/InterruptedException;
        //  23     474    477    485    Ljava/lang/InterruptedException;
        //  4      22     485    490    Ljava/awt/AWTException;
        //  23     474    485    490    Ljava/awt/AWTException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0030:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
}
