// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import javax.swing.JCheckBox;
import q.o.m.s.q;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class h implements ActionListener
{
    final ac a;
    
    h(final ac a) {
        this.a = a;
    }
    
    @Override
    public void actionPerformed(final ActionEvent actionEvent) {
        final String[] i = ac.i();
        ac a = null;
        boolean b3 = false;
        while (true) {
            Label_0098: {
                Label_0094: {
                    ac ac = null;
                    Label_0072: {
                        JCheckBox k = null;
                        Label_0047: {
                            Label_0028: {
                                boolean b;
                                try {
                                    final boolean b2;
                                    b = (b2 = q.u(a.a.ac.h(this.a)));
                                    if (i == null) {
                                        break Label_0072;
                                    }
                                    if (b) {
                                        break Label_0028;
                                    }
                                    break Label_0047;
                                }
                                catch (RuntimeException ex) {
                                    throw b(ex);
                                }
                                try {
                                    if (!b) {
                                        break Label_0047;
                                    }
                                    final JCheckBox j = a.a.ac.j(this.a);
                                }
                                catch (RuntimeException ex2) {
                                    throw b(ex2);
                                }
                            }
                            while (true) {
                                q.mg(k, false);
                                return;
                                try {
                                    ac = (a = this.a);
                                    if (i == null) {
                                        break Label_0098;
                                    }
                                    k = a.a.ac.j(ac);
                                    if (i == null) {
                                        continue;
                                    }
                                }
                                catch (RuntimeException ex3) {
                                    throw b(ex3);
                                }
                                break;
                            }
                        }
                        boolean b2 = q.u(k);
                        try {
                            if (!b2) {
                                break Label_0094;
                            }
                            final ac ac2 = this.a;
                        }
                        catch (RuntimeException ex4) {
                            throw b(ex4);
                        }
                    }
                    ac.a(b3);
                    if (i != null) {
                        return;
                    }
                }
                ac ac2;
                a = (ac2 = this.a);
            }
            b3 = false;
            if (i == null) {
                continue;
            }
            break;
        }
        a.a(b3);
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
}
