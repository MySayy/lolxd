// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import q.o.m.s.q;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class aa implements ActionListener
{
    final ac a;
    private static final String b;
    
    aa(final ac a) {
        this.a = a;
    }
    
    @Override
    public void actionPerformed(final ActionEvent actionEvent) {
        q.mj(ac.d(this.a), q.s(q.r(q.r(new StringBuilder(), aa.b), q.mh(q.mx(ac.ae)))));
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 115);
        final char[] g = q.g(n.d.a.d.q.p());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 113;
                            break;
                        }
                        case 1: {
                            n5 = 19;
                            break;
                        }
                        case 2: {
                            n5 = 84;
                            break;
                        }
                        case 3: {
                            n5 = 48;
                            break;
                        }
                        case 4: {
                            n5 = 24;
                            break;
                        }
                        case 5: {
                            n5 = 103;
                            break;
                        }
                        default: {
                            n5 = 65;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                b = q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
