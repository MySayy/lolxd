// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import org.jnativehook.mouse.NativeMouseEvent;
import java.awt.Color;
import org.jnativehook.keyboard.NativeKeyEvent;
import com.sun.jna.Structure;
import n.d.a.d.q;
import javax.swing.JTextField;
import java.util.HashMap;
import org.jnativehook.mouse.NativeMouseListener;
import org.jnativehook.keyboard.NativeKeyListener;

public class ap implements NativeKeyListener, NativeMouseListener
{
    private HashMap<String, Integer> e;
    private HashMap<String, Integer> i;
    private boolean j;
    private String d;
    private JTextField h;
    private boolean g;
    public int f;
    public int a;
    public int c;
    private int b;
    private static final String[] k;
    private static final String[] l;
    
    public ap() {
        final String[] i = ac.i();
        this.e = new HashMap<String, Integer>();
        this.i = new HashMap<String, Integer>();
        this.j = false;
        this.d = q.f();
        this.h = null;
        this.g = false;
        this.f = 1;
        this.a = 3;
        final String[] array = i;
        this.c = 8;
        this.b = this.a;
        q.o.m.s.q.qb(this.i, a(18747, 11517), q.o.m.s.q.te(4));
        q.o.m.s.q.qb(this.e, a(18745, 9303), q.o.m.s.q.te(18));
        q.o.m.s.q.qb(this.e, a(18748, 16929), q.o.m.s.q.te(20));
        if (array == null) {
            int a = Structure.a();
            Structure.b(++a);
        }
    }
    
    @Override
    public void nativeKeyPressed(final NativeKeyEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokevirtual   org/jnativehook/keyboard/NativeKeyEvent.getKeyCode:()I
        //     4: istore_3       
        //     5: invokestatic    a/a/ac.i:()[Ljava/lang/String;
        //     8: astore_2       
        //     9: iload_3        
        //    10: iconst_1       
        //    11: aload_2        
        //    12: ifnull          47
        //    15: if_icmpne       40
        //    18: goto            25
        //    21: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    24: athrow         
        //    25: iconst_0       
        //    26: putstatic       a/a/p.w:Z
        //    29: iconst_0       
        //    30: goto            37
        //    33: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    36: athrow         
        //    37: putstatic       a/a/p.g:Z
        //    40: iload_3        
        //    41: aload_2        
        //    42: ifnull          37
        //    45: bipush          28
        //    47: aload_2        
        //    48: ifnull          83
        //    51: if_icmpne       76
        //    54: goto            61
        //    57: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    60: athrow         
        //    61: iconst_0       
        //    62: putstatic       a/a/p.g:Z
        //    65: iconst_0       
        //    66: goto            73
        //    69: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    72: athrow         
        //    73: putstatic       a/a/p.w:Z
        //    76: iload_3        
        //    77: aload_2        
        //    78: ifnull          73
        //    81: bipush          53
        //    83: aload_2        
        //    84: ifnull          119
        //    87: if_icmpne       101
        //    90: goto            97
        //    93: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    96: athrow         
        //    97: iconst_1       
        //    98: putstatic       a/a/p.g:Z
        //   101: iload_3        
        //   102: aload_2        
        //   103: ifnull          98
        //   106: aload_2        
        //   107: ifnull          134
        //   110: bipush          17
        //   112: goto            119
        //   115: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   118: athrow         
        //   119: if_icmpne       126
        //   122: iconst_1       
        //   123: putstatic       a/a/p.t:Z
        //   126: aload_0        
        //   127: getfield        a/a/ap.g:Z
        //   130: aload_2        
        //   131: ifnull          123
        //   134: aload_2        
        //   135: ifnull          152
        //   138: ifeq            149
        //   141: goto            148
        //   144: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   147: athrow         
        //   148: return         
        //   149: getstatic       a/a/p.I:Z
        //   152: aload_2        
        //   153: ifnull          280
        //   156: ifeq            241
        //   159: goto            166
        //   162: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   165: athrow         
        //   166: invokestatic    a/a/p.c:()Z
        //   169: aload_2        
        //   170: ifnull          280
        //   173: ifeq            241
        //   176: iload_3        
        //   177: iconst_1       
        //   178: isub           
        //   179: goto            186
        //   182: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   185: athrow         
        //   186: aload_2        
        //   187: ifnull          280
        //   190: aload_0        
        //   191: getfield        a/a/ap.f:I
        //   194: if_icmpeq       241
        //   197: iconst_2       
        //   198: goto            205
        //   201: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   204: athrow         
        //   205: aload_2        
        //   206: ifnull          280
        //   209: iload_3        
        //   210: if_icmpgt       241
        //   213: iload_3        
        //   214: goto            221
        //   217: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   220: athrow         
        //   221: aload_2        
        //   222: ifnull          280
        //   225: bipush          10
        //   227: if_icmpgt       241
        //   230: aload_0        
        //   231: goto            238
        //   234: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   237: athrow         
        //   238: invokespecial   a/a/ap.b:()V
        //   241: aload_0        
        //   242: aload_2        
        //   243: ifnull          238
        //   246: aload_2        
        //   247: ifnull          398
        //   250: getfield        a/a/ap.j:Z
        //   253: aload_2        
        //   254: ifnull          169
        //   257: goto            264
        //   260: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   263: athrow         
        //   264: aload_2        
        //   265: ifnull          186
        //   268: aload_2        
        //   269: ifnull          205
        //   272: aload_2        
        //   273: ifnull          221
        //   276: aload_2        
        //   277: ifnull          305
        //   280: ifeq            397
        //   283: aload_1        
        //   284: aload_2        
        //   285: ifnull          352
        //   288: goto            295
        //   291: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   294: athrow         
        //   295: invokevirtual   org/jnativehook/keyboard/NativeKeyEvent.getKeyCode:()I
        //   298: goto            305
        //   301: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   304: athrow         
        //   305: iconst_1       
        //   306: if_icmpne       329
        //   309: aload_0        
        //   310: aload_0        
        //   311: getfield        a/a/ap.d:Ljava/lang/String;
        //   314: aload_0        
        //   315: getfield        a/a/ap.h:Ljavax/swing/JTextField;
        //   318: invokevirtual   a/a/ap.b:(Ljava/lang/String;Ljavax/swing/JTextField;)V
        //   321: goto            328
        //   324: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   327: athrow         
        //   328: return         
        //   329: aload_0        
        //   330: iconst_0       
        //   331: putfield        a/a/ap.j:Z
        //   334: aload_0        
        //   335: getfield        a/a/ap.e:Ljava/util/HashMap;
        //   338: aload_0        
        //   339: getfield        a/a/ap.d:Ljava/lang/String;
        //   342: aload_1        
        //   343: invokevirtual   org/jnativehook/keyboard/NativeKeyEvent.getKeyCode:()I
        //   346: invokestatic    q/o/m/s/q.te:(I)Ljava/lang/Integer;
        //   349: invokestatic    q/o/m/s/q.qb:(Ljava/util/HashMap;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   352: pop            
        //   353: aload_0        
        //   354: getfield        a/a/ap.h:Ljavax/swing/JTextField;
        //   357: aload_1        
        //   358: invokevirtual   org/jnativehook/keyboard/NativeKeyEvent.getKeyCode:()I
        //   361: invokestatic    org/jnativehook/keyboard/NativeKeyEvent.getKeyText:(I)Ljava/lang/String;
        //   364: invokestatic    q/o/m/s/q.vc:(Ljavax/swing/JTextField;Ljava/lang/String;)V
        //   367: aload_0        
        //   368: getfield        a/a/ap.h:Ljavax/swing/JTextField;
        //   371: getstatic       a/a/ac.ai:La/a/ac;
        //   374: getfield        a/a/ac.am:Ljava/awt/Color;
        //   377: invokestatic    q/o/m/s/q.tn:(Ljavax/swing/JTextField;Ljava/awt/Color;)V
        //   380: aload_0        
        //   381: invokestatic    n/d/a/d/q.f:()Ljava/lang/String;
        //   384: putfield        a/a/ap.d:Ljava/lang/String;
        //   387: aload_0        
        //   388: aconst_null    
        //   389: putfield        a/a/ap.h:Ljavax/swing/JTextField;
        //   392: aload_2        
        //   393: ifnull          328
        //   396: return         
        //   397: aload_0        
        //   398: getfield        a/a/ap.e:Ljava/util/HashMap;
        //   401: invokestatic    q/o/m/s/q.tp:(Ljava/util/HashMap;)Ljava/util/Set;
        //   404: invokestatic    q/o/m/s/q.ty:(Ljava/util/Set;)Ljava/util/Iterator;
        //   407: astore          4
        //   409: aload           4
        //   411: invokestatic    q/o/m/s/q.oi:(Ljava/util/Iterator;)Z
        //   414: ifeq            485
        //   417: aload           4
        //   419: invokestatic    q/o/m/s/q.ou:(Ljava/util/Iterator;)Ljava/lang/Object;
        //   422: checkcast       Ljava/lang/String;
        //   425: astore          5
        //   427: aload_0        
        //   428: aload_2        
        //   429: ifnull          476
        //   432: aload_2        
        //   433: ifnull          476
        //   436: goto            443
        //   439: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   442: athrow         
        //   443: getfield        a/a/ap.e:Ljava/util/HashMap;
        //   446: aload           5
        //   448: invokestatic    q/o/m/s/q.tc:(Ljava/util/HashMap;Ljava/lang/Object;)Ljava/lang/Object;
        //   451: checkcast       Ljava/lang/Integer;
        //   454: invokestatic    q/o/m/s/q.mm:(Ljava/lang/Integer;)I
        //   457: iload_3        
        //   458: if_icmpne       481
        //   461: goto            468
        //   464: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   467: athrow         
        //   468: aload_0        
        //   469: goto            476
        //   472: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   475: athrow         
        //   476: aload           5
        //   478: invokespecial   a/a/ap.a:(Ljava/lang/String;)V
        //   481: aload_2        
        //   482: ifnonnull       409
        //   485: return         
        //    StackMapTable: 00 3B FF 00 15 00 04 07 00 02 07 00 5C 07 00 60 01 00 01 07 00 5A 03 47 07 00 5A 43 01 02 FF 00 06 00 04 07 00 02 07 00 5C 07 00 60 01 00 02 01 01 49 07 00 5A 03 47 07 00 5A 43 01 02 FF 00 06 00 04 07 00 02 07 00 5C 07 00 60 01 00 02 01 01 49 07 00 5A 03 40 01 02 4D 07 00 5A FF 00 03 00 04 07 00 02 07 00 5C 07 00 60 01 00 02 01 01 43 01 02 47 01 49 07 00 5A 03 00 42 01 49 07 00 5A 03 42 01 4C 07 00 5A 43 01 4E 07 00 5A 43 01 4B 07 00 5A 43 01 4C 07 00 5A 43 07 00 02 02 52 07 00 5A 43 01 4F 01 4A 07 00 5A 43 07 00 5C 45 07 00 5A 43 01 52 07 00 5A 03 00 56 07 00 04 2C 40 07 00 02 FC 00 0A 07 00 94 FF 00 1D 00 06 07 00 02 07 00 5C 07 00 60 01 07 00 94 07 00 9E 00 01 07 00 5A 43 07 00 02 54 07 00 5A 03 43 07 00 5A 43 07 00 02 04 FA 00 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  9      18     21     25     Ljava/lang/RuntimeException;
        //  15     30     33     37     Ljava/lang/RuntimeException;
        //  47     54     57     61     Ljava/lang/RuntimeException;
        //  51     66     69     73     Ljava/lang/RuntimeException;
        //  83     90     93     97     Ljava/lang/RuntimeException;
        //  106    112    115    119    Ljava/lang/RuntimeException;
        //  134    141    144    148    Ljava/lang/RuntimeException;
        //  152    159    162    166    Ljava/lang/RuntimeException;
        //  173    179    182    186    Ljava/lang/RuntimeException;
        //  190    198    201    205    Ljava/lang/RuntimeException;
        //  209    214    217    221    Ljava/lang/RuntimeException;
        //  225    231    234    238    Ljava/lang/RuntimeException;
        //  246    257    260    264    Ljava/lang/RuntimeException;
        //  280    288    291    295    Ljava/lang/RuntimeException;
        //  283    298    301    305    Ljava/lang/RuntimeException;
        //  305    321    324    328    Ljava/lang/RuntimeException;
        //  427    436    439    443    Ljava/lang/RuntimeException;
        //  432    461    464    468    Ljava/lang/RuntimeException;
        //  443    469    472    476    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0443:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void a(final String d, final JTextField h) {
        this.j = true;
        q.o.m.s.q.tn(h, new Color(60, 200, 90));
        q.o.m.s.q.vc(h, a(18743, -20669));
        this.d = d;
        this.h = h;
    }
    
    public void b(final String s, final JTextField textField) {
        this.j = false;
        q.o.m.s.q.vc(textField, a(18744, -27110));
        q.o.m.s.q.tn(textField, ac.ai.am);
        q.o.m.s.q.tx(this.e, s);
        q.o.m.s.q.tx(this.i, s);
    }
    
    private void a(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_1        
        //     5: sipush          18749
        //     8: sipush          -27322
        //    11: invokestatic    a/a/ap.a:(II)Ljava/lang/String;
        //    14: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //    17: aload_2        
        //    18: ifnull          104
        //    21: ifeq            84
        //    24: goto            31
        //    27: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    30: athrow         
        //    31: getstatic       a/a/ac.ai:La/a/ac;
        //    34: getstatic       a/a/ac.ai:La/a/ac;
        //    37: invokevirtual   a/a/ac.isVisible:()Z
        //    40: aload_2        
        //    41: ifnull          73
        //    44: goto            51
        //    47: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    50: athrow         
        //    51: aload_2        
        //    52: ifnull          73
        //    55: goto            62
        //    58: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    61: athrow         
        //    62: ifne            76
        //    65: goto            72
        //    68: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    71: athrow         
        //    72: iconst_1       
        //    73: goto            77
        //    76: iconst_0       
        //    77: invokevirtual   a/a/ac.setVisible:(Z)V
        //    80: aload_2        
        //    81: ifnonnull       918
        //    84: aload_1        
        //    85: sipush          18741
        //    88: sipush          16673
        //    91: invokestatic    a/a/ap.a:(II)Ljava/lang/String;
        //    94: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //    97: goto            104
        //   100: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   103: athrow         
        //   104: aload_2        
        //   105: ifnull          217
        //   108: ifeq            193
        //   111: goto            118
        //   114: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   117: athrow         
        //   118: getstatic       a/a/p.o:Z
        //   121: aload_2        
        //   122: ifnull          140
        //   125: aload_2        
        //   126: ifnull          140
        //   129: ifne            143
        //   132: goto            139
        //   135: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   138: athrow         
        //   139: iconst_1       
        //   140: goto            144
        //   143: iconst_0       
        //   144: putstatic       a/a/p.o:Z
        //   147: getstatic       a/a/ac.aJ:Ljavax/swing/JCheckBox;
        //   150: getstatic       a/a/ac.aJ:Ljavax/swing/JCheckBox;
        //   153: invokestatic    q/o/m/s/q.u:(Ljavax/swing/JCheckBox;)Z
        //   156: aload_2        
        //   157: ifnull          182
        //   160: aload_2        
        //   161: ifnull          182
        //   164: goto            171
        //   167: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   170: athrow         
        //   171: ifne            185
        //   174: goto            181
        //   177: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   180: athrow         
        //   181: iconst_1       
        //   182: goto            186
        //   185: iconst_0       
        //   186: invokestatic    q/o/m/s/q.mg:(Ljavax/swing/JCheckBox;Z)V
        //   189: aload_2        
        //   190: ifnonnull       918
        //   193: aload_1        
        //   194: sipush          18751
        //   197: sipush          21642
        //   200: invokestatic    a/a/ap.a:(II)Ljava/lang/String;
        //   203: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   206: aload_2        
        //   207: ifnull          121
        //   210: goto            217
        //   213: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   216: athrow         
        //   217: aload_2        
        //   218: ifnull          330
        //   221: ifeq            306
        //   224: goto            231
        //   227: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   230: athrow         
        //   231: getstatic       a/a/p.h:Z
        //   234: aload_2        
        //   235: ifnull          253
        //   238: aload_2        
        //   239: ifnull          253
        //   242: ifne            256
        //   245: goto            252
        //   248: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   251: athrow         
        //   252: iconst_1       
        //   253: goto            257
        //   256: iconst_0       
        //   257: putstatic       a/a/p.h:Z
        //   260: getstatic       a/a/ac.d:Ljavax/swing/JCheckBox;
        //   263: getstatic       a/a/ac.d:Ljavax/swing/JCheckBox;
        //   266: invokestatic    q/o/m/s/q.u:(Ljavax/swing/JCheckBox;)Z
        //   269: aload_2        
        //   270: ifnull          295
        //   273: aload_2        
        //   274: ifnull          295
        //   277: goto            284
        //   280: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   283: athrow         
        //   284: ifne            298
        //   287: goto            294
        //   290: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   293: athrow         
        //   294: iconst_1       
        //   295: goto            299
        //   298: iconst_0       
        //   299: invokestatic    q/o/m/s/q.mg:(Ljavax/swing/JCheckBox;Z)V
        //   302: aload_2        
        //   303: ifnonnull       918
        //   306: aload_1        
        //   307: sipush          18737
        //   310: sipush          17573
        //   313: invokestatic    a/a/ap.a:(II)Ljava/lang/String;
        //   316: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   319: aload_2        
        //   320: ifnull          234
        //   323: goto            330
        //   326: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   329: athrow         
        //   330: aload_2        
        //   331: ifnull          443
        //   334: ifeq            419
        //   337: goto            344
        //   340: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   343: athrow         
        //   344: getstatic       a/a/p.A:Z
        //   347: aload_2        
        //   348: ifnull          366
        //   351: aload_2        
        //   352: ifnull          366
        //   355: ifne            369
        //   358: goto            365
        //   361: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   364: athrow         
        //   365: iconst_1       
        //   366: goto            370
        //   369: iconst_0       
        //   370: putstatic       a/a/p.A:Z
        //   373: getstatic       a/a/ac.ao:Ljavax/swing/JCheckBox;
        //   376: getstatic       a/a/ac.ao:Ljavax/swing/JCheckBox;
        //   379: invokestatic    q/o/m/s/q.u:(Ljavax/swing/JCheckBox;)Z
        //   382: aload_2        
        //   383: ifnull          408
        //   386: aload_2        
        //   387: ifnull          408
        //   390: goto            397
        //   393: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   396: athrow         
        //   397: ifne            411
        //   400: goto            407
        //   403: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   406: athrow         
        //   407: iconst_1       
        //   408: goto            412
        //   411: iconst_0       
        //   412: invokestatic    q/o/m/s/q.mg:(Ljavax/swing/JCheckBox;Z)V
        //   415: aload_2        
        //   416: ifnonnull       918
        //   419: aload_1        
        //   420: sipush          18742
        //   423: sipush          -1831
        //   426: invokestatic    a/a/ap.a:(II)Ljava/lang/String;
        //   429: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   432: aload_2        
        //   433: ifnull          347
        //   436: goto            443
        //   439: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   442: athrow         
        //   443: aload_2        
        //   444: ifnull          556
        //   447: ifeq            532
        //   450: goto            457
        //   453: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   456: athrow         
        //   457: getstatic       a/a/p.I:Z
        //   460: aload_2        
        //   461: ifnull          479
        //   464: aload_2        
        //   465: ifnull          479
        //   468: ifne            482
        //   471: goto            478
        //   474: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   477: athrow         
        //   478: iconst_1       
        //   479: goto            483
        //   482: iconst_0       
        //   483: putstatic       a/a/p.I:Z
        //   486: getstatic       a/a/ac.I:Ljavax/swing/JCheckBox;
        //   489: getstatic       a/a/ac.I:Ljavax/swing/JCheckBox;
        //   492: invokestatic    q/o/m/s/q.u:(Ljavax/swing/JCheckBox;)Z
        //   495: aload_2        
        //   496: ifnull          521
        //   499: aload_2        
        //   500: ifnull          521
        //   503: goto            510
        //   506: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   509: athrow         
        //   510: ifne            524
        //   513: goto            520
        //   516: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   519: athrow         
        //   520: iconst_1       
        //   521: goto            525
        //   524: iconst_0       
        //   525: invokestatic    q/o/m/s/q.mg:(Ljavax/swing/JCheckBox;Z)V
        //   528: aload_2        
        //   529: ifnonnull       918
        //   532: aload_1        
        //   533: sipush          18740
        //   536: sipush          32280
        //   539: invokestatic    a/a/ap.a:(II)Ljava/lang/String;
        //   542: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   545: aload_2        
        //   546: ifnull          460
        //   549: goto            556
        //   552: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   555: athrow         
        //   556: aload_2        
        //   557: ifnull          669
        //   560: ifeq            645
        //   563: goto            570
        //   566: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   569: athrow         
        //   570: getstatic       a/a/p.x:Z
        //   573: aload_2        
        //   574: ifnull          592
        //   577: aload_2        
        //   578: ifnull          592
        //   581: ifne            595
        //   584: goto            591
        //   587: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   590: athrow         
        //   591: iconst_1       
        //   592: goto            596
        //   595: iconst_0       
        //   596: putstatic       a/a/p.x:Z
        //   599: getstatic       a/a/ac.N:Ljavax/swing/JCheckBox;
        //   602: getstatic       a/a/ac.N:Ljavax/swing/JCheckBox;
        //   605: invokestatic    q/o/m/s/q.u:(Ljavax/swing/JCheckBox;)Z
        //   608: aload_2        
        //   609: ifnull          634
        //   612: aload_2        
        //   613: ifnull          634
        //   616: goto            623
        //   619: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   622: athrow         
        //   623: ifne            637
        //   626: goto            633
        //   629: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   632: athrow         
        //   633: iconst_1       
        //   634: goto            638
        //   637: iconst_0       
        //   638: invokestatic    q/o/m/s/q.mg:(Ljavax/swing/JCheckBox;Z)V
        //   641: aload_2        
        //   642: ifnonnull       918
        //   645: aload_1        
        //   646: sipush          18747
        //   649: sipush          11517
        //   652: invokestatic    a/a/ap.a:(II)Ljava/lang/String;
        //   655: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   658: aload_2        
        //   659: ifnull          573
        //   662: goto            669
        //   665: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   668: athrow         
        //   669: aload_2        
        //   670: ifnull          717
        //   673: ifeq            697
        //   676: goto            683
        //   679: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   682: athrow         
        //   683: invokestatic    a/a/ac.g:()V
        //   686: aload_2        
        //   687: ifnonnull       918
        //   690: goto            697
        //   693: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   696: athrow         
        //   697: aload_1        
        //   698: sipush          18750
        //   701: sipush          -11943
        //   704: invokestatic    a/a/ap.a:(II)Ljava/lang/String;
        //   707: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   710: goto            717
        //   713: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   716: athrow         
        //   717: aload_2        
        //   718: ifnull          766
        //   721: ifeq            746
        //   724: goto            731
        //   727: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   730: athrow         
        //   731: aload_0        
        //   732: invokespecial   a/a/ap.c:()V
        //   735: aload_2        
        //   736: ifnonnull       918
        //   739: goto            746
        //   742: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   745: athrow         
        //   746: aload_1        
        //   747: sipush          18745
        //   750: sipush          9303
        //   753: invokestatic    a/a/ap.a:(II)Ljava/lang/String;
        //   756: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   759: goto            766
        //   762: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   765: athrow         
        //   766: aload_2        
        //   767: ifnull          867
        //   770: ifeq            839
        //   773: goto            780
        //   776: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   779: athrow         
        //   780: invokestatic    a/a/p.c:()Z
        //   783: aload_2        
        //   784: ifnull          798
        //   787: ifne            791
        //   790: return         
        //   791: getstatic       a/a/p.w:Z
        //   794: aload_2        
        //   795: ifnull          820
        //   798: aload_2        
        //   799: ifnull          820
        //   802: goto            809
        //   805: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   808: athrow         
        //   809: ifne            823
        //   812: goto            819
        //   815: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   818: athrow         
        //   819: iconst_1       
        //   820: goto            824
        //   823: iconst_0       
        //   824: putstatic       a/a/p.w:Z
        //   827: aload_0        
        //   828: aload_0        
        //   829: getfield        a/a/ap.a:I
        //   832: putfield        a/a/ap.b:I
        //   835: aload_2        
        //   836: ifnonnull       918
        //   839: aload_1        
        //   840: sipush          18748
        //   843: sipush          16929
        //   846: invokestatic    a/a/ap.a:(II)Ljava/lang/String;
        //   849: invokestatic    q/o/m/s/q.th:(Ljava/lang/String;Ljava/lang/Object;)Z
        //   852: aload_2        
        //   853: ifnull          783
        //   856: goto            863
        //   859: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   862: athrow         
        //   863: aload_2        
        //   864: ifnull          891
        //   867: aload_2        
        //   868: ifnull          891
        //   871: goto            878
        //   874: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   877: athrow         
        //   878: ifeq            918
        //   881: goto            888
        //   884: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   887: athrow         
        //   888: invokestatic    a/a/p.c:()Z
        //   891: aload_2        
        //   892: ifnull          907
        //   895: ifne            906
        //   898: goto            905
        //   901: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   904: athrow         
        //   905: return         
        //   906: iconst_1       
        //   907: putstatic       a/a/p.g:Z
        //   910: aload_0        
        //   911: aload_0        
        //   912: getfield        a/a/ap.a:I
        //   915: putfield        a/a/ap.b:I
        //   918: return         
        //    StackMapTable: 00 8E FF 00 1B 00 03 07 00 02 07 00 9E 07 00 60 00 01 07 00 5A 03 4F 07 00 5A FF 00 03 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 22 01 46 07 00 5A FF 00 03 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 22 01 45 07 00 5A 43 07 00 22 FF 00 00 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 22 01 42 07 00 22 FF 00 00 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 22 01 06 4F 07 00 5A 43 01 49 07 00 5A 03 42 01 4D 07 00 5A 03 40 01 02 40 01 56 07 00 5A FF 00 03 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 45 07 00 5A 43 07 00 CB FF 00 00 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 42 07 00 CB FF 00 00 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 06 53 07 00 5A 43 01 49 07 00 5A 03 42 01 4D 07 00 5A 03 40 01 02 40 01 56 07 00 5A FF 00 03 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 45 07 00 5A 43 07 00 CB FF 00 00 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 42 07 00 CB FF 00 00 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 06 53 07 00 5A 43 01 49 07 00 5A 03 42 01 4D 07 00 5A 03 40 01 02 40 01 56 07 00 5A FF 00 03 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 45 07 00 5A 43 07 00 CB FF 00 00 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 42 07 00 CB FF 00 00 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 06 53 07 00 5A 43 01 49 07 00 5A 03 42 01 4D 07 00 5A 03 40 01 02 40 01 56 07 00 5A FF 00 03 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 45 07 00 5A 43 07 00 CB FF 00 00 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 42 07 00 CB FF 00 00 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 06 53 07 00 5A 43 01 49 07 00 5A 03 42 01 4D 07 00 5A 03 40 01 02 40 01 56 07 00 5A FF 00 03 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 45 07 00 5A 43 07 00 CB FF 00 00 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 42 07 00 CB FF 00 00 00 03 07 00 02 07 00 9E 07 00 60 00 02 07 00 CB 01 06 53 07 00 5A 43 01 49 07 00 5A 03 49 07 00 5A 03 4F 07 00 5A 43 01 49 07 00 5A 03 4A 07 00 5A 03 4F 07 00 5A 43 01 49 07 00 5A 03 42 01 07 46 01 46 07 00 5A 43 01 45 07 00 5A 03 40 01 02 40 01 0E 53 07 00 5A 43 01 43 01 46 07 00 5A 43 01 45 07 00 5A 03 42 01 49 07 00 5A 03 00 40 01 0A
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      24     27     31     Ljava/lang/RuntimeException;
        //  21     44     47     51     Ljava/lang/RuntimeException;
        //  31     55     58     62     Ljava/lang/RuntimeException;
        //  51     65     68     72     Ljava/lang/RuntimeException;
        //  77     97     100    104    Ljava/lang/RuntimeException;
        //  104    111    114    118    Ljava/lang/RuntimeException;
        //  125    132    135    139    Ljava/lang/RuntimeException;
        //  144    164    167    171    Ljava/lang/RuntimeException;
        //  160    174    177    181    Ljava/lang/RuntimeException;
        //  186    210    213    217    Ljava/lang/RuntimeException;
        //  217    224    227    231    Ljava/lang/RuntimeException;
        //  238    245    248    252    Ljava/lang/RuntimeException;
        //  257    277    280    284    Ljava/lang/RuntimeException;
        //  273    287    290    294    Ljava/lang/RuntimeException;
        //  299    323    326    330    Ljava/lang/RuntimeException;
        //  330    337    340    344    Ljava/lang/RuntimeException;
        //  351    358    361    365    Ljava/lang/RuntimeException;
        //  370    390    393    397    Ljava/lang/RuntimeException;
        //  386    400    403    407    Ljava/lang/RuntimeException;
        //  412    436    439    443    Ljava/lang/RuntimeException;
        //  443    450    453    457    Ljava/lang/RuntimeException;
        //  464    471    474    478    Ljava/lang/RuntimeException;
        //  483    503    506    510    Ljava/lang/RuntimeException;
        //  499    513    516    520    Ljava/lang/RuntimeException;
        //  525    549    552    556    Ljava/lang/RuntimeException;
        //  556    563    566    570    Ljava/lang/RuntimeException;
        //  577    584    587    591    Ljava/lang/RuntimeException;
        //  596    616    619    623    Ljava/lang/RuntimeException;
        //  612    626    629    633    Ljava/lang/RuntimeException;
        //  638    662    665    669    Ljava/lang/RuntimeException;
        //  669    676    679    683    Ljava/lang/RuntimeException;
        //  673    690    693    697    Ljava/lang/RuntimeException;
        //  683    710    713    717    Ljava/lang/RuntimeException;
        //  717    724    727    731    Ljava/lang/RuntimeException;
        //  721    739    742    746    Ljava/lang/RuntimeException;
        //  731    759    762    766    Ljava/lang/RuntimeException;
        //  766    773    776    780    Ljava/lang/RuntimeException;
        //  791    802    805    809    Ljava/lang/RuntimeException;
        //  798    812    815    819    Ljava/lang/RuntimeException;
        //  824    856    859    863    Ljava/lang/RuntimeException;
        //  863    871    874    878    Ljava/lang/RuntimeException;
        //  867    881    884    888    Ljava/lang/RuntimeException;
        //  891    898    901    905    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0031:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void b() {
        new az(this).start();
    }
    
    private int a() {
        return this.b = this.a;
    }
    
    private void c() {
        new ai(this).start();
    }
    
    @Override
    public void nativeKeyTyped(final NativeKeyEvent nativeKeyEvent) {
    }
    
    @Override
    public void nativeKeyReleased(final NativeKeyEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_1        
        //     5: invokevirtual   org/jnativehook/keyboard/NativeKeyEvent.getKeyCode:()I
        //     8: aload_2        
        //     9: ifnull          43
        //    12: aload_2        
        //    13: ifnull          43
        //    16: goto            23
        //    19: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    22: athrow         
        //    23: bipush          17
        //    25: if_icmpne       46
        //    28: goto            35
        //    31: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    34: athrow         
        //    35: iconst_0       
        //    36: goto            43
        //    39: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    42: athrow         
        //    43: putstatic       a/a/p.t:Z
        //    46: return         
        //    StackMapTable: 00 07 FF 00 13 00 01 07 00 02 00 01 07 00 5A 43 01 47 07 00 5A 03 43 07 00 5A 43 01 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      16     19     23     Ljava/lang/RuntimeException;
        //  12     28     31     35     Ljava/lang/RuntimeException;
        //  23     36     39     43     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0023:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void nativeMouseClicked(final NativeMouseEvent nativeMouseEvent) {
    }
    
    @Override
    public void nativeMousePressed(final NativeMouseEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: aload_1        
        //     5: invokevirtual   org/jnativehook/mouse/NativeMouseEvent.getButton:()I
        //     8: iconst_1       
        //     9: aload_2        
        //    10: ifnull          57
        //    13: aload_2        
        //    14: ifnull          57
        //    17: goto            24
        //    20: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    23: athrow         
        //    24: if_icmpeq       60
        //    27: goto            34
        //    30: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    33: athrow         
        //    34: aload_1        
        //    35: invokevirtual   org/jnativehook/mouse/NativeMouseEvent.getButton:()I
        //    38: aload_2        
        //    39: ifnull          76
        //    42: goto            49
        //    45: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    48: athrow         
        //    49: iconst_2       
        //    50: goto            57
        //    53: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    56: athrow         
        //    57: if_icmpne       61
        //    60: return         
        //    61: aload_0        
        //    62: aload_2        
        //    63: ifnull          173
        //    66: getfield        a/a/ap.j:Z
        //    69: goto            76
        //    72: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    75: athrow         
        //    76: ifeq            172
        //    79: aload_0        
        //    80: iconst_0       
        //    81: putfield        a/a/ap.j:Z
        //    84: aload_0        
        //    85: getfield        a/a/ap.i:Ljava/util/HashMap;
        //    88: aload_0        
        //    89: getfield        a/a/ap.d:Ljava/lang/String;
        //    92: aload_1        
        //    93: invokevirtual   org/jnativehook/mouse/NativeMouseEvent.getButton:()I
        //    96: invokestatic    q/o/m/s/q.te:(I)Ljava/lang/Integer;
        //    99: invokestatic    q/o/m/s/q.qb:(Ljava/util/HashMap;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   102: goto            109
        //   105: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   108: athrow         
        //   109: pop            
        //   110: aload_0        
        //   111: getfield        a/a/ap.h:Ljavax/swing/JTextField;
        //   114: new             Ljava/lang/StringBuilder;
        //   117: dup            
        //   118: invokespecial   java/lang/StringBuilder.<init>:()V
        //   121: sipush          18746
        //   124: sipush          -3248
        //   127: invokestatic    a/a/ap.a:(II)Ljava/lang/String;
        //   130: invokestatic    q/o/m/s/q.r:(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   133: aload_1        
        //   134: invokevirtual   org/jnativehook/mouse/NativeMouseEvent.getButton:()I
        //   137: invokestatic    q/o/m/s/q.qg:(Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
        //   140: invokestatic    q/o/m/s/q.s:(Ljava/lang/StringBuilder;)Ljava/lang/String;
        //   143: invokestatic    q/o/m/s/q.vc:(Ljavax/swing/JTextField;Ljava/lang/String;)V
        //   146: aload_0        
        //   147: getfield        a/a/ap.h:Ljavax/swing/JTextField;
        //   150: getstatic       a/a/ac.ai:La/a/ac;
        //   153: getfield        a/a/ac.am:Ljava/awt/Color;
        //   156: invokestatic    q/o/m/s/q.tn:(Ljavax/swing/JTextField;Ljava/awt/Color;)V
        //   159: aload_0        
        //   160: invokestatic    n/d/a/d/q.f:()Ljava/lang/String;
        //   163: putfield        a/a/ap.d:Ljava/lang/String;
        //   166: aload_0        
        //   167: aconst_null    
        //   168: putfield        a/a/ap.h:Ljavax/swing/JTextField;
        //   171: return         
        //   172: aload_0        
        //   173: getfield        a/a/ap.i:Ljava/util/HashMap;
        //   176: invokestatic    q/o/m/s/q.tp:(Ljava/util/HashMap;)Ljava/util/Set;
        //   179: invokestatic    q/o/m/s/q.ty:(Ljava/util/Set;)Ljava/util/Iterator;
        //   182: aload_2        
        //   183: ifnull          109
        //   186: astore_3       
        //   187: aload_3        
        //   188: invokestatic    q/o/m/s/q.oi:(Ljava/util/Iterator;)Z
        //   191: ifeq            264
        //   194: aload_3        
        //   195: invokestatic    q/o/m/s/q.ou:(Ljava/util/Iterator;)Ljava/lang/Object;
        //   198: checkcast       Ljava/lang/String;
        //   201: astore          4
        //   203: aload_0        
        //   204: aload_2        
        //   205: ifnull          255
        //   208: aload_2        
        //   209: ifnull          255
        //   212: goto            219
        //   215: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   218: athrow         
        //   219: getfield        a/a/ap.i:Ljava/util/HashMap;
        //   222: aload           4
        //   224: invokestatic    q/o/m/s/q.tc:(Ljava/util/HashMap;Ljava/lang/Object;)Ljava/lang/Object;
        //   227: checkcast       Ljava/lang/Integer;
        //   230: invokestatic    q/o/m/s/q.mm:(Ljava/lang/Integer;)I
        //   233: aload_1        
        //   234: invokevirtual   org/jnativehook/mouse/NativeMouseEvent.getButton:()I
        //   237: if_icmpne       260
        //   240: goto            247
        //   243: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   246: athrow         
        //   247: aload_0        
        //   248: goto            255
        //   251: invokestatic    a/a/ap.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //   254: athrow         
        //   255: aload           4
        //   257: invokespecial   a/a/ap.a:(Ljava/lang/String;)V
        //   260: aload_2        
        //   261: ifnonnull       187
        //   264: return         
        //    StackMapTable: 00 19 FF 00 14 00 03 07 00 02 07 00 F8 07 00 60 00 01 07 00 5A FF 00 03 00 03 07 00 02 07 00 F8 07 00 60 00 02 01 01 45 07 00 5A 03 4A 07 00 5A 43 01 43 07 00 5A FF 00 03 00 03 07 00 02 07 00 F8 07 00 60 00 02 01 01 02 00 4A 07 00 5A 43 01 5C 07 00 5A 43 07 00 04 3E 40 07 00 02 FC 00 0D 07 00 94 FF 00 1B 00 05 07 00 02 07 00 F8 07 00 60 07 00 94 07 00 9E 00 01 07 00 5A 43 07 00 02 57 07 00 5A 03 43 07 00 5A 43 07 00 02 04 FA 00 03
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      17     20     24     Ljava/lang/RuntimeException;
        //  13     27     30     34     Ljava/lang/RuntimeException;
        //  24     42     45     49     Ljava/lang/RuntimeException;
        //  34     50     53     57     Ljava/lang/RuntimeException;
        //  61     69     72     76     Ljava/lang/RuntimeException;
        //  76     102    105    109    Ljava/lang/RuntimeException;
        //  203    212    215    219    Ljava/lang/RuntimeException;
        //  208    240    243    247    Ljava/lang/RuntimeException;
        //  219    248    251    255    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0024:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void nativeMouseReleased(final NativeMouseEvent nativeMouseEvent) {
    }
    
    static boolean a(final ap ap, final boolean g) {
        return ap.g = g;
    }
    
    static int a(final ap ap) {
        return ap.b;
    }
    
    static int c(final ap ap) {
        return ap.b++;
    }
    
    static int b(final ap ap) {
        return ap.a();
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
    
    static {
        final String[] i = new String[13];
        int n = 0;
        String s;
        int n2 = q.o.m.s.q.q(s = q.a());
        int n3 = 4;
        int n4 = -1;
    Label_0023:
        while (true) {
            while (true) {
                int n8;
                int n7;
                int n6;
                int n5 = n6 = (n7 = (n8 = 97));
                ++n4;
                final String s2 = s;
                final int n9 = n4;
                String s3 = q.o.m.s.q.h(s2, n9, n9 + n3);
                int n10 = -1;
                while (true) {
                    final char[] g = q.o.m.s.q.g(s3);
                    final int length = g.length;
                    int n11 = 0;
                    while (true) {
                        Label_0260: {
                            if (length > 1) {
                                break Label_0260;
                            }
                            n7 = (n6 = n11);
                            do {
                                final char c = g[n6];
                                int n12 = 0;
                                switch (n11 % 7) {
                                    case 0: {
                                        n12 = 50;
                                        break;
                                    }
                                    case 1: {
                                        n12 = 116;
                                        break;
                                    }
                                    case 2: {
                                        n12 = 115;
                                        break;
                                    }
                                    case 3: {
                                        n12 = 91;
                                        break;
                                    }
                                    case 4: {
                                        n12 = 67;
                                        break;
                                    }
                                    case 5: {
                                        n12 = 59;
                                        break;
                                    }
                                    default: {
                                        n12 = 122;
                                        break;
                                    }
                                }
                                g[n7] = (char)(c ^ (n5 ^ n12));
                                ++n11;
                            } while (n8 == 0);
                        }
                        if (length > n11) {
                            continue;
                        }
                        break;
                    }
                    final String z = q.o.m.s.q.z(new String(g));
                    switch (n10) {
                        default: {
                            i[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.o.m.s.q.j(s, n4);
                                continue Label_0023;
                            }
                            n2 = q.o.m.s.q.q(s = q.l());
                            n3 = 7;
                            n4 = -1;
                            break;
                        }
                        case 0: {
                            i[n++] = z;
                            if ((n4 += n3) < n2) {
                                n3 = q.o.m.s.q.j(s, n4);
                                break;
                            }
                            break Label_0023;
                        }
                    }
                    n5 = (n6 = (n7 = (n8 = 26)));
                    ++n4;
                    final String s4 = s;
                    final int n13 = n4;
                    s3 = q.o.m.s.q.h(s4, n13, n13 + n3);
                    n10 = 0;
                }
            }
            break;
        }
        k = i;
        l = new String[13];
    }
    
    private static String a(final int n, final int n2) {
        final int n3 = (n ^ 0x493D) & 0xFFFF;
        if (ap.l[n3] == null) {
            final char[] g = q.o.m.s.q.g(ap.k[n3]);
            int n4 = 0;
            switch (g[0] & '\u00ff') {
                case 0: {
                    n4 = 153;
                    break;
                }
                case 1: {
                    n4 = 155;
                    break;
                }
                case 2: {
                    n4 = 144;
                    break;
                }
                case 3: {
                    n4 = 101;
                    break;
                }
                case 4: {
                    n4 = 19;
                    break;
                }
                case 5: {
                    n4 = 123;
                    break;
                }
                case 6: {
                    n4 = 61;
                    break;
                }
                case 7: {
                    n4 = 56;
                    break;
                }
                case 8: {
                    n4 = 42;
                    break;
                }
                case 9: {
                    n4 = 113;
                    break;
                }
                case 10: {
                    n4 = 174;
                    break;
                }
                case 11: {
                    n4 = 149;
                    break;
                }
                case 12: {
                    n4 = 255;
                    break;
                }
                case 13: {
                    n4 = 31;
                    break;
                }
                case 14: {
                    n4 = 240;
                    break;
                }
                case 15: {
                    n4 = 24;
                    break;
                }
                case 16: {
                    n4 = 109;
                    break;
                }
                case 17: {
                    n4 = 55;
                    break;
                }
                case 18: {
                    n4 = 121;
                    break;
                }
                case 19: {
                    n4 = 76;
                    break;
                }
                case 20: {
                    n4 = 176;
                    break;
                }
                case 21: {
                    n4 = 147;
                    break;
                }
                case 22: {
                    n4 = 246;
                    break;
                }
                case 23: {
                    n4 = 110;
                    break;
                }
                case 24: {
                    n4 = 62;
                    break;
                }
                case 25: {
                    n4 = 43;
                    break;
                }
                case 26: {
                    n4 = 36;
                    break;
                }
                case 27: {
                    n4 = 28;
                    break;
                }
                case 28: {
                    n4 = 88;
                    break;
                }
                case 29: {
                    n4 = 208;
                    break;
                }
                case 30: {
                    n4 = 194;
                    break;
                }
                case 31: {
                    n4 = 236;
                    break;
                }
                case 32: {
                    n4 = 135;
                    break;
                }
                case 33: {
                    n4 = 126;
                    break;
                }
                case 34: {
                    n4 = 181;
                    break;
                }
                case 35: {
                    n4 = 216;
                    break;
                }
                case 36: {
                    n4 = 160;
                    break;
                }
                case 37: {
                    n4 = 14;
                    break;
                }
                case 38: {
                    n4 = 35;
                    break;
                }
                case 39: {
                    n4 = 182;
                    break;
                }
                case 40: {
                    n4 = 53;
                    break;
                }
                case 41: {
                    n4 = 68;
                    break;
                }
                case 42: {
                    n4 = 77;
                    break;
                }
                case 43: {
                    n4 = 129;
                    break;
                }
                case 44: {
                    n4 = 247;
                    break;
                }
                case 45: {
                    n4 = 86;
                    break;
                }
                case 46: {
                    n4 = 132;
                    break;
                }
                case 47: {
                    n4 = 211;
                    break;
                }
                case 48: {
                    n4 = 18;
                    break;
                }
                case 49: {
                    n4 = 137;
                    break;
                }
                case 50: {
                    n4 = 21;
                    break;
                }
                case 51: {
                    n4 = 148;
                    break;
                }
                case 52: {
                    n4 = 4;
                    break;
                }
                case 53: {
                    n4 = 85;
                    break;
                }
                case 54: {
                    n4 = 248;
                    break;
                }
                case 55: {
                    n4 = 139;
                    break;
                }
                case 56: {
                    n4 = 34;
                    break;
                }
                case 57: {
                    n4 = 156;
                    break;
                }
                case 58: {
                    n4 = 185;
                    break;
                }
                case 59: {
                    n4 = 234;
                    break;
                }
                case 60: {
                    n4 = 206;
                    break;
                }
                case 61: {
                    n4 = 38;
                    break;
                }
                case 62: {
                    n4 = 64;
                    break;
                }
                case 63: {
                    n4 = 143;
                    break;
                }
                case 64: {
                    n4 = 92;
                    break;
                }
                case 65: {
                    n4 = 193;
                    break;
                }
                case 66: {
                    n4 = 112;
                    break;
                }
                case 67: {
                    n4 = 150;
                    break;
                }
                case 68: {
                    n4 = 125;
                    break;
                }
                case 69: {
                    n4 = 119;
                    break;
                }
                case 70: {
                    n4 = 59;
                    break;
                }
                case 71: {
                    n4 = 175;
                    break;
                }
                case 72: {
                    n4 = 100;
                    break;
                }
                case 73: {
                    n4 = 242;
                    break;
                }
                case 74: {
                    n4 = 217;
                    break;
                }
                case 75: {
                    n4 = 73;
                    break;
                }
                case 76: {
                    n4 = 214;
                    break;
                }
                case 77: {
                    n4 = 118;
                    break;
                }
                case 78: {
                    n4 = 146;
                    break;
                }
                case 79: {
                    n4 = 179;
                    break;
                }
                case 80: {
                    n4 = 154;
                    break;
                }
                case 81: {
                    n4 = 232;
                    break;
                }
                case 82: {
                    n4 = 157;
                    break;
                }
                case 83: {
                    n4 = 199;
                    break;
                }
                case 84: {
                    n4 = 204;
                    break;
                }
                case 85: {
                    n4 = 128;
                    break;
                }
                case 86: {
                    n4 = 249;
                    break;
                }
                case 87: {
                    n4 = 46;
                    break;
                }
                case 88: {
                    n4 = 191;
                    break;
                }
                case 89: {
                    n4 = 221;
                    break;
                }
                case 90: {
                    n4 = 239;
                    break;
                }
                case 91: {
                    n4 = 89;
                    break;
                }
                case 92: {
                    n4 = 186;
                    break;
                }
                case 93: {
                    n4 = 25;
                    break;
                }
                case 94: {
                    n4 = 207;
                    break;
                }
                case 95: {
                    n4 = 180;
                    break;
                }
                case 96: {
                    n4 = 220;
                    break;
                }
                case 97: {
                    n4 = 72;
                    break;
                }
                case 98: {
                    n4 = 82;
                    break;
                }
                case 99: {
                    n4 = 6;
                    break;
                }
                case 100: {
                    n4 = 84;
                    break;
                }
                case 101: {
                    n4 = 224;
                    break;
                }
                case 102: {
                    n4 = 235;
                    break;
                }
                case 103: {
                    n4 = 10;
                    break;
                }
                case 104: {
                    n4 = 30;
                    break;
                }
                case 105: {
                    n4 = 108;
                    break;
                }
                case 106: {
                    n4 = 188;
                    break;
                }
                case 107: {
                    n4 = 131;
                    break;
                }
                case 108: {
                    n4 = 63;
                    break;
                }
                case 109: {
                    n4 = 79;
                    break;
                }
                case 110: {
                    n4 = 13;
                    break;
                }
                case 111: {
                    n4 = 44;
                    break;
                }
                case 112: {
                    n4 = 7;
                    break;
                }
                case 113: {
                    n4 = 83;
                    break;
                }
                case 114: {
                    n4 = 252;
                    break;
                }
                case 115: {
                    n4 = 22;
                    break;
                }
                case 116: {
                    n4 = 219;
                    break;
                }
                case 117: {
                    n4 = 200;
                    break;
                }
                case 118: {
                    n4 = 32;
                    break;
                }
                case 119: {
                    n4 = 213;
                    break;
                }
                case 120: {
                    n4 = 96;
                    break;
                }
                case 121: {
                    n4 = 237;
                    break;
                }
                case 122: {
                    n4 = 51;
                    break;
                }
                case 123: {
                    n4 = 241;
                    break;
                }
                case 124: {
                    n4 = 87;
                    break;
                }
                case 125: {
                    n4 = 52;
                    break;
                }
                case 126: {
                    n4 = 0;
                    break;
                }
                case 127: {
                    n4 = 196;
                    break;
                }
                case 128: {
                    n4 = 49;
                    break;
                }
                case 129: {
                    n4 = 65;
                    break;
                }
                case 130: {
                    n4 = 11;
                    break;
                }
                case 131: {
                    n4 = 164;
                    break;
                }
                case 132: {
                    n4 = 33;
                    break;
                }
                case 133: {
                    n4 = 254;
                    break;
                }
                case 134: {
                    n4 = 122;
                    break;
                }
                case 135: {
                    n4 = 37;
                    break;
                }
                case 136: {
                    n4 = 26;
                    break;
                }
                case 137: {
                    n4 = 203;
                    break;
                }
                case 138: {
                    n4 = 163;
                    break;
                }
                case 139: {
                    n4 = 1;
                    break;
                }
                case 140: {
                    n4 = 29;
                    break;
                }
                case 141: {
                    n4 = 111;
                    break;
                }
                case 142: {
                    n4 = 189;
                    break;
                }
                case 143: {
                    n4 = 140;
                    break;
                }
                case 144: {
                    n4 = 50;
                    break;
                }
                case 145: {
                    n4 = 183;
                    break;
                }
                case 146: {
                    n4 = 48;
                    break;
                }
                case 147: {
                    n4 = 2;
                    break;
                }
                case 148: {
                    n4 = 57;
                    break;
                }
                case 149: {
                    n4 = 91;
                    break;
                }
                case 150: {
                    n4 = 58;
                    break;
                }
                case 151: {
                    n4 = 80;
                    break;
                }
                case 152: {
                    n4 = 190;
                    break;
                }
                case 153: {
                    n4 = 106;
                    break;
                }
                case 154: {
                    n4 = 184;
                    break;
                }
                case 155: {
                    n4 = 27;
                    break;
                }
                case 156: {
                    n4 = 218;
                    break;
                }
                case 157: {
                    n4 = 253;
                    break;
                }
                case 158: {
                    n4 = 171;
                    break;
                }
                case 159: {
                    n4 = 130;
                    break;
                }
                case 160: {
                    n4 = 197;
                    break;
                }
                case 161: {
                    n4 = 9;
                    break;
                }
                case 162: {
                    n4 = 170;
                    break;
                }
                case 163: {
                    n4 = 104;
                    break;
                }
                case 164: {
                    n4 = 47;
                    break;
                }
                case 165: {
                    n4 = 165;
                    break;
                }
                case 166: {
                    n4 = 202;
                    break;
                }
                case 167: {
                    n4 = 187;
                    break;
                }
                case 168: {
                    n4 = 223;
                    break;
                }
                case 169: {
                    n4 = 97;
                    break;
                }
                case 170: {
                    n4 = 78;
                    break;
                }
                case 171: {
                    n4 = 230;
                    break;
                }
                case 172: {
                    n4 = 66;
                    break;
                }
                case 173: {
                    n4 = 8;
                    break;
                }
                case 174: {
                    n4 = 158;
                    break;
                }
                case 175: {
                    n4 = 93;
                    break;
                }
                case 176: {
                    n4 = 70;
                    break;
                }
                case 177: {
                    n4 = 210;
                    break;
                }
                case 178: {
                    n4 = 20;
                    break;
                }
                case 179: {
                    n4 = 172;
                    break;
                }
                case 180: {
                    n4 = 205;
                    break;
                }
                case 181: {
                    n4 = 178;
                    break;
                }
                case 182: {
                    n4 = 222;
                    break;
                }
                case 183: {
                    n4 = 117;
                    break;
                }
                case 184: {
                    n4 = 229;
                    break;
                }
                case 185: {
                    n4 = 54;
                    break;
                }
                case 186: {
                    n4 = 45;
                    break;
                }
                case 187: {
                    n4 = 167;
                    break;
                }
                case 188: {
                    n4 = 74;
                    break;
                }
                case 189: {
                    n4 = 136;
                    break;
                }
                case 190: {
                    n4 = 120;
                    break;
                }
                case 191: {
                    n4 = 201;
                    break;
                }
                case 192: {
                    n4 = 228;
                    break;
                }
                case 193: {
                    n4 = 145;
                    break;
                }
                case 194: {
                    n4 = 233;
                    break;
                }
                case 195: {
                    n4 = 134;
                    break;
                }
                case 196: {
                    n4 = 107;
                    break;
                }
                case 197: {
                    n4 = 114;
                    break;
                }
                case 198: {
                    n4 = 103;
                    break;
                }
                case 199: {
                    n4 = 115;
                    break;
                }
                case 200: {
                    n4 = 159;
                    break;
                }
                case 201: {
                    n4 = 168;
                    break;
                }
                case 202: {
                    n4 = 169;
                    break;
                }
                case 203: {
                    n4 = 3;
                    break;
                }
                case 204: {
                    n4 = 251;
                    break;
                }
                case 205: {
                    n4 = 127;
                    break;
                }
                case 206: {
                    n4 = 102;
                    break;
                }
                case 207: {
                    n4 = 243;
                    break;
                }
                case 208: {
                    n4 = 225;
                    break;
                }
                case 209: {
                    n4 = 60;
                    break;
                }
                case 210: {
                    n4 = 209;
                    break;
                }
                case 211: {
                    n4 = 16;
                    break;
                }
                case 212: {
                    n4 = 231;
                    break;
                }
                case 213: {
                    n4 = 95;
                    break;
                }
                case 214: {
                    n4 = 173;
                    break;
                }
                case 215: {
                    n4 = 250;
                    break;
                }
                case 216: {
                    n4 = 23;
                    break;
                }
                case 217: {
                    n4 = 41;
                    break;
                }
                case 218: {
                    n4 = 39;
                    break;
                }
                case 219: {
                    n4 = 192;
                    break;
                }
                case 220: {
                    n4 = 94;
                    break;
                }
                case 221: {
                    n4 = 212;
                    break;
                }
                case 222: {
                    n4 = 99;
                    break;
                }
                case 223: {
                    n4 = 17;
                    break;
                }
                case 224: {
                    n4 = 5;
                    break;
                }
                case 225: {
                    n4 = 215;
                    break;
                }
                case 226: {
                    n4 = 138;
                    break;
                }
                case 227: {
                    n4 = 152;
                    break;
                }
                case 228: {
                    n4 = 177;
                    break;
                }
                case 229: {
                    n4 = 98;
                    break;
                }
                case 230: {
                    n4 = 245;
                    break;
                }
                case 231: {
                    n4 = 133;
                    break;
                }
                case 232: {
                    n4 = 105;
                    break;
                }
                case 233: {
                    n4 = 90;
                    break;
                }
                case 234: {
                    n4 = 198;
                    break;
                }
                case 235: {
                    n4 = 195;
                    break;
                }
                case 236: {
                    n4 = 162;
                    break;
                }
                case 237: {
                    n4 = 71;
                    break;
                }
                case 238: {
                    n4 = 151;
                    break;
                }
                case 239: {
                    n4 = 67;
                    break;
                }
                case 240: {
                    n4 = 238;
                    break;
                }
                case 241: {
                    n4 = 69;
                    break;
                }
                case 242: {
                    n4 = 141;
                    break;
                }
                case 243: {
                    n4 = 124;
                    break;
                }
                case 244: {
                    n4 = 81;
                    break;
                }
                case 245: {
                    n4 = 166;
                    break;
                }
                case 246: {
                    n4 = 75;
                    break;
                }
                case 247: {
                    n4 = 244;
                    break;
                }
                case 248: {
                    n4 = 161;
                    break;
                }
                case 249: {
                    n4 = 116;
                    break;
                }
                case 250: {
                    n4 = 226;
                    break;
                }
                case 251: {
                    n4 = 15;
                    break;
                }
                case 252: {
                    n4 = 227;
                    break;
                }
                case 253: {
                    n4 = 12;
                    break;
                }
                case 254: {
                    n4 = 142;
                    break;
                }
                default: {
                    n4 = 40;
                    break;
                }
            }
            final int n5 = n4;
            int n6 = (n2 & 0xFF) - n5;
            if (n6 < '\0') {
                n6 += '\u0100';
            }
            int n7 = ((n2 & 0xFFFF) >>> 8) - n5;
            if (n7 < '\0') {
                n7 += '\u0100';
            }
            for (int i = 0; i < g.length; ++i) {
                final int n8 = i % 2;
                final char[] array = g;
                final int n9 = i;
                final char c = array[n9];
                if (n8 == 0) {
                    array[n9] = (char)(c ^ n6);
                    n6 = (((n6 >>> 3 | n6 << 5) ^ g[i]) & 0xFF);
                }
                else {
                    array[n9] = (char)(c ^ n7);
                    n7 = (((n7 >>> 3 | n7 << 5) ^ g[i]) & 0xFF);
                }
            }
            ap.l[n3] = q.o.m.s.q.z(new String(g));
        }
        return ap.l[n3];
    }
}
