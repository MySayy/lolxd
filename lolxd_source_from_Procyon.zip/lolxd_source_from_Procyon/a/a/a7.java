// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import org.jnativehook.NativeHookException;
import org.jnativehook.GlobalScreen;

final class a7 implements Runnable
{
    @Override
    public void run() {
        try {
            GlobalScreen.unregisterNativeHook();
        }
        catch (NativeHookException ex) {
            ex.printStackTrace();
        }
    }
}
