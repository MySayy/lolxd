// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import java.awt.Graphics;
import javax.swing.JSlider;
import javax.swing.plaf.basic.BasicSliderUI;

public class al extends BasicSliderUI
{
    public al(final JSlider b) {
        super(b);
    }
    
    @Override
    public void paintFocus(final Graphics graphics) {
    }
}
