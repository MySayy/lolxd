// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import n.d.a.d.q;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

class as implements MouseListener
{
    final ac a;
    private static final String b;
    
    as(final ac a) {
        this.a = a;
    }
    
    @Override
    public void mouseClicked(final MouseEvent mouseEvent) {
    }
    
    @Override
    public void mousePressed(final MouseEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_2       
        //     4: getstatic       a/a/p.a:La/a/ap;
        //     7: getstatic       a/a/as.b:Ljava/lang/String;
        //    10: invokestatic    a/a/ac.n:()Ljavax/swing/JTextField;
        //    13: aload_2        
        //    14: ifnull          62
        //    17: aload_2        
        //    18: ifnull          62
        //    21: goto            28
        //    24: invokestatic    a/a/as.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    27: athrow         
        //    28: invokevirtual   a/a/ap.a:(Ljava/lang/String;Ljavax/swing/JTextField;)V
        //    31: aload_1        
        //    32: invokestatic    q/o/m/s/q.mq:(Ljava/awt/event/MouseEvent;)I
        //    35: iconst_3       
        //    36: if_icmpne       65
        //    39: goto            46
        //    42: invokestatic    a/a/as.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    45: athrow         
        //    46: getstatic       a/a/p.a:La/a/ap;
        //    49: getstatic       a/a/as.b:Ljava/lang/String;
        //    52: invokestatic    a/a/ac.n:()Ljavax/swing/JTextField;
        //    55: goto            62
        //    58: invokestatic    a/a/as.b:(Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
        //    61: athrow         
        //    62: invokevirtual   a/a/ap.b:(Ljava/lang/String;Ljavax/swing/JTextField;)V
        //    65: return         
        //    StackMapTable: 00 07 FF 00 18 00 01 07 00 02 00 01 07 00 17 FF 00 03 00 02 07 00 02 07 00 2D 00 03 07 00 2F 07 00 31 07 00 33 FF 00 0D 00 01 07 00 02 00 01 07 00 17 03 4B 07 00 17 FF 00 03 00 01 07 00 02 00 03 07 00 2F 07 00 31 07 00 33 02
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  4      21     24     28     Ljava/lang/RuntimeException;
        //  17     39     42     46     Ljava/lang/RuntimeException;
        //  28     55     58     62     Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0028:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void mouseReleased(final MouseEvent mouseEvent) {
    }
    
    @Override
    public void mouseEntered(final MouseEvent mouseEvent) {
    }
    
    @Override
    public void mouseExited(final MouseEvent mouseEvent) {
    }
    
    private static RuntimeException b(final RuntimeException ex) {
        return ex;
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 88);
        final char[] g = q.o.m.s.q.g(q.u());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0127: {
                if (length > 1) {
                    break Label_0127;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 92;
                            break;
                        }
                        case 1: {
                            n5 = 54;
                            break;
                        }
                        case 2: {
                            n5 = 1;
                            break;
                        }
                        case 3: {
                            n5 = 44;
                            break;
                        }
                        case 4: {
                            n5 = 20;
                            break;
                        }
                        case 5: {
                            n5 = 125;
                            break;
                        }
                        default: {
                            n5 = 93;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                b = q.o.m.s.q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
