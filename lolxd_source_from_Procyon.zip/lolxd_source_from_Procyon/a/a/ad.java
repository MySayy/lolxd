// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import q.o.m.s.q;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

class ad implements ChangeListener
{
    final ac a;
    
    ad(final ac a) {
        this.a = a;
    }
    
    @Override
    public void stateChanged(final ChangeEvent changeEvent) {
        final int mv = q.mv(ac.u(this.a));
        this.a.aB = mv;
        ac.k(this.a).a = mv;
    }
}
