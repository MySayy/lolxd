// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import java.awt.Component;
import q.o.m.s.q;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class m implements ActionListener
{
    final ac a;
    
    m(final ac a) {
        this.a = a;
    }
    
    @Override
    public void actionPerformed(final ActionEvent actionEvent) {
        q.tk(ac.aP, ac.i(this.a));
    }
}
