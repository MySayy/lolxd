// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;

class bb extends WindowAdapter
{
    final av a;
    
    bb(final av a) {
        this.a = a;
    }
    
    @Override
    public void windowGainedFocus(final WindowEvent windowEvent) {
        ac.H = true;
    }
    
    @Override
    public void windowLostFocus(final WindowEvent windowEvent) {
        ac.H = false;
    }
}
