// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import java.awt.AWTException;
import q.o.m.s.q;
import java.awt.Robot;

class ai extends Thread
{
    final ap a;
    
    ai(final ap a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        final String[] i = ac.i();
        try {
            boolean b2 = false;
            Label_0043: {
                Label_0040: {
                    Label_0025: {
                        boolean b = false;
                        Label_0022: {
                            try {
                                b = (b2 = p.c());
                                if (i == null) {
                                    break Label_0025;
                                }
                                if (b) {
                                    break Label_0022;
                                }
                            }
                            catch (RuntimeException ex) {
                                throw b(ex);
                            }
                            return;
                        }
                        final boolean w;
                        b2 = (w = p.w);
                        try {
                            if (i == null) {
                                break Label_0043;
                            }
                            if (!b) {
                                break Label_0040;
                            }
                        }
                        catch (InterruptedException ex2) {
                            throw b(ex2);
                        }
                    }
                    return;
                }
                b2 = p.g;
            }
            if (b2) {
                return;
            }
            final Robot robot = new Robot();
            int n = 49;
            Label_0477: {
                while (true) {
                    Label_0466: {
                        Label_0444: {
                            int n10;
                            while (true) {
                                Label_0351: {
                                    Label_0334: {
                                        int n9;
                                        while (true) {
                                            Label_0321: {
                                                Label_0300: {
                                                    int n8;
                                                    while (true) {
                                                        Label_0287: {
                                                            Label_0266: {
                                                                int n7;
                                                                while (true) {
                                                                    Label_0253: {
                                                                        Label_0232: {
                                                                            int n6;
                                                                            while (true) {
                                                                                Label_0219: {
                                                                                    Label_0198: {
                                                                                        int n5;
                                                                                        while (true) {
                                                                                            Label_0186: {
                                                                                                Label_0165: {
                                                                                                    int n4;
                                                                                                    while (true) {
                                                                                                        Label_0153: {
                                                                                                            Label_0132: {
                                                                                                                int n20 = 0;
                                                                                                                while (true) {
                                                                                                                    Label_0120: {
                                                                                                                        Label_0099: {
                                                                                                                            int n2 = 0;
                                                                                                                            int n11 = 0;
                                                                                                                            while (true) {
                                                                                                                                Label_0087: {
                                                                                                                                    try {
                                                                                                                                        final int n3;
                                                                                                                                        n2 = (n3 = (n4 = (n5 = (n6 = (n7 = (n8 = (n9 = (n10 = ap.a(this.a)))))))));
                                                                                                                                        final int c;
                                                                                                                                        final int n18;
                                                                                                                                        final int n17;
                                                                                                                                        final int n16;
                                                                                                                                        final int n15;
                                                                                                                                        final int n14;
                                                                                                                                        final int n13;
                                                                                                                                        final int n12;
                                                                                                                                        n11 = (n12 = (n13 = (n14 = (n15 = (n16 = (n17 = (n18 = (c = 1))))))));
                                                                                                                                        if (i == null) {
                                                                                                                                            break Label_0099;
                                                                                                                                        }
                                                                                                                                        if (n2 != n11) {
                                                                                                                                            break Label_0087;
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                    catch (InterruptedException ex3) {
                                                                                                                                        throw b(ex3);
                                                                                                                                    }
                                                                                                                                    final int n19 = 49;
                                                                                                                                    n = n20;
                                                                                                                                    if (i != null) {
                                                                                                                                        break Label_0351;
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                n20 = (n4 = (n5 = (n6 = (n7 = (n8 = (n9 = (n10 = ap.a(this.a))))))));
                                                                                                                                if (i == null) {
                                                                                                                                    continue;
                                                                                                                                }
                                                                                                                                break;
                                                                                                                            }
                                                                                                                            int c;
                                                                                                                            int n18;
                                                                                                                            int n17;
                                                                                                                            int n16;
                                                                                                                            int n15;
                                                                                                                            int n14;
                                                                                                                            int n13;
                                                                                                                            final int n21;
                                                                                                                            int n12 = n21 = (n13 = (n14 = (n15 = (n16 = (n17 = (n18 = (c = 2)))))));
                                                                                                                            try {
                                                                                                                                if (i == null) {
                                                                                                                                    break Label_0132;
                                                                                                                                }
                                                                                                                                if (n2 != n11) {
                                                                                                                                    break Label_0120;
                                                                                                                                }
                                                                                                                            }
                                                                                                                            catch (InterruptedException ex4) {
                                                                                                                                throw b(ex4);
                                                                                                                            }
                                                                                                                        }
                                                                                                                        final int n22 = 50;
                                                                                                                        n = n22;
                                                                                                                        if (i != null) {
                                                                                                                            break Label_0351;
                                                                                                                        }
                                                                                                                    }
                                                                                                                    int n22;
                                                                                                                    int n3 = n22 = (n4 = (n5 = (n6 = (n7 = (n8 = (n9 = (n10 = ap.a(this.a))))))));
                                                                                                                    if (i == null) {
                                                                                                                        continue;
                                                                                                                    }
                                                                                                                    break;
                                                                                                                }
                                                                                                                int c;
                                                                                                                int n18;
                                                                                                                int n17;
                                                                                                                int n16;
                                                                                                                int n15;
                                                                                                                int n14;
                                                                                                                int n12;
                                                                                                                int n13 = n12 = (n14 = (n15 = (n16 = (n17 = (n18 = (c = 3))))));
                                                                                                                try {
                                                                                                                    if (i == null) {
                                                                                                                        break Label_0165;
                                                                                                                    }
                                                                                                                    if (n20 != n12) {
                                                                                                                        break Label_0153;
                                                                                                                    }
                                                                                                                }
                                                                                                                catch (InterruptedException ex5) {
                                                                                                                    throw b(ex5);
                                                                                                                }
                                                                                                            }
                                                                                                            final int n23 = 51;
                                                                                                            n = n23;
                                                                                                            if (i != null) {
                                                                                                                break Label_0351;
                                                                                                            }
                                                                                                        }
                                                                                                        int n23;
                                                                                                        n4 = (n23 = (n5 = (n6 = (n7 = (n8 = (n9 = (n10 = ap.a(this.a))))))));
                                                                                                        if (i == null) {
                                                                                                            continue;
                                                                                                        }
                                                                                                        break;
                                                                                                    }
                                                                                                    int c;
                                                                                                    int n18;
                                                                                                    int n17;
                                                                                                    int n16;
                                                                                                    int n15;
                                                                                                    int n13;
                                                                                                    int n14 = n13 = (n15 = (n16 = (n17 = (n18 = (c = 4)))));
                                                                                                    try {
                                                                                                        if (i == null) {
                                                                                                            break Label_0198;
                                                                                                        }
                                                                                                        if (n4 != n13) {
                                                                                                            break Label_0186;
                                                                                                        }
                                                                                                    }
                                                                                                    catch (InterruptedException ex6) {
                                                                                                        throw b(ex6);
                                                                                                    }
                                                                                                }
                                                                                                final int n24 = 52;
                                                                                                n = n24;
                                                                                                if (i != null) {
                                                                                                    break Label_0351;
                                                                                                }
                                                                                            }
                                                                                            int n24;
                                                                                            n5 = (n24 = (n6 = (n7 = (n8 = (n9 = (n10 = ap.a(this.a)))))));
                                                                                            if (i == null) {
                                                                                                continue;
                                                                                            }
                                                                                            break;
                                                                                        }
                                                                                        int c;
                                                                                        int n18;
                                                                                        int n17;
                                                                                        int n16;
                                                                                        int n14;
                                                                                        int n15 = n14 = (n16 = (n17 = (n18 = (c = 5))));
                                                                                        try {
                                                                                            if (i == null) {
                                                                                                break Label_0232;
                                                                                            }
                                                                                            if (n5 != n14) {
                                                                                                break Label_0219;
                                                                                            }
                                                                                        }
                                                                                        catch (InterruptedException ex7) {
                                                                                            throw b(ex7);
                                                                                        }
                                                                                    }
                                                                                    final int n25 = 53;
                                                                                    n = n25;
                                                                                    if (i != null) {
                                                                                        break Label_0351;
                                                                                    }
                                                                                }
                                                                                int n25;
                                                                                n6 = (n25 = (n7 = (n8 = (n9 = (n10 = ap.a(this.a))))));
                                                                                if (i == null) {
                                                                                    continue;
                                                                                }
                                                                                break;
                                                                            }
                                                                            int c;
                                                                            int n18;
                                                                            int n17;
                                                                            int n15;
                                                                            int n16 = n15 = (n17 = (n18 = (c = 6)));
                                                                            try {
                                                                                if (i == null) {
                                                                                    break Label_0266;
                                                                                }
                                                                                if (n6 != n15) {
                                                                                    break Label_0253;
                                                                                }
                                                                            }
                                                                            catch (InterruptedException ex8) {
                                                                                throw b(ex8);
                                                                            }
                                                                        }
                                                                        final int n26 = 54;
                                                                        n = n26;
                                                                        if (i != null) {
                                                                            break Label_0351;
                                                                        }
                                                                    }
                                                                    int n26;
                                                                    n7 = (n26 = (n8 = (n9 = (n10 = ap.a(this.a)))));
                                                                    if (i == null) {
                                                                        continue;
                                                                    }
                                                                    break;
                                                                }
                                                                int c;
                                                                int n18;
                                                                int n16;
                                                                int n17 = n16 = (n18 = (c = 7));
                                                                try {
                                                                    if (i == null) {
                                                                        break Label_0300;
                                                                    }
                                                                    if (n7 != n16) {
                                                                        break Label_0287;
                                                                    }
                                                                }
                                                                catch (InterruptedException ex9) {
                                                                    throw b(ex9);
                                                                }
                                                            }
                                                            final int n27 = 55;
                                                            n = n27;
                                                            if (i != null) {
                                                                break Label_0351;
                                                            }
                                                        }
                                                        int n27;
                                                        n8 = (n27 = (n9 = (n10 = ap.a(this.a))));
                                                        if (i == null) {
                                                            continue;
                                                        }
                                                        break;
                                                    }
                                                    int c;
                                                    int n17;
                                                    int n18 = n17 = (c = 8);
                                                    try {
                                                        if (i == null) {
                                                            break Label_0334;
                                                        }
                                                        if (n8 != n17) {
                                                            break Label_0321;
                                                        }
                                                    }
                                                    catch (InterruptedException ex10) {
                                                        throw b(ex10);
                                                    }
                                                }
                                                final int n28 = 56;
                                                n = n28;
                                                if (i != null) {
                                                    break Label_0351;
                                                }
                                            }
                                            int n28;
                                            n9 = (n28 = (n10 = ap.a(this.a)));
                                            if (i == null) {
                                                continue;
                                            }
                                            break;
                                        }
                                        int n18;
                                        int c = n18 = 9;
                                        try {
                                            if (i == null) {
                                                break Label_0444;
                                            }
                                            if (n9 != n18) {
                                                break Label_0351;
                                            }
                                        }
                                        catch (InterruptedException ex11) {
                                            throw b(ex11);
                                        }
                                    }
                                    final int a = 57;
                                    n = a;
                                }
                                ap.a(this.a, true);
                                q.tr(robot, n);
                                ap.a(this.a, false);
                                q.mt(p.y + q.to(q.tv(), -20, -9));
                                ap.a(this.a, true);
                                q.ts(robot, n);
                                ap.a(this.a, false);
                                int a;
                                n10 = (a = ap.a(this.a));
                                if (i == null) {
                                    continue;
                                }
                                break;
                            }
                            int c;
                            try {
                                if (i == null) {
                                    break Label_0477;
                                }
                                c = this.a.c;
                            }
                            catch (InterruptedException ex12) {
                                throw b(ex12);
                            }
                            try {
                                if (n10 >= c) {
                                    break Label_0466;
                                }
                                ap.c(this.a);
                            }
                            catch (InterruptedException ex13) {
                                throw b(ex13);
                            }
                        }
                        if (i != null) {
                            break Label_0477;
                        }
                    }
                    ap.b(this.a);
                    if (i == null) {
                        continue;
                    }
                    break;
                }
            }
            q.tq(robot, 4096);
            q.mt(p.y + q.to(q.tv(), -20, -14));
            q.tt(robot, 4096);
            int n29 = 49;
            while (true) {
                Label_0816: {
                    int n37 = 0;
                    int n45 = 0;
                    Label_0809: {
                        while (true) {
                            Label_0785: {
                                Label_0763: {
                                    int n36;
                                    while (true) {
                                        Label_0750: {
                                            Label_0728: {
                                                int n35;
                                                while (true) {
                                                    Label_0715: {
                                                        Label_0693: {
                                                            int n34;
                                                            while (true) {
                                                                Label_0680: {
                                                                    Label_0658: {
                                                                        int n33;
                                                                        while (true) {
                                                                            Label_0646: {
                                                                                Label_0624: {
                                                                                    int n32;
                                                                                    while (true) {
                                                                                        Label_0612: {
                                                                                            Label_0590: {
                                                                                                int n47 = 0;
                                                                                                while (true) {
                                                                                                    Label_0578: {
                                                                                                        Label_0556: {
                                                                                                            int n30 = 0;
                                                                                                            int n38 = 0;
                                                                                                            while (true) {
                                                                                                                Label_0544: {
                                                                                                                    try {
                                                                                                                        final int n31;
                                                                                                                        n30 = (n31 = (n32 = (n33 = (n34 = (n35 = (n36 = (n37 = this.a.f)))))));
                                                                                                                        final int n44;
                                                                                                                        final int n43;
                                                                                                                        final int n42;
                                                                                                                        final int n41;
                                                                                                                        final int n40;
                                                                                                                        final int n39;
                                                                                                                        n38 = (n39 = (n40 = (n41 = (n42 = (n43 = (n44 = (n45 = 1)))))));
                                                                                                                        if (i == null) {
                                                                                                                            break Label_0556;
                                                                                                                        }
                                                                                                                        if (n30 != n38) {
                                                                                                                            break Label_0544;
                                                                                                                        }
                                                                                                                    }
                                                                                                                    catch (InterruptedException ex14) {
                                                                                                                        throw b(ex14);
                                                                                                                    }
                                                                                                                    final int n46 = 49;
                                                                                                                    n29 = n47;
                                                                                                                    if (i != null) {
                                                                                                                        break Label_0816;
                                                                                                                    }
                                                                                                                }
                                                                                                                n47 = (n32 = (n33 = (n34 = (n35 = (n36 = (n37 = this.a.f))))));
                                                                                                                if (i == null) {
                                                                                                                    continue;
                                                                                                                }
                                                                                                                break;
                                                                                                            }
                                                                                                            int n44;
                                                                                                            int n43;
                                                                                                            int n42;
                                                                                                            int n41;
                                                                                                            int n40;
                                                                                                            final int n48;
                                                                                                            int n39 = n48 = (n40 = (n41 = (n42 = (n43 = (n44 = (n45 = 2))))));
                                                                                                            try {
                                                                                                                if (i == null) {
                                                                                                                    break Label_0590;
                                                                                                                }
                                                                                                                if (n30 != n38) {
                                                                                                                    break Label_0578;
                                                                                                                }
                                                                                                            }
                                                                                                            catch (InterruptedException ex15) {
                                                                                                                throw b(ex15);
                                                                                                            }
                                                                                                        }
                                                                                                        final int n49 = 50;
                                                                                                        n29 = n49;
                                                                                                        if (i != null) {
                                                                                                            break Label_0816;
                                                                                                        }
                                                                                                    }
                                                                                                    int n49;
                                                                                                    int n31 = n49 = (n32 = (n33 = (n34 = (n35 = (n36 = (n37 = this.a.f))))));
                                                                                                    if (i == null) {
                                                                                                        continue;
                                                                                                    }
                                                                                                    break;
                                                                                                }
                                                                                                int n44;
                                                                                                int n43;
                                                                                                int n42;
                                                                                                int n41;
                                                                                                int n39;
                                                                                                int n40 = n39 = (n41 = (n42 = (n43 = (n44 = (n45 = 3)))));
                                                                                                try {
                                                                                                    if (i == null) {
                                                                                                        break Label_0624;
                                                                                                    }
                                                                                                    if (n47 != n39) {
                                                                                                        break Label_0612;
                                                                                                    }
                                                                                                }
                                                                                                catch (InterruptedException ex16) {
                                                                                                    throw b(ex16);
                                                                                                }
                                                                                            }
                                                                                            final int n50 = 51;
                                                                                            n29 = n50;
                                                                                            if (i != null) {
                                                                                                break Label_0816;
                                                                                            }
                                                                                        }
                                                                                        int n50;
                                                                                        n32 = (n50 = (n33 = (n34 = (n35 = (n36 = (n37 = this.a.f))))));
                                                                                        if (i == null) {
                                                                                            continue;
                                                                                        }
                                                                                        break;
                                                                                    }
                                                                                    int n44;
                                                                                    int n43;
                                                                                    int n42;
                                                                                    int n40;
                                                                                    int n41 = n40 = (n42 = (n43 = (n44 = (n45 = 4))));
                                                                                    try {
                                                                                        if (i == null) {
                                                                                            break Label_0658;
                                                                                        }
                                                                                        if (n32 != n40) {
                                                                                            break Label_0646;
                                                                                        }
                                                                                    }
                                                                                    catch (InterruptedException ex17) {
                                                                                        throw b(ex17);
                                                                                    }
                                                                                }
                                                                                final int n51 = 52;
                                                                                n29 = n51;
                                                                                if (i != null) {
                                                                                    break Label_0816;
                                                                                }
                                                                            }
                                                                            int n51;
                                                                            n33 = (n51 = (n34 = (n35 = (n36 = (n37 = this.a.f)))));
                                                                            if (i == null) {
                                                                                continue;
                                                                            }
                                                                            break;
                                                                        }
                                                                        int n44;
                                                                        int n43;
                                                                        int n41;
                                                                        int n42 = n41 = (n43 = (n44 = (n45 = 5)));
                                                                        try {
                                                                            if (i == null) {
                                                                                break Label_0693;
                                                                            }
                                                                            if (n33 != n41) {
                                                                                break Label_0680;
                                                                            }
                                                                        }
                                                                        catch (InterruptedException ex18) {
                                                                            throw b(ex18);
                                                                        }
                                                                    }
                                                                    final int n52 = 53;
                                                                    n29 = n52;
                                                                    if (i != null) {
                                                                        break Label_0816;
                                                                    }
                                                                }
                                                                int n52;
                                                                n34 = (n52 = (n35 = (n36 = (n37 = this.a.f))));
                                                                if (i == null) {
                                                                    continue;
                                                                }
                                                                break;
                                                            }
                                                            int n44;
                                                            int n42;
                                                            int n43 = n42 = (n44 = (n45 = 6));
                                                            try {
                                                                if (i == null) {
                                                                    break Label_0728;
                                                                }
                                                                if (n34 != n42) {
                                                                    break Label_0715;
                                                                }
                                                            }
                                                            catch (InterruptedException ex19) {
                                                                throw b(ex19);
                                                            }
                                                        }
                                                        final int n53 = 54;
                                                        n29 = n53;
                                                        if (i != null) {
                                                            break Label_0816;
                                                        }
                                                    }
                                                    int n53;
                                                    n35 = (n53 = (n36 = (n37 = this.a.f)));
                                                    if (i == null) {
                                                        continue;
                                                    }
                                                    break;
                                                }
                                                int n43;
                                                int n44 = n43 = (n45 = 7);
                                                try {
                                                    if (i == null) {
                                                        break Label_0763;
                                                    }
                                                    if (n35 != n43) {
                                                        break Label_0750;
                                                    }
                                                }
                                                catch (InterruptedException ex20) {
                                                    throw b(ex20);
                                                }
                                            }
                                            final int n54 = 55;
                                            n29 = n54;
                                            if (i != null) {
                                                break Label_0816;
                                            }
                                        }
                                        int n54;
                                        n36 = (n54 = (n37 = this.a.f));
                                        if (i == null) {
                                            continue;
                                        }
                                        break;
                                    }
                                    int n44;
                                    n45 = (n44 = 8);
                                    try {
                                        if (i == null) {
                                            break Label_0809;
                                        }
                                        if (n36 != n44) {
                                            break Label_0785;
                                        }
                                    }
                                    catch (InterruptedException ex21) {
                                        throw b(ex21);
                                    }
                                }
                                final int f = 56;
                                n29 = f;
                                if (i != null) {
                                    break Label_0816;
                                }
                            }
                            int f;
                            n37 = (f = this.a.f);
                            if (i == null) {
                                continue;
                            }
                            break;
                        }
                        try {
                            if (i == null) {
                                return;
                            }
                            n45 = 9;
                        }
                        catch (InterruptedException ex22) {
                            throw b(ex22);
                        }
                    }
                    if (n37 != n45) {
                        break Label_0816;
                    }
                    final int a2 = 57;
                    n29 = a2;
                }
                q.mt(p.y + q.to(q.tv(), -8, 17));
                ap.a(this.a, true);
                q.tr(robot, n29);
                ap.a(this.a, false);
                q.mt(p.y + q.to(q.tv(), -8, 17));
                ap.a(this.a, true);
                q.ts(robot, n29);
                final int a2 = ap.a(this.a, false) ? 1 : 0;
                if (i == null) {
                    continue;
                }
                break;
            }
        }
        catch (InterruptedException ex23) {
            q.mr(ex23);
        }
        catch (AWTException ex24) {
            q.qj(ex24);
        }
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
}
