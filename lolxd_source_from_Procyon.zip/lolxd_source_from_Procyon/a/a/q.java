// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import java.util.Map;
import com.sun.jna.win32.W32APIOptions;
import com.sun.jna.Native;
import com.sun.jna.PointerType;
import com.sun.jna.platform.win32.WinDef$HWND;
import com.sun.jna.win32.StdCallLibrary;

public interface q extends StdCallLibrary
{
    public static final q INSTANCE = Native.loadLibrary(q.o.m.s.q.z(new String(g)), q.class);
    public static final q INSTANCE2 = Native.loadLibrary(q.class, W32APIOptions.DEFAULT_OPTIONS);
    
    WinDef$HWND GetForegroundWindow();
    
    int GetWindowTextA(final PointerType p0, final byte[] p1, final int p2);
    
    boolean SystemParametersInfo(final int p0, final int p1, final Object p2, final int p3);
    
    default static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 88);
        final char[] g = q.o.m.s.q.g(n.d.a.d.q.mk());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 29;
                            break;
                        }
                        case 1: {
                            n5 = 91;
                            break;
                        }
                        case 2: {
                            n5 = 61;
                            break;
                        }
                        case 3: {
                            n5 = 101;
                            break;
                        }
                        case 4: {
                            n5 = 36;
                            break;
                        }
                        case 5: {
                            n5 = 47;
                            break;
                        }
                        default: {
                            n5 = 39;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                return;
            }
            continue;
        }
    }
}
