// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class an implements ActionListener
{
    final ac a;
    
    an(final ac a) {
        this.a = a;
    }
    
    @Override
    public void actionPerformed(final ActionEvent actionEvent) {
        ac.g(this.a);
    }
}
