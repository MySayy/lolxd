// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import q.o.m.s.q;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class u implements ActionListener
{
    final ac a;
    private static final String b;
    
    u(final ac a) {
        this.a = a;
    }
    
    @Override
    public void actionPerformed(final ActionEvent actionEvent) {
        q.mj(ac.i(this.a), q.s(q.r(q.r(new StringBuilder(), u.b), q.mh(q.mx(ac.aP)))));
    }
    
    static {
        int n3;
        int n2;
        final int n = n2 = (n3 = 96);
        final char[] g = q.g(n.d.a.d.q.mh());
        final int length = g.length;
        int n4 = 0;
        while (true) {
            Label_0128: {
                if (length > 1) {
                    break Label_0128;
                }
                n3 = (n2 = n4);
                do {
                    final char c = g[n2];
                    int n5 = 0;
                    switch (n4 % 7) {
                        case 0: {
                            n5 = 44;
                            break;
                        }
                        case 1: {
                            n5 = 47;
                            break;
                        }
                        case 2: {
                            n5 = 112;
                            break;
                        }
                        case 3: {
                            n5 = 37;
                            break;
                        }
                        case 4: {
                            n5 = 91;
                            break;
                        }
                        case 5: {
                            n5 = 56;
                            break;
                        }
                        default: {
                            n5 = 18;
                            break;
                        }
                    }
                    g[n3] = (char)(c ^ (n ^ n5));
                    ++n4;
                } while (n == 0);
            }
            if (length <= n4) {
                b = q.z(new String(g));
                return;
            }
            continue;
        }
    }
}
