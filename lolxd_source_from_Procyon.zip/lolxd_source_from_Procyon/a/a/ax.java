// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import q.o.m.s.q;
import java.awt.Component;
import java.awt.Color;
import java.util.ArrayList;

public class ax extends Thread
{
    private ArrayList<Color> d;
    private ac c;
    private ArrayList<Component> e;
    public volatile boolean b;
    public int a;
    
    public ax(final ArrayList<Component> e, final ac c) {
        this.d = new ArrayList<Color>();
        this.e = new ArrayList<Component>();
        this.b = false;
        this.a = 50;
        this.e = e;
        this.c = c;
        this.a();
    }
    
    private void a() {
        final String[] i = ac.i();
        int tz = 0;
        Label_0037: {
            Label_0026: {
                int n;
                try {
                    n = (tz = (q.tz(this.d) ? 1 : 0));
                    if (i == null) {
                        break Label_0037;
                    }
                    final String[] array = i;
                    if (array != null) {
                        break Label_0026;
                    }
                    break Label_0037;
                }
                catch (RuntimeException ex) {
                    throw b(ex);
                }
                try {
                    final String[] array = i;
                    if (array == null) {
                        break Label_0037;
                    }
                    if (n == 0) {
                        return;
                    }
                }
                catch (RuntimeException ex2) {
                    throw b(ex2);
                }
            }
            tz = 0;
        }
        int j = tz;
        while (true) {
            ax ax;
            ArrayList<Color> list;
            int n2;
            int n3;
            int n4;
            int n5;
            int n6;
            int n7;
            int n8;
            Color color;
            String[] array2;
            ax ax2;
            ArrayList<Color> list2;
            int n9;
            int n10;
            int n11;
            int n12;
            int n13;
            int n14;
            int n15;
            Color color2;
            String[] array3;
            ax ax3;
            ArrayList<Color> list3;
            int n16;
            int n17;
            int n18;
            int n19;
            int n20;
            int n21;
            int n22;
            int n23;
            int n24;
            int n25;
            int n26;
            Color color3;
            String[] array4;
            ax ax4;
            ArrayList<Color> list4;
            int n27;
            int n28;
            int n29;
            int n30;
            int n31;
            int n32;
            int n33;
            Color color4;
            String[] array5;
            ax ax5;
            ArrayList<Color> list5;
            int n34;
            int n35;
            int n36;
            int n37;
            int n38;
            int n39;
            int n40;
            Color color5;
            String[] array6;
            Label_0092_Outer:Label_0150_Outer:
            while (j < 100) {
            Label_0336:
                while (true) {
                Label_0275:
                    while (true) {
                    Label_0211:
                        while (true) {
                        Label_0150:
                            while (true) {
                            Label_0148:
                                while (true) {
                                    try {
                                        q.ob(this.d, new Color(j * 220 / 100, 220, 0));
                                        ++j;
                                        if (i == null) {
                                            break Label_0092;
                                        }
                                        if (i != null) {
                                            continue Label_0092_Outer;
                                        }
                                    }
                                    catch (RuntimeException ex3) {
                                        throw b(ex3);
                                    }
                                    break;
                                    Label_0137: {
                                        try {
                                            if (j <= 0) {
                                                break Label_0148;
                                            }
                                            ax = this;
                                            list = ax.d;
                                            n2 = 220;
                                            n3 = j;
                                            n4 = 220;
                                            n5 = n3 * n4;
                                            n6 = 100;
                                            n7 = n5 / n6;
                                            n8 = 0;
                                            color = new Color(n2, n7, n8);
                                            q.ob(list, color);
                                            --j;
                                            array2 = i;
                                            if (array2 != null) {
                                                break Label_0137;
                                            }
                                            break Label_0150;
                                        }
                                        catch (RuntimeException ex4) {
                                            throw b(ex4);
                                        }
                                        try {
                                            ax = this;
                                            list = ax.d;
                                            n2 = 220;
                                            n3 = j;
                                            n4 = 220;
                                            n5 = n3 * n4;
                                            n6 = 100;
                                            n7 = n5 / n6;
                                            n8 = 0;
                                            color = new Color(n2, n7, n8);
                                            q.ob(list, color);
                                            --j;
                                            array2 = i;
                                            if (array2 == null) {
                                                break Label_0150;
                                            }
                                            if (i != null) {
                                                continue Label_0150_Outer;
                                            }
                                        }
                                        catch (RuntimeException ex5) {
                                            throw b(ex5);
                                        }
                                    }
                                    break;
                                }
                                j = 0;
                                Label_0197: {
                                    try {
                                        if (j >= 100) {
                                            break Label_0150;
                                        }
                                        ax2 = this;
                                        list2 = ax2.d;
                                        n9 = 220;
                                        n10 = 0;
                                        n11 = j;
                                        n12 = 220;
                                        n13 = n11 * n12;
                                        n14 = 100;
                                        n15 = n13 / n14;
                                        color2 = new Color(n9, n10, n15);
                                        q.ob(list2, color2);
                                        ++j;
                                        array3 = i;
                                        if (array3 != null) {
                                            break Label_0197;
                                        }
                                        break Label_0211;
                                    }
                                    catch (RuntimeException ex6) {
                                        throw b(ex6);
                                    }
                                    try {
                                        ax2 = this;
                                        list2 = ax2.d;
                                        n9 = 220;
                                        n10 = 0;
                                        n11 = j;
                                        n12 = 220;
                                        n13 = n11 * n12;
                                        n14 = 100;
                                        n15 = n13 / n14;
                                        color2 = new Color(n9, n10, n15);
                                        q.ob(list2, color2);
                                        ++j;
                                        array3 = i;
                                        if (array3 == null) {
                                            break Label_0211;
                                        }
                                        if (i != null) {
                                            continue Label_0150;
                                        }
                                    }
                                    catch (RuntimeException ex7) {
                                        throw b(ex7);
                                    }
                                }
                                break;
                            }
                            j = 100;
                            Label_0262: {
                                try {
                                    if (j <= 0) {
                                        break Label_0211;
                                    }
                                    ax3 = this;
                                    list3 = ax3.d;
                                    n16 = j;
                                    n17 = 220;
                                    n18 = n16 * n17;
                                    n19 = 100;
                                    n20 = n18 / n19;
                                    n21 = j;
                                    n22 = 10;
                                    n23 = n21 * n22;
                                    n24 = 100;
                                    n25 = n23 / n24;
                                    n26 = 255;
                                    color3 = new Color(n20, n25, n26);
                                    q.ob(list3, color3);
                                    --j;
                                    array4 = i;
                                    if (array4 != null) {
                                        break Label_0262;
                                    }
                                    break Label_0275;
                                }
                                catch (RuntimeException ex8) {
                                    throw b(ex8);
                                }
                                try {
                                    ax3 = this;
                                    list3 = ax3.d;
                                    n16 = j;
                                    n17 = 220;
                                    n18 = n16 * n17;
                                    n19 = 100;
                                    n20 = n18 / n19;
                                    n21 = j;
                                    n22 = 10;
                                    n23 = n21 * n22;
                                    n24 = 100;
                                    n25 = n23 / n24;
                                    n26 = 255;
                                    color3 = new Color(n20, n25, n26);
                                    q.ob(list3, color3);
                                    --j;
                                    array4 = i;
                                    if (array4 == null) {
                                        break Label_0275;
                                    }
                                    if (i != null) {
                                        continue Label_0211;
                                    }
                                }
                                catch (RuntimeException ex9) {
                                    throw b(ex9);
                                }
                            }
                            break;
                        }
                        j = 0;
                        Label_0322: {
                            try {
                                if (j >= 100) {
                                    break Label_0275;
                                }
                                ax4 = this;
                                list4 = ax4.d;
                                n27 = 0;
                                n28 = j;
                                n29 = 220;
                                n30 = n28 * n29;
                                n31 = 100;
                                n32 = n30 / n31;
                                n33 = 255;
                                color4 = new Color(n27, n32, n33);
                                q.ob(list4, color4);
                                ++j;
                                array5 = i;
                                if (array5 != null) {
                                    break Label_0322;
                                }
                                break Label_0336;
                            }
                            catch (RuntimeException ex10) {
                                throw b(ex10);
                            }
                            try {
                                ax4 = this;
                                list4 = ax4.d;
                                n27 = 0;
                                n28 = j;
                                n29 = 220;
                                n30 = n28 * n29;
                                n31 = 100;
                                n32 = n30 / n31;
                                n33 = 255;
                                color4 = new Color(n27, n32, n33);
                                q.ob(list4, color4);
                                ++j;
                                array5 = i;
                                if (array5 == null) {
                                    break Label_0336;
                                }
                                if (i != null) {
                                    continue Label_0275;
                                }
                            }
                            catch (RuntimeException ex11) {
                                throw b(ex11);
                            }
                        }
                        break;
                    }
                    j = 100;
                    Label_0381: {
                        try {
                            if (j <= 0) {
                                break Label_0336;
                            }
                            ax5 = this;
                            list5 = ax5.d;
                            n34 = 0;
                            n35 = 220;
                            n36 = j;
                            n37 = 220;
                            n38 = n36 * n37;
                            n39 = 100;
                            n40 = n38 / n39;
                            color5 = new Color(n34, n35, n40);
                            q.ob(list5, color5);
                            --j;
                            array6 = i;
                            if (array6 != null) {
                                break Label_0381;
                            }
                            return;
                        }
                        catch (RuntimeException ex12) {
                            throw b(ex12);
                        }
                        try {
                            ax5 = this;
                            list5 = ax5.d;
                            n34 = 0;
                            n35 = 220;
                            n36 = j;
                            n37 = 220;
                            n38 = n36 * n37;
                            n39 = 100;
                            n40 = n38 / n39;
                            color5 = new Color(n34, n35, n40);
                            q.ob(list5, color5);
                            --j;
                            array6 = i;
                            if (array6 == null) {
                                return;
                            }
                            if (i != null) {
                                continue Label_0336;
                            }
                        }
                        catch (RuntimeException ex13) {
                            throw b(ex13);
                        }
                    }
                    break;
                }
                q.ob(this.d, new Color(0, 220, 0));
                return;
            }
            j = 100;
            continue;
        }
    }
    
    @Override
    public void run() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: aload_0        
        //     4: aload_0        
        //     5: getfield        a/a/ax.c:La/a/ac;
        //     8: getfield        a/a/ac.aB:I
        //    11: putfield        a/a/ax.a:I
        //    14: astore_1       
        //    15: iconst_0       
        //    16: istore_2       
        //    17: iload_2        
        //    18: aload_0        
        //    19: getfield        a/a/ax.d:Ljava/util/ArrayList;
        //    22: invokestatic    q/o/m/s/q.td:(Ljava/util/ArrayList;)I
        //    25: if_icmpge       252
        //    28: aload_0        
        //    29: aload_1        
        //    30: ifnull          121
        //    33: getfield        a/a/ax.b:Z
        //    36: ifeq            106
        //    39: goto            46
        //    42: invokestatic    a/a/ax.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //    45: athrow         
        //    46: aload_0        
        //    47: getfield        a/a/ax.c:La/a/ac;
        //    50: getfield        a/a/ac.D:Ljava/awt/Color;
        //    53: astore_3       
        //    54: aload_0        
        //    55: getfield        a/a/ax.e:Ljava/util/ArrayList;
        //    58: invokestatic    q/o/m/s/q.ol:(Ljava/util/ArrayList;)Ljava/util/Iterator;
        //    61: astore          4
        //    63: aload           4
        //    65: invokestatic    q/o/m/s/q.oi:(Ljava/util/Iterator;)Z
        //    68: ifeq            102
        //    71: aload           4
        //    73: invokestatic    q/o/m/s/q.ou:(Ljava/util/Iterator;)Ljava/lang/Object;
        //    76: checkcast       Ljava/awt/Component;
        //    79: astore          5
        //    81: aload           5
        //    83: aload_3        
        //    84: invokestatic    q/o/m/s/q.qm:(Ljava/awt/Component;Ljava/awt/Color;)V
        //    87: aload_1        
        //    88: ifnull          252
        //    91: aload_1        
        //    92: ifnonnull       63
        //    95: goto            102
        //    98: invokestatic    a/a/ax.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   101: athrow         
        //   102: aload_1        
        //   103: ifnonnull       252
        //   106: aload_0        
        //   107: getfield        a/a/ax.d:Ljava/util/ArrayList;
        //   110: iload_2        
        //   111: invokestatic    q/o/m/s/q.tb:(Ljava/util/ArrayList;I)Ljava/lang/Object;
        //   114: goto            121
        //   117: invokestatic    a/a/ax.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   120: athrow         
        //   121: checkcast       Ljava/awt/Color;
        //   124: astore_3       
        //   125: aload_0        
        //   126: getfield        a/a/ax.e:Ljava/util/ArrayList;
        //   129: invokestatic    q/o/m/s/q.ol:(Ljava/util/ArrayList;)Ljava/util/Iterator;
        //   132: aload_1        
        //   133: ifnull          61
        //   136: astore          4
        //   138: aload           4
        //   140: invokestatic    q/o/m/s/q.oi:(Ljava/util/Iterator;)Z
        //   143: ifeq            177
        //   146: aload           4
        //   148: invokestatic    q/o/m/s/q.ou:(Ljava/util/Iterator;)Ljava/lang/Object;
        //   151: checkcast       Ljava/awt/Component;
        //   154: astore          5
        //   156: aload           5
        //   158: aload_3        
        //   159: invokestatic    q/o/m/s/q.qm:(Ljava/awt/Component;Ljava/awt/Color;)V
        //   162: aload_1        
        //   163: ifnull          201
        //   166: aload_1        
        //   167: ifnonnull       138
        //   170: goto            177
        //   173: invokestatic    a/a/ax.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   176: athrow         
        //   177: aload_0        
        //   178: getfield        a/a/ax.a:I
        //   181: iconst_4       
        //   182: idiv           
        //   183: i2l            
        //   184: lstore          4
        //   186: lload           4
        //   188: invokestatic    q/o/m/s/q.mt:(J)V
        //   191: goto            201
        //   194: astore          4
        //   196: aload           4
        //   198: invokestatic    q/o/m/s/q.mr:(Ljava/lang/InterruptedException;)V
        //   201: iload_2        
        //   202: aload_1        
        //   203: ifnull          244
        //   206: aload_1        
        //   207: ifnull          244
        //   210: goto            217
        //   213: invokestatic    a/a/ax.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   216: athrow         
        //   217: aload_0        
        //   218: getfield        a/a/ax.d:Ljava/util/ArrayList;
        //   221: invokestatic    q/o/m/s/q.td:(Ljava/util/ArrayList;)I
        //   224: iconst_1       
        //   225: isub           
        //   226: if_icmplt       245
        //   229: goto            236
        //   232: invokestatic    a/a/ax.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   235: athrow         
        //   236: iconst_0       
        //   237: goto            244
        //   240: invokestatic    a/a/ax.b:(Ljava/lang/Exception;)Ljava/lang/Exception;
        //   243: athrow         
        //   244: istore_2       
        //   245: iinc            2, 1
        //   248: aload_1        
        //   249: ifnonnull       17
        //   252: return         
        //    StackMapTable: 00 17 FD 00 11 07 00 35 01 58 07 00 44 03 FF 00 0E 00 04 07 00 02 07 00 35 01 07 00 3A 00 01 07 00 55 FC 00 01 07 00 55 FF 00 22 00 06 07 00 02 07 00 35 01 07 00 3A 07 00 55 07 00 5F 00 01 07 00 44 FA 00 03 F9 00 03 4A 07 00 44 43 07 00 69 FD 00 10 07 00 3A 07 00 55 FF 00 22 00 06 07 00 02 07 00 35 01 07 00 3A 07 00 55 07 00 5F 00 01 07 00 44 FA 00 03 FF 00 10 00 04 07 00 02 07 00 35 01 07 00 3A 00 01 07 00 44 06 4B 07 00 44 43 01 4E 07 00 44 03 43 07 00 44 43 01 00 FA 00 06
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  156    170    173    177    Ljava/lang/InterruptedException;
        //  102    114    117    121    Ljava/lang/InterruptedException;
        //  81     95     98     102    Ljava/lang/InterruptedException;
        //  28     39     42     46     Ljava/lang/InterruptedException;
        //  177    191    194    201    Ljava/lang/InterruptedException;
        //  201    210    213    217    Ljava/lang/InterruptedException;
        //  206    229    232    236    Ljava/lang/InterruptedException;
        //  217    237    240    244    Ljava/lang/InterruptedException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0217:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static Exception b(final Exception ex) {
        return ex;
    }
}
