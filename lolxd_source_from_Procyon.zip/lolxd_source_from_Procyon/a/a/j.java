// 
// Decompiled by Procyon v0.5.36
// 

package a.a;

import q.o.m.s.q;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

class j implements ChangeListener
{
    final ac a;
    
    j(final ac a) {
        this.a = a;
    }
    
    @Override
    public void stateChanged(final ChangeEvent changeEvent) {
        p.c = q.mv(ac.r(this.a));
    }
}
