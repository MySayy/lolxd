// 
// Decompiled by Procyon v0.5.36
// 

package q.o.m.s;

import java.io.StringWriter;
import java.nio.charset.CharsetDecoder;
import java.util.Enumeration;
import java.util.concurrent.ThreadFactory;
import java.io.ByteArrayOutputStream;
import java.util.UUID;
import java.io.ObjectStreamClass;
import java.nio.charset.CoderResult;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.CharsetEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.RandomAccessFile;
import java.io.FilenameFilter;
import java.util.Comparator;
import java.io.CharArrayWriter;
import java.net.ServerSocket;
import java.nio.channels.Selector;
import java.io.Closeable;
import java.net.HttpURLConnection;
import java.util.Stack;
import java.util.zip.CRC32;
import java.util.Date;
import java.io.BufferedOutputStream;
import java.net.URLConnection;
import java.nio.channels.ReadableByteChannel;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
import java.io.FileInputStream;
import java.net.URI;
import java.nio.CharBuffer;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.net.URL;
import java.math.BigInteger;
import java.util.Locale;
import java.util.StringTokenizer;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.util.Collection;
import java.io.FileFilter;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.io.Reader;
import java.util.SortedMap;
import java.util.TreeMap;
import java.nio.charset.Charset;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.Control;
import javax.sound.sampled.Clip;
import java.io.PrintWriter;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.LogManager;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.prefs.Preferences;
import java.util.List;
import java.util.HashMap;
import java.lang.reflect.Method;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.image.ImageObserver;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.Iterator;
import javax.swing.JComponent;
import java.util.ArrayList;
import java.awt.Container;
import java.awt.Color;
import javax.swing.plaf.TabbedPaneUI;
import javax.swing.JTabbedPane;
import javax.swing.Timer;
import javax.swing.event.ChangeListener;
import java.awt.event.MouseListener;
import java.awt.Dimension;
import javax.swing.JTextField;
import javax.swing.plaf.ButtonUI;
import java.awt.event.ActionListener;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.LayoutManager;
import javax.swing.JPanel;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.Clipboard;
import java.awt.Toolkit;
import javax.swing.JButton;
import java.io.File;
import javax.swing.JFileChooser;
import java.io.DataOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.awt.event.MouseEvent;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JCheckBox;
import java.util.Base64;
import java.awt.Component;
import java.security.spec.InvalidKeySpecException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStream;

public interface n
{
    Runtime f();
    
    Process m(final Runtime p0, final String[] p1);
    
    InputStream v(final Process p0);
    
    String o(final BufferedReader p0);
    
    int q(final String p0);
    
    boolean t(final String p0, final String p1);
    
    StringBuilder r(final StringBuilder p0, final String p1);
    
    String s(final StringBuilder p0);
    
    String k(final String p0, final CharSequence p1, final CharSequence p2);
    
    void e(final BufferedReader p0);
    
    void n(final IOException p0);
    
    void p(final NoSuchAlgorithmException p0);
    
    void y(final InvalidKeyException p0);
    
    void c(final InvalidAlgorithmParameterException p0);
    
    void x(final InvalidKeySpecException p0);
    
    String h(final String p0, final int p1, final int p2);
    
    char j(final String p0, final int p1);
    
    char[] g(final String p0);
    
    String z(final String p0);
    
    void d(final Component p0, final Object p1, final String p2, final int p3);
    
    byte[] b(final String p0, final String p1);
    
    Base64.Encoder w();
    
    byte[] a(final Base64.Encoder p0, final byte[] p1);
    
    Base64.Decoder l();
    
    byte[] i(final Base64.Decoder p0, final String p1);
    
    boolean u(final JCheckBox p0);
    
    Object mf(final JSpinner p0);
    
    int mm(final Integer p0);
    
    int mv(final JSlider p0);
    
    void mo(final JSlider p0, final int p1);
    
    int mq(final MouseEvent p0);
    
    void mt(final long p0);
    
    void mr(final InterruptedException p0);
    
    void ms(final int p0);
    
    OutputStream mk(final Socket p0);
    
    InputStream me(final Socket p0);
    
    void mn(final DataOutputStream p0, final String p1);
    
    void mp(final DataOutputStream p0);
    
    boolean my(final String p0, final String p1);
    
    void mc(final Socket p0);
    
    File mx(final JFileChooser p0);
    
    String mh(final File p0);
    
    void mj(final JButton p0, final String p1);
    
    void mg(final JCheckBox p0, final boolean p1);
    
    Toolkit mz();
    
    Clipboard md(final Toolkit p0);
    
    void mb(final Clipboard p0, final Transferable p1, final ClipboardOwner p2);
    
    void mw(final JPanel p0, final LayoutManager p1);
    
    void ma(final JLabel p0, final String p1);
    
    void ml(final JLabel p0, final Font p1);
    
    void mi(final JLabel p0, final int p1);
    
    void mu(final JLabel p0, final boolean p1);
    
    void vf(final JPanel p0, final Component p1, final Object p2);
    
    void vm(final JButton p0, final ActionListener p1);
    
    void vv(final JButton p0, final ButtonUI p1);
    
    void vo(final JCheckBox p0, final String p1);
    
    void vq(final JCheckBox p0, final Font p1);
    
    void vt(final JCheckBox p0, final int p1);
    
    String vr(final String p0);
    
    String vs(final String p0);
    
    boolean vk(final String p0, final CharSequence p1);
    
    void ve(final JCheckBox p0, final boolean p1);
    
    void vn(final JCheckBox p0, final ActionListener p1);
    
    void vp(final JTextField p0, final Dimension p1);
    
    void vy(final JTextField p0, final boolean p1);
    
    void vc(final JTextField p0, final String p1);
    
    void vx(final JTextField p0, final Font p1);
    
    void vh(final JTextField p0, final float p1);
    
    void vj(final JTextField p0, final int p1);
    
    void vg(final JTextField p0, final MouseListener p1);
    
    void vz(final JSlider p0, final int p1);
    
    void vd(final JSlider p0, final int p1);
    
    void vb(final JSlider p0, final boolean p1);
    
    void vw(final JSlider p0, final String p1);
    
    void va(final JSlider p0, final ChangeListener p1);
    
    void vl(final JSlider p0, final Dimension p1);
    
    Component vi(final JPanel p0, final Component p1);
    
    void vu(final JPanel p0, final Dimension p1);
    
    void of(final JLabel p0, final Dimension p1);
    
    void om(final JCheckBox p0, final Dimension p1);
    
    void ov(final JFileChooser p0, final File p1);
    
    void oo(final JFileChooser p0, final String p1);
    
    void oq(final JFileChooser p0, final int p1);
    
    void ot(final JFileChooser p0, final ActionListener p1);
    
    void or(final JButton p0, final Dimension p1);
    
    void os(final JSpinner p0, final Dimension p1);
    
    void ok(final JSpinner p0, final float p1);
    
    void oe(final JSpinner p0, final ChangeListener p1);
    
    void on(final JLabel p0, final String p1);
    
    void op(final JButton p0, final boolean p1);
    
    void oy(final Timer p0, final boolean p1);
    
    void oc(final Timer p0);
    
    void ox(final JTabbedPane p0, final int p1);
    
    void oh(final JTabbedPane p0, final String p1, final Component p2);
    
    Object oj(final Object p0, final Object p1);
    
    void og(final JTabbedPane p0, final TabbedPaneUI p1);
    
    void oz(final JPanel p0, final Color p1);
    
    void od(final Container p0, final Color p1);
    
    boolean ob(final ArrayList p0, final Object p1);
    
    JComponent ow(final JSpinner p0);
    
    Component oa(final JComponent p0, final int p1);
    
    Iterator ol(final ArrayList p0);
    
    boolean oi(final Iterator p0);
    
    Object ou(final Iterator p0);
    
    void qf(final Component p0, final Color p1);
    
    void qm(final Component p0, final Color p1);
    
    void qv(final Container p0, final Color p1);
    
    void qo(final JButton p0, final Color p1);
    
    void qq(final JLabel p0, final Color p1);
    
    void qt(final Timer p0);
    
    Graphics2D qr(final BufferedImage p0);
    
    void qs(final Graphics2D p0, final RenderingHints.Key p1, final Object p2);
    
    boolean qk(final Graphics2D p0, final Image p1, final int p2, final int p3, final int p4, final int p5, final ImageObserver p6);
    
    void qe(final Graphics2D p0);
    
    double qn();
    
    PointerInfo qp();
    
    Point qy(final PointerInfo p0);
    
    double qc(final Point p0);
    
    double qx(final Point p0);
    
    void qh(final Robot p0, final int p1, final int p2);
    
    void qj(final AWTException p0);
    
    StringBuilder qg(final StringBuilder p0, final int p1);
    
    Object qz(final Method p0, final Object p1, final Object[] p2);
    
    String qd(final String p0);
    
    Object qb(final HashMap p0, final Object p1, final Object p2);
    
    boolean qw(final List p0, final Object p1);
    
    Preferences qa();
    
    Preferences ql();
    
    Class qi(final Object p0);
    
    Method qu(final Class p0, final String p1, final Class[] p2);
    
    void tf(final Method p0, final boolean p1);
    
    void tm(final Exception p0);
    
    ThreadLocalRandom tv();
    
    int to(final ThreadLocalRandom p0, final int p1, final int p2);
    
    void tq(final Robot p0, final int p1);
    
    void tt(final Robot p0, final int p1);
    
    void tr(final Robot p0, final int p1);
    
    void ts(final Robot p0, final int p1);
    
    int tk(final JFileChooser p0, final Component p1);
    
    Integer te(final int p0);
    
    void tn(final JTextField p0, final Color p1);
    
    Set tp(final HashMap p0);
    
    Iterator ty(final Set p0);
    
    Object tc(final HashMap p0, final Object p1);
    
    Object tx(final HashMap p0, final Object p1);
    
    boolean th(final String p0, final Object p1);
    
    long tj();
    
    long tg(final long p0);
    
    boolean tz(final ArrayList p0);
    
    int td(final ArrayList p0);
    
    Object tb(final ArrayList p0, final int p1);
    
    int tw(final Timer p0);
    
    void ta(final Timer p0, final int p1);
    
    void tl(final Runtime p0, final Thread p1);
    
    LogManager ti();
    
    void tu(final LogManager p0);
    
    Package rf(final Class p0);
    
    String rm(final Package p0);
    
    Logger rv(final String p0);
    
    void ro(final Logger p0, final Level p1);
    
    void rq(final Timer p0);
    
    void rt(final Timer p0, final int p1);
    
    boolean rr(final List p0);
    
    Iterator rs(final List p0);
    
    void rk(final IllegalAccessException p0);
    
    void re(final InvocationTargetException p0);
    
    void rn(final Thread p0);
    
    AudioFormat rp(final AudioInputStream p0);
    
    AudioFormat.Encoding ry(final AudioFormat p0);
    
    float rc(final AudioFormat p0);
    
    int rx(final AudioFormat p0);
    
    boolean rh(final AudioFormat p0);
    
    AudioInputStream rj(final AudioFormat p0, final AudioInputStream p1);
    
    InputStream rg(final Class p0, final String p1);
    
    void rz(final PrintWriter p0, final String p1);
    
    void rd(final PrintWriter p0);
    
    String rb(final File p0);
    
    Clip rw();
    
    AudioInputStream ra(final InputStream p0);
    
    long rl(final AudioInputStream p0);
    
    void ri(final Clip p0, final AudioInputStream p1);
    
    Control ru(final Clip p0, final Control.Type p1);
    
    void sf(final FloatControl p0, final float p1);
    
    void sm(final Clip p0);
    
    void sv(final LineUnavailableException p0);
    
    void so(final UnsupportedAudioFileException p0);
    
    boolean sq(final String p0);
    
    void st(final Object p0, final int p1, final Object p2, final int p3, final int p4);
    
    int sr(final Object p0);
    
    String ss(final Class p0);
    
    StringBuilder sk(final StringBuilder p0, final char p1);
    
    String se(final int p0);
    
    String sn(final String p0);
    
    String sp(final Charset p0);
    
    Object sy(final TreeMap p0, final Object p1, final Object p2);
    
    SortedMap sc(final SortedMap p0);
    
    Charset sx();
    
    Charset sh(final String p0);
    
    void sj(final OutputStream p0, final byte[] p1);
    
    int sg(final InputStream p0, final byte[] p1);
    
    void sz(final OutputStream p0, final byte[] p1, final int p2, final int p3);
    
    int sd(final Reader p0, final char[] p1);
    
    void sb(final Writer p0, final char[] p1, final int p2, final int p3);
    
    void sw(final OutputStreamWriter p0);
    
    void sa(final Writer p0, final String p1);
    
    File[] sl(final File p0);
    
    File[] si(final File p0, final FileFilter p1);
    
    boolean su(final File p0);
    
    int kf(final float p0);
    
    float km(final int p0);
    
    long kv(final double p0);
    
    double ko(final long p0);
    
    void kq(final OutputStream p0, final int p1);
    
    int kt(final InputStream p0);
    
    int kr(final Collection p0);
    
    Reference ks(final ReferenceQueue p0);
    
    boolean kk(final Collection p0, final Object p1);
    
    Set ke(final Set p0);
    
    List kn(final List p0);
    
    boolean kp(final Collection p0, final Object p1);
    
    void ky(final Thread p0);
    
    boolean kc(final File p0);
    
    StringBuilder kx(final StringBuilder p0, final Object p1);
    
    boolean kh(final File p0);
    
    String kj(final File p0);
    
    int kg(final List p0);
    
    Object kz(final List p0, final int p1);
    
    boolean kd(final char p0);
    
    int kb(final StringBuilder p0);
    
    char kw(final StringBuilder p0, final int p1);
    
    StringBuilder ka(final StringBuilder p0, final int p1);
    
    int kl(final StringTokenizer p0);
    
    String ki(final StringTokenizer p0);
    
    long ku(final String p0);
    
    OutputStream ef(final Process p0);
    
    InputStream em(final Process p0);
    
    String ev(final String p0, final Locale p1);
    
    int eo(final Process p0);
    
    int eq(final Process p0);
    
    List et(final Object[] p0);
    
    void er(final Process p0);
    
    StringBuilder es(final StringBuilder p0, final long p1);
    
    boolean ek(final File p0, final Object p1);
    
    boolean ee(final File p0);
    
    boolean en(final File p0);
    
    File ep(final File p0);
    
    boolean ey(final File p0);
    
    BigInteger ec(final BigInteger p0, final BigInteger p1);
    
    int ex(final BigInteger p0, final BigInteger p1);
    
    String eh(final Object p0);
    
    BigInteger ej(final long p0);
    
    boolean eg(final File p0, final long p1);
    
    Object[] ez(final Collection p0, final Object[] p1);
    
    Iterator ed(final Collection p0);
    
    long eb(final File p0);
    
    File ew(final File p0);
    
    String ea(final URL p0);
    
    String el(final URL p0);
    
    String ei(final String p0, final char p1, final char p2);
    
    int eu(final String p0, final int p1);
    
    ByteBuffer nf(final int p0);
    
    int nm(final String p0, final int p1);
    
    ByteBuffer nv(final ByteBuffer p0, final byte p1);
    
    int no(final ByteBuffer p0);
    
    Buffer nq(final ByteBuffer p0);
    
    CharBuffer nt(final Charset p0, final ByteBuffer p1);
    
    String nr(final CharBuffer p0);
    
    Buffer ns(final ByteBuffer p0);
    
    URI nk(final File p0);
    
    URL ne(final URI p0);
    
    String nn(final File p0);
    
    void np(final FileInputStream p0);
    
    FileChannel ny(final FileInputStream p0);
    
    FileChannel nc(final FileOutputStream p0);
    
    long nx(final FileChannel p0);
    
    long nh(final FileChannel p0, final ReadableByteChannel p1, final long p2, final long p3);
    
    long nj(final File p0);
    
    boolean ng(final List p0, final Object p1);
    
    InputStream nz(final URL p0);
    
    URLConnection nd(final URL p0);
    
    void nb(final URLConnection p0, final int p1);
    
    void nw(final URLConnection p0, final int p1);
    
    InputStream na(final URLConnection p0);
    
    void nl(final FileOutputStream p0);
    
    Thread ni();
    
    long nu(final long p0, final long p1);
    
    void pf(final OutputStream p0);
    
    String pm(final CharSequence p0);
    
    void pv(final BufferedOutputStream p0);
    
    void po(final File p0);
    
    BigInteger pq(final BigInteger p0, final BigInteger p1);
    
    long pt(final Date p0);
    
    long pr(final CRC32 p0);
    
    boolean ps(final File p0, final File p1);
    
    StringBuilder pk(final StringBuilder p0, final boolean p1);
    
    String pe(final File p0);
    
    File pn(final File p0);
    
    BigInteger pp(final BigInteger p0, final BigInteger p1);
    
    void py(final String p0, final int p1, final int p2, final char[] p3, final int p4);
    
    int pc(final String p0, final int p1, final int p2);
    
    int px(final int p0, final int p1);
    
    char ph(final char p0);
    
    int pj(final String p0, final int p1);
    
    int pg(final int p0, final int p1);
    
    String pz(final String p0, final int p1);
    
    boolean pd(final Collection p0);
    
    int pb(final Stack p0);
    
    Object pw(final Stack p0);
    
    Object pa(final Stack p0, final Object p1);
    
    void pl(final StringBuilder p0, final int p1);
    
    Object[] pi(final ArrayList p0, final Object[] p1);
    
    String pu(final char p0);
    
    byte[] yf(final String p0, final Charset p1);
    
    void ym(final OutputStream p0);
    
    Enum yv(final Class p0, final String p1);
    
    int yo(final String p0, final String p1);
    
    int yq(final String p0, final String p1);
    
    boolean yt(final String p0, final boolean p1, final int p2, final String p3, final int p4, final int p5);
    
    void yr(final HttpURLConnection p0);
    
    void ys(final Closeable p0);
    
    void yk(final Selector p0);
    
    void ye(final ServerSocket p0);
    
    int yn(final InputStream p0, final byte[] p1, final int p2, final int p3);
    
    void yp(final InputStream p0);
    
    char[] yy(final CharArrayWriter p0);
    
    void yc(final Writer p0, final char[] p1);
    
    String yx(final StringBuffer p0);
    
    String yh(final Object p0);
    
    int yj(final Reader p0, final char[] p1, final int p2, final int p3);
    
    int yg(final Reader p0);
    
    Buffer yz(final ByteBuffer p0, final int p1);
    
    Buffer yd(final ByteBuffer p0, final int p1);
    
    int yb(final ReadableByteChannel p0, final ByteBuffer p1);
    
    int yw(final ByteBuffer p0);
    
    void ya(final PrintWriter p0);
    
    boolean yl(final Boolean p0);
    
    Throwable yi(final InvocationTargetException p0);
    
    ClassLoader yu(final Thread p0);
    
    Class cf(final ClassLoader p0, final String p1);
    
    Method cm(final Class p0, final String p1, final Class[] p2);
    
    Object cv(final Class p0, final int p1);
    
    boolean co(final Object p0, final Object p1);
    
    String cq(final IOException p0);
    
    void ct(final Thread p0, final boolean p1);
    
    void cr(final Object[] p0, final Comparator p1);
    
    void cs(final List p0, final Comparator p1);
    
    Iterator ck(final Iterable p0);
    
    Object[] ce(final List p0, final Object[] p1);
    
    int cn(final Comparator p0, final Object p1, final Object p2);
    
    int cp(final File p0, final File p1);
    
    List cy(final List p0);
    
    boolean cc(final List p0, final Object p1);
    
    void cx(final List p0);
    
    boolean ch(final List p0, final Collection p1);
    
    boolean cj(final FileFilter p0, final File p1);
    
    boolean cg(final FilenameFilter p0, final File p1, final String p2);
    
    boolean cz(final File p0);
    
    boolean cd(final File p0);
    
    void cb(final RandomAccessFile p0, final long p1);
    
    int cw(final RandomAccessFile p0, final byte[] p1);
    
    boolean ca(final byte[] p0, final byte[] p1);
    
    Pattern cl(final String p0);
    
    Pattern ci(final String p0, final int p1);
    
    Matcher cu(final Pattern p0, final CharSequence p1);
    
    boolean xf(final Matcher p0);
    
    void xm(final InputStream p0, final int p1);
    
    void xv(final InputStream p0);
    
    long xo(final InputStream p0, final long p1);
    
    int xq(final InputStream p0);
    
    boolean xt(final InputStream p0);
    
    void xr(final Reader p0);
    
    void xs(final Reader p0);
    
    void xk(final Reader p0, final int p1);
    
    CharsetEncoder xe(final Charset p0);
    
    CharsetEncoder xn(final CharsetEncoder p0, final CodingErrorAction p1);
    
    CharsetEncoder xp(final CharsetEncoder p0, final CodingErrorAction p1);
    
    float xy(final CharsetEncoder p0);
    
    StringBuilder xc(final StringBuilder p0, final float p1);
    
    CharBuffer xx(final CharSequence p0);
    
    ByteBuffer xh(final ByteBuffer p0);
    
    CoderResult xj(final CharsetEncoder p0, final CharBuffer p1, final ByteBuffer p2, final boolean p3);
    
    boolean xg(final CoderResult p0);
    
    void xz(final CoderResult p0);
    
    boolean xd(final ByteBuffer p0);
    
    boolean xb(final CharBuffer p0);
    
    ByteBuffer xw(final ByteBuffer p0, final byte[] p1, final int p2, final int p3);
    
    byte xa(final ByteBuffer p0);
    
    int xl(final CharBuffer p0);
    
    int xi(final CharBuffer p0);
    
    Buffer xu(final CharBuffer p0);
    
    Buffer hf(final ByteBuffer p0);
    
    CharsetEncoder hm(final CharsetEncoder p0);
    
    Buffer hv(final CharBuffer p0);
    
    Buffer ho(final ByteBuffer p0);
    
    int hq(final CharSequence p0);
    
    char ht(final CharSequence p0, final int p1);
    
    String hr(final ObjectStreamClass p0);
    
    Class hs(final String p0, final boolean p1, final ClassLoader p2);
    
    Class hk(final ClassLoader p0, final Class[] p1);
    
    Object he(final InheritableThreadLocal p0);
    
    void hn(final InheritableThreadLocal p0, final Object p1);
    
    int hp(final CharBuffer p0);
    
    int hy(final Reader p0, final CharBuffer p1);
    
    long hc(final Reader p0, final long p1);
    
    boolean hx(final Reader p0);
    
    boolean hh(final Reader p0);
    
    CharBuffer hj(final int p0);
    
    Buffer hg(final CharBuffer p0);
    
    boolean hz(final CoderResult p0);
    
    CharBuffer hd(final CharBuffer p0);
    
    char[] hb(final CharBuffer p0);
    
    Buffer hw(final CharBuffer p0, final int p1);
    
    int ha(final RandomAccessFile p0, final byte[] p1, final int p2, final int p3);
    
    long hl(final RandomAccessFile p0);
    
    void hi(final RandomAccessFile p0);
    
    UUID hu();
    
    long jf(final RandomAccessFile p0);
    
    byte[] jm(final ByteArrayOutputStream p0);
    
    void jv(final ByteArrayOutputStream p0);
    
    void jo(final ByteArrayOutputStream p0, final int p1);
    
    String jq(final URLConnection p0);
    
    String jt(final String p0, final Object[] p1);
    
    int jr(final String p0, final String p1);
    
    boolean js(final Matcher p0);
    
    String jk(final Matcher p0, final int p1);
    
    String je(final String p0, final Locale p1);
    
    StringBuffer jn(final StringBuffer p0, final String p1);
    
    boolean jp(final String p0, final String p1);
    
    Thread jy(final ThreadFactory p0, final Runnable p1);
    
    void jc(final Thread p0, final long p1);
    
    Appendable jx(final Appendable p0, final char p1);
    
    Enumeration jh(final Collection p0);
    
    File jj(final String p0, final String p1, final File p2);
    
    void jg(final Writer p0, final int p1);
    
    void jz(final Writer p0, final String p1, final int p2, final int p3);
    
    void jd(final Writer p0);
    
    void jb(final Writer p0);
    
    boolean jw(final File p0);
    
    Writer ja(final Writer p0, final char p1);
    
    Writer jl(final Writer p0, final CharSequence p1, final int p2, final int p3);
    
    Writer ji(final Writer p0, final CharSequence p1);
    
    StringBuilder ju(final StringBuilder p0, final CharSequence p1);
    
    StringBuilder gf(final StringBuilder p0, final CharSequence p1, final int p2, final int p3);
    
    StringBuilder gm(final StringBuilder p0, final char[] p1, final int p2, final int p3);
    
    Charset gv(final CharsetDecoder p0);
    
    CharsetDecoder go(final Charset p0);
    
    CharsetDecoder gq(final CharsetDecoder p0, final CodingErrorAction p1);
    
    CharsetDecoder gt(final CharsetDecoder p0, final CodingErrorAction p1);
    
    CharsetDecoder gr(final CharsetDecoder p0, final String p1);
    
    ByteBuffer gs(final ByteBuffer p0, final byte[] p1, final int p2, final int p3);
    
    CoderResult gk(final CharsetDecoder p0, final ByteBuffer p1, final CharBuffer p2, final boolean p3);
    
    boolean ge(final CoderResult p0);
    
    String gn(final StringWriter p0);
    
    StringBuffer gp(final StringWriter p0);
    
    int gy(final StringBuffer p0);
    
    void gc(final StringWriter p0, final char[] p1, final int p2, final int p3);
    
    String gx(final StringBuffer p0, final int p1, final int p2);
    
    int gh(final StringBuffer p0, final String p1);
    
    Set gj(final Set p0);
    
    boolean gg(final Set p0, final Object p1);
    
    String gz(final Class p0);
}
