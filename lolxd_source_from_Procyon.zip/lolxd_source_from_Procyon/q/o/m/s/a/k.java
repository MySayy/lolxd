// 
// Decompiled by Procyon v0.5.36
// 

package q.o.m.s.a;

import java.io.InputStream;
import java.util.zip.GZIPInputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;

public class k extends ClassLoader
{
    private byte[] b;
    
    public k(final ClassLoader parent, final String name, final int n) {
        super(parent);
        try {
            final InputStream resourceAsStream = parent.getResourceAsStream(name);
            new DataInputStream(resourceAsStream).readFully(this.b = new byte[n], 0, resourceAsStream.available());
            for (int i = 7; i >= 0; --i) {
                this.b[7 - i] = (byte)(2272919233031569408L >> 8 * i & 0xFFL);
            }
            resourceAsStream.close();
            final GZIPInputStream in = new GZIPInputStream(new ByteArrayInputStream(this.b.clone()));
            new DataInputStream(in).readFully(this.b);
            in.close();
        }
        catch (Exception ex) {
            while (true) {}
        }
    }
    
    public Class<?> createClass(final String s) throws ClassNotFoundException {
        try {
            return super.defineClass(s, this.b, 0, this.b.length);
        }
        catch (Exception ex) {
            return super.findClass(s);
        }
    }
}
